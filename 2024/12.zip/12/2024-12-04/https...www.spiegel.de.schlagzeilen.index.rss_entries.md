# Source:DER SPIEGEL - Schlagzeilen, URL:https://www.spiegel.de/schlagzeilen/index.rss, language:de

## DFB-Pokal: Der 1. FC Köln schlägt Hertha BSC im Achtelfinale
 - [https://www.spiegel.de/sport/dfb-pokal-der-1-fc-koeln-schlaegt-hertha-bsc-im-achtelfinale-a-b9308976-1d2f-4768-a44d-cc4cd40bc0b4#ref=rss](https://www.spiegel.de/sport/dfb-pokal-der-1-fc-koeln-schlaegt-hertha-bsc-im-achtelfinale-a-b9308976-1d2f-4768-a44d-cc4cd40bc0b4#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T23:21:55.873940+00:00

Hertha BSC und der 1. FC Köln treffen im Achtelfinale des DFB-Pokals aufeinander – und damit auch die Köpfe ihrer Spieler. Zwischen Platzwunde und Platzverweis setzt sich das klügere Team durch.

## DFB-Pokal: RB Leipzig wirft Eintracht Frankfurt aus dem Pokal und kann dabei auf sein Sturmduo bauen
 - [https://www.spiegel.de/sport/fussball/dfb-pokal-rb-leipzig-wirft-eintracht-frankfurt-aus-dem-pokal-und-kann-dabei-auf-sein-sturmduo-bauen-a-e04f5664-5b74-40cb-9bd5-793c61fe1036#ref=rss](https://www.spiegel.de/sport/fussball/dfb-pokal-rb-leipzig-wirft-eintracht-frankfurt-aus-dem-pokal-und-kann-dabei-auf-sein-sturmduo-bauen-a-e04f5664-5b74-40cb-9bd5-793c61fe1036#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T23:21:55.403653+00:00

Leipzig schien das Gewinnen verlernt zu haben, Marco Rose wirkte wie ein Trainer auf Abruf – und dann kommt Frankfurt mit seinen gefürchteten Angreifern. Von denen aber ist nichts zu sehen, dafür überragen zwei Leipziger Stürmer.

## Südkorea: Regierungspartei lehnt Amtsenthebung von Präsident Yoon Suk-yeol ab
 - [https://www.spiegel.de/ausland/suedkorea-regierungspartei-lehnt-amtsenthebung-von-praesident-yoon-suk-yeol-ab-a-9b50270b-f560-4da4-9dfb-d954364fc5cd#ref=rss](https://www.spiegel.de/ausland/suedkorea-regierungspartei-lehnt-amtsenthebung-von-praesident-yoon-suk-yeol-ab-a-9b50270b-f560-4da4-9dfb-d954364fc5cd#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T23:21:55.013250+00:00

Sechs Stunden lang galt das Kriegsrecht in Südkorea, dann hob Präsident Yoon es wieder auf – auch auf Druck aus seiner Partei. Beim Oppositionsantrag auf Amtsenthebung steht sie nun aber wohl auf der Seite des Staatschefs.

## Kylian Mbappé: Erneuter Elfmeter-Patzer bei Real-Madrid-Niederlage gegen Bilbao
 - [https://www.spiegel.de/sport/fussball/kylian-mbappe-erneuter-elfmeter-patzer-bei-real-madrid-niederlage-gegen-bilbao-a-a6c6df10-f961-4c19-972a-f880eb2739ce#ref=rss](https://www.spiegel.de/sport/fussball/kylian-mbappe-erneuter-elfmeter-patzer-bei-real-madrid-niederlage-gegen-bilbao-a-a6c6df10-f961-4c19-972a-f880eb2739ce#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T23:21:54.673180+00:00

Schon gegen den FC Liverpool patzte Superstar Kylian Mbappé vom Punkt, die Kritik an ihm war danach vernichtend. Nun leistet er sich erneut ein Missgeschick, Real kommt dem FC Barcelona in der Tabelle nicht näher.

## Premier League: Jack Stephens zieht Marc Cucurella an den Haaren und sieht Rot
 - [https://www.spiegel.de/sport/fussball/premier-league-jack-stephens-zieht-marc-cucurella-an-den-haaren-und-sieht-rot-a-71457790-979f-4e36-81d7-550281f757b7#ref=rss](https://www.spiegel.de/sport/fussball/premier-league-jack-stephens-zieht-marc-cucurella-an-den-haaren-und-sieht-rot-a-71457790-979f-4e36-81d7-550281f757b7#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T23:21:54.122757+00:00

Bei der EM stand Marc Cucurella im Fokus, als sein vermeintliches Handspiel im Viertelfinale gegen Deutschland nicht geahndet wurde. Nun wurde er Opfer einer Tätlichkeit. Außerdem darf Manchester City aufatmen.

## Israel-Gaza-Krieg: Leiche von deutsch-israelischer Geisel Itay Svirsky geborgen
 - [https://www.spiegel.de/ausland/israel-gaza-krieg-leiche-von-deutsch-israelischer-geisel-itay-svirsky-geborgen-a-1b05d734-9236-4855-9d7c-50bcfd6b2f5e#ref=rss](https://www.spiegel.de/ausland/israel-gaza-krieg-leiche-von-deutsch-israelischer-geisel-itay-svirsky-geborgen-a-1b05d734-9236-4855-9d7c-50bcfd6b2f5e#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:00+00:00

Im Januar hatte Israel den Tod von Itay Svirsky gemeldet. Jetzt haben Spezialkräfte die Leiche der deutsch-israelischen Hamas-Geisel im Gazatsreifen geborgen. Dort halten Terroristen noch immer Dutzende Menschen fest.

## Frankreich: Regierung abgewählt - Emmanuel Macron unter Druck
 - [https://www.spiegel.de/ausland/frankreich-regierung-abgewaehlt-emmanuel-macron-unter-druck-a-adae5251-ce88-4511-b64a-3beed9dfaf7f#ref=rss](https://www.spiegel.de/ausland/frankreich-regierung-abgewaehlt-emmanuel-macron-unter-druck-a-adae5251-ce88-4511-b64a-3beed9dfaf7f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T22:16:38.726133+00:00

Die ultrarechte Marine Le Pen stürzt die Regierung um Premier Barnier, die Schulden steigen ungebremst: Frankreich versinkt in einer schweren politischen Krise. Kann sich Präsident Macron halten?

## DFB-Pokal: RB Leipzig schlägt Eintracht Frankfurt deutlich, Loïs Openda trifft doppelt
 - [https://www.spiegel.de/sport/fussball/dfb-pokal-rb-leipzig-schlaegt-eintracht-frankfurt-deutlich-lois-openda-trifft-doppelt-a-44676a53-db9d-4179-b1ac-af17eda2f1af#ref=rss](https://www.spiegel.de/sport/fussball/dfb-pokal-rb-leipzig-schlaegt-eintracht-frankfurt-deutlich-lois-openda-trifft-doppelt-a-44676a53-db9d-4179-b1ac-af17eda2f1af#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T22:16:38.459702+00:00

Der Pokalsieger von 2022 und 2023 steht auch in diesem Jahr unter den letzten Acht: RB Leipzig dominiert Eintracht Frankfurt auf ganzer Linie – und betreibt Wiedergutmachung für einen desolaten November.

## Donald Trump: Jared Isaacman soll Nasa-Chef werden
 - [https://www.spiegel.de/ausland/donald-trump-jared-isaacman-soll-nasa-chef-werden-a-ac3bfaf0-91c3-4d7c-9497-833cdc801fac#ref=rss](https://www.spiegel.de/ausland/donald-trump-jared-isaacman-soll-nasa-chef-werden-a-ac3bfaf0-91c3-4d7c-9497-833cdc801fac#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T21:11:13.121020+00:00

Donald Trump verteilt weitere Posten. Der Milliardär, All-Ausflügler und Musk-Bewunderer Jared Isaacman soll künftig die Raumfahrtbehörde Nasa leiten. Ein verurteilter Straftäter darf als Berater zurück ins Weiße Haus.

## Syrien: Recep Tayyip Erdoğan hat Diktator Baschar al-Assad in der Hand
 - [https://www.spiegel.de/ausland/syrien-recep-tayyip-erdogan-hat-diktator-baschar-al-assad-in-der-hand-a-8626f885-1e6d-416f-963d-f3f1fe8b5895#ref=rss](https://www.spiegel.de/ausland/syrien-recep-tayyip-erdogan-hat-diktator-baschar-al-assad-in-der-hand-a-8626f885-1e6d-416f-963d-f3f1fe8b5895#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T21:11:13.011612+00:00

Der türkische Präsident Erdoğan ist der wichtigste Unterstützer der syrischen Rebellen. Jedes Entgegenkommen gegenüber Diktator Assad wird er sich teuer bezahlen lassen.

## New York: United Healthcare-CEO Brian Thompson erschossen - Täter auf der Flucht
 - [https://www.spiegel.de/panorama/new-york-united-healthcare-ceo-brian-thompson-erschossen-taeter-auf-der-flucht-a-6d890860-0199-4365-9a46-83fa8ea4a0ca#ref=rss](https://www.spiegel.de/panorama/new-york-united-healthcare-ceo-brian-thompson-erschossen-taeter-auf-der-flucht-a-6d890860-0199-4365-9a46-83fa8ea4a0ca#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T21:06:00+00:00

Der Chef eines der größten US-Versicherer, United Healthcare ist mitten in Manhattan erschossen worden. Der Täter lauerte Brian Thompson vor einem Hotel auf, seine Spur verliert sich im Central Park.

## Spotify Wrapped 2024: Was sagt der musikalische Jahresüberblick über mich aus?
 - [https://www.spiegel.de/netzwelt/apps/spotify-wrapped-2024-was-sagt-der-musikalische-jahresueberblick-ueber-mich-aus-a-ba2555a1-a4f7-4cd4-9dea-595acc1fa7e8#ref=rss](https://www.spiegel.de/netzwelt/apps/spotify-wrapped-2024-was-sagt-der-musikalische-jahresueberblick-ueber-mich-aus-a-ba2555a1-a4f7-4cd4-9dea-595acc1fa7e8#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:34.098626+00:00

Spotify Wrapped ist da. Was sagt mein Hörverhalten über mich aus – und warum will ich es posten? Musikwissenschaftler Steffen Lepa erklärt, wann ein Jahresrückblick besorgniserregend ist.

## Frankreich: Parlament stürzt Regierung von Premier Michel Barnier
 - [https://www.spiegel.de/ausland/frankreich-parlament-stuerzt-minderheitsregierung-von-premier-michel-barnier-a-b3797386-ca76-47e7-b3f1-c11c878b7278#ref=rss](https://www.spiegel.de/ausland/frankreich-parlament-stuerzt-minderheitsregierung-von-premier-michel-barnier-a-b3797386-ca76-47e7-b3f1-c11c878b7278#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:33.981406+00:00

Frankreichs Abgeordnete haben der Regierung von Premierminister Barnier mehrheitlich das Misstrauen ausgesprochen. Der Antrag linker Oppositionsparteien wurde vom rechtsnationalen Lager unterstützt.

## Ostsee: Russisches Schiff schießt mit Leuchtmunition auf Bundeswehr-Hubschrauber
 - [https://www.spiegel.de/ausland/ostsee-russisches-schiff-schiesst-mit-leuchtmunition-auf-bundeswehr-hubschrauber-a-f0716e62-bd88-4c23-86e6-938980b8e631#ref=rss](https://www.spiegel.de/ausland/ostsee-russisches-schiff-schiesst-mit-leuchtmunition-auf-bundeswehr-hubschrauber-a-f0716e62-bd88-4c23-86e6-938980b8e631#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:33.865302+00:00

Erneuter Zwischenfall in der Ostsee: Ein Hubschrauber der Bundeswehr fliegt an ein russisches Schiff heran – dessen Besatzung antwortet mit Signalmunition.

## DFB-Pokal: 1. FC Köln nach Sieg über Hertha BSC im Viertelfinale, auch Wolfsburg weiter
 - [https://www.spiegel.de/sport/fussball/dfb-pokal-1-fc-koeln-nach-sieg-ueber-hertha-bsc-im-viertelfinale-auch-wolfsburg-weiter-a-e3cec4aa-36fc-45ac-bdd4-49bb397edd8d#ref=rss](https://www.spiegel.de/sport/fussball/dfb-pokal-1-fc-koeln-nach-sieg-ueber-hertha-bsc-im-viertelfinale-auch-wolfsburg-weiter-a-e3cec4aa-36fc-45ac-bdd4-49bb397edd8d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:33.716372+00:00

Platzverweis, Eigentor, Elfmeter: Im dramatischen Pokalduell mit dem 1. FC Köln ist sich die Berliner Hertha selbst der größte Gegner und verliert in der Verlängerung. Der VfL Wolfsburg kommt gegen Hoffenheim weiter.

## Mexiko: Sicherheitskräfte beschlagnahmen mehr als eine Tonne Fentanyl
 - [https://www.spiegel.de/panorama/justiz/mexiko-sicherheitskraefte-beschlagnahmen-mehr-als-eine-tonne-fentanyl-a-4670c0ea-b51b-45f6-bb4f-d532fbc1e2ce#ref=rss](https://www.spiegel.de/panorama/justiz/mexiko-sicherheitskraefte-beschlagnahmen-mehr-als-eine-tonne-fentanyl-a-4670c0ea-b51b-45f6-bb4f-d532fbc1e2ce#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T19:58:00+00:00

Häufig wird die Droge Fentanyl in Mexiko produziert und dann in die USA geschmuggelt. Nun ist Ermittlern offenbar ein Schlag gegen das Beltrán-Leyva-Kartell gelungen.

## Popkultur: Sind Taylor Swift und Co. die Top-Künstlerinnen des Jahres? Der Spotify-Jahresrückblick gibt Aufschluss
 - [https://www.spiegel.de/kultur/musik/popkultur-sind-taylor-swift-und-co-die-top-kuenstlerinnen-des-jahres-der-spotify-jahresrueckblick-gibt-aufschluss-a-68281e72-f16d-4b0f-8826-511b6f5a8587#ref=rss](https://www.spiegel.de/kultur/musik/popkultur-sind-taylor-swift-und-co-die-top-kuenstlerinnen-des-jahres-der-spotify-jahresrueckblick-gibt-aufschluss-a-68281e72-f16d-4b0f-8826-511b6f5a8587#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T19:01:12.225367+00:00

2024 dominierten die Popfrauen die Charts. Aber zählen sie auch zu den Topkünstlerinnen des Kulturressorts? Oder wurden doch mehr Beatles gehört? Die persönlichen Spotify-Listen sind entlarvend. Wir teilen sie trotzdem.

## Argentinien: Taugt Javier Milei wirklich als Vorbild für Deutschland?
 - [https://www.spiegel.de/ausland/argentinien-taugt-javier-milei-wirklich-als-vorbild-fuer-deutschland-a-77e7e9ee-31e0-4307-9379-e0a154551c61#ref=rss](https://www.spiegel.de/ausland/argentinien-taugt-javier-milei-wirklich-als-vorbild-fuer-deutschland-a-77e7e9ee-31e0-4307-9379-e0a154551c61#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T19:01:11.969821+00:00

FDP-Chef Lindner will »mehr Milei wagen«, preist die Wirtschaftspolitik des argentinischen Präsidenten. Der hat die horrende Inflation in seinem Land tatsächlich gesenkt. Doch es ist ein Erfolg auf Pump.

## Sachsen-Anhalt: Förderbank förderte Kauf eines Luxussportwagens mit rund 50.000 Euro
 - [https://www.spiegel.de/wirtschaft/sachsen-anhalt-foerderbank-foerderte-kauf-eines-luxussportwagens-mit-rund-50-000-euro-a-cfd1fd63-8e9f-4ae5-a612-2ce4ccac83d6#ref=rss](https://www.spiegel.de/wirtschaft/sachsen-anhalt-foerderbank-foerderte-kauf-eines-luxussportwagens-mit-rund-50-000-euro-a-cfd1fd63-8e9f-4ae5-a612-2ce4ccac83d6#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T19:01:11.712594+00:00

Ein Unternehmer wollte seinen Luxuswagen gegen einen neuen Luxuswagen tauschen. Die Investitionsbank Sachsen-Anhalt unterstützte ihn mit Steuergeldern – sieht die Schuld dafür aber nicht bei sich.

## FDP: Wie sich Christian Lindner an Elon Musk und Javier Milei orientiert
 - [https://www.spiegel.de/politik/deutschland/fdp-wie-sich-christian-lindner-an-elon-musk-und-javier-milei-orientiert-a-00873408-b0d6-48b1-8d2f-caba683c0f5a#ref=rss](https://www.spiegel.de/politik/deutschland/fdp-wie-sich-christian-lindner-an-elon-musk-und-javier-milei-orientiert-a-00873408-b0d6-48b1-8d2f-caba683c0f5a#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T19:01:11.461075+00:00

Christian Lindner hält sich an der Spitze der FDP, trotz der Skandale seit dem Ampel-Aus. Denn was wäre die Partei ohne ihn? SPIEGEL-Redakteur Florian Gathmann erklärt, wie Lindner jetzt das Schlimmste verhindern will.

## FDP: Wie sich Christian Lindner an Elon Musk und Javier Milei orientiert – Podcast
 - [https://www.spiegel.de/politik/deutschland/fdp-wie-sich-christian-lindner-an-elon-musk-und-javier-milei-orientiert-podcast-a-69053354-b364-496f-9d02-ec7e8b4ba4e5#ref=rss](https://www.spiegel.de/politik/deutschland/fdp-wie-sich-christian-lindner-an-elon-musk-und-javier-milei-orientiert-podcast-a-69053354-b364-496f-9d02-ec7e8b4ba4e5#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T19:01:11.207074+00:00

Christian Lindner hält sich an der Spitze der FDP, trotz der Skandale seit dem Ampel-Aus. Denn was wäre die Partei ohne ihn? SPIEGEL-Redakteur Florian Gathmann erklärt, wie Lindner jetzt das Schlimmste verhindern will.

## Bundeswehr: Bundesregierung beschließt neue Strategie für Rüstungsindustrie
 - [https://www.spiegel.de/politik/bundeswehr-bundesregierung-beschliesst-neue-strategie-fuer-ruestungsindustrie-a-de680149-418b-41aa-98ed-bbde0c28bfbe#ref=rss](https://www.spiegel.de/politik/bundeswehr-bundesregierung-beschliesst-neue-strategie-fuer-ruestungsindustrie-a-de680149-418b-41aa-98ed-bbde0c28bfbe#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T19:01:10.950457+00:00

Geplant wurde die neue Sicherheitsstrategie noch in der Ampel, erst jetzt wurde sie fertig. Künftig sollen mehr Rüstungsgüter schneller produziert werden. Das Ziel: Deutschland soll »schnellstmöglich wehrhaft« werden.

## Norwegen: Anders Breivik scheitert mit Klage auf vorzeitige Entlassung aus der Haft
 - [https://www.spiegel.de/panorama/justiz/norwegen-anders-breivik-scheitert-mit-klage-auf-vorzeitige-entlassung-aus-der-haft-a-2b4f8bc7-8447-46a1-a9c2-009ef5be7532#ref=rss](https://www.spiegel.de/panorama/justiz/norwegen-anders-breivik-scheitert-mit-klage-auf-vorzeitige-entlassung-aus-der-haft-a-2b4f8bc7-8447-46a1-a9c2-009ef5be7532#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T18:54:00+00:00

Zum zweiten Mal hat Anders Behring Breivik eine Verkürzung seiner Gefängnisstrafe beantragt, zum zweiten Mal ist er gescheitert. Der norwegische Massenmörder bleibt hinter Gittern.

## News des Tages: Olaf Scholz, Jan Marsalek, Spotify "Wrapped 2024"
 - [https://www.spiegel.de/politik/deutschland/news-des-tages-olaf-scholz-jan-marsalek-spotify-wrapped-2024-a-f6d378af-b130-432e-bcfa-5a9b8907fc4e#ref=rss](https://www.spiegel.de/politik/deutschland/news-des-tages-olaf-scholz-jan-marsalek-spotify-wrapped-2024-a-f6d378af-b130-432e-bcfa-5a9b8907fc4e#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T17:56:58.242966+00:00

Die Opposition greift im Bundestag den Kanzler an, der geht in die Offensive. In London läuft ein spektakulärer Spionageprozess mit Jan Marsalek im Zentrum. Kinder sind in Mathe Durchschnitt. Das ist die Lage am Mittwochabend.

## Westjordanland: Dutzende Siedler sollen Dörfer verwüstet haben
 - [https://www.spiegel.de/ausland/westjordanland-dutzende-siedler-sollen-doerfer-verwuestet-haben-a-9f15d59a-255c-4d94-a6ce-d70279bfd885#ref=rss](https://www.spiegel.de/ausland/westjordanland-dutzende-siedler-sollen-doerfer-verwuestet-haben-a-9f15d59a-255c-4d94-a6ce-d70279bfd885#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T17:56:58.120241+00:00

Neue Übergriffe im Westjordanland: Israelische Siedler sollen Autos und Häuser von Palästinensern angezündet und verwüstet haben. Acht Personen wurden festgenommen.

## Fifa-Klub-WM: DAZN zeigt alle Spiele des XXL-Turniers kostenfrei
 - [https://www.spiegel.de/sport/fussball/fifa-klub-wm-dazn-zeigt-alle-spiele-des-xxl-turniers-kostenfrei-a-03641256-0cfc-446c-b29d-7f648fdb507f#ref=rss](https://www.spiegel.de/sport/fussball/fifa-klub-wm-dazn-zeigt-alle-spiele-des-xxl-turniers-kostenfrei-a-03641256-0cfc-446c-b29d-7f648fdb507f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T17:56:57.977601+00:00

Die Fifa hat die Klub-WM revolutioniert und ein XXL-Turnier mit 32 Teams erfunden. Los geht es im kommenden Sommer in den USA, aus Deutschland sind Bayern und Dortmund dabei. Nun steht fest, wo man die Spiele sehen kann.

## Libanon: Afrikanische Gastarbeiterinnen - Gefangen im »Kafala«-System
 - [https://www.spiegel.de/ausland/libgefangene-frauen-im-kafala-system-moderne-sklaverei-im-libanon-a-725f226d-d553-4d52-b9a9-60270c0c266e#ref=rss](https://www.spiegel.de/ausland/libgefangene-frauen-im-kafala-system-moderne-sklaverei-im-libanon-a-725f226d-d553-4d52-b9a9-60270c0c266e#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T17:56:57.851218+00:00

Zehntausende ausländische Arbeitskräfte leben im Libanon. Viele sind ihren Arbeitgebern ausgeliefert, es kommt zu Missbrauch und Ausbeutung. Der Krieg zwischen Israel und der Hisbollah hat die Not der Frauen noch verschärft.

## Bordesholm: Landfrauen sagen Kuchenverkauf wegen Vorschriften ab
 - [https://www.spiegel.de/panorama/bordesholm-landfrauen-sagen-kuchenverkauf-wegen-vorschriften-ab-a-30b2e1d5-2f64-4187-a7a2-374a48b3eab0#ref=rss](https://www.spiegel.de/panorama/bordesholm-landfrauen-sagen-kuchenverkauf-wegen-vorschriften-ab-a-30b2e1d5-2f64-4187-a7a2-374a48b3eab0#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T17:56:57.716542+00:00

In Bordesholm haben die Landfrauen ihren Kuchenverkauf auf dem Weihnachtsmarkt abgesagt, sie sehen sich durch zu viele Vorschriften überfordert. Hier erklärt die Vorsitzende die Entscheidung und ihren Plan B.

## Keir Starmer: 99-jährige Rentnerin reist 8000 Kilometer für Treffen – doch der britische Premier blockt ab
 - [https://www.spiegel.de/kultur/keir-starmer-99-jaehrige-rentnerin-reist-8000-kilometer-fuer-treffen-doch-der-britische-premier-blockt-ab-a-91b2a7ff-2956-4faf-b2c4-544b64fa3dae#ref=rss](https://www.spiegel.de/kultur/keir-starmer-99-jaehrige-rentnerin-reist-8000-kilometer-fuer-treffen-doch-der-britische-premier-blockt-ab-a-91b2a7ff-2956-4faf-b2c4-544b64fa3dae#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T17:56:00+00:00

Eine Britin setzt sich für im Ausland lebende Rentner ein. Premier Keir Starmer aber versagt der Weltkriegsveteranin ein Treffen. Jetzt hat der Labour-Politiker ein Problem mit älteren Bürgern im Königreich.

## Marc Seaberg: Der Originalsänger von »Looking for Freedom« ist tot
 - [https://www.spiegel.de/kultur/musik/marc-seaberg-der-originalsaenger-von-looking-for-freedom-ist-tot-a-9fd6c454-1298-4035-a178-21b1ce8e826b#ref=rss](https://www.spiegel.de/kultur/musik/marc-seaberg-der-originalsaenger-von-looking-for-freedom-ist-tot-a-9fd6c454-1298-4035-a178-21b1ce8e826b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T17:50:00+00:00

Elf Jahre bevor David Hasselhoff damit die Berliner Mauer stürzen wollte, war »Looking for Freedom« schon einmal ein Hit. Damals sang ein Franke, der sich Marc Seaberg nannte, das Lied. Nun ist er im Alter von 78 Jahren gestorben.

## Schokolade: Diese Süßigkeit naschten die Brüder Grimm beim Märchensammeln
 - [https://www.spiegel.de/panorama/schokolade-diese-suessigkeit-naschten-die-brueder-grimm-beim-maerchensammeln-a-4e6d4288-7e83-4839-86fd-6202b6016b6b#ref=rss](https://www.spiegel.de/panorama/schokolade-diese-suessigkeit-naschten-die-brueder-grimm-beim-maerchensammeln-a-4e6d4288-7e83-4839-86fd-6202b6016b6b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:17.278635+00:00

Schon die Brüder Grimm gönnten sich gerne mal ein Stück Schokolade. Das hat eine Kunsthistorikerin herausgefunden. Eine historische Gewissheit ist damit hinfällig.

## Georgien: Oppositionspolitiker Nika Gwaramia offerbar bewusstlos geschlagen und festgenommen
 - [https://www.spiegel.de/ausland/georgien-oppositionspolitiker-nika-gwaramia-offerbar-bewusstlos-geschlagen-und-festgenommen-a-46f7da79-5d41-4c4c-9fed-9a53f6e76f89#ref=rss](https://www.spiegel.de/ausland/georgien-oppositionspolitiker-nika-gwaramia-offerbar-bewusstlos-geschlagen-und-festgenommen-a-46f7da79-5d41-4c4c-9fed-9a53f6e76f89#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:17.021718+00:00

Nika Gwaramia gehört zu den bekanntesten Vertretern der georgischen Opposition. Nun wurde der Anwalt und Politiker offenbar von Polizisten brutal attackiert – und anschließend festgenommen.

## Olaf Scholz: Patzer beim Thema Südkorea - Opposition nutzt Steilvorlage
 - [https://www.spiegel.de/politik/deutschland/olaf-scholz-patzer-beim-thema-suedkorea-opposition-nutzt-steilvorlage-a-8baeddd7-2126-436e-8cab-c831f0d5524d#ref=rss](https://www.spiegel.de/politik/deutschland/olaf-scholz-patzer-beim-thema-suedkorea-opposition-nutzt-steilvorlage-a-8baeddd7-2126-436e-8cab-c831f0d5524d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:16.764387+00:00

Der Kanzler schaltete bei der Regierungsbeauftragung auf Attacke. Bei der Lage in Südkorea war Olaf Scholz allerdings nicht ganz auf dem aktuellen Stand. Eine Steilvorlage für die Opposition.

## Klaasohm auf Borkum: Interview mit Ethnologin Heidrun Alzheimer zu frauenfeindlichen Bräuchen
 - [https://www.spiegel.de/panorama/gesellschaft/klaasohm-auf-borkum-interview-mit-ethnologin-heidrun-alzheimer-zu-frauenfeindlichen-braeuchen-a-44d9f05e-b51f-41e7-9f43-d89149c7e10f#ref=rss](https://www.spiegel.de/panorama/gesellschaft/klaasohm-auf-borkum-interview-mit-ethnologin-heidrun-alzheimer-zu-frauenfeindlichen-braeuchen-a-44d9f05e-b51f-41e7-9f43-d89149c7e10f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:16.457947+00:00

Beim Klaasohm auf Borkum wurden jahrelang Frauen geschlagen. Trotzdem protestierten einige für den Erhalt des Brauchs. Die Ethnologin Heidrun Alzheimer warnt, dass solche Bräuche die Hemmschwelle für Gewalt senken.

## Primastrom, Voxenergie und Nowenergy: Geld zurück vom Stromanbieter ‒ nur noch bis Dezember
 - [https://www.spiegel.de/wirtschaft/primastrom-voxenergie-und-nowenergy-geld-zurueck-vom-stromanbieter-nur-noch-bis-dezember-a-439fa1e3-9bbe-4b26-95c4-161854c87dee#ref=rss](https://www.spiegel.de/wirtschaft/primastrom-voxenergie-und-nowenergy-geld-zurueck-vom-stromanbieter-nur-noch-bis-dezember-a-439fa1e3-9bbe-4b26-95c4-161854c87dee#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:16.207246+00:00

Hohe Preise und abgelehnte Widerrufe: Durch eine außergerichtliche Einigung können Kunden bestimmter Energiekonzerne Erstattungen beantragen. Aber die Zeit wird knapp.

## Fußball: Wegen Noussair Mazraoui? Manchester United verzichtet auf Regenbogenjacken
 - [https://www.spiegel.de/sport/fussball/fussball-wegen-noussair-mazraoui-manchester-united-verzichtet-auf-regenbogenjacken-a-3edaa7f7-02cd-4324-b875-46289bc12a48#ref=rss](https://www.spiegel.de/sport/fussball/fussball-wegen-noussair-mazraoui-manchester-united-verzichtet-auf-regenbogenjacken-a-3edaa7f7-02cd-4324-b875-46289bc12a48#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:15.866319+00:00

Fußballprofi Noussair Mazraoui war wohl nicht bereit, eine Jacke zu tragen, mit der die LGBTQIA+-Community unterstützt werden sollte. Manchester United blies die Initiative daraufhin ab und sorgt damit für Ärger.

## Berlin: Vater soll Tochter tausendfach missbraucht haben
 - [https://www.spiegel.de/panorama/justiz/berlin-vater-soll-tochter-tausendfach-missbraucht-haben-a-9c38321b-db9b-4845-a817-30ca0ea4b0eb#ref=rss](https://www.spiegel.de/panorama/justiz/berlin-vater-soll-tochter-tausendfach-missbraucht-haben-a-9c38321b-db9b-4845-a817-30ca0ea4b0eb#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:15.427822+00:00

Er drohte ihr offenbar mit der Veröffentlichung von Videoaufnahmen: Ein 47-Jähriger soll seine Tochter ab ihrem 15. Geburtstag täglich zu sexuellen Handlungen genötigt haben. Vor Gericht wies der Mann die Vorwürfe nun zurück.

## Olaf Scholz im Bundestag: Der Kanzler darf wieder Sozi sein
 - [https://www.spiegel.de/politik/deutschland/olaf-scholz-im-bundestag-der-kanzler-darf-wieder-sozi-sein-a-5a84f70e-1e3f-4fd2-8c28-763803b87f60#ref=rss](https://www.spiegel.de/politik/deutschland/olaf-scholz-im-bundestag-der-kanzler-darf-wieder-sozi-sein-a-5a84f70e-1e3f-4fd2-8c28-763803b87f60#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:15.177611+00:00

Auf einmal wirkt der Kanzler wie befreit. Nach der Trennung von der FDP tritt Olaf Scholz im Bundestag so rauflustig auf wie selten. Im Wahlkampf braucht er die Polarisierung.

## USA: Demokraten sichern sich letzten offenen Sitz im Repräsentantenhaus
 - [https://www.spiegel.de/ausland/usa-demokraten-sichern-sich-letzten-offenen-sitz-im-repraesentantenhaus-a-9aa34444-899a-4dde-98e2-71347be62816#ref=rss](https://www.spiegel.de/ausland/usa-demokraten-sichern-sich-letzten-offenen-sitz-im-repraesentantenhaus-a-9aa34444-899a-4dde-98e2-71347be62816#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:14.920647+00:00

Späte Entscheidung in den USA: Der letzte offene Sitz im Repräsentantenhaus geht an den Demokraten Adam Gray. Die Mehrheit der Republikaner konnten sie dennoch nicht abwenden.

## Elektroauto von Mercedes-Benz: Papst Franziskus fährt jetzt ein batterieelektrisches Papamobil
 - [https://www.spiegel.de/auto/elektroauto-von-mercedes-benz-papst-franziskus-faehrt-jetzt-ein-batterieelektrisches-papamobil-a-035b0bd7-8817-4309-a50e-fc6ba38b076b#ref=rss](https://www.spiegel.de/auto/elektroauto-von-mercedes-benz-papst-franziskus-faehrt-jetzt-ein-batterieelektrisches-papamobil-a-035b0bd7-8817-4309-a50e-fc6ba38b076b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:14.661512+00:00

Papst Franziskus hat ein neues Auto, es fährt mit Batterieantrieb. Der Vatikan hat das Sondermodell heute in Rom vorgestellt. Es kommt von einem deutschen Hersteller.

## New York: United Healthcare-CEO Brian Thompson erschossen
 - [https://www.spiegel.de/panorama/new-york-united-health-ceo-brian-thompson-erschossen-a-1c98346c-bfa1-4a29-a0fd-5f5449a85af1#ref=rss](https://www.spiegel.de/panorama/new-york-united-health-ceo-brian-thompson-erschossen-a-1c98346c-bfa1-4a29-a0fd-5f5449a85af1#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:20.944506+00:00

Ein unbekannter Täter hat in Manhattan Schüsse auf Brian Thompson abgefeuert, den Vorstandsvorsitzenden des Versicherungskonzerns United Healthcare. Medienberichten zufolge starb er im Krankenhaus.

## Nordsee: Zollfahndungsamt findet 150 Kilogramm Kokain auf Föhr, Amrum und Sylt
 - [https://www.spiegel.de/panorama/justiz/nordsee-zollfahndungsamt-findet-150-kilogramm-kokain-auf-foehr-amrum-und-sylt-a-876fd401-f03e-4b75-b670-4515cc3c5349#ref=rss](https://www.spiegel.de/panorama/justiz/nordsee-zollfahndungsamt-findet-150-kilogramm-kokain-auf-foehr-amrum-und-sylt-a-876fd401-f03e-4b75-b670-4515cc3c5349#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:20.695463+00:00

An den Stränden von Föhr, Sylt und Amrum ist verbotenes Treibgut angeschwemmt worden: Insgesamt 150 Kilogramm Kokain hat das Zollfahndungsamt sichergestellt. Wie die Pakete in die Nordsee gelangten, ist bislang unklar.

## Tennis: Andre Agassi hielt sich für Weltklasse – bis er Steffi Graf kennenlernte
 - [https://www.spiegel.de/sport/tennis/tennis-andre-agassi-hielt-sich-fuer-weltklasse-bis-er-steffi-graf-kennenlernte-a-8541fd46-bae5-4af7-9a83-3a5f78e89397#ref=rss](https://www.spiegel.de/sport/tennis/tennis-andre-agassi-hielt-sich-fuer-weltklasse-bis-er-steffi-graf-kennenlernte-a-8541fd46-bae5-4af7-9a83-3a5f78e89397#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:20.447177+00:00

Als Tennisprofi zertrümmerte Andre Agassi seine Schläger und war ein Rebell. Auf einer Sportartikelmesse reflektierte der Ehemann von Steffi Graf nun seine Laufbahn und sprach über seinen Sport, den er eigentlich »gehasst« habe.

## Schach-WM: Dommaraju Gukesh schlägt Remismöglichkeit aus, Großmeister reagieren fassungslos
 - [https://www.spiegel.de/sport/schach-wm-dommaraju-gukesh-schlaegt-remismoeglichkeit-aus-grossmeister-reagieren-fassungslos-a-98ee919c-beac-482c-af8d-1478c5ba244d#ref=rss](https://www.spiegel.de/sport/schach-wm-dommaraju-gukesh-schlaegt-remismoeglichkeit-aus-grossmeister-reagieren-fassungslos-a-98ee919c-beac-482c-af8d-1478c5ba244d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:20.197024+00:00

Dommaraju Gukesh war bei der achten WM-Partie im Nachteil – und schlug ein zwischenzeitliches Angebot zum Unentschieden trotzdem aus. Schach-Meister Levy Rozman meint: »Gukesh ist eine Bestie.«

## Psychologie: Resultate der Copsy-Studie - ein Fünftel der Kinder und Jugendlichen in Deutschland ist psychisch belastet
 - [https://www.spiegel.de/gesundheit/psychologie-resultate-der-copsy-studie-ein-fuenftel-der-kinder-und-jugendlichen-in-deutschland-ist-psychisch-belastet-a-d6aa3443-0375-4b12-8e19-7e66c0e3bb4d#ref=rss](https://www.spiegel.de/gesundheit/psychologie-resultate-der-copsy-studie-ein-fuenftel-der-kinder-und-jugendlichen-in-deutschland-ist-psychisch-belastet-a-d6aa3443-0375-4b12-8e19-7e66c0e3bb4d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:19.947764+00:00

Ängste, Einsamkeit und depressive Symptome: Hochgerechnet geht es heute 400.000 Kindern und Jugendlichen in Deutschland schlechter als vor der Coronapandemie. Aber es gibt Möglichkeiten, ihnen zu helfen.

## Taylor Swift und Co.: Frauen an der Spitze des Spotify-Jahresrückblicks 2024
 - [https://www.spiegel.de/kultur/musik/taylor-swift-und-co-frauen-an-der-spitze-des-spotify-jahresrueckblicks-2024-a-03c5e326-141c-4e13-8bc2-2f93f3d190fc#ref=rss](https://www.spiegel.de/kultur/musik/taylor-swift-und-co-frauen-an-der-spitze-des-spotify-jahresrueckblicks-2024-a-03c5e326-141c-4e13-8bc2-2f93f3d190fc#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:19.696668+00:00

Taylor Swift, Sabrina Carpenter, Billie Eilish: Das Jahr der Popfrauen spiegelt sich auch im Spotify-Best-of. Aber eine Ikone fehlt. Gut platzierte Alphamännchen und verhaltensauffällige Machos prägen die Charts aber auch.

## Schweden: Wie das Land mit dem Phänomen der Teenie-Killer umgeht
 - [https://www.spiegel.de/ausland/schweden-wie-das-land-mit-dem-phaenomen-der-teenie-killer-umgeht-a-c8cdab76-bd39-46aa-9f7a-e63d9d64d170#ref=rss](https://www.spiegel.de/ausland/schweden-wie-das-land-mit-dem-phaenomen-der-teenie-killer-umgeht-a-c8cdab76-bd39-46aa-9f7a-e63d9d64d170#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:19.438355+00:00

Teenager bieten sich auf Social Media als Auftragskiller an: Eine Reihe brutaler Taten befeuert in Schweden die Debatte, was Jugendliche zu Mördern macht. Fachleute warnen vor Pauschalurteilen und sind doch oft ratlos.

## Iran: Friedensnobelpreisträgerin Narges Mohammadi vorübergehend aus Gefängnis entlassen
 - [https://www.spiegel.de/ausland/iran-friedensnobelpreistraegerin-narges-mohammadi-voruebergehend-aus-gefaengnis-entlassen-a-14d3c41d-9501-459b-bd76-6ccc8c429a44#ref=rss](https://www.spiegel.de/ausland/iran-friedensnobelpreistraegerin-narges-mohammadi-voruebergehend-aus-gefaengnis-entlassen-a-14d3c41d-9501-459b-bd76-6ccc8c429a44#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:19.141346+00:00

Die iranische Frauenrechtsaktivistin Narges Mohammadi verbüßt eine langjährige Haftstrafe. Nun wurde sie zeitweilig aus dem Gefängnis entlassen. Grund ist offenbar eine ärztliche Empfehlung.

## Olaf Scholz und Friedrich Merz: Schlagabtausch im Bundestag – Livestream
 - [https://www.spiegel.de/politik/deutschland/olaf-scholz-und-friedrich-merz-schlagabtausch-im-bundestag-livestream-a-bb93e569-6b9e-471c-88a7-35c8b74846e9#ref=rss](https://www.spiegel.de/politik/deutschland/olaf-scholz-und-friedrich-merz-schlagabtausch-im-bundestag-livestream-a-bb93e569-6b9e-471c-88a7-35c8b74846e9#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:18.891975+00:00

Wahlkampf im Bundestag: Erstmals seit dem Aus der Ampel-Koalition und der Neuwahl-Entscheidung stand Olaf Scholz im Bundestag den Abgeordneten Rede und Antwort. Sehen Sie hier den Schlagabtausch.

## Grippe-Symptome: Rätselhafte Todesfälle im Kongo – Forscher auf der Suche nach Ursache
 - [https://www.spiegel.de/wissenschaft/grippe-symptome-raetselhafte-todesfaelle-im-kongo-forscher-auf-der-suche-nach-ursache-a-c84410ef-929b-4d9e-9f30-f6a121c65521#ref=rss](https://www.spiegel.de/wissenschaft/grippe-symptome-raetselhafte-todesfaelle-im-kongo-forscher-auf-der-suche-nach-ursache-a-c84410ef-929b-4d9e-9f30-f6a121c65521#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:18.783247+00:00

Die Patienten haben Fieber, Kopfschmerzen, Atemprobleme: Dutzende Menschen sind im Kongo mit grippeähnlichen Symptomen gestorben, die meisten von ihnen Kinder. Ein Expertenteam soll die Lage in der betroffenen Region nun untersuchen.

## Dortmund: Tod von Mouhamed Dramé – Verteidiger bezeichnet Schüsse als "rechtmäßig"
 - [https://www.spiegel.de/panorama/justiz/dortmund-tod-von-mouhamed-drame-verteidiger-bezeichnet-schuesse-als-rechtmaessig-a-83bf0c88-5081-47e2-839f-de91c1db1165#ref=rss](https://www.spiegel.de/panorama/justiz/dortmund-tod-von-mouhamed-drame-verteidiger-bezeichnet-schuesse-als-rechtmaessig-a-83bf0c88-5081-47e2-839f-de91c1db1165#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:00+00:00

Sie zückten Pfefferspray und Taser, dann schoss ein Beamter mit seiner Maschinenpistole. Am Ende war Mouhamed Dramé tot. Vor Gericht in Dortmund bezeichnen die Verteidiger den Polizeieinsatz als rechtmäßig – und plädieren auf Freispruch.

## Schöneck/Vogtland: 20-Jähriger soll mit Softairwaffe auf Bürgermeister geschossen haben
 - [https://www.spiegel.de/panorama/justiz/schoeneck-vogtland-20-jaehriger-soll-mit-softairwaffe-auf-buergermeister-geschossen-haben-a-4f0f03e5-f2f4-4564-a49e-4e7f9b576618#ref=rss](https://www.spiegel.de/panorama/justiz/schoeneck-vogtland-20-jaehriger-soll-mit-softairwaffe-auf-buergermeister-geschossen-haben-a-4f0f03e5-f2f4-4564-a49e-4e7f9b576618#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:56:00+00:00

Der Schütze zielte offenbar aus einem Dachfenster: Die Polizei meldet einen Angriff auf einen Kommunalpolitiker in Sachsen. Die Staatsanwaltschaft ermittelt wegen versuchter gefährlicher Körperverletzung.

## Spotify Wrapped: Taylor Swift Künstlerin des Jahres - Streamingbilanz für 2024
 - [https://www.spiegel.de/kultur/musik/spotify-wrapped-taylor-swift-kuenstlerin-des-jahres-streamingbilanz-fuer-2024-a-080d5dd4-b6f3-4877-88ae-e877d454a361#ref=rss](https://www.spiegel.de/kultur/musik/spotify-wrapped-taylor-swift-kuenstlerin-des-jahres-streamingbilanz-fuer-2024-a-080d5dd4-b6f3-4877-88ae-e877d454a361#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:44:00+00:00

Der Jahresrückblick des Audiostreamers Spotify ist da. In Deutschland war erstmals seit 2017 kein Deutschrapper der meistgestreamte Act, sondern Taylor Swift. Bei den Podcasts rutschten Jan Böhmermann und Olli Schulz ab.

## Spotify Wrapped: Taylor Swift Künstlerin des Jahres, auch in Deutschland
 - [https://www.spiegel.de/kultur/musik/spotify-wrapped-taylor-swift-kuenstlerin-des-jahres-auch-in-deutschland-a-080d5dd4-b6f3-4877-88ae-e877d454a361#ref=rss](https://www.spiegel.de/kultur/musik/spotify-wrapped-taylor-swift-kuenstlerin-des-jahres-auch-in-deutschland-a-080d5dd4-b6f3-4877-88ae-e877d454a361#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:40:50.980294+00:00

Der Jahresrückblick des Audiostreamers Spotify ist da. In Deutschland war erstmals seit 2017 kein Deutschrapper der meistgestreamte Act, sondern Taylor Swift. Bei den Podcasts rutschten Jan Böhmermann und Olli Schulz ab.

## What Role Will the U.S. Play in the World?: "Trump Has Never Been an Isolationist"
 - [https://www.spiegel.de/international/world/what-role-will-the-u-s-play-in-the-world-trump-has-never-been-an-isolationist-a-d5bf1be7-54a6-4f7f-99fd-d60050b6dcd0#ref=rss](https://www.spiegel.de/international/world/what-role-will-the-u-s-play-in-the-world-trump-has-never-been-an-isolationist-a-d5bf1be7-54a6-4f7f-99fd-d60050b6dcd0#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:40:50.864699+00:00

He insists on the U.S. retaining is global supremacy, but wants to stay out of conflicts. In an interview, historian Stephen Wertheim discusses Donald Trump's view of the world, the Republicans' foreign policy views and what it all might mean for Europe.

## Kunstausstellung: Erste große Retrospektive der niederländischen Stilllebenmalerin Rachel Ruysch in der Alten Pinakothek München
 - [https://www.spiegel.de/kultur/kunstausstellung-erste-grosse-retrospektive-der-niederlaendischen-stilllebenmalerin-rachel-ruysch-in-der-alten-pinakothek-muenchen-a-05695e53-afd2-4d2f-80df-387db0b96752#ref=rss](https://www.spiegel.de/kultur/kunstausstellung-erste-grosse-retrospektive-der-niederlaendischen-stilllebenmalerin-rachel-ruysch-in-der-alten-pinakothek-muenchen-a-05695e53-afd2-4d2f-80df-387db0b96752#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:40:50.730339+00:00

Die Alte Pinakothek in München zeigt die erste große Retrospektive der niederländischen Stilllebenmalerin Rachel Ruysch. Opulent, detailverliebt und wissenschaftlich fundiert.

## Schöneck/Vogtland: 20-Jähriger soll mit Softairwaffe auf Bürgermeister Andy Anders geschossen haben
 - [https://www.spiegel.de/panorama/justiz/schoeneck-vogtland-20-jaehriger-soll-mit-softairwaffe-auf-buergermeister-andy-anders-geschossen-haben-a-4f0f03e5-f2f4-4564-a49e-4e7f9b576618#ref=rss](https://www.spiegel.de/panorama/justiz/schoeneck-vogtland-20-jaehriger-soll-mit-softairwaffe-auf-buergermeister-andy-anders-geschossen-haben-a-4f0f03e5-f2f4-4564-a49e-4e7f9b576618#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:40:50.602154+00:00

Der Schütze zielte offenbar aus einem Dachfenster: Die Polizei meldet einen Angriff auf einen Kommunalpolitiker in Sachsen. Die Staatsanwaltschaft ermittelt wegen versuchter gefährlicher Körperverletzung.

## Deutsche Bahn: Union will Milliarden erst nach Vertrauensfrage freigeben
 - [https://www.spiegel.de/wirtschaft/unternehmen/deutsche-bahn-union-will-milliarden-erst-nach-vertrauensfrage-freigeben-a-3fa9811c-22c2-4180-8ede-69b9e15097c6#ref=rss](https://www.spiegel.de/wirtschaft/unternehmen/deutsche-bahn-union-will-milliarden-erst-nach-vertrauensfrage-freigeben-a-3fa9811c-22c2-4180-8ede-69b9e15097c6#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:38:00+00:00

Für ihre Streckensanierung braucht die Deutsche Bahn dringend Geld. Doch die Mittel sind Verhandlungsmasse im Ringen zwischen Regierung und Opposition geworden, wie sich jetzt im Haushaltsausschuss zeigt.

## Nato: Mark Rutte wirft Russland Unterstützung von Nordkoreas Atomprogramm vor
 - [https://www.spiegel.de/ausland/nato-mark-rutte-wirft-russland-unterstuetzung-von-nordkoreas-atomprogramm-vor-a-6392f962-26ab-474e-aa0b-aed003a69b0c#ref=rss](https://www.spiegel.de/ausland/nato-mark-rutte-wirft-russland-unterstuetzung-von-nordkoreas-atomprogramm-vor-a-6392f962-26ab-474e-aa0b-aed003a69b0c#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:38:00+00:00

Nordkorea schickt Russland Soldaten und Waffen für seinen Angriffskrieg. Was erhält das Regime in Pjöngjang im Gegenzug dafür? Nato-Generalsekretär Mark Rutte erhebt nun schwere Vorwürfe.

## Nato-Generalsekretär Mark Rutte wirft Russland Unterstützung von Nordkoreas Atomprogramm vor
 - [https://www.spiegel.de/ausland/nato-generalsekretaer-mark-rutte-wirft-russland-unterstuetzung-von-nordkoreas-atomprogramm-vor-a-6392f962-26ab-474e-aa0b-aed003a69b0c#ref=rss](https://www.spiegel.de/ausland/nato-generalsekretaer-mark-rutte-wirft-russland-unterstuetzung-von-nordkoreas-atomprogramm-vor-a-6392f962-26ab-474e-aa0b-aed003a69b0c#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T14:38:00+00:00

Nordkorea schickt Russland Soldaten und Waffen für seinen Angriffskrieg. Was erhält das Regime in Pjöngjang im Gegenzug dafür? Nato-Generalsekretär Mark Rutte erhebt nun schwere Vorwürfe.

## Düsseldorf: Schülerin darf laut Gerichtsurteil nicht vollverschleiert in Unterricht
 - [https://www.spiegel.de/panorama/bildung/duesseldorf-schuelerin-darf-laut-gerichtsurteil-nicht-vollverschleiert-in-unterricht-a-a9b2d373-a591-40c2-bb54-f99112ea93d7#ref=rss](https://www.spiegel.de/panorama/bildung/duesseldorf-schuelerin-darf-laut-gerichtsurteil-nicht-vollverschleiert-in-unterricht-a-a9b2d373-a591-40c2-bb54-f99112ea93d7#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:37.873439+00:00

Ob Schülerinnen mit Nikab im Klassenraum sitzen dürfen, wird kontrovers diskutiert – und von Richtern unterschiedlich bewertet. Ein Gericht in Düsseldorf lehnte nun den Antrag einer 17-Jährigen ab.

## Annalena Baerbock: Deutsche Politiker reagieren auf Ukraine-Vorstoß
 - [https://www.spiegel.de/politik/annalena-baerbock-deutsche-politiker-reagieren-auf-ukraine-vorstoss-a-e17f055b-8566-4864-9f74-fdd2cb9317a2#ref=rss](https://www.spiegel.de/politik/annalena-baerbock-deutsche-politiker-reagieren-auf-ukraine-vorstoss-a-e17f055b-8566-4864-9f74-fdd2cb9317a2#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:37.740068+00:00

Es ist ein brisantes Gedankenspiel: Bundeswehrsoldaten könnten einen möglichen Waffenstillstand in der Ukraine sichern. Außenministerin Annalena Baerbock erntet für diese Überlegung parteiübergreifend Skepsis und Kritik.

## Syrien und Russland: Offensive gegen Assad beschädigt Reputation von Wladimir Putin
 - [https://www.spiegel.de/ausland/syrien-und-russland-offensive-gegen-assad-beschaedigt-reputation-von-wladimir-putin-a-41e066cf-ff00-42d9-b9b8-096c9284aaf8#ref=rss](https://www.spiegel.de/ausland/syrien-und-russland-offensive-gegen-assad-beschaedigt-reputation-von-wladimir-putin-a-41e066cf-ff00-42d9-b9b8-096c9284aaf8#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:37.628453+00:00

Die Rebellenoffensive gegen Syriens Machthaber beschädigt auch seinen Verbündeten Putin. Expertin Hanna Notte sagt: Russland hat nur begrenzte Mittel, um Assad militärisch zu stützen.

## Greenwashing-Vorwurf: Coca-Cola verabschiedet sich offenbar von Verpackungsziel
 - [https://www.spiegel.de/wissenschaft/greenwashing-vorwurf-coca-cola-verabschiedet-sich-offenbar-von-verpackungsziel-a-66945d37-e8e0-402c-9a2e-327f7418d9dc#ref=rss](https://www.spiegel.de/wissenschaft/greenwashing-vorwurf-coca-cola-verabschiedet-sich-offenbar-von-verpackungsziel-a-66945d37-e8e0-402c-9a2e-327f7418d9dc#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:37.513964+00:00

Eigentlich wollte Coca-Cola den Anteil von Einwegplastik bei Verpackungen deutlich reduzieren. Doch laut einem Bericht ist im Getränkekonzern von verbindlichen Zielmarken für Mehrwegflaschen keine Rede mehr.

## The Netanyahu System: How the Israeli Prime Minister Is Leading His Country into the Abyss
 - [https://www.spiegel.de/international/world/the-netanyahu-system-how-the-israeli-prime-minister-is-leading-his-country-into-the-abyss-a-97a68da1-e3cf-443d-a8b5-0684723ca0b6#ref=rss](https://www.spiegel.de/international/world/the-netanyahu-system-how-the-israeli-prime-minister-is-leading-his-country-into-the-abyss-a-97a68da1-e3cf-443d-a8b5-0684723ca0b6#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:57.518704+00:00

Benjamin Netanyahu is waging an endless war in Gaza and delivering his country into the arms of Israel's extremist right wing - all in a desperate gambit to cling to power. Former confidants describe a man who sees himself as something of a king.

## Ricarda Lang über Zeit als Grünenchefin – »Hatte meine Unbekümmertheit verloren, sprach schablonenhaft«
 - [https://www.spiegel.de/politik/ricarda-lang-ueber-zeit-als-gruenenchefin-hatte-meine-unbekuemmertheit-verloren-sprach-schablonenhaft-a-0da09965-89cd-4822-8145-88414a756b77#ref=rss](https://www.spiegel.de/politik/ricarda-lang-ueber-zeit-als-gruenenchefin-hatte-meine-unbekuemmertheit-verloren-sprach-schablonenhaft-a-0da09965-89cd-4822-8145-88414a756b77#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:57.261516+00:00

Als Grünenchefin klagte Ricarda Lang über persönliche Angriffe und den enormen Stress in der Politik. Nach ihrem Rücktritt gewährte sie nun Einblicke in ihr neues Privatleben – und schaut auf ihre Zeit an der Parteispitze.

## Syrien: Vorstoß der Dschihadisten auf Hama vorerst gestoppt
 - [https://www.spiegel.de/ausland/syrien-vorstoss-der-dschihadisten-auf-hama-vorerst-gestoppt-a-2f5bdab4-3edb-44a1-b9e0-1f0e7bca3e63#ref=rss](https://www.spiegel.de/ausland/syrien-vorstoss-der-dschihadisten-auf-hama-vorerst-gestoppt-a-2f5bdab4-3edb-44a1-b9e0-1f0e7bca3e63#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:57.004329+00:00

Die Offensive islamistischer Kämpfer in Syrien kommt zunächst zum Halt. Die Dschihadisten sollen vor Syriens viertgrößter Stadt Hama zurückgedrängt worden sein.

## Norwegen: Staatsfonds schließt israelisches und russisches Unternehmen aus
 - [https://www.spiegel.de/ausland/norwegen-staatsfonds-schliesst-israelisches-und-russisches-unternehmen-aus-a-c977e8a7-bddb-4fdb-b744-e34b7d930625#ref=rss](https://www.spiegel.de/ausland/norwegen-staatsfonds-schliesst-israelisches-und-russisches-unternehmen-aus-a-c977e8a7-bddb-4fdb-b744-e34b7d930625#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:56.754229+00:00

Weil es Siedlungen im Westjordanland versorgt, trennt sich der norwegische Pensionsfonds vom israelischen Telekommunikationsunternehmen Bezeq. Auch ein russischer Konzern fliegt aus dem Portfolio.

## Südkorea: Verteidigungsminister Kim Yong Hyun nach zeitweiser Ausrufung des Kriegsrechts zum Rücktritt bereit
 - [https://www.spiegel.de/ausland/suedkorea-verteidigungsminister-kim-yong-hyun-nach-zeitweiser-ausrufung-des-kriegsrechts-zum-ruecktritt-bereit-a-d7d426be-7598-46ae-acc3-31d6f60dbde4#ref=rss](https://www.spiegel.de/ausland/suedkorea-verteidigungsminister-kim-yong-hyun-nach-zeitweiser-ausrufung-des-kriegsrechts-zum-ruecktritt-bereit-a-d7d426be-7598-46ae-acc3-31d6f60dbde4#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:56.498164+00:00

Er soll Präsident Yoon Suk-yeol darin unterstützt haben, das Kriegsrecht auszurufen: Nachdem das Parlament die Entscheidung gekippt hat, bietet Verteidigungsminister Kim Yong-hyun nun seinen Rücktritt an.

## Olaf Scholz im Bundestag: Scholz stellt sich den Fragen der Abgeordneten im Bundestag
 - [https://www.spiegel.de/politik/deutschland/olaf-scholz-im-bundestag-scholz-stellt-sich-den-fragen-der-abgeordneten-im-bundestag-a-836d202e-de81-408a-b988-9fe2f8bfd8f5#ref=rss](https://www.spiegel.de/politik/deutschland/olaf-scholz-im-bundestag-scholz-stellt-sich-den-fragen-der-abgeordneten-im-bundestag-a-836d202e-de81-408a-b988-9fe2f8bfd8f5#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:56.243363+00:00

Erstmals seit dem Bruch der Ampel steht Olaf Scholz den Parlamentariern Rede und Antwort. Lesen Sie im Liveblog des SPIEGEL-Politikteams, wie die Opposition den Kanzler angreift und wie er reagiert.

## Klarna: Verbraucherschützer kritisieren Konto-Schnüffelei bei Zahlungsdienstleister
 - [https://www.spiegel.de/netzwelt/apps/klarna-verbraucherschuetzer-kritisieren-konto-schnueffelei-bei-zahlungsdienstleister-a-de915cd3-997e-4b39-ad67-bb5d22969635#ref=rss](https://www.spiegel.de/netzwelt/apps/klarna-verbraucherschuetzer-kritisieren-konto-schnueffelei-bei-zahlungsdienstleister-a-de915cd3-997e-4b39-ad67-bb5d22969635#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:55.943213+00:00

Wer dem Zahlungsdienst Klarna Zugang auf das eigene Konto einräumt, erlaubt dem Fintech-Unternehmen Einblick in die Kontoauszüge. Verbraucherschätzer warnen vor dem »gläsernen Kunden«.

## Ausländische Ärzte in Deutschland: Ihr Antrag wird bearbeitet, die Antwort bekommen Sie – in einem Jahr
 - [https://www.spiegel.de/karriere/auslaendische-aerzte-in-deutschland-ihr-antrag-wird-bearbeitet-die-antwort-bekommen-sie-in-einem-jahr-a-c70a4249-e8bc-429b-9510-ed1016c17220#ref=rss](https://www.spiegel.de/karriere/auslaendische-aerzte-in-deutschland-ihr-antrag-wird-bearbeitet-die-antwort-bekommen-sie-in-einem-jahr-a-c70a4249-e8bc-429b-9510-ed1016c17220#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:55.687779+00:00

Deutschland braucht mehr Ärzte. Aber Mediziner, die nicht aus der EU kommen, haben es schwer. Mohamed Lahyeni ist 33 Jahre alt und stammt aus Tunesien. Ihm half nur der Weg vor Gericht.

## Leistungsstand von Grundschülern: »Können addieren und subtrahieren, darüber hinaus wird es oft schwierig«
 - [https://www.spiegel.de/panorama/bildung/leistungsstand-von-grundschuelern-koennen-addieren-und-subtrahieren-darueber-hinaus-wird-es-oft-schwierig-a-df243447-27c5-484a-b51e-4dc337821c11#ref=rss](https://www.spiegel.de/panorama/bildung/leistungsstand-von-grundschuelern-koennen-addieren-und-subtrahieren-darueber-hinaus-wird-es-oft-schwierig-a-df243447-27c5-484a-b51e-4dc337821c11#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:55.351538+00:00

Etwa jeder vierte Viertklässler in Deutschland hat nur rudimentäre Kenntnisse in Mathematik, zeigt die neue Timss-Studie. Insgesamt erkennt Knut Schwippert, Studienleiter in Deutschland, dennoch eine »starke Leistung«.

## FC Bayern München: Max Eberl liefert sich Scharmützel mit Reporter
 - [https://www.spiegel.de/sport/fussball/fc-bayern-muenchen-max-eberl-liefert-sich-scharmuetzel-mit-reporter-a-edbe9f7f-c17f-43a2-9ba9-3532f30d5fd7#ref=rss](https://www.spiegel.de/sport/fussball/fc-bayern-muenchen-max-eberl-liefert-sich-scharmuetzel-mit-reporter-a-edbe9f7f-c17f-43a2-9ba9-3532f30d5fd7#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:54.997771+00:00

»Das ist mir relativ scheißegal«: Im Anschluss an die Niederlage des FC Bayern gegen Leverkusen lieferte sich Max Eberl ein Scharmützel mit einem Reporter. Schon wieder. Will er ablenken oder ist er nervös?

## Kann ich mein Kind zu sehr verwöhnen, Marlene Hellene?
 - [https://www.spiegel.de/familie/kann-ich-mein-kind-zu-sehr-verwoehnen-marlene-hellene-a-d949a885-526f-4759-9e5d-cd58a425a848#ref=rss](https://www.spiegel.de/familie/kann-ich-mein-kind-zu-sehr-verwoehnen-marlene-hellene-a-d949a885-526f-4759-9e5d-cd58a425a848#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:54.883548+00:00

Viele Menschen reden uns Eltern ein, dass wir unsere Kinder zu sehr behüten und damit weich machen. Ich sage: Gut so!

## Südkorea: Sechs Stunden Chaos
 - [https://www.spiegel.de/ausland/suedkorea-sechs-stunden-chaos-a-6c3f5fd0-0eca-42e7-82a7-c0b901041005#ref=rss](https://www.spiegel.de/ausland/suedkorea-sechs-stunden-chaos-a-6c3f5fd0-0eca-42e7-82a7-c0b901041005#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:23:00+00:00

Südkoreas Präsident verhängt das Kriegsrecht, die Opposition hält dagegen. Soldaten stürmen das Parlament, Abgeordnete stellen sich ihnen in den Weg und erkämpfen eine Abstimmung. Szenen einer turbulenten Nacht.

## Südkorea: Sechs Stunden Chaos - Seoul im Ausnahmezustand
 - [https://www.spiegel.de/ausland/suedkorea-sechs-stunden-chaos-seoul-im-ausnahmezustand-a-6c3f5fd0-0eca-42e7-82a7-c0b901041005#ref=rss](https://www.spiegel.de/ausland/suedkorea-sechs-stunden-chaos-seoul-im-ausnahmezustand-a-6c3f5fd0-0eca-42e7-82a7-c0b901041005#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:23:00+00:00

Südkoreas Präsident verhängt das Kriegsrecht, die Opposition hält dagegen. Soldaten stürmen das Parlament, Abgeordnete stellen sich ihnen in den Weg und erkämpfen eine Abstimmung. Szenen einer turbulenten Nacht.

## Südkorea: Opposition beantragt Amtsenthebungsverfahren gegen Präsidenten
 - [https://www.spiegel.de/ausland/suedkorea-opposition-beantragt-amtsenthebungsverfahren-gegen-praesidenten-a-deacfb2f-afb8-4218-bbeb-a83a6a08592e#ref=rss](https://www.spiegel.de/ausland/suedkorea-opposition-beantragt-amtsenthebungsverfahren-gegen-praesidenten-a-deacfb2f-afb8-4218-bbeb-a83a6a08592e#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:43.020327+00:00

Die Opposition in Südkorea will Staatschef Yoon Suk-yeol absetzen. Damit reagiert sie auf die dramatischen Stunden, in denen der Präsident das Kriegsrecht verhängt hatte.

## OECD: Deutsche Wirtschaft wächst weniger als erwartet
 - [https://www.spiegel.de/wirtschaft/oecd-deutsche-wirtschaft-waechst-weniger-als-erwartet-a-9ae99c4c-132f-478d-a6a1-2c5b712cfed3#ref=rss](https://www.spiegel.de/wirtschaft/oecd-deutsche-wirtschaft-waechst-weniger-als-erwartet-a-9ae99c4c-132f-478d-a6a1-2c5b712cfed3#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:42.786822+00:00

Zum zweiten Mal innerhalb weniger Wochen senkt die OECD ihre Vorhersage: Im kommenden Jahr soll das Wirtschaftswachstum in Deutschland nur 0,7 Prozent betragen. Grund dafür ist auch das Auslandsgeschäft.

## Sachsen: CDU und SPD vereinbaren Koalitionsvertrag für Minderheitsregierung
 - [https://www.spiegel.de/politik/deutschland/sachsen-cdu-und-spd-vereinbaren-koalitionsvertrag-fuer-minderheitsregierung-a-b61dbf5c-0072-4356-9064-1f34041ebe72#ref=rss](https://www.spiegel.de/politik/deutschland/sachsen-cdu-und-spd-vereinbaren-koalitionsvertrag-fuer-minderheitsregierung-a-b61dbf5c-0072-4356-9064-1f34041ebe72#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:42.547732+00:00

Eine Koalition mit dem BSW scheiterte bereits in der Sondierungsphase. Nun haben sich CDU und SPD auf Bedingungen für eine Minderheitsregierung in Sachsen geeinigt.

## Frankfurt am Main: Ex-Fußballtrainer wegen Vergewaltigung zu mehr als zwölf Jahren Haft verurteilt
 - [https://www.spiegel.de/panorama/justiz/frankfurt-am-main-ex-fussballtrainer-wegen-vergewaltigung-zu-mehr-als-zwoelf-jahren-haft-verurteilt-a-dfd44fe3-81cb-4ac1-b24b-a57c0ca8040b#ref=rss](https://www.spiegel.de/panorama/justiz/frankfurt-am-main-ex-fussballtrainer-wegen-vergewaltigung-zu-mehr-als-zwoelf-jahren-haft-verurteilt-a-dfd44fe3-81cb-4ac1-b24b-a57c0ca8040b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:42.312617+00:00

Er betäubte und vergewaltigte zahlreiche Jungen: Ein 37-Jähriger ist in Hessen erneut schuldig gesprochen worden. Das Urteil fiel in dem Revisionsprozess geringfügig kürzer aus.

## VW: Betriebsratschefin bezeichnet Volkswagen als »das Gespött der Nation«
 - [https://www.spiegel.de/wirtschaft/unternehmen/vw-betriebsratschefin-bezeichnet-volkswagen-als-das-gespoett-der-nation-a-7922a0d5-51f6-43cf-be0a-d02c4d569c9f#ref=rss](https://www.spiegel.de/wirtschaft/unternehmen/vw-betriebsratschefin-bezeichnet-volkswagen-als-das-gespoett-der-nation-a-7922a0d5-51f6-43cf-be0a-d02c4d569c9f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:42.074967+00:00

Krisenstimmung bei VW: Während einer Versammlung hat Betriebsratschefin Daniela Cavallo das Management des Autobauers hart attackiert – vor etwa 20.000 Mitarbeitern. Auch Bundesarbeitsminister Hubertus Heil spricht vor der Belegschaft.

## Ifo-Umfrage: 22 Prozent der Arbeitszeit gehen für Bürokratie drauf
 - [https://www.spiegel.de/wirtschaft/ifo-umfrage-22-prozent-der-arbeitszeit-gehen-fuer-buerokratie-drauf-a-ce1c1baa-265b-4d54-b4d3-a79a4128c072#ref=rss](https://www.spiegel.de/wirtschaft/ifo-umfrage-22-prozent-der-arbeitszeit-gehen-fuer-buerokratie-drauf-a-ce1c1baa-265b-4d54-b4d3-a79a4128c072#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:41.756229+00:00

Man muss ja nicht gleich mit der Kettensäge kommen, aber jedes Quäntchen Bürokratieabbau würde der deutschen Wirtschaft helfen. Das legt eine neue Umfrage unter Managern nahe.

## Marie-Agnes Strack-Zimmermann: Offenbar keine Ambitionen auf FDP-Spitzenjob
 - [https://www.spiegel.de/politik/deutschland/marie-agnes-strack-zimmermann-offenbar-keine-ambitionen-auf-fdp-spitzenjob-a-7ac5b175-a3ec-456e-82a0-6a8cf7fdc692#ref=rss](https://www.spiegel.de/politik/deutschland/marie-agnes-strack-zimmermann-offenbar-keine-ambitionen-auf-fdp-spitzenjob-a-7ac5b175-a3ec-456e-82a0-6a8cf7fdc692#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:41.645318+00:00

Wer beseitigt das FDP-Chaos? Zeitweise galt Marie-Agnes Strack-Zimmermann als mögliche Generalsekretärin. Manche sahen sie sogar als Nachfolgerin von Parteichef Lindner. Sie selbst sieht das offenbar anders.

## Kai Trump: So hilft seine Enkelin Donald Trump
 - [https://www.spiegel.de/ausland/kai-trump-so-hilft-seine-enkelin-donald-trump-a-76961939-e53c-41ee-adcf-89a4a7dae1a7#ref=rss](https://www.spiegel.de/ausland/kai-trump-so-hilft-seine-enkelin-donald-trump-a-76961939-e53c-41ee-adcf-89a4a7dae1a7#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:41.532615+00:00

Sie ist 17, sympathisch und hat offenbar eine Mission. Donald Trumps Enkelin ist seit dem Sommer immer aktiver auf Instagram, TikTok und YouTube. Und bringt dort der Gen Z den Trumpismus näher.

## Jan Marsalek: So spionierte die Agentenzelle um den Ex-Wirecard-Manager für Moskau
 - [https://www.spiegel.de/panorama/justiz/jan-marsalek-so-spionierte-die-agentenzelle-um-den-ex-wirecard-manager-fuer-moskau-a-3d461cd0-a538-4a57-bff4-81f8582a0dba#ref=rss](https://www.spiegel.de/panorama/justiz/jan-marsalek-so-spionierte-die-agentenzelle-um-den-ex-wirecard-manager-fuer-moskau-a-3d461cd0-a538-4a57-bff4-81f8582a0dba#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T10:20:33.293834+00:00

Als Hintermann eines Agentenrings ließ der geflohene Ex-Wirecard-Manager Jan Marsalek wohl Journalisten und Soldaten ausforschen – auch in Deutschland. Ein Prozess in London offenbart, wie die Truppe vorging.

## Energiepreise: Gaspreise der Grundversorger entwickeln sich regional unterschiedlich
 - [https://www.spiegel.de/wirtschaft/energiepreise-gaspreise-der-grundversorger-entwickeln-sich-regional-unterschiedlich-a-f20cfb26-f7be-4708-945e-3934ecbccd69#ref=rss](https://www.spiegel.de/wirtschaft/energiepreise-gaspreise-der-grundversorger-entwickeln-sich-regional-unterschiedlich-a-f20cfb26-f7be-4708-945e-3934ecbccd69#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:36.718979+00:00

Die Gaspreise der Grundversorger steigen zum Jahreswechsel mancherorts um bis zu 32 Prozent. Anderswo wird es um 35 Prozent günstiger. Woran das liegt – und wie es bei Ihnen aussieht.

## FC Bayern München: Manuel Neuer sieht Rot gegen Leverkusen - ist er die Münchner Schwachstelle?
 - [https://www.spiegel.de/sport/fussball/fc-bayern-muenchen-manuel-neuer-sieht-rot-gegen-leverkusen-ist-er-die-muenchner-schwachstelle-a-53cc58ce-477d-47eb-bed8-63dc97e90d14#ref=rss](https://www.spiegel.de/sport/fussball/fc-bayern-muenchen-manuel-neuer-sieht-rot-gegen-leverkusen-ist-er-die-muenchner-schwachstelle-a-53cc58ce-477d-47eb-bed8-63dc97e90d14#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:36.607505+00:00

Im Pokalspiel gegen Leverkusen sah Manuel Neuer die erste Rote Karte seiner Karriere. Sein Timing, einst bewundert, ließ ihn im Stich. Die Debatte um seine Zukunft dürfte das anheizen.

## Türkei: Warum der Westen die Unterstützung von Präsident Recep Tayyip Erdoğan in Syrien braucht
 - [https://www.spiegel.de/ausland/tuerkei-warum-der-westen-die-unterstuetzung-von-praesident-recep-tayyip-erdogan-in-syrien-braucht-a-5d801484-034d-447f-a185-b148a7e5f333#ref=rss](https://www.spiegel.de/ausland/tuerkei-warum-der-westen-die-unterstuetzung-von-praesident-recep-tayyip-erdogan-in-syrien-braucht-a-5d801484-034d-447f-a185-b148a7e5f333#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:36.495329+00:00

Europäer und Amerikaner sollten über den türkischen Präsidenten Erdoğan versuchen, auf die Konfliktparteien in Syrien einzuwirken. Sonst drohen erneute Vertreibung und die Rückkehr des Terrors.

## Turner Prize: Schottische Sikh-Künstlerin Jasleen Kaur gewinnt
 - [https://www.spiegel.de/kultur/turner-prize-schottische-sikh-kuenstlerin-jasleen-kaur-gewinnt-a-bbc78276-337e-4076-b9d1-bbdf480f213b#ref=rss](https://www.spiegel.de/kultur/turner-prize-schottische-sikh-kuenstlerin-jasleen-kaur-gewinnt-a-bbc78276-337e-4076-b9d1-bbdf480f213b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:36.384380+00:00

Ein Ford Escort, bedeckt von einer riesigen Häkeldecke: Für diese Installation wurde die Künstlerin Jasleen Kaur jetzt mit dem wichtigsten britischen Kunstpreis geehrt. Sie nutzt ihre Dankesrede zur Israelkritik.

## Verbraucherschützer erzielen juristischen Erfolg gegen 1N Telecom
 - [https://www.spiegel.de/netzwelt/web/verbraucherschuetzer-erzielen-juristischen-erfolg-gegen-1n-telecom-a-f9571f2a-46eb-44ab-a1bb-dcfc1102a02d#ref=rss](https://www.spiegel.de/netzwelt/web/verbraucherschuetzer-erzielen-juristischen-erfolg-gegen-1n-telecom-a-f9571f2a-46eb-44ab-a1bb-dcfc1102a02d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:36.275264+00:00

Der DSL-Anbieter 1N Telecom bietet Verbrauchern per Postwurfsendung neue Internettarife an. Dabei täuscht die Firma eine Vertragsbeziehung zur Deutschen Telekom vor, urteilte nun das Amtsgericht Leipzig.

## Didier Reynders: Ehemaliger EU-Justizkommissar wegen Geldwäsche verhört
 - [https://www.spiegel.de/ausland/didier-reynders-ehemaliger-eu-justizkommissar-wegen-geldwaesche-verhoert-a-b41d9a10-96a3-4ac8-bb0d-7de4dd53b3fe#ref=rss](https://www.spiegel.de/ausland/didier-reynders-ehemaliger-eu-justizkommissar-wegen-geldwaesche-verhoert-a-b41d9a10-96a3-4ac8-bb0d-7de4dd53b3fe#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:36.165884+00:00

Bis vergangene Woche war er noch EU-Justizkommissar, nun wurde Didier Reynders wegen des Vorwurfs der Geldwäsche verhört. Noch genießt er Immunität.

## Adventskalender: Das kleine Mädchen von damals und das kleine Mädchen von heute
 - [https://www.spiegel.de/familie/adventskalender-das-kleine-maedchen-von-damals-und-das-kleine-maedchen-von-heute-a-b1bedf31-97d5-4a90-a754-a6ae9137b30f#ref=rss](https://www.spiegel.de/familie/adventskalender-das-kleine-maedchen-von-damals-und-das-kleine-maedchen-von-heute-a-b1bedf31-97d5-4a90-a754-a6ae9137b30f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:36.054935+00:00

Als Kind wünschte ich mir einen Adventskalender mit kleinen Säckchen. Meine Mutter fand die Idee toll. Aber die Sache hatte einen Haken.

## Strom für künstliche Intelligenz: Meta will eigene Atomreaktoren bauen
 - [https://www.spiegel.de/netzwelt/web/strom-fuer-kuenstliche-intelligenz-meta-will-eigene-atomreaktoren-bauen-a-35d977ba-9158-4824-8f8c-e86903bfaada#ref=rss](https://www.spiegel.de/netzwelt/web/strom-fuer-kuenstliche-intelligenz-meta-will-eigene-atomreaktoren-bauen-a-35d977ba-9158-4824-8f8c-e86903bfaada#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:35.945941+00:00

Nach Amazon, Google und Microsoft hat auch Meta angekündigt, den Energiebedarf seiner KI-Rechenzentren künftig mit Atomstrom decken zu wollen. Jetzt sucht der Konzern die passenden Fachleute.

## Stiftung Warentest: Das sind die besten Kaffeevollautomaten 2024
 - [https://www.spiegel.de/tests/haushalt/stiftung-warentest-das-sind-die-besten-kaffeevollautomaten-2024-a-1e33e9f4-a9ff-48d4-8e13-9e2d387860d6#ref=rss](https://www.spiegel.de/tests/haushalt/stiftung-warentest-das-sind-die-besten-kaffeevollautomaten-2024-a-1e33e9f4-a9ff-48d4-8e13-9e2d387860d6#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:35.835818+00:00

Wer zu Hause einen Cappuccino zubereiten möchte, hat laut Stiftung Warentest die Wahl zwischen einigen guten Geräten. Doch die Preisunterschiede sind erheblich, der Espresso des Testsiegers schmeckt den Sommeliers nicht am besten.

## Timss-Studie: Matheleistungen von Deutschlands Viertklässlern verharren auf mittelmäßigem Niveau
 - [https://www.spiegel.de/panorama/bildung/timss-studie-matheleistungen-von-deutschlands-viertklaesslern-verharren-auf-mittelmaessigem-niveau-a-5019ca54-0d39-4452-a793-a5e64a5cf374#ref=rss](https://www.spiegel.de/panorama/bildung/timss-studie-matheleistungen-von-deutschlands-viertklaesslern-verharren-auf-mittelmaessigem-niveau-a-5019ca54-0d39-4452-a793-a5e64a5cf374#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:35.721959+00:00

Viele Grundschüler haben unter den Schulschließungen während der Coronapandemie gelitten. Eine neue Studie zeigt: Zumindest in Mathe können sie das Niveau früherer Jahrgänge halten. Ist das nun eine gute Nachricht?

## Nordrhein-Westfalen und Baden-Württemberg: Razzia gegen mutmaßliches Schleuser-Netzwerk
 - [https://www.spiegel.de/panorama/justiz/nordrhein-westfalen-und-baden-wuerttemberg-razzia-gegen-mutmassliches-schleuser-netzwerk-a-835835b5-edb1-47e3-be06-1b7a938e13cf#ref=rss](https://www.spiegel.de/panorama/justiz/nordrhein-westfalen-und-baden-wuerttemberg-razzia-gegen-mutmassliches-schleuser-netzwerk-a-835835b5-edb1-47e3-be06-1b7a938e13cf#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T09:14:00+00:00

Die Verdächtigen sollen Menschen »in minderwertigen Schlauchbooten« von Frankreich nach Großbritannien gebracht haben: In mehreren deutschen Städten laufen Durchsuchungen. Es sollen Haftbefehle vollstreckt werden.

## Israel Vázquez: Ehemaliger Boxweltmeister stirbt mit 46 Jahren
 - [https://www.spiegel.de/sport/israel-vazquez-ehemaliger-boxweltmeister-stirbt-mit-46-jahren-a-66b05dae-4c34-4df3-9013-e080823a3aee#ref=rss](https://www.spiegel.de/sport/israel-vazquez-ehemaliger-boxweltmeister-stirbt-mit-46-jahren-a-66b05dae-4c34-4df3-9013-e080823a3aee#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T08:10:52.432055+00:00

Seine Kämpfe gegen Rafael Márquez gehören zu den besten des Boxsports der vergangenen 20 Jahre. Israel Vázquez krönte sich dreimal zum Weltmeister im Bantamgewicht. Nun erlag »El Magnifico« einem Krebsleiden.

## VW: Konzernchef Oliver Blume tritt bei Betriebsversammlung vor Belegschaft
 - [https://www.spiegel.de/wirtschaft/vw-konzernchef-oliver-blume-tritt-bei-betriebsversammlung-vor-belegschaft-a-2f62b35d-8d0d-4fd7-bd2c-14cc64bc140d#ref=rss](https://www.spiegel.de/wirtschaft/vw-konzernchef-oliver-blume-tritt-bei-betriebsversammlung-vor-belegschaft-a-2f62b35d-8d0d-4fd7-bd2c-14cc64bc140d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T08:10:52.172520+00:00

Es dürfte turbulent werden: In Kürze beginnt bei VW in Wolfsburg eine Betriebsversammlung. Neben Konzernchef Blume hat sich auch Arbeitsminister Hubertus Heil angekündigt.

## Tollwut in Kalifornien: Lehrerin stirbt nach Biss einer Fledermaus
 - [https://www.spiegel.de/panorama/tollwut-in-kalifornien-lehrerin-stirbt-nach-biss-einer-fledermaus-a-9f592aa6-d954-44b4-95d5-99cb79fbd4fd#ref=rss](https://www.spiegel.de/panorama/tollwut-in-kalifornien-lehrerin-stirbt-nach-biss-einer-fledermaus-a-9f592aa6-d954-44b4-95d5-99cb79fbd4fd#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T08:10:51.911362+00:00

Leah Seneng war Lehrerin in Kalifornien. Als sich eine Fledermaus ins Klassenzimmer verirrte, wollte sie das Tier ins Freie bringen, doch das biss zu.

## Alex Mashinsky: Celsius-Gründer bekennt sich teils schuldig - droht ihm ähnliches wie Sam Bankman-Fried?
 - [https://www.spiegel.de/wirtschaft/alex-mashinsky-celsius-gruender-bekennt-sich-teils-schuldig-droht-ihm-aehnliches-wie-sam-bankman-fried-a-4739a6cc-fb41-42f2-a0e0-402572483fb1#ref=rss](https://www.spiegel.de/wirtschaft/alex-mashinsky-celsius-gruender-bekennt-sich-teils-schuldig-droht-ihm-aehnliches-wie-sam-bankman-fried-a-4739a6cc-fb41-42f2-a0e0-402572483fb1#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T08:07:00+00:00

25 Jahre Gefängnis bekam Sam Bankman-Fried für seine faulen Kryptogeschäfte. Celsius-Gründer Alex Mashinsky droht Ähnliches: Er hatte 17 Prozent Rendite versprochen und ein staatliches Siegel vorgetäuscht.

## Syrien: Dschihadisten stehen kurz vor Einnahme von Hama
 - [https://www.spiegel.de/ausland/syrien-dschihadisten-stehen-kurz-vor-einnahme-von-hama-a-81d52f5b-7bcc-43e6-b242-f1c69f1ffc80#ref=rss](https://www.spiegel.de/ausland/syrien-dschihadisten-stehen-kurz-vor-einnahme-von-hama-a-81d52f5b-7bcc-43e6-b242-f1c69f1ffc80#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T07:06:12.371475+00:00

Die Großoffensive der Islamisten in Syrien geht weiter – die Angreifer stehen kurz vor Hama, einem für Machthaber Assad wichtigen Stützpunkt. International sorgt der wieder aufgeflammte Krieg für Streit.

## Wohnkosten: Deutsche geben gut ein Viertel des Einkommens fürs Wohnen aus
 - [https://www.spiegel.de/wirtschaft/wohnkosten-deutsche-geben-gut-ein-viertel-des-einkommens-fuers-wohnen-aus-a-b94c294a-d96a-4fa0-a64f-791e0f373404#ref=rss](https://www.spiegel.de/wirtschaft/wohnkosten-deutsche-geben-gut-ein-viertel-des-einkommens-fuers-wohnen-aus-a-b94c294a-d96a-4fa0-a64f-791e0f373404#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T07:06:12.113612+00:00

Ein Dach überm Kopf – und alles, was dazu gehört – kostet in Deutschland rund ein Viertel des Haushaltseinkommens, zeigen aktuelle Zahlen. Tendenz steigend.

## Namibia wählt mit Netumbo Nandi-Ndaitwah erstmals Frau zur Präsidentin
 - [https://www.spiegel.de/ausland/namibia-waehlt-mit-netumbo-nandi-ndaitwah-erstmals-frau-zur-praesidentin-a-5df0c59a-7238-49d1-8589-797876def46e#ref=rss](https://www.spiegel.de/ausland/namibia-waehlt-mit-netumbo-nandi-ndaitwah-erstmals-frau-zur-praesidentin-a-5df0c59a-7238-49d1-8589-797876def46e#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T07:06:11.857177+00:00

Seit 34 Jahren ist Namibia unabhängig. Nun steht mit der 72-jährigen Netumbo Nandi-Ndaitwah erstmals eine Frau an der Spitze des jungen Staates. Die Opposition zürnt.

## Königin Camilla und Herzogin Kate bei Staatsbesuch des Emirs von Katar dabei
 - [https://www.spiegel.de/panorama/leute/koenigin-camilla-und-herzogin-kate-bei-staatsbesuch-des-emirs-von-katar-dabei-a-387215bb-5b6b-4756-a767-173af854bfb4#ref=rss](https://www.spiegel.de/panorama/leute/koenigin-camilla-und-herzogin-kate-bei-staatsbesuch-des-emirs-von-katar-dabei-a-387215bb-5b6b-4756-a767-173af854bfb4#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T07:06:11.603383+00:00

Nirgends fühlen sich Staatsgäste umschmeichelter als in London, wenn die britischen Royals alle Register ziehen. Für den Emir von Katar zeigten sich selbst die kranke Queen und die nur noch selten auftretende Catherine.

## Angela Merkel nennt Wladimir Putins Krim-Lüge Wendepunkt im Miteinander
 - [https://www.spiegel.de/politik/deutschland/angela-merkel-nennt-wladimir-putins-krim-luege-wendepunkt-im-miteinander-a-f94d236c-970e-4747-901f-73508042af36#ref=rss](https://www.spiegel.de/politik/deutschland/angela-merkel-nennt-wladimir-putins-krim-luege-wendepunkt-im-miteinander-a-f94d236c-970e-4747-901f-73508042af36#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T07:06:11.343273+00:00

Ex-Kanzlerin Merkel hatte in ihrer Amtszeit viel mit machthungrigen Männern zu tun – allen voran Kremlchef Putin. In einem CNN-Interview warnt sie nun mit Blick auf die Ukraine vor leichtfertigen Kompromissen mit ihm.

## Georgien: Demonstrierende bleiben trotzen Drohungen von Regierungschef auf der Straße
 - [https://www.spiegel.de/ausland/georgien-demonstrierende-bleiben-trotzen-drohungen-von-regierungschef-auf-der-strasse-a-18122900-18d5-4c19-afab-6d0f0c1be859#ref=rss](https://www.spiegel.de/ausland/georgien-demonstrierende-bleiben-trotzen-drohungen-von-regierungschef-auf-der-strasse-a-18122900-18d5-4c19-afab-6d0f0c1be859#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T07:06:11.077273+00:00

Die sechste Nacht in Folge haben in Georgiens Hauptstadt Tiflis Menschen gegen die russlandfreundliche Regierung von Premier Kobachidse protestiert. Ein Aktivist prangert Folter durch Polizisten an.

## Ukraine-Russland-Krieg: Außenministerin Annalena Baerbock kann sich deutsche Friedenstruppe vorstellen
 - [https://www.spiegel.de/politik/deutschland/ukraine-russland-krieg-aussenministerin-annalena-baerbock-kann-sich-deutsche-friedenstruppe-vorstellen-a-44ff3ba7-a04a-4390-b610-fa9e2bf92bb1#ref=rss](https://www.spiegel.de/politik/deutschland/ukraine-russland-krieg-aussenministerin-annalena-baerbock-kann-sich-deutsche-friedenstruppe-vorstellen-a-44ff3ba7-a04a-4390-b610-fa9e2bf92bb1#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:24.576176+00:00

Wie könnte ein Waffenstillstand zwischen Russland und der Ukraine abgesichert werden? Beim Treffen der Nato hat sich Bundesaußenministerin Baerbock zu einem »Was wäre wenn«-Szenario geäußert.

## Weihnachtsstress im Job: Wie man trotzdem gut durch die Jahresendphase kommt
 - [https://www.spiegel.de/start/weihnachtsstress-im-job-wie-man-trotzdem-gut-durch-die-jahresendphase-kommt-a-c12d2c16-d832-48fb-8d09-7cedb1720783#ref=rss](https://www.spiegel.de/start/weihnachtsstress-im-job-wie-man-trotzdem-gut-durch-die-jahresendphase-kommt-a-c12d2c16-d832-48fb-8d09-7cedb1720783#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:24.324444+00:00

Bei der Arbeit schleppen Sie sich nur durch – dabei gäbe es noch so viel zu tun? Willkommen im Klub! Dabei könnten wir das Jahresende mit weniger Druck und mehr Vorfreude entspannter gestalten.

## Extra GESUNDHEIT & FITNESS: Jede Narbe erzählt eine Geschichte
 - [https://www.spiegel.de/gesundheit/extra-gesundheit-fitness-jede-narbe-erzaehlt-eine-geschichte-a-1f3b303e-57aa-440b-9dd6-8869eb7a0002#ref=rss](https://www.spiegel.de/gesundheit/extra-gesundheit-fitness-jede-narbe-erzaehlt-eine-geschichte-a-1f3b303e-57aa-440b-9dd6-8869eb7a0002#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:00+00:00

Seit einem Unfall im Kleinkindalter habe ich eine Wulst an der Lippe. Vielen Menschen fällt sie gar nicht auf – nicht mal denjenigen, die mich küssen. Aber ich weiß, dass sie da ist und woher sie kommt.

## Krumm sitzen im Büro? Physiotherapeutin: »Eine gesunde Wirbelsäule hält das aus«
 - [https://www.spiegel.de/gesundheit/krumm-sitzen-im-buero-physiotherapeutin-eine-gesunde-wirbelsaeule-haelt-das-aus-a-86211dfa-2d37-487a-a7a1-0076ad7969db#ref=rss](https://www.spiegel.de/gesundheit/krumm-sitzen-im-buero-physiotherapeutin-eine-gesunde-wirbelsaeule-haelt-das-aus-a-86211dfa-2d37-487a-a7a1-0076ad7969db#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:00+00:00

Hannah Hecker behandelt Menschen, die Verspannungen und Schmerzen haben. Sie hatte selbst oft starke Probleme mit dem Nacken. Hier verrät sie, was ihr geholfen hat und welches Fitnessgerät sie mit auf Reisen nimmt.

## Psychotherapie und Schönheitschirurgie: »Es hilft, viel über die Narbe zu sprechen«
 - [https://www.spiegel.de/gesundheit/psychotherapie-und-schoenheitschirurgie-es-hilft-viel-ueber-die-narbe-zu-sprechen-a-a968a119-6386-4910-bb03-239f2bfc6291#ref=rss](https://www.spiegel.de/gesundheit/psychotherapie-und-schoenheitschirurgie-es-hilft-viel-ueber-die-narbe-zu-sprechen-a-a968a119-6386-4910-bb03-239f2bfc6291#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:00+00:00

Kaiserschnitt, Hautinfektion, Unfall: Eine Narbe bleibt. Ein Psychotherapeut und ein plastischer Chirurg erklären, wie man das akzeptieren kann und was sie tun, wenn Hautveränderungen zur Belastung werden.

## Superfood-Check: Wie gesund ist Senf?
 - [https://www.spiegel.de/gesundheit/superfood-check-wie-gesund-ist-senf-a-f88dcedb-ab95-4d0f-ac8b-88e7767e2a23#ref=rss](https://www.spiegel.de/gesundheit/superfood-check-wie-gesund-ist-senf-a-f88dcedb-ab95-4d0f-ac8b-88e7767e2a23#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:00+00:00

Schon früh in der Menschheitsgeschichte war klar: Das ist ein kleiner Klacks, der es in sich hat. Senf überrascht mit vielen gesundheitsfördernden Eigenschaften.

## Einsatz in Marguerite, Pennsylvania: Polizei vermutet vermisste Großmutter in Erdloch
 - [https://www.spiegel.de/panorama/einsatz-in-marguerite-pennsylvania-polizei-vermutet-vermisste-grossmutter-in-erdloch-a-ed678f7e-0b10-4b22-bfea-9dc502fc6e60#ref=rss](https://www.spiegel.de/panorama/einsatz-in-marguerite-pennsylvania-polizei-vermutet-vermisste-grossmutter-in-erdloch-a-ed678f7e-0b10-4b22-bfea-9dc502fc6e60#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T04:55:27.297093+00:00

Im US-Staat Pennsylvania hat sich eine Frau auf die Suche nach ihrer vermissten Katze gemacht – und gilt seitdem selbst als verschwunden. Nun hat die Polizei eine neue Spur: ein Loch, das sich plötzlich im Boden auftat.

## Kita-Krise: Immer mehr Personal ohne pädagogische Ausbildung, ein Viertel der Erzieher will hinschmeißen
 - [https://www.spiegel.de/panorama/bildung/kita-krise-immer-mehr-personal-ohne-paedagogische-ausbildung-ein-viertel-der-erzieher-will-hinschmeissen-a-486e47a4-72af-4a58-9821-83b81c1b454a#ref=rss](https://www.spiegel.de/panorama/bildung/kita-krise-immer-mehr-personal-ohne-paedagogische-ausbildung-ein-viertel-der-erzieher-will-hinschmeissen-a-486e47a4-72af-4a58-9821-83b81c1b454a#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T04:55:27.174764+00:00

Mehr Arbeitsbelastung, weniger voll ausgebildete Fachkräfte – zwei Studien zeichnen ein düsteres Bild der Kinderbetreuung in Deutschland. Eine Expertenempfehlung erfüllen nur die ostdeutschen Länder.

## News: Olaf Scholz, Friedrich Merz, Emmanuel Macron, Notre-Dame
 - [https://www.spiegel.de/politik/deutschland/news-olaf-scholz-friedrich-merz-emmanuel-macron-notre-dame-a-88507774-db3e-4ea1-aaa1-2b7d64f8e02c#ref=rss](https://www.spiegel.de/politik/deutschland/news-olaf-scholz-friedrich-merz-emmanuel-macron-notre-dame-a-88507774-db3e-4ea1-aaa1-2b7d64f8e02c#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T04:55:27.035765+00:00

Olaf Scholz wird im Bundestag befragt, Friedrich Merz in Niederschönhausen. Und der Wolf hat ein Problem. Das ist die Lage am Mittwochmorgen.

## Eminem: Seine Mutter Debbie Nelson ist tot
 - [https://www.spiegel.de/kultur/eminem-seine-mutter-debbie-nelson-ist-tot-a-8b6b99b8-2a83-4ff7-9e33-e74b17121840#ref=rss](https://www.spiegel.de/kultur/eminem-seine-mutter-debbie-nelson-ist-tot-a-8b6b99b8-2a83-4ff7-9e33-e74b17121840#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T03:50:40.744151+00:00

In mehreren Songs teilt Rapper Eminem heftig gegen seine Mutter aus. Sie wehrte sich juristisch und mit einer Autobiografie. Erst später gab es Anzeichen von Versöhnung. Nun ist Debbie Nelson im Alter von 69 Jahren gestorben.

## Trumps Wunschverteidigungsminister strauchelt – Spekulation über Ersatz
 - [https://www.spiegel.de/ausland/trumps-wunschverteidigungsminister-strauchelt-spekulation-ueber-ersatz-a-fa9b2382-c3e1-4f49-8786-ae7333284aee#ref=rss](https://www.spiegel.de/ausland/trumps-wunschverteidigungsminister-strauchelt-spekulation-ueber-ersatz-a-fa9b2382-c3e1-4f49-8786-ae7333284aee#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T03:50:40.630629+00:00

Pete Hegseth soll bald das Pentagon leiten. Doch die Zweifel an der Eignung des TV-Moderators werden lauter. Nun könnte Donald Trump eine Alternative gefunden haben – einen alten Bekannten.

## Foodwatch fordert Verkaufsstopp für Lachs aus Norwegen
 - [https://www.spiegel.de/wirtschaft/foodwatch-fordert-verkaufsstopp-fuer-lachs-aus-norwegen-a-7a9b7fd6-1476-4c70-b25d-cb9cd2b49732#ref=rss](https://www.spiegel.de/wirtschaft/foodwatch-fordert-verkaufsstopp-fuer-lachs-aus-norwegen-a-7a9b7fd6-1476-4c70-b25d-cb9cd2b49732#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T02:47:04.698166+00:00

Die Deutschen lieben Lachs aus Norwegen. Aber die industrielle Zucht der Fische ist oft ein grausiges Geschäft. Verbraucherschützer wenden sich mit einem Boykottaufruf an die Supermarktketten.

## Missouri richtet verurteilten Mörder per Giftinjektion hin
 - [https://www.spiegel.de/panorama/justiz/missouri-richtet-verurteilten-moerder-per-giftinjektion-hin-a-651c0619-da21-4c9b-91f2-158a22aae102#ref=rss](https://www.spiegel.de/panorama/justiz/missouri-richtet-verurteilten-moerder-per-giftinjektion-hin-a-651c0619-da21-4c9b-91f2-158a22aae102#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T02:47:04.386115+00:00

Der Mann hatte eine Viertklässlerin missbraucht und erwürgt: Dafür ist ein 49-Jähriger im US-Staat Missouri hingerichtet worden. In seinen letzten Worten akzeptierte er seine Strafe.

## Südkorea: Gewerkschaftsverband ruft zu Generalstreik auf
 - [https://www.spiegel.de/ausland/suedkorea-gewerkschaftsverband-ruft-zu-generalstreik-auf-a-1b36f274-ce85-44d7-9037-ed4644b4457d#ref=rss](https://www.spiegel.de/ausland/suedkorea-gewerkschaftsverband-ruft-zu-generalstreik-auf-a-1b36f274-ce85-44d7-9037-ed4644b4457d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T01:41:54.954948+00:00

Weil die Opposition seine Pläne blockierte, verhängte Südkoreas Präsident für kurze Zeit das Kriegsrecht. Das war »antidemokratisch«, protestieren Gewerkschafter. Nun treten sie in den Ausstand. Und haben ein klares Ziel.

## Brasilien: Polizist wirft Mann von Brücke in São Paulo – Videos zeigen brutalen Machtmissbrauch
 - [https://www.spiegel.de/panorama/brasilien-polizist-wirft-mann-von-bruecke-in-sao-paulo-videos-zeigen-brutalen-machtmissbrauch-a-90c3df23-d5ae-4046-96a2-e9241a818616#ref=rss](https://www.spiegel.de/panorama/brasilien-polizist-wirft-mann-von-bruecke-in-sao-paulo-videos-zeigen-brutalen-machtmissbrauch-a-90c3df23-d5ae-4046-96a2-e9241a818616#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T01:41:54.671396+00:00

Ein brasilianischer Polizist wirft einen Mann über eine Brücke. Ein anderer Beamter schießt einem Flüchtenden mehrfach in den Rücken. Videoaufnahmen dieser Vorfälle sorgen in São Paulo für Aufruhr.

## Junge Alternative der AfD: Thüringer Verfassungsschutz kritisiert Umordnung als Ablenkungsmanöver
 - [https://www.spiegel.de/politik/junge-alternative-der-afd-thueringer-verfassungsschutz-kritisiert-umordnung-als-ablenkungsmanoever-a-34f0631d-4b91-4708-bf86-604e371e26be#ref=rss](https://www.spiegel.de/politik/junge-alternative-der-afd-thueringer-verfassungsschutz-kritisiert-umordnung-als-ablenkungsmanoever-a-34f0631d-4b91-4708-bf86-604e371e26be#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T00:35:20.263241+00:00

Die AfD will ihre Jugendorganisation neu strukturieren und begründet das mit dem Wunsch nach besseren »Durchgriffsmöglichkeiten«. Der Präsident des Thüringer Verfassungsschutzes sieht andere Gründe.

## Donald Trump beantragt Ende seines Schweigegeld-Prozesses – und argumentiert mit Worten von Joe Biden
 - [https://www.spiegel.de/ausland/donald-trump-beantragt-ende-seines-schweigegeld-prozesses-und-argumentiert-mit-worten-von-joe-biden-a-beb309ce-60d8-4d2c-9687-85e5c638a96f#ref=rss](https://www.spiegel.de/ausland/donald-trump-beantragt-ende-seines-schweigegeld-prozesses-und-argumentiert-mit-worten-von-joe-biden-a-beb309ce-60d8-4d2c-9687-85e5c638a96f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-04T00:30:00+00:00

Im Prozess um eine Schweigegeldzahlung an eine Ex-Pornodarstellerin wurde Donald Trump schuldig gesprochen. Nun will er erreichen, dass das Verfahren eingestellt wird. Und bedient sich beim Vokabular der Konkurrenz.

