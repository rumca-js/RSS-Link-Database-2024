# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## ​Siemoniak o prześwietleniu Nawrockiego: Ta sprawa wymaga wyjaśnienia
 - [https://www.rmf24.pl/polityka/news-siemoniak-o-przeswietleniu-nawrockiego-ta-sprawa-wymaga-wyja,nId,7869484](https://www.rmf24.pl/polityka/news-siemoniak-o-przeswietleniu-nawrockiego-ta-sprawa-wymaga-wyja,nId,7869484)
 - RSS feed: $source
 - date published: 2024-12-04T23:08:54.885928+00:00

<p><a href="https://www.rmf24.pl/polityka/news-siemoniak-o-przeswietleniu-nawrockiego-ta-sprawa-wymaga-wyja,nId,7869484"><img src="https://interia-s.pluscdn.pl/siemoniak-o-przeswietleniu-nawrockiego-ta-sprawa-wymaga-wyja/000K8EC73RKLAOIK-C307.jpg" alt="​Siemoniak o prześwietleniu Nawrockiego: Ta sprawa wymaga wyjaśnienia" align="left" /></a>&quot;Agencja Bezpieczeństwa Wewnętrznego powinna zweryfikować, czy działania sprawdzające wobec Karola Nawrockiego, obecnego szefa IPN i kandydata PiS na prezydenta, były właściwe&quot; - powiedział minister koordynator służb specjalnych, szef MSWiA Tomasz Siemoniak. &quot;Ta sprawa wymaga wyjaśnienia, ale uważam, że tutaj było jak w pozostałych przypadkach - ponieważ był swój, patrzono przez palce&quot; - ocenił minister.</p><br clear="all" />

## ​Piłkarz Fiorentiny opuścił oddział intensywnej terapii, jego stan się poprawia
 - [https://www.rmf24.pl/sport/pilka-nozna/news-pilkarz-fiorentiny-opuscil-oddzial-intensywnej-terapii-jego-,nId,7869466](https://www.rmf24.pl/sport/pilka-nozna/news-pilkarz-fiorentiny-opuscil-oddzial-intensywnej-terapii-jego-,nId,7869466)
 - RSS feed: $source
 - date published: 2024-12-04T22:03:56.257329+00:00

<p><a href="https://www.rmf24.pl/sport/pilka-nozna/news-pilkarz-fiorentiny-opuscil-oddzial-intensywnej-terapii-jego-,nId,7869466"><img src="https://interia-s.pluscdn.pl/pilkarz-fiorentiny-opuscil-oddzial-intensywnej-terapii-jego/000K8E7A9S7ORSQC-C307.jpg" alt="​Piłkarz Fiorentiny opuścił oddział intensywnej terapii, jego stan się poprawia" align="left" /></a>Piłkarz Fiorentiny Edoardo Bove, który zasłabł podczas niedzielnego meczu Serie A z Interem Mediolan, opuścił w środę oddział intensywnej terapii szpitala Careggi, a jego stan cały czas się poprawia. 
</p><br clear="all" />

## ​Senat jednomyślny. Ustawa o mrożeniu cen prądu trafi teraz do prezydenta
 - [https://www.rmf24.pl/ekonomia/news-senat-jednomyslny-ustawa-o-mrozeniu-cen-pradu-trafi-teraz-do,nId,7869445](https://www.rmf24.pl/ekonomia/news-senat-jednomyslny-ustawa-o-mrozeniu-cen-pradu-trafi-teraz-do,nId,7869445)
 - RSS feed: $source
 - date published: 2024-12-04T20:58:52.928920+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-senat-jednomyslny-ustawa-o-mrozeniu-cen-pradu-trafi-teraz-do,nId,7869445"><img src="https://interia-s.pluscdn.pl/senat-jednomyslny-ustawa-o-mrozeniu-cen-pradu-trafi-teraz-do/000K8DVK7J3V51PL-C307.jpg" alt="​Senat jednomyślny. Ustawa o mrożeniu cen prądu trafi teraz do prezydenta" align="left" /></a>Senat nie zgłosił w środę poprawek do ustawy o zamrożeniu na poziomie 500 zł za MWh netto cen energii elektrycznej dla gospodarstw domowych do końca września 2025 r. Za podjęciem uchwały w tej sprawie głosowało 92 senatorów, nikt nie był przeciw, nikt nie wstrzymał się od głosu. W sumie cała interwencja rządu ma kosztować nieco ponad 5,6 mld zł. Ustawa trafi teraz do prezydenta Andrzeja Dudy, podobnie jak ustawa okołobudżetowa, również przyjęta przez Senat bez poprawek.</p><br clear="all" />

## Wojna w Ukrainie: USA ogłasza sankcje na Rosjan odpowiedzialnych za deportacje dzieci
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-wojna-w-ukrainie-usa-oglasza-sankcje-na-rosjan-odpowiedzialn,nId,7869423](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-wojna-w-ukrainie-usa-oglasza-sankcje-na-rosjan-odpowiedzialn,nId,7869423)
 - RSS feed: $source
 - date published: 2024-12-04T20:51:19+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-wojna-w-ukrainie-usa-oglasza-sankcje-na-rosjan-odpowiedzialn,nId,7869423"><img src="https://interia-s.pluscdn.pl/wojna-w-ukrainie-usa-oglasza-sankcje-na-rosjan-odpowiedzialn/000K8DSWW4SNVIUU-C307.jpg" alt="Wojna w Ukrainie: USA ogłasza sankcje na Rosjan odpowiedzialnych za deportacje dzieci" align="left" /></a>Stany Zjednoczone ogłosiły sankcje wobec rosyjskich urzędników zaangażowanych w uprowadzenia dzieci z tymczasowo okupowanych terytoriów ukraińskich do Rosji. Sankcjami objęto również międzynarodową grupę TGR, którą Moskwa wykorzystuje do omijania restrykcji.</p><br clear="all" />

## Świąteczne iluminacje w stylu retro rozświetliły Warszawę
 - [https://www.rmf24.pl/regiony/warszawa/news-swiateczne-iluminacje-w-stylu-retro-rozswietlily-warszawe,nId,7869409](https://www.rmf24.pl/regiony/warszawa/news-swiateczne-iluminacje-w-stylu-retro-rozswietlily-warszawe,nId,7869409)
 - RSS feed: $source
 - date published: 2024-12-04T19:54:51.150619+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-swiateczne-iluminacje-w-stylu-retro-rozswietlily-warszawe,nId,7869409"><img src="https://interia-s.pluscdn.pl/swiateczne-iluminacje-w-stylu-retro-rozswietlily-warszawe/000K8DJT3CHDDT0J-C307.jpg" alt="Świąteczne iluminacje w stylu retro rozświetliły Warszawę" align="left" /></a>W środowy wieczór w Warszawie uruchomiono świąteczne iluminacje. Ozdoby wykonane są z energooszczędnych diod eko-LED, które zużywają 10 razy mniej prądu niż tradycyjne oświetlenie. </p><br clear="all" />

## Watykan zaprezentował nowy papamobile. Tak wygląda auto Franciszka
 - [https://www.rmf24.pl/fakty/swiat/news-watykan-zaprezentowal-nowy-papamobile-tak-wyglada-auto-franc,nId,7869431](https://www.rmf24.pl/fakty/swiat/news-watykan-zaprezentowal-nowy-papamobile-tak-wyglada-auto-franc,nId,7869431)
 - RSS feed: $source
 - date published: 2024-12-04T19:54:50.852699+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-watykan-zaprezentowal-nowy-papamobile-tak-wyglada-auto-franc,nId,7869431"><img src="https://interia-s.pluscdn.pl/watykan-zaprezentowal-nowy-papamobile-tak-wyglada-auto-franc/000K8DQY3O4H6EG3-C307.jpg" alt="Watykan zaprezentował nowy papamobile. Tak wygląda auto Franciszka" align="left" /></a>Papież Franciszek otrzymał kluczyki do nowego papamobile. Pojazd jest elektryczny, ma podgrzewany fotel oraz barierkę, której trzyma się papież, pozdrawiając wiernych. Kluczyki w białej walizeczce przekazano papieżowi na dziedzińcu w Watykanie.</p><br clear="all" />

## Polityczne trzęsienie ziemi we Francji. Upadł rząd Michela Barniera
 - [https://www.rmf24.pl/fakty/swiat/news-polityczne-trzesienie-ziemi-we-francji-upadl-rzad-michela-ba,nId,7869432](https://www.rmf24.pl/fakty/swiat/news-polityczne-trzesienie-ziemi-we-francji-upadl-rzad-michela-ba,nId,7869432)
 - RSS feed: $source
 - date published: 2024-12-04T19:54:50.322871+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-polityczne-trzesienie-ziemi-we-francji-upadl-rzad-michela-ba,nId,7869432"><img src="https://interia-s.pluscdn.pl/polityczne-trzesienie-ziemi-we-francji-upadl-rzad-michela-ba/000K8DRLB17VUOT5-C307.jpg" alt="Polityczne trzęsienie ziemi we Francji. Upadł rząd Michela Barniera" align="left" /></a>Parlament Francji uchwalił w środę wniosek o wotum nieufności wobec rządu Michela Barniera zmuszając go do ustąpienia. Rząd premiera Barniera jest pierwszym od 1962 roku gabinetem ustępującym w wyniku wotum nieufności.</p><br clear="all" />

## Rosyjska ropa przestała płynąć do Czech
 - [https://www.rmf24.pl/fakty/swiat/news-rosyjska-ropa-przestala-plynac-do-czech,nId,7869391](https://www.rmf24.pl/fakty/swiat/news-rosyjska-ropa-przestala-plynac-do-czech,nId,7869391)
 - RSS feed: $source
 - date published: 2024-12-04T18:48:42.499252+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-rosyjska-ropa-przestala-plynac-do-czech,nId,7869391"><img src="https://interia-s.pluscdn.pl/rosyjska-ropa-przestala-plynac-do-czech/000K8DE599JY73U4-C307.jpg" alt="Rosyjska ropa przestała płynąć do Czech" align="left" /></a>Do Czech przestała płynąć przez rurociąg „Przyjaźń” rosyjska ropa naftowa, która stanowi 58 proc. krajowego zapotrzebowania - podały czeskie media. Doniesienia te potwierdził Orlen Unipetrol, który jest jedyną firmą w Czechach przerabiającą ropę oraz czeski resort przemysłu i handlu. Rząd Czech zdecydował o pożyczeniu Orlenowi ropy z rezerwy strategicznej.</p><br clear="all" />

## Rosjanie strzelali na Bałtyku do niemieckiego śmigłowca? Zamęt po słowach Baerbock
 - [https://www.rmf24.pl/fakty/swiat/news-rosjanie-strzelali-na-baltyku-do-niemieckiego-smiglowca-zame,nId,7869376](https://www.rmf24.pl/fakty/swiat/news-rosjanie-strzelali-na-baltyku-do-niemieckiego-smiglowca-zame,nId,7869376)
 - RSS feed: $source
 - date published: 2024-12-04T18:48:42.030013+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-rosjanie-strzelali-na-baltyku-do-niemieckiego-smiglowca-zame,nId,7869376"><img src="https://interia-s.pluscdn.pl/rosjanie-strzelali-na-baltyku-do-niemieckiego-smiglowca-zame/000K8DGHWSB6X9E9-C307.jpg" alt="Rosjanie strzelali na Bałtyku do niemieckiego śmigłowca? Zamęt po słowach Baerbock" align="left" /></a>Rosyjski okręt na Morzu Bałtyckim miał ostrzelać amunicją sygnałową niemiecki helikopter wykonujący misję rozpoznawczą. Według niemieckich mediów zdawkową informację w tej sprawie przekazać miała w Brukseli Annalena Baerbock, szefowa dyplomacji RFN. Baerbock miała też powiedzieć kilka słów, które wywołały spore zamieszanie medialne. Teraz wypowiedź dyplomatki próbuje prostować kanclerz Niemiec Olaf Scholz.</p><br clear="all" />

## Bodnar o immunitecie Kaczyńskiego: Polityk nie powinien być ponad prawem
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-bodnar-o-immunitecie-kaczynskiego-polityk-nie-powinien-byc-p,nId,7869050](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-bodnar-o-immunitecie-kaczynskiego-polityk-nie-powinien-byc-p,nId,7869050)
 - RSS feed: $source
 - date published: 2024-12-04T18:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-bodnar-o-immunitecie-kaczynskiego-polityk-nie-powinien-byc-p,nId,7869050"><img src="https://interia-s.pluscdn.pl/bodnar-o-immunitecie-kaczynskiego-polityk-nie-powinien-byc-p/000K8DI0DCN88FI8-C307.jpg" alt="Bodnar o immunitecie Kaczyńskiego: Polityk nie powinien być ponad prawem" align="left" /></a>&quot;Status polityka i osoby chronionej immunitetem nie powinien prowadzić do tego, że jest się ponad prawem&quot; – w ten sposób minister sprawiedliwości Adam Bodnar w Popołudniowej rozmowie w RMF FM skomentował sprawę odebrania immunitetu liderowi PiS Jarosławowi Kaczyńskiemu.</p><br clear="all" />

## Zbrodnia na Manhattanie. Nie żyje szef największej w USA firmy ubezpieczeniowej
 - [https://www.rmf24.pl/fakty/swiat/news-zbrodnia-na-manhattanie-nie-zyje-szef-najwiekszej-w-usa-firm,nId,7869223](https://www.rmf24.pl/fakty/swiat/news-zbrodnia-na-manhattanie-nie-zyje-szef-najwiekszej-w-usa-firm,nId,7869223)
 - RSS feed: $source
 - date published: 2024-12-04T17:44:10.383008+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-zbrodnia-na-manhattanie-nie-zyje-szef-najwiekszej-w-usa-firm,nId,7869223"><img src="https://interia-s.pluscdn.pl/zbrodnia-na-manhattanie-nie-zyje-szef-najwiekszej-w-usa-firm/000K8CS54DG9ULC1-C307.jpg" alt="Zbrodnia na Manhattanie. Nie żyje szef największej w USA firmy ubezpieczeniowej" align="left" /></a>Brian Thompson, dyrektor UnitedHealthcare, największej w USA prywatnej firmy sprzedającej ubezpieczenia zdrowotne, został zastrzelony w Nowym Jorku. Sprawca uciekł z miejsca zdarzenia. </p><br clear="all" />

## Kłopoty prezydenta Korei Płd. Jest wniosek o impeachment
 - [https://www.rmf24.pl/fakty/swiat/news-klopoty-prezydenta-korei-pld-jest-wniosek-o-impeachment,nId,7869212](https://www.rmf24.pl/fakty/swiat/news-klopoty-prezydenta-korei-pld-jest-wniosek-o-impeachment,nId,7869212)
 - RSS feed: $source
 - date published: 2024-12-04T17:37:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-klopoty-prezydenta-korei-pld-jest-wniosek-o-impeachment,nId,7869212"><img src="https://interia-s.pluscdn.pl/klopoty-prezydenta-korei-pld-jest-wniosek-o-impeachment/000K8CRCT9VMHI7G-C307.jpg" alt="Kłopoty prezydenta Korei Płd. Jest wniosek o impeachment" align="left" /></a>W parlamencie Korei Płd. został formalnie zgłoszony wniosek o impeachment prezydenta Jun Suk Jeola w związku z wprowadzeniem przez niego we wtorek stanu wojennego. Partia Władzy Ludowej, z której wywodzi się Jun, zapowiedziała, że nie poprze wniosku.</p><br clear="all" />

## ​Mikołajki w Mikołajkach z RMF FM
 - [https://www.rmf24.pl/raporty/raport-boze-narodzenie-2024/news-mikolajki-w-mikolajkach-z-rmf-fm,nId,7869022](https://www.rmf24.pl/raporty/raport-boze-narodzenie-2024/news-mikolajki-w-mikolajkach-z-rmf-fm,nId,7869022)
 - RSS feed: $source
 - date published: 2024-12-04T16:38:41.612726+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-boze-narodzenie-2024/news-mikolajki-w-mikolajkach-z-rmf-fm,nId,7869022"><img src="https://interia-s.pluscdn.pl/mikolajki-w-mikolajkach-z-rmf-fm/000K8CH6JC3DKUJ5-C307.jpg" alt="​Mikołajki w Mikołajkach z RMF FM" align="left" /></a>To będzie wyjątkowy mikołajkowy weekend w RMF FM. Zaczynamy w piątek pod Tatrami - w Zakopanem, a kończymy na Mazurach - w mikołajowej wiosce w Mikołajkach. Wypatrujcie naszego konwoju nie tylko na ziemi. Będą prezenty, spotkania z dziećmi i mnóstwo radości. W sobotę zapraszamy Was na wyjątkowy zlot Mikołajów w Mikołajkach. Zapewniamy: będzie się działo! Bo Mikołaj przygotował dla Was mnóstwo atrakcji.</p><br clear="all" />

## Kolejna noc protestu w Tbilisi. Relacja wysłannika RMF FM z Tbilisi
 - [https://www.rmf24.pl/fakty/swiat/news-kolejna-noc-protestu-w-tbilisi-relacja-wyslannika-rmf-fm-z-t,nId,7869167](https://www.rmf24.pl/fakty/swiat/news-kolejna-noc-protestu-w-tbilisi-relacja-wyslannika-rmf-fm-z-t,nId,7869167)
 - RSS feed: $source
 - date published: 2024-12-04T16:35:59+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-kolejna-noc-protestu-w-tbilisi-relacja-wyslannika-rmf-fm-z-t,nId,7869167"><img src="https://interia-s.pluscdn.pl/kolejna-noc-protestu-w-tbilisi-relacja-wyslannika-rmf-fm-z-t/000K8DMP17X5SO14-C307.jpg" alt="Kolejna noc protestu w Tbilisi. Relacja wysłannika RMF FM z Tbilisi" align="left" /></a>Nika Gwaramia, lider Koalicji na Rzecz Zmiany, jednej z czterech największych partii opozycyjnych Gruzji, został pobity do nieprzytomności w Tbilisi, a następnie zatrzymany przez policję. &quot;Podobnie jak wczoraj i w poprzednich dniach aleja Rustawelego przed parlamentem po horyzont wypełniła się protestującymi. To głównie młodzi ludzie z flagami Gruzji i Unii Europejskiej, ale wspierają ich także mieszkańcy stolicy pamiętający czasy Związku Radzieckiego&quot; - relacjonuje specjalny wysłannik RMF FM Mateusz Chłystun.</p><br clear="all" />

## "Nie prowokować policji". Kolejna noc protestu w Tbilisi - relacja wysłannika RMF FM
 - [https://www.rmf24.pl/fakty/swiat/news-nie-prowokowac-policji-kolejna-noc-protestu-w-tbilisi-relacj,nId,7869167](https://www.rmf24.pl/fakty/swiat/news-nie-prowokowac-policji-kolejna-noc-protestu-w-tbilisi-relacj,nId,7869167)
 - RSS feed: $source
 - date published: 2024-12-04T16:35:59+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nie-prowokowac-policji-kolejna-noc-protestu-w-tbilisi-relacj,nId,7869167"><img src="https://interia-s.pluscdn.pl/nie-prowokowac-policji-kolejna-noc-protestu-w-tbilisi-relacj/000K8DMP17X5SO14-C307.jpg" alt="&quot;Nie prowokować policji&quot;. Kolejna noc protestu w Tbilisi - relacja wysłannika RMF FM " align="left" /></a>&quot;Spokojniej niż w czasie poprzednich nocy przebiega antyrządowy protest w stolicy Gruzji - Tbilisi. Niektórzy mówią wprost, że dziś przyjęli taktykę, by nie prowokować policji do działania i sprawdzić, jaka będzie reakcja funkcjonariuszy. Oczywiście, przed parlamentem słychać co jakiś czas okrzyki i gwizdy, ale nie ma dzisiaj zbyt wielu huku petardy ani głośnych komunikatów wzywających do rozejścia się&quot; - relacjonuje ze stolicy Gruzji Mateusz Chłystun, specjalny wysłannik RMF FM. W środę zatrzymany został przez służby Nika Gwaramia, lider...</p><br clear="all" />

## ​Służby zatrzymały lidera gruzińskiej opozycji. Relacja wysłannika RMF FM z Tbilisi
 - [https://www.rmf24.pl/fakty/swiat/news-sluzby-zatrzymaly-lidera-gruzinskiej-opozycji-relacja-wyslan,nId,7869167](https://www.rmf24.pl/fakty/swiat/news-sluzby-zatrzymaly-lidera-gruzinskiej-opozycji-relacja-wyslan,nId,7869167)
 - RSS feed: $source
 - date published: 2024-12-04T16:35:59+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-sluzby-zatrzymaly-lidera-gruzinskiej-opozycji-relacja-wyslan,nId,7869167"><img src="https://interia-s.pluscdn.pl/sluzby-zatrzymaly-lidera-gruzinskiej-opozycji-relacja-wyslan/000K8CJPW8D82KOR-C307.jpg" alt="​Służby zatrzymały lidera gruzińskiej opozycji. Relacja wysłannika RMF FM z Tbilisi" align="left" /></a>Nika Gwaramia, lider Koalicji na Rzecz Zmiany, jednej z czterech największych partii opozycyjnych Gruzji, został pobity do nieprzytomności w Tbilisi, a następnie zatrzymany przez policję. &quot;Przeciwnicy gruzińskiego rządu ponownie gromadzą się przed parlamentem. To głównie młodzi ludzie z flagami Gruzji i Unii Europejskiej, ale wspierają ich także mieszkańcy stolicy pamiętający czasy Związku Radzieckiego&quot; - relacjonuje specjalny wysłannik RMF FM Mateusz Chłystun.</p><br clear="all" />

## Roman Polański kontra Charlotte Lewis. Jest decyzja sądu
 - [https://www.rmf24.pl/fakty/swiat/news-roman-polanski-kontra-charlotte-lewis-jest-decyzja-sadu,nId,7869138](https://www.rmf24.pl/fakty/swiat/news-roman-polanski-kontra-charlotte-lewis-jest-decyzja-sadu,nId,7869138)
 - RSS feed: $source
 - date published: 2024-12-04T16:23:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-roman-polanski-kontra-charlotte-lewis-jest-decyzja-sadu,nId,7869138"><img src="https://interia-s.pluscdn.pl/roman-polanski-kontra-charlotte-lewis-jest-decyzja-sadu/000K8BCRX8D6OXOK-C307.jpg" alt="Roman Polański kontra Charlotte Lewis. Jest decyzja sądu" align="left" /></a>Sąd w Paryżu oddalił apelację brytyjskiej aktorki Charlotte Lewis, która oskarżyła Romana Polańskiego o zniesławienie. Reżyser podważył jej oskarżenia o gwałt. </p><br clear="all" />

## Czerwony Kapturek, wilkołak i wilki. Dlaczego Europa zmierza tam, gdzie nie powinna?
 - [https://www.rmf24.pl/fakty/swiat/news-czerwony-kapturek-wilkolak-i-wilki-dlaczego-europa-zmierza-t,nId,7869094](https://www.rmf24.pl/fakty/swiat/news-czerwony-kapturek-wilkolak-i-wilki-dlaczego-europa-zmierza-t,nId,7869094)
 - RSS feed: $source
 - date published: 2024-12-04T16:17:29+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-czerwony-kapturek-wilkolak-i-wilki-dlaczego-europa-zmierza-t,nId,7869094"><img src="https://interia-s.pluscdn.pl/czerwony-kapturek-wilkolak-i-wilki-dlaczego-europa-zmierza-t/000K8C3KREPAE5I4-C307.jpg" alt="Czerwony Kapturek, wilkołak i wilki. Dlaczego Europa zmierza tam, gdzie nie powinna?" align="left" /></a>Stały Komitet Konwencji Berneńskiej zagłosował za obniżeniem statusu ochronnego wilka. Drapieżniki te nie będą już ściśle chronione. Decyzja zapadła na wniosek państw Unii Europejskich, a za jego przyjęciem zagłosowała także Polska. Jaki los czeka teraz wilki i dlaczego postanowiono o chronieniu ich w mniejszym stopniu? O sprawie Piotr Salak rozmawiał w Radiu RMF24 z dziennikarzem &quot;Gazety Wyborczej&quot; Adamem Wajrakiem, który o tych majestatycznych zwierzętach pisał wielokrotnie.</p><br clear="all" />

## Stopy procentowe. Jest decyzja Rady Polityki Pieniężnej
 - [https://www.rmf24.pl/ekonomia/news-stopy-procentowe-jest-decyzja-rady-polityki-pienieznej,nId,7869129](https://www.rmf24.pl/ekonomia/news-stopy-procentowe-jest-decyzja-rady-polityki-pienieznej,nId,7869129)
 - RSS feed: $source
 - date published: 2024-12-04T15:33:47.747122+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-stopy-procentowe-jest-decyzja-rady-polityki-pienieznej,nId,7869129"><img src="https://interia-s.pluscdn.pl/stopy-procentowe-jest-decyzja-rady-polityki-pienieznej/000K8C3MSQ93QFYK-C307.jpg" alt="Stopy procentowe. Jest decyzja Rady Polityki Pieniężnej" align="left" /></a>Rada Polityki Pieniężnej zdecydowała o pozostawieniu stóp procentowych na dotychczasowym poziomie – poinformował bank centralny w komunikacie. Stopa referencyjna NBP nadal wynosi 5,75 proc.</p><br clear="all" />

## Sejmowa komisja zdecydowała ws. immunitetu Jarosława Kaczyńskiego
 - [https://www.rmf24.pl/polityka/news-sejmowa-komisja-zdecydowala-ws-immunitetu-jaroslawa-kaczynsk,nId,7869057](https://www.rmf24.pl/polityka/news-sejmowa-komisja-zdecydowala-ws-immunitetu-jaroslawa-kaczynsk,nId,7869057)
 - RSS feed: $source
 - date published: 2024-12-04T14:35:02+00:00

<p><a href="https://www.rmf24.pl/polityka/news-sejmowa-komisja-zdecydowala-ws-immunitetu-jaroslawa-kaczynsk,nId,7869057"><img src="https://interia-s.pluscdn.pl/sejmowa-komisja-zdecydowala-ws-immunitetu-jaroslawa-kaczynsk/000K8DBKCM2IC99G-C307.jpg" alt="Sejmowa komisja zdecydowała ws. immunitetu Jarosława Kaczyńskiego" align="left" /></a>Czy Jarosław Kaczyński będzie miał kłopoty? Sejmowa komisja regulaminowa pozytywnie rozpatrzyła wniosek o wyrażenie zgody na pociągnięcie prezesa PiS do odpowiedzialności za wydarzenia w trakcie obchodów miesięcznicy katastrofy smoleńskiej. Sam prezes podkreślił w oświadczeniu, że miał prawo do swojej reakcji.</p><br clear="all" />

## Górnicze oświadczyny podczas barbórkowej parady
 - [https://www.rmf24.pl/regiony/slaskie/news-gornicze-oswiadczyny-podczas-barborkowej-parady,nId,7869096](https://www.rmf24.pl/regiony/slaskie/news-gornicze-oswiadczyny-podczas-barborkowej-parady,nId,7869096)
 - RSS feed: $source
 - date published: 2024-12-04T14:28:56.181118+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-gornicze-oswiadczyny-podczas-barborkowej-parady,nId,7869096"><img src="https://interia-s.pluscdn.pl/gornicze-oswiadczyny-podczas-barborkowej-parady/000K8ALAOEWGI5A0-C307.jpg" alt="Górnicze oświadczyny podczas barbórkowej parady" align="left" /></a>Barbórka to tradycyjne górnicze święto. Okazuje się, że można celebrować ten dzień w wyjątkowy sposób - np. prosząc o rękę. </p><br clear="all" />

## Naukowcy już wiedzą, dlaczego dieta keto czy post dobrze działają na mózg
 - [https://www.rmf24.pl/nauka/news-naukowcy-juz-wiedza-dlaczego-dieta-keto-czy-post-dobrze-dzia,nId,7869006](https://www.rmf24.pl/nauka/news-naukowcy-juz-wiedza-dlaczego-dieta-keto-czy-post-dobrze-dzia,nId,7869006)
 - RSS feed: $source
 - date published: 2024-12-04T14:28:56.011054+00:00

<p><a href="https://www.rmf24.pl/nauka/news-naukowcy-juz-wiedza-dlaczego-dieta-keto-czy-post-dobrze-dzia,nId,7869006"><img src="https://interia-s.pluscdn.pl/naukowcy-juz-wiedza-dlaczego-dieta-keto-czy-post-dobrze-dzia/000K8AMCCJPXK1GA-C307.jpg" alt="Naukowcy już wiedzą, dlaczego dieta keto czy post dobrze działają na mózg" align="left" /></a>Dieta keto albo post przerywany mogą odmładzać nam mózg. Naukowcy z Buck Institute for Research on Aging w Kalifornii odkryli nowy mechanizm działania tak zwanych ciał ketonowych, które nasz organizm w trakcie takich diet wytwarza jako paliwo. Na łamach czasopisma &quot;Cell Chemical Biology&quot; piszą, że ich znaczenie nie ogranicza się do produkcji energii, mogą też korzystnie wpływać na proces starzenia się mózgu i ryzyko choroby Alzheimera. Badania na myszach obciążonych genetycznym ryzykiem choroby podobnej do Alzheimera pokazały, że np....</p><br clear="all" />

## Polak Władysław Kondratowicz został szefem MSW Litwy
 - [https://www.rmf24.pl/fakty/swiat/news-polak-wladyslaw-kondratowicz-zostal-szefem-msw-litwy,nId,7869109](https://www.rmf24.pl/fakty/swiat/news-polak-wladyslaw-kondratowicz-zostal-szefem-msw-litwy,nId,7869109)
 - RSS feed: $source
 - date published: 2024-12-04T14:28:55.795541+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-polak-wladyslaw-kondratowicz-zostal-szefem-msw-litwy,nId,7869109"><img src="https://interia-s.pluscdn.pl/polak-wladyslaw-kondratowicz-zostal-szefem-msw-litwy/000K8B0Y1XOJOSWA-C307.jpg" alt="Polak Władysław Kondratowicz został szefem MSW Litwy" align="left" /></a>Prezydent Litwy Gitanas Nauseda zatwierdził skład nowego rządu socjaldemokraty Ginatautasa Paluckasa. Stanowisko ministra spraw wewnętrznych objął Polak Władysław Kondratowicz, obecny dyrektor Administracji Samorządu Rejonu Wileńskiego, wcześniej wiceminister komunikacji.</p><br clear="all" />

## Głodzenie budżetowych "świętych krów"
 - [https://www.rmf24.pl/news-glodzenie-budzetowych-swietych-krow,nId,7868995](https://www.rmf24.pl/news-glodzenie-budzetowych-swietych-krow,nId,7868995)
 - RSS feed: $source
 - date published: 2024-12-04T14:28:55.214362+00:00

<p><a href="https://www.rmf24.pl/news-glodzenie-budzetowych-swietych-krow,nId,7868995"><img src="https://interia-s.pluscdn.pl/glodzenie-budzetowych-swietych-krow/000K8AKL4WAOM2G2-C307.jpg" alt="Głodzenie budżetowych &quot;świętych krów&quot;" align="left" /></a>Krajowa Rada Radiofonii i Telewizji ma w przyszłym roku stracić ponad połowę planowanych środków, Krajowa Rada Sądownictwa prawie jedną czwartą, a Trybunał Konstytucyjny ma otrzymać ponad 17 proc. mniej. W piątek Sejm ma uchwalić przyszłoroczny budżet, w którym realizuje zapowiadany zamiar obcięcia finansowania niektórych organów i urzędów. W niektórych przypadkach dające ponad 335 milionów złotych cięcia są dość drastyczne.</p><br clear="all" />

## Kaczyński: Szkalowano pamięć mojego brata, miałem prawo do reakcji
 - [https://www.rmf24.pl/polityka/news-kaczynski-szkalowano-pamiec-mojego-brata-mialem-prawo-do-rea,nId,7869057](https://www.rmf24.pl/polityka/news-kaczynski-szkalowano-pamiec-mojego-brata-mialem-prawo-do-rea,nId,7869057)
 - RSS feed: $source
 - date published: 2024-12-04T14:28:55.015581+00:00

<p><a href="https://www.rmf24.pl/polityka/news-kaczynski-szkalowano-pamiec-mojego-brata-mialem-prawo-do-rea,nId,7869057"><img src="https://interia-s.pluscdn.pl/kaczynski-szkalowano-pamiec-mojego-brata-mialem-prawo-do-rea/000K8AJM4B9E6O0W-C307.jpg" alt="Kaczyński: Szkalowano pamięć mojego brata, miałem prawo do reakcji" align="left" /></a>Czy Jarosław Kaczyński będzie miał kłopoty? Sejmowa komisja regulaminowa rozpatruje wniosek o wyrażenie zgody na pociągnięcie prezesa PiS do odpowiedzialności za wydarzenia w trakcie obchodów miesięcznicy katastrofy smoleńskiej. Sam prezes podkreślił w oświadczeniu, że miał prawo do swojej reakcji.</p><br clear="all" />

## Dostawy sprzętu z Korei Płd. do Polski bez opóźnień
 - [https://www.rmf24.pl/fakty/polska/news-dostawy-sprzetu-z-korei-pld-do-polski-bez-opoznien,nId,7869041](https://www.rmf24.pl/fakty/polska/news-dostawy-sprzetu-z-korei-pld-do-polski-bez-opoznien,nId,7869041)
 - RSS feed: $source
 - date published: 2024-12-04T14:16:13+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-dostawy-sprzetu-z-korei-pld-do-polski-bez-opoznien,nId,7869041"><img src="https://interia-s.pluscdn.pl/dostawy-sprzetu-z-korei-pld-do-polski-bez-opoznien/000K89U023BDU8IX-C307.jpg" alt="Dostawy sprzętu z Korei Płd. do Polski bez opóźnień" align="left" /></a>Koreańczycy przyśpieszają dostawy do Polski czołgów K2 oraz aurmatohaubic K - poinformował wiceminister obrony narodowej Paweł Bejda. Zapewnił, że w związku z kryzysem politycznym w Korei Południowej zakupy uzbrojenia dla Polski nie są zagrożone i nie ma mowy o żadnych zakłóceniach. </p><br clear="all" />

## Problemy NATO: Bałtyk, rosyjska dezinformacja i agentura. Polska ma propozycje
 - [https://www.rmf24.pl/fakty/swiat/news-problemy-nato-baltyk-rosyjska-dezinformacja-i-agentura-polsk,nId,7869007](https://www.rmf24.pl/fakty/swiat/news-problemy-nato-baltyk-rosyjska-dezinformacja-i-agentura-polsk,nId,7869007)
 - RSS feed: $source
 - date published: 2024-12-04T14:12:56+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-problemy-nato-baltyk-rosyjska-dezinformacja-i-agentura-polsk,nId,7869007"><img src="https://interia-s.pluscdn.pl/problemy-nato-baltyk-rosyjska-dezinformacja-i-agentura-polsk/000K89U9HOYUC7Y9-C307.jpg" alt="Problemy NATO: Bałtyk, rosyjska dezinformacja i agentura. Polska ma propozycje" align="left" /></a>NATO musi odpowiedzieć na zagrożenie dla bezpieczeństwa krajów Sojuszu w rejonie Bałtyku. Szef polskiej dyplomacji Radosław Sikorski bierze udział w dwudniowym posiedzeniu ministrów Paktu Północnoatlantyckiego i przekonuje do konieczności przyjęcia postulatu Warszawy o konieczności stworzenia wspólnych misji patrolowych na morzu. Istotna w kontekście rosyjskiej aktywności będzie też ściślejsza wymiana wywiadowcza w ramach krajów sojuszniczych.</p><br clear="all" />

## Wybili szybę w aucie i ukradli walizkę z 60 tys. euro. Policja szuka rabusiów
 - [https://www.rmf24.pl/regiony/lodz/news-wybili-szybe-w-aucie-i-ukradli-walizke-z-60-tys-euro-policja,nId,7869023](https://www.rmf24.pl/regiony/lodz/news-wybili-szybe-w-aucie-i-ukradli-walizke-z-60-tys-euro-policja,nId,7869023)
 - RSS feed: $source
 - date published: 2024-12-04T13:23:43.504508+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-wybili-szybe-w-aucie-i-ukradli-walizke-z-60-tys-euro-policja,nId,7869023"><img src="https://interia-s.pluscdn.pl/wybili-szybe-w-aucie-i-ukradli-walizke-z-60-tys-euro-policja/000K89H5KOQQH6HW-C307.jpg" alt="Wybili szybę w aucie i ukradli walizkę z 60 tys. euro. Policja szuka rabusiów" align="left" /></a>Policja z Piotrkowa Trybunalskiego poszukuje sprawców kradzieży pieniędzy w centrum miasta. Na ul. Skłodowskiej przestępcy wybili szybę w zaparkowanym samochodzie i uciekli z walizką zawierającą 60 tys. euro.</p><br clear="all" />

## Dwa niewybuchy znalezione w Łódzkiem. Bomb może być więcej
 - [https://www.rmf24.pl/regiony/lodz/news-dwa-niewybuchy-znalezione-w-lodzkiem-bomb-moze-byc-wiecej,nId,7868959](https://www.rmf24.pl/regiony/lodz/news-dwa-niewybuchy-znalezione-w-lodzkiem-bomb-moze-byc-wiecej,nId,7868959)
 - RSS feed: $source
 - date published: 2024-12-04T12:18:33.728341+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-dwa-niewybuchy-znalezione-w-lodzkiem-bomb-moze-byc-wiecej,nId,7868959"><img src="https://interia-s.pluscdn.pl/dwa-niewybuchy-znalezione-w-lodzkiem-bomb-moze-byc-wiecej/000K87YKOG6K9OM2-C307.jpg" alt="Dwa niewybuchy znalezione w Łódzkiem. Bomb może być więcej" align="left" /></a>Dwa niewybuchy z czasów drugiej wojny światowej znaleziono w miejscowości Przedbórz w województwie łódzkim. Na miejscu pracuje patrol saperski. Jak dowiedział się reporter RMF FM Beniamin Kubiak-Piłat, służby zapewniają, że ewakuacja nie jest konieczna.</p><br clear="all" />

## Medycy też mówią "tak" Europie. Relacja RMF FM z Gruzji
 - [https://www.rmf24.pl/fakty/swiat/news-medycy-tez-mowia-tak-europie-relacja-rmf-fm-z-gruzji,nId,7868946](https://www.rmf24.pl/fakty/swiat/news-medycy-tez-mowia-tak-europie-relacja-rmf-fm-z-gruzji,nId,7868946)
 - RSS feed: $source
 - date published: 2024-12-04T12:15:56+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-medycy-tez-mowia-tak-europie-relacja-rmf-fm-z-gruzji,nId,7868946"><img src="https://interia-s.pluscdn.pl/medycy-tez-mowia-tak-europie-relacja-rmf-fm-z-gruzji/000K87AW14H46J57-C307.jpg" alt="Medycy też mówią &quot;tak&quot; Europie. Relacja RMF FM z Gruzji" align="left" /></a>Pracownicy gruzińskiej służby zdrowia zapowiedzieli na środowe popołudnie marsz białych fartuchów. Medycy zamierzają wesprzeć rodaków protestujących od tygodnia przeciwko obecnej, antyeuropejskiej polityce rządu. W Gruzji jest specjalny wysłannik RMF FM, który zbiera informacje w tej sprawie.</p><br clear="all" />

## NEWS RMF FM: 24-latek spowodował kolejny wypadek, tym razem śmiertelny
 - [https://www.rmf24.pl/regiony/poznan/news-news-rmf-fm-24-letni-kierowca-spowodowal-kolejny-wypadek-tym,nId,7868945](https://www.rmf24.pl/regiony/poznan/news-news-rmf-fm-24-letni-kierowca-spowodowal-kolejny-wypadek-tym,nId,7868945)
 - RSS feed: $source
 - date published: 2024-12-04T12:13:41+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-news-rmf-fm-24-letni-kierowca-spowodowal-kolejny-wypadek-tym,nId,7868945"><img src="https://interia-s.pluscdn.pl/news-rmf-fm-24-latek-spowodowal-kolejny-wypadek-tym-razem-sm/000K87ZBJ3SRFWBT-C307.jpg" alt="NEWS RMF FM: 24-latek spowodował kolejny wypadek, tym razem śmiertelny" align="left" /></a>24-latek, który we wtorek spowodował śmiertelny wypadek w Wolsztynie, miał mieć trzy dni temu odebrane prawo jazdy - dowiedział się reporter RMF FM. We wtorkowym wypadku z udziałem dwóch osobówek zginął 71-letni mężczyzna.</p><br clear="all" />

## Przemycali cudzoziemców do Niemiec. Kary dla dwóch Polaków
 - [https://www.rmf24.pl/regiony/lodz/news-przemycali-cudzoziemcow-do-niemiec-kary-dla-dwoch-polakow,nId,7868922](https://www.rmf24.pl/regiony/lodz/news-przemycali-cudzoziemcow-do-niemiec-kary-dla-dwoch-polakow,nId,7868922)
 - RSS feed: $source
 - date published: 2024-12-04T12:02:19+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-przemycali-cudzoziemcow-do-niemiec-kary-dla-dwoch-polakow,nId,7868922"><img src="https://interia-s.pluscdn.pl/przemycali-cudzoziemcow-do-niemiec-kary-dla-dwoch-polakow/000K86FQ0YVHRGYI-C307.jpg" alt="Przemycali cudzoziemców do Niemiec. Kary dla dwóch Polaków" align="left" /></a>Jest wyrok dla dwóch mieszkańców Łodzi, którzy działali w zorganizowanej grupie przestępczej, zajmującej się przemytem cudzoziemców do Niemiec. Zostali skazani na kary roku i trzech miesięcy oraz 10 miesięcy bezwzględnego więzienia. </p><br clear="all" />

## Jarosław Kaczyński wezwany do prokuratury. Chodzi o list do Ziobry
 - [https://www.rmf24.pl/polityka/news-jaroslaw-kaczynski-wezwany-do-prokuratury-chodzi-o-list-do-z,nId,7868844](https://www.rmf24.pl/polityka/news-jaroslaw-kaczynski-wezwany-do-prokuratury-chodzi-o-list-do-z,nId,7868844)
 - RSS feed: $source
 - date published: 2024-12-04T11:13:23.737665+00:00

<p><a href="https://www.rmf24.pl/polityka/news-jaroslaw-kaczynski-wezwany-do-prokuratury-chodzi-o-list-do-z,nId,7868844"><img src="https://interia-s.pluscdn.pl/jaroslaw-kaczynski-wezwany-do-prokuratury-chodzi-o-list-do-z/000K85V48THW641S-C307.jpg" alt="Jarosław Kaczyński wezwany do prokuratury. Chodzi o list do Ziobry" align="left" /></a>Jarosław Kaczyński został wezwany przez prokuraturę. Jak dowiedział się reporter RMF FM Krzysztof Zasada, prezes Prawa i Sprawiedliwości ma w przyszłym tygodniu zeznawać w śledztwie dotyczącym afery w Funduszu Sprawiedliwości.</p><br clear="all" />

## Izabela Leszczyna gościem Rozmowy o 7:00 w Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-izabela-leszczyna-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7868829](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-izabela-leszczyna-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7868829)
 - RSS feed: $source
 - date published: 2024-12-04T11:13:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-izabela-leszczyna-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7868829"><img src="https://interia-s.pluscdn.pl/izabela-leszczyna-gosciem-rozmowy-o-7-00-w-radiu-rmf24/000K84NEP5LL8D4J-C307.jpg" alt="Izabela Leszczyna gościem Rozmowy o 7:00 w Radiu RMF24" align="left" /></a>Minister zdrowia Izabela Leszczyna będzie w czwartek gościem Tomasza Terlikowskiego w Rozmowie o 7:00 w Radiu RMF24. Porozmawiamy m.in. o najpilniejszych problemach polskiej psychiatrii. </p><br clear="all" />

## Niebezpieczny przestępca z Libii zatrzymany na polskiej granicy
 - [https://www.rmf24.pl/fakty/polska/news-niebezpieczny-przestepca-z-libii-zatrzymany-na-polskiej-gran,nId,7868886](https://www.rmf24.pl/fakty/polska/news-niebezpieczny-przestepca-z-libii-zatrzymany-na-polskiej-gran,nId,7868886)
 - RSS feed: $source
 - date published: 2024-12-04T11:13:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-niebezpieczny-przestepca-z-libii-zatrzymany-na-polskiej-gran,nId,7868886"><img src="https://interia-s.pluscdn.pl/niebezpieczny-przestepca-z-libii-zatrzymany-na-polskiej-gran/000K85N940M87B19-C307.jpg" alt="Niebezpieczny przestępca z Libii zatrzymany na polskiej granicy" align="left" /></a>Ścigany czerwoną notą Interpolu m.in. za kierowanie zorganizowaną grupą przestępczą, porwania, szantaże i zabójstwa 34-letni obywatel Libii został zatrzymany na granicy w Korczowej. &quot;Nie stawiał oporu&quot; – poinformował w środę rzecznik Bieszczadzkiego Oddziału SG por. Piotr Zakielarz.</p><br clear="all" />

## Wiadomo, kiedy Hołownia poda datę pierwszej tury wyborów
 - [https://www.rmf24.pl/raporty/raport-wybory-prezydenckie-2025/news-8-stycznia-holownia-poda-date-pierwszej-tury-wyborow,nId,7868889](https://www.rmf24.pl/raporty/raport-wybory-prezydenckie-2025/news-8-stycznia-holownia-poda-date-pierwszej-tury-wyborow,nId,7868889)
 - RSS feed: $source
 - date published: 2024-12-04T11:09:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wybory-prezydenckie-2025/news-8-stycznia-holownia-poda-date-pierwszej-tury-wyborow,nId,7868889"><img src="https://interia-s.pluscdn.pl/wiadomo-kiedy-holownia-poda-date-pierwszej-tury-wyborow/000K85MTGQESSNT8-C307.jpg" alt="Wiadomo, kiedy Hołownia poda datę pierwszej tury wyborów" align="left" /></a>&quot;8 stycznia poinformuję, jaka będzie data pierwszej tury wyborów prezydenckich&quot; - powiedział w środę marszałek Sejmu Szymon Hołownia. Lider Polski 2050 dodał, że formalne zarządzenie w tej sprawie pojawi się 15 stycznia, zgodnie z opinią Państwowej Komisji Wyborczej. W trakcie środowej konferencji polityk wspominał także o własnym kandydowaniu. Wrócił też do tematu uczelni Collegium Humanum.</p><br clear="all" />

## "Choinki pod choinkę od RMF FM i Małopolski". Sprawdź, które miasta odwiedzimy
 - [https://www.rmf24.pl/raporty/raport-boze-narodzenie-2024/news-choinki-pod-choinke-od-rmf-fm-i-malopolski-sprawdz-ktore-mia,nId,7868859](https://www.rmf24.pl/raporty/raport-boze-narodzenie-2024/news-choinki-pod-choinke-od-rmf-fm-i-malopolski-sprawdz-ktore-mia,nId,7868859)
 - RSS feed: $source
 - date published: 2024-12-04T11:00:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-boze-narodzenie-2024/news-choinki-pod-choinke-od-rmf-fm-i-malopolski-sprawdz-ktore-mia,nId,7868859"><img src="https://interia-s.pluscdn.pl/choinki-pod-choinke-od-rmf-fm-i-malopolski-sprawdz-ktore-mia/000K89EUTQ6PYT9R-C307.jpg" alt="&quot;Choinki pod choinkę od RMF FM i Małopolski&quot;. Sprawdź, które miasta odwiedzimy" align="left" /></a>Żółto-niebieski konwój z choinkami znowu rusza w Polskę. Kolejny rok mamy dla Was tysiące pachnących drzewek i wiele atrakcji. 8 dni, 9 miast i setki pokonanych kilometrów. &quot;Choinki pod Choinkę od RMF FM i Małopolski&quot; startują już 6 grudnia. Sprawdźcie, kiedy zawitamy w Wasze rejony!</p><br clear="all" />

## Kilkadziesiąt oddechów od śmierci. Uratowała ją czujka czadu
 - [https://www.rmf24.pl/regiony/rzeszow/news-kilkadziesiat-oddechow-od-smierci-uratowala-ja-czujka-czadu,nId,7868837](https://www.rmf24.pl/regiony/rzeszow/news-kilkadziesiat-oddechow-od-smierci-uratowala-ja-czujka-czadu,nId,7868837)
 - RSS feed: $source
 - date published: 2024-12-04T10:08:19.726293+00:00

<p><a href="https://www.rmf24.pl/regiony/rzeszow/news-kilkadziesiat-oddechow-od-smierci-uratowala-ja-czujka-czadu,nId,7868837"><img src="https://interia-s.pluscdn.pl/kilkadziesiat-oddechow-od-smierci-uratowala-ja-czujka-czadu/000K84V70AHJAUEI-C307.jpg" alt="Kilkadziesiąt oddechów od śmierci. Uratowała ją czujka czadu" align="left" /></a>21-letnia kobieta trafiła do szpitala z objawami zatrucia tlenkiem węgla. Do zdarzenia doszło w środę rano w jednym z mieszkań w Mielcu (woj. podkarpackie). Strażacy zostali wezwani przez sąsiadów, którzy usłyszeli w mieszkaniu sygnał czujki.</p><br clear="all" />

## Boże Narodzenie będzie białe? Najnowsza prognoza
 - [https://www.rmf24.pl/pogoda/news-boze-narodzenie-bedzie-biale-najnowsza-prognoza,nId,7868838](https://www.rmf24.pl/pogoda/news-boze-narodzenie-bedzie-biale-najnowsza-prognoza,nId,7868838)
 - RSS feed: $source
 - date published: 2024-12-04T10:08:19.335777+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-boze-narodzenie-bedzie-biale-najnowsza-prognoza,nId,7868838"><img src="https://interia-s.pluscdn.pl/boze-narodzenie-bedzie-biale-najnowsza-prognoza/000K84O31F2393KO-C307.jpg" alt="Boże Narodzenie będzie białe? Najnowsza prognoza" align="left" /></a>Pogoda podczas tegorocznych świąt Bożego Narodzenia nie będzie szczególnie odbiegać od normy wieloletniej - wynika z najnowszej długoterminowej prognozy udostępnionej na platformie X przez IMGW.</p><br clear="all" />

## Atak hakerski w krakowskim MPK. Winna "międzynarodowa grupa"
 - [https://www.rmf24.pl/regiony/krakow/news-atak-hakerski-w-krakowskim-mpk-winna-miedzynarodowa-grupa,nId,7868808](https://www.rmf24.pl/regiony/krakow/news-atak-hakerski-w-krakowskim-mpk-winna-miedzynarodowa-grupa,nId,7868808)
 - RSS feed: $source
 - date published: 2024-12-04T10:08:19.139476+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-atak-hakerski-w-krakowskim-mpk-winna-miedzynarodowa-grupa,nId,7868808"><img src="https://interia-s.pluscdn.pl/atak-hakerski-w-krakowskim-mpk-winna-miedzynarodowa-grupa/000K84DHO3CJOQPC-C307.jpg" alt="Atak hakerski w krakowskim MPK. Winna &quot;międzynarodowa grupa&quot;" align="left" /></a>Krakowskie MPK poinformowało, że padło ofiarą ataku hakerskiego, który został przeprowadzony wcześnie rano we wtorek. Z uzyskanych informacji wynika, że stoi za nim międzynarodowa grupa hakerska przeprowadzająca na zlecenie ataki na różne przedsiębiorstwa. Sprawa została zgłoszona policji oraz odpowiednim służbom.</p><br clear="all" />

## Afera wizowa: Zawiadomienia do prokuratury są już gotowe
 - [https://www.rmf24.pl/raporty/raport-afera-wizowa/news-afera-wizowa-zawiadomienia-do-prokuratury-sa-juz-gotowe,nId,7868807](https://www.rmf24.pl/raporty/raport-afera-wizowa/news-afera-wizowa-zawiadomienia-do-prokuratury-sa-juz-gotowe,nId,7868807)
 - RSS feed: $source
 - date published: 2024-12-04T10:08:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-afera-wizowa/news-afera-wizowa-zawiadomienia-do-prokuratury-sa-juz-gotowe,nId,7868807"><img src="https://interia-s.pluscdn.pl/afera-wizowa-zawiadomienia-do-prokuratury-sa-juz-gotowe/000K84C2JK7DABPO-C307.jpg" alt="Afera wizowa: Zawiadomienia do prokuratury są już gotowe" align="left" /></a>Szef sejmowej komisji śledczej Marek Sowa (KO) powiedział, że zawiadomienia do prokuratury w związku z tzw. aferą wizową są już gotowe. Dodał, że zapewne w tym tygodniu zostaną wysłane do prokuratury.</p><br clear="all" />

## 12-latek wpadł pod pociąg SKM. Trafił do szpitala
 - [https://www.rmf24.pl/regiony/warszawa/news-12-latek-wpadl-pod-pociag-skm-trafil-do-szpitala,nId,7868840](https://www.rmf24.pl/regiony/warszawa/news-12-latek-wpadl-pod-pociag-skm-trafil-do-szpitala,nId,7868840)
 - RSS feed: $source
 - date published: 2024-12-04T10:06:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-12-latek-wpadl-pod-pociag-skm-trafil-do-szpitala,nId,7868840"><img src="https://interia-s.pluscdn.pl/12-latek-wpadl-pod-pociag-skm-trafil-do-szpitala/000K84O4CL1BILHM-C307.jpg" alt="12-latek wpadł pod pociąg SKM. Trafił do szpitala" align="left" /></a>Wypadek na tzw. dzikim przejściu kolejowym w podwarszawskim Aninie. Pod pociąg Szybkiej Kolei Miejskiej wpadł 12-latek.</p><br clear="all" />

## Tatrzańskie stawy zamarzają. Wchodząc, ryzykujesz życiem
 - [https://www.rmf24.pl/regiony/zakopane/news-tatrzanskie-stawy-zamarzaja-wchodzac-ryzykujesz-zyciem,nId,7868785](https://www.rmf24.pl/regiony/zakopane/news-tatrzanskie-stawy-zamarzaja-wchodzac-ryzykujesz-zyciem,nId,7868785)
 - RSS feed: $source
 - date published: 2024-12-04T09:03:24.557325+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-tatrzanskie-stawy-zamarzaja-wchodzac-ryzykujesz-zyciem,nId,7868785"><img src="https://interia-s.pluscdn.pl/tatrzanskie-stawy-zamarzaja-wchodzac-ryzykujesz-zyciem/000K83QM7YAGH2WC-C307.jpg" alt="Tatrzańskie stawy zamarzają. Wchodząc, ryzykujesz życiem" align="left" /></a>Tatrzański Park Narodowy (TPN) apeluje o niewchodzenie na tafle zamarzających tatrzańskich stawów. Lód w wielu miejscach jest jeszcze bardzo cienki i z łatwością może się załamać - ostrzegają służby parku.</p><br clear="all" />

## Sądy są pobłażliwe dla aktywistów z Ostatniego Pokolenia
 - [https://www.rmf24.pl/regiony/warszawa/news-sady-sa-poblazliwe-dla-aktywistow-z-ostatniego-pokolenia,nId,7868806](https://www.rmf24.pl/regiony/warszawa/news-sady-sa-poblazliwe-dla-aktywistow-z-ostatniego-pokolenia,nId,7868806)
 - RSS feed: $source
 - date published: 2024-12-04T09:03:24.021644+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-sady-sa-poblazliwe-dla-aktywistow-z-ostatniego-pokolenia,nId,7868806"><img src="https://interia-s.pluscdn.pl/sady-sa-poblazliwe-dla-aktywistow-z-ostatniego-pokolenia/000K84MBVTHX8EBD-C307.jpg" alt="Sądy są pobłażliwe dla aktywistów z Ostatniego Pokolenia" align="left" /></a>Sądy są pobłażliwe dla aktywistów ekologicznych z Ostatniego Pokolenia, którzy blokują stołeczne drogi. Jak dowiedział się reporter RMF FM, rozpatrując sprawy o ukaranie za wykroczenia, w większości przypadków orzekają wobec nich nagany.</p><br clear="all" />

## Pijany kierowca spał w aucie na drodze ekspresowej
 - [https://www.rmf24.pl/regiony/lodz/news-pijany-kierowca-spal-w-aucie-na-drodze-ekspresowej,nId,7868757](https://www.rmf24.pl/regiony/lodz/news-pijany-kierowca-spal-w-aucie-na-drodze-ekspresowej,nId,7868757)
 - RSS feed: $source
 - date published: 2024-12-04T07:58:12.451325+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-pijany-kierowca-spal-w-aucie-na-drodze-ekspresowej,nId,7868757"><img src="https://interia-s.pluscdn.pl/pijany-kierowca-spal-w-aucie-na-drodze-ekspresowej/000K832OQG1T2RO4-C307.jpg" alt="Pijany kierowca spał w aucie na drodze ekspresowej" align="left" /></a>Policjanci z łaskiej drogówki, patrolując drogę ekspresową S8, zauważyli stojący na pasie awaryjnym samochód osobowy. Pojazd nie był oznaczony trójkątem ostrzegawczym, dlatego też postanowili zatrzymać się i sprawdzić, co się stało. Po otwarciu drzwi auta funkcjonariusze zobaczyli w nim śpiącego kierowcę. 29-latek był nietrzeźwy.</p><br clear="all" />

## Na orbitę trafi dziś europejska sonda do symulacji zaćmień Słońca
 - [https://www.rmf24.pl/nauka/news-na-orbite-trafi-dzis-europejska-sonda-do-symulacji-zacmien-s,nId,7868765](https://www.rmf24.pl/nauka/news-na-orbite-trafi-dzis-europejska-sonda-do-symulacji-zacmien-s,nId,7868765)
 - RSS feed: $source
 - date published: 2024-12-04T07:58:12.236617+00:00

<p><a href="https://www.rmf24.pl/nauka/news-na-orbite-trafi-dzis-europejska-sonda-do-symulacji-zacmien-s,nId,7868765"><img src="https://interia-s.pluscdn.pl/na-orbite-trafi-dzis-europejska-sonda-do-symulacji-zacmien-s/000K837XDWFGXD27-C307.jpg" alt="Na orbitę trafi dziś europejska sonda do symulacji zaćmień Słońca" align="left" /></a>Z Centrum Kosmicznego Satish Dhawan w Sriharikota w Indiach, na pokładzie rakiety PSLV-XL, ma zostać dziś wystrzelona na orbitę sonda Europejskiej Agencji Kosmicznej Proba-3. Ten satelita to tak naprawdę zestaw dwóch próbników, które będą miały zademonstrować precyzyjny lot w formacji i przy okazji umożliwić badania sztucznie wywoływanego zaćmienia Słońca. Start zaplanowano na godz. 11:38 czasu polskiego. Czterostopniowa rakieta nośna PSLV-XL z Indii została wybrana ze względu na wysoką wydajność w połączeniu z odpowiednią dla takiej...</p><br clear="all" />

## Bosak o Collegium Humanum: Tysiące ludzi studiowało tam uczciwie
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-bosak-o-collegium-humanum-tysiace-ludzi-studiowalo-tam-uczci,nId,7868327](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-bosak-o-collegium-humanum-tysiace-ludzi-studiowalo-tam-uczci,nId,7868327)
 - RSS feed: $source
 - date published: 2024-12-04T07:58:11.637332+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-bosak-o-collegium-humanum-tysiace-ludzi-studiowalo-tam-uczci,nId,7868327"><img src="https://interia-s.pluscdn.pl/bosak-o-collegium-humanum-tysiace-ludzi-studiowalo-tam-uczci/000K7YM86W4TTMQS-C307.jpg" alt="Bosak o Collegium Humanum: Tysiące ludzi studiowało tam uczciwie" align="left" /></a>&quot;W całej tej aferze umyka jedna rzecz - tysiące, kilkanaście tysięcy, a być może dziesiątki tysięcy ludzi studiowało tam uczciwe, wielu pracowników naukowych pracowało tam uczciwie i to zupełnie znika w tej historii. A faktycznie winni nie są dostatecznie naświetlani&quot; - powiedział w Porannej rozmowie w RMF FM Krzysztof Bosak, odnosząc się do afery ws. Collegium Humanum. Lider Konfederacji przyznał, że przez chwilę studiował tam zarządzanie, jednak po kilku miesiącach zrezygnował, a dyplomu nigdy nie uzyskał.</p><br clear="all" />

## Dramat w Krakowie. Mężczyzna zastrzelił się na komisariacie
 - [https://www.rmf24.pl/regiony/krakow/news-dramat-w-krakowie-mezczyzna-zastrzelil-sie-na-komisariacie,nId,7868753](https://www.rmf24.pl/regiony/krakow/news-dramat-w-krakowie-mezczyzna-zastrzelil-sie-na-komisariacie,nId,7868753)
 - RSS feed: $source
 - date published: 2024-12-04T07:58:11.439435+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-dramat-w-krakowie-mezczyzna-zastrzelil-sie-na-komisariacie,nId,7868753"><img src="https://interia-s.pluscdn.pl/dramat-w-krakowie-mezczyzna-zastrzelil-sie-na-komisariacie/000K8302OBL2F20U-C307.jpg" alt="Dramat w Krakowie. Mężczyzna zastrzelił się na komisariacie" align="left" /></a>Dramatyczne wydarzenia w Krakowie. Jak dowiedziała się reporterka RMF FM, mężczyzna wyrwał policjantom broń, zabarykadował się na komisariacie i popełnił samobójstwo. Wcześniej w szpitalu zmarła jego 24-letnia partnerka.</p><br clear="all" />

## Barbórka ruszyła, orkiestra zagrała. Zobacz nagranie z Nikiszowca
 - [https://www.rmf24.pl/regiony/slaskie/news-barborka-ruszyla-orkiestra-zagrala-zobacz-nagranie-z-nikiszo,nId,7868736](https://www.rmf24.pl/regiony/slaskie/news-barborka-ruszyla-orkiestra-zagrala-zobacz-nagranie-z-nikiszo,nId,7868736)
 - RSS feed: $source
 - date published: 2024-12-04T07:50:00+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-barborka-ruszyla-orkiestra-zagrala-zobacz-nagranie-z-nikiszo,nId,7868736"><img src="https://interia-s.pluscdn.pl/barborka-ruszyla-orkiestra-zagrala-zobacz-nagranie-z-nikiszo/000K82ZW2IDEV7ED-C307.jpg" alt="Barbórka ruszyła, orkiestra zagrała. Zobacz nagranie z Nikiszowca" align="left" /></a>Czwarty grudnia to dzień imienin Barbary, a także górnicza Barbórka. Świętowaniu co roku towarzyszy występ górniczych orkiestr. Nie inaczej było w środowy poranek na katowickim Nikiszowcu.</p><br clear="all" />

## "Węgiel jest skończony". Akcja Greenpeace Polska przy siedzibie resortu
 - [https://www.rmf24.pl/regiony/slaskie/news-wegiel-jest-skonczony-akcja-greenpeace-polska-przy-siedzibie,nId,7868741](https://www.rmf24.pl/regiony/slaskie/news-wegiel-jest-skonczony-akcja-greenpeace-polska-przy-siedzibie,nId,7868741)
 - RSS feed: $source
 - date published: 2024-12-04T07:49:00+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-wegiel-jest-skonczony-akcja-greenpeace-polska-przy-siedzibie,nId,7868741"><img src="https://interia-s.pluscdn.pl/wegiel-jest-skonczony-akcja-greenpeace-polska-przy-siedzibie/000K82OX8JYCQPEV-C307.jpg" alt="&quot;Węgiel jest skończony&quot;. Akcja Greenpeace Polska przy siedzibie resortu" align="left" /></a>Dziś Barbórka - dzień św. Barbary, która jest patronką m.in. górników. Z tej okazji aktywiści organizacji Greenpeace Polska zorganizowali protest przy siedzibie ​Ministerstwa Przemysłu w Katowicach; na budynku rozwinęli skierowany do rządu napis: &quot;Węgiel jest skończony. Przestańcie ściemniać&quot;.</p><br clear="all" />

## TK od dziś liczy 13 sędziów. Zakończyły się dwie kadencje
 - [https://www.rmf24.pl/polityka/news-trybunal-konstytucyjny-od-dzis-liczy-13-sedziow-zakonczyly-s,nId,7868732](https://www.rmf24.pl/polityka/news-trybunal-konstytucyjny-od-dzis-liczy-13-sedziow-zakonczyly-s,nId,7868732)
 - RSS feed: $source
 - date published: 2024-12-04T06:53:17.571138+00:00

<p><a href="https://www.rmf24.pl/polityka/news-trybunal-konstytucyjny-od-dzis-liczy-13-sedziow-zakonczyly-s,nId,7868732"><img src="https://interia-s.pluscdn.pl/tk-od-dzis-liczy-13-sedziow-zakonczyly-sie-dwie-kadencje/000K82O752VAPQLR-C307.jpg" alt="TK od dziś liczy 13 sędziów. Zakończyły się dwie kadencje" align="left" /></a>Zakończyły się kadencje Mariusza Muszyńskiego i Piotra Pszczółkowskiego w Trybunale Konstytucyjnym, w związku z czym TK od dziś liczy 13 sędziów. Za kilka dni zakończy się także kadencja kierującej pracami TK Julii Przyłębskiej.</p><br clear="all" />

## Kwiatkowski: Ziobro przekonał się, że instytucje państwa działają
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-kwiatkowski-ziobro-przekonal-sie-ze-instytucje-panstwa-dzial,nId,7868293](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-kwiatkowski-ziobro-przekonal-sie-ze-instytucje-panstwa-dzial,nId,7868293)
 - RSS feed: $source
 - date published: 2024-12-04T06:53:16.912286+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-kwiatkowski-ziobro-przekonal-sie-ze-instytucje-panstwa-dzial,nId,7868293"><img src="https://interia-s.pluscdn.pl/kwiatkowski-ziobro-przekonal-sie-ze-instytucje-panstwa-dzial/000K7YF0V3QH8Q0R-C307.jpg" alt="Kwiatkowski: Ziobro przekonał się, że instytucje państwa działają" align="left" /></a>&quot;Okażemy się tymi, którzy przestrzegają prawa i pamiętają, że jeśli poseł mógł się dopuścić przestępstwa, to trzeba mu uchylić immunitet, by mógł być pociągnięty do odpowiedzialności&quot; - tak o sprawie pozbawienia Zbigniewa Ziobry immunitetu mówił w Rozmowie o 7:00 w Radiu RMF24 Krzysztof Kwiatkowski, senator Koalicji Obywatelskiej. Stwierdził, że Ziobro przekonał się, że &quot;instytucje państwa, w tym konkretnym przypadku komisja regulaminowa Sejmu - działa&quot;.</p><br clear="all" />

## Krzysztof Bosak gościem Porannej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-krzysztof-bosak-gosciem-porannej-rozmowy-w-rmf-fm,nId,7868327](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-krzysztof-bosak-gosciem-porannej-rozmowy-w-rmf-fm,nId,7868327)
 - RSS feed: $source
 - date published: 2024-12-04T06:53:16.423488+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-krzysztof-bosak-gosciem-porannej-rozmowy-w-rmf-fm,nId,7868327"><img src="https://interia-s.pluscdn.pl/krzysztof-bosak-gosciem-porannej-rozmowy-w-rmf-fm/000K7YM86W4TTMQS-C307.jpg" alt="Krzysztof Bosak gościem Porannej rozmowy w RMF FM" align="left" /></a>Gościem Roberta Mazurka w Porannej rozmowie w RMF FM będzie Krzysztof Bosak, wicemarszałek Sejmu z Konfederacji. </p><br clear="all" />

## Donald Trump rozważa zastąpienie kandydata na szefa Pentagonu
 - [https://www.rmf24.pl/fakty/swiat/news-bedzie-zwrot-akcji-trump-rozwaza-zastapienie-kandydata-na-sz,nId,7868715](https://www.rmf24.pl/fakty/swiat/news-bedzie-zwrot-akcji-trump-rozwaza-zastapienie-kandydata-na-sz,nId,7868715)
 - RSS feed: $source
 - date published: 2024-12-04T06:48:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-bedzie-zwrot-akcji-trump-rozwaza-zastapienie-kandydata-na-sz,nId,7868715"><img src="https://interia-s.pluscdn.pl/donald-trump-rozwaza-zastapienie-kandydata-na-szefa-pentagon/000K82LYFRIC5O27-C307.jpg" alt="Donald Trump rozważa zastąpienie kandydata na szefa Pentagonu" align="left" /></a>Donald Trump rozważa zastąpienie wybranego przez siebie kandydata na szefa Pentagonu Pete'a Hegsetha byłym rywalem i gubernatorem Ronem DeSantisem - twierdzi &quot;Wall Street Journal&quot;. Część republikanów w Senacie wyraża sceptycyzm wobec prezentera telewizji Fox News w związku z ujawnionymi wybrykami z przeszłości.</p><br clear="all" />

## Broń i mundury z rosyjskimi naszywkami przejęte przez policję w Kosowie
 - [https://www.rmf24.pl/fakty/swiat/news-bron-i-mundury-z-rosyjskimi-naszywkami-przejete-przez-policj,nId,7868718](https://www.rmf24.pl/fakty/swiat/news-bron-i-mundury-z-rosyjskimi-naszywkami-przejete-przez-policj,nId,7868718)
 - RSS feed: $source
 - date published: 2024-12-04T06:45:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-bron-i-mundury-z-rosyjskimi-naszywkami-przejete-przez-policj,nId,7868718"><img src="https://interia-s.pluscdn.pl/bron-i-mundury-z-rosyjskimi-naszywkami-przejete-przez-policj/000K82LSOBJR9WUK-C307.jpg" alt="Broń i mundury z rosyjskimi naszywkami przejęte przez policję w Kosowie" align="left" /></a>Niespokojnie w Kosowie. Po tym, jak w ostatni piątek na zdominowanej przez Serbów północy tego kraju doszło do eksplozji na kanale zaopatrującym w wodę dwie największe elektrownie węglowe, we wtorek policjanci przejęli tam znaczną ilość broni i amunicji oraz mundury z m.in. rosyjskimi naszywkami.</p><br clear="all" />

## Próbny egzamin ósmoklasisty z języka obcego [ARKUSZE]
 - [https://www.rmf24.pl/fakty/polska/news-probny-egzamin-osmoklasisty-z-jezyka-obcego-arkusze,nId,7868655](https://www.rmf24.pl/fakty/polska/news-probny-egzamin-osmoklasisty-z-jezyka-obcego-arkusze,nId,7868655)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-probny-egzamin-osmoklasisty-z-jezyka-obcego-arkusze,nId,7868655"><img src="https://interia-s.pluscdn.pl/probny-egzamin-osmoklasisty-z-jezyka-obcego-arkusze/000K81PHJSB9ANF7-C307.jpg" alt="Próbny egzamin ósmoklasisty z języka obcego [ARKUSZE]" align="left" /></a>Trzeciego dnia próbnych egzaminów ósmoklasisty uczniowie zmierzyli się z językiem obcym. Na RMF24.pl publikujemy arkusze egzaminacyjne, udostępnione przez CKE.</p><br clear="all" />

## Dziś próbny egzamin ósmoklasisty z języka obcego
 - [https://www.rmf24.pl/fakty/polska/news-dzis-probny-egzamin-osmoklasisty-z-jezyka-obcego,nId,7868655](https://www.rmf24.pl/fakty/polska/news-dzis-probny-egzamin-osmoklasisty-z-jezyka-obcego,nId,7868655)
 - RSS feed: $source
 - date published: 2024-12-04T05:48:03.810407+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-dzis-probny-egzamin-osmoklasisty-z-jezyka-obcego,nId,7868655"><img src="https://interia-s.pluscdn.pl/dzis-probny-egzamin-osmoklasisty-z-jezyka-obcego/000K81PHJSB9ANF7-C307.jpg" alt="Dziś próbny egzamin ósmoklasisty z języka obcego" align="left" /></a>Trzeciego dnia próbnych egzaminów ósmoklasisty uczniowie zmierzą się z językiem obcym. Na RMF24.pl opublikujemy arkusze egzaminacyjne, udostępnione przez CKE.</p><br clear="all" />

## Ciała dzieci zakopane na podwórku. Rodzice należą do sekty
 - [https://www.rmf24.pl/fakty/swiat/news-chorwacja-ciala-dzieci-zakopane-na-podworku-rodzice-naleza-d,nId,7868713](https://www.rmf24.pl/fakty/swiat/news-chorwacja-ciala-dzieci-zakopane-na-podworku-rodzice-naleza-d,nId,7868713)
 - RSS feed: $source
 - date published: 2024-12-04T05:40:29+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-chorwacja-ciala-dzieci-zakopane-na-podworku-rodzice-naleza-d,nId,7868713"><img src="https://interia-s.pluscdn.pl/ciala-dzieci-zakopane-na-podworku-rodzice-naleza-do-sekty/000K82K398EDM2EV-C307.jpg" alt="Ciała dzieci zakopane na podwórku. Rodzice należą do sekty" align="left" /></a>Makabryczne odkrycie w okolicy położonego na północy Chorwacji Varażdina. Odnaleziono ciała dwójki dzieci, które zakopano na podwórku jednego z wiejskich domów. Policja zatrzymała rodziców. Podejrzewa ich o &quot;poważne zaniedbania&quot;, które doprowadziły do śmierci dzieci - wynika z komunikatu chorwackich służb.</p><br clear="all" />

## "Akt rebelii". Prezydent Korei Płd. w ogniu krytyki po próbie wprowadzenia stanu wojennego
 - [https://www.rmf24.pl/fakty/swiat/news-akt-rebelii-prezydent-korei-pld-w-ogniu-krytyki-po-probie-wp,nId,7868711](https://www.rmf24.pl/fakty/swiat/news-akt-rebelii-prezydent-korei-pld-w-ogniu-krytyki-po-probie-wp,nId,7868711)
 - RSS feed: $source
 - date published: 2024-12-04T04:43:08.279542+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-akt-rebelii-prezydent-korei-pld-w-ogniu-krytyki-po-probie-wp,nId,7868711"><img src="https://interia-s.pluscdn.pl/akt-rebelii-prezydent-korei-pld-w-ogniu-krytyki-po-probie-wp/000K82JOLQV9MD0U-C307.jpg" alt="&quot;Akt rebelii&quot;. Prezydent Korei Płd. w ogniu krytyki po próbie wprowadzenia stanu wojennego" align="left" /></a>Prezydent Korei Południowej Jun Suk Jeol znalazł się w ogniu krytyki po ogłoszeniu, a następnie zniesieniu stanu wojennego. Opozycja wzywa do jego dymisji i grozi impeachmentem, a związki zawodowe zapowiadają strajki, dopóki prezydent nie ustąpi – podały media.</p><br clear="all" />

## ​Wisła Kraków nie obroni Pucharu Polski. Dramatyczny mecz w Warszawie
 - [https://www.rmf24.pl/sport/news-wisla-krakow-nie-obroni-pucharu-polski-dramatyczny-mecz-w-wa,nId,7868705](https://www.rmf24.pl/sport/news-wisla-krakow-nie-obroni-pucharu-polski-dramatyczny-mecz-w-wa,nId,7868705)
 - RSS feed: $source
 - date published: 2024-12-04T00:16:57+00:00

<p><a href="https://www.rmf24.pl/sport/news-wisla-krakow-nie-obroni-pucharu-polski-dramatyczny-mecz-w-wa,nId,7868705"><img src="https://interia-s.pluscdn.pl/wisla-krakow-nie-obroni-pucharu-polski-dramatyczny-mecz-w-wa/000K82DWCG9Y2DPI-C307.jpg" alt="​Wisła Kraków nie obroni Pucharu Polski. Dramatyczny mecz w Warszawie" align="left" /></a>Broniąca trofeum pierwszoligowa Wisła Kraków, choć prowadziła 2:0, uległa po dramatycznej dogrywce Polonii Warszawa 2:3 i odpadła w w 1/8 finału piłkarskiego Pucharu Polski. We wtorek do ćwierćfinału awansowały też Puszcza Niepołomice i Piast Gliwice z ekstraklasy.</p><br clear="all" />

