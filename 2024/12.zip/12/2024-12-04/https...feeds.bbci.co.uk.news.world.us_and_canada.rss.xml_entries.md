# Source:BBC US Canada News, URL:https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml, language:en-gb

## Multiple victims reported in Vancouver stabbing 
 - [https://www.bbc.com/news/articles/cq624628gj5o](https://www.bbc.com/news/articles/cq624628gj5o)
 - RSS feed: $source
 - date published: 2024-12-04T21:28:42+00:00

The condition of the victims and the suspect, who was shot by police, remains unclear. 

## Watch: How the NYC shooting of UnitedHealthcare CEO unfolded
 - [https://www.bbc.com/news/videos/cgj643ndlj0o](https://www.bbc.com/news/videos/cgj643ndlj0o)
 - RSS feed: $source
 - date published: 2024-12-04T21:16:13+00:00

Police say Brian Thompson was targeted outside the Hilton Hotel in Midtown Manhattan.

## Supreme Court reluctant to overturn Tennessee transgender law
 - [https://www.bbc.com/news/articles/c3wepv7jyvdo](https://www.bbc.com/news/articles/c3wepv7jyvdo)
 - RSS feed: $source
 - date published: 2024-12-04T19:42:34+00:00

Its ruling on the ban of hormone and puberty treatment for minors will affect more than half the states.

## World's oldest known wild bird lays egg at 74
 - [https://www.bbc.com/news/articles/c86w9n4jlvwo](https://www.bbc.com/news/articles/c86w9n4jlvwo)
 - RSS feed: $source
 - date published: 2024-12-04T16:26:23+00:00

Laysan albatross Wisdom was spotted with her new partner and egg at a Pacific Ocean refuge.

## Slim majority for Republicans after Democrats flip final House seat
 - [https://www.bbc.com/news/articles/cwyder59wn9o](https://www.bbc.com/news/articles/cwyder59wn9o)
 - RSS feed: $source
 - date published: 2024-12-04T16:07:40+00:00

The narrow majority leaves Republicans with even less margin for error as they try to enact President-elect Trump’s agenda.

## Eminem's mother, Debbie Nelson, dies aged 69
 - [https://www.bbc.com/news/articles/c4gl05n8r0zo](https://www.bbc.com/news/articles/c4gl05n8r0zo)
 - RSS feed: $source
 - date published: 2024-12-04T07:48:39+00:00

The rapper's difficult relationship with his mother was reflected in much of his earlier music.

## Trump may replace Hegseth for defence post with Florida governor: reports
 - [https://www.bbc.com/news/articles/cr564zd43l9o](https://www.bbc.com/news/articles/cr564zd43l9o)
 - RSS feed: $source
 - date published: 2024-12-04T05:33:03+00:00

Since Trump nominated Hegseth for the post, an allegation of sexual assault has surfaced along with concerns about h

## The awkward parallels between the Biden and Trump convictions
 - [https://www.bbc.com/news/articles/cvgrw92zr9ko](https://www.bbc.com/news/articles/cvgrw92zr9ko)
 - RSS feed: $source
 - date published: 2024-12-04T01:29:14+00:00

Joe Biden's criticism of a politicised justice system echoes sentiments regularly used by Donald Trump.

## Search on for woman believed trapped in sinkhole after going looking for cat
 - [https://www.bbc.com/news/articles/cp3z9e64zd9o](https://www.bbc.com/news/articles/cp3z9e64zd9o)
 - RSS feed: $source
 - date published: 2024-12-04T00:42:22+00:00

Elizabeth Pollard was searching for her missing cat when it is thought she fell into the sink hole, police say.

