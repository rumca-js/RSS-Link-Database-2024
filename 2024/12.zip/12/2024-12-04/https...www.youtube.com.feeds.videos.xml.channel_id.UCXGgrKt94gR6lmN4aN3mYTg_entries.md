# Source:Austin Evans, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg, language:en-US

## This Spotify Wrapped Feature is AWESOME
 - [https://www.youtube.com/watch?v=nBlrZzoQc94](https://www.youtube.com/watch?v=nBlrZzoQc94)
 - RSS feed: $source
 - date published: 2024-12-04T21:44:00+00:00

None

## Is Gaming on Mac FINALLY Good?
 - [https://www.youtube.com/watch?v=t6VXciGdZO4](https://www.youtube.com/watch?v=t6VXciGdZO4)
 - RSS feed: $source
 - date published: 2024-12-04T16:21:24+00:00

Subscribe for more! https://www.youtube.com/austinevans
TikTok: https://www.tiktok.com/@austintechtips
Instagram: https://instagram.com/austinnotduncan
Threads: https://www.threads.net/@austinnotduncan

I put Apple's new M4 Mac mini head-to-head against the PS5 in a blind gaming test and the results were surprising. Through side-by-side comparisons of Resident Evil and Death Stranding, we discovered that while the PS5 still holds the crown, the $600 Mac mini comes surprisingly close. Don't call it a gaming revolution yet, but Apple might finally be onto something here.

Chapter Titles:
0:00 Blind Test
5:48 Austin Test
8:42 Is M4 Mac Mini Worth It?
10:21 Gaming on Mac

