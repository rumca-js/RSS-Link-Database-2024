# Source:Tabletop Gaming News – TGN, URL:https://www.tabletopgamingnews.com/feed, language:en-US

## Roll 4 Ruins Brings Strategic Solo Dungeon Crawling to Kickstarter
 - [https://www.tabletopgamingnews.com/roll-4-ruins-brings-strategic-solo-dungeon-crawling-to-kickstarter/?utm_source=rss&utm_medium=rss&utm_campaign=roll-4-ruins-brings-strategic-solo-dungeon-crawling-to-kickstarter](https://www.tabletopgamingnews.com/roll-4-ruins-brings-strategic-solo-dungeon-crawling-to-kickstarter/?utm_source=rss&utm_medium=rss&utm_campaign=roll-4-ruins-brings-strategic-solo-dungeon-crawling-to-kickstarter)
 - RSS feed: $source
 - date published: 2024-12-04T23:05:49+00:00

Roll 4 Ruins is a print-and-play solo dungeon crawler that blends strategic dice mechanics with immersive dungeon exploration. Designed for players who enjoy a challenge and a DIY approach, the game allows adventurers to assemble their own dungeon experience in minutes. Players step into the role of a daring adventurer, navigating through dungeons filled with...

## Solarian Games and TotalCon Announce the James Carpio Memorial Golden Fez Awards
 - [https://www.tabletopgamingnews.com/solarian-games-and-totalcon-announce-the-james-carpio-memorial-golden-fez-awards/?utm_source=rss&utm_medium=rss&utm_campaign=solarian-games-and-totalcon-announce-the-james-carpio-memorial-golden-fez-awards](https://www.tabletopgamingnews.com/solarian-games-and-totalcon-announce-the-james-carpio-memorial-golden-fez-awards/?utm_source=rss&utm_medium=rss&utm_campaign=solarian-games-and-totalcon-announce-the-james-carpio-memorial-golden-fez-awards)
 - RSS feed: $source
 - date published: 2024-12-04T22:53:49+00:00

Solarian Games and TotalCon have introduced the James Carpio Memorial Golden Fez Awards to honor the memory of James Carpio, co-founder of Solarian Games, who passed away earlier this year. These awards aim to recognize creativity, innovation, and fun in tabletop role-playing games The awards are open to TTRPGs released in 2024, with an exception...

## Osprey Games Announces Ofrenda, Inspired by Día de los Muertos
 - [https://www.tabletopgamingnews.com/osprey-games-announces-ofrenda-inspired-by-dia-de-los-muertos/?utm_source=rss&utm_medium=rss&utm_campaign=osprey-games-announces-ofrenda-inspired-by-dia-de-los-muertos](https://www.tabletopgamingnews.com/osprey-games-announces-ofrenda-inspired-by-dia-de-los-muertos/?utm_source=rss&utm_medium=rss&utm_campaign=osprey-games-announces-ofrenda-inspired-by-dia-de-los-muertos)
 - RSS feed: $source
 - date published: 2024-12-04T22:38:53+00:00

Osprey Games has announced Ofrenda, a new card-placement game designed by Orlando Sá and André Santos, with artwork by Alex Herrerías. The game is rooted in the traditions of Día de los Muertos, offering players an opportunity to create vibrant altars in remembrance of loved ones. In the game, players work to assemble an ofrenda,...

## New Humblewood Releases by Hitpoint Press
 - [https://www.tabletopgamingnews.com/new-humblewood-releases-by-hitpoint-press/?utm_source=rss&utm_medium=rss&utm_campaign=new-humblewood-releases-by-hitpoint-press](https://www.tabletopgamingnews.com/new-humblewood-releases-by-hitpoint-press/?utm_source=rss&utm_medium=rss&utm_campaign=new-humblewood-releases-by-hitpoint-press)
 - RSS feed: $source
 - date published: 2024-12-04T22:35:06+00:00

Hitpoint Press has announced the release of two new additions to the Humblewood setting. Humblewood Tales and Humblewood: For Want of a Nail are now available, offering new ways for players and game masters to explore the world of Alderheart. Humblewood Tales is a comprehensive sourcebook that expands on the lore and locations of the...

