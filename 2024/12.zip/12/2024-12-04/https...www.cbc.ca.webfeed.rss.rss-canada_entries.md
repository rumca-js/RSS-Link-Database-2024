# Source:CBC | Canada News, URL:https://www.cbc.ca/webfeed/rss/rss-canada, language:en

## These 2 Quebecers are now the most wanted men in Canada
 - [https://www.cbc.ca/news/canada/montreal/dave-pik-turmel-all-boivin-most-wanted-quebec-canada-1.7400973?cmp=rss](https://www.cbc.ca/news/canada/montreal/dave-pik-turmel-all-boivin-most-wanted-quebec-canada-1.7400973?cmp=rss)
 - RSS feed: $source
 - date published: 2024-12-04T13:33:32+00:00

<img src='https://i.cbc.ca/1.7401021.1733335762!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/cda-most-wanted-20241204.jpg' alt='man sitting in front of group of life-size cutouts. ' width='620' height='349' title='Maxime Langlois, director of the Bolo program speaks at a press conference to release the latest Top 25 list of Canada&apos;s Most Wanted fugitives in Montreal, Wednesday, Dec. 4, 2024.'/><p>The alleged leader of a notorious street gang that is involved in brutal turf wars in Quebec during which victims have been tortured and have had their limbs amputated is the most wanted fugitive in Canada.</p>

## Dollarama buys land for Calgary warehouse, targets 2,200 Canadian stores by 2034
 - [https://www.cbc.ca/news/canada/calgary/dollarama-buys-land-for-calgary-warehouse-targets-2-200-canadian-stores-by-2034-1.7400895?cmp=rss](https://www.cbc.ca/news/canada/calgary/dollarama-buys-land-for-calgary-warehouse-targets-2-200-canadian-stores-by-2034-1.7400895?cmp=rss)
 - RSS feed: $source
 - date published: 2024-12-04T12:20:31+00:00

<img src='https://i.cbc.ca/1.5277687.1733340161!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/dollarama-at-yonge-and-wellesley-in-toronto.jpg' alt='A Dollarama sign outside one of the chain&apos;s locations in Toronto is shown.' width='620' height='349' title='Dollarama at Yonge and Wellesley in Toronto.'/><p>A new Dollarama distribution centre and a lot more of the chain's stores are headed for Canada over the next decade.</p>

## Measles outbreak in N.B. renews interest in national vaccination registry
 - [https://www.cbc.ca/news/canada/new-brunswick/measles-outbreak-new-brunswick-national-vaccination-registry-1.7398752?cmp=rss](https://www.cbc.ca/news/canada/new-brunswick/measles-outbreak-new-brunswick-national-vaccination-registry-1.7398752?cmp=rss)
 - RSS feed: $source
 - date published: 2024-12-04T05:00:00+00:00

<img src='https://i.cbc.ca/1.5120934.1733232929!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/usa-measles-states.jpg' alt='A vial of the measles, mumps, and rubella virus (MMR) vaccine is pictured at the International Community Health Services clinic in Seattle, Washington, U.S., March 20, 2019.  ' width='620' height='349' title='FILE PHOTO: FILE PHOTO: FILE PHOTO: A vial of the measles, mumps, and rubella virus (MMR) vaccine is pictured at the International Community Health Services clinic in Seattle, Washington, U.S., March 20, 2019.  '/><p>A measles outbreak in New Brunswick and surge of cases across Canada has renewed calls for a national vaccination registry.</p>

