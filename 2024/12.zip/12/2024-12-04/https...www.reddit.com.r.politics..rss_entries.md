# Source:Reddit - Politics, URL:https://www.reddit.com/r/politics/.rss, language:en-US

## Biden White House Is Discussing Preemptive Pardons for Those in Trump’s Crosshairs
 - [https://www.reddit.com/r/politics/comments/1h6ryrf/biden_white_house_is_discussing_preemptive](https://www.reddit.com/r/politics/comments/1h6ryrf/biden_white_house_is_discussing_preemptive)
 - RSS feed: $source
 - date published: 2024-12-04T21:37:49+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/codyave"> /u/codyave </a> <br/> <span><a href="https://www.politico.com/news/magazine/2024/12/04/biden-white-house-pardons-00192610">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6ryrf/biden_white_house_is_discussing_preemptive/">[comments]</a></span>

## Hegseth Is Reportedly Vowing to Stop Drinking, Having His Mom Call Senators
 - [https://www.reddit.com/r/politics/comments/1h6rj80/hegseth_is_reportedly_vowing_to_stop_drinking](https://www.reddit.com/r/politics/comments/1h6rj80/hegseth_is_reportedly_vowing_to_stop_drinking)
 - RSS feed: $source
 - date published: 2024-12-04T21:20:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6rj80/hegseth_is_reportedly_vowing_to_stop_drinking/"> <img src="https://external-preview.redd.it/QQLVd2LH_gsSBCbUdKHvt2Tpy9NYeajyuDsTqhLHNX0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5ad34425a22351160c453c53c8e59877476ab6ab" alt="Hegseth Is Reportedly Vowing to Stop Drinking, Having His Mom Call Senators" title="Hegseth Is Reportedly Vowing to Stop Drinking, Having His Mom Call Senators" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rollingstone"> /u/rollingstone </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-news/pete-hegseth-vowing-stop-drinking-mom-call-senators-1235192656/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6rj80/hegseth_is_reportedly_vowing_to_stop_drinking/">[comments]</a></span> </td></tr></table>

## Trump Defense Nominee Asks Mom to Call Senators for Him in Effort to Land Job: Report
 - [https://www.reddit.com/r/politics/comments/1h6r36h/trump_defense_nominee_asks_mom_to_call_senators](https://www.reddit.com/r/politics/comments/1h6r36h/trump_defense_nominee_asks_mom_to_call_senators)
 - RSS feed: $source
 - date published: 2024-12-04T21:02:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6r36h/trump_defense_nominee_asks_mom_to_call_senators/"> <img src="https://external-preview.redd.it/hN_4Iqvq4UNBXr1CVKlYmgyFO4LaIvyxXCx9xg2G1k4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fe982af1503a6e5fc355e6cd68d52d1f6c6b6aa6" alt="Trump Defense Nominee Asks Mom to Call Senators for Him in Effort to Land Job: Report" title="Trump Defense Nominee Asks Mom to Call Senators for Him in Effort to Land Job: Report" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PostHeraldTimes"> /u/PostHeraldTimes </a> <br/> <span><a href="https://www.ibtimes.com/trump-defense-nominee-asks-mom-call-senators-him-effort-land-job-report-3754018">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6r36h/trump_defense_nominee_asks_mom_to_call_senators/">[comments]</a></span> </td></tr></table>

## RFK Jr. was paid six figures by his vaccine-challenging group before presidential run
 - [https://www.reddit.com/r/politics/comments/1h6pjjk/rfk_jr_was_paid_six_figures_by_his](https://www.reddit.com/r/politics/comments/1h6pjjk/rfk_jr_was_paid_six_figures_by_his)
 - RSS feed: $source
 - date published: 2024-12-04T19:59:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6pjjk/rfk_jr_was_paid_six_figures_by_his/"> <img src="https://external-preview.redd.it/gXHF6iL4ZJHCekgyjySz2bDIYKpIBu5feYmPeK271hg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8875ed96e87e794507ebf7b7554689918a53b5c2" alt="RFK Jr. was paid six figures by his vaccine-challenging group before presidential run" title="RFK Jr. was paid six figures by his vaccine-challenging group before presidential run" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/indig0sixalpha"> /u/indig0sixalpha </a> <br/> <span><a href="https://www.statnews.com/2024/12/03/rfk-jr-maha-pay-vaccine-group-childrens-health-defense/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6pjjk/rfk_jr_was_paid_six_figures_by_his/">[comments]</a></span> </td></tr></table>

## Tennessee State Sen. Ken Yager arrested, charged with DUI, hit and run in Georgia on Tuesday
 - [https://www.reddit.com/r/politics/comments/1h6ng9h/tennessee_state_sen_ken_yager_arrested_charged](https://www.reddit.com/r/politics/comments/1h6ng9h/tennessee_state_sen_ken_yager_arrested_charged)
 - RSS feed: $source
 - date published: 2024-12-04T18:35:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6ng9h/tennessee_state_sen_ken_yager_arrested_charged/"> <img src="https://external-preview.redd.it/MPX34VEJ041nX3kN0KOAsqjGK15Cc7ttJ9INxHbveto.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=40ded5cb2f7d0b06f35fa8a978575c818df1735a" alt="Tennessee State Sen. Ken Yager arrested, charged with DUI, hit and run in Georgia on Tuesday" title="Tennessee State Sen. Ken Yager arrested, charged with DUI, hit and run in Georgia on Tuesday" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LurkmasterGeneral"> /u/LurkmasterGeneral </a> <br/> <span><a href="https://www.tennessean.com/story/news/politics/2024/12/04/tennessee-senate-ken-yager-arrested-dui-hit-and-run/76764714007/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6ng9h/tennessee_state_sen_ken_yager_arrested_charged/">[comments]</a></span> </td></tr></table>

## Vivek Ramaswamy Secretly Thinks Elon Musk Is in “China’s Pocket” - Resurfaced audio shows Vivek Ramaswamy sang a very different tune about Elon Musk not too long ago.
 - [https://www.reddit.com/r/politics/comments/1h6n9dx/vivek_ramaswamy_secretly_thinks_elon_musk_is_in](https://www.reddit.com/r/politics/comments/1h6n9dx/vivek_ramaswamy_secretly_thinks_elon_musk_is_in)
 - RSS feed: $source
 - date published: 2024-12-04T18:28:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6n9dx/vivek_ramaswamy_secretly_thinks_elon_musk_is_in/"> <img src="https://external-preview.redd.it/BY139bhChJy2sOZ4adeYejQyNEPSrOq3BiTCg1O18Cs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=53256d0a3faacfd94cb97d34dcb6a7d67132a9b2" alt="Vivek Ramaswamy Secretly Thinks Elon Musk Is in “China’s Pocket” - Resurfaced audio shows Vivek Ramaswamy sang a very different tune about Elon Musk not too long ago." title="Vivek Ramaswamy Secretly Thinks Elon Musk Is in “China’s Pocket” - Resurfaced audio shows Vivek Ramaswamy sang a very different tune about Elon Musk not too long ago." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br/> <span><a href="https://newrepublic.com/post/189007/vivek-ramaswamy-elon-musk-china-audio">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6n9dx/vivek_ramaswamy_secretly_thinks_elon_musk_is_in/">[c

## Alexandria Ocasio-Cortez Mulls Bid For Top Oversight Committee Spot
 - [https://www.reddit.com/r/politics/comments/1h6mpvi/alexandria_ocasiocortez_mulls_bid_for_top](https://www.reddit.com/r/politics/comments/1h6mpvi/alexandria_ocasiocortez_mulls_bid_for_top)
 - RSS feed: $source
 - date published: 2024-12-04T18:06:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6mpvi/alexandria_ocasiocortez_mulls_bid_for_top/"> <img src="https://external-preview.redd.it/RdQyJMHHHea-VsbvQgq0z9pq06ClBMHZjdl9litjr8o.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7d2d9b3ddb2dbcd8a0109ced5440540adc2af146" alt="Alexandria Ocasio-Cortez Mulls Bid For Top Oversight Committee Spot" title="Alexandria Ocasio-Cortez Mulls Bid For Top Oversight Committee Spot" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/UWCG"> /u/UWCG </a> <br/> <span><a href="https://www.huffpost.com/entry/aoc-oversight-committee-alexandria-ocasio-cortez_n_67507cc9e4b033802ee46cef">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6mpvi/alexandria_ocasiocortez_mulls_bid_for_top/">[comments]</a></span> </td></tr></table>

## South Korea showed Americans how to defend democracy
 - [https://www.reddit.com/r/politics/comments/1h6m37n/south_korea_showed_americans_how_to_defend](https://www.reddit.com/r/politics/comments/1h6m37n/south_korea_showed_americans_how_to_defend)
 - RSS feed: $source
 - date published: 2024-12-04T17:42:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6m37n/south_korea_showed_americans_how_to_defend/"> <img src="https://external-preview.redd.it/KhKQ_cM4uF58nLgZpqBOlGOnR4qZR5Vy9ciTR3ImShU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c6c9068ea9ad0b3bab9b3f4fee5a395b57cd8774" alt="South Korea showed Americans how to defend democracy" title="South Korea showed Americans how to defend democracy" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/msnbc"> /u/msnbc </a> <br/> <span><a href="https://www.msnbc.com/opinion/msnbc-opinion/south-korea-martial-law-president-democracy-trump-rcna182732">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6m37n/south_korea_showed_americans_how_to_defend/">[comments]</a></span> </td></tr></table>

## Marjorie Taylor Greene Wants A ‘Blanket Pardon’ And Everyone Has The Same Question
 - [https://www.reddit.com/r/politics/comments/1h6lmbh/marjorie_taylor_greene_wants_a_blanket_pardon_and](https://www.reddit.com/r/politics/comments/1h6lmbh/marjorie_taylor_greene_wants_a_blanket_pardon_and)
 - RSS feed: $source
 - date published: 2024-12-04T17:24:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6lmbh/marjorie_taylor_greene_wants_a_blanket_pardon_and/"> <img src="https://external-preview.redd.it/7S_hg8fIXbtetwzTZwzTvUJN9uFUaWsvQiGIlCNPLoU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2a58213899a90cd6b6ff9f27e984a8302af47174" alt="Marjorie Taylor Greene Wants A ‘Blanket Pardon’ And Everyone Has The Same Question" title="Marjorie Taylor Greene Wants A ‘Blanket Pardon’ And Everyone Has The Same Question" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mmccxi"> /u/mmccxi </a> <br/> <span><a href="https://www.huffpost.com/entry/marjorie-taylor-greene-blanket-pardon_n_675019b0e4b07209ad74584c">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6lmbh/marjorie_taylor_greene_wants_a_blanket_pardon_and/">[comments]</a></span> </td></tr></table>

## OpenAI CEO Sam Altman says it’d be ‘un-American’ for Elon Musk to wield political influence to harm rivals
 - [https://www.reddit.com/r/politics/comments/1h6llzi/openai_ceo_sam_altman_says_itd_be_unamerican_for](https://www.reddit.com/r/politics/comments/1h6llzi/openai_ceo_sam_altman_says_itd_be_unamerican_for)
 - RSS feed: $source
 - date published: 2024-12-04T17:23:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6llzi/openai_ceo_sam_altman_says_itd_be_unamerican_for/"> <img src="https://external-preview.redd.it/G_zWHWGLYuIjDA67wcUjEaXlz9gXEupSovZwjTJfkWU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b4a09bff520fb81efe0374055d5a6553c6e24298" alt="OpenAI CEO Sam Altman says it’d be ‘un-American’ for Elon Musk to wield political influence to harm rivals" title="OpenAI CEO Sam Altman says it’d be ‘un-American’ for Elon Musk to wield political influence to harm rivals" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/indig0sixalpha"> /u/indig0sixalpha </a> <br/> <span><a href="https://techcrunch.com/2024/12/04/openai-ceo-sam-altman-says-itd-be-un-american-for-elon-musk-to-wield-political-influence-to-harm-rivals/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6llzi/openai_ceo_sam_altman_says_itd_be_unamerican_for/">[comments]</a></span> </td></tr></table>

## Trump picks Peter Navarro, who went to prison for defying Jan. 6 committee subpoena, as top trade adviser
 - [https://www.reddit.com/r/politics/comments/1h6lih7/trump_picks_peter_navarro_who_went_to_prison_for](https://www.reddit.com/r/politics/comments/1h6lih7/trump_picks_peter_navarro_who_went_to_prison_for)
 - RSS feed: $source
 - date published: 2024-12-04T17:19:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6lih7/trump_picks_peter_navarro_who_went_to_prison_for/"> <img src="https://external-preview.redd.it/HlU-ujysvofj0Kg8LEYP6-7ug97zA5PWNFr0B9El9X4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5724b4776eade57bc0ae9e9001d099dc31687d0c" alt="Trump picks Peter Navarro, who went to prison for defying Jan. 6 committee subpoena, as top trade adviser" title="Trump picks Peter Navarro, who went to prison for defying Jan. 6 committee subpoena, as top trade adviser" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nbcnews"> /u/nbcnews </a> <br/> <span><a href="https://www.nbcnews.com/politics/donald-trump/trump-picks-peter-navarro-went-prison-defying-jan-6-committee-subpoena-rcna182843">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6lih7/trump_picks_peter_navarro_who_went_to_prison_for/">[comments]</a></span> </td></tr></table>

## AOC mulls run to be top Democrat on the House Oversight Committee | The progressive lawmaker is one of many younger members challenging more senior colleagues for top committee roles
 - [https://www.reddit.com/r/politics/comments/1h6ksik/aoc_mulls_run_to_be_top_democrat_on_the_house](https://www.reddit.com/r/politics/comments/1h6ksik/aoc_mulls_run_to_be_top_democrat_on_the_house)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6ksik/aoc_mulls_run_to_be_top_democrat_on_the_house/"> <img src="https://external-preview.redd.it/YuUDyPnJSk7ks5j0bgYf08f8B0tzcvts3eDReKcHFLg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1b03ea97f60fb08f30724b081aebfdb0a71bd6b1" alt="AOC mulls run to be top Democrat on the House Oversight Committee | The progressive lawmaker is one of many younger members challenging more senior colleagues for top committee roles" title="AOC mulls run to be top Democrat on the House Oversight Committee | The progressive lawmaker is one of many younger members challenging more senior colleagues for top committee roles" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murky-Site7468"> /u/Murky-Site7468 </a> <br/> <span><a href="https://www.salon.com/2024/12/04/aoc-mulls-run-to-be-top-democrat-on-the-oversight-committee/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comme

## Trump Picks Billionaire Jared Isaacman as NASA Administrator
 - [https://www.reddit.com/r/politics/comments/1h6kq3d/trump_picks_billionaire_jared_isaacman_as_nasa](https://www.reddit.com/r/politics/comments/1h6kq3d/trump_picks_billionaire_jared_isaacman_as_nasa)
 - RSS feed: $source
 - date published: 2024-12-04T16:48:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6kq3d/trump_picks_billionaire_jared_isaacman_as_nasa/"> <img src="https://external-preview.redd.it/DTCteTVxwtgmuDCmJzcvJ_xLRZ3ThJTEwW2oJwyq-Dk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=db7b5bbf232302be6dfeb78b5b4157f0b8b0e09d" alt="Trump Picks Billionaire Jared Isaacman as NASA Administrator" title="Trump Picks Billionaire Jared Isaacman as NASA Administrator" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DomesticErrorist22"> /u/DomesticErrorist22 </a> <br/> <span><a href="https://www.bloomberg.com/news/articles/2024-12-04/trump-picks-jared-isaacman-as-nasa-administrator">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6kq3d/trump_picks_billionaire_jared_isaacman_as_nasa/">[comments]</a></span> </td></tr></table>

## FTC called to investigate Dr. Oz
 - [https://www.reddit.com/r/politics/comments/1h6kokb/ftc_called_to_investigate_dr_oz](https://www.reddit.com/r/politics/comments/1h6kokb/ftc_called_to_investigate_dr_oz)
 - RSS feed: $source
 - date published: 2024-12-04T16:47:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6kokb/ftc_called_to_investigate_dr_oz/"> <img src="https://external-preview.redd.it/Wz590oLr8Czn7phV58RhWAxsjynqQUq-oajSGCbR-Qc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f8894051b7006d2f6cbe9f559325c2274e421a70" alt="FTC called to investigate Dr. Oz" title="FTC called to investigate Dr. Oz" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IntlDogOfMystery"> /u/IntlDogOfMystery </a> <br/> <span><a href="https://www.newsweek.com/ftc-called-investigate-dr-oz-1995333">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6kokb/ftc_called_to_investigate_dr_oz/">[comments]</a></span> </td></tr></table>

## Ramaswamy Once Called DOGE Partner Elon Musk a ‘Circus Monkey’ for China
 - [https://www.reddit.com/r/politics/comments/1h6jfgj/ramaswamy_once_called_doge_partner_elon_musk_a](https://www.reddit.com/r/politics/comments/1h6jfgj/ramaswamy_once_called_doge_partner_elon_musk_a)
 - RSS feed: $source
 - date published: 2024-12-04T15:57:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6jfgj/ramaswamy_once_called_doge_partner_elon_musk_a/"> <img src="https://external-preview.redd.it/74Vu2i3R-5spNwRR2lFulO7kuGghJy3fXZtN67as4QI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d757fe14651dc50714572d4dee4c4c257a77d798" alt="Ramaswamy Once Called DOGE Partner Elon Musk a ‘Circus Monkey’ for China" title="Ramaswamy Once Called DOGE Partner Elon Musk a ‘Circus Monkey’ for China" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rollingstone"> /u/rollingstone </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-news/ramaswamy-elon-musk-china-circus-monkey-doge-1235191737/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6jfgj/ramaswamy_once_called_doge_partner_elon_musk_a/">[comments]</a></span> </td></tr></table>

## Donald Trump is ready to make Republicans touch the third rail Without a voting public to face again, Trump is gearing up to cut Social Security and Medicare
 - [https://www.reddit.com/r/politics/comments/1h6iv85/donald_trump_is_ready_to_make_republicans_touch](https://www.reddit.com/r/politics/comments/1h6iv85/donald_trump_is_ready_to_make_republicans_touch)
 - RSS feed: $source
 - date published: 2024-12-04T15:34:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6iv85/donald_trump_is_ready_to_make_republicans_touch/"> <img src="https://external-preview.redd.it/B11EWqQaGNz2CTXeH8dejsN7RzSiS1GS9azghDoZ-qM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9b6a192e7c9772a329c80a2446a254cfdb3b9b59" alt="Donald Trump is ready to make Republicans touch the third rail Without a voting public to face again, Trump is gearing up to cut Social Security and Medicare" title="Donald Trump is ready to make Republicans touch the third rail Without a voting public to face again, Trump is gearing up to cut Social Security and Medicare" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/prohb"> /u/prohb </a> <br/> <span><a href="https://www.salon.com/2024/12/04/donald-is-ready-to-make-touch-the-third-rail/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6iv85/donald_trump_is_ready_to_make_republicans_touch/">[comments]</a></spa

## Number of Indictments and Convictions of Biden White House Appointees: Zero
 - [https://www.reddit.com/r/politics/comments/1h6hdgg/number_of_indictments_and_convictions_of_biden](https://www.reddit.com/r/politics/comments/1h6hdgg/number_of_indictments_and_convictions_of_biden)
 - RSS feed: $source
 - date published: 2024-12-04T14:31:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6hdgg/number_of_indictments_and_convictions_of_biden/"> <img src="https://external-preview.redd.it/SsRlf0eT7q76GwWaFU-GNSDz8BMpVrWRma_7qbtReyc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=720dad354adc7e14183a8156871cd3956c5064c6" alt="Number of Indictments and Convictions of Biden White House Appointees: Zero" title="Number of Indictments and Convictions of Biden White House Appointees: Zero" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/harsh2k5"> /u/harsh2k5 </a> <br/> <span><a href="https://washingtonmonthly.com/2024/12/03/number-of-indictments-and-convictions-of-biden-white-house-appointees-zero/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6hdgg/number_of_indictments_and_convictions_of_biden/">[comments]</a></span> </td></tr></table>

## Mayor Adams says undocumented New Yorkers aren’t owed due process, defying Constitution
 - [https://www.reddit.com/r/politics/comments/1h6h22h/mayor_adams_says_undocumented_new_yorkers_arent](https://www.reddit.com/r/politics/comments/1h6h22h/mayor_adams_says_undocumented_new_yorkers_arent)
 - RSS feed: $source
 - date published: 2024-12-04T14:17:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6h22h/mayor_adams_says_undocumented_new_yorkers_arent/"> <img src="https://external-preview.redd.it/CfWhhGHgankbKvOUoeUxvJ-YNqT0YmopxXUnSCQbKHA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f641d030efede927cb11f79999b8e90f16f97613" alt="Mayor Adams says undocumented New Yorkers aren’t owed due process, defying Constitution" title="Mayor Adams says undocumented New Yorkers aren’t owed due process, defying Constitution" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GothamistWNYC"> /u/GothamistWNYC </a> <br/> <span><a href="https://gothamist.com/news/mayor-adams-says-undocumented-new-yorkers-arent-owed-due-process-defying-constitution">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6h22h/mayor_adams_says_undocumented_new_yorkers_arent/">[comments]</a></span> </td></tr></table>

## Discussion Thread: US Supreme Court Hears Oral Argument in United States v. Skrmetti, a Case on Whether a Ban on the Medical Treatment of Transgender Minors Violates the 14th Amendment's Equal Protection Clause
 - [https://www.reddit.com/r/politics/comments/1h6gmt3/discussion_thread_us_supreme_court_hears_oral](https://www.reddit.com/r/politics/comments/1h6gmt3/discussion_thread_us_supreme_court_hears_oral)
 - RSS feed: $source
 - date published: 2024-12-04T13:59:24+00:00

<!-- SC_OFF --><div class="md"><p>Oral argument is scheduled to begin at 10 a.m. Eastern.</p> <p><strong>News and Analysis</strong></p> <ul> <li><p>SCOTUSblog: <a href="https://www.scotusblog.com/2024/12/supreme-court-to-hear-challenge-to-ban-on-transgender-health-care-for-minors/">Supreme Court to hear challenge to ban on transgender health care for minors</a></p></li> <li><p>AP: <a href="https://apnews.com/article/supreme-court-genderaffirming-care-minors-tennessee-trump-a6b408e7531ec4ac4826ce692e381cfb">Chase Strangio, first transgender attorney to argue before the Supreme Court, challenging health care ban for minors</a></p></li> </ul> <p><strong>Primary Source</strong></p> <ul> <li>An <a href="/r/politics">r/politics</a> AMA with one of the lawyers who will be arguing before the court today: <a href="https://www.reddit.com/r/politics/comments/faw44s/i_am_aclu_attorney_and_trans_activist_chase/">I am ACLU attorney and trans activist Chase Strangio, AMA.</a></li> </ul> <p><strong>

## Trump's pick for FBI director promoted bogus supplements to 'reverse' vaccines
 - [https://www.reddit.com/r/politics/comments/1h6g9a3/trumps_pick_for_fbi_director_promoted_bogus](https://www.reddit.com/r/politics/comments/1h6g9a3/trumps_pick_for_fbi_director_promoted_bogus)
 - RSS feed: $source
 - date published: 2024-12-04T13:41:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6g9a3/trumps_pick_for_fbi_director_promoted_bogus/"> <img src="https://external-preview.redd.it/1zm16otrZhe6VFTaXSnnxS1NCZBDzf_I3Xytc9sLBA0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6eda7e895f9c370ecd57f523d1d7bc3c13c514fc" alt="Trump's pick for FBI director promoted bogus supplements to 'reverse' vaccines" title="Trump's pick for FBI director promoted bogus supplements to 'reverse' vaccines" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nbcnews"> /u/nbcnews </a> <br/> <span><a href="https://www.nbcnews.com/health/health-news/trump-fbi-director-kash-patel-vaccine-detox-supplements-rcna182434">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6g9a3/trumps_pick_for_fbi_director_promoted_bogus/">[comments]</a></span> </td></tr></table>

## Court Rules Idaho Can Enforce Ban On Interstate Abortion Travel
 - [https://www.reddit.com/r/politics/comments/1h6g00a/court_rules_idaho_can_enforce_ban_on_interstate](https://www.reddit.com/r/politics/comments/1h6g00a/court_rules_idaho_can_enforce_ban_on_interstate)
 - RSS feed: $source
 - date published: 2024-12-04T13:29:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6g00a/court_rules_idaho_can_enforce_ban_on_interstate/"> <img src="https://external-preview.redd.it/vrBojyZgQn0lv5Nu9EviJzMGU2R0dEq55zR4xLrB1q8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f81e37fc752127ee77019b6ebbf7f175e6c44796" alt="Court Rules Idaho Can Enforce Ban On Interstate Abortion Travel" title="Court Rules Idaho Can Enforce Ban On Interstate Abortion Travel" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SenorBurns"> /u/SenorBurns </a> <br/> <span><a href="https://www.huffpost.com/entry/idaho-court-rules-the-state-can-enforce-ban-on-interstate-abortion-travel_n_674f461de4b04b35d102d125">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6g00a/court_rules_idaho_can_enforce_ban_on_interstate/">[comments]</a></span> </td></tr></table>

## Is Kristi Noem ready to run FEMA? South Dakota flood victims doubt it.
 - [https://www.reddit.com/r/politics/comments/1h6fzjr/is_kristi_noem_ready_to_run_fema_south_dakota](https://www.reddit.com/r/politics/comments/1h6fzjr/is_kristi_noem_ready_to_run_fema_south_dakota)
 - RSS feed: $source
 - date published: 2024-12-04T13:28:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6fzjr/is_kristi_noem_ready_to_run_fema_south_dakota/"> <img src="https://external-preview.redd.it/KRD1OM50nyvXJ0MalKbn7DMETTSfgxwHikgdmNtMrjw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f68467c24c1012e58ce41649f90e5e24abe28770" alt="Is Kristi Noem ready to run FEMA? South Dakota flood victims doubt it." title="Is Kristi Noem ready to run FEMA? South Dakota flood victims doubt it." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sir-Lady-Cat"> /u/Sir-Lady-Cat </a> <br/> <span><a href="https://www.washingtonpost.com/politics/2024/12/04/noem-fema-south-dakota-floods/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6fzjr/is_kristi_noem_ready_to_run_fema_south_dakota/">[comments]</a></span> </td></tr></table>

## Now There's Resurfaced Video Of Pete Hegseth Completely Trashing Trump
 - [https://www.reddit.com/r/politics/comments/1h6elyp/now_theres_resurfaced_video_of_pete_hegseth](https://www.reddit.com/r/politics/comments/1h6elyp/now_theres_resurfaced_video_of_pete_hegseth)
 - RSS feed: $source
 - date published: 2024-12-04T12:15:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6elyp/now_theres_resurfaced_video_of_pete_hegseth/"> <img src="https://external-preview.redd.it/IMKYUUxPR7UdSzEd5CrRQ5zNB2EeW12EP4Q04LwmgP8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0d5b25333c76204bc8869ab2116ce65f27939c69" alt="Now There's Resurfaced Video Of Pete Hegseth Completely Trashing Trump" title="Now There's Resurfaced Video Of Pete Hegseth Completely Trashing Trump" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br/> <span><a href="https://www.huffpost.com/entry/pete-hegseth-donald-trump-armchair-tough-guy-vide_n_67502b49e4b076132d51253a">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6elyp/now_theres_resurfaced_video_of_pete_hegseth/">[comments]</a></span> </td></tr></table>

## Measure to ban trans Montana lawmaker Zooey Zephyr from women's bathroom fails
 - [https://www.reddit.com/r/politics/comments/1h6efz1/measure_to_ban_trans_montana_lawmaker_zooey](https://www.reddit.com/r/politics/comments/1h6efz1/measure_to_ban_trans_montana_lawmaker_zooey)
 - RSS feed: $source
 - date published: 2024-12-04T12:05:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6efz1/measure_to_ban_trans_montana_lawmaker_zooey/"> <img src="https://external-preview.redd.it/kn2PUWXh1kbnKv1WNCQTmOAqBRUASrmSrOEissb5ckg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b80ccc3c7cc1f81e8ea11cf9ed996a7cb4d000e2" alt="Measure to ban trans Montana lawmaker Zooey Zephyr from women's bathroom fails" title="Measure to ban trans Montana lawmaker Zooey Zephyr from women's bathroom fails" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ErinInTheMorning"> /u/ErinInTheMorning </a> <br/> <span><a href="https://www.nbcnews.com/news/amp/rcna182733">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6efz1/measure_to_ban_trans_montana_lawmaker_zooey/">[comments]</a></span> </td></tr></table>

## Elon Musk's Twitter harassment of federal employees shows "DOGE" is weaker than he pretends
 - [https://www.reddit.com/r/politics/comments/1h6do74/elon_musks_twitter_harassment_of_federal](https://www.reddit.com/r/politics/comments/1h6do74/elon_musks_twitter_harassment_of_federal)
 - RSS feed: $source
 - date published: 2024-12-04T11:15:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6do74/elon_musks_twitter_harassment_of_federal/"> <img src="https://external-preview.redd.it/54ZyPbL2lJFxv4IuD3GTr-U5V85PmElt_HhZPuIXZ-g.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=af21eb941bc0ad91642162d763e0a587022d72b3" alt="Elon Musk's Twitter harassment of federal employees shows &quot;DOGE&quot; is weaker than he pretends" title="Elon Musk's Twitter harassment of federal employees shows &quot;DOGE&quot; is weaker than he pretends" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br/> <span><a href="https://www.salon.com/2024/12/04/elon-musks-twitter-harassment-of-employees-shows-doge-is-weaker-than-he-pretends/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6do74/elon_musks_twitter_harassment_of_federal/">[comments]</a></span> </td></tr></table>

## Conquest: Trump posts bizarre AI pic of himself with a Canadian flag (on a Swiss mountain)
 - [https://www.reddit.com/r/politics/comments/1h6a6qa/conquest_trump_posts_bizarre_ai_pic_of_himself](https://www.reddit.com/r/politics/comments/1h6a6qa/conquest_trump_posts_bizarre_ai_pic_of_himself)
 - RSS feed: $source
 - date published: 2024-12-04T06:58:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h6a6qa/conquest_trump_posts_bizarre_ai_pic_of_himself/"> <img src="https://external-preview.redd.it/0oHzWTaXmPmT4aaxoJ1gUKdcAE2z-INc6DW7UAmbwFw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a82c7070dcd64fd766e9272100aca977c482ce78" alt="Conquest: Trump posts bizarre AI pic of himself with a Canadian flag (on a Swiss mountain)" title="Conquest: Trump posts bizarre AI pic of himself with a Canadian flag (on a Swiss mountain)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SandraScottjk4q7"> /u/SandraScottjk4q7 </a> <br/> <span><a href="https://www.independent.co.uk/news/world/americas/us-politics/trump-canada-ai-mountain-tariffs-b2658374.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h6a6qa/conquest_trump_posts_bizarre_ai_pic_of_himself/">[comments]</a></span> </td></tr></table>

## California Democrat Flips Seat in the Last House Race to Be Decided
 - [https://www.reddit.com/r/politics/comments/1h68vep/california_democrat_flips_seat_in_the_last_house](https://www.reddit.com/r/politics/comments/1h68vep/california_democrat_flips_seat_in_the_last_house)
 - RSS feed: $source
 - date published: 2024-12-04T05:34:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h68vep/california_democrat_flips_seat_in_the_last_house/"> <img src="https://external-preview.redd.it/QD0JkWqLLK1Zlynyp0dSwxG0AYxGHqNPzAScZm88cns.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3ecc4f043eba68e411c193505d29ec1cd8dba17e" alt="California Democrat Flips Seat in the Last House Race to Be Decided" title="California Democrat Flips Seat in the Last House Race to Be Decided" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FriskyDingos"> /u/FriskyDingos </a> <br/> <span><a href="https://www.nytimes.com/2024/12/04/us/politics/california-house-gray-duarte.html?smid=nytcore-ios-share&amp;referringSource=articleShare">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h68vep/california_democrat_flips_seat_in_the_last_house/">[comments]</a></span> </td></tr></table>

## Elon Musk’s Real Plan Is Starting to Appear: gutting Social Security and Medicare.
 - [https://www.reddit.com/r/politics/comments/1h66ncb/elon_musks_real_plan_is_starting_to_appear](https://www.reddit.com/r/politics/comments/1h66ncb/elon_musks_real_plan_is_starting_to_appear)
 - RSS feed: $source
 - date published: 2024-12-04T03:30:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h66ncb/elon_musks_real_plan_is_starting_to_appear/"> <img src="https://external-preview.redd.it/DimniwG5Bvrlj1f8YvZo1ck6JxDXBkDeawbM4PHBLfk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=87ae499a36ced1b74b9133708f9483b9869d638a" alt="Elon Musk’s Real Plan Is Starting to Appear: gutting Social Security and Medicare." title="Elon Musk’s Real Plan Is Starting to Appear: gutting Social Security and Medicare." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SandraScottjk4q7"> /u/SandraScottjk4q7 </a> <br/> <span><a href="https://newrepublic.com/post/188989/elon-musk-republican-party-senator-mike-lee-gut-social-security">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h66ncb/elon_musks_real_plan_is_starting_to_appear/">[comments]</a></span> </td></tr></table>

## Trump Mulls Replacing Pete Hegseth With Florida Gov. Ron DeSantis
 - [https://www.reddit.com/r/politics/comments/1h662av/trump_mulls_replacing_pete_hegseth_with_florida](https://www.reddit.com/r/politics/comments/1h662av/trump_mulls_replacing_pete_hegseth_with_florida)
 - RSS feed: $source
 - date published: 2024-12-04T03:01:37+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DomesticErrorist22"> /u/DomesticErrorist22 </a> <br/> <span><a href="https://www.wsj.com/politics/elections/trump-mulls-replacing-pete-hegseth-with-florida-gov-ron-desantis-8f682ad2?st=j7aVTM">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h662av/trump_mulls_replacing_pete_hegseth_with_florida/">[comments]</a></span>

## Democrat Adam Gray declares victory over Republican John Duarte in close congressional rematch
 - [https://www.reddit.com/r/politics/comments/1h65ee9/democrat_adam_gray_declares_victory_over](https://www.reddit.com/r/politics/comments/1h65ee9/democrat_adam_gray_declares_victory_over)
 - RSS feed: $source
 - date published: 2024-12-04T02:27:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h65ee9/democrat_adam_gray_declares_victory_over/"> <img src="https://external-preview.redd.it/eV-C9Vv0lxmqKiOkAsKeOPg0mg0TYKgKykWTlM5siZs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0878969c1497697292d0831868727846875416b6" alt="Democrat Adam Gray declares victory over Republican John Duarte in close congressional rematch" title="Democrat Adam Gray declares victory over Republican John Duarte in close congressional rematch" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plz-let-me-in"> /u/plz-let-me-in </a> <br/> <span><a href="https://www.sacbee.com/news/politics-government/election/california-elections/article295207064.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h65ee9/democrat_adam_gray_declares_victory_over/">[comments]</a></span> </td></tr></table>

## 'Gut punch': Trump upsets local union leaders by opposing U.S. Steel-Nippon deal
 - [https://www.reddit.com/r/politics/comments/1h654ao/gut_punch_trump_upsets_local_union_leaders_by](https://www.reddit.com/r/politics/comments/1h654ao/gut_punch_trump_upsets_local_union_leaders_by)
 - RSS feed: $source
 - date published: 2024-12-04T02:13:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h654ao/gut_punch_trump_upsets_local_union_leaders_by/"> <img src="https://external-preview.redd.it/j2210IS24Hz79X7yl8nB7hdGKztaTpBuOlDlzh0nu74.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=939029353f24e8709e66a0022bbd54cc7e662410" alt="'Gut punch': Trump upsets local union leaders by opposing U.S. Steel-Nippon deal" title="'Gut punch': Trump upsets local union leaders by opposing U.S. Steel-Nippon deal" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/freestudent88"> /u/freestudent88 </a> <br/> <span><a href="https://triblive.com/news/politics-election/gut-punch-trump-upsets-local-union-leaders-by-opposing-us-steel-nippon-deal/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h654ao/gut_punch_trump_upsets_local_union_leaders_by/">[comments]</a></span> </td></tr></table>

## 46 Senators Call on Biden to Certify Equal Rights Amendment as GOP Control Looms
 - [https://www.reddit.com/r/politics/comments/1h63ist/46_senators_call_on_biden_to_certify_equal_rights](https://www.reddit.com/r/politics/comments/1h63ist/46_senators_call_on_biden_to_certify_equal_rights)
 - RSS feed: $source
 - date published: 2024-12-04T00:56:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h63ist/46_senators_call_on_biden_to_certify_equal_rights/"> <img src="https://external-preview.redd.it/vAJplAw31sof5e-5kefCSljB0Ue3k4U8uRz-iIw8ZEo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=faf3271c74d898f1b1bed269af694d9e57474079" alt="46 Senators Call on Biden to Certify Equal Rights Amendment as GOP Control Looms" title="46 Senators Call on Biden to Certify Equal Rights Amendment as GOP Control Looms" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/grew_up_on_reddit"> /u/grew_up_on_reddit </a> <br/> <span><a href="https://www.commondreams.org/news/era-equal-rights-amendment">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h63ist/46_senators_call_on_biden_to_certify_equal_rights/">[comments]</a></span> </td></tr></table>

## Obama-appointed judge becomes second on federal bench to unretire on Trump after election win
 - [https://www.reddit.com/r/politics/comments/1h63ehw/obamaappointed_judge_becomes_second_on_federal](https://www.reddit.com/r/politics/comments/1h63ehw/obamaappointed_judge_becomes_second_on_federal)
 - RSS feed: $source
 - date published: 2024-12-04T00:51:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h63ehw/obamaappointed_judge_becomes_second_on_federal/"> <img src="https://external-preview.redd.it/qr1OpoY1qgr8QjUTlTq2tvkc4Y06j2qcOiO8cJAkbNw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2ce8fba2826bc3441d5037771950d07919ddaece" alt="Obama-appointed judge becomes second on federal bench to unretire on Trump after election win" title="Obama-appointed judge becomes second on federal bench to unretire on Trump after election win" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tasty_jams_5280"> /u/tasty_jams_5280 </a> <br/> <span><a href="https://lawandcrime.com/high-profile/obama-appointed-judge-becomes-second-democratic-appointee-to-unretire-on-trump-after-election-win/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h63ehw/obamaappointed_judge_becomes_second_on_federal/">[comments]</a></span> </td></tr></table>

## Michigan Republican says gay marriage should be illegal
 - [https://www.reddit.com/r/politics/comments/1h62igk/michigan_republican_says_gay_marriage_should_be](https://www.reddit.com/r/politics/comments/1h62igk/michigan_republican_says_gay_marriage_should_be)
 - RSS feed: $source
 - date published: 2024-12-04T00:10:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1h62igk/michigan_republican_says_gay_marriage_should_be/"> <img src="https://external-preview.redd.it/O2BFS2YZKKlcZE14pIzGqspgccodyDoERdfqybviRc4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0adedd39042c916b1025e341ad905bc180557e7c" alt="Michigan Republican says gay marriage should be illegal" title="Michigan Republican says gay marriage should be illegal" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Professor603"> /u/Professor603 </a> <br/> <span><a href="https://thehill.com/homenews/state-watch/5019909-michigan-republican-says-gay-marriage-should-be-illegal/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1h62igk/michigan_republican_says_gay_marriage_should_be/">[comments]</a></span> </td></tr></table>

