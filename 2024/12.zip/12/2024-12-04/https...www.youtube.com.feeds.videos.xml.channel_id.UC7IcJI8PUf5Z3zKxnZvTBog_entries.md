# Source:The School of Life, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog, language:en-US

## The Appeal of Rescuing Other People
 - [https://www.youtube.com/watch?v=54zAsOOo8xU](https://www.youtube.com/watch?v=54zAsOOo8xU)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:09+00:00

We might assume that our great longing in relationships would be to be looked after by someone; an exceptionally kind person who could listen to us, nurture us, assist us and make us feel comforted and seen. But this is to ignore just how strong there is - in some of us - a diametrically opposed aspiration: a wish to find someone who is in a lot of pain and trouble…

Enjoying our Youtube videos? Get full access to all our audio content, videos, and thousands of thought-provoking articles, conversation cards and more with The School of Life Subscription: https://www.theschooloflife.com/the-school-of-life-youtube/?utm_source=youtube&utm_medium=description&utm_campaign=The%20Appeal%20of%20Rescuing%20Other%20People


Learn, heal and grow. Get the best of The School of Life delivered straight to your inbox: https://www.theschooloflife.com/signup/?utm_source=youtube&utm_medium=description&utm_campaign=The%20Appeal%20of%20Rescuing%20Other%20People

FURTHER READING

You can read more on this

