# Source:Quality Gaming Content and Discussion -- /r/Games, URL:https://www.reddit.com/r/Games/.rss, language:en

## Infinity Nikki - Review Thread
 - [https://www.reddit.com/r/Games/comments/1h6u68j/infinity_nikki_review_thread](https://www.reddit.com/r/Games/comments/1h6u68j/infinity_nikki_review_thread)
 - RSS feed: $source
 - date published: 2024-12-04T23:10:02+00:00

<!-- SC_OFF --><div class="md"><h2>Game Information</h2> <p><strong>Game Title</strong>: Infinity Nikki</p> <p><strong>Platforms</strong>:</p> <ul> <li>PlayStation 5 (Dec 4, 2024)</li> <li>PC (Dec 4, 2024)</li> </ul> <p><strong>Trailer</strong>:</p> <p><strong>Developer</strong>: Infold Games</p> <p><strong>Review Aggregator</strong>:</p> <p><strong><a href="https://opencritic.com/game/17807/infinity-nikki">OpenCritic - 81 average - 91% recommended - 11 reviews</a></strong></p> <h2>Critic Reviews</h2> <p><strong><a href="https://opencritic.com/outlet/470/areajugones">Areajugones</a></strong> - <a href="https://opencritic.com/critic/4082/alfonso-c-novas">Alfonso Cánovas</a> - <em>Spanish</em> - <a href="https://areajugones.sport.es/videojuegos/analisis-de-infinity-nikki-cuando-la-moda-salva-el-mundo/">8.2 / 10</a></p> <blockquote> <p>Infinity Nikki is like that perfect outfit you didn&#39;t know you needed in your gaming closet. It&#39;s refreshing, beautiful, and surprisingly deep. I

## Vintage Story v1.20 - The Journey
 - [https://www.reddit.com/r/Games/comments/1h6sbg5/vintage_story_v120_the_journey](https://www.reddit.com/r/Games/comments/1h6sbg5/vintage_story_v120_the_journey)
 - RSS feed: $source
 - date published: 2024-12-04T21:52:22+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Watch-The-Skies"> /u/Watch-The-Skies </a> <br/> <span><a href="https://www.youtube.com/watch?v=C5v8NaRVIyk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6sbg5/vintage_story_v120_the_journey/">[comments]</a></span>

## Update of ConcernedApe’s Haunted Choclatier
 - [https://www.reddit.com/r/Games/comments/1h6rv46/update_of_concernedapes_haunted_choclatier](https://www.reddit.com/r/Games/comments/1h6rv46/update_of_concernedapes_haunted_choclatier)
 - RSS feed: $source
 - date published: 2024-12-04T21:33:55+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/swidd_hi"> /u/swidd_hi </a> <br/> <span><a href="https://www.hauntedchocolatier.net/2024/12/04/update/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6rv46/update_of_concernedapes_haunted_choclatier/">[comments]</a></span>

## Infinity Nikki Review - IGN
 - [https://www.reddit.com/r/Games/comments/1h6qbbg/infinity_nikki_review_ign](https://www.reddit.com/r/Games/comments/1h6qbbg/infinity_nikki_review_ign)
 - RSS feed: $source
 - date published: 2024-12-04T20:30:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/NoNefariousness2144"> /u/NoNefariousness2144 </a> <br/> <span><a href="https://www.ign.com/articles/infinity-nikki-review">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6qbbg/infinity_nikki_review_ign/">[comments]</a></span>

## Legacy of Kain: Soul Reaver 1 & 2 Remastered - Launch Trailer | PS5 & PS4 Games
 - [https://www.reddit.com/r/Games/comments/1h6qank/legacy_of_kain_soul_reaver_1_2_remastered_launch](https://www.reddit.com/r/Games/comments/1h6qank/legacy_of_kain_soul_reaver_1_2_remastered_launch)
 - RSS feed: $source
 - date published: 2024-12-04T20:29:53+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Just_a_user_name_"> /u/Just_a_user_name_ </a> <br/> <span><a href="https://www.youtube.com/watch?v=LpKy31RzDBA">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6qank/legacy_of_kain_soul_reaver_1_2_remastered_launch/">[comments]</a></span>

## BAPBAP - Official Trailer
 - [https://www.reddit.com/r/Games/comments/1h6q3ij/bapbap_official_trailer](https://www.reddit.com/r/Games/comments/1h6q3ij/bapbap_official_trailer)
 - RSS feed: $source
 - date published: 2024-12-04T20:21:26+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DarkChew"> /u/DarkChew </a> <br/> <span><a href="https://www.youtube.com/watch?v=Y4p8UyaPmDM">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6q3ij/bapbap_official_trailer/">[comments]</a></span>

## Kingmakers | Winter Games Expo Trailer - Early Access Release in Q1 2025 AD
 - [https://www.reddit.com/r/Games/comments/1h6pyob/kingmakers_winter_games_expo_trailer_early_access](https://www.reddit.com/r/Games/comments/1h6pyob/kingmakers_winter_games_expo_trailer_early_access)
 - RSS feed: $source
 - date published: 2024-12-04T20:16:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/pfisch"> /u/pfisch </a> <br/> <span><a href="https://www.youtube.com/watch?v=ZXujvsd9C58">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6pyob/kingmakers_winter_games_expo_trailer_early_access/">[comments]</a></span>

## Layoffs happening at illFonic (Friday the 13th, Killer Clowns from Outer Space, Predator: Hunting Grounds)
 - [https://www.reddit.com/r/Games/comments/1h6pc6o/layoffs_happening_at_illfonic_friday_the_13th](https://www.reddit.com/r/Games/comments/1h6pc6o/layoffs_happening_at_illfonic_friday_the_13th)
 - RSS feed: $source
 - date published: 2024-12-04T19:51:19+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TheEnygma"> /u/TheEnygma </a> <br/> <span><a href="https://x.com/IllFonic/status/1864369606988632330">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6pc6o/layoffs_happening_at_illfonic_friday_the_13th/">[comments]</a></span>

## Ask the Developer Vol. 15, Mario & Luigi: Brothership – Chapter 1 and 2
 - [https://www.reddit.com/r/Games/comments/1h6nysw/ask_the_developer_vol_15_mario_luigi_brothership](https://www.reddit.com/r/Games/comments/1h6nysw/ask_the_developer_vol_15_mario_luigi_brothership)
 - RSS feed: $source
 - date published: 2024-12-04T18:56:40+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/brzzcode"> /u/brzzcode </a> <br/> <span><a href="https://www.nintendo.com/en-gb/News/2024/December/Ask-the-Developer-Vol-15-Mario-Luigi-Brothership-Chapter-1-2706762.html?utm_medium=social&amp;utm_source=twitter&amp;utm_campaign=MarioLuigiBrothership|NULL|AskTheDevVol15|m_id_swQZvxjTDy|2706762">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6nysw/ask_the_developer_vol_15_mario_luigi_brothership/">[comments]</a></span>

## Raft - Console Launch Trailer
 - [https://www.reddit.com/r/Games/comments/1h6ngim/raft_console_launch_trailer](https://www.reddit.com/r/Games/comments/1h6ngim/raft_console_launch_trailer)
 - RSS feed: $source
 - date published: 2024-12-04T18:36:01+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/PrinceDizzy"> /u/PrinceDizzy </a> <br/> <span><a href="https://www.youtube.com/watch?v=t0AKZaCOjUE">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6ngim/raft_console_launch_trailer/">[comments]</a></span>

## Wolverine: The Best There Is | Character Reveal | Marvel Rivals
 - [https://www.reddit.com/r/Games/comments/1h6naw4/wolverine_the_best_there_is_character_reveal](https://www.reddit.com/r/Games/comments/1h6naw4/wolverine_the_best_there_is_character_reveal)
 - RSS feed: $source
 - date published: 2024-12-04T18:29:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Hakuryuu15"> /u/Hakuryuu15 </a> <br/> <span><a href="https://youtube.com/watch?v=wUsWBsuNITg&amp;si=MplWzxl0EjTH2tVa">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6naw4/wolverine_the_best_there_is_character_reveal/">[comments]</a></span>

## My First Gran Turismo launches on PS5 and PS4 December 6
 - [https://www.reddit.com/r/Games/comments/1h6l89x/my_first_gran_turismo_launches_on_ps5_and_ps4](https://www.reddit.com/r/Games/comments/1h6l89x/my_first_gran_turismo_launches_on_ps5_and_ps4)
 - RSS feed: $source
 - date published: 2024-12-04T17:08:30+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/willdearborn-"> /u/willdearborn- </a> <br/> <span><a href="https://blog.playstation.com/2024/12/04/my-first-gran-turismo-launches-on-ps5-and-ps4-december-6/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6l89x/my_first_gran_turismo_launches_on_ps5_and_ps4/">[comments]</a></span>

## Kingdom Come: Deliverance II will arrive at your homes on FEBRUARY 4TH 2025!
 - [https://www.reddit.com/r/Games/comments/1h6l24m/kingdom_come_deliverance_ii_will_arrive_at_your](https://www.reddit.com/r/Games/comments/1h6l24m/kingdom_come_deliverance_ii_will_arrive_at_your)
 - RSS feed: $source
 - date published: 2024-12-04T17:01:53+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://twitter.com/WarhorseStudios/status/1864354217139314820">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6l24m/kingdom_come_deliverance_ii_will_arrive_at_your/">[comments]</a></span>

## Bethesda: Indiana Jones and the Great Circle does not include Denuvo. It was only in review builds for leak precaution
 - [https://www.reddit.com/r/Games/comments/1h6kat4/bethesda_indiana_jones_and_the_great_circle_does](https://www.reddit.com/r/Games/comments/1h6kat4/bethesda_indiana_jones_and_the_great_circle_does)
 - RSS feed: $source
 - date published: 2024-12-04T16:31:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://x.com/bethesda/status/1864341765668372673">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6kat4/bethesda_indiana_jones_and_the_great_circle_does/">[comments]</a></span>

## Legacy of Kain: Soul Reaver 1 & 2 Remastered – Lost Levels and other bonus materials detailed
 - [https://www.reddit.com/r/Games/comments/1h6jk8m/legacy_of_kain_soul_reaver_1_2_remastered_lost](https://www.reddit.com/r/Games/comments/1h6jk8m/legacy_of_kain_soul_reaver_1_2_remastered_lost)
 - RSS feed: $source
 - date published: 2024-12-04T16:02:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://blog.playstation.com/2024/12/04/legacy-of-kain-soul-reaver-1-2-remastered-lost-levels-and-other-bonus-materials-detailed/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6jk8m/legacy_of_kain_soul_reaver_1_2_remastered_lost/">[comments]</a></span>

## Bleach Rebirth of Souls - Release Date Announcement Trailer | PS5 & PS4 Games
 - [https://www.reddit.com/r/Games/comments/1h6i33w/bleach_rebirth_of_souls_release_date_announcement](https://www.reddit.com/r/Games/comments/1h6i33w/bleach_rebirth_of_souls_release_date_announcement)
 - RSS feed: $source
 - date published: 2024-12-04T15:02:08+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.youtube.com/watch?v=61-mhztdef4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6i33w/bleach_rebirth_of_souls_release_date_announcement/">[comments]</a></span>

## Why Raphaël Colantonio's next game is and isn't like Dishonored
 - [https://www.reddit.com/r/Games/comments/1h6i0em/why_raphaël_colantonios_next_game_is_and_isnt](https://www.reddit.com/r/Games/comments/1h6i0em/why_raphaël_colantonios_next_game_is_and_isnt)
 - RSS feed: $source
 - date published: 2024-12-04T14:59:18+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.gamesindustry.biz/why-raphael-colantonios-next-game-is-and-isnt-like-dishonored">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6i0em/why_raphaël_colantonios_next_game_is_and_isnt/">[comments]</a></span>

## FANTASIAN Neo Dimension Review Thread
 - [https://www.reddit.com/r/Games/comments/1h6harf/fantasian_neo_dimension_review_thread](https://www.reddit.com/r/Games/comments/1h6harf/fantasian_neo_dimension_review_thread)
 - RSS feed: $source
 - date published: 2024-12-04T14:28:24+00:00

<!-- SC_OFF --><div class="md"><h2>Game Information</h2> <p><strong>Game Title</strong>: FANTASIAN Neo Dimension</p> <p><strong>Platforms</strong>:</p> <ul> <li>PlayStation 5 (Dec 5, 2024)</li> <li>PlayStation 4 (Dec 5, 2024)</li> <li>Xbox Series X/S (Dec 5, 2024)</li> <li>Nintendo Switch (Dec 5, 2024)</li> <li>PC (Dec 5, 2024)</li> </ul> <p><strong>Trailer</strong>:</p> <p><strong>Review Aggregator</strong>:</p> <p><strong><a href="https://opencritic.com/game/17731/fantasian-neo-dimension">OpenCritic - 82 average - 87% recommended - 30 reviews</a></strong></p> <h2>Critic Reviews</h2> <p><strong><a href="https://opencritic.com/outlet/458/atomix">Atomix</a></strong> - <a href="https://opencritic.com/critic/6511/sebastian-quiroz">Sebastian Quiroz</a> - <em>Spanish</em> - <a href="https://atomix.vg/review-fantasian-neo-dimension/">80 / 100</a></p> <blockquote> <p>In an age where every JRPG offers us complex experiences, with hundreds of hours of content and multiple systems at our dispo

## Crimson Desert: Official Hexe Marie Boss Fight Gameplay
 - [https://www.reddit.com/r/Games/comments/1h6gx2a/crimson_desert_official_hexe_marie_boss_fight](https://www.reddit.com/r/Games/comments/1h6gx2a/crimson_desert_official_hexe_marie_boss_fight)
 - RSS feed: $source
 - date published: 2024-12-04T14:11:32+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Dasnap"> /u/Dasnap </a> <br/> <span><a href="https://www.youtube.com/watch?v=EVqEYivqSVY">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6gx2a/crimson_desert_official_hexe_marie_boss_fight/">[comments]</a></span>

## My First Gran Turismo Trailer | PS5 & PS4 Games
 - [https://www.reddit.com/r/Games/comments/1h6go0k/my_first_gran_turismo_trailer_ps5_ps4_games](https://www.reddit.com/r/Games/comments/1h6go0k/my_first_gran_turismo_trailer_ps5_ps4_games)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:46+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.youtube.com/watch?v=9xXXU7LlrfQ">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6go0k/my_first_gran_turismo_trailer_ps5_ps4_games/">[comments]</a></span>

## For the sixth consecutive year, Super Smash Bros. Ultimate is the best-selling second-hand game in Japan
 - [https://www.reddit.com/r/Games/comments/1h6g3e1/for_the_sixth_consecutive_year_super_smash_bros](https://www.reddit.com/r/Games/comments/1h6g3e1/for_the_sixth_consecutive_year_super_smash_bros)
 - RSS feed: $source
 - date published: 2024-12-04T13:33:40+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://automaton-media.com/en/news/for-the-sixth-consecutive-year-super-smash-bros-ultimate-is-the-best-selling-second-hand-game-in-japan/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h6g3e1/for_the_sixth_consecutive_year_super_smash_bros/">[comments]</a></span>

## Daily /r/Games Discussion - Suggest Me a Game - December 04, 2024
 - [https://www.reddit.com/r/Games/comments/1h6dgmi/daily_rgames_discussion_suggest_me_a_game](https://www.reddit.com/r/Games/comments/1h6dgmi/daily_rgames_discussion_suggest_me_a_game)
 - RSS feed: $source
 - date published: 2024-12-04T11:00:59+00:00

<!-- SC_OFF --><div class="md"><p><a href="/r/Games">/r/Games</a> usually removes suggestion requests that are either too general (eg &quot;Which PS3 games are the best?&quot;) or too specific/personal (eg &quot;Should I buy Game A or Game B?&quot;), so this thread is the place to post any suggestion requests like those, or any other ones that you think wouldn&#39;t normally be worth starting a new post about.</p> <p>This thread is set to sort comments by &#39;new&#39; on default. </p> <p><strong>Obligatory Advertisements</strong></p> <p>If you want to post requests like this during the rest of the week, please post to other subreddits like <a href="/r/gamingsuggestions">/r/gamingsuggestions</a>, <a href="/r/ShouldIBuyThisGame">/r/ShouldIBuyThisGame</a>, or <a href="/r/AskGames">/r/AskGames</a> instead.</p> <p><a href="/r/Games">/r/Games</a> has a Discord server! Feel free to join us and chit-chat about games here: <a href="https://discord.gg/zRPaXTn">https://discord.gg/zRPaXTn</a></

## 【Tokyo Xtreme Racer】#8：Full PV
 - [https://www.reddit.com/r/Games/comments/1h69t5w/tokyo_xtreme_racer8full_pv](https://www.reddit.com/r/Games/comments/1h69t5w/tokyo_xtreme_racer8full_pv)
 - RSS feed: $source
 - date published: 2024-12-04T06:32:21+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sickladbro"> /u/sickladbro </a> <br/> <span><a href="https://youtu.be/umlztIQ7HeE?si=jrjwTAgg3_wV3dxj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h69t5w/tokyo_xtreme_racer8full_pv/">[comments]</a></span>

## Super House of Dead Ninjas back with original developer, on sale once again
 - [https://www.reddit.com/r/Games/comments/1h68fxj/super_house_of_dead_ninjas_back_with_original](https://www.reddit.com/r/Games/comments/1h68fxj/super_house_of_dead_ninjas_back_with_original)
 - RSS feed: $source
 - date published: 2024-12-04T05:09:05+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Gyossaits"> /u/Gyossaits </a> <br/> <span><a href="https://steamcommunity.com/games/224820/announcements/detail/4464851965270032739">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h68fxj/super_house_of_dead_ninjas_back_with_original/">[comments]</a></span>

## Cloak & Dagger: Inseparable Bond | Character Reveal | Marvel Rivals
 - [https://www.reddit.com/r/Games/comments/1h64ypt/cloak_dagger_inseparable_bond_character_reveal](https://www.reddit.com/r/Games/comments/1h64ypt/cloak_dagger_inseparable_bond_character_reveal)
 - RSS feed: $source
 - date published: 2024-12-04T02:05:58+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/chimerauprising"> /u/chimerauprising </a> <br/> <span><a href="https://youtu.be/mWkajLU7fxQ">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h64ypt/cloak_dagger_inseparable_bond_character_reveal/">[comments]</a></span>

## Donkey Kong Land III is now available to play for #NintendoSwitchOnline members! #GameBoy
 - [https://www.reddit.com/r/Games/comments/1h64vrt/donkey_kong_land_iii_is_now_available_to_play_for](https://www.reddit.com/r/Games/comments/1h64vrt/donkey_kong_land_iii_is_now_available_to_play_for)
 - RSS feed: $source
 - date published: 2024-12-04T02:02:00+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/bandit2"> /u/bandit2 </a> <br/> <span><a href="https://x.com/NintendoAmerica/status/1864120027764453776">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h64vrt/donkey_kong_land_iii_is_now_available_to_play_for/">[comments]</a></span>

## Tom Henderson: Ubisoft San Francisco and Osaka will be shut down, around 170-180 people will be laid off. Those not affected will move on to other Ubisoft projects. Today is the last day for some employees.
 - [https://www.reddit.com/r/Games/comments/1h63pf6/tom_henderson_ubisoft_san_francisco_and_osaka](https://www.reddit.com/r/Games/comments/1h63pf6/tom_henderson_ubisoft_san_francisco_and_osaka)
 - RSS feed: $source
 - date published: 2024-12-04T01:05:19+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/brzzcode"> /u/brzzcode </a> <br/> <span><a href="https://twitter.com/_Tom_Henderson_/status/1864095029519647111">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1h63pf6/tom_henderson_ubisoft_san_francisco_and_osaka/">[comments]</a></span>

