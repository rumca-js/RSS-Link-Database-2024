# Source:Handmade - Arts & Crafts Made by Hand, URL:https://www.reddit.com/r/handmade/.rss, language:

## Big waves near the shore. My oil painting on canvas.
 - [https://www.reddit.com/r/handmade/comments/1h6tzq4/big_waves_near_the_shore_my_oil_painting_on_canvas](https://www.reddit.com/r/handmade/comments/1h6tzq4/big_waves_near_the_shore_my_oil_painting_on_canvas)
 - RSS feed: $source
 - date published: 2024-12-04T23:01:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6tzq4/big_waves_near_the_shore_my_oil_painting_on_canvas/"> <img src="https://preview.redd.it/v38k77u8xw4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=35a67aed0634485afa716e924dc3a13b270f6e47" alt="Big waves near the shore. My oil painting on canvas." title="Big waves near the shore. My oil painting on canvas." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GreenStrength5876"> /u/GreenStrength5876 </a> <br/> <span><a href="https://i.redd.it/v38k77u8xw4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6tzq4/big_waves_near_the_shore_my_oil_painting_on_canvas/">[comments]</a></span> </td></tr></table>

## made some beaded bracelets
 - [https://www.reddit.com/r/handmade/comments/1h6ovfu/made_some_beaded_bracelets](https://www.reddit.com/r/handmade/comments/1h6ovfu/made_some_beaded_bracelets)
 - RSS feed: $source
 - date published: 2024-12-04T19:32:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6ovfu/made_some_beaded_bracelets/"> <img src="https://preview.redd.it/yyp7pbfxvv4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c5249a29528ad1996d988b778f09e73e8cb55242" alt="made some beaded bracelets " title="made some beaded bracelets " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ThrowRAcocididisos"> /u/ThrowRAcocididisos </a> <br/> <span><a href="https://i.redd.it/yyp7pbfxvv4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6ovfu/made_some_beaded_bracelets/">[comments]</a></span> </td></tr></table>

## I carved & painted this wooden chickadee brooch
 - [https://www.reddit.com/r/handmade/comments/1h6nqz3/i_carved_painted_this_wooden_chickadee_brooch](https://www.reddit.com/r/handmade/comments/1h6nqz3/i_carved_painted_this_wooden_chickadee_brooch)
 - RSS feed: $source
 - date published: 2024-12-04T18:47:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6nqz3/i_carved_painted_this_wooden_chickadee_brooch/"> <img src="https://b.thumbs.redditmedia.com/Yvm5Y53ZnKiqrRvcwKoTc7sFCLwvLfQ486XORDd9uuU.jpg" alt="I carved &amp; painted this wooden chickadee brooch" title="I carved &amp; painted this wooden chickadee brooch" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JaclynBatdorfFineArt"> /u/JaclynBatdorfFineArt </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6nqz3">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6nqz3/i_carved_painted_this_wooden_chickadee_brooch/">[comments]</a></span> </td></tr></table>

## Wool is a unique material. It can be used to make not only realistic animals, but even characters like these. I had a lot of fun making Grogu
 - [https://www.reddit.com/r/handmade/comments/1h6jsrc/wool_is_a_unique_material_it_can_be_used_to_make](https://www.reddit.com/r/handmade/comments/1h6jsrc/wool_is_a_unique_material_it_can_be_used_to_make)
 - RSS feed: $source
 - date published: 2024-12-04T16:12:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6jsrc/wool_is_a_unique_material_it_can_be_used_to_make/"> <img src="https://b.thumbs.redditmedia.com/M7kJudLacLYZs7y0hvNmUF8BrBlH_dHfV4h_XKeC6aQ.jpg" alt="Wool is a unique material. It can be used to make not only realistic animals, but even characters like these. I had a lot of fun making Grogu" title="Wool is a unique material. It can be used to make not only realistic animals, but even characters like these. I had a lot of fun making Grogu" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Uniquewoolgifts"> /u/Uniquewoolgifts </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6jsrc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6jsrc/wool_is_a_unique_material_it_can_be_used_to_make/">[comments]</a></span> </td></tr></table>

## Christmas is coming... 🎄☃️⛄❄️❄️❄️
 - [https://www.reddit.com/r/handmade/comments/1h6jegw/christmas_is_coming](https://www.reddit.com/r/handmade/comments/1h6jegw/christmas_is_coming)
 - RSS feed: $source
 - date published: 2024-12-04T15:56:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6jegw/christmas_is_coming/"> <img src="https://external-preview.redd.it/MHp6NWcwdWN0dTRlMdVF7dFAsQjvLyaW-UL2nJL5Ec8gc_0-tfTCWZTKhFd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=fe29107669e41ac4750cd37dbb8082b9113542f4" alt="Christmas is coming... 🎄☃️⛄❄️❄️❄️" title="Christmas is coming... 🎄☃️⛄❄️❄️❄️" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/June-Ceramics"> /u/June-Ceramics </a> <br/> <span><a href="https://v.redd.it/ypc03czctu4e1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6jegw/christmas_is_coming/">[comments]</a></span> </td></tr></table>

## Made Two Rose Bracelets
 - [https://www.reddit.com/r/handmade/comments/1h6ik9k/made_two_rose_bracelets](https://www.reddit.com/r/handmade/comments/1h6ik9k/made_two_rose_bracelets)
 - RSS feed: $source
 - date published: 2024-12-04T15:21:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6ik9k/made_two_rose_bracelets/"> <img src="https://b.thumbs.redditmedia.com/xju6IqzulTm-ABxJb3ePjlLdW9BzhotglduNrmoXLIw.jpg" alt="Made Two Rose Bracelets" title="Made Two Rose Bracelets" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Spent two days making it, which one do you like😜🌸</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AlisonYang33"> /u/AlisonYang33 </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6ik9k">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6ik9k/made_two_rose_bracelets/">[comments]</a></span> </td></tr></table>

## My Graphite pencil commission dachshund, what do you think
 - [https://www.reddit.com/r/handmade/comments/1h6eemm/my_graphite_pencil_commission_dachshund_what_do](https://www.reddit.com/r/handmade/comments/1h6eemm/my_graphite_pencil_commission_dachshund_what_do)
 - RSS feed: $source
 - date published: 2024-12-04T12:03:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6eemm/my_graphite_pencil_commission_dachshund_what_do/"> <img src="https://b.thumbs.redditmedia.com/I_4Q4IVN0GxC2H-GddGNnif5XvU5aUu29-AD97sfwhA.jpg" alt="My Graphite pencil commission dachshund, what do you think" title="My Graphite pencil commission dachshund, what do you think" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cary_21"> /u/Cary_21 </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6eemm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6eemm/my_graphite_pencil_commission_dachshund_what_do/">[comments]</a></span> </td></tr></table>

## Dainty Heart and Bow Necklace
 - [https://www.reddit.com/r/handmade/comments/1h6devj/dainty_heart_and_bow_necklace](https://www.reddit.com/r/handmade/comments/1h6devj/dainty_heart_and_bow_necklace)
 - RSS feed: $source
 - date published: 2024-12-04T10:57:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6devj/dainty_heart_and_bow_necklace/"> <img src="https://preview.redd.it/q9limrp5ct4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=34530ccb892335ff7655449658812d5dcdb4ead3" alt="Dainty Heart and Bow Necklace " title="Dainty Heart and Bow Necklace " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PrestigiousCoat390"> /u/PrestigiousCoat390 </a> <br/> <span><a href="https://i.redd.it/q9limrp5ct4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6devj/dainty_heart_and_bow_necklace/">[comments]</a></span> </td></tr></table>

## It was our first time doing pottery, and we didn't even know that it would turn white if we didn't apply any color...
 - [https://www.reddit.com/r/handmade/comments/1h6ch1f/it_was_our_first_time_doing_pottery_and_we_didnt](https://www.reddit.com/r/handmade/comments/1h6ch1f/it_was_our_first_time_doing_pottery_and_we_didnt)
 - RSS feed: $source
 - date published: 2024-12-04T09:50:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6ch1f/it_was_our_first_time_doing_pottery_and_we_didnt/"> <img src="https://preview.redd.it/0lhv8vl00t4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5453b7c7a952570161d941fb8a020efbe9a1b7cc" alt="It was our first time doing pottery, and we didn't even know that it would turn white if we didn't apply any color..." title="It was our first time doing pottery, and we didn't even know that it would turn white if we didn't apply any color..." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Material_Tea_3513"> /u/Material_Tea_3513 </a> <br/> <span><a href="https://i.redd.it/0lhv8vl00t4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6ch1f/it_was_our_first_time_doing_pottery_and_we_didnt/">[comments]</a></span> </td></tr></table>

## A hand hammered glass panel portrait of Jaylen Brown
 - [https://www.reddit.com/r/handmade/comments/1h6bvrc/a_hand_hammered_glass_panel_portrait_of_jaylen](https://www.reddit.com/r/handmade/comments/1h6bvrc/a_hand_hammered_glass_panel_portrait_of_jaylen)
 - RSS feed: $source
 - date published: 2024-12-04T09:04:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6bvrc/a_hand_hammered_glass_panel_portrait_of_jaylen/"> <img src="https://b.thumbs.redditmedia.com/GyPy5b3YWxy92rim9q3MRjdPE4GybNh2bwkupyi4cMo.jpg" alt="A hand hammered glass panel portrait of Jaylen Brown" title="A hand hammered glass panel portrait of Jaylen Brown" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sargon_studios"> /u/sargon_studios </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6bvrc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6bvrc/a_hand_hammered_glass_panel_portrait_of_jaylen/">[comments]</a></span> </td></tr></table>

## My project: Shibari Frames. I've started on a human, went to big, and now to small scale. I'm using shibari techniques and sewing skills.
 - [https://www.reddit.com/r/handmade/comments/1h6atte/my_project_shibari_frames_ive_started_on_a_human](https://www.reddit.com/r/handmade/comments/1h6atte/my_project_shibari_frames_ive_started_on_a_human)
 - RSS feed: $source
 - date published: 2024-12-04T07:44:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6atte/my_project_shibari_frames_ive_started_on_a_human/"> <img src="https://b.thumbs.redditmedia.com/ztjG12vGjW7MMAb28Zyj40IakALKFUGc53KA5ix_SCk.jpg" alt="My project: Shibari Frames. I've started on a human, went to big, and now to small scale. I'm using shibari techniques and sewing skills." title="My project: Shibari Frames. I've started on a human, went to big, and now to small scale. I'm using shibari techniques and sewing skills." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/EntertainerOverall36"> /u/EntertainerOverall36 </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6atte">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6atte/my_project_shibari_frames_ive_started_on_a_human/">[comments]</a></span> </td></tr></table>

## ✨
 - [https://www.reddit.com/r/handmade/comments/1h6albf/_](https://www.reddit.com/r/handmade/comments/1h6albf/_)
 - RSS feed: $source
 - date published: 2024-12-04T07:26:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h6albf/_/"> <img src="https://b.thumbs.redditmedia.com/Kb772LdH12c2QAJmQo92UQDhF8QywMVXne9lS96TnOY.jpg" alt="✨" title="✨" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/maheenzaib"> /u/maheenzaib </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6albf">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h6albf/_/">[comments]</a></span> </td></tr></table>

## When you forget to take your art supplies camping...
 - [https://www.reddit.com/r/handmade/comments/1h69ivd/when_you_forget_to_take_your_art_supplies_camping](https://www.reddit.com/r/handmade/comments/1h69ivd/when_you_forget_to_take_your_art_supplies_camping)
 - RSS feed: $source
 - date published: 2024-12-04T06:13:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h69ivd/when_you_forget_to_take_your_art_supplies_camping/"> <img src="https://preview.redd.it/q9ggrrqhxr4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=621ac4e5dc8679b461c446e7c5c1861bbefe9626" alt="When you forget to take your art supplies camping... " title="When you forget to take your art supplies camping... " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I totally forgot all my art supplies on a 3 week camping trip. This was made with seed pods twigs and a slightly dried green eucalyptus leaf broken into tiny pieces. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Decent_Ad8380"> /u/Decent_Ad8380 </a> <br/> <span><a href="https://i.redd.it/q9ggrrqhxr4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h69ivd/when_you_forget_to_take_your_art_supplies_camping/">[comments]</a></span> </td></tr></table>

## Just a few of the bookmarks I've made recently. What do you think?
 - [https://www.reddit.com/r/handmade/comments/1h67htr/just_a_few_of_the_bookmarks_ive_made_recently](https://www.reddit.com/r/handmade/comments/1h67htr/just_a_few_of_the_bookmarks_ive_made_recently)
 - RSS feed: $source
 - date published: 2024-12-04T04:16:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h67htr/just_a_few_of_the_bookmarks_ive_made_recently/"> <img src="https://b.thumbs.redditmedia.com/kDCg6hNCoxfqh-WvGDIjdnSvH-G0IMhmkBfsrZwsCaM.jpg" alt="Just a few of the bookmarks I've made recently. What do you think?" title="Just a few of the bookmarks I've made recently. What do you think?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/KoveyCat"> /u/KoveyCat </a> <br/> <span><a href="https://www.reddit.com/gallery/1h67htr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h67htr/just_a_few_of_the_bookmarks_ive_made_recently/">[comments]</a></span> </td></tr></table>

## Carved one of my homegrown gourds
 - [https://www.reddit.com/r/handmade/comments/1h66742/carved_one_of_my_homegrown_gourds](https://www.reddit.com/r/handmade/comments/1h66742/carved_one_of_my_homegrown_gourds)
 - RSS feed: $source
 - date published: 2024-12-04T03:08:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h66742/carved_one_of_my_homegrown_gourds/"> <img src="https://preview.redd.it/9f9tn20d0r4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7e279457980cc7dbeccbc5d47d5835643ee34f85" alt="Carved one of my homegrown gourds" title="Carved one of my homegrown gourds" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I originally started growing them just to make some birdhouses, getting into carving now. This is my first carved one, used some leather dye where I left the skin on. So proud with how it came out! 😊</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HerbivorousFarmer"> /u/HerbivorousFarmer </a> <br/> <span><a href="https://i.redd.it/9f9tn20d0r4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h66742/carved_one_of_my_homegrown_gourds/">[comments]</a></span> </td></tr></table>

## Unique Jewelry Alert: Green Fluorite & Peridot Bracelets I made. What do you think?
 - [https://www.reddit.com/r/handmade/comments/1h62l7h/unique_jewelry_alert_green_fluorite_peridot](https://www.reddit.com/r/handmade/comments/1h62l7h/unique_jewelry_alert_green_fluorite_peridot)
 - RSS feed: $source
 - date published: 2024-12-04T00:13:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1h62l7h/unique_jewelry_alert_green_fluorite_peridot/"> <img src="https://b.thumbs.redditmedia.com/MdfClmdCNIGQ0EeQlblAYEr-8CE1UywgohsKxav7hjE.jpg" alt="Unique Jewelry Alert: Green Fluorite &amp; Peridot Bracelets I made. What do you think?" title="Unique Jewelry Alert: Green Fluorite &amp; Peridot Bracelets I made. What do you think?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/guidevillage"> /u/guidevillage </a> <br/> <span><a href="https://www.reddit.com/gallery/1h62l7h">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1h62l7h/unique_jewelry_alert_green_fluorite_peridot/">[comments]</a></span> </td></tr></table>

