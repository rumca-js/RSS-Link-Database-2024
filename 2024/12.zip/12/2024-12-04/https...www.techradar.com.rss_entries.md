# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

##  AWS has a new tool that wants to stop AI hallucinations for good 
 - [https://www.techradar.com/pro/aws-has-a-new-tool-that-wants-to-stop-ai-hallucinations-for-good](https://www.techradar.com/pro/aws-has-a-new-tool-that-wants-to-stop-ai-hallucinations-for-good)
 - RSS feed: $source
 - date published: 2024-12-04T21:42:19+00:00


                             AWS reveals "first and only" safeguard against AI hallucinations. 
                                                                                                            

##  Why your favorite fictional AI friends are vanishing from Character.AI 
 - [https://www.techradar.com/computing/artificial-intelligence/why-your-favorite-fictional-ai-friends-are-vanishing-from-character-ai](https://www.techradar.com/computing/artificial-intelligence/why-your-favorite-fictional-ai-friends-are-vanishing-from-character-ai)
 - RSS feed: $source
 - date published: 2024-12-04T21:00:00+00:00


                             Character.AI removes many copyrighted characters from its platform. 
                                                                                                            

##  Your Netflix account is not suspended – how to avoid the latest SMS scam 
 - [https://www.techradar.com/streaming/netflix/your-netflix-account-is-not-suspended-how-to-avoid-the-latest-sms-scam](https://www.techradar.com/streaming/netflix/your-netflix-account-is-not-suspended-how-to-avoid-the-latest-sms-scam)
 - RSS feed: $source
 - date published: 2024-12-04T21:00:00+00:00


                             A Netflix SMS scam has again resurfaced, claiming that your account has been suspended –here's how to stay safe. 
                                                                                                            

##  Tim Cook won't leave Apple 'til a voice in his head tells him to do so 
 - [https://www.techradar.com/phones/tim-cook-wont-leave-apple-til-a-voice-in-his-head-tells-him-to-do-so](https://www.techradar.com/phones/tim-cook-wont-leave-apple-til-a-voice-in-his-head-tells-him-to-do-so)
 - RSS feed: $source
 - date published: 2024-12-04T20:33:51+00:00


                             Apple isn't charing for AI, it's OK with Vision Pro's market performance, and Tim isn't going anywhere. 
                                                                                                            

##  Do Macs get viruses? The answer is yes – and AI-powered malware is a growing threat, new report claims 
 - [https://www.techradar.com/computing/do-macs-get-viruses-the-answer-is-yes-and-ai-powered-malware-is-a-growing-threat-new-report-claims](https://www.techradar.com/computing/do-macs-get-viruses-the-answer-is-yes-and-ai-powered-malware-is-a-growing-threat-new-report-claims)
 - RSS feed: $source
 - date published: 2024-12-04T20:00:00+00:00


                             A new report has detailed the ways hackers are using ChatGPT to create effective viruses. 
                                                                                                            

##  Microsoft continues to mess up Windows 11 Recall, failing to provide fix for weird bug that breaks the feature 
 - [https://www.techradar.com/computing/windows/microsoft-continues-to-mess-up-windows-11-recall-failing-to-provide-fix-for-weird-bug-that-breaks-the-feature](https://www.techradar.com/computing/windows/microsoft-continues-to-mess-up-windows-11-recall-failing-to-provide-fix-for-weird-bug-that-breaks-the-feature)
 - RSS feed: $source
 - date published: 2024-12-04T18:52:42+00:00


                             Microsoft explains how to avoid bug that torpedoed Windows 11’s Recall feature for some testers – but there’s no cure for it. 
                                                                                                            

##  "Something the world has never seen before" – revolutionary cryo-CMOS transistor thrives in freezing conditions; could be used for scaling quantum computing and in space tech 
 - [https://www.techradar.com/pro/something-the-world-has-never-seen-before-revolutionary-cryo-cmos-transistor-thrives-in-freezing-conditions-could-be-used-for-scaling-quantum-computing-and-in-space-tech](https://www.techradar.com/pro/something-the-world-has-never-seen-before-revolutionary-cryo-cmos-transistor-thrives-in-freezing-conditions-could-be-used-for-scaling-quantum-computing-and-in-space-tech)
 - RSS feed: $source
 - date published: 2024-12-04T18:31:00+00:00


                             Cryo-CMOS transistor thrives in freezing conditions and could be used in quantum computing and space tech. 
                                                                                                            

##  Hackers are building bespoke Mac malware using GenAI 
 - [https://www.techradar.com/pro/security/hackers-are-building-bespoke-mac-malware-using-genai](https://www.techradar.com/pro/security/hackers-are-building-bespoke-mac-malware-using-genai)
 - RSS feed: $source
 - date published: 2024-12-04T18:02:00+00:00


                             The idea that macOS is safer than Windows is a dated one thanks to generative AI and its impact on malware writing. 
                                                                                                            

##  PSVR 2 gets surprise hand tracking update, and Sony should be making a bigger deal of it 
 - [https://www.techradar.com/gaming/playstation/psvr-2-gets-surprise-hand-tracking-update-and-sony-should-be-making-a-bigger-deal-of-it](https://www.techradar.com/gaming/playstation/psvr-2-gets-surprise-hand-tracking-update-and-sony-should-be-making-a-bigger-deal-of-it)
 - RSS feed: $source
 - date published: 2024-12-04T17:01:48+00:00


                             PSVR 2 headsets are finally getting hand-tracking. 
                                                                                                            

##  Cisco warns a decade-old vulnerability is back and targeting users 
 - [https://www.techradar.com/pro/security/cisco-warns-a-decade-old-vulnerability-is-back-and-targeting-users](https://www.techradar.com/pro/security/cisco-warns-a-decade-old-vulnerability-is-back-and-targeting-users)
 - RSS feed: $source
 - date published: 2024-12-04T17:01:00+00:00


                             Cisco bug was also added to CISA's KEV. 
                                                                                                            

##  Samsung Galaxy S25 Ultra predicted colors: every rumored shade 
 - [https://www.techradar.com/phones/samsung-galaxy-phones/samsung-galaxy-s25-ultra-colors](https://www.techradar.com/phones/samsung-galaxy-phones/samsung-galaxy-s25-ultra-colors)
 - RSS feed: $source
 - date published: 2024-12-04T16:35:18+00:00


                             We're expecting the Samsung Galaxy S25 Ultra to be sold in seven shades, and we have a good idea of what they'll be. 
                                                                                                            

##  The Day of the Jackal just broke a Sky streaming record but it’s not as big on Peacock 
 - [https://www.techradar.com/streaming/sky-tv/the-day-of-the-jackal-just-broke-a-sky-streaming-record-but-its-not-as-big-on-peacock](https://www.techradar.com/streaming/sky-tv/the-day-of-the-jackal-just-broke-a-sky-streaming-record-but-its-not-as-big-on-peacock)
 - RSS feed: $source
 - date published: 2024-12-04T16:29:06+00:00


                             The Day of the Jackal has beaten a mammoth milestone on Sky, but the same can't be said for Peacock. 
                                                                                                            

##  Top vodka brand Stoli files for bankruptcy following ransomware attack 
 - [https://www.techradar.com/pro/security/top-vodka-brand-stoli-files-for-bankruptcy-following-ransomware-attack](https://www.techradar.com/pro/security/top-vodka-brand-stoli-files-for-bankruptcy-following-ransomware-attack)
 - RSS feed: $source
 - date published: 2024-12-04T16:00:00+00:00


                             No threat actors have so far assumed responsibility for the attack on Stoli. 
                                                                                                            

##  Black Ops 6 CODMAS: what to expect from this year's Call of Duty Christmas event 
 - [https://www.techradar.com/gaming/black-ops-6-codmas](https://www.techradar.com/gaming/black-ops-6-codmas)
 - RSS feed: $source
 - date published: 2024-12-04T15:45:23+00:00


                             Here's when to expect the Black Ops 6 CODMAS update, which will add new limited-time modes, maps, and skins, as part of this year's Call of Duty Christmas event. 
                                                                                                            

##  The race to build data centers is on - here’s how we keep them secure 
 - [https://www.techradar.com/pro/the-race-to-build-data-centers-is-on-heres-how-we-keep-them-secure](https://www.techradar.com/pro/the-race-to-build-data-centers-is-on-heres-how-we-keep-them-secure)
 - RSS feed: $source
 - date published: 2024-12-04T15:26:21+00:00


                             Investment in AI infrastructure will require protection from cybersecurity threats. 
                                                                                                            

##  Three steps to take with governance and culture to catalyze AI success 
 - [https://www.techradar.com/pro/three-steps-to-take-with-governance-and-culture-to-catalyze-ai-success](https://www.techradar.com/pro/three-steps-to-take-with-governance-and-culture-to-catalyze-ai-success)
 - RSS feed: $source
 - date published: 2024-12-04T15:11:15+00:00


                             Three steps to develop effective governance and culture to lead to success with AI. 
                                                                                                            

##  Ransomware attack forces US government contractor ENGlobal to shut down some operations 
 - [https://www.techradar.com/pro/security/ransomware-attack-forces-us-government-contractor-englobal-to-shut-down-some-operations](https://www.techradar.com/pro/security/ransomware-attack-forces-us-government-contractor-englobal-to-shut-down-some-operations)
 - RSS feed: $source
 - date published: 2024-12-04T15:00:00+00:00


                             The company doesn't know when it will be fully operational again. 
                                                                                                            

##  New Batman fan film is made entirely with AI, and you won’t believe how good it is 
 - [https://www.techradar.com/computing/artificial-intelligence/new-batman-fan-film-is-made-entirely-with-ai-and-you-wont-believe-how-good-it-is](https://www.techradar.com/computing/artificial-intelligence/new-batman-fan-film-is-made-entirely-with-ai-and-you-wont-believe-how-good-it-is)
 - RSS feed: $source
 - date published: 2024-12-04T14:47:05+00:00


                             New 10-minute Batman fan film is entirely made with AI. 
                                                                                                            

##  Microsoft stubbornly sticks to Windows 11’s TPM security requirement – and risks annoying Windows 10 users 
 - [https://www.techradar.com/computing/windows/microsoft-stubbornly-sticks-to-windows-11s-tpm-security-requirement-and-risks-annoying-windows-10-users](https://www.techradar.com/computing/windows/microsoft-stubbornly-sticks-to-windows-11s-tpm-security-requirement-and-risks-annoying-windows-10-users)
 - RSS feed: $source
 - date published: 2024-12-04T14:34:30+00:00


                             Still hoping Microsoft might relent on Windows 11’s steeper spec requirements? Forget that idea... 
                                                                                                            

##  US Government says Salt Typhoon still lurks on telecoms networks, shares some top tips to stay protected 
 - [https://www.techradar.com/pro/security/us-government-says-salt-typhoon-still-lurks-on-telecoms-networks-shares-some-top-tips-to-stay-protected](https://www.techradar.com/pro/security/us-government-says-salt-typhoon-still-lurks-on-telecoms-networks-shares-some-top-tips-to-stay-protected)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:00+00:00


                             Months after being spotted, Salt Typhoon is still lurking, CISA says. 
                                                                                                            

##  Spotify Wrapped 2024 live – all the latest on its new AI-powered features and how to find them 
 - [https://www.techradar.com/news/live/spotify-wrapped-2024-live](https://www.techradar.com/news/live/spotify-wrapped-2024-live)
 - RSS feed: $source
 - date published: 2024-12-04T13:00:42+00:00


                             Spotify Wrapped 2024 has finally landed –here's our guide to using the recap's new features, plus all of our latest reactions. 
                                                                                                            

##  One of NASA's top data centers taken offline by flood 
 - [https://www.techradar.com/pro/one-of-nasas-top-data-centers-taken-offline-by-flood](https://www.techradar.com/pro/one-of-nasas-top-data-centers-taken-offline-by-flood)
 - RSS feed: $source
 - date published: 2024-12-04T13:00:00+00:00


                             NASA projects like IRIS, HMI and AIA have been affected by a burst pipe, taking a key data center offline. 
                                                                                                            

##  Spotify Wrapped 2024 is here – how to find it, plus the best new features 
 - [https://www.techradar.com/audio/audio-streaming/spotify-wrapped-2024-how-to-find-it](https://www.techradar.com/audio/audio-streaming/spotify-wrapped-2024-how-to-find-it)
 - RSS feed: $source
 - date published: 2024-12-04T13:00:00+00:00


                             Spotify Wrapped 2024 has landed, so you can see everything you've been listening to for the past 12 months. 
                                                                                                            

##  Spotify Wrapped 2024 not working? Try these 3 fixes to help it show up 
 - [https://www.techradar.com/audio/audio-streaming/spotify-wrapped-2024-not-working-try-these-3-fixes-to-help-it-show-up](https://www.techradar.com/audio/audio-streaming/spotify-wrapped-2024-not-working-try-these-3-fixes-to-help-it-show-up)
 - RSS feed: $source
 - date published: 2024-12-04T13:00:00+00:00


                             Is your Spotify Wrapped 2024 stubbornly refusing to show up? Here's a few potential fixes. 
                                                                                                            

##  Microsoft doesn’t care if your unsupported PC can run Windows 11 – it wants you to stop using it right now 
 - [https://www.techradar.com/computing/windows/microsoft-doesnt-care-if-your-unsupported-pc-can-run-windows-11-it-wants-you-to-stop-using-it-right-now](https://www.techradar.com/computing/windows/microsoft-doesnt-care-if-your-unsupported-pc-can-run-windows-11-it-wants-you-to-stop-using-it-right-now)
 - RSS feed: $source
 - date published: 2024-12-04T12:53:08+00:00


                             Oh great, Microsoft gets even more heavy-handed trying to force people to get new PCs for Windows 11 
                                                                                                            

##  Max’s password sharing crackdown starts soon with new member fees set to launch in early 2025 
 - [https://www.techradar.com/streaming/hbo-max/maxs-password-sharing-crackdown-starts-soon-with-new-member-fees-set-to-launch-in-early-2025](https://www.techradar.com/streaming/hbo-max/maxs-password-sharing-crackdown-starts-soon-with-new-member-fees-set-to-launch-in-early-2025)
 - RSS feed: $source
 - date published: 2024-12-04T12:12:42+00:00


                             Max will start sending reminders about its password sharing crackdown next week.  
                                                                                                            

##  Police crack encrypted chat service MATRIX used by criminals  
 - [https://www.techradar.com/pro/security/police-crack-encrypted-chat-service-matrix-used-by-criminals](https://www.techradar.com/pro/security/police-crack-encrypted-chat-service-matrix-used-by-criminals)
 - RSS feed: $source
 - date published: 2024-12-04T12:00:00+00:00


                             European authorities have disrupted and deciphered a chat service used by criminals. 
                                                                                                            

##  Garmin just revealed all the free new features in its December update 
 - [https://www.techradar.com/health-fitness/smartwatches/garmin-just-revealed-all-the-free-new-features-in-its-december-update](https://www.techradar.com/health-fitness/smartwatches/garmin-just-revealed-all-the-free-new-features-in-its-december-update)
 - RSS feed: $source
 - date published: 2024-12-04T11:53:41+00:00


                             Everything new in the Garmin December update.  
                                                                                                            

##  Amazon Music has Delivered its 2024 Spotify Wrapped clone – here’s how to find it 
 - [https://www.techradar.com/audio/audio-streaming/amazon-music-has-delivered-its-2024-spotify-wrapped-clone-heres-how-to-find-it](https://www.techradar.com/audio/audio-streaming/amazon-music-has-delivered-its-2024-spotify-wrapped-clone-heres-how-to-find-it)
 - RSS feed: $source
 - date published: 2024-12-04T11:44:46+00:00


                             Amazon Music Delivered 2024 is here to show off your year in music. 
                                                                                                            

##  Apple's smart HomePod and M5 iPad Pro tipped for 2025 launch – here's when to expect them 
 - [https://www.techradar.com/home/smart-home/apples-smart-homepod-and-m5-ipad-pro-tipped-for-2025-launch-heres-when-to-expect-them](https://www.techradar.com/home/smart-home/apples-smart-homepod-and-m5-ipad-pro-tipped-for-2025-launch-heres-when-to-expect-them)
 - RSS feed: $source
 - date published: 2024-12-04T11:31:42+00:00


                             A well-respected Apple analyst sheds some light on the new Apple gadgets we can expect over the next 12 months. 
                                                                                                            

##  This AI-powered chessboard could turn you into a grandmaster 
 - [https://www.techradar.com/computing/artificial-intelligence/this-ai-powered-chessboard-could-turn-you-into-a-grandmaster](https://www.techradar.com/computing/artificial-intelligence/this-ai-powered-chessboard-could-turn-you-into-a-grandmaster)
 - RSS feed: $source
 - date published: 2024-12-04T11:31:24+00:00


                             The GoChess Mini is not your average chess board - it has built-in AI personal coaching to make you a better player. 
                                                                                                            

##  AMD announces CES 2025 launch event on January 6, 2025 – and drops a heavy hint that new RDNA 4 GPUs will be revealed 
 - [https://www.techradar.com/computing/gpu/amd-announces-ces-2025-launch-event-on-january-6-2025-and-drops-a-heavy-hint-that-new-rdna-4-gpus-will-be-revealed](https://www.techradar.com/computing/gpu/amd-announces-ces-2025-launch-event-on-january-6-2025-and-drops-a-heavy-hint-that-new-rdna-4-gpus-will-be-revealed)
 - RSS feed: $source
 - date published: 2024-12-04T10:43:07+00:00


                             Can’t wait for RDNA 4 GPUs to arrive? We should see them next month at CES 2025, among a bunch of other gaming goodies. 
                                                                                                            

##  Got a Galaxy Watch 5 or FE? Samsung has a free upgrade for you 
 - [https://www.techradar.com/health-fitness/smartwatches/got-a-galaxy-watch-5-or-fe-samsung-has-a-free-upgrade-for-you](https://www.techradar.com/health-fitness/smartwatches/got-a-galaxy-watch-5-or-fe-samsung-has-a-free-upgrade-for-you)
 - RSS feed: $source
 - date published: 2024-12-04T10:42:19+00:00


                             Samsung is rolling out Wear OS 5 to two older Galaxy Watch models.  
                                                                                                            

##  Fallout season 2 gets an exciting filming update from two of its stars – but I'd be amazed if it's released before 2026 
 - [https://www.techradar.com/streaming/amazon-prime-video/fallout-season-2-gets-an-exciting-filming-update-from-two-of-its-stars-but-id-be-amazed-if-its-released-before-2026](https://www.techradar.com/streaming/amazon-prime-video/fallout-season-2-gets-an-exciting-filming-update-from-two-of-its-stars-but-id-be-amazed-if-its-released-before-2026)
 - RSS feed: $source
 - date published: 2024-12-04T10:32:41+00:00


                             Fallout season 2 has entered full production after two of its three main stars confirmed filming has begun. 
                                                                                                            

##  Microsoft accused of overcharging UK businesses in £1 billion legal claim 
 - [https://www.techradar.com/pro/microsoft-accused-of-overcharging-uk-businesses-in-gbp1-billion-legal-claim](https://www.techradar.com/pro/microsoft-accused-of-overcharging-uk-businesses-in-gbp1-billion-legal-claim)
 - RSS feed: $source
 - date published: 2024-12-04T10:01:00+00:00


                             Unfair Windows Server software pricing has disproportionately affected UK SMBs, Microsoft could pay out £1bn. 
                                                                                                            

##  The EU proposal to scan all your WhatsApp chats is back on the agenda 
 - [https://www.techradar.com/computing/cyber-security/the-eu-proposal-to-scan-all-your-whatsapp-chats-is-back-on-the-agenda](https://www.techradar.com/computing/cyber-security/the-eu-proposal-to-scan-all-your-whatsapp-chats-is-back-on-the-agenda)
 - RSS feed: $source
 - date published: 2024-12-04T07:00:00+00:00


                             The controversial CSAM scanning plan keeps coming back. Here's what we know so far. 
                                                                                                            

##  Apple Watch dominates Strava running devices for 2024, even beating out Garmin 
 - [https://www.techradar.com/health-fitness/apple-watch-dominates-strava-running-devices-for-2024-even-beating-out-garmin](https://www.techradar.com/health-fitness/apple-watch-dominates-strava-running-devices-for-2024-even-beating-out-garmin)
 - RSS feed: $source
 - date published: 2024-12-04T05:01:00+00:00


                             Here's your Strava data dump for 2024. 
                                                                                                            

##  Everything announced at AWS re:Invent 2024 you might have missed 
 - [https://www.techradar.com/pro/everything-announced-at-aws-re-invent-2024-you-might-have-missed](https://www.techradar.com/pro/everything-announced-at-aws-re-invent-2024-you-might-have-missed)
 - RSS feed: $source
 - date published: 2024-12-04T01:23:49+00:00


                             Stay up to date with all the biggest AWS re:Invent news announcements here. 
                                                                                                            

##  NYT Connections today — hints and answers for Wednesday, December 4 (game #542) 
 - [https://www.techradar.com/gaming/nyt-connections-today-answers-hints-4-december-2024](https://www.techradar.com/gaming/nyt-connections-today-answers-hints-4-december-2024)
 - RSS feed: $source
 - date published: 2024-12-04T00:02:10+00:00


                             Looking for NYT Connections answers and hints? Here's all you need to know to solve today's game, plus my commentary on the puzzles. 
                                                                                                            

##  NYT Strands today — hints, answers and spangram for Wednesday, December 4 (game #276) 
 - [https://www.techradar.com/computing/websites-apps/nyt-strands-today-answers-hints-4-december-2024](https://www.techradar.com/computing/websites-apps/nyt-strands-today-answers-hints-4-december-2024)
 - RSS feed: $source
 - date published: 2024-12-04T00:02:00+00:00


                             Looking for NYT Strands answers and hints? Here's all you need to know to solve today's game, including the spangram. 
                                                                                                            

##  Quordle today – hints and answers for Wednesday, December 4 (game #1045) 
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-4-december-2024](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-4-december-2024)
 - RSS feed: $source
 - date published: 2024-12-04T00:02:00+00:00


                             Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions. 
                                                                                                            

##  Gemini AI might be ready for you to roll the prompt dice 
 - [https://www.techradar.com/computing/artificial-intelligence/gemini-ai-might-be-ready-for-you-to-roll-the-prompt-dice](https://www.techradar.com/computing/artificial-intelligence/gemini-ai-might-be-ready-for-you-to-roll-the-prompt-dice)
 - RSS feed: $source
 - date published: 2024-12-04T00:00:00+00:00


                             Google plans Get Lucky button for Gemini AI. 
                                                                                                            

