# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## A New Season of Shows – Warhammer TV
 - [https://www.youtube.com/watch?v=r5qUT6fSZEg](https://www.youtube.com/watch?v=r5qUT6fSZEg)
 - RSS feed: $source
 - date published: 2024-12-04T13:01:06+00:00

From exclusive interviews with 'Eavy Metal painters to conversion challenges and chats with the Warhammer studio about rules, the new season of Warhammer TV is launching some incredible shows! Learn more: https://www.warhammer-community.com/en-gb/articles/0l4bpxrk/these-are-just-some-of-the-fantastic-new-shows-coming-to-warhammer-tv/

Follow for more Warhammer, more often:

- Instagram: https://www.instagram.com/warhammerofficial/
- Facebook: https://www.facebook.com/WarhammerOfficial/
- X: https://x.com/warhammer
- Warhammer Community: https://www.warhammer-community.com/
- Get Warhammer in your inbox: https://ow.ly/6SJq50T3NL1

## Joytoy Imperial Knights House Terryn Knight Paladin Teaser #warhammer
 - [https://www.youtube.com/watch?v=pOdKCPt10F4](https://www.youtube.com/watch?v=pOdKCPt10F4)
 - RSS feed: $source
 - date published: 2024-12-04T10:43:16+00:00

Follow for more Warhammer, more often:

- Instagram: https://www.instagram.com/warhammerofficial/
- Facebook: https://www.facebook.com/WarhammerOfficial/
- X: https://x.com/warhammer
- Warhammer Community: https://www.warhammer-community.com/
- Get Warhammer in your inbox: https://ow.ly/6SJq50T3NL1

