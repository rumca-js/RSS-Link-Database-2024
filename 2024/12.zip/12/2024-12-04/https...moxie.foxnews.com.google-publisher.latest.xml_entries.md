# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Smiling Hunter Biden seen in first photos since receiving presidential pardon
 - [https://www.foxnews.com/politics/smiling-hunter-biden-seen-first-photos-since-receiving-presidential-pardon](https://www.foxnews.com/politics/smiling-hunter-biden-seen-first-photos-since-receiving-presidential-pardon)
 - RSS feed: $source
 - date published: 2024-12-04T17:48:39+00:00

First photos of Hunter Biden emerge after President Biden&apos;s surprise pardoning of the first son in a Sunday night announcement.

## Women golfers rejoice after LPGA bars post-puberty males from female competition: 'No more!'
 - [https://www.foxnews.com/sports/women-golfers-rejoice-after-lpga-bars-post-puberty-males-from-female-competition-no-more](https://www.foxnews.com/sports/women-golfers-rejoice-after-lpga-bars-post-puberty-males-from-female-competition-no-more)
 - RSS feed: $source
 - date published: 2024-12-04T17:44:16+00:00

Multiple women&apos;s golfers have spoken out in support of the LGPA&apos;s new rule that bars post-pubescent males from competing against female golfers.

## Fox News Channel dominates cable news as CNN, MSNBC collapse to embarrassing weekly lows
 - [https://www.foxnews.com/media/fox-news-channel-dominates-cable-news-cnn-msnbc-collapse-embarrassing-weekly-lows](https://www.foxnews.com/media/fox-news-channel-dominates-cable-news-cnn-msnbc-collapse-embarrassing-weekly-lows)
 - RSS feed: $source
 - date published: 2024-12-04T17:31:33+00:00

Fox News Channel averaged 1.4 million total day viewers and two million during primetime to dominate cable news last week, while MSNBC and CNN hit historic viewership lows.

## Elton John’s vision loss: How an eye infection can cause blindness
 - [https://www.foxnews.com/health/elton-johns-vision-loss-how-eye-infection-can-cause-blindness](https://www.foxnews.com/health/elton-johns-vision-loss-how-eye-infection-can-cause-blindness)
 - RSS feed: $source
 - date published: 2024-12-04T17:30:21+00:00

Singer-songwriter Elton John has reported vision loss due to an eye infection. Dr. Derek Cunningham explains how this extreme outcome can happen and what to watch for.

## Ravens suspend Diontae Johnson 1 game after refusing to play vs Eagles
 - [https://www.foxnews.com/sports/ravens-suspend-diontae-johnson-1-game-after-refusing-play-vs-eagles](https://www.foxnews.com/sports/ravens-suspend-diontae-johnson-1-game-after-refusing-play-vs-eagles)
 - RSS feed: $source
 - date published: 2024-12-04T17:27:14+00:00

The Baltimore Ravens announced they have suspended wide receiver Diontae Johnson one game for refusing to play against the Philadelphia Eagles on Sunday.

## Fox News Sports Huddle Newsletter: LPGA Tour's gender-eligibility policy bars 'players assigned male at birth'
 - [https://www.foxnews.com/sports/fox-news-sports-huddle-newsletter-lpga-tours-gender-eligibility-policy-bars-players-assigned-male-birth](https://www.foxnews.com/sports/fox-news-sports-huddle-newsletter-lpga-tours-gender-eligibility-policy-bars-players-assigned-male-birth)
 - RSS feed: $source
 - date published: 2024-12-04T16:51:43+00:00

Receive your weekly recap of all the happenings around the world of sports.

## Martina Navratilova 'mad' that Republicans are more outspoken than Dems about trans athletes in girls sports
 - [https://www.foxnews.com/sports/martina-navratilova-mad-republicans-more-outspoken-than-dems-about-trans-athletes-girls-sports](https://www.foxnews.com/sports/martina-navratilova-mad-republicans-more-outspoken-than-dems-about-trans-athletes-girls-sports)
 - RSS feed: $source
 - date published: 2024-12-04T16:47:45+00:00

Martina Navratilova again ripped Democrats on Wednesday in an X post for their tolerance of transgender athletes in women&apos;s and girls&apos; sports.

## Oklahoma measure seeks to make school district superintendents an elected position
 - [https://www.foxnews.com/politics/proposed-state-bill-would-make-ok-school-leaders-elected-public-after-spate-controversies](https://www.foxnews.com/politics/proposed-state-bill-would-make-ok-school-leaders-elected-public-after-spate-controversies)
 - RSS feed: $source
 - date published: 2024-12-04T16:40:03+00:00

Legislators in Oklahoma are primed to consider forthcoming legislation making the position of local school superintendent an elected one, just as the statewide superintendent is so.

## Commanders' Austin Ekeler says he suffered memory loss after second concussion this season
 - [https://www.foxnews.com/sports/commanders-austin-ekeler-says-he-suffered-memory-loss-after-second-concussion-season](https://www.foxnews.com/sports/commanders-austin-ekeler-says-he-suffered-memory-loss-after-second-concussion-season)
 - RSS feed: $source
 - date published: 2024-12-04T16:38:14+00:00

Washington Commanders running back Austin Ekeler was placed on injured reserve this past weekend after he sustained his second concussion in a span of just two months.

## Trevor Lawrence placed on injured reserve, likely ending his season after dangerous hit
 - [https://www.foxnews.com/sports/trevor-lawrence-placed-injured-reserve-likely-ending-his-season-after-dangerous-hit](https://www.foxnews.com/sports/trevor-lawrence-placed-injured-reserve-likely-ending-his-season-after-dangerous-hit)
 - RSS feed: $source
 - date published: 2024-12-04T16:30:40+00:00

The Jacksonville Jaguars have placed Trevor Lawrence on injured reserve, likely ending his season after the hit he took earlier this week.

## Lawmakers hold moment of silence for slain Omer Neutra as thousands mourn in hometown synagogue
 - [https://www.foxnews.com/world/lawmakers-hold-moment-silence-slain-omer-neutra-thousands-mourn-hometown-synagogue](https://www.foxnews.com/world/lawmakers-hold-moment-silence-slain-omer-neutra-thousands-mourn-hometown-synagogue)
 - RSS feed: $source
 - date published: 2024-12-04T16:24:54+00:00

A bipartisan group of lawmakers held a moment of silence for the slain Omer Neutra, an American-Israeli who was killed by Hamas on Oct. 7, 2023, according to new intelligence uncovered by the IDF.

## Vogue head honcho Anna Wintour explains why she refuses to take off 'prop' sunglasses
 - [https://www.foxnews.com/entertainment/vogue-anna-wintour-explains-refuses-take-off-prop-sunglasses](https://www.foxnews.com/entertainment/vogue-anna-wintour-explains-refuses-take-off-prop-sunglasses)
 - RSS feed: $source
 - date published: 2024-12-04T16:21:30+00:00

Vogue executive Anna Wintour debunked misconceptions of her icy persona and explained why she chooses to keep her signature shades on.

## Mexico seizes record amount of fentanyl days after Trump issued tariff threats
 - [https://www.foxnews.com/world/mexico-seizes-record-amount-fentanyl-days-trump-issued-tariff-threats](https://www.foxnews.com/world/mexico-seizes-record-amount-fentanyl-days-trump-issued-tariff-threats)
 - RSS feed: $source
 - date published: 2024-12-04T15:58:37+00:00

Mexican troops seized a record amount of fentanyl pills in the state of Sinaloa on Tuesday, which broke a record, authorities said this week.

## Sean Penn says he's 'proud' of Biden for pardoning Hunter, 'one of the finest people I know'
 - [https://www.foxnews.com/media/sean-penn-says-hes-proud-biden-pardoning-hunter-one-finest-people-i-know](https://www.foxnews.com/media/sean-penn-says-hes-proud-biden-pardoning-hunter-one-finest-people-i-know)
 - RSS feed: $source
 - date published: 2024-12-04T15:56:24+00:00

Liberal actor Sean Penn defended President Biden for his pardon of his son Hunter, which spares him from his upcoming sentencing in two unrelated federal cases.

## Notable baseball names react to MLB's 'golden at-bat' rule: 'Is this an April Fool's joke?'
 - [https://www.foxnews.com/sports/notable-mlb-names-react-mlbs-golden-at-bat-rule-is-april-fools-joke](https://www.foxnews.com/sports/notable-mlb-names-react-mlbs-golden-at-bat-rule-is-april-fools-joke)
 - RSS feed: $source
 - date published: 2024-12-04T15:51:20+00:00

MLB proposed &quot;golden at-bat&quot; rule, which would allow teams one chance to send whoever they want to the plate, is getting brushback from notable names in the sport.

## Joe Burrow tells Bengals teammates he bought $3 million Batmobile during 'Hard Knocks'
 - [https://www.foxnews.com/sports/joe-burrow-tells-bengals-teammates-he-bought-3-million-batmobile-during-hard-knocks](https://www.foxnews.com/sports/joe-burrow-tells-bengals-teammates-he-bought-3-million-batmobile-during-hard-knocks)
 - RSS feed: $source
 - date published: 2024-12-04T15:50:16+00:00

The Cincinnati Bengals&apos; season isn&apos;t going too well for quarterback Joe Burrow, but off the field, he did make a pretty big purchase as he revealed he bought the Batmobile.

## Border Patrol chief thrilled with Trump border czar pick after 'exhausting' Biden-era crisis: 'I'm excited'
 - [https://www.foxnews.com/politics/border-patrol-chief-thrilled-trump-border-czar-after-exhausting-biden-era-crisis](https://www.foxnews.com/politics/border-patrol-chief-thrilled-trump-border-czar-after-exhausting-biden-era-crisis)
 - RSS feed: $source
 - date published: 2024-12-04T15:39:15+00:00

Border Patrol Chief Jason Owens is warning about the threats posed by fentanyl and Tren de Aragua, while saying he is excited for the arrival of Tom Homan as border czar.

## French government collapses after no-confidence vote passes against Prime Minister Michel Barnier
 - [https://www.foxnews.com/world/french-government-collapses-no-confidence-vote-passes-prime-minister-michel-barnier](https://www.foxnews.com/world/french-government-collapses-no-confidence-vote-passes-prime-minister-michel-barnier)
 - RSS feed: $source
 - date published: 2024-12-04T15:34:59+00:00

Prime Minister Michel Barnier is expected to resign after the National Assembly passed a vote of no-confidence on Wednesday, effectively collapsing the current government.

## Shocking video shows UnitedHealthcare CEO Brian Thompson gunned down on NYC street
 - [https://www.foxnews.com/us/shocking-video-shows-unitedhealthcare-ceo-brian-thompson-gunned-down-nyc-street](https://www.foxnews.com/us/shocking-video-shows-unitedhealthcare-ceo-brian-thompson-gunned-down-nyc-street)
 - RSS feed: $source
 - date published: 2024-12-04T15:18:56+00:00

Video obtained by Fox News Digital shows the suspect wanted for the shooting death of UnitedHealth CEO Brian Thompson in Midtown Manhattan savagely gunning him down.

## NATO chief defends Trump to critical MSNBC host, says 'he was right' to hit allies on defense spending
 - [https://www.foxnews.com/media/nato-chief-defends-trump-critical-msnbc-host-says-right-hit-allies-defense-spending](https://www.foxnews.com/media/nato-chief-defends-trump-critical-msnbc-host-says-right-hit-allies-defense-spending)
 - RSS feed: $source
 - date published: 2024-12-04T15:14:44+00:00

NATO chief Mark Rutte told MSNBC&apos;s Jonathan Lemire that President-elect Donald Trump was right to criticize allies for not meeting defense spending goals in 2018.

## Sotomayor compares trans medical 'treatments' to aspirin in question about side effects during oral arguments
 - [https://www.foxnews.com/politics/sotomayor-compares-trans-medical-treatments-aspirin-question-about-side-effects-during-oral-arguments](https://www.foxnews.com/politics/sotomayor-compares-trans-medical-treatments-aspirin-question-about-side-effects-during-oral-arguments)
 - RSS feed: $source
 - date published: 2024-12-04T15:12:47+00:00

Justice Sonia Sotomayor said &apos;every medical treatment has a risk, even taking Aspirin&apos; during oral arguments in high-profile SCOTUS case involving trans &apos;treatments&apos; for minors.

## UK killer nurse Letby questioned over further baby deaths
 - [https://www.foxnews.com/world/uk-killer-nurse-letby-questioned-further-baby-deaths](https://www.foxnews.com/world/uk-killer-nurse-letby-questioned-further-baby-deaths)
 - RSS feed: $source
 - date published: 2024-12-04T15:06:02+00:00

Lucy Letby, a former British nurse who is serving a life sentence for the murders of babies in her care, has reportedly been questioned about more infant deaths.

## Reporter's Notebook: People are policy
 - [https://www.foxnews.com/politics/reporters-notebook-people-policy](https://www.foxnews.com/politics/reporters-notebook-people-policy)
 - RSS feed: $source
 - date published: 2024-12-04T14:46:43+00:00

This week begins the quadrennial tradition of various Cabinet nominees parading around the Senate to meet with lawmakers, answer questions, and get insight into their confirmation hearing.

## Bill Clinton recalls pardoning half-brother, says it's not similar to Biden's controversial one of Hunter
 - [https://www.foxnews.com/media/bill-clinton-recalls-pardoning-half-brother-says-its-not-similar-bidens-controversial-one-hunter](https://www.foxnews.com/media/bill-clinton-recalls-pardoning-half-brother-says-its-not-similar-bidens-controversial-one-hunter)
 - RSS feed: $source
 - date published: 2024-12-04T14:44:12+00:00

Bill Clinton recalled the pardon of his half-brother, Roger Clinton, during an interview on Wednesday and said it wasn&apos;t the same as President Biden&apos;s pardon for Hunter.

## British band robbed at gunpoint in California
 - [https://www.foxnews.com/entertainment/british-band-robbed-gunpoint-california](https://www.foxnews.com/entertainment/british-band-robbed-gunpoint-california)
 - RSS feed: $source
 - date published: 2024-12-04T14:27:02+00:00

Sports Team revealed the band was robbed at gunpoint on Dec. 3 after stopping at a Starbucks in California. The U.K. band will continue the tour despite the incident.

## Biden appears to rest his eyes at African summit in Angola
 - [https://www.foxnews.com/politics/biden-appears-rest-his-eyes-african-summit-angola](https://www.foxnews.com/politics/biden-appears-rest-his-eyes-african-summit-angola)
 - RSS feed: $source
 - date published: 2024-12-04T14:22:14+00:00

President Biden appeared to rest his eyes during a summit with African leaders in Lobito, Angola, during his travel overseas to visit African nations.

## Esquire deletes false George Bush pardon story after liberal columnist makes major error
 - [https://www.foxnews.com/media/esquire-deletes-false-george-bush-pardon-story-liberal-columnist-makes-major-error](https://www.foxnews.com/media/esquire-deletes-false-george-bush-pardon-story-liberal-columnist-makes-major-error)
 - RSS feed: $source
 - date published: 2024-12-04T14:07:50+00:00

Esquire has removed a column that attacked critics of the Hunter Biden pardon and falsely claimed former President George H.W. Bush pardoned his son.

## Manhattan DA's downplaying of Daniel Penny's potential punishment 'improper and misleading': defense
 - [https://www.foxnews.com/us/manhattan-das-downplaying-daniel-pennys-potential-punishment-improper-misleading-defense](https://www.foxnews.com/us/manhattan-das-downplaying-daniel-pennys-potential-punishment-improper-misleading-defense)
 - RSS feed: $source
 - date published: 2024-12-04T14:05:19+00:00

What&apos;s behind Manhattan DA Alvin Bragg&apos;s push to downplay the potential consequences for Daniel Penny, if his office gets a conviction in the Jordan Neely case?

## Supreme Court appears divided over state bans on gender transition 'treatments' for minors
 - [https://www.foxnews.com/politics/supreme-court-appears-divided-over-state-bans-gender-transition-treatments-minors](https://www.foxnews.com/politics/supreme-court-appears-divided-over-state-bans-gender-transition-treatments-minors)
 - RSS feed: $source
 - date published: 2024-12-04T13:53:33+00:00

The Supreme Court appeared divided Wednesday over the constitutionality of state laws banning gender transition medical treatments for minors.

## Some migrants anticipating Trump's policies are already turning back home: report
 - [https://www.foxnews.com/politics/some-migrants-anticipating-trumps-policies-already-turning-back-home-report](https://www.foxnews.com/politics/some-migrants-anticipating-trumps-policies-already-turning-back-home-report)
 - RSS feed: $source
 - date published: 2024-12-04T13:44:11+00:00

Some migrants are planning to return home if they can&apos;t get into the U.S. before President-elect Trump takes office.

## Stanley's new Messi x Stanley collection features athlete-focused tumblers
 - [https://www.foxnews.com/lifestyle/messi-x-stanley-collection](https://www.foxnews.com/lifestyle/messi-x-stanley-collection)
 - RSS feed: $source
 - date published: 2024-12-04T13:36:24+00:00

The new Messi x Stanley collection features cool pink tumblers, water bottles and cups.

## Georgia city to ring in 2025 by imploding 16-story hotel on New Year's Eve
 - [https://www.foxnews.com/travel/georgia-city-ring-2025-imploding-16-story-hotel-new-years-eve](https://www.foxnews.com/travel/georgia-city-ring-2025-imploding-16-story-hotel-new-years-eve)
 - RSS feed: $source
 - date published: 2024-12-04T13:33:10+00:00

A 16-story vacant hotel in Macon, Georgia, was purchased by city officials and will be detonated on New Year&apos;s Eve to ring in 2025. The building was last occupied in 2017.

## Dem senator urges Biden to extend protections for illegal immigrants before Trump admin: ‘Nobody is safe'
 - [https://www.foxnews.com/politics/dem-senator-urges-biden-extend-protections-some-illegal-immigrants-before-trump-admin-nobody-safe](https://www.foxnews.com/politics/dem-senator-urges-biden-extend-protections-some-illegal-immigrants-before-trump-admin-nobody-safe)
 - RSS feed: $source
 - date published: 2024-12-04T13:26:52+00:00

Democratic Sen. Catherine Cortez Masto is calling on President Biden to extend deportation protections for illegal immigrants in the U.S. before President-elect Trump takes office.

## Outgoing GOP congressman seeks role as Trump's drug czar after first nominee falls through
 - [https://www.foxnews.com/politics/outgoing-gop-congressman-seeks-role-trumps-drug-czar-after-first-nominee-falls-through](https://www.foxnews.com/politics/outgoing-gop-congressman-seeks-role-trumps-drug-czar-after-first-nominee-falls-through)
 - RSS feed: $source
 - date published: 2024-12-04T13:23:50+00:00

Outgoing GOP Rep. Anthony D&apos;Esposito, R-N.Y., is gunning to be the next leader of President-elect Donald Trump&apos;s Drug Enforcement Agency, after Trump&apos;s first nominee withdrew his name amid criticism.

## Pence backs Trump's 'hawkish' tariffs on China but warns it 'must not become our enemy'
 - [https://www.foxnews.com/world/pence-backs-trumps-hawkish-tariffs-china-warns-must-not-become-our-enemy](https://www.foxnews.com/world/pence-backs-trumps-hawkish-tariffs-china-warns-must-not-become-our-enemy)
 - RSS feed: $source
 - date published: 2024-12-04T13:16:44+00:00

Former Vice President Mike Pence came out in support of the additional tariffs that President-elect Trump promised to slap on China over the continued fentanyl crisis plaguing the U.S.

## Supreme Court weighs transgender youth treatments in landmark case
 - [https://www.foxnews.com/politics/supreme-court-weighs-transgender-youth-treatments-landmark-case](https://www.foxnews.com/politics/supreme-court-weighs-transgender-youth-treatments-landmark-case)
 - RSS feed: $source
 - date published: 2024-12-04T13:08:05+00:00

The Supreme Court&apos;s ruling on the Tennessee legislation could affect similar laws in 25 states.

## Chiefs' Travis Kelce sounds off on lack of scoring this season: 'F---ing frustrating'
 - [https://www.foxnews.com/sports/chiefs-travis-kelce-sounds-off-lack-scoring-season-f-g-frustrating](https://www.foxnews.com/sports/chiefs-travis-kelce-sounds-off-lack-scoring-season-f-g-frustrating)
 - RSS feed: $source
 - date published: 2024-12-04T12:59:37+00:00

Kansas City Chiefs tight end Travis Kelce talked about his frustration with his lack of touchdowns this season during a recent episode of &quot;New Heights.&quot;

## LPGA Tour's gender-eligibility policy change draws fiery reaction from transgender golfer
 - [https://www.foxnews.com/sports/lpga-tours-gender-eligibility-policy-change-draws-fiery-reaction-from-transgender-golfer](https://www.foxnews.com/sports/lpga-tours-gender-eligibility-policy-change-draws-fiery-reaction-from-transgender-golfer)
 - RSS feed: $source
 - date published: 2024-12-04T12:51:18+00:00

Transgender golfer Hailey Davidson reacted to the LPGA Tour&apos;s stunning decision to effectively ban trans competitors in events on Wednesday.

## Dolly Parton doesn’t know if she’s ‘still considered a country artist'
 - [https://www.foxnews.com/entertainment/dolly-parton-doesnt-know-shes-still-considered-country-artist](https://www.foxnews.com/entertainment/dolly-parton-doesnt-know-shes-still-considered-country-artist)
 - RSS feed: $source
 - date published: 2024-12-04T12:46:40+00:00

Country music star Dolly Parton shared that she sometimes wonders if fans still see her as an artist in the popular genre.

## Flames honor Johnny Gaudreau with emotional tribute months after tragic death of NHL star and brother
 - [https://www.foxnews.com/sports/flames-honor-johnny-gaudreau-emotional-tribute-months-after-tragic-death-nhl-star-brother](https://www.foxnews.com/sports/flames-honor-johnny-gaudreau-emotional-tribute-months-after-tragic-death-nhl-star-brother)
 - RSS feed: $source
 - date published: 2024-12-04T12:31:33+00:00

The Calgary Flames hosted the Gaudreau family on Tuesday night as they paid tribute to former NHL star Johnny Gaudreau, who was killed alongside his brother in a bike accident in August.

## Iranian activist, Nobel prize winner Mohammadi released from jail for medical treatment
 - [https://www.foxnews.com/world/iranian-activist-nobel-prize-winner-mohammadi-released-from-jail-medical-treatment](https://www.foxnews.com/world/iranian-activist-nobel-prize-winner-mohammadi-released-from-jail-medical-treatment)
 - RSS feed: $source
 - date published: 2024-12-04T12:26:21+00:00

Human rights activist Narges Mohammadi, who is imprisoned in Iran on charges including spreading propaganda, had her jail term suspended to undergo medical treatment.

## Dems renew push for limiting presidential clemency powers after Hunter Biden pardon
 - [https://www.foxnews.com/politics/dems-renew-push-limiting-presidential-clemency-powers-after-hunter-biden-pardon](https://www.foxnews.com/politics/dems-renew-push-limiting-presidential-clemency-powers-after-hunter-biden-pardon)
 - RSS feed: $source
 - date published: 2024-12-04T12:20:53+00:00

Calls to limit presidential pardon powers have fallen on party lines in the House of Representatives.

## Charlamagne Tha God clashes with Whoopi Goldberg over Biden's pardon of Hunter: 'He just changed his mind?'
 - [https://www.foxnews.com/media/charlamagne-tha-god-clashes-whoopi-goldberg-over-bidens-pardon-hunter-he-just-changed-his-mind](https://www.foxnews.com/media/charlamagne-tha-god-clashes-whoopi-goldberg-over-bidens-pardon-hunter-he-just-changed-his-mind)
 - RSS feed: $source
 - date published: 2024-12-04T12:19:27+00:00

&quot;The View&quot; co-host Whoopi Goldberg clashed with Charlamagne Tha God on Wednesday over President Biden&apos;s decision to pardon Hunter despite repeatedly saying he wouldn&apos;t.

## Trump keeps Whatley at Republican National Committee following 'OUTSTANDING and HISTORIC JOB'
 - [https://www.foxnews.com/politics/trump-keeps-whatley-republican-national-committee-following-outstanding-historic-job](https://www.foxnews.com/politics/trump-keeps-whatley-republican-national-committee-following-outstanding-historic-job)
 - RSS feed: $source
 - date published: 2024-12-04T12:18:24+00:00

President-elect Trump on Wednesday invited Republican National Committee chair Michael Whatley to continue steering the GOP&apos;s national party committee, and Whatley quickly accepted.

## Top Dems, activists call on Biden admin to dole out more student loan forgiveness before term ends
 - [https://www.foxnews.com/politics/top-dems-activists-biden-admin-student-loan-forgiveness-before-term-ends](https://www.foxnews.com/politics/top-dems-activists-biden-admin-student-loan-forgiveness-before-term-ends)
 - RSS feed: $source
 - date published: 2024-12-04T12:14:43+00:00

Top Democratic lawmakers and activists alike are calling on the Biden administration to ignore a federal injunction and continue wiping out student loan debt before its tenure comes to a close.

## 20 luxury gift ideas under $50 for the haute-loving recipient in your life
 - [https://www.foxnews.com/lifestyle/luxury-gift-ideas-under-50](https://www.foxnews.com/lifestyle/luxury-gift-ideas-under-50)
 - RSS feed: $source
 - date published: 2024-12-04T12:14:41+00:00

Luxury gift giving isn&apos;t about the price tag. Provide luxury gifts to your recipients by way of aroma, neutral color palettes and style this holiday season.

## Fox News AI Newsletter: AI catches cancer that mammogram misses
 - [https://www.foxnews.com/tech/fox-news-ai-newsletter-ai-catches-cancer-mammogram-missed](https://www.foxnews.com/tech/fox-news-ai-newsletter-ai-catches-cancer-mammogram-missed)
 - RSS feed: $source
 - date published: 2024-12-04T11:57:22+00:00

Stay up to date on the latest AI technology advancements and learn about the challenges and opportunities AI presents now and for the future.

## Top House Democrat says Hunter Biden pardon was 'disappointing,' calls out Biden for flip-flop
 - [https://www.foxnews.com/politics/top-house-democrat-says-hunter-biden-pardon-disappointing-calls-out-biden-flip-flop](https://www.foxnews.com/politics/top-house-democrat-says-hunter-biden-pardon-disappointing-calls-out-biden-flip-flop)
 - RSS feed: $source
 - date published: 2024-12-04T11:50:23+00:00

Rep. Pete Aguilar says President Biden went back on his word when he pardoned his son, Hunter Biden.

## Incoming GOP Senate majority leader unveils legislative agenda for Trump administration's 1st 30 days
 - [https://www.foxnews.com/politics/incoming-gop-senate-majority-leader-unveils-agenda-trump-first-30-days](https://www.foxnews.com/politics/incoming-gop-senate-majority-leader-unveils-agenda-trump-first-30-days)
 - RSS feed: $source
 - date published: 2024-12-04T11:44:52+00:00

Sen. John Thune plans to make border security one of his first legislative focuses in 2025, the Republican told colleagues during a closed-door meeting on Tuesday.

## 'Young and the Restless' star holds second job as flight attendant to not ‘forget who’ she is
 - [https://www.foxnews.com/entertainment/young-restless-star-holds-second-job-flight-attendant-not-forget-who](https://www.foxnews.com/entertainment/young-restless-star-holds-second-job-flight-attendant-not-forget-who)
 - RSS feed: $source
 - date published: 2024-12-04T11:44:09+00:00

&quot;The Young and the Restless&quot; actress Kate Linder has appeared in more than 2,000 episodes of the show, but chooses to keep a second job.

## CNN data guru reports that Americans’ trust in the FBI is at its lowest point 'this century'
 - [https://www.foxnews.com/media/cnn-data-guru-reports-americans-trust-fbi-lowest-point-century](https://www.foxnews.com/media/cnn-data-guru-reports-americans-trust-fbi-lowest-point-century)
 - RSS feed: $source
 - date published: 2024-12-04T11:38:25+00:00

CNN senior data reporter Harry Enten broke down the FBI&apos;s approval numbers, showing that only 41 percent of Americans approve of the law enforcement agency in 2024.

## LPGA Tour updates gender-eligibility policy, bars 'players assigned male at birth'
 - [https://www.foxnews.com/sports/lpga-tour-updates-gender-eligibility-policy-bars-players-assigned-male-birth](https://www.foxnews.com/sports/lpga-tour-updates-gender-eligibility-policy-bars-players-assigned-male-birth)
 - RSS feed: $source
 - date published: 2024-12-04T11:29:38+00:00

The LPGA Tour on Wednesday announced an altercation to its gender-eligibility policy and will effectively prohibit transgender players from competing in events.

## Lakefront family massacre teen suspect's attorneys show possible defense, claim forensics show innocence
 - [https://www.foxnews.com/us/lakefront-family-massacre-teen-suspects-attorneys-show-possible-defense-claim-forensics-show-innocence](https://www.foxnews.com/us/lakefront-family-massacre-teen-suspects-attorneys-show-possible-defense-claim-forensics-show-innocence)
 - RSS feed: $source
 - date published: 2024-12-04T11:00:22+00:00

Attorneys for a 15-year-old accused of slaughtering his parents and siblings in their Washington state lakeside house have defended the teenager&apos;s narrative of what happened.

## These food gift baskets are all around $25 this holiday season
 - [https://www.foxnews.com/food-drink/food-gift-baskets-all-around-25-holiday-season](https://www.foxnews.com/food-drink/food-gift-baskets-all-around-25-holiday-season)
 - RSS feed: $source
 - date published: 2024-12-04T10:54:59+00:00

Here are three holiday gift ideas that won&apos;t break the bank this Christmas. These enticing food baskets are all priced at around $25 and make thoughtful gifts.

## John Elway, a Yankees draft pick, gets own baseball card with help from 'Seinfeld' co-creator Larry David
 - [https://www.foxnews.com/sports/john-elway-yankees-draft-pick-gets-own-baseball-card-help-from-seinfeld-co-creator-larry-david](https://www.foxnews.com/sports/john-elway-yankees-draft-pick-gets-own-baseball-card-help-from-seinfeld-co-creator-larry-david)
 - RSS feed: $source
 - date published: 2024-12-04T10:30:03+00:00

A new John Elway trading card has hit the market, but it&apos;s not one that relives his NFL glory days. The card shows Elway in a Yankees uniform.

## NFL legend demands league address 'weaponized quarterback slide' after Trevor Lawrence injury
 - [https://www.foxnews.com/sports/nfl-legend-demands-league-address-weaponized-quarterback-slide-after-trevor-lawrence-injury](https://www.foxnews.com/sports/nfl-legend-demands-league-address-weaponized-quarterback-slide-after-trevor-lawrence-injury)
 - RSS feed: $source
 - date published: 2024-12-04T10:28:20+00:00

Pro Football Hall of Famer Joe Thomas called on the NFL to address the &quot;weaponized quarterback slide&quot; after the Trevor Lawrence injury.

## Facebook Marketplace shoppers terrorized at gunpoint after teens lure victims with holiday gift items: police
 - [https://www.foxnews.com/us/facebook-marketplace-shoppers-terrorized-gunpoint-after-teens-lure-victims-holiday-gift-items-police](https://www.foxnews.com/us/facebook-marketplace-shoppers-terrorized-gunpoint-after-teens-lure-victims-holiday-gift-items-police)
 - RSS feed: $source
 - date published: 2024-12-04T10:11:43+00:00

Two Houston robbery suspects are on the run after allegedly staging Facebook Marketplace scams and then stealing money from victims at gunpoint, according to police.

## House GOP leaders endorse Trump-backed candidate Jimmy Patronis for Matt Gaetz's old seat
 - [https://www.foxnews.com/politics/house-gop-leaders-endorse-trump-backed-candidate-jimmy-patronis-matt-gaetzs-old-seat](https://www.foxnews.com/politics/house-gop-leaders-endorse-trump-backed-candidate-jimmy-patronis-matt-gaetzs-old-seat)
 - RSS feed: $source
 - date published: 2024-12-04T10:01:33+00:00

House Republican leaders endorse Florida CFO Jimmy Patronis, who is running to represent Florida&apos;s 1st Congressional District in Congress

## Bakery honors Christmas by recreating Nativity scene: 'Bread of life made from bread'
 - [https://www.foxnews.com/food-drink/bakery-christmas-recreates-nativity-scene-bread-life-made-bread](https://www.foxnews.com/food-drink/bakery-christmas-recreates-nativity-scene-bread-life-made-bread)
 - RSS feed: $source
 - date published: 2024-12-04T09:50:04+00:00

This Christmas season, a bakery in England has created a Nativity scene almost entirely made of bread. Baby Jesus, plus Mary and Joseph, are all represented in the display.

## Trump floats DeSantis as potential defense secretary replacement if Hegseth falters
 - [https://www.foxnews.com/politics/trump-floats-desantis-potential-defense-secretary-replacement-hegseth-falters](https://www.foxnews.com/politics/trump-floats-desantis-potential-defense-secretary-replacement-hegseth-falters)
 - RSS feed: $source
 - date published: 2024-12-04T09:44:48+00:00

President-elect Trump is considering nominating Republican Gov. Ron DeSantis of Florida as defense secretary to replace Pete Hegseth, Trump&apos;s embattled first pick to steer the Pentagon, according to sources

## Ted Cruz, GOP lawmakers urge SCOTUS to end 'Mexico's assault on our Second Amendment'
 - [https://www.foxnews.com/politics/ted-cruz-gop-lawmakers-urge-scotus-end-mexicos-assault-our-second-amendment](https://www.foxnews.com/politics/ted-cruz-gop-lawmakers-urge-scotus-end-mexicos-assault-our-second-amendment)
 - RSS feed: $source
 - date published: 2024-12-04T09:15:08+00:00

Sen. Ted Cruz, joined by other GOP Congress members, is urging the U.S. Supreme Court &quot;to uphold American Sovereignty and the Second Amendment&quot; in a new amicus filed in support of U.S. gun manufacturers.

## Dem Rep. Clyburn admits he urged Biden to pardon his son: ‘Needed to do this’
 - [https://www.foxnews.com/media/dem-rep-clyburn-admits-urged-biden-pardon-son-needed-this](https://www.foxnews.com/media/dem-rep-clyburn-admits-urged-biden-pardon-son-needed-this)
 - RSS feed: $source
 - date published: 2024-12-04T09:13:12+00:00

Rep. James Clyburn, D-S.C., revealed to CNN Tuesday night that he had urged President Biden to go through with pardoning his son despite the naysayers in their own party.

## ACC calls on CFP officials to rethink Miami's ranking after latest release: 'Absolutely deserves better'
 - [https://www.foxnews.com/sports/acc-calls-cfp-officials-rethink-miamis-ranking-after-latest-release-absolutely-deserves-better](https://www.foxnews.com/sports/acc-calls-cfp-officials-rethink-miamis-ranking-after-latest-release-absolutely-deserves-better)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:33+00:00

The Miami Hurricanes were left out of the bracket in the penultimate College Football Playoff rankings on Tuesday, drawing rebuke from the ACC.

## 10 items to heat up your outdoor patio in cold weather
 - [https://www.foxnews.com/lifestyle/patio-winter-ideas](https://www.foxnews.com/lifestyle/patio-winter-ideas)
 - RSS feed: $source
 - date published: 2024-12-04T08:57:43+00:00

Forget the winter cold with these 10 patio upgrades.

## American students face declines in math, science scores compared to international peers: Report
 - [https://www.foxnews.com/media/american-students-face-declines-math-science-scores-compared-international-peers-report](https://www.foxnews.com/media/american-students-face-declines-math-science-scores-compared-international-peers-report)
 - RSS feed: $source
 - date published: 2024-12-04T08:50:41+00:00

American fourth and eighth graders are struggling with math after COVID-19 prompted school closures across the country and started new trends in education.

## Archaeologists in Denmark discover over 100 weapons from the Iron Age during excavations
 - [https://www.foxnews.com/world/archaeologists-denmark-discover-over-100-weapons-from-iron-age-during-excavations](https://www.foxnews.com/world/archaeologists-denmark-discover-over-100-weapons-from-iron-age-during-excavations)
 - RSS feed: $source
 - date published: 2024-12-04T08:48:10+00:00

Archaeologists in Denmark unearthed what they&apos;ve suggested is a sacrifice of weapons. The weapons likely belonged to a powerful chieftain thousands of years ago.

## 2 American climbers go missing on New Zealand mountain
 - [https://www.foxnews.com/us/2-american-climbers-go-missing-new-zealand-mountain](https://www.foxnews.com/us/2-american-climbers-go-missing-new-zealand-mountain)
 - RSS feed: $source
 - date published: 2024-12-04T08:47:44+00:00

Two American mountain climbers and a Canadian climber are missing on Aoraki, also known as Mount Cook, the highest peak in New Zealand.

## California voters in Bay Area to decide fate of controversial sheriff
 - [https://www.foxnews.com/us/california-voters-bay-area-decide-fate-controversial-sheriff](https://www.foxnews.com/us/california-voters-bay-area-decide-fate-controversial-sheriff)
 - RSS feed: $source
 - date published: 2024-12-04T08:23:11+00:00

Voters will decide in March whether San Mateo County Sheriff Christina Corpus can be removed by the board of supervisors through a charter amendment.

## Iowa State, SMU ADs have war of words after latest CFP rankings: 'Stay off my lawn!'
 - [https://www.foxnews.com/sports/iowa-state-smu-ads-have-war-words-after-latest-cfp-rankings-stay-off-my-lawn](https://www.foxnews.com/sports/iowa-state-smu-ads-have-war-words-after-latest-cfp-rankings-stay-off-my-lawn)
 - RSS feed: $source
 - date published: 2024-12-04T08:22:52+00:00

Iowa State and SMU athletics directors went tit-for-tat on social media on Tuesday night following the penultimate College Football Playoff rankings.

## Pro golfers call on LPGA Tour to alter gender-eligibility policy amid leadership shakeup
 - [https://www.foxnews.com/sports/pro-golfers-call-lpga-tour-alter-gender-eligibility-policy-amid-leadership-shakeup](https://www.foxnews.com/sports/pro-golfers-call-lpga-tour-alter-gender-eligibility-policy-amid-leadership-shakeup)
 - RSS feed: $source
 - date published: 2024-12-04T07:56:20+00:00

Pro golfers called on the LPGA Tour to alter its gender-participation policy amid a sudden leadership shakeup before the start of the 2025 season.

## Freshman Focus: Republican Rob Bresnahan, who ousted six-term House Democrat, reveals how he did it
 - [https://www.foxnews.com/politics/freshman-focus-republican-rob-bresnahan-who-ousted-six-term-house-democrat-reveals-how-he-did](https://www.foxnews.com/politics/freshman-focus-republican-rob-bresnahan-who-ousted-six-term-house-democrat-reveals-how-he-did)
 - RSS feed: $source
 - date published: 2024-12-04T07:36:16+00:00

Rep.-elect Rob Bresnahan of Pennsylvania discusses his priorities for the next Congress with Fox News Digital after he unseated six-term incumbent Rep. Matt Cartwright.

## Jeffries wants Biden to dole out pardons for people aggressively prosecuted 'for nonviolent offenses'
 - [https://www.foxnews.com/politics/jeffries-wants-biden-dole-out-pardons-people-aggressively-prosecuted-for-nonviolent-offenses](https://www.foxnews.com/politics/jeffries-wants-biden-dole-out-pardons-people-aggressively-prosecuted-for-nonviolent-offenses)
 - RSS feed: $source
 - date published: 2024-12-04T07:24:18+00:00

House Democratic Leader Hakeem Jeffries wants President Joe Biden to pardon people who faced &quot;aggressive prosecutions for nonviolent offenses.&quot;

## Supreme Court can take massive step in preventing trans athletes in girls' sports with historic hearing
 - [https://www.foxnews.com/sports/supreme-court-can-strike-down-trans-in-girls-sports-medications-surgeries](https://www.foxnews.com/sports/supreme-court-can-strike-down-trans-in-girls-sports-medications-surgeries)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:56+00:00

The Supreme Court faces a decision that could help determine whether biological males will compete against female athletes for generations to come.

## Balance of Congress known as final House race called and more top headlines
 - [https://www.foxnews.com/us/balance-congress-known-final-house-race-called-more-top-headlines](https://www.foxnews.com/us/balance-congress-known-final-house-race-called-more-top-headlines)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:55+00:00

Get all the stories you need-to-know from the most powerful name in news delivered first thing every morning to your inbox.

## Elon and Vivek should tackle US funding for this boondoogle organization and score a multimillion dollar win
 - [https://www.foxnews.com/opinion/elon-vivek-should-tackle-us-funding-boondoogle-organization-score-multimillion-dollar-win](https://www.foxnews.com/opinion/elon-vivek-should-tackle-us-funding-boondoogle-organization-score-multimillion-dollar-win)
 - RSS feed: $source
 - date published: 2024-12-04T07:00:43+00:00

Congress has long been skeptical about U.N. uses of American money, so much so that they have insisted upon an annual report on “United States Participation in the United Nations.&quot;

## Trump transition signs agreement for FBI background checks
 - [https://www.foxnews.com/politics/trump-transition-signs-agreement-fbi-background-checks](https://www.foxnews.com/politics/trump-transition-signs-agreement-fbi-background-checks)
 - RSS feed: $source
 - date published: 2024-12-04T06:57:29+00:00

President Trump&apos;s transition team has agreed to allow the FBI to vet incoming cabinet nominees with background checks, they announced Tuesday.

## Auburn's Bruce Pearl applauds NYC mayor's message to critics over desire to meet with incoming border czar
 - [https://www.foxnews.com/sports/auburns-bruce-pearl-applauds-nyc-mayors-message-critics-over-desire-meet-incoming-border-czar](https://www.foxnews.com/sports/auburns-bruce-pearl-applauds-nyc-mayors-message-critics-over-desire-meet-incoming-border-czar)
 - RSS feed: $source
 - date published: 2024-12-04T06:54:50+00:00

Auburn Tigers men&apos;s basketball coach Bruce Pearl applauded New York City Mayor Eric Adams for challenging critics over his desire to meet with President-elect Donald Trump&apos;s border czar.

## ACLU lawyer defends trans procedures for minors despite acknowledging 'it's not the kids who are consenting'
 - [https://www.foxnews.com/media/aclu-lawyer-defends-trans-procedures-minors-despite-acknowledging-its-not-kids-who-consenting](https://www.foxnews.com/media/aclu-lawyer-defends-trans-procedures-minors-despite-acknowledging-its-not-kids-who-consenting)
 - RSS feed: $source
 - date published: 2024-12-04T06:38:24+00:00

Lawyer and transgender activist Chase Strangio told CNN’s Jake Tapper Tuesday that kids don&apos;t consent to gender transition treatments, their parents do.

## Al Sharpton's interview scandal becomes latest in decades-long history of controversies haunting MSNBC host
 - [https://www.foxnews.com/media/al-sharptons-interview-scandal-becomes-latest-decades-long-history-controversies-haunting-msnbc-host](https://www.foxnews.com/media/al-sharptons-interview-scandal-becomes-latest-decades-long-history-controversies-haunting-msnbc-host)
 - RSS feed: $source
 - date published: 2024-12-04T06:00:55+00:00

MSNBC&apos;s Rev. Al Sharpton had a long history of scandals and controversies with the &quot;pay for play&quot; allegations with the Harris campaign being the latest.

## 5 wild ways Democrats have embraced the Monty Python strategy of politics
 - [https://www.foxnews.com/opinion/5-wild-ways-democrats-have-embraced-monty-python-strategy-politics](https://www.foxnews.com/opinion/5-wild-ways-democrats-have-embraced-monty-python-strategy-politics)
 - RSS feed: $source
 - date published: 2024-12-04T05:49:27+00:00

Rather than accept President-elect Trump&apos;s election victory and try to move forward, leftists and the journalists who love them are choosing another option – running away.

## Students at Ohio elementary school can participate in Satanic Temple's religious learning program
 - [https://www.foxnews.com/us/students-ohio-elementary-school-can-participate-satanic-temples-religious-learning-program](https://www.foxnews.com/us/students-ohio-elementary-school-can-participate-satanic-temples-religious-learning-program)
 - RSS feed: $source
 - date published: 2024-12-04T05:45:11+00:00

The Satanic Temple is offering religious learning instruction to students at an Ohio elementary school as part of the state&apos;s religious release program.

## Before Biden pardoned Hunter, the media speculated Trump would pardon his children ahead of leaving office
 - [https://www.foxnews.com/media/before-biden-pardoned-hunter-media-speculated-trump-would-pardon-his-children-ahead-leaving-office](https://www.foxnews.com/media/before-biden-pardoned-hunter-media-speculated-trump-would-pardon-his-children-ahead-leaving-office)
 - RSS feed: $source
 - date published: 2024-12-04T05:00:26+00:00

Four years before President Biden issued a pardon for his son Hunter, the media hyped speculation that then-President Trump would issue premptive pardons for his own children.

## The simple solution to the ‘Californication’ of American energy policy
 - [https://www.foxnews.com/opinion/the-simple-solution-to-the-californication-american-energy-policy](https://www.foxnews.com/opinion/the-simple-solution-to-the-californication-american-energy-policy)
 - RSS feed: $source
 - date published: 2024-12-04T05:00:22+00:00

President-elect Trump and California Gov. Newsom are polar opposites on power production: Trump represents a mindset of energy abundance while Newsom represents one of energy scarcity.

## These fish are the best and worst for your health, say experts
 - [https://www.foxnews.com/food-drink/fish-best-worst-your-health-say-experts](https://www.foxnews.com/food-drink/fish-best-worst-your-health-say-experts)
 - RSS feed: $source
 - date published: 2024-12-04T05:00:14+00:00

Experts offer a list of the fish that have the most health benefits — from salmon and sardines to tilapia and tuna — plus which fish to avoid and why.

## Doctor and cancer survivor gears up to run 7 marathons on 7 continents in 7 days
 - [https://www.foxnews.com/health/doctor-cancer-survivor-gears-up-run-marathons-continents-days](https://www.foxnews.com/health/doctor-cancer-survivor-gears-up-run-marathons-continents-days)
 - RSS feed: $source
 - date published: 2024-12-04T04:30:37+00:00

Dr. T. Clark Gamblin, a Wisconsin doctor and cancer survivor, spoke with Fox News Digital about his plans to run in the World Marathon Challenge, from Antarctica to Miami, starting on Jan. 31.

## College students killed in fiery Cybertruck accident day before Thanksgiving
 - [https://www.foxnews.com/us/college-students-killed-fiery-cybertruck-accident-day-before-thanksgiving](https://www.foxnews.com/us/college-students-killed-fiery-cybertruck-accident-day-before-thanksgiving)
 - RSS feed: $source
 - date published: 2024-12-04T03:38:16+00:00

Three recent graduates of Piedmont High School tragically lost their lives in a fiery crash the day before Thanksgiving and the city of Piedmont released their names Tuesday.

## Oregon prosecutor slams 'leniency' of state law protecting man convicted of 13-year-old girl's rape, murder
 - [https://www.foxnews.com/us/oregon-prosecutor-slams-leniency-state-law-protecting-man-convicted-13-year-old-girls-rape-murder](https://www.foxnews.com/us/oregon-prosecutor-slams-leniency-state-law-protecting-man-convicted-13-year-old-girls-rape-murder)
 - RSS feed: $source
 - date published: 2024-12-04T03:31:22+00:00

A prosecutor is criticizing an Oregon law that would significantly reduce prison time for a man, 18, was sentenced to life for the rape and murder of a 13-year-old girl.

## South Korean leader facing mounting calls to resign or be impeached over martial law
 - [https://www.foxnews.com/world/south-korean-leader-facing-mounting-calls-resign-impeached-over-martial-law](https://www.foxnews.com/world/south-korean-leader-facing-mounting-calls-resign-impeached-over-martial-law)
 - RSS feed: $source
 - date published: 2024-12-04T02:15:31+00:00

South Korean President Yoon Suk Yeol is facing pressure from legislators and the public to step down or be impeached after he ended a martial law.

## Federal judge accuses President Biden of attempting to 'rewrite history' in Hunter Biden pardon
 - [https://www.foxnews.com/politics/federal-judge-accuses-president-biden-attempting-rewrite-history-hunter-biden-pardon](https://www.foxnews.com/politics/federal-judge-accuses-president-biden-attempting-rewrite-history-hunter-biden-pardon)
 - RSS feed: $source
 - date published: 2024-12-04T00:23:39+00:00

U.S. District Judge Mark Scarsi issued a scathing rebuke of President Biden&apos;s claim that his son, Hunter Biden, was unfairly treated during his criminal tax case.

## Florida man attempting to purchase crack on Craigslist busted by undercover cop who responded to ad
 - [https://www.foxnews.com/us/florida-man-attempting-purchase-crack-craigslist-busted-undercover-cop-who-responded-ad](https://www.foxnews.com/us/florida-man-attempting-purchase-crack-craigslist-busted-undercover-cop-who-responded-ad)
 - RSS feed: $source
 - date published: 2024-12-04T00:13:54+00:00

A Florida man found himself behind bars after his Craigslist post searching for &quot;ice or crack&quot; was answered by an undercover investigator.

