# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## AMD’s upcoming RX 8800 could be a lot better than expected
 - [https://www.digitaltrends.com/computing/amd-rdna-4-announcement-specs-gpus](https://www.digitaltrends.com/computing/amd-rdna-4-announcement-specs-gpus)
 - RSS feed: $source
 - date published: 2024-12-04T15:27:56.510053+00:00

AMD's RDNA 4 is just around the corner, and we now got some more hints as to which GPUs are on the way and the kind of performance they might offer.

