# Source:Second Wind, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1wZGocgLvopgOqBUFCyIJA, language:en

## Is the Original PlayStation a Top-Tier Console? | Firelink Podcast
 - [https://www.youtube.com/watch?v=VH9jQWSfsEc](https://www.youtube.com/watch?v=VH9jQWSfsEc)
 - RSS feed: $source
 - date published: 2024-12-04T22:36:56+00:00

This video is brought to you by Lord Ambermaze, an upcoming adventure-RPG where each of your individual steps controls the flow of time. Head on over to the Steam page now to Wishlist it and play a free prologue today – https://store.steampowered.com/app/1811330/Lord_Ambermaze/

This week on Firelink, Marty, Nick, and KC celebrate the 30th anniversary of the original PlayStation. HBD lil' guy!

Support us on Patreon: https://www.patreon.com/SecondWindGroup

## Slitterhead | Fully Ramblomatic
 - [https://www.youtube.com/watch?v=hBDELWLfN-8](https://www.youtube.com/watch?v=hBDELWLfN-8)
 - RSS feed: $source
 - date published: 2024-12-04T17:00:53+00:00

This week on Fully Ramblomatic, Yahtzee reviews Slitterhead.

Support us on Patreon: https://www.patreon.com/SecondWindGroup

Second Wind Merch Store: https://sharkrobot.com/collections/second-wind

## Yahtzee Tries... Antonblast and Get To Work
 - [https://www.youtube.com/watch?v=pHtKD5c7qzo](https://www.youtube.com/watch?v=pHtKD5c7qzo)
 - RSS feed: $source
 - date published: 2024-12-04T16:12:24+00:00

This video is brought to you by Lord Ambermaze, an upcoming adventure-RPG where each of your individual steps controls the flow of time. Head on over to the Steam page now to Wishlist it and play a free prologue today – https://store.steampowered.com/app/1811330/Lord_Ambermaze/

This week on Yahtzee Tries... Yahtzee and JM8 play Antonblast and Get To Work.

Support us on Patreon: https://www.patreon.com/SecondWindGroup

https://store.steampowered.com/app/1887400/ANTONBLAST/
https://store.steampowered.com/app/2706170/Get_To_Work/

