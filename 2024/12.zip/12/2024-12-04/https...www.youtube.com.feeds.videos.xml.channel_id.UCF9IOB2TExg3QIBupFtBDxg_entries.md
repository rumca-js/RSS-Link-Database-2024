# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## WHO full rethink
 - [https://www.youtube.com/watch?v=YyfgBnBKOc4](https://www.youtube.com/watch?v=YyfgBnBKOc4)
 - RSS feed: $source
 - date published: 2024-12-04T09:03:01+00:00

Action on World Health (AWH). An independent review into the WHO.

https://www.actionwh.org

Trump can seize back control of health policy from WHO

https://www.telegraph.co.uk/news/2024/12/02/farage-trump-seize-back-control-health-policy-who/

Mr Farage is the chairman of Action on World Health (AWH)

https://www.actionwh.org

“once in a generation” chance to seize back control of health policy from the World Health Organisation

Mr Trump (May 2020)

https://www.telegraph.co.uk/news/2020/05/29/donald-trump-says-us-terminating-relationship-world-health-organisation/

“terminating” America’s relationship with WHO

“China has total control over the World Health Organisation.”

(Had previously paused funding to WHO)

https://www.who.int/about/funding/contributors/usa

 

"Because they have failed to make the requested and greatly needed reforms, we will be today terminating the relationship."

Process to end US membership, reversed by Mr. Biden.

Back to 2024

Mr Farage

Believes Mr Tru

