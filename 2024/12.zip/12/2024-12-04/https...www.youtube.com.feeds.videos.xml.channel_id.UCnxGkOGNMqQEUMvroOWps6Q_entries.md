# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## "The Sheriff of Baghdad" on Seeing Evil in Iraq and Shows Joe Saddam Hussein's Hat
 - [https://www.youtube.com/watch?v=oHt_C19YKBE](https://www.youtube.com/watch?v=oHt_C19YKBE)
 - RSS feed: $source
 - date published: 2024-12-04T18:00:36+00:00

JRE #2238 w/John McPhee
YouTube: https://youtu.be/8E1hrK77GLI
JRE on Spotify: https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk

