# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Dodatkowy przelew dla miliona emerytów. To czeka seniorów w grudniu
 - [https://www.money.pl/emerytury/dodatkowy-przelew-dla-miliona-emerytow-to-czeka-seniorow-w-grudniu-7099757083396225a.html](https://www.money.pl/emerytury/dodatkowy-przelew-dla-miliona-emerytow-to-czeka-seniorow-w-grudniu-7099757083396225a.html)
 - RSS feed: $source
 - date published: 2024-12-04T19:49:42.894205+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e5659981-6fb3-4048-9039-8eea1c302a66" width="308" /> W grudniu emeryci mogą oczekiwać zmian w harmonogramie wypłat z ZUS w związku z nadchodzącymi świętami Bożego Narodzenia. Szczególnie uprzywilejowane będą osoby otrzymujące świadczenia już 1. dnia każdego miesiąca, co sprawi, że dodatkowy przelew otrzyma aż milion osób. 

## Zasiłki dla powodzian. Wiemy, ile rodzin otrzymało pieniądze
 - [https://www.money.pl/pieniadze/zasilki-dla-powodzian-wiemy-ile-rodzin-otrzymalo-pieniadze-7099716885269120a.html](https://www.money.pl/pieniadze/zasilki-dla-powodzian-wiemy-ile-rodzin-otrzymalo-pieniadze-7099716885269120a.html)
 - RSS feed: $source
 - date published: 2024-12-04T19:44:40+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/01fb036e-342b-444e-a03d-1ff727b667c1" width="308" /> Do 4 grudnia w ramach zasiłków powodziowych i doraźnych wypłacono ponad 331,2 mln zł dla ponad 125 tys. poszkodowanych rodzin - poinformowało nas Ministerstwo Spraw Wewnętrznych i Administracji. Więcej pieniędzy przeznaczono na zasiłki remontowo-budowlane. 

## Podpis ministra uratował ogródki przed deweloperami? "Radykalna zmiana"
 - [https://www.money.pl/gospodarka/podpis-ministra-uratowal-ogrodki-przed-deweloperami-radykalna-zmiana-7099693447346816a.html](https://www.money.pl/gospodarka/podpis-ministra-uratowal-ogrodki-przed-deweloperami-radykalna-zmiana-7099693447346816a.html)
 - RSS feed: $source
 - date published: 2024-12-04T18:44:23.426401+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/38fa7b13-3844-4f1c-82fe-44508e1e3c00" width="308" /> "Postulat działkowców spełniony. Podpisałem nowelizację" - ogłosił minister rozwoju Krzysztof Paszyk. Ogrody działkowe będą brane pod uwagę w planach zagospodarowania przestrzennego. - Zabezpieczy to ogródki przed niekontrolowaną likwidacją - ocenia Jarosław Jędrzyński, ekspert portalu RynekPierwotny.pl. 

## Brian Thompson, prezes medycznego giganta, zastrzelony na Manhattanie
 - [https://www.money.pl/ubezpieczenia/brian-thompson-prezes-medycznego-giganta-zastrzelony-na-manhattanie-7099727237241472a.html](https://www.money.pl/ubezpieczenia/brian-thompson-prezes-medycznego-giganta-zastrzelony-na-manhattanie-7099727237241472a.html)
 - RSS feed: $source
 - date published: 2024-12-04T17:39:40.006920+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7040cb19-a955-4acf-a77a-1b8a04de93f0" width="308" /> Nie żyje Brian Thompson, 50-letni dyrektor generalny medycznego giganta UnitedHealthcare. Mężczyznę zastrzelono w środę przed New York Hilton Midtown na Manhattanie, gdzie firma organizowała dzień inwestora - informuje CBS. 

## Zatrudniają 160 tys. osób na całym świecie. Amerykański gigant zapowiedział wielkie zwolnienia
 - [https://www.money.pl/gospodarka/zatrudniaja-160-tys-osob-na-calym-swiecie-amerykanski-gigant-zapowiedzial-wielkie-zwolnienia-7099696671541888a.html](https://www.money.pl/gospodarka/zatrudniaja-160-tys-osob-na-calym-swiecie-amerykanski-gigant-zapowiedzial-wielkie-zwolnienia-7099696671541888a.html)
 - RSS feed: $source
 - date published: 2024-12-04T16:35:20.804859+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4479e76b-bc85-4984-80c4-90dac9e6c8dc" width="308" /> Cargill, czyli największa prywatna firma w Stanach Zjednoczonych zwolni tysiące pracowników. Problemy producenta żywności mają wynikać z niższych cen produktów. W efekcie zwolnionych zostanie nawet 8 tys. osób. Firma zatrudnia też w Polsce. 

## To ostatni moment na skorzystanie z tej ulgi podatkowej
 - [https://www.money.pl/emerytury/to-ostatni-moment-na-skorzystanie-z-tej-ulgi-podatkowej-7099656231152288a.html](https://www.money.pl/emerytury/to-ostatni-moment-na-skorzystanie-z-tej-ulgi-podatkowej-7099656231152288a.html)
 - RSS feed: $source
 - date published: 2024-12-04T14:24:52.853568+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d0ca78bd-95bb-4f35-b43d-3337e2333ecf" width="308" /> Atrakcyjna ulga podatkowa, a przy tym świetna forma zabezpieczenia na przyszłość? Tym wyróżnia się IKZE, czyli specjalne konto emerytalne, które daje możliwość odkładania na emeryturę i coroczną ulgę podatkową. Dlaczego warto zainteresować się nimi właśnie teraz, a nie po 1 stycznia? Powód jest prosty – wpłaty na IKZE w danym roku można odliczyć od dochodu i dzięki temu zapłacić mniejszy podatek PIT lub zyskać zwrot od fiskusa. 

## Nie wszędzie zwalniają. Co druga firma planuje podwyżki
 - [https://www.money.pl/gospodarka/nie-wszedzie-zwalniaja-co-druga-firma-planuje-podwyzki-7099678271109792a.html](https://www.money.pl/gospodarka/nie-wszedzie-zwalniaja-co-druga-firma-planuje-podwyzki-7099678271109792a.html)
 - RSS feed: $source
 - date published: 2024-12-04T14:24:52.591354+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/aab174b4-df82-4e08-af2a-63afe6db733a" width="308" /> Odsetek firm planujących nowe rekrutacje wzrósł w ujęciu rocznym do 28 proc., wskazuje to na pozytywną zmianę w podejściu pracodawców, którzy dostrzegają konieczność wzmacniania zespołów - ocenił Robert Lisicki z Konfederacji Lewiatan, komentując badanie Instytutu Badawczego Randstad. Co druga firma planuje podwyżki. 

## Teksas już się pali do pomocy. Stan sonduje pomysł z "cesarzem granicy"
 - [https://www.money.pl/gospodarka/obozy-wzdluz-rio-grande-teksas-sonduje-pomysl-z-cesarzem-granicy-7099660840348288a.html](https://www.money.pl/gospodarka/obozy-wzdluz-rio-grande-teksas-sonduje-pomysl-z-cesarzem-granicy-7099660840348288a.html)
 - RSS feed: $source
 - date published: 2024-12-04T13:19:46.011058+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/48492282-ff93-4949-a346-fc93a000f0f0" width="308" /> Administracja Trumpa i władze Teksasu rozważają budowę ośrodków deportacyjnych na zakupionej ziemi wzdłuż Rio Grande. Rozmowy z przyszłą administracją Trumpa dotyczą wykorzystania zasobów wojskowych do transportu migrantów i budowy infrastruktury. 

## Czesi szturmują polskie targowiska. Oto ich faworyt
 - [https://www.money.pl/gospodarka/czesi-szturmuja-polskie-targowiska-oto-ich-faworyt-7099638255700640a.html](https://www.money.pl/gospodarka/czesi-szturmuja-polskie-targowiska-oto-ich-faworyt-7099638255700640a.html)
 - RSS feed: $source
 - date published: 2024-12-04T12:14:29.867496+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2d27212b-88b6-4103-81bc-3caff94651b7" width="308" /> Czesi masowo odwiedzają polskie targowiska, szukając tańszych produktów przed Bożym Narodzeniem. Wysokie ceny w Czechach skłaniają ich do zakupów w Polsce, szczególnie w Kudowie-Zdroju. Oszczędności sięgają nawet 340 zł - informuje Business Insider Polska, powołując się czeskie CNN Prima News. 

## Tąpnięcie na rynku. Deweloperzy sprzedali o 26 proc. mniej mieszkań
 - [https://www.money.pl/gospodarka/tapniecie-na-rynku-deweloperzy-sprzedali-o-26-proc-mniej-mieszkan-7099622356847264a.html](https://www.money.pl/gospodarka/tapniecie-na-rynku-deweloperzy-sprzedali-o-26-proc-mniej-mieszkan-7099622356847264a.html)
 - RSS feed: $source
 - date published: 2024-12-04T11:09:30.011112+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/46481d5e-d9d5-47b9-bf08-4b3a5229248b" width="308" /> W Katowicach, Krakowie, Łodzi, Poznaniu, Trójmieście, Warszawie i we Wrocławiu w tym roku deweloperzy sprzedali o 26 proc. mniej mieszkań niż w tym samym czasie 2023 r. - wynika z opublikowanego w środę raportu. Listopad był kolejnym miesiącem z rzędu, w którym podaż była większa od popytu. 

## Mandat za zakręcony kaloryfer? Oto co mówi prawo
 - [https://www.money.pl/gospodarka/mandat-za-zakrecony-kaloryfer-oto-co-mowi-prawo-7099629697555072a.html](https://www.money.pl/gospodarka/mandat-za-zakrecony-kaloryfer-oto-co-mowi-prawo-7099629697555072a.html)
 - RSS feed: $source
 - date published: 2024-12-04T11:09:29.460826+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/943fb085-2ac1-4229-9da8-b71b95351999" width="308" /> W mediach pojawiły się doniesienia o karach za zakręcone grzejniki i kontrolach przeprowadzanych przez spółdzielnie mieszkaniowe. Czy spółdzielnie faktycznie prowadzą takie działania i czy można, dostać 500 zł mandatu za oszczędzanie ogrzewania? Wyjaśniamy. 

## Kryzys we Francji, Korei, Gruzji. Tak chaos może uderzyć w polską gospodarkę
 - [https://www.money.pl/gospodarka/kryzys-we-francji-korei-gruzji-tak-chaos-moze-uderzyc-w-polska-gospodarke-7099605184211616a.html](https://www.money.pl/gospodarka/kryzys-we-francji-korei-gruzji-tak-chaos-moze-uderzyc-w-polska-gospodarke-7099605184211616a.html)
 - RSS feed: $source
 - date published: 2024-12-04T09:58:16+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/36dca4b1-9f1e-439f-9be2-7ac1344d68d3" width="308" /> Kryzys polityczny w Korei Południowej wywołał gwałtowne reakcje na rynkach finansowych całego regionu. Niespokojnie jest też w Gruzji, w obliczu nowego kryzysu politycznego staje także Francja. Czy rosnący chaos jest zagrożeniem dla polskiej gospodarki? Analizują to eksperci XTB. 

## Tak azjatyckie rynki reagują na polityczny kryzys w Korei Południowej
 - [https://www.money.pl/gielda/tak-azjatyckie-rynki-reaguja-na-polityczny-kryzys-w-korei-poludniowej-7099601148029568a.html](https://www.money.pl/gielda/tak-azjatyckie-rynki-reaguja-na-polityczny-kryzys-w-korei-poludniowej-7099601148029568a.html)
 - RSS feed: $source
 - date published: 2024-12-04T09:35:12+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/90bc9f9a-c286-4d2e-a70d-d61ba49f67e1" width="308" /> Południowokoreański kryzys konstytucyjny wywołuje znaczące turbulencje na rynkach finansowych regionu, prowadząc do istotnych wahań na giełdach i rynku walutowym. Won odnotował jedno z największych osłabień względem dolara na przestrzeni kilku lat, częściowo jednak odrobił straty. Co dalej? 

## Nagły skok cen ropy. Co zrobi OPEC?
 - [https://www.money.pl/gielda/nagly-skok-cen-ropy-co-zrobi-opec-7099574776916608a.html](https://www.money.pl/gielda/nagly-skok-cen-ropy-co-zrobi-opec-7099574776916608a.html)
 - RSS feed: $source
 - date published: 2024-12-04T07:54:03.810708+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/dc1477e5-907a-47ac-975a-cb204408ed09" width="308" /> Ceny ropy na giełdzie paliw w Nowym Jorku zaliczyły we wtorek najmocniejszy wzrost od ponad 2 tygodni i dalej idą w górę. Inwestorzy czekają na decyzję w sprawie planów produkcyjnych krajów sojuszu OPEC+, które w czwartek odbędą wirtualne posiedzenie - informują maklerzy. 

## 170 mln zł od Orlenu dla PZPN. Ujawniają szczegóły rekordowego kontraktu
 - [https://www.money.pl/gospodarka/170-mln-zl-od-orlenu-dla-pzpn-ujawniaja-szczegoly-rekordowego-kontraktu-7099578721028768a.html](https://www.money.pl/gospodarka/170-mln-zl-od-orlenu-dla-pzpn-ujawniaja-szczegoly-rekordowego-kontraktu-7099578721028768a.html)
 - RSS feed: $source
 - date published: 2024-12-04T07:54:03.698464+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b338bc0e-7ee0-483a-ab0f-40c565cc46d5" width="308" /> Onet ujawnia szczegóły umowy sponsorskiej między Orlenem a PZPN. Kontrakt opiewa na 170 mln zł, z czego 134 mln zł to kwota gwarantowana. Dodatkowe 36 mln zł zależy od wyników sportowych. Jak przekonuje portal umowa, podpisana w styczniu ubiegłego roku, była dotąd pilnie strzeżona. 

## Rząd ma problem ze sztandarowym pomysłem PiS. "Tworzymy podmiot, który jest bankrutem"
 - [https://www.money.pl/gospodarka/rzad-ma-problem-ze-sztandarowym-pomyslem-pis-tworzymy-podmiot-ktory-jest-bankrutem-7099570473757344a.html](https://www.money.pl/gospodarka/rzad-ma-problem-ze-sztandarowym-pomyslem-pis-tworzymy-podmiot-ktory-jest-bankrutem-7099570473757344a.html)
 - RSS feed: $source
 - date published: 2024-12-04T07:51:32+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/27f4fca3-79dc-4b76-a2d7-87c0f37e7451" width="308" /> Rząd rozważa  wycofanie się z pomysłu PiS, a dotyczącego  przekazania aktywów węglowych spółek do NABE. - Żeby NABE funkcjonowało, to państwo musiałoby do niego dopłacać - przekonuje w rozmowie z Business Insider Polska minister aktywów państwowych Jakub Jaworowski. 

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 04.12.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-04-12-2024-7099564256885408a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-04-12-2024-7099564256885408a.html)
 - RSS feed: $source
 - date published: 2024-12-04T06:49:26.622484+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 04.12.2024. W środę za jednego dolara (USD) trzeba zapłacić 4.0804 zł. 

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 04.12.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-04-12-2024-7099564256914080a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-04-12-2024-7099564256914080a.html)
 - RSS feed: $source
 - date published: 2024-12-04T06:49:26.366844+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 04.12.2024. W środę za jednego franka (CHF) trzeba zapłacić 4.6062 zł. 

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 04.12.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-04-12-2024-7099564992228000a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-04-12-2024-7099564992228000a.html)
 - RSS feed: $source
 - date published: 2024-12-04T06:49:26.105494+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 04.12.2024. W środę za jedno euro (EUR) trzeba zapłacić 4.2917 zł. 

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 04.12.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-04-12-2024-7099568689003136a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-04-12-2024-7099568689003136a.html)
 - RSS feed: $source
 - date published: 2024-12-04T06:49:25.833805+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 04.12.2024. W środę za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.1786 zł. 

## Nawet 1,4 tys. zł większa emerytura. ZUS ma nowe wyliczenia dla tysięcy seniorów
 - [https://www.money.pl/emerytury/nawet-1-4-tys-zl-wieksza-emerytura-zus-ma-nowe-wyliczenia-dla-tysiecy-seniorow-7099563539245728a.html](https://www.money.pl/emerytury/nawet-1-4-tys-zl-wieksza-emerytura-zus-ma-nowe-wyliczenia-dla-tysiecy-seniorow-7099563539245728a.html)
 - RSS feed: $source
 - date published: 2024-12-04T06:49:25.460259+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/60093149-ae22-4c6e-b27e-2f7f39b0fedd" width="308" /> Prawie 200 tys. seniorów czeka na zmianę przepisów dotyczących wcześniejszych emerytur. "Fakt" informuje, że chodzi o podwyższenie emerytury nawet o 1,4 tys. zł. Do tego dochodzi 79 tys. zł wyrównania. Wyrok Trybunału Konstytucyjnego w tej sprawie wciąż nie został opublikowany. 

## Trump chce, by miliarder z branży zbrojeniowej został wiceszefem Pentagonu
 - [https://www.money.pl/gospodarka/trump-chce-by-miliarder-z-branzy-zbrojeniowej-zostal-wiceszefem-pentagonu-7099547365898912a.html](https://www.money.pl/gospodarka/trump-chce-by-miliarder-z-branzy-zbrojeniowej-zostal-wiceszefem-pentagonu-7099547365898912a.html)
 - RSS feed: $source
 - date published: 2024-12-04T05:44:01.101482+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/00083b4b-134a-4436-afd1-cf87cb6be1f4" width="308" /> Prezydent elekt Donald Trump zaoferował miliarderowi Stephenowi Feinbergowi posadę zastępcy sekretarza obrony - podał we wtorek "Washington Post". Feinberg był właścicielem firmy z sektora zbrojeniowego DynCorp i inwestował w rozwój pocisków hipersonicznych. 

## System kaucyjny jeszcze później? Komisje senackie zdecydowały
 - [https://www.money.pl/gospodarka/system-kaucyjny-jeszcze-pozniej-komisje-senackie-zdecydowaly-7099551849122432a.html](https://www.money.pl/gospodarka/system-kaucyjny-jeszcze-pozniej-komisje-senackie-zdecydowaly-7099551849122432a.html)
 - RSS feed: $source
 - date published: 2024-12-04T05:44:00.986738+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/32fb1d91-2187-4598-84c2-778f1eec6e28" width="308" /> Senackie komisje gospodarki i klimatu zaproponowały odsunięcie o trzy miesiące - do stycznia 2026 r. początku działania systemu kaucyjnego. Nowelizacja ustawy o gospodarce opakowaniami trafi teraz pod obrady całego Senatu. 

## Kursy walut 04.12.2024. Środowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kopia-kopia-kopia-kursy-walut-14-11-2024-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-7099555947727520a.html](https://www.money.pl/pieniadze/kopia-kopia-kopia-kursy-walut-14-11-2024-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-7099555947727520a.html)
 - RSS feed: $source
 - date published: 2024-12-04T05:44:00.875530+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/183881f7-a666-4129-a751-e4034862f0e8" width="308" /> Kursy walut - 04.12.2024. W środę za jednego dolara (USD) zapłacimy 4,08 zł. Cena jednego funta szterlinga (GBP) to 5,18 zł, a franka szwajcarskiego (CHF) 4,60 zł. Z kolei euro (EUR) możemy zakupić za 4,29 zł. 

