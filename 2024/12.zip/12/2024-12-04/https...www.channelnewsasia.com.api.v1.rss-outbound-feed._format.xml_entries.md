# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## Mbappe misses another penalty as Real Madrid are shocked at Bilbao
 - [https://www.channelnewsasia.com/sport/mbappe-misses-another-penalty-real-madrid-slump-bilbao-4787881](https://www.channelnewsasia.com/sport/mbappe-misses-another-penalty-real-madrid-slump-bilbao-4787881)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:37.933490+00:00

None

## Corner kings Arsenal earn 2-0 win over Manchester United
 - [https://www.channelnewsasia.com/sport/corner-kings-arsenal-earn-2-0-win-over-manchester-united-4787891](https://www.channelnewsasia.com/sport/corner-kings-arsenal-earn-2-0-win-over-manchester-united-4787891)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:37.658073+00:00

None

## Alpine skiing-Shiffrin back home and resting after crash
 - [https://www.channelnewsasia.com/sport/alpine-skiing-shiffrin-back-home-and-resting-after-crash-4787926](https://www.channelnewsasia.com/sport/alpine-skiing-shiffrin-back-home-and-resting-after-crash-4787926)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:37.386490+00:00

None

## Villa end winless run with nervy win over Brentford
 - [https://www.channelnewsasia.com/sport/villa-end-winless-run-nervy-win-over-brentford-4787921](https://www.channelnewsasia.com/sport/villa-end-winless-run-nervy-win-over-brentford-4787921)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:37.114093+00:00

None

## Musk's xAI plans massive expansion of AI supercomputer in Memphis
 - [https://www.channelnewsasia.com/business/musks-xai-plans-massive-expansion-ai-supercomputer-memphis-4787966](https://www.channelnewsasia.com/business/musks-xai-plans-massive-expansion-ai-supercomputer-memphis-4787966)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:36.792296+00:00

None

## We need to help De Bruyne through tough schedule, says Guardiola
 - [https://www.channelnewsasia.com/sport/we-need-help-de-bruyne-through-tough-schedule-says-guardiola-4787986](https://www.channelnewsasia.com/sport/we-need-help-de-bruyne-through-tough-schedule-says-guardiola-4787986)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:36.492589+00:00

None

## Keeping fans happy is Chelsea's aim, says Maresca
 - [https://www.channelnewsasia.com/sport/keeping-fans-happy-chelseas-aim-says-maresca-4788011](https://www.channelnewsasia.com/sport/keeping-fans-happy-chelseas-aim-says-maresca-4788011)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:36.215332+00:00

None

## Mbappe not at his best, but working to improve - Ancelotti
 - [https://www.channelnewsasia.com/sport/mbappe-not-his-best-working-improve-ancelotti-4788006](https://www.channelnewsasia.com/sport/mbappe-not-his-best-working-improve-ancelotti-4788006)
 - RSS feed: $source
 - date published: 2024-12-04T23:18:35.885250+00:00

None

## Powell 'not concerned' US Fed would lose independence under Trump
 - [https://www.channelnewsasia.com/world/us-federal-reserve-jerome-powell-independence-over-trump-4787751](https://www.channelnewsasia.com/world/us-federal-reserve-jerome-powell-independence-over-trump-4787751)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:30.815083+00:00

None

## Lawyers seek leniency for France rape trial defendants, blaming 'wolf' husband
 - [https://www.channelnewsasia.com/world/lawyers-seek-leniency-france-rape-trial-defendants-blaming-wolf-husband-4787781](https://www.channelnewsasia.com/world/lawyers-seek-leniency-france-rape-trial-defendants-blaming-wolf-husband-4787781)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:30.561561+00:00

None

## De Bruyne shines as Man City ease past Forest to end losing run
 - [https://www.channelnewsasia.com/sport/de-bruyne-shines-man-city-ease-past-forest-end-losing-run-4787801](https://www.channelnewsasia.com/sport/de-bruyne-shines-man-city-ease-past-forest-end-losing-run-4787801)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:30.305686+00:00

None

## Intel's interim co-CEO Zinsner says new chief executive will have foundry experience
 - [https://www.channelnewsasia.com/business/intels-interim-co-ceo-zinsner-says-new-chief-executive-will-have-foundry-experience-4787816](https://www.channelnewsasia.com/business/intels-interim-co-ceo-zinsner-says-new-chief-executive-will-have-foundry-experience-4787816)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:30.046984+00:00

None

## Young becomes oldest Everton scorer in rout of Wolves
 - [https://www.channelnewsasia.com/sport/young-becomes-oldest-everton-scorer-rout-wolves-4787826](https://www.channelnewsasia.com/sport/young-becomes-oldest-everton-scorer-rout-wolves-4787826)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:29.799119+00:00

None

## Schar grabs late equaliser as Newcastle deny Liverpool
 - [https://www.channelnewsasia.com/sport/schar-grabs-late-equaliser-newcastle-deny-liverpool-4787821](https://www.channelnewsasia.com/sport/schar-grabs-late-equaliser-newcastle-deny-liverpool-4787821)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:29.549497+00:00

None

## Paloma, one of Mexico’s favourite tequila cocktail, is experiencing a revival across the globe
 - [https://www.channelnewsasia.com/experiences/la-paloma-cocktail-singapore-bars-4781791](https://www.channelnewsasia.com/experiences/la-paloma-cocktail-singapore-bars-4781791)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:29.297857+00:00

The Paloma hits the winning trifecta with a tequila base, highball format, and a flavour profile that appeals to millennials.

## Chelsea stroll to 5-1 away win over 10-man Southampton
 - [https://www.channelnewsasia.com/sport/chelsea-stroll-5-1-away-win-over-10-man-southampton-4787846](https://www.channelnewsasia.com/sport/chelsea-stroll-5-1-away-win-over-10-man-southampton-4787846)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:29.047169+00:00

None

##  Russia supporting North Korea nuclear programme in exchange for troops: NATO chief
 - [https://www.channelnewsasia.com/world/nato-chief-says-russia-supporting-north-korea-nuclear-programme-troops-ukraine-4787856](https://www.channelnewsasia.com/world/nato-chief-says-russia-supporting-north-korea-nuclear-programme-troops-ukraine-4787856)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:28.795135+00:00

None

## RB Leipzig cruise past Frankfurt 3-0 in German Cup to end winless run
 - [https://www.channelnewsasia.com/sport/rb-leipzig-cruise-past-frankfurt-3-0-german-cup-end-winless-run-4787861](https://www.channelnewsasia.com/sport/rb-leipzig-cruise-past-frankfurt-3-0-german-cup-end-winless-run-4787861)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:28.543622+00:00

None

## Commentary: Joe Biden’s selfish parting act
 - [https://www.channelnewsasia.com/commentary/us-joe-biden-donald-trump-election-administration-son-hunter-pardon-4786306](https://www.channelnewsasia.com/commentary/us-joe-biden-donald-trump-election-administration-son-hunter-pardon-4786306)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:28.288646+00:00

In pardoning his son, US President Joe Biden has ensured that the distance between himself and Donald Trump is now shrouded in fog, says the Financial Times' Edward Luce.

## 'Must be held to high standards': Why Resorts World Sentosa's tourism performance was deemed unsatisfactory
 - [https://www.channelnewsasia.com/singapore/rws-casino-resorts-world-sentosa-integrated-resorts-4786031](https://www.channelnewsasia.com/singapore/rws-casino-resorts-world-sentosa-integrated-resorts-4786031)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:28.037517+00:00

The Singapore integrated resort’s casino licence has been renewed for two years instead of three.

## Commentary: Will phasing out shoebox homes improve living conditions for Hong Kong’s poor?
 - [https://www.channelnewsasia.com/commentary/hong-kong-shoebox-home-subdivided-unit-new-regulation-tenant-public-rental-flat-4786461](https://www.channelnewsasia.com/commentary/hong-kong-shoebox-home-subdivided-unit-new-regulation-tenant-public-rental-flat-4786461)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:27.741380+00:00

When Hong Kong’s new regulations on subdivided units kick in, tenants may have to pay more to continue living in them, says University of Minnesota PhD student John Hanzhang Ye.

## Analysis: Vietnam-Malaysia diplomatic upgrade signals more united approach to China’s maritime claims
 - [https://www.channelnewsasia.com/asia/malaysia-vietnam-ties-south-china-sea-csp-4786511](https://www.channelnewsasia.com/asia/malaysia-vietnam-ties-south-china-sea-csp-4786511)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:27.482623+00:00

Indonesia and the Philippines could be next in line to sign a comprehensive strategic partnership with Vietnam in what analysts say is a growing trend of Southeast Asian countries uniting against China’s maritime claims.

## Meta to invest $10 billion for Louisiana data center
 - [https://www.channelnewsasia.com/business/meta-invest-10-billion-louisiana-data-center-4787681](https://www.channelnewsasia.com/business/meta-invest-10-billion-louisiana-data-center-4787681)
 - RSS feed: $source
 - date published: 2024-12-04T21:08:21.139211+00:00

None

## Southampton's Stephens sent off for pulling Cucurella's hair
 - [https://www.channelnewsasia.com/sport/southamptons-stephens-sent-pulling-cucurellas-hair-4787696](https://www.channelnewsasia.com/sport/southamptons-stephens-sent-pulling-cucurellas-hair-4787696)
 - RSS feed: $source
 - date published: 2024-12-04T21:08:21.030313+00:00

None

## South Korea opposition push to impeach president
 - [https://www.channelnewsasia.com/east-asia/south-korea-opposition-party-impeach-yoon-seoul-protests-martial-law-4787691](https://www.channelnewsasia.com/east-asia/south-korea-opposition-party-impeach-yoon-seoul-protests-martial-law-4787691)
 - RSS feed: $source
 - date published: 2024-12-04T21:08:20.920026+00:00

None

## Fiorentina's Bove out of intensive care, says club
 - [https://www.channelnewsasia.com/sport/fiorentinas-bove-out-intensive-care-says-club-4787716](https://www.channelnewsasia.com/sport/fiorentinas-bove-out-intensive-care-says-club-4787716)
 - RSS feed: $source
 - date published: 2024-12-04T21:08:20.809229+00:00

None

## Mammoths topped the menu for North American Ice Age people
 - [https://www.channelnewsasia.com/business/mammoths-topped-menu-north-american-ice-age-people-4787546](https://www.channelnewsasia.com/business/mammoths-topped-menu-north-american-ice-age-people-4787546)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:18.815397+00:00

None

## Trump's nominee to run Pentagon hangs by a thread
 - [https://www.channelnewsasia.com/world/donald-trump-pentagon-nomination-senate-defence-secretary-4787541](https://www.channelnewsasia.com/world/donald-trump-pentagon-nomination-senate-defence-secretary-4787541)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:18.556004+00:00

None

## Oh brother, Leclerc and Leclerc in F1 practice first at Ferrari
 - [https://www.channelnewsasia.com/sport/oh-brother-leclerc-and-leclerc-f1-practice-first-ferrari-4787561](https://www.channelnewsasia.com/sport/oh-brother-leclerc-and-leclerc-f1-practice-first-ferrari-4787561)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:18.283592+00:00

None

## Trafigura director deflects blame at Swiss corruption trial 
 - [https://www.channelnewsasia.com/business/trafigura-director-deflects-blame-swiss-corruption-trial-4787566](https://www.channelnewsasia.com/business/trafigura-director-deflects-blame-swiss-corruption-trial-4787566)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:18.011233+00:00

None

## UK to nationalise train operators from May
 - [https://www.channelnewsasia.com/world/uk-trains-railway-nationalisation-labour-party-london-4787581](https://www.channelnewsasia.com/world/uk-trains-railway-nationalisation-labour-party-london-4787581)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:17.753312+00:00

None

## UnitedHealthcare executive killed in Manhattan in targeted attack
 - [https://www.channelnewsasia.com/world/unitedhealthcare-ceo-brian-thompson-shot-dead-new-york-4786936](https://www.channelnewsasia.com/world/unitedhealthcare-ceo-brian-thompson-shot-dead-new-york-4786936)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:17.463367+00:00

None

## Coe welcomes new track start-ups amid push for innovation
 - [https://www.channelnewsasia.com/sport/coe-welcomes-new-track-start-ups-amid-push-innovation-4787626](https://www.channelnewsasia.com/sport/coe-welcomes-new-track-start-ups-amid-push-innovation-4787626)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:17.160259+00:00

None

## French government toppled in no-confidence vote, deepening political crisis
 - [https://www.channelnewsasia.com/world/france-government-no-confidence-vote-political-crisis-michel-barnier-4787136](https://www.channelnewsasia.com/world/france-government-no-confidence-vote-political-crisis-michel-barnier-4787136)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:16.694682+00:00

None

## New LPGA gender policy bars players who have gone through male puberty
 - [https://www.channelnewsasia.com/sport/new-lpga-gender-policy-bars-players-who-have-gone-through-male-puberty-4787396](https://www.channelnewsasia.com/sport/new-lpga-gender-policy-bars-players-who-have-gone-through-male-puberty-4787396)
 - RSS feed: $source
 - date published: 2024-12-04T18:58:00.234368+00:00

None

## Hamas threatens to 'neutralize' hostages if Israel launches rescue
 - [https://www.channelnewsasia.com/world/hamas-threat-neutralize-hostages-gaza-israel-nuseirat-camp-4786956](https://www.channelnewsasia.com/world/hamas-threat-neutralize-hostages-gaza-israel-nuseirat-camp-4786956)
 - RSS feed: $source
 - date published: 2024-12-04T18:57:59.923073+00:00

None

## Trump's crypto advocacy steers businesses away from traditional treasury assets
 - [https://www.channelnewsasia.com/business/trumps-crypto-advocacy-steers-businesses-away-traditional-treasury-assets-4787291](https://www.channelnewsasia.com/business/trumps-crypto-advocacy-steers-businesses-away-traditional-treasury-assets-4787291)
 - RSS feed: $source
 - date published: 2024-12-04T17:54:03.353073+00:00

None

## South Korea's ruling party to oppose President Yoon's impeachment after failed martial law move: Report
 - [https://www.channelnewsasia.com/asia/south-korea-ruling-party-opposition-yoon-impeachment-4787171](https://www.channelnewsasia.com/asia/south-korea-ruling-party-opposition-yoon-impeachment-4787171)
 - RSS feed: $source
 - date published: 2024-12-04T17:54:03.096008+00:00

None

## Nippon Steel committed to US Steel takeover, aims to close in Dec, says executive
 - [https://www.channelnewsasia.com/business/nippon-steel-committed-us-steel-takeover-aims-close-dec-says-executive-4787341](https://www.channelnewsasia.com/business/nippon-steel-committed-us-steel-takeover-aims-close-dec-says-executive-4787341)
 - RSS feed: $source
 - date published: 2024-12-04T17:54:02.845761+00:00

None

## Atletico's Le Normand available to compete after brain injury, says Simeone
 - [https://www.channelnewsasia.com/sport/atleticos-le-normand-available-compete-after-brain-injury-says-simeone-4787366](https://www.channelnewsasia.com/sport/atleticos-le-normand-available-compete-after-brain-injury-says-simeone-4787366)
 - RSS feed: $source
 - date published: 2024-12-04T17:54:02.593366+00:00

None

## Briton Pidcock to leave Ineos Grenadiers at end of season
 - [https://www.channelnewsasia.com/sport/briton-pidcock-leave-ineos-grenadiers-end-season-4787416](https://www.channelnewsasia.com/sport/briton-pidcock-leave-ineos-grenadiers-end-season-4787416)
 - RSS feed: $source
 - date published: 2024-12-04T17:54:02.345098+00:00

None

## Soitec to supply wafers to GlobalFoundries' 9SW platform
 - [https://www.channelnewsasia.com/business/soitec-supply-wafers-globalfoundries-9sw-platform-4787411](https://www.channelnewsasia.com/business/soitec-supply-wafers-globalfoundries-9sw-platform-4787411)
 - RSS feed: $source
 - date published: 2024-12-04T17:54:02.082599+00:00

None

## Chipmaker Marvell's shares jump to record high on AI-powered Q4 forecast
 - [https://www.channelnewsasia.com/business/chipmaker-marvells-shares-jump-record-high-ai-powered-q4-forecast-4786721](https://www.channelnewsasia.com/business/chipmaker-marvells-shares-jump-record-high-ai-powered-q4-forecast-4786721)
 - RSS feed: $source
 - date published: 2024-12-04T16:48:04.838521+00:00

None

## EU watchdog probes potential Nvidia hardware bundling as it scrutinises Run:ai deal
 - [https://www.channelnewsasia.com/business/eu-watchdog-probes-potential-nvidia-hardware-bundling-it-scrutinises-runai-deal-4786751](https://www.channelnewsasia.com/business/eu-watchdog-probes-potential-nvidia-hardware-bundling-it-scrutinises-runai-deal-4786751)
 - RSS feed: $source
 - date published: 2024-12-04T16:48:04.393848+00:00

None

## Wall Street stocks advance, dollar steady amid political turmoil in South Korea, France
 - [https://www.channelnewsasia.com/business/wall-street-stocks-advance-dollar-steady-amid-political-turmoil-south-korea-france-4785701](https://www.channelnewsasia.com/business/wall-street-stocks-advance-dollar-steady-amid-political-turmoil-south-korea-france-4785701)
 - RSS feed: $source
 - date published: 2024-12-04T16:48:04.126240+00:00

None

## DAZN named global broadcaster for 2025 Club World Cup
 - [https://www.channelnewsasia.com/sport/dazn-named-global-broadcaster-2025-club-world-cup-4787196](https://www.channelnewsasia.com/sport/dazn-named-global-broadcaster-2025-club-world-cup-4787196)
 - RSS feed: $source
 - date published: 2024-12-04T16:48:03.587007+00:00

None

## Sumo-Grand Sumo Tournament makes historic return to London after 34 years
 - [https://www.channelnewsasia.com/sport/sumo-grand-sumo-tournament-makes-historic-return-london-after-34-years-4787211](https://www.channelnewsasia.com/sport/sumo-grand-sumo-tournament-makes-historic-return-london-after-34-years-4787211)
 - RSS feed: $source
 - date published: 2024-12-04T16:48:03.319148+00:00

None

## Schneider Electric working with Nvidia to design data center cooling systems
 - [https://www.channelnewsasia.com/business/schneider-electric-working-nvidia-design-data-center-cooling-systems-4787231](https://www.channelnewsasia.com/business/schneider-electric-working-nvidia-design-data-center-cooling-systems-4787231)
 - RSS feed: $source
 - date published: 2024-12-04T16:48:03.049243+00:00

None

## Salesforce shares scale record high on promising AI tools
 - [https://www.channelnewsasia.com/business/salesforce-shares-scale-record-high-promising-ai-tools-4786741](https://www.channelnewsasia.com/business/salesforce-shares-scale-record-high-promising-ai-tools-4786741)
 - RSS feed: $source
 - date published: 2024-12-04T15:43:05.060569+00:00

None

## Wall Street stocks, dollar advance amid political turmoil in South Korea, France
 - [https://www.channelnewsasia.com/business/wall-street-stocks-dollar-advance-amid-political-turmoil-south-korea-france-4785701](https://www.channelnewsasia.com/business/wall-street-stocks-dollar-advance-amid-political-turmoil-south-korea-france-4785701)
 - RSS feed: $source
 - date published: 2024-12-04T15:43:04.780151+00:00

None

## Kebaya inscribed onto UNESCO intangible cultural heritage list
 - [https://www.channelnewsasia.com/singapore/kebaya-inscribed-unesco-intangible-cultural-heritage-list-4786996](https://www.channelnewsasia.com/singapore/kebaya-inscribed-unesco-intangible-cultural-heritage-list-4786996)
 - RSS feed: $source
 - date published: 2024-12-04T15:43:04.345590+00:00

The kebaya was jointly nominated by five Southeast Asian countries – Singapore, Brunei, Indonesia, Malaysia and Thailand.

## Consortium to take HK-listed ESR Group private for $7.09 billion
 - [https://www.channelnewsasia.com/business/consortium-take-hk-listed-esr-group-private-709-billion-4786891](https://www.channelnewsasia.com/business/consortium-take-hk-listed-esr-group-private-709-billion-4786891)
 - RSS feed: $source
 - date published: 2024-12-04T14:38:02.423193+00:00

None

## LGBTQ group disappointed after Man Utd squad don't wear rainbow jackets
 - [https://www.channelnewsasia.com/sport/lgbtq-group-disappointed-after-man-utd-squad-dont-wear-rainbow-jackets-4786911](https://www.channelnewsasia.com/sport/lgbtq-group-disappointed-after-man-utd-squad-dont-wear-rainbow-jackets-4786911)
 - RSS feed: $source
 - date published: 2024-12-04T14:38:02.312573+00:00

None

## England's Bethell receives contract upgrade after impressive test debut
 - [https://www.channelnewsasia.com/sport/englands-bethell-receives-contract-upgrade-after-impressive-test-debut-4786926](https://www.channelnewsasia.com/sport/englands-bethell-receives-contract-upgrade-after-impressive-test-debut-4786926)
 - RSS feed: $source
 - date published: 2024-12-04T14:38:02.201682+00:00

None

## Malaysia government faces backlash over harsher penalties, wider powers proposed to tackle harmful online content
 - [https://www.channelnewsasia.com/asia/malaysia-internet-online-content-communications-and-multimedia-act-amendments-backlash-civil-society-freedom-speech-4786546](https://www.channelnewsasia.com/asia/malaysia-internet-online-content-communications-and-multimedia-act-amendments-backlash-civil-society-freedom-speech-4786546)
 - RSS feed: $source
 - date published: 2024-12-04T13:32:52.485849+00:00

Civil society groups and experts fear the amendments will curb free speech in the country and are calling for more stakeholder consultations.

## UK to publish provisional report on cloud computing in January
 - [https://www.channelnewsasia.com/business/uk-publish-provisional-report-cloud-computing-january-4786801](https://www.channelnewsasia.com/business/uk-publish-provisional-report-cloud-computing-january-4786801)
 - RSS feed: $source
 - date published: 2024-12-04T13:32:52.377040+00:00

None

## Taiwanese romance author Chiung Yao dies at 86
 - [https://www.channelnewsasia.com/east-asia/taiwanese-romance-author-chiung-yao-dies-4786746](https://www.channelnewsasia.com/east-asia/taiwanese-romance-author-chiung-yao-dies-4786746)
 - RSS feed: $source
 - date published: 2024-12-04T13:32:52.268747+00:00

None

## Singapore blocks access to online gender clinic GenderGP due to 'public health risk'
 - [https://www.channelnewsasia.com/singapore/gendergp-access-blocked-puberty-blockers-hormone-therapy-moh-imda-4786666](https://www.channelnewsasia.com/singapore/gendergp-access-blocked-puberty-blockers-hormone-therapy-moh-imda-4786666)
 - RSS feed: $source
 - date published: 2024-12-04T13:32:52.158857+00:00

The Ministry of Health had warned GenderGP in October to stop providing unlicensed outpatient medical services to Singapore-based users.

## How is a South Korean president impeached and does the opposition have enough votes to do so?
 - [https://www.channelnewsasia.com/east-asia/south-korea-martial-law-president-impeach-bill-opposition-enough-votes-4785801](https://www.channelnewsasia.com/east-asia/south-korea-martial-law-president-impeach-bill-opposition-enough-votes-4785801)
 - RSS feed: $source
 - date published: 2024-12-04T13:32:52.039824+00:00

South Korean lawmakers have submitted a Bill to impeach President Yoon Suk Yeol after he declared martial law and reversed the move hours later.

## BlackRock bets on AI-driven stocks rally but US debt clouds 2025 outlook
 - [https://www.channelnewsasia.com/business/blackrock-bets-ai-driven-stocks-rally-us-debt-clouds-2025-outlook-4786671](https://www.channelnewsasia.com/business/blackrock-bets-ai-driven-stocks-rally-us-debt-clouds-2025-outlook-4786671)
 - RSS feed: $source
 - date published: 2024-12-04T12:27:54.152894+00:00

None

## Ubisoft pulls the plug on XDefiant, to close San Francisco and Osaka studios
 - [https://www.channelnewsasia.com/business/ubisoft-pulls-plug-xdefiant-close-san-francisco-and-osaka-studios-4786701](https://www.channelnewsasia.com/business/ubisoft-pulls-plug-xdefiant-close-san-francisco-and-osaka-studios-4786701)
 - RSS feed: $source
 - date published: 2024-12-04T12:27:53.865607+00:00

None

## Tottenham must bolster attack in transfer window, says Postecoglou
 - [https://www.channelnewsasia.com/sport/tottenham-must-bolster-attack-transfer-window-says-postecoglou-4786726](https://www.channelnewsasia.com/sport/tottenham-must-bolster-attack-transfer-window-says-postecoglou-4786726)
 - RSS feed: $source
 - date published: 2024-12-04T12:27:53.618263+00:00

None

## Salesforce jumps as latest AI tools set to accelerate demand
 - [https://www.channelnewsasia.com/business/salesforce-jumps-latest-ai-tools-set-accelerate-demand-4786741](https://www.channelnewsasia.com/business/salesforce-jumps-latest-ai-tools-set-accelerate-demand-4786741)
 - RSS feed: $source
 - date published: 2024-12-04T12:27:53.365650+00:00

None

## EU watchdog probes Nvidia hardware bundling as it scrutinises Run:ai deal
 - [https://www.channelnewsasia.com/business/eu-watchdog-probes-nvidia-hardware-bundling-it-scrutinises-runai-deal-4786751](https://www.channelnewsasia.com/business/eu-watchdog-probes-nvidia-hardware-bundling-it-scrutinises-runai-deal-4786751)
 - RSS feed: $source
 - date published: 2024-12-04T12:27:53.110062+00:00

None

## Global stocks grapple with political turmoil in South Korea, France
 - [https://www.channelnewsasia.com/business/global-stocks-grapple-political-turmoil-south-korea-france-4785701](https://www.channelnewsasia.com/business/global-stocks-grapple-political-turmoil-south-korea-france-4785701)
 - RSS feed: $source
 - date published: 2024-12-04T12:27:52.846102+00:00

None

## PAP announces new central executive committee; Lawrence Wong officially elected secretary-general
 - [https://www.channelnewsasia.com/singapore/pap-cec-lawrence-wong-secretary-general-four-co-opted-4786521](https://www.channelnewsasia.com/singapore/pap-cec-lawrence-wong-secretary-general-four-co-opted-4786521)
 - RSS feed: $source
 - date published: 2024-12-04T11:22:53.418811+00:00

Education Minister Chan Chun Sing and Minister for National Development Desmond Lee remain assistant secretaries-general. 

## England name unchanged team for second New Zealand test
 - [https://www.channelnewsasia.com/sport/england-name-unchanged-team-second-new-zealand-test-4786541](https://www.channelnewsasia.com/sport/england-name-unchanged-team-second-new-zealand-test-4786541)
 - RSS feed: $source
 - date published: 2024-12-04T11:22:53.304475+00:00

None

## TCM clinic in China claiming to ‘cure cancer’ under investigation following 15 deaths 
 - [https://www.channelnewsasia.com/east-asia/china-hubei-tcm-clinic-under-investigation-cancer-cure-patients-deaths-4786536](https://www.channelnewsasia.com/east-asia/china-hubei-tcm-clinic-under-investigation-cancer-cure-patients-deaths-4786536)
 - RSS feed: $source
 - date published: 2024-12-04T11:22:53.170245+00:00

The clinic gained widespread attention online when its founder peddled outrageous claims of curing cancer using TCM and making more than 3,000 patients’ tumours disappear.  

## Evenepoel undergoes surgery after training crash
 - [https://www.channelnewsasia.com/sport/evenepoel-undergoes-surgery-after-training-crash-4786606](https://www.channelnewsasia.com/sport/evenepoel-undergoes-surgery-after-training-crash-4786606)
 - RSS feed: $source
 - date published: 2024-12-04T11:22:53.052957+00:00

None

## Thailand to extend production timeframe for battery EVs, investment board says
 - [https://www.channelnewsasia.com/business/thailand-extend-production-timeframe-battery-evs-4786276](https://www.channelnewsasia.com/business/thailand-extend-production-timeframe-battery-evs-4786276)
 - RSS feed: $source
 - date published: 2024-12-04T10:17:47.282679+00:00

None

## OECD warns of protectionism risk to global growth outlook
 - [https://www.channelnewsasia.com/business/oecd-warns-protectionism-risk-global-growth-outlook-4786381](https://www.channelnewsasia.com/business/oecd-warns-protectionism-risk-global-growth-outlook-4786381)
 - RSS feed: $source
 - date published: 2024-12-04T10:17:47.086560+00:00

None

## Philippine VP Duterte faces second impeachment complaint
 - [https://www.channelnewsasia.com/asia/philippine-vp-sara-duterte-second-impeachment-complaint-president-ferdinand-marcos-4786411](https://www.channelnewsasia.com/asia/philippine-vp-sara-duterte-second-impeachment-complaint-president-ferdinand-marcos-4786411)
 - RSS feed: $source
 - date published: 2024-12-04T10:17:46.977198+00:00

None

## The lure of Labubu: How people are potentially breaking the law to get their hands on the popular dolls
 - [https://www.channelnewsasia.com/singapore/labubu-toys-illegal-gambling-social-media-tiktok-4786346](https://www.channelnewsasia.com/singapore/labubu-toys-illegal-gambling-social-media-tiktok-4786346)
 - RSS feed: $source
 - date published: 2024-12-04T10:17:46.864285+00:00

Labubu toys have been around for nine years, but only shot to fame a few months ago when K-pop star Lisa from Blackpink shared photos of herself with the characters.

## Seoul stocks sink amid South Korea drama as Asian markets mixed
 - [https://www.channelnewsasia.com/east-asia/south-korea-stocks-sink-asian-markets-mixed-4786201](https://www.channelnewsasia.com/east-asia/south-korea-stocks-sink-asian-markets-mixed-4786201)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:50.805738+00:00

None

## McLaren and Ferrari fight for title as Hamilton ends an era
 - [https://www.channelnewsasia.com/sport/mclaren-and-ferrari-fight-title-hamilton-ends-era-4786266](https://www.channelnewsasia.com/sport/mclaren-and-ferrari-fight-title-hamilton-ends-era-4786266)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:50.630230+00:00

None

## COE prices for Category A cars rebound after drop in previous round
 - [https://www.channelnewsasia.com/singapore/coe-cat-cars-prices-bidding-exercise-4786226](https://www.channelnewsasia.com/singapore/coe-cat-cars-prices-bidding-exercise-4786226)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:50.520250+00:00

None

## Thailand to extend production timeframe for battery EVs, investment board says
 - [https://www.channelnewsasia.com/business/thailand-extend-production-timeframe-battery-evs-investment-board-says-4786276](https://www.channelnewsasia.com/business/thailand-extend-production-timeframe-battery-evs-investment-board-says-4786276)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:50.410780+00:00

None

## Verstappen's Dutch GP to drop off F1 calendar after 2026
 - [https://www.channelnewsasia.com/sport/verstappens-dutch-gp-drop-f1-calendar-after-2026-4786316](https://www.channelnewsasia.com/sport/verstappens-dutch-gp-drop-f1-calendar-after-2026-4786316)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:50.301942+00:00

None

## Death toll rises to 29 in southern Thailand floods
 - [https://www.channelnewsasia.com/asia/death-toll-rises-29-southern-thailand-floods-4786311](https://www.channelnewsasia.com/asia/death-toll-rises-29-southern-thailand-floods-4786311)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:50.190026+00:00

None

## French government risks falling in no-confidence vote
 - [https://www.channelnewsasia.com/world/france-government-collapse-michel-barnier-no-confidence-vote-4786351](https://www.channelnewsasia.com/world/france-government-collapse-michel-barnier-no-confidence-vote-4786351)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:50.067535+00:00

None

## Protecting people from themselves: Can a proposed law help bring down scam numbers in Singapore?
 - [https://www.channelnewsasia.com/singapore/scams-police-powers-mha-restrict-banking-transactions-proposed-bill-4781411](https://www.channelnewsasia.com/singapore/scams-police-powers-mha-restrict-banking-transactions-proposed-bill-4781411)
 - RSS feed: $source
 - date published: 2024-12-04T08:07:47.137336+00:00

A clinical psychologist and lawyer speak to CNA’s Deep Dive podcast to weigh in on plans to give police powers to avert scams by freezing bank accounts of potential victims.

## South Korea stocks slide as President Yoon's failed martial law bid stokes turmoil
 - [https://www.channelnewsasia.com/business/south-korea-stocks-slide-president-yoons-failed-martial-law-bid-stokes-turmoil-4786201](https://www.channelnewsasia.com/business/south-korea-stocks-slide-president-yoons-failed-martial-law-bid-stokes-turmoil-4786201)
 - RSS feed: $source
 - date published: 2024-12-04T08:07:46.835035+00:00

None

## Trump's plan for Ukraine comes into focus: Territorial concessions but NATO off the table
 - [https://www.channelnewsasia.com/world/trumps-plan-ukraine-comes-focus-territorial-concessions-nato-table-4784711](https://www.channelnewsasia.com/world/trumps-plan-ukraine-comes-focus-territorial-concessions-nato-table-4784711)
 - RSS feed: $source
 - date published: 2024-12-04T08:07:46.577867+00:00

None

## Klaasen to captain South Africa’s T20 side as Markram rested
 - [https://www.channelnewsasia.com/sport/klaasen-captain-south-africas-t20-side-markram-rested-4786216](https://www.channelnewsasia.com/sport/klaasen-captain-south-africas-t20-side-markram-rested-4786216)
 - RSS feed: $source
 - date published: 2024-12-04T08:07:46.318259+00:00

None

## UN seeks US$47 billion in aid for 2025 as donor appetite shrinks while crises multiply
 - [https://www.channelnewsasia.com/world/un-seeks-us47-billion-aid-2025-donor-appetite-shrinks-while-crises-multiply-4785971](https://www.channelnewsasia.com/world/un-seeks-us47-billion-aid-2025-donor-appetite-shrinks-while-crises-multiply-4785971)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:09.094144+00:00

None

## Google Cloud partners with Air France-KLM on AI technology
 - [https://www.channelnewsasia.com/business/google-cloud-partners-air-france-klm-ai-technology-4786091](https://www.channelnewsasia.com/business/google-cloud-partners-air-france-klm-ai-technology-4786091)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:08.751026+00:00

None

## Rahul keeps India's batting line-up a closely guarded secret
 - [https://www.channelnewsasia.com/sport/rahul-keeps-indias-batting-line-up-closely-guarded-secret-4786131](https://www.channelnewsasia.com/sport/rahul-keeps-indias-batting-line-up-closely-guarded-secret-4786131)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:08.492600+00:00

None

## Man United's Shaw suffers fresh injury setback
 - [https://www.channelnewsasia.com/sport/man-uniteds-shaw-suffers-fresh-injury-setback-4786146](https://www.channelnewsasia.com/sport/man-uniteds-shaw-suffers-fresh-injury-setback-4786146)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:08.219257+00:00

None

## Thailand’s tom yum kung makes it to UNESCO's intangible cultural heritage list
 - [https://www.channelnewsasia.com/dining/tom-yum-kung-prawn-thailand-unesco-intangible-cultural-heritage-4786071](https://www.channelnewsasia.com/dining/tom-yum-kung-prawn-thailand-unesco-intangible-cultural-heritage-4786071)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:07.893902+00:00

The sour, spicy and hot prawn soup was added to the UNESCO Representative List of the Intangible Cultural Heritage of Humanity on Wednesday (Dec 4), highlighting its cultural significance. 

## Johor-Singapore SEZ deal signing postponed after PM Wong tests positive for COVID-19: Malaysia PM Anwar
 - [https://www.channelnewsasia.com/asia/johor-singapore-sez-deal-signing-postponed-after-pm-wong-tests-positive-covid-19-malaysia-pm-anwar-4786026](https://www.channelnewsasia.com/asia/johor-singapore-sez-deal-signing-postponed-after-pm-wong-tests-positive-covid-19-malaysia-pm-anwar-4786026)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:07.616444+00:00

The signing was originally planned for during the annual Singapore-Malaysia Leader’s Retreat scheduled from Dec 8-9 in Malaysia’s administrative capital, Putrajaya.

## Dolphins around South Korea’s Jeju Island dying from overtourism, pollution, say experts
 - [https://www.channelnewsasia.com/asia/south-korea-jeju-island-dolphins-dying-overtourism-marine-pollution-4784146](https://www.channelnewsasia.com/asia/south-korea-jeju-island-dolphins-dying-overtourism-marine-pollution-4784146)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:07.361017+00:00

About 10 bottlenose dolphin calves have died this year so far, up from just one death last year.

## Wet weather in Singapore batters businesses, ruins sports enthusiasts’ plans
 - [https://www.channelnewsasia.com/singapore/wet-weather-sea-sports-windsurfing-outdoor-activities-rain-4784581](https://www.channelnewsasia.com/singapore/wet-weather-sea-sports-windsurfing-outdoor-activities-rain-4784581)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:07.112933+00:00

The recent spate of heavy rain has dampened plans, with at least one business seeing a 90 per cent dip in equipment rental.

## Singaporeans, travel agencies proceed with tours in South Korea after reversed martial law order
 - [https://www.channelnewsasia.com/singapore/singaporeans-travel-agencies-proceed-tours-south-korea-after-reversed-martial-law-order-4786101](https://www.channelnewsasia.com/singapore/singaporeans-travel-agencies-proceed-tours-south-korea-after-reversed-martial-law-order-4786101)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:06.859314+00:00

Singaporeans visiting or living in Seoul said that they were not too worried about the situation, but would take necessary precautions to remain safe.

## Malaysian king vows to end ties with military university if 'inhumane' bullying culture continues
 - [https://www.channelnewsasia.com/asia/malaysia-agong-sultan-ibrahim-bullying-abuse-chancellor-upnm-military-university-4786116](https://www.channelnewsasia.com/asia/malaysia-agong-sultan-ibrahim-bullying-abuse-chancellor-upnm-military-university-4786116)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:06.604930+00:00

Sultan Ibrahim Sultan Iskandar is the new chancellor of Universiti Pertahanan Nasional Malaysia, which has seen several shocking cases of bullying and abuse over the years.

## Pressure mounts on West Ham manager Lopetegui after loss at Leicester
 - [https://www.channelnewsasia.com/sport/pressure-mounts-west-ham-manager-lopetegui-after-loss-leicester-4786161](https://www.channelnewsasia.com/sport/pressure-mounts-west-ham-manager-lopetegui-after-loss-leicester-4786161)
 - RSS feed: $source
 - date published: 2024-12-04T07:03:06.343647+00:00

None

## Tan Howe Liang, Singapore's first Olympic medallist, dies aged 91
 - [https://www.channelnewsasia.com/singapore/tan-howe-liang-first-olympic-medal-weightlifting-4785926](https://www.channelnewsasia.com/singapore/tan-howe-liang-first-olympic-medal-weightlifting-4785926)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:41.506521+00:00

Tan won silver in weightlifting at the 1960 Rome Games, making him the country's sole Olympic medallist for almost half a century.

## Leicester boss Van Nistelrooy pleased with win but keeping feet on the ground
 - [https://www.channelnewsasia.com/sport/leicester-boss-van-nistelrooy-pleased-win-keeping-feet-ground-4785961](https://www.channelnewsasia.com/sport/leicester-boss-van-nistelrooy-pleased-win-keeping-feet-ground-4785961)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:41.392760+00:00

None

## Djokovic to play at Brisbane International ahead of Australian Open
 - [https://www.channelnewsasia.com/sport/djokovic-play-brisbane-international-ahead-australian-open-4785996](https://www.channelnewsasia.com/sport/djokovic-play-brisbane-international-ahead-australian-open-4785996)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:41.283431+00:00

None

## Knicks beat Magic to advance in the NBA Cup. Orlando also moves on as the East wild card
 - [https://www.channelnewsasia.com/sport/knicks-beat-magic-advance-nba-cup-orlando-also-moves-east-wild-card-4785836](https://www.channelnewsasia.com/sport/knicks-beat-magic-advance-nba-cup-orlando-also-moves-east-wild-card-4785836)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:41.153001+00:00

None

## 3 schizophrenic men who killed or attempted to kill others to be confined further after review
 - [https://www.channelnewsasia.com/singapore/3-schizophrenic-men-unsound-mind-murder-acquit-confine-imh-prison-4785931](https://www.channelnewsasia.com/singapore/3-schizophrenic-men-unsound-mind-murder-acquit-confine-imh-prison-4785931)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:41.043974+00:00

The three men, who are in their 60s to 70s, were ordered to remain confined in the Institute of Mental Health or Changi Prison.

## UN seeks US$47 billion in aid as donor appetite shrinks while crises multiply
 - [https://www.channelnewsasia.com/world/un-seeks-us47-billion-aid-donor-appetite-shrinks-while-crises-multiply-4785971](https://www.channelnewsasia.com/world/un-seeks-us47-billion-aid-donor-appetite-shrinks-while-crises-multiply-4785971)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:40.934376+00:00

None

## South Korean lawmakers call to impeach President Yoon after back-track on martial law
 - [https://www.channelnewsasia.com/east-asia/martial-law-south-korea-lawmakers-military-rule-yoon-suk-yeol-back-track-4786046](https://www.channelnewsasia.com/east-asia/martial-law-south-korea-lawmakers-military-rule-yoon-suk-yeol-back-track-4786046)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:40.825599+00:00

None

## Snap Insight: South Korea President Yoon’s martial law attempt was an inept semi-coup
 - [https://www.channelnewsasia.com/commentary/south-korea-martial-law-yoon-suk-yeol-military-parliament-impeach-snap-insight-4785936](https://www.channelnewsasia.com/commentary/south-korea-martial-law-yoon-suk-yeol-military-parliament-impeach-snap-insight-4785936)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:40.665439+00:00

It is remarkable that South Korea President Yoon Suk Yeol thought he could halt constitutional government without provoking a massive national backlash, says political science professor Robert Kelly.

## Second major Myanmar rebel group calls for talks with junta
 - [https://www.channelnewsasia.com/asia/second-major-myanmar-rebel-group-calls-talks-junta-4785861](https://www.channelnewsasia.com/asia/second-major-myanmar-rebel-group-calls-talks-junta-4785861)
 - RSS feed: $source
 - date published: 2024-12-04T04:52:38.811383+00:00

None

## Singaporean couple linked to US$51 million fraud case arrested in Malaysia after 19 years on the run
 - [https://www.channelnewsasia.com/singapore/citiraya-industries-ng-teck-lee-thor-chwee-hwa-arrested-corruption-fraud-cpib-scrap-recycling-4785656](https://www.channelnewsasia.com/singapore/citiraya-industries-ng-teck-lee-thor-chwee-hwa-arrested-corruption-fraud-cpib-scrap-recycling-4785656)
 - RSS feed: $source
 - date published: 2024-12-04T04:52:38.681880+00:00

The former CEO of recycling firm Citiraya Industries and his wife were handed over to CPIB's custody.

## Thai November headline inflation misses forecast, below central bank target 
 - [https://www.channelnewsasia.com/business/thai-november-headline-inflation-misses-forecast-below-central-bank-target-4785921](https://www.channelnewsasia.com/business/thai-november-headline-inflation-misses-forecast-below-central-bank-target-4785921)
 - RSS feed: $source
 - date published: 2024-12-04T04:52:38.572142+00:00

None

## Japan's service activity perks up as demand improves, PMI shows  
 - [https://www.channelnewsasia.com/east-asia/japans-service-activity-perks-up-demand-improves-pmi-shows-4785611](https://www.channelnewsasia.com/east-asia/japans-service-activity-perks-up-demand-improves-pmi-shows-4785611)
 - RSS feed: $source
 - date published: 2024-12-04T03:47:42.067751+00:00

None

## Netflix’s Culinary Class Wars now looking for season 2 chef contestants
 - [https://www.channelnewsasia.com/entertainment/culinary-class-wars-season-2-recruiting-new-contestants-4785691](https://www.channelnewsasia.com/entertainment/culinary-class-wars-season-2-recruiting-new-contestants-4785691)
 - RSS feed: $source
 - date published: 2024-12-04T03:47:41.759441+00:00

Anyone can apply "regardless of nationality or where you reside" – but the application form is in Korean.

## Philippines, China trade accusations over confrontation in South China Sea
 - [https://www.channelnewsasia.com/east-asia/philippines-china-trade-accusations-over-confrontation-south-china-sea-4785626](https://www.channelnewsasia.com/east-asia/philippines-china-trade-accusations-over-confrontation-south-china-sea-4785626)
 - RSS feed: $source
 - date published: 2024-12-04T03:47:41.455316+00:00

None

## Australia look to boss India with pink ball under Adelaide lights
 - [https://www.channelnewsasia.com/sport/australia-look-boss-india-pink-ball-under-adelaide-lights-4785831](https://www.channelnewsasia.com/sport/australia-look-boss-india-pink-ball-under-adelaide-lights-4785831)
 - RSS feed: $source
 - date published: 2024-12-04T03:47:41.157934+00:00

None

## Taiwanese TV host Mickey Huang sentenced to 8 months in jail for possessing obscene materials involving minors 
 - [https://www.channelnewsasia.com/entertainment/taiwan-host-mickey-huang-jail-term-child-pornography-4785686](https://www.channelnewsasia.com/entertainment/taiwan-host-mickey-huang-jail-term-child-pornography-4785686)
 - RSS feed: $source
 - date published: 2024-12-04T03:47:40.845263+00:00

The 52-year-old was also fined NT$100,000 (US$3,070) under Taiwan’s Child and Youth Sexual Exploitation Prevention Act.

## Taiwan's President Lai visits Pacific ally Tuvalu
 - [https://www.channelnewsasia.com/east-asia/taiwans-president-lai-visits-pacific-ally-tuvalu-4785641](https://www.channelnewsasia.com/east-asia/taiwans-president-lai-visits-pacific-ally-tuvalu-4785641)
 - RSS feed: $source
 - date published: 2024-12-04T02:42:56.828973+00:00

None

## Dollar holds ground as Fed path pondered; won stable after martial law lifted
 - [https://www.channelnewsasia.com/business/dollar-holds-ground-fed-path-pondered-won-stable-after-martial-law-lifted-4785696](https://www.channelnewsasia.com/business/dollar-holds-ground-fed-path-pondered-won-stable-after-martial-law-lifted-4785696)
 - RSS feed: $source
 - date published: 2024-12-04T02:42:56.645416+00:00

None

## Oil steady as markets weigh higher US stockpiles, OPEC+ supply plans
 - [https://www.channelnewsasia.com/business/oil-steady-markets-weigh-higher-us-stockpiles-opec-supply-plans-4785711](https://www.channelnewsasia.com/business/oil-steady-markets-weigh-higher-us-stockpiles-opec-supply-plans-4785711)
 - RSS feed: $source
 - date published: 2024-12-04T02:42:56.458020+00:00

None

## Fugitive Singapore lawyer Charles Yeo's extradition hearing set for May 2025
 - [https://www.channelnewsasia.com/singapore/charles-yeo-extradition-request-fugitive-lawyer-cancel-singapore-passport-custody-bail-4785746](https://www.channelnewsasia.com/singapore/charles-yeo-extradition-request-fugitive-lawyer-cancel-singapore-passport-custody-bail-4785746)
 - RSS feed: $source
 - date published: 2024-12-04T02:42:56.270866+00:00

Lawyers acting for Charles Yeo have applied for his Singapore passport to be cancelled in an attempt to satisfy the bail conditions, a UK court heard.

## Acclaimed Taiwanese songwriter Liu Chia-chang dies of cancer 
 - [https://www.channelnewsasia.com/entertainment/taiwanese-songwriter-liu-chia-chang-dies-cancer-4785616](https://www.channelnewsasia.com/entertainment/taiwanese-songwriter-liu-chia-chang-dies-cancer-4785616)
 - RSS feed: $source
 - date published: 2024-12-04T02:42:55.926081+00:00

Liu reportedly composed more than 2,000 songs in his storied career, many of which were hits, including Meilan Meilan I Love You, Memories Can Only Be Reminisced and Seagull. 

##  Who is Yoon Suk Yeol, South Korea's embattled conservative president?
 - [https://www.channelnewsasia.com/east-asia/who-south-korea-president-yoon-suk-yeol-martial-law-wife-kim-keon-hee-controversy-4785751](https://www.channelnewsasia.com/east-asia/who-south-korea-president-yoon-suk-yeol-martial-law-wife-kim-keon-hee-controversy-4785751)
 - RSS feed: $source
 - date published: 2024-12-04T02:42:55.717888+00:00

Many South Koreans have expressed dissatisfaction over Yoon's handling of the economy and controversies involving his wife, Kim Keon Hee.

## Live: South Korea's president reverses martial law decision after lawmakers vote against declaration
 - [https://www.channelnewsasia.com/east-asia/south-korea-martial-law-yoon-suk-yeol-live-4784761](https://www.channelnewsasia.com/east-asia/south-korea-martial-law-yoon-suk-yeol-live-4784761)
 - RSS feed: $source
 - date published: 2024-12-04T01:37:30.864926+00:00

None

## Suntec City brings you POP BEAN premiums and shopping rewards this Christmas
 - [https://www.channelnewsasia.com/advertorial/suntec-city-brings-you-pop-bean-premiums-and-shopping-rewards-christmas-4754071](https://www.channelnewsasia.com/advertorial/suntec-city-brings-you-pop-bean-premiums-and-shopping-rewards-christmas-4754071)
 - RSS feed: $source
 - date published: 2024-12-04T01:37:30.411244+00:00

Spark holiday cheer with festive perks and adorable collectibles, including the pink DIMOO Wish Deer bag charm, exclusive to Singapore in Southeast Asia.

## Shoring up cyber defence with artificial intelligence
 - [https://www.channelnewsasia.com/advertorial/shoring-up-cyber-defence-artificial-intelligence-4732771](https://www.channelnewsasia.com/advertorial/shoring-up-cyber-defence-artificial-intelligence-4732771)
 - RSS feed: $source
 - date published: 2024-12-04T01:37:29.987538+00:00

Veritas Technologies is enhancing data protection through innovative solutions, helping businesses navigate the challenges of a dynamic digital landscape.

## Taiwan's President Lai visits Pacific ally Tuvalu
 - [https://www.channelnewsasia.com/world/taiwans-president-lai-visits-pacific-ally-tuvalu-4785641](https://www.channelnewsasia.com/world/taiwans-president-lai-visits-pacific-ally-tuvalu-4785641)
 - RSS feed: $source
 - date published: 2024-12-04T01:37:29.522553+00:00

None

## Fonseca content with Milan's serious attitude in easy Sassuolo win
 - [https://www.channelnewsasia.com/sport/fonseca-content-milans-serious-attitude-easy-sassuolo-win-4785541](https://www.channelnewsasia.com/sport/fonseca-content-milans-serious-attitude-easy-sassuolo-win-4785541)
 - RSS feed: $source
 - date published: 2024-12-04T00:27:54.569227+00:00

None

## Saudi Arabia's 2034 World Cup bid chief highlights human rights progress
 - [https://www.channelnewsasia.com/sport/saudi-arabias-2034-world-cup-bid-chief-highlights-human-rights-progress-4785546](https://www.channelnewsasia.com/sport/saudi-arabias-2034-world-cup-bid-chief-highlights-human-rights-progress-4785546)
 - RSS feed: $source
 - date published: 2024-12-04T00:27:54.368329+00:00

None

## Qatar to invest $1.3 billion in climate technology in Britain
 - [https://www.channelnewsasia.com/business/qatar-invest-13-billion-climate-technology-britain-4785576](https://www.channelnewsasia.com/business/qatar-invest-13-billion-climate-technology-britain-4785576)
 - RSS feed: $source
 - date published: 2024-12-04T00:27:54.135751+00:00

None

