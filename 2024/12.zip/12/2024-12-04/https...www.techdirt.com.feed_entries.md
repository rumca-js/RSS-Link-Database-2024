# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## Techdirt Podcast Episode 407: Brendan Carr Is A Threat To Free Speech
 - [https://www.techdirt.com/2024/12/04/techdirt-podcast-episode-407-brendan-carr-is-a-threat-to-free-speech](https://www.techdirt.com/2024/12/04/techdirt-podcast-episode-407-brendan-carr-is-a-threat-to-free-speech)
 - RSS feed: $source
 - date published: 2024-12-04T21:29:00+00:00

Support us on Patreon&#160;&#187; We&#8217;ve written about the many signs that Trump FCC pick Brendan Carr is eager to be America&#8217;s top censor. Recently, Mike once again joined Andy Levy on The New Abnormal podcast for a discussion about how much of a threat Carr represents to free speech and the First Amendment, and you [&#8230;]

## Federal Court Says Dismantling A Phone To Install Firmware Isn’t A ‘Search,’ Even If Was Done To Facilitate A Search
 - [https://www.techdirt.com/2024/12/04/federal-court-says-dismantling-a-phone-to-install-firmware-isnt-a-search-even-if-was-done-to-facilitate-a-search](https://www.techdirt.com/2024/12/04/federal-court-says-dismantling-a-phone-to-install-firmware-isnt-a-search-even-if-was-done-to-facilitate-a-search)
 - RSS feed: $source
 - date published: 2024-12-04T19:48:07+00:00

This is probably the correct conclusion to arrive at, at least at this point in extremely limited jurisprudence, but it still raises some questions courts will likely have to confront in the future. Is manhandling a phone to make it responsive to a search itself a search, or does the Fourth Amendment not kick in [&#8230;]

## Elon Musk Should Be Shouting About The Florida And Texas Social Media Laws (But Are You Surprised That He’s Not?)
 - [https://www.techdirt.com/2024/12/04/elon-musk-should-be-shouting-about-the-florida-and-texas-social-media-laws-but-are-you-surprised-that-hes-not](https://www.techdirt.com/2024/12/04/elon-musk-should-be-shouting-about-the-florida-and-texas-social-media-laws-but-are-you-surprised-that-hes-not)
 - RSS feed: $source
 - date published: 2024-12-04T17:27:33+00:00

In May 2022 Thierry Breton, at the time a prominent European Commissioner, went to Texas and dropped in on Elon Musk, who was then on his way to buying Twitter. During his visit, Breton did something remarkable: he showed that Elon, whatever his other accomplishments, is a sucker’s sucker. In a video posted on social [&#8230;]

## Senator Ernst Wants To Kill Billions In Broadband Infrastructure Grants For No Coherent Reason
 - [https://www.techdirt.com/2024/12/04/senator-ernst-wants-to-kill-billions-in-broadband-infrastructure-grants-for-no-coherent-reason](https://www.techdirt.com/2024/12/04/senator-ernst-wants-to-kill-billions-in-broadband-infrastructure-grants-for-no-coherent-reason)
 - RSS feed: $source
 - date published: 2024-12-04T13:23:33+00:00

The 2021 infrastructure bill is poised to deliver&#160;$42.5&#160;billion&#160;in broadband subsidies to the states under a program called Broadband Equity, Access, And Deployment (BEAD). This program has been slow sledding, because America&#8217;s broadband maps were absolute garbage, requiring that states work overtime to fix our broadband maps and ensure the money is spent semi-wisely. Republicans and [&#8230;]

## Why Generative AI’s Lack Of Modularity Means It Can’t Be Meaningfully Open, Is Unreliable, And Is A Technological Dead End
 - [https://www.techdirt.com/2024/12/03/why-generative-ais-lack-of-modularity-means-it-cant-be-meaningfully-open-is-unreliable-and-is-a-technological-dead-end](https://www.techdirt.com/2024/12/03/why-generative-ais-lack-of-modularity-means-it-cant-be-meaningfully-open-is-unreliable-and-is-a-technological-dead-end)
 - RSS feed: $source
 - date published: 2024-12-04T04:07:00+00:00

One of the most important shifts in computing over the last few decades has been the increasing use of open source software on nearly every platform, from cloud computing to smartphones (well, I would say that). For the distributed development methodology pioneered by Linus Torvalds with Linux to work, modularity is key. It allows coders [&#8230;]

