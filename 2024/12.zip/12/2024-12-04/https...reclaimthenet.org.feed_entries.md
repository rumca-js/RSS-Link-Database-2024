# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed, language:en-US

## Meta’s Nick Clegg Admits Excessive Censorship and High Error Rates in Content Moderation
 - [https://reclaimthenet.org/metas-nick-clegg-admits-high-content-moderation-errors](https://reclaimthenet.org/metas-nick-clegg-admits-high-content-moderation-errors)
 - RSS feed: $source
 - date published: 2024-12-04T20:05:57+00:00

<a href="https://reclaimthenet.org/metas-nick-clegg-admits-high-content-moderation-errors" title="Meta&#8217;s Nick Clegg Admits Excessive Censorship and High Error Rates in Content Moderation" rel="nofollow"><img width="2560" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/12/zuck-clegg-scaled.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="Zuckerberg and Clegg sitting in separate rooms, one wears a black shirt, the other a light-colored shirt with glasses." style="display: block; margin: auto; margin-bottom: 15px;max-width: 100%;" link_thumbnail="1" decoding="async" srcset="https://reclaimthenet.org/wp-content/uploads/2024/12/zuck-clegg-scaled.jpg 2560w, https://reclaimthenet.org/wp-content/uploads/2024/12/zuck-clegg-300x169.jpg 300w, https://reclaimthenet.org/wp-content/uploads/2024/12/zuck-clegg-1024x576.jpg 1024w, https://reclaimthenet.org/wp-content/uploads/2024/12/zuck-clegg-768x432.jpg 768w, https://reclaimthenet.org/wp-content/uploads/2024/12/zuck

## UK’s “Safety” Watchdog Forms New “Misinformation” Taskforce
 - [https://reclaimthenet.org/uks-safety-watchdog-forms-new-misinformation-taskforce](https://reclaimthenet.org/uks-safety-watchdog-forms-new-misinformation-taskforce)
 - RSS feed: $source
 - date published: 2024-12-04T20:03:39+00:00

<a href="https://reclaimthenet.org/uks-safety-watchdog-forms-new-misinformation-taskforce" title="UK’s &#8220;Safety&#8221; Watchdog Forms New &#8220;Misinformation&#8221; Taskforce" rel="nofollow"><img width="2560" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/12/uk-speech-sl-scaled.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="Weathered Union Jack flag with colorful speech bubbles." style="display: block; margin: auto; margin-bottom: 15px;max-width: 100%;" link_thumbnail="1" decoding="async" srcset="https://reclaimthenet.org/wp-content/uploads/2024/12/uk-speech-sl-scaled.jpg 2560w, https://reclaimthenet.org/wp-content/uploads/2024/12/uk-speech-sl-300x169.jpg 300w, https://reclaimthenet.org/wp-content/uploads/2024/12/uk-speech-sl-1024x576.jpg 1024w, https://reclaimthenet.org/wp-content/uploads/2024/12/uk-speech-sl-768x432.jpg 768w, https://reclaimthenet.org/wp-content/uploads/2024/12/uk-speech-sl-1536x864.jpg 1536w, https://reclaimthenet.org/wp-conten

## Lawyers Slam DOJ’s “Insane” Online Gag Order Against Texas Doctor Who Exposed Controversial Practices on Children
 - [https://reclaimthenet.org/doj-gag-order-dr-eithan-haim-transgender-whistleblower-case](https://reclaimthenet.org/doj-gag-order-dr-eithan-haim-transgender-whistleblower-case)
 - RSS feed: $source
 - date published: 2024-12-04T20:01:37+00:00

<a href="https://reclaimthenet.org/doj-gag-order-dr-eithan-haim-transgender-whistleblower-case" title="Lawyers Slam DOJ&#8217;s &#8220;Insane&#8221; Online Gag Order Against Texas Doctor Who Exposed Controversial Practices on Children" rel="nofollow"><img width="2560" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/12/Dr-Eithan-Haim-scaled.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="Dr. Haim with short brown hair wearing green scrubs and a wireless earbud." style="display: block; margin: auto; margin-bottom: 15px;max-width: 100%;" link_thumbnail="1" decoding="async" srcset="https://reclaimthenet.org/wp-content/uploads/2024/12/Dr-Eithan-Haim-scaled.jpg 2560w, https://reclaimthenet.org/wp-content/uploads/2024/12/Dr-Eithan-Haim-300x169.jpg 300w, https://reclaimthenet.org/wp-content/uploads/2024/12/Dr-Eithan-Haim-1024x576.jpg 1024w, https://reclaimthenet.org/wp-content/uploads/2024/12/Dr-Eithan-Haim-768x432.jpg 768w, https://reclaimthenet.org/wp-content/up

## Trump Taps Gail Slater to Lead Justice Department Shakeup
 - [https://reclaimthenet.org/trump-taps-gail-slater-to-lead-justice-department-shakeup](https://reclaimthenet.org/trump-taps-gail-slater-to-lead-justice-department-shakeup)
 - RSS feed: $source
 - date published: 2024-12-04T19:15:56+00:00

<a href="https://reclaimthenet.org/trump-taps-gail-slater-to-lead-justice-department-shakeup" title="Trump Taps Gail Slater to Lead Justice Department Shakeup" rel="nofollow"><img width="2560" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/12/white-house-digital-scaled.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="A digital illustration of the White House surrounded by binary code and digital data streams, symbolizing technology or cybersecurity themes." style="display: block; margin: auto; margin-bottom: 15px;max-width: 100%;" link_thumbnail="1" decoding="async" srcset="https://reclaimthenet.org/wp-content/uploads/2024/12/white-house-digital-scaled.jpg 2560w, https://reclaimthenet.org/wp-content/uploads/2024/12/white-house-digital-300x169.jpg 300w, https://reclaimthenet.org/wp-content/uploads/2024/12/white-house-digital-1024x576.jpg 1024w, https://reclaimthenet.org/wp-content/uploads/2024/12/white-house-digital-768x432.jpg 768w, https://reclaimthenet.o

## Verizon, AT&T, and T-Mobile Say They Have a Legal Right To Track You and Sell Your Data
 - [https://reclaimthenet.org/verizon-att-and-t-mobile-say-they-have-a-legal-right-to-track-you-and-sell-your-data](https://reclaimthenet.org/verizon-att-and-t-mobile-say-they-have-a-legal-right-to-track-you-and-sell-your-data)
 - RSS feed: $source
 - date published: 2024-12-04T18:38:20+00:00

<a href="https://reclaimthenet.org/verizon-att-and-t-mobile-say-they-have-a-legal-right-to-track-you-and-sell-your-data" title="Verizon, AT&#038;T, and T-Mobile Say They Have a Legal Right To Track You and Sell Your Data" rel="nofollow"><img width="2560" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/12/telecom-tower-3-scaled.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="Cell towers on a hill with a digital network overlay at sunset." style="display: block; margin: auto; margin-bottom: 15px;max-width: 100%;" link_thumbnail="1" decoding="async" srcset="https://reclaimthenet.org/wp-content/uploads/2024/12/telecom-tower-3-scaled.jpg 2560w, https://reclaimthenet.org/wp-content/uploads/2024/12/telecom-tower-3-300x169.jpg 300w, https://reclaimthenet.org/wp-content/uploads/2024/12/telecom-tower-3-1024x576.jpg 1024w, https://reclaimthenet.org/wp-content/uploads/2024/12/telecom-tower-3-768x432.jpg 768w, https://reclaimthenet.org/wp-content/uploads/2024/12/teleco

