# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Telegram U-turns and joins child safety scheme
 - [https://www.bbc.com/news/articles/c5yd35l0r91o](https://www.bbc.com/news/articles/c5yd35l0r91o)
 - RSS feed: $source
 - date published: 2024-12-04T04:56:55+00:00

It is the latest in a series of changes announced by the platform since its founder Pavel Durov was arrested.

