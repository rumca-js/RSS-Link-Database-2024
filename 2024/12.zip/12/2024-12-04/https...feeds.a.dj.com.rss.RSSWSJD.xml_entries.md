# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## OpenAI Enters Silicon Valley's Hot New Business: War
 - [https://www.wsj.com/articles/openai-enters-silicon-valleys-hot-new-business-war-7beccf6e?mod=rss_Technology](https://www.wsj.com/articles/openai-enters-silicon-valleys-hot-new-business-war-7beccf6e?mod=rss_Technology)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:00+00:00

The artificial-intelligence company behind ChatGPT has agreed to put its powerful tech in Anduril Industries’ drone defense systems.

## OpenAI Expands in Europe With Zurich Office
 - [https://www.wsj.com/articles/openai-expands-in-europe-with-zurich-office-f3425003?mod=rss_Technology](https://www.wsj.com/articles/openai-expands-in-europe-with-zurich-office-f3425003?mod=rss_Technology)
 - RSS feed: $source
 - date published: 2024-12-04T06:25:00+00:00

OpenAI said it would set up a new office in Zurich, Switzerland, as part of efforts from the ChatGPT maker to bolster its presence in Europe as the continent emerges as a key battleground for regulating artificial intelligence.

## Tech, Media & Telecom Roundup: Market Talk
 - [https://www.wsj.com/articles/tech-media-telecom-roundup-market-talk-f2678219?mod=rss_Technology](https://www.wsj.com/articles/tech-media-telecom-roundup-market-talk-f2678219?mod=rss_Technology)
 - RSS feed: $source
 - date published: 2024-12-04T04:39:00+00:00

Find insight on Chinese chip makers, Salesforce and more in the latest Market Talks covering technology, media and telecom.

