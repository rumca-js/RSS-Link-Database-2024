# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: The Savage Sword of Conan #5
 - [https://www.grimdarkmagazine.com/review-the-savage-sword-of-conan-5](https://www.grimdarkmagazine.com/review-the-savage-sword-of-conan-5)
 - RSS feed: $source
 - date published: 2024-12-04T04:25:28+00:00

<p>While previous issues have included at least one entry spotlighting a different Robert E. Howard character, the fifth issue of Titan Comics’ bimonthly magazine The Savage Sword of Conan delivers three stories exclusively focusing on Conan at different stages in his life. The issue opens with “The Ensorcelled” by Jason Aaron, with art by Geof Isherwood. Bearded King Conan is visiting the chaotic Brythunian borderlands, trying to help the local royalty secure their demesnes, lest their upheaval affect Conan’s neighboring kingdom of Aquilonia. While hunting with the foppish King Fabiano Conan encounters the infamous Witch of Graaskal, blamed for a host of misdeeds including child-murder. While Conan witnesses her powerful sorcery firsthand, he soon grows skeptical of the litany of crimes of which the witch is accused. King Conan intervenes on the witch’s behalf, even though it brings him into conflict with King Fabiano. “The Ensorcelled” features some interesting twists along the way

