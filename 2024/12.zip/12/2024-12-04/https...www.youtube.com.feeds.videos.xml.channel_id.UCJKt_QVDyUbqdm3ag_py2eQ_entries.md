# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: Mutetus - Blower Orchestra (SIDFX 6581 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=hmdfqSc44Jk](https://www.youtube.com/watch?v=hmdfqSc44Jk)
 - RSS feed: $source
 - date published: 2024-12-04T20:58:49+00:00

"Blower Orchestra" by Mutetus/Artline Designs^Onslaught, 7th at Psykoz 2023 mixed compo.
Art "Beatitboi" by Sulevi/Extend^Virtual Dreams, 2nd at Transmission64 2023 gfx compo.

Made using real C64 audio in SIDFX dual mono config (identical audio for both chips). Brainworx VST effects applied.

Left channel: MOS 6581R4AR 4486 14 Hong Kong HH452134 HC-30
Right channel: MOS 6581R4 3686 S Philippines IH352105 HC-30

These chips are on the "brighter" side (ok'ish with Lightforce/IK+)

