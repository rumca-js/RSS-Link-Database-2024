# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Woke Dungeons And Dragons
 - [https://www.youtube.com/watch?v=cEAsMMx_1jg](https://www.youtube.com/watch?v=cEAsMMx_1jg)
 - RSS feed: $source
 - date published: 2024-12-04T21:35:26+00:00

The new edition of Dungeons and Dragons includes trigger warnings for content you feel is objectionable. Plus, Orcs and Beholders are cute and friendly now! Enjoy this playthrough session of the new, improved, more inclusive D&D.

Become a premium subscriber: https://buff.ly/3mxrUba

The Official The Babylon Bee Store: https://shop.babylonbee.com/

Follow The Babylon Bee:
Website: https://babylonbee.com/
X: https://X.com/thebabylonbee
Facebook: https://www.facebook.com/TheBabylonBee
Instagram: http://instagram.com/thebabylonbee

#dnd #dungeonsanddragons #gameplay #babylonbee #comedy

