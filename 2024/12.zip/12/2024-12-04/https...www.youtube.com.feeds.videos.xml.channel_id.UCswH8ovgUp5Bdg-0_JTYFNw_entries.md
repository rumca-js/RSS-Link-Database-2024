# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## WHAT THE F*** IS GOING ON IN SOUTH KOREA?!
 - [https://www.youtube.com/watch?v=KQhFcp5k5hA](https://www.youtube.com/watch?v=KQhFcp5k5hA)
 - RSS feed: $source
 - date published: 2024-12-04T19:54:08+00:00

Go to http://rumble.com/premium/brand and use code BRAND to save $10 off!

Watch my new Locals series 'The Oracles' here: https://russellbrand.locals.com/upost/6159441/the-last-pandemic-and-the-next-pandemic

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Watch my exclusive LIVE weekly special, “Break Bread”, get access to all of my interviews a week early, send in questions for me to respond to with guests, and more HERE: https://bit.ly/joinlocals

All links: https://linktr.ee/RussellBrand

## MARTIAL LAW IMPLIMENTED IN SOUTH KOREA! Tyranny or Defending the Peace? – SF507
 - [https://www.youtube.com/watch?v=59OUNn99wkg](https://www.youtube.com/watch?v=59OUNn99wkg)
 - RSS feed: $source
 - date published: 2024-12-04T17:25:53+00:00

Order today at http://www.1775coffee.com/BRAND - code BRAND  to save 15% off your order

Go to http://rumble.com/premium/brand and use code BRAND to save $10 off!

⏰ BE HERE AT 12PM ET / 5PM GMT ⏰

Join us here for a PREVIEW of our daily one-hour RUMBLE show. 
To continue watching the show in full, join me exclusively over on RUMBLE: https://bit.ly/SF507-live

In today’s show – South Korea takes center stage as President Yoon’s brief martial law declaration amidst corruption allegations raises serious questions about democracy, authoritarianism, and U.S. influence. Mike Benz’s insights help unravel how soft power shapes these narratives and the broader implications for global politics.

Elsewhere, we’ll touch on the absurdity of leadership missteps, cracks in political unity, and media clashes over truth and censorship—if we can fit it all in!

