# Source:r/gaming, URL:https://www.reddit.com/r/gaming/.rss, language:

## POV its 2000 and you're about to buy your first pokemon game.
 - [https://www.reddit.com/r/gaming/comments/1h6ubk9/pov_its_2000_and_youre_about_to_buy_your_first](https://www.reddit.com/r/gaming/comments/1h6ubk9/pov_its_2000_and_youre_about_to_buy_your_first)
 - RSS feed: $source
 - date published: 2024-12-04T23:16:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6ubk9/pov_its_2000_and_youre_about_to_buy_your_first/"> <img src="https://preview.redd.it/v11twczxzw4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c819398be008b894cfd8bc99b84298e060fc492e" alt="POV its 2000 and you're about to buy your first pokemon game." title="POV its 2000 and you're about to buy your first pokemon game." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ZooterTheWooter"> /u/ZooterTheWooter </a> <br/> <span><a href="https://i.redd.it/v11twczxzw4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6ubk9/pov_its_2000_and_youre_about_to_buy_your_first/">[comments]</a></span> </td></tr></table>

## [Katamari damacy] The most 2009 Video Game Choice.
 - [https://www.reddit.com/r/gaming/comments/1h6t7eq/katamari_damacy_the_most_2009_video_game_choice](https://www.reddit.com/r/gaming/comments/1h6t7eq/katamari_damacy_the_most_2009_video_game_choice)
 - RSS feed: $source
 - date published: 2024-12-04T22:28:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6t7eq/katamari_damacy_the_most_2009_video_game_choice/"> <img src="https://preview.redd.it/ggv4kddfrw4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a41da0a5ab1f8b9d3a551235d196f8bd863ef394" alt="[Katamari damacy] The most 2009 Video Game Choice." title="[Katamari damacy] The most 2009 Video Game Choice." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ashensnake02"> /u/Ashensnake02 </a> <br/> <span><a href="https://i.redd.it/ggv4kddfrw4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6t7eq/katamari_damacy_the_most_2009_video_game_choice/">[comments]</a></span> </td></tr></table>

## Remember Mini Consoles, did you own some, what are your thoughts on them?
 - [https://www.reddit.com/r/gaming/comments/1h6r8td/remember_mini_consoles_did_you_own_some_what_are](https://www.reddit.com/r/gaming/comments/1h6r8td/remember_mini_consoles_did_you_own_some_what_are)
 - RSS feed: $source
 - date published: 2024-12-04T21:08:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6r8td/remember_mini_consoles_did_you_own_some_what_are/"> <img src="https://preview.redd.it/iaisv353dw4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4a1a6399e4a40e5e4f696886d1665be833d3409c" alt="Remember Mini Consoles, did you own some, what are your thoughts on them?" title="Remember Mini Consoles, did you own some, what are your thoughts on them?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/115_zombie_slayer"> /u/115_zombie_slayer </a> <br/> <span><a href="https://i.redd.it/iaisv353dw4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6r8td/remember_mini_consoles_did_you_own_some_what_are/">[comments]</a></span> </td></tr></table>

## Kingmakers | Winter Games Expo Trailer - Early Access Release in Q1 2025 AD
 - [https://www.reddit.com/r/gaming/comments/1h6pvu2/kingmakers_winter_games_expo_trailer_early_access](https://www.reddit.com/r/gaming/comments/1h6pvu2/kingmakers_winter_games_expo_trailer_early_access)
 - RSS feed: $source
 - date published: 2024-12-04T20:13:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6pvu2/kingmakers_winter_games_expo_trailer_early_access/"> <img src="https://external-preview.redd.it/yxizAN1qe2uUtShFnJQmHCToc9dxPCBWsDucw_TuJeQ.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=6b627740c89aa7654c15f5658e7fcb6bc1c69f5e" alt="Kingmakers | Winter Games Expo Trailer - Early Access Release in Q1 2025 AD" title="Kingmakers | Winter Games Expo Trailer - Early Access Release in Q1 2025 AD" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/abcinng"> /u/abcinng </a> <br/> <span><a href="https://www.youtube.com/watch?v=ZXujvsd9C58">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6pvu2/kingmakers_winter_games_expo_trailer_early_access/">[comments]</a></span> </td></tr></table>

## Another W for Marvel Rivals
 - [https://www.reddit.com/r/gaming/comments/1h6pa76/another_w_for_marvel_rivals](https://www.reddit.com/r/gaming/comments/1h6pa76/another_w_for_marvel_rivals)
 - RSS feed: $source
 - date published: 2024-12-04T19:49:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6pa76/another_w_for_marvel_rivals/"> <img src="https://preview.redd.it/dididwpuyv4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=52daec3f36b00341eb7467247864e8b69e79fe9d" alt="Another W for Marvel Rivals" title="Another W for Marvel Rivals" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/critxcanuck88"> /u/critxcanuck88 </a> <br/> <span><a href="https://i.redd.it/dididwpuyv4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6pa76/another_w_for_marvel_rivals/">[comments]</a></span> </td></tr></table>

## I still have my original copy of Half Life 2. Was a Christmas gift from my wife in 2004, though I think she gave it to me a little earlier.
 - [https://www.reddit.com/r/gaming/comments/1h6p3xg/i_still_have_my_original_copy_of_half_life_2_was](https://www.reddit.com/r/gaming/comments/1h6p3xg/i_still_have_my_original_copy_of_half_life_2_was)
 - RSS feed: $source
 - date published: 2024-12-04T19:41:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6p3xg/i_still_have_my_original_copy_of_half_life_2_was/"> <img src="https://preview.redd.it/i90iocwnxv4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f983db07a20d9b02c5a3949b8e03b1905d872af3" alt="I still have my original copy of Half Life 2. Was a Christmas gift from my wife in 2004, though I think she gave it to me a little earlier." title="I still have my original copy of Half Life 2. Was a Christmas gift from my wife in 2004, though I think she gave it to me a little earlier." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ecnerwal1234"> /u/ecnerwal1234 </a> <br/> <span><a href="https://i.redd.it/i90iocwnxv4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6p3xg/i_still_have_my_original_copy_of_half_life_2_was/">[comments]</a></span> </td></tr></table>

## The last time I seriously played and enjoyed COD
 - [https://www.reddit.com/r/gaming/comments/1h6ngkh/the_last_time_i_seriously_played_and_enjoyed_cod](https://www.reddit.com/r/gaming/comments/1h6ngkh/the_last_time_i_seriously_played_and_enjoyed_cod)
 - RSS feed: $source
 - date published: 2024-12-04T18:36:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6ngkh/the_last_time_i_seriously_played_and_enjoyed_cod/"> <img src="https://preview.redd.it/h2syc7rwlv4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bc1b12345d3816e523038c59ddcb78d0569b7082" alt="The last time I seriously played and enjoyed COD" title="The last time I seriously played and enjoyed COD" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Going through my old game storage found physical disks of oblivion, Morrowind, Aion, Diablo three and this old classic. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MinervaMedica000"> /u/MinervaMedica000 </a> <br/> <span><a href="https://i.redd.it/h2syc7rwlv4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6ngkh/the_last_time_i_seriously_played_and_enjoyed_cod/">[comments]</a></span> </td></tr></table>

## A gem from the XBOX One launch. What were they thinking?
 - [https://www.reddit.com/r/gaming/comments/1h6lvec/a_gem_from_the_xbox_one_launch_what_were_they](https://www.reddit.com/r/gaming/comments/1h6lvec/a_gem_from_the_xbox_one_launch_what_were_they)
 - RSS feed: $source
 - date published: 2024-12-04T17:33:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6lvec/a_gem_from_the_xbox_one_launch_what_were_they/"> <img src="https://preview.redd.it/r5a9h8gpav4e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=529a8c4ac1d6c124a96899bb272dc7f49bee0521" alt="A gem from the XBOX One launch. What were they thinking?" title="A gem from the XBOX One launch. What were they thinking?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/anonAcc1993"> /u/anonAcc1993 </a> <br/> <span><a href="https://i.redd.it/r5a9h8gpav4e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6lvec/a_gem_from_the_xbox_one_launch_what_were_they/">[comments]</a></span> </td></tr></table>

## Kingdom Come: Deliverance 2 will offer 60fps on PS5/XSX, new release date February 4th
 - [https://www.reddit.com/r/gaming/comments/1h6lhv2/kingdom_come_deliverance_2_will_offer_60fps_on](https://www.reddit.com/r/gaming/comments/1h6lhv2/kingdom_come_deliverance_2_will_offer_60fps_on)
 - RSS feed: $source
 - date published: 2024-12-04T17:19:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6lhv2/kingdom_come_deliverance_2_will_offer_60fps_on/"> <img src="https://external-preview.redd.it/DtGW4Yc4q99SkBGpfERj5G4k7mNoVwKkOn_bRlRCvH0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=df9baf2886f47ae47f1dcde55e62493eba7486ab" alt="Kingdom Come: Deliverance 2 will offer 60fps on PS5/XSX, new release date February 4th" title="Kingdom Come: Deliverance 2 will offer 60fps on PS5/XSX, new release date February 4th" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Paul_cz"> /u/Paul_cz </a> <br/> <span><a href="https://x.com/WarhorseStudios/status/1864354217139314820">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6lhv2/kingdom_come_deliverance_2_will_offer_60fps_on/">[comments]</a></span> </td></tr></table>

## The most 2009 Video Game Choice
 - [https://www.reddit.com/r/gaming/comments/1h6kvzc/the_most_2009_video_game_choice](https://www.reddit.com/r/gaming/comments/1h6kvzc/the_most_2009_video_game_choice)
 - RSS feed: $source
 - date published: 2024-12-04T16:55:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6kvzc/the_most_2009_video_game_choice/"> <img src="https://preview.redd.it/cnh9vp3x3v4e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=fd8f26e784e1359cf3042f277f932cbd929a2c69" alt="The most 2009 Video Game Choice " title="The most 2009 Video Game Choice " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>So long as we&#39;re doing this</p> <p>I know that 09 was a great year for games, but I never remember <em>how</em> good until I see the list</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/twec21"> /u/twec21 </a> <br/> <span><a href="https://i.redd.it/cnh9vp3x3v4e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6kvzc/the_most_2009_video_game_choice/">[comments]</a></span> </td></tr></table>

## Helldivers 2 weapon's realism is insane
 - [https://www.reddit.com/r/gaming/comments/1h6iu7i/helldivers_2_weapons_realism_is_insane](https://www.reddit.com/r/gaming/comments/1h6iu7i/helldivers_2_weapons_realism_is_insane)
 - RSS feed: $source
 - date published: 2024-12-04T15:33:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6iu7i/helldivers_2_weapons_realism_is_insane/"> <img src="https://external-preview.redd.it/oswAvMzD8_s6L2Y8CgI0mYf0C9q8GYlT2CE6ttiHB2c.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=ddf49a9aa5a8adaaac5e57e9ed06de7a04fd6cc1" alt="Helldivers 2 weapon's realism is insane" title="Helldivers 2 weapon's realism is insane" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MakubeC"> /u/MakubeC </a> <br/> <span><a href="https://www.youtube.com/watch?v=u2dxexfGf44">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6iu7i/helldivers_2_weapons_realism_is_insane/">[comments]</a></span> </td></tr></table>

## Sony was “lucky to survive” the PS3 era, says ex PlayStation boss Shawn Layden - “PS3 was Sony’s Icarus moment. We flew too close to the sun,”
 - [https://www.reddit.com/r/gaming/comments/1h6ih1y/sony_was_lucky_to_survive_the_ps3_era_says_ex](https://www.reddit.com/r/gaming/comments/1h6ih1y/sony_was_lucky_to_survive_the_ps3_era_says_ex)
 - RSS feed: $source
 - date published: 2024-12-04T15:18:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6ih1y/sony_was_lucky_to_survive_the_ps3_era_says_ex/"> <img src="https://external-preview.redd.it/wgywthXD2urfqfyCL61MbZRj1uu-moilYuxG38GOGRU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f243c040922710d180f9f90ac5cf9b795f021eef" alt="Sony was “lucky to survive” the PS3 era, says ex PlayStation boss Shawn Layden - “PS3 was Sony’s Icarus moment. We flew too close to the sun,”" title="Sony was “lucky to survive” the PS3 era, says ex PlayStation boss Shawn Layden - “PS3 was Sony’s Icarus moment. We flew too close to the sun,”" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ChiefLeef22"> /u/ChiefLeef22 </a> <br/> <span><a href="https://www.playstationlifestyle.net/2024/12/03/sony-felt-lucky-survived-ps3-struggles-says-shawn-layden/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6ih1y/sony_was_lucky_to_survive_the_ps3_era_says_ex/">[comments]</a></sp

## How do I fill the hole that finishing Titanfall 2 left in me?
 - [https://www.reddit.com/r/gaming/comments/1h6ib47/how_do_i_fill_the_hole_that_finishing_titanfall_2](https://www.reddit.com/r/gaming/comments/1h6ib47/how_do_i_fill_the_hole_that_finishing_titanfall_2)
 - RSS feed: $source
 - date published: 2024-12-04T15:11:26+00:00

<!-- SC_OFF --><div class="md"><p>After a lot of recommendations, I bought Titanfall 2 this steam sale. What I didn&#39;t know is how short this game is. As I started to become accustomed to it&#39;s gameplay and mechanics especially controlling the Titan, it ended and man i haven&#39;t been this disappointed in a while. I was really enjoying the mission design, the unique platforming, the dynamic between BT and pilot and ther overall badass feeling of controlling a giant mech.</p> <p>Unfortunately for me though, I can really play online multiplayer as I don&#39;t think there are SEA servers for this game. </p> <p>Anyways I was hoping you guys could recommend me some games which offer the same unique gameplay as Titanfall 2.</p> <p>Really appreciate your suggestions..</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Top_Distribution_497"> /u/Top_Distribution_497 </a> <br/> <span><a href="https://www.reddit.com/r/gaming/comments/1h6ib47/how_do_i_f

## The most 2009 video game choice
 - [https://www.reddit.com/r/gaming/comments/1h6hyre/the_most_2009_video_game_choice](https://www.reddit.com/r/gaming/comments/1h6hyre/the_most_2009_video_game_choice)
 - RSS feed: $source
 - date published: 2024-12-04T14:57:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6hyre/the_most_2009_video_game_choice/"> <img src="https://preview.redd.it/xihegoopiu4e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=4007ab999e8a857fe6a265f47132a4114ce47ee6" alt="The most 2009 video game choice" title="The most 2009 video game choice" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PalebloodSky"> /u/PalebloodSky </a> <br/> <span><a href="https://i.redd.it/xihegoopiu4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6hyre/the_most_2009_video_game_choice/">[comments]</a></span> </td></tr></table>

## welp, there goes my weekend
 - [https://www.reddit.com/r/gaming/comments/1h6gj4d/welp_there_goes_my_weekend](https://www.reddit.com/r/gaming/comments/1h6gj4d/welp_there_goes_my_weekend)
 - RSS feed: $source
 - date published: 2024-12-04T13:54:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6gj4d/welp_there_goes_my_weekend/"> <img src="https://preview.redd.it/jtyf6wno7u4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9ff99e924d78e6134258ae4f518411982d55490d" alt="welp, there goes my weekend" title="welp, there goes my weekend" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rsjpeckham"> /u/rsjpeckham </a> <br/> <span><a href="https://i.redd.it/jtyf6wno7u4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6gj4d/welp_there_goes_my_weekend/">[comments]</a></span> </td></tr></table>

## What's a habit that you have in multiple different games
 - [https://www.reddit.com/r/gaming/comments/1h6g8lr/whats_a_habit_that_you_have_in_multiple_different](https://www.reddit.com/r/gaming/comments/1h6g8lr/whats_a_habit_that_you_have_in_multiple_different)
 - RSS feed: $source
 - date published: 2024-12-04T13:40:31+00:00

<!-- SC_OFF --><div class="md"><p>My roommate has to unlock every fast travel location as soon as physically possible in every game he plays. When he played Tears of the Kingdom he spent 20 hours going around all of the map unlocking stuff. What&#39;s something you are compelled to do no matter what game it is?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lordlemming"> /u/lordlemming </a> <br/> <span><a href="https://www.reddit.com/r/gaming/comments/1h6g8lr/whats_a_habit_that_you_have_in_multiple_different/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6g8lr/whats_a_habit_that_you_have_in_multiple_different/">[comments]</a></span>

## I digged up a screen cap from 15 years ago.
 - [https://www.reddit.com/r/gaming/comments/1h6g7k9/i_digged_up_a_screen_cap_from_15_years_ago](https://www.reddit.com/r/gaming/comments/1h6g7k9/i_digged_up_a_screen_cap_from_15_years_ago)
 - RSS feed: $source
 - date published: 2024-12-04T13:39:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6g7k9/i_digged_up_a_screen_cap_from_15_years_ago/"> <img src="https://preview.redd.it/2zirk9dx4u4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=540437b04c10f24039e91d76f4882f7b4728d178" alt="I digged up a screen cap from 15 years ago." title="I digged up a screen cap from 15 years ago." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cheezburgapocalypse"> /u/cheezburgapocalypse </a> <br/> <span><a href="https://i.redd.it/2zirk9dx4u4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6g7k9/i_digged_up_a_screen_cap_from_15_years_ago/">[comments]</a></span> </td></tr></table>

## What game has the biggest issue with money being worthles?
 - [https://www.reddit.com/r/gaming/comments/1h6g2sj/what_game_has_the_biggest_issue_with_money_being](https://www.reddit.com/r/gaming/comments/1h6g2sj/what_game_has_the_biggest_issue_with_money_being)
 - RSS feed: $source
 - date published: 2024-12-04T13:32:56+00:00

<!-- SC_OFF --><div class="md"><p>Money makes the world go round, but in many video game worlds, it often ends up worthless, so monetary rewards can end up moot.</p> <p>The Legend of Zelda series has a recurring problem, the worst cases I have seen are Breath of the Wild and Echoes of Wisdom (I haven&#39;t played Tears yet). Despite Breath of the Wild not having money you can find by cutting grass, you still end up with more than you&#39;ll ever need because you can sell virtually anything you come across. I often ended up netting a profit from shopping by selling a fraction of the stuff you collect. The are items for sale you can use in cooking, and I didn&#39;t buy most of them because the stuff I found worked fine.</p> <p>The most annoying part for me was that shops did sell special arrows except they quit restocking them if you had enough in your inventory so I was better off find enemies to get more. Past the early game I didn&#39;t need money for anything besides upgrading armo

## The Pokémon TCGP experience
 - [https://www.reddit.com/r/gaming/comments/1h6cswa/the_pokémon_tcgp_experience](https://www.reddit.com/r/gaming/comments/1h6cswa/the_pokémon_tcgp_experience)
 - RSS feed: $source
 - date published: 2024-12-04T10:14:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6cswa/the_pokémon_tcgp_experience/"> <img src="https://preview.redd.it/xc54xzzd4t4e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=8c13d75e4143ecc13d55b43d549a5e2bdd7d1b15" alt="The Pokémon TCGP experience " title="The Pokémon TCGP experience " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheSpectacularBagMan"> /u/TheSpectacularBagMan </a> <br/> <span><a href="https://i.redd.it/xc54xzzd4t4e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6cswa/the_pokémon_tcgp_experience/">[comments]</a></span> </td></tr></table>

## What games in your opinion have the most creative use of physics?
 - [https://www.reddit.com/r/gaming/comments/1h6coj4/what_games_in_your_opinion_have_the_most_creative](https://www.reddit.com/r/gaming/comments/1h6coj4/what_games_in_your_opinion_have_the_most_creative)
 - RSS feed: $source
 - date published: 2024-12-04T10:05:18+00:00

<!-- SC_OFF --><div class="md"><p>Breath of the wild and Tears of the kingdom are obvious picks, they have really creative use of physics in puzzle solving and manipulating the environment. Especially TotK with the ability to rewind time on an object; in essence reverse physics.</p> <p>If I had to pick another, I&#39;d say Human Fall Flat since the whole game kinda revolves around the idea of controlling ragdoll physics.</p> <p>What would be your picks?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Routasoft"> /u/Routasoft </a> <br/> <span><a href="https://www.reddit.com/r/gaming/comments/1h6coj4/what_games_in_your_opinion_have_the_most_creative/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6coj4/what_games_in_your_opinion_have_the_most_creative/">[comments]</a></span>

## Games with a sense of long-term progression and goals?
 - [https://www.reddit.com/r/gaming/comments/1h6bsax/games_with_a_sense_of_longterm_progression_and](https://www.reddit.com/r/gaming/comments/1h6bsax/games_with_a_sense_of_longterm_progression_and)
 - RSS feed: $source
 - date published: 2024-12-04T08:57:24+00:00

<!-- SC_OFF --><div class="md"><p>I love WoW and Tarkov and Runescape, but also Stardew Valley, Rimworld, and a whole bunch of others. </p> <p>Nothing makes me happier than having a game with a sense of long-term progress, like I’ve built something and have something to show for it. For example, I love the Player-Owned house in Runescape and showing off my pets and achievements. I love mounts and transmogs in wow because I love building my own aesthetic based around my greatest moments. I LOVE my hideout in Tarkov because I feel like I made it with my blood, sweat, and tears, and each mannequin with boss armor on it reminds me of those first kills. </p> <p>I’m burned out of most of the above, and while I’m obviously okay with grinding, I need a purpose for it (looking at you WoW) </p> <p>Any suggestions for someone looking for a long-term experience?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ArcadeRay"> /u/ArcadeRay </a> <br/> <span><a hre

## What are you playing Wednesday!
 - [https://www.reddit.com/r/gaming/comments/1h6a7ql/what_are_you_playing_wednesday](https://www.reddit.com/r/gaming/comments/1h6a7ql/what_are_you_playing_wednesday)
 - RSS feed: $source
 - date published: 2024-12-04T07:00:10+00:00

<!-- SC_OFF --><div class="md"><p>What game&#39;s got your attention this week? What&#39;s great about it? What sucks? Tell us all about it! </p> <p>&#x200B;</p> <p>This thread is posted weekly on Wednesdays (adjustments made as needed).</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AutoModerator"> /u/AutoModerator </a> <br/> <span><a href="https://www.reddit.com/r/gaming/comments/1h6a7ql/what_are_you_playing_wednesday/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6a7ql/what_are_you_playing_wednesday/">[comments]</a></span>

## Musings on Video Gaming
 - [https://www.reddit.com/r/gaming/comments/1h67phc/musings_on_video_gaming](https://www.reddit.com/r/gaming/comments/1h67phc/musings_on_video_gaming)
 - RSS feed: $source
 - date published: 2024-12-04T04:27:58+00:00

<!-- SC_OFF --><div class="md"><p>I’m over 65 and have been playing video games (badly) since my Intellevision days. I’m now using a PS5. I have loved games such as The Last of Us, Days Gone, Zelda and so many more and I played almost every day especially since the ps3 days. Recently my hands and wrists have gotten a little painful so I haven’t played in a few weeks. The thing is I don’t miss it. Right now as it stands if I never played again it wouldn’t kill me. It made me wonder how many of us are playing for the love of gaming or because it’s become an easy habit to fall into. When was the last time any of us stopped playing for a week just to catch our breath so to speak? This is a hobby that can consume thousands of hours.Maybe we should set aside some of those hours in levelling ourselves up rather than our avatars. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TemperatureTime1617"> /u/TemperatureTime1617 </a> <br/> <span><a href="https

## A map of my 1:1 fictional Minecraft City after nearly 5 years of work. 2024 update.
 - [https://www.reddit.com/r/gaming/comments/1h679mu/a_map_of_my_11_fictional_minecraft_city_after](https://www.reddit.com/r/gaming/comments/1h679mu/a_map_of_my_11_fictional_minecraft_city_after)
 - RSS feed: $source
 - date published: 2024-12-04T04:03:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h679mu/a_map_of_my_11_fictional_minecraft_city_after/"> <img src="https://preview.redd.it/fmzvjeqs9r4e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=1ebf04f179af61895cf107d6969dfe8704941568" alt="A map of my 1:1 fictional Minecraft City after nearly 5 years of work. 2024 update. " title="A map of my 1:1 fictional Minecraft City after nearly 5 years of work. 2024 update. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/KanyeWaste69"> /u/KanyeWaste69 </a> <br/> <span><a href="https://i.redd.it/fmzvjeqs9r4e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h679mu/a_map_of_my_11_fictional_minecraft_city_after/">[comments]</a></span> </td></tr></table>

## What game gives you a strong feeling of nostalgia and makes you remember everything that happened to you at the time when you were actively playing this game?
 - [https://www.reddit.com/r/gaming/comments/1h66dxl/what_game_gives_you_a_strong_feeling_of_nostalgia](https://www.reddit.com/r/gaming/comments/1h66dxl/what_game_gives_you_a_strong_feeling_of_nostalgia)
 - RSS feed: $source
 - date published: 2024-12-04T03:17:40+00:00

<!-- SC_OFF --><div class="md"><p>I was recently surfing net when, out of nowhere, I decided to open <strong><em>Super Mario 64</em></strong>. No real reason, just a random decision</p> <p>The second the title screen appeared, I felt like I was a kid again. That familiar music, Mario’s face, the vibrant world - it all came rushing back. After a few minutes of gameplay I was literally hooked. Running around, hearing the old sound effects and all that stuff - everything felt so nostalgic</p> <p>Then suddenly memories started flooding in. I remembered where I was when I first played it - the old couch in my living room, the excitement of my first time exploring the game, the friends I used to play it with after school. I hadn’t realized how much I missed it until I was already lost in the game. It was like no time had passed at all</p> <p><strong>Do you have games that make you feel like that?</strong></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/use

## The hidden master
 - [https://www.reddit.com/r/gaming/comments/1h648xr/the_hidden_master](https://www.reddit.com/r/gaming/comments/1h648xr/the_hidden_master)
 - RSS feed: $source
 - date published: 2024-12-04T01:30:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h648xr/the_hidden_master/"> <img src="https://preview.redd.it/vtenpyf0jq4e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=0d849e6b90f2dbdb041a4506b99f1cda856db95a" alt="The hidden master" title="The hidden master" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DreadedDrMaybe"> /u/DreadedDrMaybe </a> <br/> <span><a href="https://i.redd.it/vtenpyf0jq4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h648xr/the_hidden_master/">[comments]</a></span> </td></tr></table>

## The most 2009 video game choice
 - [https://www.reddit.com/r/gaming/comments/1h634lo/the_most_2009_video_game_choice](https://www.reddit.com/r/gaming/comments/1h634lo/the_most_2009_video_game_choice)
 - RSS feed: $source
 - date published: 2024-12-04T00:38:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h634lo/the_most_2009_video_game_choice/"> <img src="https://external-preview.redd.it/XqrRiiLIjcAAZf36Xzl5C5QMxSgT90SAHtGJDke5nZM.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=e5697c904ed4915a1eb6d067f5c9bb1cabaf4829" alt="The most 2009 video game choice" title="The most 2009 video game choice" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JustTrollingYou"> /u/JustTrollingYou </a> <br/> <span><a href="https://i.imgur.com/6xKo70k.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h634lo/the_most_2009_video_game_choice/">[comments]</a></span> </td></tr></table>

## Remember when games were cheap guys?
 - [https://www.reddit.com/r/gaming/comments/1h6347r/remember_when_games_were_cheap_guys](https://www.reddit.com/r/gaming/comments/1h6347r/remember_when_games_were_cheap_guys)
 - RSS feed: $source
 - date published: 2024-12-04T00:37:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h6347r/remember_when_games_were_cheap_guys/"> <img src="https://preview.redd.it/z0vw1o3g9q4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0dd4714038a1d859b5c3098ba20a68524a9ca1a8" alt="Remember when games were cheap guys?" title="Remember when games were cheap guys?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ForegroundEclipse"> /u/ForegroundEclipse </a> <br/> <span><a href="https://i.redd.it/z0vw1o3g9q4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h6347r/remember_when_games_were_cheap_guys/">[comments]</a></span> </td></tr></table>

## XDefiant officially shutting down as Ubisoft announces FPS end date
 - [https://www.reddit.com/r/gaming/comments/1h62k12/xdefiant_officially_shutting_down_as_ubisoft](https://www.reddit.com/r/gaming/comments/1h62k12/xdefiant_officially_shutting_down_as_ubisoft)
 - RSS feed: $source
 - date published: 2024-12-04T00:12:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h62k12/xdefiant_officially_shutting_down_as_ubisoft/"> <img src="https://external-preview.redd.it/WJDTXOgp9x5PYB7Ajvhy6X3Kc-fpF8rjtN3kMBsuHcg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aa9918da60ef5b978548fd27c65776138c7ebd88" alt="XDefiant officially shutting down as Ubisoft announces FPS end date" title="XDefiant officially shutting down as Ubisoft announces FPS end date" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BigT232"> /u/BigT232 </a> <br/> <span><a href="https://www.dexerto.com/gaming/xdefiant-officially-shutting-down-2997613/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h62k12/xdefiant_officially_shutting_down_as_ubisoft/">[comments]</a></span> </td></tr></table>

## Ubisoft Is Discontinuing XDefiant in 2025, San Francisco and Osaka Studios Shutting Down Amid Major Layoffs
 - [https://www.reddit.com/r/gaming/comments/1h62gb1/ubisoft_is_discontinuing_xdefiant_in_2025_san](https://www.reddit.com/r/gaming/comments/1h62gb1/ubisoft_is_discontinuing_xdefiant_in_2025_san)
 - RSS feed: $source
 - date published: 2024-12-04T00:07:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1h62gb1/ubisoft_is_discontinuing_xdefiant_in_2025_san/"> <img src="https://external-preview.redd.it/Ed13IzIsJmZPArFs5f85sFNQzJo9xk0r5OpXLGkn118.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e5df78d3d6ddd32e9ca26f14e4251ab640a4fae7" alt="Ubisoft Is Discontinuing XDefiant in 2025, San Francisco and Osaka Studios Shutting Down Amid Major Layoffs" title="Ubisoft Is Discontinuing XDefiant in 2025, San Francisco and Osaka Studios Shutting Down Amid Major Layoffs" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IcePopsicleDragon"> /u/IcePopsicleDragon </a> <br/> <span><a href="https://in.ign.com/tom-clancys-xdefiant/220442/news/ubisoft-is-discontinuing-xdefiant-in-2025-san-francisco-and-osaka-studios-shutting-down-amid-major-l">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1h62gb1/ubisoft_is_discontinuing_xdefiant_in_2025_san/">[comments]</a></span> </td></

