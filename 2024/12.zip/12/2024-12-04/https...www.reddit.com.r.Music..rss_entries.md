# Source:r/Music, URL:https://www.reddit.com/r/Music/.rss, language:en

## Surviving SOUNDGARDEN Members To Perform At 'SMooCH' Benefit Concert In Seattle
 - [https://www.reddit.com/r/Music/comments/1h6r8yl/surviving_soundgarden_members_to_perform_at](https://www.reddit.com/r/Music/comments/1h6r8yl/surviving_soundgarden_members_to_perform_at)
 - RSS feed: $source
 - date published: 2024-12-04T21:08:34+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Edm_vanhalen1981"> /u/Edm_vanhalen1981 </a> <br/> <span><a href="https://blabbermouth.net/news/surviving-soundgarden-members-to-perform-at-smooch-benefit-concert-in-seattle">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6r8yl/surviving_soundgarden_members_to_perform_at/">[comments]</a></span>

## The Coup - 5 Million ways to kill a CEO [Hip Hop]
 - [https://www.reddit.com/r/Music/comments/1h6r71p/the_coup_5_million_ways_to_kill_a_ceo_hip_hop](https://www.reddit.com/r/Music/comments/1h6r71p/the_coup_5_million_ways_to_kill_a_ceo_hip_hop)
 - RSS feed: $source
 - date published: 2024-12-04T21:06:24+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/CumingLinguist"> /u/CumingLinguist </a> <br/> <span><a href="https://youtu.be/RQthFDpYCys?si=5N0iyX_dW0-bF5yx">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6r71p/the_coup_5_million_ways_to_kill_a_ceo_hip_hop/">[comments]</a></span>

## Roy Orbinson - Ooby Dooby (Live) [pop rock] (1988)
 - [https://www.reddit.com/r/Music/comments/1h6qqb0/roy_orbinson_ooby_dooby_live_pop_rock_1988](https://www.reddit.com/r/Music/comments/1h6qqb0/roy_orbinson_ooby_dooby_live_pop_rock_1988)
 - RSS feed: $source
 - date published: 2024-12-04T20:47:45+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/ThrashMetallix"> /u/ThrashMetallix </a> <br/> <span><a href="https://youtu.be/3TSktJeimjE?si=NxDc9kSZiX57px03">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6qqb0/roy_orbinson_ooby_dooby_live_pop_rock_1988/">[comments]</a></span>

## Bob Dylan Praises His Biopic: 'Timmy’s a brilliant actor so I’m sure he’s going to be completely believable as me. Or a younger me. Or some other me'
 - [https://www.reddit.com/r/Music/comments/1h6qo3a/bob_dylan_praises_his_biopic_timmys_a_brilliant](https://www.reddit.com/r/Music/comments/1h6qo3a/bob_dylan_praises_his_biopic_timmys_a_brilliant)
 - RSS feed: $source
 - date published: 2024-12-04T20:45:14+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Apprehensive_Fly9352"> /u/Apprehensive_Fly9352 </a> <br/> <span><a href="https://www.vulture.com/article/bob-dylan-a-complete-unknown-timothee-chalamet-review.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6qo3a/bob_dylan_praises_his_biopic_timmys_a_brilliant/">[comments]</a></span>

## Sadus Fire Jon Allen After Domestic Violence Videos Show Him Being an Abusive Piece of Shit
 - [https://www.reddit.com/r/Music/comments/1h6phva/sadus_fire_jon_allen_after_domestic_violence](https://www.reddit.com/r/Music/comments/1h6phva/sadus_fire_jon_allen_after_domestic_violence)
 - RSS feed: $source
 - date published: 2024-12-04T19:57:39+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Puzzleheaded-Dig7475"> /u/Puzzleheaded-Dig7475 </a> <br/> <span><a href="https://www.metalsucks.net/2024/12/04/sadus-fire-jon-allen-after-domestic-violence-videos-show-him-being-an-abusive-piece-of-sht/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6phva/sadus_fire_jon_allen_after_domestic_violence/">[comments]</a></span>

## David Bowie Brutally Turned Down A Coldplay Collaboration On Their 6.8 Million Selling Masterpiece - "It's Not A Very Good Song, Is It?"
 - [https://www.reddit.com/r/Music/comments/1h6p0qq/david_bowie_brutally_turned_down_a_coldplay](https://www.reddit.com/r/Music/comments/1h6p0qq/david_bowie_brutally_turned_down_a_coldplay)
 - RSS feed: $source
 - date published: 2024-12-04T19:38:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/HappyHarryHardOn"> /u/HappyHarryHardOn </a> <br/> <span><a href="https://screenrant.com/david-bowie-coldplay-rejection-lhuna-song-factoid/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6p0qq/david_bowie_brutally_turned_down_a_coldplay/">[comments]</a></span>

## The Decemberists - Here I Dreamt I Was An Architect [Alternative/Indie]
 - [https://www.reddit.com/r/Music/comments/1h6o710/the_decemberists_here_i_dreamt_i_was_an_architect](https://www.reddit.com/r/Music/comments/1h6o710/the_decemberists_here_i_dreamt_i_was_an_architect)
 - RSS feed: $source
 - date published: 2024-12-04T19:05:26+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Parklifeee"> /u/Parklifeee </a> <br/> <span><a href="https://youtu.be/qkWrnWRKDJQ?feature=shared">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6o710/the_decemberists_here_i_dreamt_i_was_an_architect/">[comments]</a></span>

## Opeth - The Moor [Progressive Metal / Death Metal]
 - [https://www.reddit.com/r/Music/comments/1h6mp2e/opeth_the_moor_progressive_metal_death_metal](https://www.reddit.com/r/Music/comments/1h6mp2e/opeth_the_moor_progressive_metal_death_metal)
 - RSS feed: $source
 - date published: 2024-12-04T18:05:46+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=5bq8t-DEdJU">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6mp2e/opeth_the_moor_progressive_metal_death_metal/">[comments]</a></span>

## Trent Reznor On The Future Of Nine Inch Nails: "We’re Ready To Be Back In The Driver’s Seat"
 - [https://www.reddit.com/r/Music/comments/1h6mhzq/trent_reznor_on_the_future_of_nine_inch_nails](https://www.reddit.com/r/Music/comments/1h6mhzq/trent_reznor_on_the_future_of_nine_inch_nails)
 - RSS feed: $source
 - date published: 2024-12-04T17:58:06+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DamnitRidley"> /u/DamnitRidley </a> <br/> <span><a href="https://www.theprp.com/2024/12/04/news/trent-reznor-on-the-future-of-nine-inch-nails-were-ready-to-be-back-in-the-drivers-seat/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6mhzq/trent_reznor_on_the_future_of_nine_inch_nails/">[comments]</a></span>

## Dave Gahan Is Unsure of Depeche Mode's Future: 'I wouldn’t rule out as getting together at some point but it’s not on the cards at this point'
 - [https://www.reddit.com/r/Music/comments/1h6lzps/dave_gahan_is_unsure_of_depeche_modes_future_i](https://www.reddit.com/r/Music/comments/1h6lzps/dave_gahan_is_unsure_of_depeche_modes_future_i)
 - RSS feed: $source
 - date published: 2024-12-04T17:38:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Apprehensive_Fly9352"> /u/Apprehensive_Fly9352 </a> <br/> <span><a href="https://www.vulture.com/article/depeche-mode-new-music-dave-gahan.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6lzps/dave_gahan_is_unsure_of_depeche_modes_future_i/">[comments]</a></span>

## We’re the divorced dad and mom rock band, Breaking Benjamin AMA
 - [https://www.reddit.com/r/Music/comments/1h6loa0/were_the_divorced_dad_and_mom_rock_band_breaking](https://www.reddit.com/r/Music/comments/1h6loa0/were_the_divorced_dad_and_mom_rock_band_breaking)
 - RSS feed: $source
 - date published: 2024-12-04T17:26:09+00:00

<!-- SC_OFF --><div class="md"><p><em>Hey, Reddit! We’re Keith Wallen (guitarist/vocalist) and Jasen Rauch (lead guitarist) of Breaking Benjamin, and we’re excited to chat with you today! Whether you’ve been with us since Saturate or just discovered our music, we’re here to answer your questions.</em></p> <p><em>Breaking Benjamin was on an incredible tour over the pas 45 days, playing our biggest shows EVER, we’re stoked about what’s coming in 2025. We recently dropped our new single, &quot;Awaken,&quot; and y’alls support of it has been incredible. Awaken is our first single in over 5 years, so it really means the world to us to see y’all championing it.</em></p> <p><em>We’d love to talk about the new single, life on the road, what’s coming next for Breaking Benjamin, or anything else you’ve been curious about!</em> </p> <p><em>🫶 Keith &amp; Jasen</em></p> <p><a href="https://preview.redd.it/jzs6yr8a9v4e1.png?width=628&amp;format=png&amp;auto=webp&amp;s=d5fa4af081fee4d70de787ac7d5c7

## Judas Priest - The Hellion/Electric Eye [Heavy Metal]
 - [https://www.reddit.com/r/Music/comments/1h6l4ii/judas_priest_the_hellionelectric_eye_heavy_metal](https://www.reddit.com/r/Music/comments/1h6l4ii/judas_priest_the_hellionelectric_eye_heavy_metal)
 - RSS feed: $source
 - date published: 2024-12-04T17:04:29+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=eGtwgYt_QnA">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6l4ii/judas_priest_the_hellionelectric_eye_heavy_metal/">[comments]</a></span>

## Pearl Jam - Jeremy [rock]
 - [https://www.reddit.com/r/Music/comments/1h6l3gw/pearl_jam_jeremy_rock](https://www.reddit.com/r/Music/comments/1h6l3gw/pearl_jam_jeremy_rock)
 - RSS feed: $source
 - date published: 2024-12-04T17:03:20+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/lacinated"> /u/lacinated </a> <br/> <span><a href="https://m.youtube.com/watch?v=MS91knuzoOA&amp;pp=ygUQamVyZW15IHBlYXJsIGphbQ%3D%3D&amp;rco=1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6l3gw/pearl_jam_jeremy_rock/">[comments]</a></span>

## A Perfect Circle - Pet [Alternative Metal]
 - [https://www.reddit.com/r/Music/comments/1h6l2wt/a_perfect_circle_pet_alternative_metal](https://www.reddit.com/r/Music/comments/1h6l2wt/a_perfect_circle_pet_alternative_metal)
 - RSS feed: $source
 - date published: 2024-12-04T17:02:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=TmWhY_irAXE">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6l2wt/a_perfect_circle_pet_alternative_metal/">[comments]</a></span>

## Pixies - Hey [Alternative Rock]
 - [https://www.reddit.com/r/Music/comments/1h6l24t/pixies_hey_alternative_rock](https://www.reddit.com/r/Music/comments/1h6l24t/pixies_hey_alternative_rock)
 - RSS feed: $source
 - date published: 2024-12-04T17:01:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=tVCUAXOBF7w">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6l24t/pixies_hey_alternative_rock/">[comments]</a></span>

## Depeche Mode's Dave Gahan on losing Mark Lanegan: "I had this sense that he was still around for a while"
 - [https://www.reddit.com/r/Music/comments/1h6jp93/depeche_modes_dave_gahan_on_losing_mark_lanegan_i](https://www.reddit.com/r/Music/comments/1h6jp93/depeche_modes_dave_gahan_on_losing_mark_lanegan_i)
 - RSS feed: $source
 - date published: 2024-12-04T16:07:57+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/BetterCallSaul1995"> /u/BetterCallSaul1995 </a> <br/> <span><a href="https://www.nme.com/news/music/depeche-mode-dave-gahan-interview-mark-lanegan-london-tribute-gig-3818305">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6jp93/depeche_modes_dave_gahan_on_losing_mark_lanegan_i/">[comments]</a></span>

## Spotify Wrapped dropped today. I've made a little website called Spotify Unwrapped to allow people to see how much money Spotify pays to artists on your behalf.
 - [https://www.reddit.com/r/Music/comments/1h6ifqp/spotify_wrapped_dropped_today_ive_made_a_little](https://www.reddit.com/r/Music/comments/1h6ifqp/spotify_wrapped_dropped_today_ive_made_a_little)
 - RSS feed: $source
 - date published: 2024-12-04T15:16:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/spacecadet06"> /u/spacecadet06 </a> <br/> <span><a href="https://www.spotify-unwrapped.com/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6ifqp/spotify_wrapped_dropped_today_ive_made_a_little/">[comments]</a></span>

## Kim Wilde - You came [Pop] (1988)
 - [https://www.reddit.com/r/Music/comments/1h6hmty/kim_wilde_you_came_pop_1988](https://www.reddit.com/r/Music/comments/1h6hmty/kim_wilde_you_came_pop_1988)
 - RSS feed: $source
 - date published: 2024-12-04T14:43:00+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/mamut2000"> /u/mamut2000 </a> <br/> <span><a href="https://www.youtube.com/watch?v=P6Agwu_5J14">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6hmty/kim_wilde_you_came_pop_1988/">[comments]</a></span>

## Zayn Malik Cancels Newcastle Gig Minutes Before Stage Time
 - [https://www.reddit.com/r/Music/comments/1h6hdtu/zayn_malik_cancels_newcastle_gig_minutes_before](https://www.reddit.com/r/Music/comments/1h6hdtu/zayn_malik_cancels_newcastle_gig_minutes_before)
 - RSS feed: $source
 - date published: 2024-12-04T14:31:59+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/mcfw31"> /u/mcfw31 </a> <br/> <span><a href="https://www.billboard.com/music/music-news/zayn-malik-cancels-newcastle-gig-last-minute-1235844284/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6hdtu/zayn_malik_cancels_newcastle_gig_minutes_before/">[comments]</a></span>

## Sean Ono Lennon on Yoko's life after John: "She never has moved on from that relationship"
 - [https://www.reddit.com/r/Music/comments/1h6h1sf/sean_ono_lennon_on_yokos_life_after_john_she](https://www.reddit.com/r/Music/comments/1h6h1sf/sean_ono_lennon_on_yokos_life_after_john_she)
 - RSS feed: $source
 - date published: 2024-12-04T14:17:20+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/ebradio"> /u/ebradio </a> <br/> <span><a href="https://www.nme.com/news/music/sean-ono-lennon-on-yokos-life-after-john-she-never-has-moved-on-from-that-relationship-3818096">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6h1sf/sean_ono_lennon_on_yokos_life_after_john_she/">[comments]</a></span>

## CAKE - Short Skirt / Long Jacket [Rock]
 - [https://www.reddit.com/r/Music/comments/1h6gryc/cake_short_skirt_long_jacket_rock](https://www.reddit.com/r/Music/comments/1h6gryc/cake_short_skirt_long_jacket_rock)
 - RSS feed: $source
 - date published: 2024-12-04T14:05:16+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Public-Strawberry304"> /u/Public-Strawberry304 </a> <br/> <span><a href="https://youtu.be/X5KmB8Laemg?si=-jvoPqSmrPSLXEVQ">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6gryc/cake_short_skirt_long_jacket_rock/">[comments]</a></span>

## CAKE - Frank Sinatra [rock]
 - [https://www.reddit.com/r/Music/comments/1h6gnh2/cake_frank_sinatra_rock](https://www.reddit.com/r/Music/comments/1h6gnh2/cake_frank_sinatra_rock)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:12+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Public-Strawberry304"> /u/Public-Strawberry304 </a> <br/> <span><a href="https://youtu.be/7xw49Y-bYYk?si=Z-LItcj4OLwBYC8D">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6gnh2/cake_frank_sinatra_rock/">[comments]</a></span>

## Tom Waits - Swordfishtrombone [Singer-Songwriter / Experimental Rock]
 - [https://www.reddit.com/r/Music/comments/1h6g6v9/tom_waits_swordfishtrombone_singersongwriter](https://www.reddit.com/r/Music/comments/1h6g6v9/tom_waits_swordfishtrombone_singersongwriter)
 - RSS feed: $source
 - date published: 2024-12-04T13:38:11+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=KiGN9RFko1o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6g6v9/tom_waits_swordfishtrombone_singersongwriter/">[comments]</a></span>

## Gorillaz - Clint Eastwood [alternative]
 - [https://www.reddit.com/r/Music/comments/1h6g4r3/gorillaz_clint_eastwood_alternative](https://www.reddit.com/r/Music/comments/1h6g4r3/gorillaz_clint_eastwood_alternative)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:23+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Public-Strawberry304"> /u/Public-Strawberry304 </a> <br/> <span><a href="https://youtu.be/1V_xRb0x9aw?si=myH8-OaDTetfdCiK">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6g4r3/gorillaz_clint_eastwood_alternative/">[comments]</a></span>

## Santana - Oye Como Va [rock]
 - [https://www.reddit.com/r/Music/comments/1h6g0sh/santana_oye_como_va_rock](https://www.reddit.com/r/Music/comments/1h6g0sh/santana_oye_como_va_rock)
 - RSS feed: $source
 - date published: 2024-12-04T13:30:19+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Public-Strawberry304"> /u/Public-Strawberry304 </a> <br/> <span><a href="https://youtu.be/J7ATTjg7tpE?si=85UNkCKhDWnOlB5r">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6g0sh/santana_oye_como_va_rock/">[comments]</a></span>

## Melvins - Allergic to Food [Sludge Metal / Experimental Rock]
 - [https://www.reddit.com/r/Music/comments/1h6fjbm/melvins_allergic_to_food_sludge_metal](https://www.reddit.com/r/Music/comments/1h6fjbm/melvins_allergic_to_food_sludge_metal)
 - RSS feed: $source
 - date published: 2024-12-04T13:06:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=Fsd8gDGSSKU">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6fjbm/melvins_allergic_to_food_sludge_metal/">[comments]</a></span>

## Fantômas - Rosemary's Baby (composed by Krzysztof Komeda) [Avant-garde Metal / Soundtrack]
 - [https://www.reddit.com/r/Music/comments/1h6f6mf/fantômas_rosemarys_baby_composed_by_krzysztof](https://www.reddit.com/r/Music/comments/1h6f6mf/fantômas_rosemarys_baby_composed_by_krzysztof)
 - RSS feed: $source
 - date published: 2024-12-04T12:48:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=-qqUwtTUEYE">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6f6mf/fantômas_rosemarys_baby_composed_by_krzysztof/">[comments]</a></span>

## System of a Down - $uggestions [Alternative Metal]
 - [https://www.reddit.com/r/Music/comments/1h6eugd/system_of_a_down_uggestions_alternative_metal](https://www.reddit.com/r/Music/comments/1h6eugd/system_of_a_down_uggestions_alternative_metal)
 - RSS feed: $source
 - date published: 2024-12-04T12:29:39+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sea-of-unorthodoxy"> /u/sea-of-unorthodoxy </a> <br/> <span><a href="https://www.youtube.com/watch?v=kjLPPjjMCog">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6eugd/system_of_a_down_uggestions_alternative_metal/">[comments]</a></span>

## Catching Flies, The West Green Quartet - Ojai [Electronic]
 - [https://www.reddit.com/r/Music/comments/1h6eta0/catching_flies_the_west_green_quartet_ojai](https://www.reddit.com/r/Music/comments/1h6eta0/catching_flies_the_west_green_quartet_ojai)
 - RSS feed: $source
 - date published: 2024-12-04T12:27:47+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/mediazikos"> /u/mediazikos </a> <br/> <span><a href="https://youtube.com/watch?v=j2zWzdfgYbM">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6eta0/catching_flies_the_west_green_quartet_ojai/">[comments]</a></span>

## Rise Against - Sudden Urge [punk rock]
 - [https://www.reddit.com/r/Music/comments/1h6er0v/rise_against_sudden_urge_punk_rock](https://www.reddit.com/r/Music/comments/1h6er0v/rise_against_sudden_urge_punk_rock)
 - RSS feed: $source
 - date published: 2024-12-04T12:24:04+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Roksyk"> /u/Roksyk </a> <br/> <span><a href="https://www.youtube.com/watch?v=EVlYtN5q8d8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6er0v/rise_against_sudden_urge_punk_rock/">[comments]</a></span>

## Devin Townsend - Aftermath (Devolution Series #2 - Galactic Quarantine) [Metal]
 - [https://www.reddit.com/r/Music/comments/1h6e72e/devin_townsend_aftermath_devolution_series_2](https://www.reddit.com/r/Music/comments/1h6e72e/devin_townsend_aftermath_devolution_series_2)
 - RSS feed: $source
 - date published: 2024-12-04T11:50:02+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/MDFHASDIED"> /u/MDFHASDIED </a> <br/> <span><a href="https://youtu.be/4rOhiHLPT9Q">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6e72e/devin_townsend_aftermath_devolution_series_2/">[comments]</a></span>

## British band Sports Team robbed at gunpoint on the first day of their American tour
 - [https://www.reddit.com/r/Music/comments/1h6dcvu/british_band_sports_team_robbed_at_gunpoint_on](https://www.reddit.com/r/Music/comments/1h6dcvu/british_band_sports_team_robbed_at_gunpoint_on)
 - RSS feed: $source
 - date published: 2024-12-04T10:54:01+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TheMirrorUS"> /u/TheMirrorUS </a> <br/> <span><a href="https://www.themirror.com/entertainment/breaking-rock-band-robbed-gunpoint-840457">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6dcvu/british_band_sports_team_robbed_at_gunpoint_on/">[comments]</a></span>

## My Top 10 Dark Ambient releases of 2024 (with some hidden gems)
 - [https://www.reddit.com/r/Music/comments/1h6b14k/my_top_10_dark_ambient_releases_of_2024_with_some](https://www.reddit.com/r/Music/comments/1h6b14k/my_top_10_dark_ambient_releases_of_2024_with_some)
 - RSS feed: $source
 - date published: 2024-12-04T07:59:33+00:00

<!-- SC_OFF --><div class="md"><p><strong>10 ) Richie Culver - Hostile Environments</strong></p> <p>I’m a big sucker for spoken word mixed with ambient, so I really enjoyed this one.</p> <p><a href="https://www.youtube.com/watch?v=IZAdA-Tawhc">https://www.youtube.com/watch?v=IZAdA-Tawhc</a></p> <p><strong>9) Capricorni Pneumatici - Witchcraft (1989)</strong></p> <p>It’s an old release that just got reissued, but I never heard of this project. Esoteric and eerie, reminds of Aghast at times.</p> <p><a href="https://www.youtube.com/watch?v=DYSZd2mta5E">https://www.youtube.com/watch?v=DYSZd2mta5E</a></p> <p><strong>8) Apocryphos - Atrementia</strong></p> <p>One of my favorite artist from the Cryo Chamber roster, and his new album has a great old-school production.</p> <p><a href="https://www.youtube.com/watch?v=gWnIotfWoBA">https://www.youtube.com/watch?v=gWnIotfWoBA</a></p> <p><strong>7) Darkspace - -II</strong></p> <p>If you dig spacey and a bit industrial-ish sound, you are in for a t

## The Avalanches - The Divine Chord (feat. MGMT & Johnny Marr) [Alternative/Electronic]
 - [https://www.reddit.com/r/Music/comments/1h6aqct/the_avalanches_the_divine_chord_feat_mgmt_johnny](https://www.reddit.com/r/Music/comments/1h6aqct/the_avalanches_the_divine_chord_feat_mgmt_johnny)
 - RSS feed: $source
 - date published: 2024-12-04T07:36:58+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/udderlymoovelous"> /u/udderlymoovelous </a> <br/> <span><a href="https://youtu.be/TvZpn322LxE?si=SGpdM6Oh-Y7TkRoA">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6aqct/the_avalanches_the_divine_chord_feat_mgmt_johnny/">[comments]</a></span>

## Pete & Bas - Stepped Into the Building [Rap]
 - [https://www.reddit.com/r/Music/comments/1h6a710/pete_bas_stepped_into_the_building_rap](https://www.reddit.com/r/Music/comments/1h6a710/pete_bas_stepped_into_the_building_rap)
 - RSS feed: $source
 - date published: 2024-12-04T06:58:48+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TOVILIAN"> /u/TOVILIAN </a> <br/> <span><a href="https://youtube.com/watch?v=GBuTTz1-IQU&amp;si=e1U-FAdu9-yFa3bR">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h6a710/pete_bas_stepped_into_the_building_rap/">[comments]</a></span>

## Rufus Wainwright - You Ain't Big [Rock]
 - [https://www.reddit.com/r/Music/comments/1h685mm/rufus_wainwright_you_aint_big_rock](https://www.reddit.com/r/Music/comments/1h685mm/rufus_wainwright_you_aint_big_rock)
 - RSS feed: $source
 - date published: 2024-12-04T04:53:40+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/CJ_Productions"> /u/CJ_Productions </a> <br/> <span><a href="https://www.youtube.com/watch?v=FP0jz5RD0vc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h685mm/rufus_wainwright_you_aint_big_rock/">[comments]</a></span>

## Eddie Rabbitt - Drivin' My Life Away [country rock] (1980)
 - [https://www.reddit.com/r/Music/comments/1h67aqp/eddie_rabbitt_drivin_my_life_away_country_rock](https://www.reddit.com/r/Music/comments/1h67aqp/eddie_rabbitt_drivin_my_life_away_country_rock)
 - RSS feed: $source
 - date published: 2024-12-04T04:05:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/ThrashMetallix"> /u/ThrashMetallix </a> <br/> <span><a href="https://youtu.be/s6JJ1qoS_0w?si=2tyY8FOVCnHDmIHK">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h67aqp/eddie_rabbitt_drivin_my_life_away_country_rock/">[comments]</a></span>

## My Chemical Romance’s Frank Iero pays tribute to late ex-drummer Bob Bryar: “I don’t think I ever got to tell him I was sorry”
 - [https://www.reddit.com/r/Music/comments/1h66xoo/my_chemical_romances_frank_iero_pays_tribute_to](https://www.reddit.com/r/Music/comments/1h66xoo/my_chemical_romances_frank_iero_pays_tribute_to)
 - RSS feed: $source
 - date published: 2024-12-04T03:45:49+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/cmaia1503"> /u/cmaia1503 </a> <br/> <span><a href="https://www.nme.com/news/music/my-chemical-romances-frank-iero-pays-tribute-to-late-ex-drummer-bob-bryar-i-dont-think-i-ever-got-to-tell-him-i-was-sorry-3818536">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h66xoo/my_chemical_romances_frank_iero_pays_tribute_to/">[comments]</a></span>

## Death From Above 1979 - Pull Out [Alternative Rock]
 - [https://www.reddit.com/r/Music/comments/1h66fyy/death_from_above_1979_pull_out_alternative_rock](https://www.reddit.com/r/Music/comments/1h66fyy/death_from_above_1979_pull_out_alternative_rock)
 - RSS feed: $source
 - date published: 2024-12-04T03:20:28+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/ceeman77"> /u/ceeman77 </a> <br/> <span><a href="https://www.youtube.com/watch?v=1qaBTqhlv8o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h66fyy/death_from_above_1979_pull_out_alternative_rock/">[comments]</a></span>

## John Denver gives me such a warm fuzzy feeling!
 - [https://www.reddit.com/r/Music/comments/1h66abb/john_denver_gives_me_such_a_warm_fuzzy_feeling](https://www.reddit.com/r/Music/comments/1h66abb/john_denver_gives_me_such_a_warm_fuzzy_feeling)
 - RSS feed: $source
 - date published: 2024-12-04T03:12:38+00:00

<!-- SC_OFF --><div class="md"><p>I was just a tiny toddler when first introduced. My grandma and grandpa would put their JD vinyls on after Sunday dinner and dance lovingly in the front room. The family always joined in after they had their first dance. When I became a bit older, my grandpa sat me down and explained why JD was so important. His music reminded us of our roots, family, great loves of our lives, and just pure emotion. Sometimes that emotion was happy, sometimes sad, sometimes silly, but always truthful. My grandpa passed when I was a pretty young, and my grandma when I was a young adult, but I often listen to JD and always feel close to them when I do. I was their only biological granddaughter. They always told me I was their petunia in the onion patch. I&#39;m middle aged now, and live very far from my hometown but, when I listen to JD, it makes me yearn for the simplicity of the easy love that came when I was with my grandpa and grandma. What music makes you feel hap

## Barry Manilow Announces He'll Perform at Westgate Las Vegas for the 'Rest of My Career' with Lifetime Residency
 - [https://www.reddit.com/r/Music/comments/1h63cid/barry_manilow_announces_hell_perform_at_westgate](https://www.reddit.com/r/Music/comments/1h63cid/barry_manilow_announces_hell_perform_at_westgate)
 - RSS feed: $source
 - date published: 2024-12-04T00:48:34+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/cmaia1503"> /u/cmaia1503 </a> <br/> <span><a href="https://people.com/barry-manilow-announces-lifetime-residency-westgate-las-vegas-8754873">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Music/comments/1h63cid/barry_manilow_announces_hell_perform_at_westgate/">[comments]</a></span>

