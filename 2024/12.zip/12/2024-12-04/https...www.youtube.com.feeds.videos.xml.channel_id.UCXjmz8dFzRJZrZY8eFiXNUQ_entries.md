# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## The Worst Episodes of ALL Your Favorite Shows | Compilation
 - [https://www.youtube.com/watch?v=0XvfGcVLFMA](https://www.youtube.com/watch?v=0XvfGcVLFMA)
 - RSS feed: $source
 - date published: 2024-12-04T18:00:01+00:00

Sometimes, even your favorite TV Shows have a terrible episode.  Whether it be modern sitcom classics like The Office, Brooklyn Nine Nine, Parks and Recreation or a timeless classic like The Simpsons or Family Guy, everyone produces a bad episode.  We take a look at some of the Worst Episodes of your favorite TV Shows. 

#theoffice #parksandrecreation #thesimpsons #nerdstalgic 


00:00 - Brooklyn Nine Nine
8:38 - The Office
18:25 - The Simpsons
26:44 - Saturday Night Live
34:49 - Modern Family
42:51 - How I Met Your Mother
51:11 - Parks and Recreation
59:32 - The Big Bang Theory
01:07:58 - Family Guy
01:16:22 - It's Always Sunny In Philadelphia

