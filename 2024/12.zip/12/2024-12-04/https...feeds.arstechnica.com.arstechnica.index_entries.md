# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Dog domestication happened many times, but most didn’t pan out
 - [https://arstechnica.com/science/2024/12/dog-domestication-happened-many-times-but-most-didnt-pan-out](https://arstechnica.com/science/2024/12/dog-domestication-happened-many-times-but-most-didnt-pan-out)
 - RSS feed: $source
 - date published: 2024-12-04T22:16:36+00:00


            Our relationship with wolves, dogs, and even coyotes has always been complicated.
          

## OpenAI teases 12 days of mystery product launches starting tomorrow
 - [https://arstechnica.com/ai/2024/12/openai-teases-12-days-of-mystery-product-launches-starting-tomorrow](https://arstechnica.com/ai/2024/12/openai-teases-12-days-of-mystery-product-launches-starting-tomorrow)
 - RSS feed: $source
 - date published: 2024-12-04T20:15:32+00:00


            OpenAI's "12 days of shipmas" will reveal new AI releases and demos for two weeks.
          

## US recommends encrypted messaging as Chinese hackers linger in telecom networks
 - [https://arstechnica.com/tech-policy/2024/12/us-recommends-encrypted-messaging-as-chinese-hackers-linger-in-telecom-networks](https://arstechnica.com/tech-policy/2024/12/us-recommends-encrypted-messaging-as-chinese-hackers-linger-in-telecom-networks)
 - RSS feed: $source
 - date published: 2024-12-04T18:47:28+00:00


            US official: "Impossible for us to predict when we'll have full eviction."
          

## Trump nominates Jared Isaacman to become the next NASA administrator
 - [https://arstechnica.com/space/2024/12/jared-isaacman-entrepreneur-and-private-astronaut-is-trumps-choice-to-lead-nasa](https://arstechnica.com/space/2024/12/jared-isaacman-entrepreneur-and-private-astronaut-is-trumps-choice-to-lead-nasa)
 - RSS feed: $source
 - date published: 2024-12-04T18:41:43+00:00


            "We will never again lose our ability to journey to the stars and never settle for second place."
          

## Amazon secretly slowed deliveries, deceived anyone who complained, lawsuit says
 - [https://arstechnica.com/tech-policy/2024/12/amazon-secretly-slowed-deliveries-deceived-anyone-who-complained-lawsuit-says](https://arstechnica.com/tech-policy/2024/12/amazon-secretly-slowed-deliveries-deceived-anyone-who-complained-lawsuit-says)
 - RSS feed: $source
 - date published: 2024-12-04T17:37:52+00:00


            Amazon called delays a "coincidence" while overcharging by millions, AG alleged.
          

## No more EV app folders: Universal plug-and-charge is due to launch in 2025
 - [https://arstechnica.com/cars/2024/12/universal-plug-and-charge-for-most-evs-is-moving-ahead-for-2025](https://arstechnica.com/cars/2024/12/universal-plug-and-charge-for-most-evs-is-moving-ahead-for-2025)
 - RSS feed: $source
 - date published: 2024-12-04T17:18:41+00:00


            Most of the major EV makers and charging networks are on board.
          

## Google’s DeepMind tackles weather forecasting, with great performance
 - [https://arstechnica.com/science/2024/12/googles-deepmind-tackles-weather-forecasting-with-great-performance](https://arstechnica.com/science/2024/12/googles-deepmind-tackles-weather-forecasting-with-great-performance)
 - RSS feed: $source
 - date published: 2024-12-04T17:06:17+00:00


            Needs just eight minutes on one processor to do a single 15-day forecast.
          

## Microsoft reiterates “non-negotiable” TPM 2.0 requirement for Windows 11
 - [https://arstechnica.com/gadgets/2024/12/microsoft-reiterates-non-negotiable-tpm-2-0-requirement-for-windows-11](https://arstechnica.com/gadgets/2024/12/microsoft-reiterates-non-negotiable-tpm-2-0-requirement-for-windows-11)
 - RSS feed: $source
 - date published: 2024-12-04T16:49:07+00:00


            Microsoft won't lower Windows 11's requirements to save older Windows 10 PCs.
          

## Seagrass is fantastic at carbon capture—and it’s at risk of extinction
 - [https://arstechnica.com/science/2024/12/seagrass-is-fantastic-at-carbon-capture-and-its-at-risk-of-extinction](https://arstechnica.com/science/2024/12/seagrass-is-fantastic-at-carbon-capture-and-its-at-risk-of-extinction)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:39+00:00


            An underwater gardening experiment along the East Coast aims at restoration.
          

## ESA workers face a maze of non-compete clauses and service contracts
 - [https://arstechnica.com/space/2024/12/esa-workers-face-a-maze-of-non-compete-clauses-and-service-contracts](https://arstechnica.com/space/2024/12/esa-workers-face-a-maze-of-non-compete-clauses-and-service-contracts)
 - RSS feed: $source
 - date published: 2024-12-04T14:46:57+00:00


            Contracts limit mobility and career advancement, and ESA policy limits local laws.
          

## HowStuffWorks founder Marshall Brain sent final email before sudden death
 - [https://arstechnica.com/ai/2024/12/web-pioneer-marshall-brain-dies-suddenly-at-63-amid-ethics-battle](https://arstechnica.com/ai/2024/12/web-pioneer-marshall-brain-dies-suddenly-at-63-amid-ethics-battle)
 - RSS feed: $source
 - date published: 2024-12-04T13:54:15+00:00


            Popular tech educator died in his office within hours of claiming retaliation for filing NCSU ethics reports.
          

