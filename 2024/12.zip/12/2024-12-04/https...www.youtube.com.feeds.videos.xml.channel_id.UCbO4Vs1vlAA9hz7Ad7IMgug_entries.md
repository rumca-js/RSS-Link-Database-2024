# Source:Guerrilla Miniature Games, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug, language:en

## Age of Sigmar: SPEARTIPZ- A Faction Guide for the Skyhammer Task Force
 - [https://www.youtube.com/watch?v=GCEiyKaDKt4](https://www.youtube.com/watch?v=GCEiyKaDKt4)
 - RSS feed: $source
 - date published: 2024-12-04T17:30:05+00:00

WELCOME TO SPEARTIPZ! This companion series fo SPEARHEADZ has the gang playing through Warhammer: Age of Sigmar's Spearhead format break down all the factions with tips and tricks and what to look for. 

Today's first episode has MIKE from Epic Duck Studios and I breaking down his first painted Spearhead; the Kharadron Overlords Skyhammer Task Force!

Check out all his cool STLs in the shop at https://DuckDrop.link

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/guerrilla-miniature-games/

GMG T-Shirts and Hoodie

## Age of Sigmar: SPEARHEADZ - Skaven  vs. Kharadron Overlords
 - [https://www.youtube.com/watch?v=oxhawppyLNM](https://www.youtube.com/watch?v=oxhawppyLNM)
 - RSS feed: $source
 - date published: 2024-12-04T17:01:02+00:00

WELCOME TO SPEARHEADZ! This casual gaming series is going to explore Warhammer's new format of fixed-list casual gaming. This wide-onramp new system for playing Games Workshop's cosmic-fantasy wargame is perfect for the kitchen-table game crowd and is perfectly suited for where I'm at with gaming. 

Today the third SPEARHEAD to finish his boxed set is Mike from Epic Duck Studios! He's throwing down against my Skaven with his freshly painted Kharadron Overlords! He's also brought in the very cool SpearHeadz Terrain kits so we can use our old game boards to play this new Age of Sigmar Battlepack!  Check them out HERE: https://www.myminifactory.com/object/3d-print-spearheadz-terrain-designed-for-aos-spearhead-393936

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at Guerrilla

## Age of Sigmar: SPEARTIPZ- A Faction Guide for Gnawfeast Clawpack
 - [https://www.youtube.com/watch?v=n0PxKCTfKYI](https://www.youtube.com/watch?v=n0PxKCTfKYI)
 - RSS feed: $source
 - date published: 2024-12-04T17:00:53+00:00

WELCOME TO SPEARTIPZ! This companion series fo SPEARHEADZ has the gang playing through Warhammer: Age of Sigmar's Spearhead format break down all the factions with tips and tricks and what to look for. 

Today's first episode has MIKE from Epic Duck Studios and I breaking down one half of the Ultimate Starter Set Spearheads - the Skaven Gnawfeast Clawpack!

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/guerrilla-miniature-games/

GMG T-Shirts and Hoodies HERE: https://shop.spreadshirt.ca/guerrillaminiaturegames/

