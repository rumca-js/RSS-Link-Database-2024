# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## Review: We read all 922 pages of Project 2025 so that you didn't have to
 - [https://www.louderwithcrowder.com/what-is-project-2025](https://www.louderwithcrowder.com/what-is-project-2025)
 - RSS feed: $source
 - date published: 2024-12-04T21:21:13+00:00


<img src="https://www.louderwithcrowder.com/media-library/image.png?id=55142417&width=1200&height=800&coordinates=100%2C0%2C100%2C0"/><br/><br/><p>Well, I did it.
</p><p>
	I read all 922 pages of Project 2025 so you don’t have to. Thank God Trump was elected, or some people might have called it a waste of time…
</p><p>
	Like most conservative policy manuals, it’s all meat and no fat. If you really want to dive into conservative policy solutions to government-caused problems, go for it. <a href="https://static.project2025.org/2025_MandateForLeadership_FULL.pdf" rel="noopener noreferrer" target="_blank"><u>The PDF is free to anyone who wants to download it</u></a>.
</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" data-rm-shortcode-id="bfc8c4821b9747fc8cda49e2ea517bda" data-rm-shortcode-name="rebelmouse-image" id="decfa" loading="lazy" src="https://www.louderwithcrowder.com/media-library/image.png?id=55142257&width=980"/>
</p><p>
	But, h

## Ketanji Brown Jackson: Banning interracial marriage totally the same as banning child genital mutilation
 - [https://www.louderwithcrowder.com/ketanji-interracial-marriage](https://www.louderwithcrowder.com/ketanji-interracial-marriage)
 - RSS feed: $source
 - date published: 2024-12-04T21:19:02+00:00


<img src="https://www.louderwithcrowder.com/media-library/image.png?id=55142488&width=1200&height=800&coordinates=94%2C0%2C94%2C0"/><br/><br/><p>There is no bigger embarrassment to the Supreme Court of the United States than Ketanji Brown Jackson, as she just compared banning sex changes for kids to bans on interracial marriage. </p><p><br/></p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Ketanji Brown Jackson just compared bans on sex changes for kids to bans on interracial marriage. <a href="https://t.co/XOOZRLOI2N">pic.twitter.com/XOOZRLOI2N</a><br/>— Greg Price (@greg_price11) <a href="https://twitter.com/greg_price11/status/1864343733958754513?ref_src=twsrc%5Etfw">December 4, 2024</a></blockquote> <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script></div><p><br/></p>
<p>It’s astonishing the lengths these people will go to defend this deranged ideology, especially at the expense of logic. </p>
<p>How does that even make 

## Watch: Biden Falls Asleep (Again, This Time in the Middle of an African Summit
 - [https://www.louderwithcrowder.com/biden-african-summit](https://www.louderwithcrowder.com/biden-african-summit)
 - RSS feed: $source
 - date published: 2024-12-04T19:33:21+00:00


<img src="https://www.louderwithcrowder.com/media-library/image.png?id=55141662&width=1200&height=800&coordinates=59%2C0%2C59%2C0"/><br/><br/><p>They don’t call him Sleepy Joe because he is awake, as he may have been the first POTUS to fall asleep in front of world leaders on several occasions. </p>
<p>Biden fell asleep in the middle of a summit with African officials and he could not be more of a national embarrassment if he tried. </p><p><br/></p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Biden just fell asleep smack in the middle of a summit with African leaders <a href="https://t.co/fs692GkE1A">pic.twitter.com/fs692GkE1A</a><br/>— End Wokeness (@EndWokeness) <a href="https://twitter.com/EndWokeness/status/1864322690326106287?ref_src=twsrc%5Etfw">December 4, 2024</a></blockquote> <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script></div><p>He does not even try to hide it. </p>
<p>I think most people are relieved that we

## Watch: ACLU lawyer swears your two-year-old is old enough to change their gender if they feel like it
 - [https://www.louderwithcrowder.com/aclu-trans-lawyer](https://www.louderwithcrowder.com/aclu-trans-lawyer)
 - RSS feed: $source
 - date published: 2024-12-04T18:46:33+00:00


<img src="https://www.louderwithcrowder.com/media-library/image.png?id=55141439&width=1200&height=800&coordinates=33%2C0%2C33%2C0"/><br/><br/><p>A man, who is actually a woman, is representing the ACLU in its efforts to fight for child castration, as that is what it means to fully medically transition a two-year-old. And the worst part is that although the lawyer admitted two-year-olds are not capable of consenting to sex changes, their parents are. Thus, he/she/they believes children as young as two, should be able to medically transition.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">ACLU lawyer Chase Strangio: 2-year-olds know if they're trans, so castrating them young must be allowed <a href="https://t.co/NYEv7pQzdd">pic.twitter.com/NYEv7pQzdd</a><br/>— End Wokeness (@EndWokeness) <a href="https://twitter.com/EndWokeness/status/1864105115025625321?ref_src=twsrc%5Etfw">December 4, 2024</a></blockquote> <script async="" charset="utf-8" src="https://platfor

## Watch: Celebrity Exodus! Where Are They Heading Post-Trump Victory
 - [https://www.louderwithcrowder.com/leftist-hollywood-celebrities](https://www.louderwithcrowder.com/leftist-hollywood-celebrities)
 - RSS feed: $source
 - date published: 2024-12-04T17:16:18+00:00


<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=55138795&width=1200&height=800&coordinates=100%2C0%2C100%2C0"/><br/><br/><p>In the past year, Hollywood celebrities have threatened to move if Trump wins and some have actually fled the United States after his victory. Today’s show breaks down why the countries they moved to are not free like America.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" data-rm-shortcode-id="b1b0b425210d2bcdaf1f19818cdf5d10" style="display:block;position:relative;padding-top:56.25%;"><iframe frameborder="0" height="auto" lazy-loadable="true" scrolling="no" src="https://www.youtube.com/embed/NRYkctbvo0A?rel=0" style="position:absolute;top:0;left:0;width:100%;height:100%;" width="100%"></iframe></span>
<small class="image-media media-caption" placeholder="Add Photo Caption...">- YouTube</small>
<small class="image-media media-photo-credit" placeholder="Add Photo Credit...">
<a href="https://www.youtube.

## Watch: Joy Reid has major freakout over hilarious Trump joke about Canada
 - [https://www.louderwithcrowder.com/joy-reid-trump-canada](https://www.louderwithcrowder.com/joy-reid-trump-canada)
 - RSS feed: $source
 - date published: 2024-12-04T13:42:57+00:00


<img src="https://www.louderwithcrowder.com/media-library/image.png?id=55136805&width=1200&height=800&coordinates=100%2C0%2C100%2C0"/><br/><br/><p>If cable news journalismers don't pace themselves, one of them is gonna have an aneurysm live on air before Trump gets sworn in next month. Even after their party got their heinies whooped, the media STILL goes to Defcon 5 over every little thing Trump says. Trump being Trump, this encourages him to say more of those things. Exhibit Q of this involves <a href="https://www.louderwithcrowder.com/joy-reid-msnbc-family-holidays" target="_blank">Racist Joy Reid</a> and Canada.</p><p>Trump threatened to impose massive tariffs on Canada if nothing is done about border issues and the trade deficit. The threat was enough for Prime Minister Justin "I Feel Pretty' Trudeau, Canada's walking pile of soy and hair goop, to travel to Mar-a-Lago for an audience with Trump. The unpopular Trudeau is facing his own electoral threat from the far <a href="http

## Sources: Why South Korea's Martial Law Really Matters to America
 - [https://www.louderwithcrowder.com/sources-december-4-2024](https://www.louderwithcrowder.com/sources-december-4-2024)
 - RSS feed: $source
 - date published: 2024-12-04T12:18:02+00:00


<img src="https://www.louderwithcrowder.com/media-library/image.png?id=55136648&width=1200&height=800&coordinates=132%2C0%2C132%2C0"/><br/><br/><p>South Korean chaos erupted as President Yoon Seok-yeol declared a state of martial law for the country yesterday, meanwhile leftist Hollywood celebrities are fleeing the United States after Donald Trump’s Presidential victory, juror deliberation began yesterday in the manslaughter and criminal negligence trial of Daniel Penny in New York regarding the death of Jordan Neely on a subway train, new developments in Chinese automation technology has taken sperm sample acquisition to the next level, we’re launching our Christmas 2024 Ugly Sweater Contest and much more! </p><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p

