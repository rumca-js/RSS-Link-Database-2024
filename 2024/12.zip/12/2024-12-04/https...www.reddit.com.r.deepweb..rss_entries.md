# Source:Deep Web, URL:https://www.reddit.com/r/deepweb/.rss, language:en

## Need to talk to someone on what’s on the web
 - [https://www.reddit.com/r/deepweb/comments/1h6ot3u/need_to_talk_to_someone_on_whats_on_the_web](https://www.reddit.com/r/deepweb/comments/1h6ot3u/need_to_talk_to_someone_on_whats_on_the_web)
 - RSS feed: $source
 - date published: 2024-12-04T19:29:39+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/saifastic"> /u/saifastic </a> <br/> <span><a href="https://www.reddit.com/r/deepweb/comments/1h6ot3u/need_to_talk_to_someone_on_whats_on_the_web/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/deepweb/comments/1h6ot3u/need_to_talk_to_someone_on_whats_on_the_web/">[comments]</a></span>

