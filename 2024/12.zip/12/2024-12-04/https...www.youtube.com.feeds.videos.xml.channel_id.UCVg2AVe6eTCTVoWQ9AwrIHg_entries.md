# Source:In Deep Geek, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCVg2AVe6eTCTVoWQ9AwrIHg, language:en

## Helm Hammerhand - A Character Study
 - [https://www.youtube.com/watch?v=sBXYDrHc0X0](https://www.youtube.com/watch?v=sBXYDrHc0X0)
 - RSS feed: $source
 - date published: 2024-12-04T21:00:42+00:00

Explore the best of fantasy and sci-fi in depth, with analysis of the worlds of Lord of the Rings, Game of Thrones, The Witcher and more.

For more Lord of the Rings content: https://www.youtube.com/playlist?list=PLVTclEEyY1SKFumpT86h-y6jikkEUKIAH 

Join me on Patreon - http://patreon.com/indeepgeek 
My channel for live content, including interviews and weekly livestreams – youtube.com/@IDGlive
My audiobook channel: The Well Told Tale - youtube.com/thewelltoldtale 

Follow me on:
Twitter - @indeepgeek 
Instagram – indeepgeekofficial
Facebook - https://facebook.com/indeepgeek 
TikTok - @indeepgeek
For merch, audiobooks, and all things In Deep Geek, explore my website - www.indeepgeek.com

Thank you to the talented artists who allowed their work to be featured in this video. You can find them and buy your own prints by following the links below:
Onirio -  https://www.deviantart.com/onirio/gallery/81571268/jrr-tolkien-legendarium-in-proper-sequence
Anthony Catillaz - https://www.artstat

