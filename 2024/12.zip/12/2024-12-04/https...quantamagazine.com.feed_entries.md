# Source:Quanta Magazine, URL:https://quantamagazine.com/feed, language:en-US

## The AI Pioneer With Provocative Plans for Humanity
 - [https://www.quantamagazine.org/the-ai-pioneer-with-provocative-plans-for-humanity-20241204](https://www.quantamagazine.org/the-ai-pioneer-with-provocative-plans-for-humanity-20241204)
 - RSS feed: $source
 - date published: 2024-12-04T14:51:43+00:00

While some fret about technology’s social impacts, Raj Reddy still believes in the power of artificial intelligence to improve lives.            <p>The post <a href="https://www.quantamagazine.org/the-ai-pioneer-with-provocative-plans-for-humanity-20241204/" target="_blank">The AI Pioneer With Provocative Plans for Humanity</a> first appeared on <a href="https://www.quantamagazine.org" target="_blank">Quanta Magazine</a></p>

