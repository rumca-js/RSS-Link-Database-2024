# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## To Deprive Trans Kids of Medical Care, Supreme Court Looks to Britain and Sweden
 - [https://theintercept.com/2024/12/04/supreme-court-trans-health-care-tennessee](https://theintercept.com/2024/12/04/supreme-court-trans-health-care-tennessee)
 - RSS feed: $source
 - date published: 2024-12-04T21:48:18+00:00

<p>Supreme Court conservatives cited overseas laws to defend draconian legislation in Tennessee banning gender-affirming care.</p>
<p>The post <a href="https://theintercept.com/2024/12/04/supreme-court-trans-health-care-tennessee/">To Deprive Trans Kids of Medical Care, Supreme Court Looks to Britain and Sweden</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>


## She Joined Facebook to Fight Terror. Now She’s Convinced We Need to Fight Facebook.
 - [https://theintercept.com/2024/12/04/meta-facebook-terrorism-censorship-speech](https://theintercept.com/2024/12/04/meta-facebook-terrorism-censorship-speech)
 - RSS feed: $source
 - date published: 2024-12-04T17:07:26+00:00

<p>Hannah Byrne joined Facebook to combat far-right extremism. She’s now convinced the tech giant can’t be trusted with such power.</p>
<p>The post <a href="https://theintercept.com/2024/12/04/meta-facebook-terrorism-censorship-speech/">She Joined Facebook to Fight Terror. Now She’s Convinced We Need to Fight Facebook.</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>


## Guess Who Profits From Trump’s Deportation Plan? Private Equity Firms.
 - [https://theintercept.com/2024/12/04/trump-mass-deportation-private-equity-prisons](https://theintercept.com/2024/12/04/trump-mass-deportation-private-equity-prisons)
 - RSS feed: $source
 - date published: 2024-12-04T11:04:00+00:00

<p>Private equity firms play a key role in America’s prison system. If Trump carries out his plans for mass deportations, they stand to benefit.</p>
<p>The post <a href="https://theintercept.com/2024/12/04/trump-mass-deportation-private-equity-prisons/">Guess Who Profits From Trump’s Deportation Plan? Private Equity Firms.</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>


## Police Raid Pro-Palestine Students’ Home in FBI-Led Graffiti Investigation
 - [https://theintercept.com/2024/12/03/george-mason-fbi-gaza-palestine-israel](https://theintercept.com/2024/12/03/george-mason-fbi-gaza-palestine-israel)
 - RSS feed: $source
 - date published: 2024-12-04T00:33:16+00:00

<p>George Mason University suspended its Students for Justice in Palestine chapter and effectively kicked out the group’s co-president.</p>
<p>The post <a href="https://theintercept.com/2024/12/03/george-mason-fbi-gaza-palestine-israel/">Police Raid Pro-Palestine Students’ Home in FBI-Led Graffiti Investigation</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>


