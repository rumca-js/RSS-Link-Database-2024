# Source:All things Warhammer!, URL:https://www.reddit.com/r/Warhammer/.rss, language:en

## The real one 🪄
 - [https://www.reddit.com/r/Warhammer/comments/1h6sa0l/the_real_one](https://www.reddit.com/r/Warhammer/comments/1h6sa0l/the_real_one)
 - RSS feed: $source
 - date published: 2024-12-04T21:50:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6sa0l/the_real_one/"> <img src="https://preview.redd.it/oyiq8bslkw4e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f7df49375aaed6044338ce83a9b6d6460d773ee4" alt="The real one 🪄" title="The real one 🪄" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/madsage87"> /u/madsage87 </a> <br/> <span><a href="https://i.redd.it/oyiq8bslkw4e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6sa0l/the_real_one/">[comments]</a></span> </td></tr></table>

## Be'lakor (40k version)
 - [https://www.reddit.com/r/Warhammer/comments/1h6rvy3/belakor_40k_version](https://www.reddit.com/r/Warhammer/comments/1h6rvy3/belakor_40k_version)
 - RSS feed: $source
 - date published: 2024-12-04T21:34:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6rvy3/belakor_40k_version/"> <img src="https://preview.redd.it/una9y7wphw4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=90d3aad5cf8b3323a16c14e9c24a9dc2b02ff85e" alt="Be'lakor (40k version)" title="Be'lakor (40k version)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/whirl_turtle"> /u/whirl_turtle </a> <br/> <span><a href="https://i.redd.it/una9y7wphw4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6rvy3/belakor_40k_version/">[comments]</a></span> </td></tr></table>

## WIP. Be’lakor. Such a great model but I do keep finding extra detail every time I sit down
 - [https://www.reddit.com/r/Warhammer/comments/1h6rpxe/wip_belakor_such_a_great_model_but_i_do_keep](https://www.reddit.com/r/Warhammer/comments/1h6rpxe/wip_belakor_such_a_great_model_but_i_do_keep)
 - RSS feed: $source
 - date published: 2024-12-04T21:28:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6rpxe/wip_belakor_such_a_great_model_but_i_do_keep/"> <img src="https://a.thumbs.redditmedia.com/z_wAZgbM8sc7P_VSarD-p8MvV8VczkmHnZSwyFizFj8.jpg" alt="WIP. Be’lakor. Such a great model but I do keep finding extra detail every time I sit down" title="WIP. Be’lakor. Such a great model but I do keep finding extra detail every time I sit down" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jake00dd"> /u/jake00dd </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6rpxe">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6rpxe/wip_belakor_such_a_great_model_but_i_do_keep/">[comments]</a></span> </td></tr></table>

## Enough nuln oil for today brother
 - [https://www.reddit.com/r/Warhammer/comments/1h6re2k/enough_nuln_oil_for_today_brother](https://www.reddit.com/r/Warhammer/comments/1h6re2k/enough_nuln_oil_for_today_brother)
 - RSS feed: $source
 - date published: 2024-12-04T21:14:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6re2k/enough_nuln_oil_for_today_brother/"> <img src="https://preview.redd.it/9b0xtlg5ew4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e3ebb80b289602fdb21787dbfe1d3edb430f7797" alt="Enough nuln oil for today brother " title="Enough nuln oil for today brother " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CaptainVlax"> /u/CaptainVlax </a> <br/> <span><a href="https://i.redd.it/9b0xtlg5ew4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6re2k/enough_nuln_oil_for_today_brother/">[comments]</a></span> </td></tr></table>

## Sloppity Bilepiper
 - [https://www.reddit.com/r/Warhammer/comments/1h6r5ty/sloppity_bilepiper](https://www.reddit.com/r/Warhammer/comments/1h6r5ty/sloppity_bilepiper)
 - RSS feed: $source
 - date published: 2024-12-04T21:05:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6r5ty/sloppity_bilepiper/"> <img src="https://b.thumbs.redditmedia.com/lpiL2YkNWn8X6fmOQvAWAVVgq1eyJCBQav3A6Li1t5o.jpg" alt="Sloppity Bilepiper" title="Sloppity Bilepiper" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AtomThePainter"> /u/AtomThePainter </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6r5ty">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6r5ty/sloppity_bilepiper/">[comments]</a></span> </td></tr></table>

## I love goblins wearing armor, I just wish there were more!
 - [https://www.reddit.com/r/Warhammer/comments/1h6r4n9/i_love_goblins_wearing_armor_i_just_wish_there](https://www.reddit.com/r/Warhammer/comments/1h6r4n9/i_love_goblins_wearing_armor_i_just_wish_there)
 - RSS feed: $source
 - date published: 2024-12-04T21:03:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6r4n9/i_love_goblins_wearing_armor_i_just_wish_there/"> <img src="https://preview.redd.it/0eml3k39cw4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=090d5cae76337e2985e48a427771d24a54f7de74" alt="I love goblins wearing armor, I just wish there were more! " title="I love goblins wearing armor, I just wish there were more! " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PressurePlate"> /u/PressurePlate </a> <br/> <span><a href="https://i.redd.it/0eml3k39cw4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6r4n9/i_love_goblins_wearing_armor_i_just_wish_there/">[comments]</a></span> </td></tr></table>

## Emperor's Champion !
 - [https://www.reddit.com/r/Warhammer/comments/1h6qsjl/emperors_champion](https://www.reddit.com/r/Warhammer/comments/1h6qsjl/emperors_champion)
 - RSS feed: $source
 - date published: 2024-12-04T20:50:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6qsjl/emperors_champion/"> <img src="https://b.thumbs.redditmedia.com/rroOcN4bPqjz23rjQqksrrbUpqiVvIjsQTptjHjbOwM.jpg" alt="Emperor's Champion !" title="Emperor's Champion !" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Kob346"> /u/Kob346 </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6qsjl">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6qsjl/emperors_champion/">[comments]</a></span> </td></tr></table>

## Ushoran
 - [https://www.reddit.com/r/Warhammer/comments/1h6q5j2/ushoran](https://www.reddit.com/r/Warhammer/comments/1h6q5j2/ushoran)
 - RSS feed: $source
 - date published: 2024-12-04T20:23:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6q5j2/ushoran/"> <img src="https://b.thumbs.redditmedia.com/0PT_PzM1-nisjTZ-YSIgjV2zU9RLjW9WoN97b2CCIwU.jpg" alt="Ushoran" title="Ushoran" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Ushoran, The Undying King, The Mortarch of Delusion complete as an upcoming video tutorial for the Grimdark Compendium.</p> <p>One of my all time favourite GW sculpts, this guy oozes character and atmosphere, so all I added here was a tattered shawl to break up the large expanse of cape, and some scratch built meat hooks &amp; chains to mirror the ones already attached to his pelt.</p> <p>Fairly extensive pre weathering and texturing undertaken and some surface manipulation to add a little extra depth to the skin prior to painting, and a deceptively large decrepit crypt base created to add some extra narrative.</p> <p>Painted using mixed acrylics and Villainy Ink, including the astounding phase 2 colors.</p> <p>An absolute pl

## No idea what paintbrushes and colours to get.
 - [https://www.reddit.com/r/Warhammer/comments/1h6onuq/no_idea_what_paintbrushes_and_colours_to_get](https://www.reddit.com/r/Warhammer/comments/1h6onuq/no_idea_what_paintbrushes_and_colours_to_get)
 - RSS feed: $source
 - date published: 2024-12-04T19:23:44+00:00

<!-- SC_OFF --><div class="md"><p>Hi, So I have custom made minatures and I love citadel paints as Ive used them before for warhammer painting and I was wondering what the best setup for paints is, Im new and only painted my first 3 models with the starter pack age of sigmar and I am looking to upgrade paintbrushes for more fine detail and maybe a larger brush for quicker painting, For Colours I am looking for something generic that I would always use in minatures? Does anyone have any ideas that could help me?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Marceleyyy"> /u/Marceleyyy </a> <br/> <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6onuq/no_idea_what_paintbrushes_and_colours_to_get/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6onuq/no_idea_what_paintbrushes_and_colours_to_get/">[comments]</a></span>

## Fallen sisters of Slaanesh close ups
 - [https://www.reddit.com/r/Warhammer/comments/1h6n6uc/fallen_sisters_of_slaanesh_close_ups](https://www.reddit.com/r/Warhammer/comments/1h6n6uc/fallen_sisters_of_slaanesh_close_ups)
 - RSS feed: $source
 - date published: 2024-12-04T18:25:20+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Last_Calamity"> /u/Last_Calamity </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6n52c">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6n6uc/fallen_sisters_of_slaanesh_close_ups/">[comments]</a></span>

## My old ass still trying to support the All-Father
 - [https://www.reddit.com/r/Warhammer/comments/1h6kyt2/my_old_ass_still_trying_to_support_the_allfather](https://www.reddit.com/r/Warhammer/comments/1h6kyt2/my_old_ass_still_trying_to_support_the_allfather)
 - RSS feed: $source
 - date published: 2024-12-04T16:58:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6kyt2/my_old_ass_still_trying_to_support_the_allfather/"> <img src="https://preview.redd.it/1mq9r60g4v4e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0eddf229a5406150a5b9530d105cdafa279eb8f1" alt="My old ass still trying to support the All-Father" title="My old ass still trying to support the All-Father" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FtF_Alters"> /u/FtF_Alters </a> <br/> <span><a href="https://i.redd.it/1mq9r60g4v4e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6kyt2/my_old_ass_still_trying_to_support_the_allfather/">[comments]</a></span> </td></tr></table>

## All the gear and no idea!!
 - [https://www.reddit.com/r/Warhammer/comments/1h6kqd1/all_the_gear_and_no_idea](https://www.reddit.com/r/Warhammer/comments/1h6kqd1/all_the_gear_and_no_idea)
 - RSS feed: $source
 - date published: 2024-12-04T16:49:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6kqd1/all_the_gear_and_no_idea/"> <img src="https://preview.redd.it/2x0q4hrt2v4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0075a497a9328e017d29bbc17714b8ef584ac788" alt="All the gear and no idea!!" title="All the gear and no idea!!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>After 25 years I’ve decided to pick up a paint brush again didn’t realise it would cost a small fortune 🫣. Wish me luck I’ll post some updates if they turn out alright 😂</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PollutionOne6661"> /u/PollutionOne6661 </a> <br/> <span><a href="https://i.redd.it/2x0q4hrt2v4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6kqd1/all_the_gear_and_no_idea/">[comments]</a></span> </td></tr></table>

## December 24 after the base size changed vs. April 23 Mibyllorr Darkfang
 - [https://www.reddit.com/r/Warhammer/comments/1h6j66x/december_24_after_the_base_size_changed_vs_april](https://www.reddit.com/r/Warhammer/comments/1h6j66x/december_24_after_the_base_size_changed_vs_april)
 - RSS feed: $source
 - date published: 2024-12-04T15:46:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6j66x/december_24_after_the_base_size_changed_vs_april/"> <img src="https://a.thumbs.redditmedia.com/1oRifcj9SfbtUBk1fcuSTzBkUlAzboUjhvn9DGPEfk0.jpg" alt="December 24 after the base size changed vs. April 23 Mibyllorr Darkfang " title="December 24 after the base size changed vs. April 23 Mibyllorr Darkfang " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IgnisFatuu"> /u/IgnisFatuu </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6j66x">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6j66x/december_24_after_the_base_size_changed_vs_april/">[comments]</a></span> </td></tr></table>

## Magnets suitable for dreadnaught attachments?
 - [https://www.reddit.com/r/Warhammer/comments/1h6i7zp/magnets_suitable_for_dreadnaught_attachments](https://www.reddit.com/r/Warhammer/comments/1h6i7zp/magnets_suitable_for_dreadnaught_attachments)
 - RSS feed: $source
 - date published: 2024-12-04T15:07:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6i7zp/magnets_suitable_for_dreadnaught_attachments/"> <img src="https://preview.redd.it/ncrlbh5qku4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9406f9a858127511b3c0328250a43dae617a7c14" alt="Magnets suitable for dreadnaught attachments? " title="Magnets suitable for dreadnaught attachments? " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hey, </p> <p>I’ve had these 3x1mm magnets stored away for a while, Santa is bringing my first Dreadnaught and the plan was to magnetise for different attachments but unsure if they’ll be too small? </p> <p>Tia</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GrimGinge"> /u/GrimGinge </a> <br/> <span><a href="https://i.redd.it/ncrlbh5qku4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6i7zp/magnets_suitable_for_dreadnaught_attachments/">[comments]</a></span> </td></tr></table>

## Grotmas comes to the Mortal Realms with eight free Regiments of Renown
 - [https://www.reddit.com/r/Warhammer/comments/1h6hy89/grotmas_comes_to_the_mortal_realms_with_eight](https://www.reddit.com/r/Warhammer/comments/1h6hy89/grotmas_comes_to_the_mortal_realms_with_eight)
 - RSS feed: $source
 - date published: 2024-12-04T14:56:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6hy89/grotmas_comes_to_the_mortal_realms_with_eight/"> <img src="https://external-preview.redd.it/LHjDDQZn7hlI6nSWEW2z9hK4W3OrTtgbTGyjcEa_s-I.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=27a157396dc2910eaadf731d7456de13667b1e2b" alt="Grotmas comes to the Mortal Realms with eight free Regiments of Renown" title="Grotmas comes to the Mortal Realms with eight free Regiments of Renown" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/-CMYK_COLOR_MODE-"> /u/-CMYK_COLOR_MODE- </a> <br/> <span><a href="https://www.warhammer-community.com/en-gb/articles/x3og0mrh/grotmas-comes-to-the-mortal-realms-with-eight-free-regiments-of-renown/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6hy89/grotmas_comes_to_the_mortal_realms_with_eight/">[comments]</a></span> </td></tr></table>

## I’m painting my first mini figure and I feel like the paint is chipping
 - [https://www.reddit.com/r/Warhammer/comments/1h6gjxi/im_painting_my_first_mini_figure_and_i_feel_like](https://www.reddit.com/r/Warhammer/comments/1h6gjxi/im_painting_my_first_mini_figure_and_i_feel_like)
 - RSS feed: $source
 - date published: 2024-12-04T13:55:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6gjxi/im_painting_my_first_mini_figure_and_i_feel_like/"> <img src="https://preview.redd.it/4r3qkvbv7u4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e75cd4888a5c6164769c5f0b7b880297e82f0e9b" alt="I’m painting my first mini figure and I feel like the paint is chipping " title="I’m painting my first mini figure and I feel like the paint is chipping " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Im no where near done yet with the painting. Im not sure if its bad paint work on my behalf I know its not the best anyways but in all the corners and the head/gun I painted it all and made sure I did having no gray showing and I’ve came back to it today with a lot of the gray coming threw and seeming like it’s chipping off because where I’m working as well there’s little paint chips, is there anyway to stop it chipping? Is it something I’m doing wrong with the paint because I’m not sure if I’m applying it to t

## 40k loves frankensteining historical designs, so why hasn't this been ripped off yet? Give the Land Raider a big brother!
 - [https://www.reddit.com/r/Warhammer/comments/1h6g4ek/40k_loves_frankensteining_historical_designs_so](https://www.reddit.com/r/Warhammer/comments/1h6g4ek/40k_loves_frankensteining_historical_designs_so)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6g4ek/40k_loves_frankensteining_historical_designs_so/"> <img src="https://preview.redd.it/a03k8boqpt4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bba94d9698d1ad0a6d26cc9748ae86f912e5f992" alt="40k loves frankensteining historical designs, so why hasn't this been ripped off yet? Give the Land Raider a big brother!" title="40k loves frankensteining historical designs, so why hasn't this been ripped off yet? Give the Land Raider a big brother!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jarmak1234"> /u/jarmak1234 </a> <br/> <span><a href="https://i.redd.it/a03k8boqpt4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6g4ek/40k_loves_frankensteining_historical_designs_so/">[comments]</a></span> </td></tr></table>

## Legio Fureans Reinforcement!🔥
 - [https://www.reddit.com/r/Warhammer/comments/1h6fknh/legio_fureans_reinforcement](https://www.reddit.com/r/Warhammer/comments/1h6fknh/legio_fureans_reinforcement)
 - RSS feed: $source
 - date published: 2024-12-04T13:08:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6fknh/legio_fureans_reinforcement/"> <img src="https://b.thumbs.redditmedia.com/K8Y3ln8c3iSOJZi5hFvoa2o53uXASM0wAqRvEtUppfY.jpg" alt="Legio Fureans Reinforcement!🔥 " title="Legio Fureans Reinforcement!🔥 " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/emperorhimself"> /u/emperorhimself </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6fknh">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6fknh/legio_fureans_reinforcement/">[comments]</a></span> </td></tr></table>

## Grotmas Calendar Day 4 – A light dusting of… snow? - Warhammer Community
 - [https://www.reddit.com/r/Warhammer/comments/1h6ebqd/grotmas_calendar_day_4_a_light_dusting_of_snow](https://www.reddit.com/r/Warhammer/comments/1h6ebqd/grotmas_calendar_day_4_a_light_dusting_of_snow)
 - RSS feed: $source
 - date published: 2024-12-04T11:58:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6ebqd/grotmas_calendar_day_4_a_light_dusting_of_snow/"> <img src="https://external-preview.redd.it/1_8ABngF4W7IjQ0X4612ObnRJ6kymTFhgtyUmtRqESI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0eb28c89a3018526d7920072d16cf15efddf2ea6" alt="Grotmas Calendar Day 4 – A light dusting of… snow? - Warhammer Community" title="Grotmas Calendar Day 4 – A light dusting of… snow? - Warhammer Community" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/I_suck_at_Blender"> /u/I_suck_at_Blender </a> <br/> <span><a href="https://www.warhammer-community.com/en-gb/articles/d1mcf5ae/grotmas-calendar-day-4-a-light-dusting-of-snow/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6ebqd/grotmas_calendar_day_4_a_light_dusting_of_snow/">[comments]</a></span> </td></tr></table>

## Da Red Gobbo
 - [https://www.reddit.com/r/Warhammer/comments/1h6dxkl/da_red_gobbo](https://www.reddit.com/r/Warhammer/comments/1h6dxkl/da_red_gobbo)
 - RSS feed: $source
 - date published: 2024-12-04T11:32:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6dxkl/da_red_gobbo/"> <img src="https://preview.redd.it/wuh05h8eit4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=70dbd29ac0fe2c8ab159c3adee67b748c9cef003" alt="Da Red Gobbo" title="Da Red Gobbo" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Think this will be my new Christmas tradition </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FrazMoJazz"> /u/FrazMoJazz </a> <br/> <span><a href="https://i.redd.it/wuh05h8eit4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6dxkl/da_red_gobbo/">[comments]</a></span> </td></tr></table>

## Awesome model but I’m not sure if he can be used any more?
 - [https://www.reddit.com/r/Warhammer/comments/1h6dtc9/awesome_model_but_im_not_sure_if_he_can_be_used](https://www.reddit.com/r/Warhammer/comments/1h6dtc9/awesome_model_but_im_not_sure_if_he_can_be_used)
 - RSS feed: $source
 - date published: 2024-12-04T11:25:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6dtc9/awesome_model_but_im_not_sure_if_he_can_be_used/"> <img src="https://b.thumbs.redditmedia.com/vwOnXViU_BaUcyhc7O9K0BAEjOrwan5cVS2B7ulkk5Q.jpg" alt="Awesome model but I’m not sure if he can be used any more?" title="Awesome model but I’m not sure if he can be used any more?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LongjumpingPickle499"> /u/LongjumpingPickle499 </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6dtc9">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6dtc9/awesome_model_but_im_not_sure_if_he_can_be_used/">[comments]</a></span> </td></tr></table>

## I require some paint magic assistance
 - [https://www.reddit.com/r/Warhammer/comments/1h6cmqk/i_require_some_paint_magic_assistance](https://www.reddit.com/r/Warhammer/comments/1h6cmqk/i_require_some_paint_magic_assistance)
 - RSS feed: $source
 - date published: 2024-12-04T10:01:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6cmqk/i_require_some_paint_magic_assistance/"> <img src="https://preview.redd.it/ynofj5z42t4e1.jpeg?width=216&amp;crop=smart&amp;auto=webp&amp;s=09362793fa965fde4e69d682e909d7ea86b80d72" alt="I require some paint magic assistance" title="I require some paint magic assistance" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I live in a country in which I can’t easily buy new paints so</p> <p>How in the emperors name can I achieve a skin tone with these colors please </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JonhLawieskt"> /u/JonhLawieskt </a> <br/> <span><a href="https://i.redd.it/ynofj5z42t4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6cmqk/i_require_some_paint_magic_assistance/">[comments]</a></span> </td></tr></table>

## Canoptek Doomstalker
 - [https://www.reddit.com/r/Warhammer/comments/1h6c38k/canoptek_doomstalker](https://www.reddit.com/r/Warhammer/comments/1h6c38k/canoptek_doomstalker)
 - RSS feed: $source
 - date published: 2024-12-04T09:20:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6c38k/canoptek_doomstalker/"> <img src="https://b.thumbs.redditmedia.com/oE6aBmp8bxpoH9E3YmfPp6Qt9inLJ0XU5hhzJL9IPaU.jpg" alt="Canoptek Doomstalker" title="Canoptek Doomstalker" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Painted up my Canoptek Doomstalker from the Combat Patrol box in my custom dynasty scheme, i feel kind of iffy about the paint job but it’s a finished product either way </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IronWarriorPainter"> /u/IronWarriorPainter </a> <br/> <span><a href="https://www.reddit.com/gallery/1h6c38k">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6c38k/canoptek_doomstalker/">[comments]</a></span> </td></tr></table>

## Group shot of the Gobbapalooza unit I've been painting!
 - [https://www.reddit.com/r/Warhammer/comments/1h6bpdw/group_shot_of_the_gobbapalooza_unit_ive_been](https://www.reddit.com/r/Warhammer/comments/1h6bpdw/group_shot_of_the_gobbapalooza_unit_ive_been)
 - RSS feed: $source
 - date published: 2024-12-04T08:51:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h6bpdw/group_shot_of_the_gobbapalooza_unit_ive_been/"> <img src="https://preview.redd.it/4vjl7fqjps4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3c5d2d9373cd8b3d5c6c63aacda561b1d258a03a" alt="Group shot of the Gobbapalooza unit I've been painting!" title="Group shot of the Gobbapalooza unit I've been painting!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ranjeybaby"> /u/ranjeybaby </a> <br/> <span><a href="https://i.redd.it/4vjl7fqjps4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6bpdw/group_shot_of_the_gobbapalooza_unit_ive_been/">[comments]</a></span> </td></tr></table>

## Warband scheme test
 - [https://www.reddit.com/r/Warhammer/comments/1h6aiex/warband_scheme_test](https://www.reddit.com/r/Warhammer/comments/1h6aiex/warband_scheme_test)
 - RSS feed: $source
 - date published: 2024-12-04T07:21:04+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Will-Dear-born"> /u/Will-Dear-born </a> <br/> <span><a href="https://www.reddit.com/gallery/1h61o1l">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h6aiex/warband_scheme_test/">[comments]</a></span>

## Classic Mortarion. Super Sculpey, Green Stuff, Majick Sculpt
 - [https://www.reddit.com/r/Warhammer/comments/1h68du8/classic_mortarion_super_sculpey_green_stuff](https://www.reddit.com/r/Warhammer/comments/1h68du8/classic_mortarion_super_sculpey_green_stuff)
 - RSS feed: $source
 - date published: 2024-12-04T05:05:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h68du8/classic_mortarion_super_sculpey_green_stuff/"> <img src="https://b.thumbs.redditmedia.com/hYnhwjwaHRHmeZ8EBiXI5qDs_34o3iNX4Xzkp5-g_wc.jpg" alt="Classic Mortarion. Super Sculpey, Green Stuff, Majick Sculpt" title="Classic Mortarion. Super Sculpey, Green Stuff, Majick Sculpt" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ragnarwerk"> /u/Ragnarwerk </a> <br/> <span><a href="https://www.reddit.com/gallery/1h68du8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h68du8/classic_mortarion_super_sculpey_green_stuff/">[comments]</a></span> </td></tr></table>

## Introducing Colonel Rock ‘Venom Bones’ Millenz, leader of the Catachan XCVI regiment or better known as the ‘Black Adders’. First to strike and last to leave! Hope you enjoy my Lord Solar Proxy! About half a centimeter off from the original height so pretty darn close!
 - [https://www.reddit.com/r/Warhammer/comments/1h688gt/introducing_colonel_rock_venom_bones_millenz](https://www.reddit.com/r/Warhammer/comments/1h688gt/introducing_colonel_rock_venom_bones_millenz)
 - RSS feed: $source
 - date published: 2024-12-04T04:58:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h688gt/introducing_colonel_rock_venom_bones_millenz/"> <img src="https://b.thumbs.redditmedia.com/DpUfdVpDSOcoXbQSffqLCIWMkhXoWLiVgSMW-sCUiwQ.jpg" alt="Introducing Colonel Rock ‘Venom Bones’ Millenz, leader of the Catachan XCVI regiment or better known as the ‘Black Adders’. First to strike and last to leave! Hope you enjoy my Lord Solar Proxy! About half a centimeter off from the original height so pretty darn close!" title="Introducing Colonel Rock ‘Venom Bones’ Millenz, leader of the Catachan XCVI regiment or better known as the ‘Black Adders’. First to strike and last to leave! Hope you enjoy my Lord Solar Proxy! About half a centimeter off from the original height so pretty darn close!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/D0ct0rAlanGrant"> /u/D0ct0rAlanGrant </a> <br/> <span><a href="https://www.reddit.com/gallery/1h688gt">[link]</a></span> &#32; <span><a href="http

## You are his lawyer. Defend him.
 - [https://www.reddit.com/r/Warhammer/comments/1h66riq/you_are_his_lawyer_defend_him](https://www.reddit.com/r/Warhammer/comments/1h66riq/you_are_his_lawyer_defend_him)
 - RSS feed: $source
 - date published: 2024-12-04T03:36:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h66riq/you_are_his_lawyer_defend_him/"> <img src="https://preview.redd.it/mhzi3g3h5r4e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=0b2bff73fef51e35cdda5c71683fa4db5fa57c6a" alt="You are his lawyer. Defend him." title="You are his lawyer. Defend him." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AlpaCreed"> /u/AlpaCreed </a> <br/> <span><a href="https://i.redd.it/mhzi3g3h5r4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h66riq/you_are_his_lawyer_defend_him/">[comments]</a></span> </td></tr></table>

## I give to you... Summer Skitarii in December!
 - [https://www.reddit.com/r/Warhammer/comments/1h65lrb/i_give_to_you_summer_skitarii_in_december](https://www.reddit.com/r/Warhammer/comments/1h65lrb/i_give_to_you_summer_skitarii_in_december)
 - RSS feed: $source
 - date published: 2024-12-04T02:38:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h65lrb/i_give_to_you_summer_skitarii_in_december/"> <img src="https://b.thumbs.redditmedia.com/4-NSbRQvEeYN2H4R-7yDuX0_3rn1HtRj7tXB31SxiVI.jpg" alt="I give to you... Summer Skitarii in December!" title="I give to you... Summer Skitarii in December!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Helios_The_Undying"> /u/Helios_The_Undying </a> <br/> <span><a href="https://www.reddit.com/gallery/1h65lrb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h65lrb/i_give_to_you_summer_skitarii_in_december/">[comments]</a></span> </td></tr></table>

## My Freeguild Marshal Proxy! Hope u guys like it 🤘🏾
 - [https://www.reddit.com/r/Warhammer/comments/1h658pp/my_freeguild_marshal_proxy_hope_u_guys_like_it](https://www.reddit.com/r/Warhammer/comments/1h658pp/my_freeguild_marshal_proxy_hope_u_guys_like_it)
 - RSS feed: $source
 - date published: 2024-12-04T02:19:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h658pp/my_freeguild_marshal_proxy_hope_u_guys_like_it/"> <img src="https://preview.redd.it/6lzbksrprq4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3a50024016c0c0242d7c1678a120a3662ea7e146" alt="My Freeguild Marshal Proxy! Hope u guys like it 🤘🏾" title="My Freeguild Marshal Proxy! Hope u guys like it 🤘🏾" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HomunculiV"> /u/HomunculiV </a> <br/> <span><a href="https://i.redd.it/6lzbksrprq4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h658pp/my_freeguild_marshal_proxy_hope_u_guys_like_it/">[comments]</a></span> </td></tr></table>

## First time NMM’ing
 - [https://www.reddit.com/r/Warhammer/comments/1h63v3d/first_time_nmming](https://www.reddit.com/r/Warhammer/comments/1h63v3d/first_time_nmming)
 - RSS feed: $source
 - date published: 2024-12-04T01:12:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h63v3d/first_time_nmming/"> <img src="https://b.thumbs.redditmedia.com/b17ZJAFSitFDABHP9zt3sNLq4_3vO8yn9xuttnsl2fk.jpg" alt="First time NMM’ing " title="First time NMM’ing " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Decided to have a stab at some NMM gold so I dug out an old Stormcast and dusted off the ice yellow! Surprisingly pleased with the results so far, couple more steps and the armours finished. </p> <p>Another pleasant surprise was realising the process is highly enjoyable! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Equal_Thing_5756"> /u/Equal_Thing_5756 </a> <br/> <span><a href="https://www.reddit.com/gallery/1h63v3d">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h63v3d/first_time_nmming/">[comments]</a></span> </td></tr></table>

## Zikkit’s tunnelpack
 - [https://www.reddit.com/r/Warhammer/comments/1h62ika/zikkits_tunnelpack](https://www.reddit.com/r/Warhammer/comments/1h62ika/zikkits_tunnelpack)
 - RSS feed: $source
 - date published: 2024-12-04T00:10:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1h62ika/zikkits_tunnelpack/"> <img src="https://b.thumbs.redditmedia.com/tqFi1KMKQofQdsHQfmyWyP581EPpPSAbNeLPTL-iMvA.jpg" alt="Zikkit’s tunnelpack" title="Zikkit’s tunnelpack" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NOWANGSTA"> /u/NOWANGSTA </a> <br/> <span><a href="https://www.reddit.com/gallery/1h62ika">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1h62ika/zikkits_tunnelpack/">[comments]</a></span> </td></tr></table>

