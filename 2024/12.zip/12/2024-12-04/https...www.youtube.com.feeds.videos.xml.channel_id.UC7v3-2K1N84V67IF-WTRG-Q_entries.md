# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Nosferatu - Movie Review
 - [https://www.youtube.com/watch?v=y7ElL5U4VmU](https://www.youtube.com/watch?v=y7ElL5U4VmU)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:58+00:00

Robert Eggars brings us a remake of the classic horror film, which he's wanted to do for over a decade now. Here's my review for NOSFERATU!

#Nosferatu

