# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Nastolatka szpiegowała dla Rosji. Grozi jej dożywocie
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/nastolatka-szpiegowala-dla-rosji-grozi-jej-dozywocie](https://www.polsatnews.pl/wiadomosc/2024-12-04/nastolatka-szpiegowala-dla-rosji-grozi-jej-dozywocie)
 - RSS feed: $source
 - date published: 2024-12-04T21:13:16.599936+00:00

Służba Bezpieczeństwa Ukrainy (SBU) zatrzymała 16-latkę, która szpiegowała dla Rosji. Nastolatka wybierała się na długie wycieczki taksówką, podczas których fotografowała ważne miejsca i strategiczne punkty. Jej informacje miały pomóc w zaplanowaniu kolejnych nalotów.

## Potężny kryzys we Francji. Upadł tamtejszy rząd
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/potezny-kryzys-we-francji-upadl-tamtejszy-rzad](https://www.polsatnews.pl/wiadomosc/2024-12-04/potezny-kryzys-we-francji-upadl-tamtejszy-rzad)
 - RSS feed: $source
 - date published: 2024-12-04T20:08:02.146811+00:00

Francuskie Zgromadzenie Narodowe przyjęło wniosek o wotum nieufności wobec obecnego rządu Michela Barniera. Wniosek został zaproponowany przez skrajną lewicę, a poparty przez skrajną prawicę pod przywództwem Marine Le Pen.

## Prezentacja nowego auta Franciszka. Papamobile jest elektryczny
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/prezentacja-nowego-auta-franciszka-papamobile-jest-elektryczny](https://www.polsatnews.pl/wiadomosc/2024-12-04/prezentacja-nowego-auta-franciszka-papamobile-jest-elektryczny)
 - RSS feed: $source
 - date published: 2024-12-04T19:03:02.448562+00:00

W Watykanie pokazano nowy papamobile. Jest to zmodyfikowana wersja luksusowego Mercedesa SUV klasy G. Pojazd jest biały i, co ważne, elektryczny. - Zbudowanie jedynego w swoim rodzaju auta wymagało setek godzin - powiedział dyrektor generalny firmy Sten Ola Kallenius. Nie zdradzono, ile kosztował samochód.

## Polak w litewskim rządzie. Zostanie szefem MSW
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/polak-w-litewskim-rzadzie-zostanie-szefem-msw](https://www.polsatnews.pl/wiadomosc/2024-12-04/polak-w-litewskim-rzadzie-zostanie-szefem-msw)
 - RSS feed: $source
 - date published: 2024-12-04T19:03:02.193426+00:00

Władysław Kondratowicz zostanie nowym ministrem spraw wewnętrznych Litwy. Polak otrzymał mandat w październikowych wyborach parlamentarnych, startując z ugrupowania Litewskiej Partii Socjaldemokratycznej.

## Incydent na Bałtyku. Rosyjski okręt wystrzelił amunicję sygnalizacyjną
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/incydent-na-baltyku-rosyjski-okret-wystrzelil-amunicje-sygnalizacyjna](https://www.polsatnews.pl/wiadomosc/2024-12-04/incydent-na-baltyku-rosyjski-okret-wystrzelil-amunicje-sygnalizacyjna)
 - RSS feed: $source
 - date published: 2024-12-04T16:53:09.942899+00:00

Rosyjski okręt wystrzelił pociski sygnalizacyjne w kierunku śmigłowca Bundeswehry przeprowadzającego misję rozpoznawczą - powiadomiła szefowa niemieckiego MON. Minister zapowiedziała wzmożenie działań na Morzu Bałtyckim.

## Papież Franciszek wspomniał o Polakach. "Modlitwą i ofiarą"
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/papiez-franciszek-wspomnial-o-polakach-modlitwa-i-ofiara](https://www.polsatnews.pl/wiadomosc/2024-12-04/papiez-franciszek-wspomnial-o-polakach-modlitwa-i-ofiara)
 - RSS feed: $source
 - date published: 2024-12-04T13:38:00.496454+00:00

Premier Węgier spotkał się z papieżem. Wśród tematów rozmów była m.in. wojna na Ukrainie i jej skutki dla ludności cywilnej. Nastąpiła również tradycyjna wymiana podarunkami. Podczas audiencji Franciszek mówił o Polsce i Polakach, którzy wspierają kraje ogarnięte wojną.

## Impeachment w Korei Południowej. Jest wniosek
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/impeachment-w-korei-poludniowej-jest-wniosek](https://www.polsatnews.pl/wiadomosc/2024-12-04/impeachment-w-korei-poludniowej-jest-wniosek)
 - RSS feed: $source
 - date published: 2024-12-04T13:38:00.249069+00:00

Parlamentarna opozycja Korei Południowej wszczęła procedurę impeachmentu prezydenta Jun Suk Jeola. AFP dotarło do treści wniosku, w którym wskazano, że wprowadzenie stanu wojennego miało mieć na celu uniknięcie dochodzenia przez głowę państwa i jej bliskich.

## Tragedia na rajskiej plaży. Nie żyje rosyjska aktorka
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/tragedia-na-rajskiej-plazy-nie-zyje-rosyjska-aktorka](https://www.polsatnews.pl/wiadomosc/2024-12-04/tragedia-na-rajskiej-plazy-nie-zyje-rosyjska-aktorka)
 - RSS feed: $source
 - date published: 2024-12-04T12:32:00+00:00

Młoda aktorka z Nowosybirska zginęła podczas pobytu w Tajlandii. Kamilla Belyatskaya odpoczywała nad skalistym brzegu, gdy w pewnym momencie porwała ją fala. Na ratunek rzucił się jeden ze świadków, było jednak już za późno.

## Policja w domu byłego komisarza UE. W tle afera z praniem brudnych pieniędzy
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/policja-przeszukala-nieruchomosci-bylego-komisarza-ue-maja-podejrzenia](https://www.polsatnews.pl/wiadomosc/2024-12-04/policja-przeszukala-nieruchomosci-bylego-komisarza-ue-maja-podejrzenia)
 - RSS feed: $source
 - date published: 2024-12-04T12:08:00+00:00

Policja przeszukała nieruchomości należące do Didiera Reyndersa. Były komisarz Unii Europejskiej ds. sprawiedliwości został przesłuchany. Służby podejrzewają polityka o wieloletnie pranie brudnych pieniędzy.

## Włochy wprowadzają zmiany. Chodzi o bezpieczeństwo, ale uderzą w turystów
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/wlochy-wprowadzaja-zmiany-chodzi-o-bezpieczenstwo-ale-uderza-w-turystow](https://www.polsatnews.pl/wiadomosc/2024-12-04/wlochy-wprowadzaja-zmiany-chodzi-o-bezpieczenstwo-ale-uderza-w-turystow)
 - RSS feed: $source
 - date published: 2024-12-04T09:17:51.494128+00:00

Włochy wprowadzają spore zmiany związane z zameldowaniem osób przyjezdnych. Od teraz każdy turysta musi otrzymać klucze do wynajmowanego mieszkania bezpośrednio od właściciela. Koniec z zostawianiem kluczy w specjalnych skrzynkach na kłódki i wysyłaniem internetowej instrukcji. Władze tłumaczą to względami bezpieczeństwa, ale lokalni mówią o zmniejszeniu ruchu turystycznego.

## Prezydent potajemnie zoperowała nos. Teraz może stracić urząd
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/prezydent-potajemnie-zoperowala-nos-teraz-moze-stracic-urzad](https://www.polsatnews.pl/wiadomosc/2024-12-04/prezydent-potajemnie-zoperowala-nos-teraz-moze-stracic-urzad)
 - RSS feed: $source
 - date published: 2024-12-04T09:17:51.387008+00:00

Prezydent Peru Dina Boluarte wpadła w kłopoty z powodu potajemnej operacji plastycznej nosa. Polityk zniknęła z życia publicznego na 12 dni. Problem w tym, że nie wyznaczyła zastępcy na czas swojej nieobecności. W związku z tym, w kraju pojawiły się apele o usunięcie jej z urzędu.

## Stan wojenny w Korei Południowej. USA komentuje
 - [https://www.polsatnews.pl/wiadomosc/2024-12-04/stan-wojenny-w-korei-poludniowej-usa-komentuje](https://www.polsatnews.pl/wiadomosc/2024-12-04/stan-wojenny-w-korei-poludniowej-usa-komentuje)
 - RSS feed: $source
 - date published: 2024-12-04T06:49:00+00:00

- Jesteśmy zadowoleni, że prezydent Jun zmienił kurs ws. swojego niepokojącego ogłoszenia stanu wojennego i uszanował decyzję Zgromadzenia Narodowego Republiki Korei o jego zakończeniu - przekazał rzecznik Rady Bezpieczeństwa Narodowego USA. Jun Suk Jeola wprowadził stan wojenny w celu eliminacji sił antypaństwowych, ale już po kilku godzinach go zniósł. Teraz opozycja żąda dymisji prezydenta.

