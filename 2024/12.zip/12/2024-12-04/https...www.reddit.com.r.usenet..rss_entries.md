# Source:Usenet, URL:https://www.reddit.com/r/usenet/.rss, language:en

## UNS increase?
 - [https://www.reddit.com/r/usenet/comments/1h6stqq/uns_increase](https://www.reddit.com/r/usenet/comments/1h6stqq/uns_increase)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:22+00:00

<!-- SC_OFF --><div class="md"><p>Have been with them for ages, despite having alternatives. They sent a letter indicating they will now be adding a VPN and increasing their prices at the next billing cycle. Has anyone else received this? Is the only alternative, if one doesn’t want the increase, to cancel?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lstep2"> /u/lstep2 </a> <br/> <span><a href="https://www.reddit.com/r/usenet/comments/1h6stqq/uns_increase/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/usenet/comments/1h6stqq/uns_increase/">[comments]</a></span>

## Usenet downloads are crawling
 - [https://www.reddit.com/r/usenet/comments/1h6iy2g/usenet_downloads_are_crawling](https://www.reddit.com/r/usenet/comments/1h6iy2g/usenet_downloads_are_crawling)
 - RSS feed: $source
 - date published: 2024-12-04T15:37:34+00:00

<!-- SC_OFF --><div class="md"><p>** Update, issue seems to be with Easynews servers in the Netherlands. </p> <p>Not sure what has changed in the past week, but all my usenet downloads are crawling, I am lucky if I get above 500KB. I&#39;ve checked my settings and connection to servers, firewall isn&#39;t reporting anything suspicious either and my bandwidth has been fine.</p> <p>So far in troubleshooting I have done the following:</p> <p>- updated Sabnzb from 4.1.x to 4.3.3</p> <p>- installed all windows updates and rebooted</p> <p>- reviewed cpu performance and ram, cpu never goes about 20% and ram sits around 3GB of 8GB</p> <p>- tested connection to switch, then to firewall using wireshark</p> <p>- tested bandwidth behind firewall and and directly connected, getting 300mb each way</p> <p>- Not sure if its related to usenet servers in Europe, but easynews seems to be my biggest culprit even though i have the priority set at 90. I use 2 other usenet services for download at 0 and 1,

## This sub is bent
 - [https://www.reddit.com/r/usenet/comments/1h6e8wh/this_sub_is_bent](https://www.reddit.com/r/usenet/comments/1h6e8wh/this_sub_is_bent)
 - RSS feed: $source
 - date published: 2024-12-04T11:53:20+00:00

<!-- SC_OFF --><div class="md"><p>all the people who offered and they set up 2 accounts. 1 low usage and 1 clearly fake </p> <p>Good luck all. you are going to need it lol </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/No_Importance_5000"> /u/No_Importance_5000 </a> <br/> <span><a href="https://www.reddit.com/r/usenet/comments/1h6e8wh/this_sub_is_bent/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/usenet/comments/1h6e8wh/this_sub_is_bent/">[comments]</a></span>

## Am I using Usenight wrong? Really low success rate
 - [https://www.reddit.com/r/usenet/comments/1h6e7a3/am_i_using_usenight_wrong_really_low_success_rate](https://www.reddit.com/r/usenet/comments/1h6e7a3/am_i_using_usenight_wrong_really_low_success_rate)
 - RSS feed: $source
 - date published: 2024-12-04T11:50:23+00:00

<!-- SC_OFF --><div class="md"><p>I have it as priority 0 enabled during their night hours and while it&#39;s quite fast when it does hit (slower than my others tbh, but reasonable), I&#39;m getting a really poor hit rate: </p> <p>Article availability: Selected date range: 6% available of 3M requested articles</p> <p>This is compared to around 60-70% for newshosting and newsdemon</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/doolittledoolate"> /u/doolittledoolate </a> <br/> <span><a href="https://www.reddit.com/r/usenet/comments/1h6e7a3/am_i_using_usenight_wrong_really_low_success_rate/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/usenet/comments/1h6e7a3/am_i_using_usenight_wrong_really_low_success_rate/">[comments]</a></span>

## Can any article be missed?
 - [https://www.reddit.com/r/usenet/comments/1h6cfzs/can_any_article_be_missed](https://www.reddit.com/r/usenet/comments/1h6cfzs/can_any_article_be_missed)
 - RSS feed: $source
 - date published: 2024-12-04T09:47:51+00:00

<!-- SC_OFF --><div class="md"><p>I have paid subscription of DS, Geek, althub, Finder, NC, and dog. Providers I have are NH and easynews. Is there any chance of missing any article? Even 1% chance of missing any article? If yes then what are your suggestions? What should I add more, specially in indexers?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SteveJohn44"> /u/SteveJohn44 </a> <br/> <span><a href="https://www.reddit.com/r/usenet/comments/1h6cfzs/can_any_article_be_missed/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/usenet/comments/1h6cfzs/can_any_article_be_missed/">[comments]</a></span>

