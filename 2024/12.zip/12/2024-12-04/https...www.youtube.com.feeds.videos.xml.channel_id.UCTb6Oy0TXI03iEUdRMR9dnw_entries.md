# Source:Stuff You Should Know, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTb6Oy0TXI03iEUdRMR9dnw, language:en

## Selects: Star Wars Holiday Spectacular | STUFF YOU SHOULD KNOW
 - [https://www.youtube.com/watch?v=pV_XcTaFjIo](https://www.youtube.com/watch?v=pV_XcTaFjIo)
 - RSS feed: $source
 - date published: 2024-12-04T17:29:33+00:00

🛎  If You're New Subscribe ► https://bit.ly/SYSKSubscribe

Selects: Star Wars Holiday Spectacular | STUFF YOU SHOULD KNOW

Long ago, in a galaxy not so far away, George Lucas allowed the Star Wars Holiday Special to be made. What happened on the night of November 17, 1978 can never be fully explained, but we make our best effort in our annual special edition of SYSK. May the force be with us all.

Original Air Date: November 30, 2024

❤️ iHeartRadio » https://ihr.fm/3DyBDna
📢 APPLE PODCASTS » https://apple.co/3SKFZMe
📢 AMAZON MUSIC » https://amzn.to/3WgBVq1
🟢 SPOTIFY » https://spoti.fi/3zvX3ij
🎥 PREVIOUS VIDEO » https://youtu.be/eUYKBGNSdnQ
📕 GRAB YOUR COPY of Stuff You Should Read » https://bit.ly/3N9DuSm

✨ KEEP IN TOUCH WITH :
FACEBOOK » https://bit.ly/3DeXKxB
TWITTER » https://bit.ly/3NbH9PM
INSTAGRAM » https://bit.ly/3N9rosu
GOOGLE+ » https://bit.ly/3TJW6v0

If you've ever wanted to know about champagne, satanism, the Stonewall Uprising, chaos theory, LSD, El Nino, true crime an

## Solipsism: This Is All In My Mind? | STUFF YOU SHOULD KNOW
 - [https://www.youtube.com/watch?v=eUYKBGNSdnQ](https://www.youtube.com/watch?v=eUYKBGNSdnQ)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:42+00:00

🛎  If You're New Subscribe ► https://bit.ly/SYSKSubscribe

Solipsism: This Is All In My Mind? | STUFF YOU SHOULD KNOW

As the philosophical holds, there’s a chance you don’t exist, that not only you, but this episode, the podcast, and the entire universe are only projections of Josh or Chuck’s mind. If so, then recording this episode was a waste of time. 

Original Air Date: December 3, 2024

❤️ iHeartRadio » https://ihr.fm/3DyBDna
📢 APPLE PODCASTS » https://apple.co/3SKFZMe
📢 AMAZON MUSIC » https://amzn.to/3WgBVq1
🟢 SPOTIFY » https://spoti.fi/3zvX3ij
🎥 PREVIOUS VIDEO » https://youtu.be/LirWwzKzw80
📕 GRAB YOUR COPY of Stuff You Should Read » https://bit.ly/3N9DuSm

✨ KEEP IN TOUCH WITH :
FACEBOOK » https://bit.ly/3DeXKxB
TWITTER » https://bit.ly/3NbH9PM
INSTAGRAM » https://bit.ly/3N9rosu
GOOGLE+ » https://bit.ly/3TJW6v0

If you've ever wanted to know about champagne, satanism, the Stonewall Uprising, chaos theory, LSD, El Nino, true crime and Rosa Parks, then look no further. Josh an

