# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## UnitedHealthcare CEO shot dead in ambush in New York
 - [https://japantoday.com/category/world/man-killed-in-a-shooting-outside-a-new-york-city-hotel](https://japantoday.com/category/world/man-killed-in-a-shooting-outside-a-new-york-city-hotel)
 - RSS feed: $source
 - date published: 2024-12-04T23:06:56+00:00

UnitedHealthcare's CEO was shot and killed Wednesday in a “brazen, targeted attack” outside a Manhattan hotel where the health insurer was holding its investor conference, police said, setting…

## JR East eyes hike in starting fare in 2026
 - [https://japantoday.com/category/business/JR-East-eyes-hike-in-starting-fare-in-2026](https://japantoday.com/category/business/JR-East-eyes-hike-in-starting-fare-in-2026)
 - RSS feed: $source
 - date published: 2024-12-04T21:45:40+00:00

The operator of Tokyo's busy Yamanote loop line and other train routes is considering hiking the starting fare by 10 yen from the current 150 yen in March…

## Hyundai Motor union plans strikes on Thursday and Friday
 - [https://japantoday.com/category/business/hyundai-motor-union-plans-strikes-on-thursday-and-friday](https://japantoday.com/category/business/hyundai-motor-union-plans-strikes-on-thursday-and-friday)
 - RSS feed: $source
 - date published: 2024-12-04T21:41:36+00:00

Hyundai Motor's labour union plans to stage strikes for four hours each on Thursday and Friday, a union spokesperson said on Wednesday.
South Korea's Metal Workers' Union, of…

## 'Anora,' 'I Saw the TV Glow' lead Spirit Award nominations
 - [https://japantoday.com/category/entertainment/%27anora-%27-%27i-saw-the-tv-glow%27-lead-spirit-award-nominations](https://japantoday.com/category/entertainment/%27anora-%27-%27i-saw-the-tv-glow%27-lead-spirit-award-nominations)
 - RSS feed: $source
 - date published: 2024-12-04T21:41:08+00:00

“Anora,” Sean Baker’s odyssey of a New York stripper, and Jane Schoenbrun’s psychological horror “I Saw the TV Glow” dominated nominations for the Film Independent Spirit Awards with…

## Spotify Wrapped 2024 is here, and Taylor Swift is once again the platform's most-streamed artist
 - [https://japantoday.com/category/entertainment/spotify-wrapped-2024-is-here-and-taylor-swift-is-once-again-the-platform%27s-most-streamed-artist](https://japantoday.com/category/entertainment/spotify-wrapped-2024-is-here-and-taylor-swift-is-once-again-the-platform%27s-most-streamed-artist)
 - RSS feed: $source
 - date published: 2024-12-04T21:40:50+00:00

'Tis the season to unpack Spotify Wrapped. And it should come as no surprise that for a second year in a row, Taylor Swift has been named its…

## Lewis Hamilton faces an emotional end to 'amazing' Mercedes journey before joining Ferrari in F1
 - [https://japantoday.com/category/sports/lewis-hamilton-faces-an-emotional-end-to-%27amazing%27-mercedes-journey-before-joining-ferrari-in-f1](https://japantoday.com/category/sports/lewis-hamilton-faces-an-emotional-end-to-%27amazing%27-mercedes-journey-before-joining-ferrari-in-f1)
 - RSS feed: $source
 - date published: 2024-12-04T21:40:30+00:00

Lewis Hamilton is looking back on an “amazing journey” and the most successful partnership in Formula 1 history as he prepares to bid farewell to Mercedes this week…

## Japan's Premier League pioneer Inamoto retires at 45
 - [https://japantoday.com/category/sports/japan%27s-premier-league-pioneer-inamoto-retires-aged-45](https://japantoday.com/category/sports/japan%27s-premier-league-pioneer-inamoto-retires-aged-45)
 - RSS feed: $source
 - date published: 2024-12-04T21:40:20+00:00

Junichi Inamoto announced his retirement aged 45 on Wednesday, ending a career that saw the midfielder become the first Japanese player to appear in the Premier League.
Inamoto…

## FIFA to reveal Club World Cup draw amid apathy, legal threats
 - [https://japantoday.com/category/sports/fifa-to-reveal-club-world-cup-draw-amid-apathy-legal-threats](https://japantoday.com/category/sports/fifa-to-reveal-club-world-cup-draw-amid-apathy-legal-threats)
 - RSS feed: $source
 - date published: 2024-12-04T21:40:08+00:00

The draw for the expanded FIFA Club World Cup takes place in Miami on Thursday, offering a first glimpse into the fine detail of a tournament that has…

## Does Shohei Ohtani still owe his manager Dave Roberts a new Porsche?
 - [https://japantoday.com/category/sports/does-shohei-ohtani-still-owe-his-manager-dave-roberts-a-new-porsche](https://japantoday.com/category/sports/does-shohei-ohtani-still-owe-his-manager-dave-roberts-a-new-porsche)
 - RSS feed: $source
 - date published: 2024-12-04T21:39:54+00:00

Hey Shohei Ohtani, where is the fancy Porsche you hinted at giving your manager Dave Roberts if the Los Angeles Dodgers won the World Series?
Well, the Dodgers…

## Sumo wrestlers bring 1,500 years of tradition to London
 - [https://japantoday.com/category/sports/sumo-wrestlers-bring-1-500-years-of-tradition-to-london](https://japantoday.com/category/sports/sumo-wrestlers-bring-1-500-years-of-tradition-to-london)
 - RSS feed: $source
 - date published: 2024-12-04T21:39:43+00:00

London’s Royal Albert Hall, the gilded concert venue known for an annual “Rule Britannia” singalong, is preparing to host a different kind of spectacle: Sumo wrestling.
Camera shutters…

## Japan sake-brewing added to UNESCO intangible heritage
 - [https://japantoday.com/category/national/japan-sake-brewing-added-to-unesco-intangible-heritage](https://japantoday.com/category/national/japan-sake-brewing-added-to-unesco-intangible-heritage)
 - RSS feed: $source
 - date published: 2024-12-04T21:39:00+00:00

Traditional Japanese knowledge and skills used in the production of sake and shochu distilled spirits were approved on Wednesday for addition to UNESCO's Intangible Cultural Heritage list, a…

## Japan, Sweden agree to upgrade ties to strategic partnership
 - [https://japantoday.com/category/politics/update1-japan-sweden-leaders-agree-to-upgrade-ties-to-strategic-partnership](https://japantoday.com/category/politics/update1-japan-sweden-leaders-agree-to-upgrade-ties-to-strategic-partnership)
 - RSS feed: $source
 - date published: 2024-12-04T21:38:28+00:00

Japan and Sweden agreed Wednesday to deepen cooperation in areas ranging from the economy to security by elevating bilateral ties to a &quot;strategic partnership&quot; at the first summit…

## Head of influential Japan opposition party suspended over extramarital affair
 - [https://japantoday.com/category/politics/head-of-influential-japan-opposition-party-suspended-over-affair](https://japantoday.com/category/politics/head-of-influential-japan-opposition-party-suspended-over-affair)
 - RSS feed: $source
 - date published: 2024-12-04T21:38:20+00:00

A small but increasingly influential Japanese opposition party decided Wednesday to suspend its leader, Yuichiro Tamaki, for three months following a media report about an extramarital affair.
Tamaki…

## Japanese court convicts Australian who says she was tricked into smuggling drugs
 - [https://japantoday.com/category/crime/japanese-court-convicts-australian-who-says-she-was-tricked-into-smuggling-drugs](https://japantoday.com/category/crime/japanese-court-convicts-australian-who-says-she-was-tricked-into-smuggling-drugs)
 - RSS feed: $source
 - date published: 2024-12-04T21:37:42+00:00

A Japanese court on Wednesday sentenced an Australian woman to six years in prison for smuggling amphetamines into the country, despite accepting her testimony that she was tricked…

## Disaster contingency plans lagging to assist Tokyo's foreign visitors
 - [https://japantoday.com/category/features/kuchikomi/disaster-contingency-plans-lagging-to-assist-tokyo%27s-foreign-visitors](https://japantoday.com/category/features/kuchikomi/disaster-contingency-plans-lagging-to-assist-tokyo%27s-foreign-visitors)
 - RSS feed: $source
 - date published: 2024-12-04T21:36:08+00:00

With the waning of the COVID-19 pandemic, foreign tourists have been converging on Japan with a vengeance. Since visits to Japan have been made even more affordable thanks to the…

## Armed ethnic rebels in northeast Myanmar declare ceasefire and seek talks with military government
 - [https://japantoday.com/category/world/armed-ethnic-rebels-in-northeast-myanmar-declare-ceasefire-and-seek-talks-with-military-government](https://japantoday.com/category/world/armed-ethnic-rebels-in-northeast-myanmar-declare-ceasefire-and-seek-talks-with-military-government)
 - RSS feed: $source
 - date published: 2024-12-04T21:35:46+00:00

A major ethnic rebel group in Myanmar has announced a unilateral ceasefire in its conflict with the ruling military and called for a dialogue under Chinese auspices to…

## Georgian opposition leader detained by police and beaten unconscious, his party says
 - [https://japantoday.com/category/world/georgian-opposition-leader-detained-by-police-and-beaten-unconscious-his-party-says](https://japantoday.com/category/world/georgian-opposition-leader-detained-by-police-and-beaten-unconscious-his-party-says)
 - RSS feed: $source
 - date published: 2024-12-04T21:35:39+00:00

The leader of one of Georgia's four main opposition parties has been detained by police after being beaten unconscious in the capital Tbilisi, his party said on Wednesday,…

## Trump picks Musk ally Jared Isaacman to head NASA
 - [https://japantoday.com/category/world/trump-picks-musk-ally-jared-isaacman-to-head-nasa2](https://japantoday.com/category/world/trump-picks-musk-ally-jared-isaacman-to-head-nasa2)
 - RSS feed: $source
 - date published: 2024-12-04T21:35:31+00:00

U.S. President-elect Donald Trump on Wednesday tapped Jared Isaacman to lead NASA, selecting a billionaire private astronaut and business associate of Elon Musk to oversee an agency closely…

## Controversial presidential front-runner Calin Georgescu wants Romania to be 'self-sufficient power'
 - [https://japantoday.com/category/world/controversial-presidential-front-runner-calin-georgescu-wants-romania-to-be-%27self-sufficient-power%27](https://japantoday.com/category/world/controversial-presidential-front-runner-calin-georgescu-wants-romania-to-be-%27self-sufficient-power%27)
 - RSS feed: $source
 - date published: 2024-12-04T21:35:24+00:00

Sitting at his desk in an isolated compound north of Bucharest, presidential front-runner and far-right populist Calin Georgescu says Romania’s Western alliances remain secure providing they “serve the…

## Syrian army fights rebel offensive with counterattack
 - [https://japantoday.com/category/world/syrian-army-launches-counteroffensive-against-rebels](https://japantoday.com/category/world/syrian-army-launches-counteroffensive-against-rebels)
 - RSS feed: $source
 - date published: 2024-12-04T21:35:16+00:00

Syrian government forces pressed a counterattack against Islamist-led rebels around the key city of Hama on Wednesday after suffering a string of staggering losses further north, a war…

## UK dismantles massive money laundering operations tied to Russian oligarchs and cybercriminals
 - [https://japantoday.com/category/world/uk-dismantles-massive-money-laundering-operations-tied-to-russian-oligarchs-and-cybercriminals](https://japantoday.com/category/world/uk-dismantles-massive-money-laundering-operations-tied-to-russian-oligarchs-and-cybercriminals)
 - RSS feed: $source
 - date published: 2024-12-04T21:35:08+00:00

British authorities have dismantled two massive money laundering operations linked to Russia that were used by oligarchs, organized crime groups, cybercriminals and drug dealers, the National Crime Agency…

## NATO chief urges European allies to ramp up defense spending as Trump returns to White House
 - [https://japantoday.com/category/world/nato-chief-urges-european-allies-to-ramp-up-defense-spending-as-trump-returns-to-white-house](https://japantoday.com/category/world/nato-chief-urges-european-allies-to-ramp-up-defense-spending-as-trump-returns-to-white-house)
 - RSS feed: $source
 - date published: 2024-12-04T21:34:57+00:00

NATO Secretary-General Mark Rutte led a fresh push Wednesday for European countries to ramp up defense spending, a budget shortfall that President-elect Donald Trump used to berate U.S.…

## South Korean ruling party to oppose Yoon's impeachment
 - [https://japantoday.com/category/world/south-korean-ruling-party-to-oppose-yoon%27s-impeachment2](https://japantoday.com/category/world/south-korean-ruling-party-to-oppose-yoon%27s-impeachment2)
 - RSS feed: $source
 - date published: 2024-12-04T21:34:49+00:00

South Korea's parliament formally introduced a motion on Thursday to impeach President Yoon Suk Yeol over a botched attempt to impose martial law, but his party vowed to oppose…

## Israeli strikes on Gaza tent camp kill at least 21 people, hospital says
 - [https://japantoday.com/category/world/israeli-strikes-on-a-gaza-tent-camp-kill-at-least-21-people-hospital-says](https://japantoday.com/category/world/israeli-strikes-on-a-gaza-tent-camp-kill-at-least-21-people-hospital-says)
 - RSS feed: $source
 - date published: 2024-12-04T21:34:37+00:00

Israeli aircraft struck a sprawling tent camp housing displaced Palestinians in Gaza on Wednesday, killing at least 21 people, according to a local health official, setting off fires…

## Trump considers DeSantis for Pentagon with Hegseth under pressure over allegations
 - [https://japantoday.com/category/world/trump-considers-desantis-for-the-pentagon-with-hegseth-under-pressure-over-a-series-of-allegations](https://japantoday.com/category/world/trump-considers-desantis-for-the-pentagon-with-hegseth-under-pressure-over-a-series-of-allegations)
 - RSS feed: $source
 - date published: 2024-12-04T21:34:19+00:00

Pete Hegseth, Donald Trump's Pentagon pick, was fighting to hold on to his Cabinet nomination amid growing questions Wednesday about his personal conduct as the president-elect's team considers…

## French government collapses after no-confidence vote, deepening political crisis
 - [https://japantoday.com/category/world/french-government-felled-in-no-confidence-vote-deepening-political-crisis](https://japantoday.com/category/world/french-government-felled-in-no-confidence-vote-deepening-political-crisis)
 - RSS feed: $source
 - date published: 2024-12-04T21:34:05+00:00

French opposition lawmakers brought the government down on Wednesday, throwing the European Union's second-biggest economic power deeper into a political crisis that threatens its capacity to legislate and…

## UK bans daytime TV ads for cereals, muffins and burgers
 - [https://japantoday.com/category/features/food/uk-bans-daytime-tv-ads-for-cereals-muffins-and-burgers](https://japantoday.com/category/features/food/uk-bans-daytime-tv-ads-for-cereals-muffins-and-burgers)
 - RSS feed: $source
 - date published: 2024-12-04T21:29:17+00:00

The UK government is banning daytime TV adverts for sugary foods like granola and muffins in its battle against child obesity, branding such popular items as junk food.…

## U.S. senators set to grill officials from 5 airlines over fees for seats and checked bags
 - [https://japantoday.com/category/features/travel/us-senators-are-set-to-grill-officials-from-5-airlines-over-fees-for-seats-and-checked-bags](https://japantoday.com/category/features/travel/us-senators-are-set-to-grill-officials-from-5-airlines-over-fees-for-seats-and-checked-bags)
 - RSS feed: $source
 - date published: 2024-12-04T21:28:54+00:00

A U.S. Senate panel planned to take aim at airline executives Wednesday for the carriers' growing use of fees for early boarding, better seats and other comforts that…

## Trump's plan for Ukraine comes into focus: Territorial concessions but NATO off the table
 - [https://japantoday.com/category/world/trump%27s-plan-for-ukraine-comes-into-focus-territorial-concessions-but-nato-off-the-table](https://japantoday.com/category/world/trump%27s-plan-for-ukraine-comes-into-focus-territorial-concessions-but-nato-off-the-table)
 - RSS feed: $source
 - date published: 2024-12-04T10:10:37+00:00

Advisers to Donald Trump publicly and privately are floating proposals to end the Ukraine war that would cede large parts of the country to Russia for the foreseeable…

## Asian stocks slide after South Korea's political drama
 - [https://japantoday.com/category/business/stock-market-today-asian-stocks-slide-after-south-korea%27s-political-drama-but-kospi-falls-only-2](https://japantoday.com/category/business/stock-market-today-asian-stocks-slide-after-south-korea%27s-political-drama-but-kospi-falls-only-2)
 - RSS feed: $source
 - date published: 2024-12-04T07:44:50+00:00

Asian markets retreated Wednesday after overnight political drama in South Korea added to regional uncertainties, though the Kospi in Seoul fell less than 2%.
U.S. futures and oil…

## Two delivery men assaulted in Sagamihara; suspects on the run
 - [https://japantoday.com/category/crime/two-delivery-men-assaulted-in-sagamihara-suspects-on-the-run](https://japantoday.com/category/crime/two-delivery-men-assaulted-in-sagamihara-suspects-on-the-run)
 - RSS feed: $source
 - date published: 2024-12-04T07:35:51+00:00

Police in Sagamihara, Kanagawa Prefecture, are searching for two men who assaulted two delivery men in separate incidents on Tuesday.
The first incident occurred just before 11 p.m.,…

## Japan watching South Korean situation with grave concern
 - [https://japantoday.com/category/politics/update1-japan-watching-s.-korean-situation-with-grave-concern](https://japantoday.com/category/politics/update1-japan-watching-s.-korean-situation-with-grave-concern)
 - RSS feed: $source
 - date published: 2024-12-04T07:33:17+00:00

Japan said Wednesday it will closely monitor the evolving situation in South Korea to determine its implications on bilateral ties, after the overnight chaos wrought by the temporary…

## Djokovic to begin bid for 25th Grand Slam crown in Brisbane
 - [https://japantoday.com/category/sports/djokovic-to-begin-bid-for-25th-grand-slam-crown-in-brisbane](https://japantoday.com/category/sports/djokovic-to-begin-bid-for-25th-grand-slam-crown-in-brisbane)
 - RSS feed: $source
 - date published: 2024-12-04T04:31:09+00:00

Novak Djokovic will begin his 2025 season and bid for an 11th Australian Open title at the Brisbane International, it was announced Wednesday, with the Serbian superstar now…

## South Korean lawmakers call to impeach President Yoon after back-track on martial law
 - [https://japantoday.com/category/world/south-korean-lawmakers-call-to-impeach-president-yoon-after-back-track-on-martial-law1](https://japantoday.com/category/world/south-korean-lawmakers-call-to-impeach-president-yoon-after-back-track-on-martial-law1)
 - RSS feed: $source
 - date published: 2024-12-04T04:26:18+00:00

South Korean lawmakers on Wednesday called for the impeachment of President Yoon Suk Yeol after he declared martial law only to reverse the move hours later, triggering the…

## Trump and Republican senators plan agenda for first 30 days
 - [https://japantoday.com/category/world/trump-and-republican-senators-plan-agenda-for-first-30-days](https://japantoday.com/category/world/trump-and-republican-senators-plan-agenda-for-first-30-days)
 - RSS feed: $source
 - date published: 2024-12-04T02:59:50+00:00

President-elect Donald Trump dialed in to what was described as a “love fest” Tuesday with Senate Republicans as they begin laying the groundwork for control of government in…

## Van Nistelrooy off to winning start at Leicester; Palace beat Ipswich
 - [https://japantoday.com/category/sports/van-nistelrooy-off-to-winning-start-at-leicester-palace-beat-ipswich](https://japantoday.com/category/sports/van-nistelrooy-off-to-winning-start-at-leicester-palace-beat-ipswich)
 - RSS feed: $source
 - date published: 2024-12-04T00:43:19+00:00

Ruud van Nistelrooy savoured his first match in charge of Leicester with a 3-1 Premier League win over West Ham, while Crystal Palace edged Ipswich 1-0 on Tuesday.…

