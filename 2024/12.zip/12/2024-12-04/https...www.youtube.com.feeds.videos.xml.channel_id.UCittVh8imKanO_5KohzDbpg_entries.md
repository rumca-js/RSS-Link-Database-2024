# Source:Paul Joseph Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg, language:en-US

## A Stunning Change of Mind
 - [https://www.youtube.com/watch?v=rg9q8ZFNoVk](https://www.youtube.com/watch?v=rg9q8ZFNoVk)
 - RSS feed: $source
 - date published: 2024-12-04T22:05:01+00:00

Please subscribe to the channel for more: https://www.youtube.com/PrisonPlanetLive?sub_confirmation=1

## Woke Women Are Sterilizing Themselves
 - [https://www.youtube.com/watch?v=EgwpAcyvrOk](https://www.youtube.com/watch?v=EgwpAcyvrOk)
 - RSS feed: $source
 - date published: 2024-12-04T18:41:14+00:00

FULL VIDEO: https://www.youtube.com/watch?v=QYzWI58AKDA

Please subscribe to the channel for more: https://www.youtube.com/PrisonPlanetLive?sub_confirmation=1

