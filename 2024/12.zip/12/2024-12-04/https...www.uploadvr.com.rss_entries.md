# Source:UploadVR, URL:https://www.uploadvr.com/rss, language:en

##  Shattered Hands-On: How Badly Do You Want To Get Out? 
 - [https://www.uploadvr.com/shattered-mixed-reality-escape-room-impressions](https://www.uploadvr.com/shattered-mixed-reality-escape-room-impressions)
 - RSS feed: $source
 - date published: 2024-12-04T09:00:41+00:00

 Shattered delivers a compelling mixed reality escape room seasoned with light mystery, and it&#39;s out today on Quest 3. 

##  Xreal One Has Built-In 3DoF Tracking &amp; A Wider Field Of View 
 - [https://www.uploadvr.com/xreal-one-announcement-preorders](https://www.uploadvr.com/xreal-one-announcement-preorders)
 - RSS feed: $source
 - date published: 2024-12-04T07:01:23+00:00

 The new Xreal One series bring built-in 3DoF tracking and a wider field of view to transparent virtual display glasses. 

##  My First Gran Turismo Is A Free-To-Play Racer Reaching PlayStation VR2 This Week 
 - [https://www.uploadvr.com/my-first-gran-turismo-playstation-vr2](https://www.uploadvr.com/my-first-gran-turismo-playstation-vr2)
 - RSS feed: $source
 - date published: 2024-12-04T06:51:02+00:00

 My First Gran Turismo is a new free-to-play racing game heading for PlayStation VR2 this week. 

##  PlayStation VR2 Seemingly Now Has Controller-Free Hand Tracking 
 - [https://www.uploadvr.com/playstation-vr2-controller-free-hand-tracking-siggraph-asia](https://www.uploadvr.com/playstation-vr2-controller-free-hand-tracking-siggraph-asia)
 - RSS feed: $source
 - date published: 2024-12-04T05:43:26+00:00

 Sony is demoing PlayStation VR2 hand tracking at SIGGRAPH Asia, and the booth suggests developers can already start using it in games. 

##  Quest 3S Now Shows On The Steam Hardware Survey, But There&#x27;s A Catch 
 - [https://www.uploadvr.com/quest-3s-now-shows-on-steam-hardware-survey-november-2024](https://www.uploadvr.com/quest-3s-now-shows-on-steam-hardware-survey-november-2024)
 - RSS feed: $source
 - date published: 2024-12-04T04:53:46+00:00

 Valve just updated the Steam Hardware Survey to list Quest 3S - but only from Steam Link. 

