# Source:Brodie Robertson | Linux Tips & Tricks on Odysee, URL:https://odysee.com/$/rss/@BrodieRobertson:5, language:en

## I Was Right About KDE
 - [https://odysee.com/i-was-right-about-kde:c8183324e82055dc5c36a7e922d9452900ffe98a](https://odysee.com/i-was-right-about-kde:c8183324e82055dc5c36a7e922d9452900ffe98a)
 - RSS feed: $source
 - date published: 2024-12-04T20:00:03+00:00

<p><img src="https://thumbnails.lbry.com/5vivHquoiAc" width="480" alt="thumbnail" title="I Was Right About KDE" /></p>I said it before and I'll keep saying that the FOSS world has a lot of money in it, the issue is people have absolutely no idea how to ask for money relying on social media campaigns, not reaching out to people with audiences, and not doing direct calls to action where the users are.<br /><br />==========Support The Channel==========<br />► Patreon: https://brodierobertson.xyz/patreon<br />► Paypal: https://brodierobertson.xyz/paypal<br />► Liberapay: https://brodierobertson.xyz/liberapay<br />► Amazon USA: https://brodierobertson.xyz/amazonusa<br /><br />==========Resources==========<br />Thunderbird Report: https://blog.thunderbird.net/2023/05/thunderbird-is-thriving-our-2022-financial-report/<br />Thunderbird Financials: https://stats.thunderbird.net/#financials<br />KDE MR: https://invent.kde.org/plasma/plasma-workspace/-/merge_requests/4490<br />KDE Donations: ht

