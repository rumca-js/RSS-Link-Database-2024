# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## An Advent Calendar for Books Entering the Public Domain in 2024
 - [https://bookriot.com/an-advent-calendar-for-books-entering-the-public-domain-in-2024](https://bookriot.com/an-advent-calendar-for-books-entering-the-public-domain-in-2024)
 - RSS feed: $source
 - date published: 2024-12-04T18:34:10+00:00

Books entering the public domain in 2025, The New Yorker's Essential Books of 2024, and more of the day's book news. 

## HayMarket Books Runs Books Not Bars Fundraiser for the Holidays
 - [https://bookriot.com/haymarket-books-runs-books-not-bars-fundraiser-for-the-holidays](https://bookriot.com/haymarket-books-runs-books-not-bars-fundraiser-for-the-holidays)
 - RSS feed: $source
 - date published: 2024-12-04T15:47:05+00:00

Every little bit helps! 

## Podcasts, Adaptations, And Top Mysteries, Oh My!
 - [https://bookriot.com/podcasts-adaptations-and-top-mysteries](https://bookriot.com/podcasts-adaptations-and-top-mysteries)
 - RSS feed: $source
 - date published: 2024-12-04T14:30:00+00:00

What was your favorite mystery show, audiobook, or podcast this year?

## A Must-Read Book on Ways to Make the World More Accessible for All
 - [https://bookriot.com/the-anti-ableist-manifesto-by-tiffany-yu](https://bookriot.com/the-anti-ableist-manifesto-by-tiffany-yu)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:00+00:00

"Her TED Talk, 'How to Help Employees with Disabilities Thrive', has over one million views. But I first came across her work on TikTok where she is the creator of the Anti-Ableism series."

## Cozy Up With December’s New Historical Fiction Releases
 - [https://bookriot.com/decembers-new-historical-fiction-releases](https://bookriot.com/decembers-new-historical-fiction-releases)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:00+00:00

Which historical fiction books are you most excited for this month?

## Book Riot’s Deal of the Day for December 4, 2024
 - [https://bookriot.com/book-riots-deal-of-the-day-for-december-4-2024](https://bookriot.com/book-riots-deal-of-the-day-for-december-4-2024)
 - RSS feed: $source
 - date published: 2024-12-04T13:30:00+00:00

Bowling nerds, an ocean folktale, a technicolor space opera, and more of today's best book deals

## New YA Book Releases This Week, December 4, 2024
 - [https://bookriot.com/new-ya-book-releases-this-week-december-4-2024](https://bookriot.com/new-ya-book-releases-this-week-december-4-2024)
 - RSS feed: $source
 - date published: 2024-12-04T13:30:00+00:00

This week's new YA releases include family secrets, a nod to Zora Neale Hurston, a queer gothic romance, and more. 

## Is BookTok Past Its Peak?
 - [https://bookriot.com/is-booktok-past-its-peak](https://bookriot.com/is-booktok-past-its-peak)
 - RSS feed: $source
 - date published: 2024-12-04T13:00:00+00:00

What do you think of BookTok's status in the book world?

## 10 New Nonfiction Book Releases of December
 - [https://bookriot.com/new-nonfiction-book-releases-of-december](https://bookriot.com/new-nonfiction-book-releases-of-december)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:00+00:00

Which nonfiction release are you most excited about this month?

## The Most Wonderful New Comics and Graphic Novels of December
 - [https://bookriot.com/new-comics-and-graphic-novels-of-december](https://bookriot.com/new-comics-and-graphic-novels-of-december)
 - RSS feed: $source
 - date published: 2024-12-04T12:00:00+00:00

Which comics and graphic novels are you most looking forward to this month?

## 8 Queer Romance Comics
 - [https://bookriot.com/queer-romance-comics](https://bookriot.com/queer-romance-comics)
 - RSS feed: $source
 - date published: 2024-12-04T11:00:00+00:00

What are your favorite queer romance comics?

