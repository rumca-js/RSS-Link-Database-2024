# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Deepfake YouTube Ads of Celebrities Promise to Get You ‘Rock Hard’
 - [https://www.404media.co/deepfake-youtube-ads-of-celebrities-promise-to-get-you-rock-hard](https://www.404media.co/deepfake-youtube-ads-of-celebrities-promise-to-get-you-rock-hard)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:31+00:00

Deepfakes of Arnold Schwarzenegger, Sylvester Stallone, Mike Tyson, and Terry Crews are selling erectile dysfunction supplements on YouTube. 

## Podcast: Your Bluesky Posts Are Probably Training AI
 - [https://www.404media.co/podcast-your-bluesky-posts-are-probably-training-ai](https://www.404media.co/podcast-your-bluesky-posts-are-probably-training-ai)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:07+00:00

We talk about the big datasets of Bluesky posts being offered to AI; how people are breaking into Redbox systems; and how the U.S. government is clamping down on data brokers.

