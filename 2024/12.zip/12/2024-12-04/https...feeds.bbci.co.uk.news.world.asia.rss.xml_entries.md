# Source:BBC Asia News, URL:https://feeds.bbci.co.uk/news/world/asia/rss.xml, language:en-gb

## Top Chinese language novelist dies in apparent suicide
 - [https://www.bbc.com/news/articles/cq624qj2ln9o](https://www.bbc.com/news/articles/cq624qj2ln9o)
 - RSS feed: $source
 - date published: 2024-12-04T10:29:43+00:00

Chiung Yao's work has been adapted to movies and TV and launched the careers of big name stars.

## Filipino vessel 'sideswiped' by China Coast Guard
 - [https://www.bbc.com/news/articles/c4gp46dm49yo](https://www.bbc.com/news/articles/c4gp46dm49yo)
 - RSS feed: $source
 - date published: 2024-12-04T09:49:29+00:00

The incident happened near the disputed Scarborough Shoal and Beijing said it acted "in accordance with the law". 

## The South Korean president's martial law gamble backfired: What was he thinking? 
 - [https://www.bbc.com/news/articles/c5y7jxe88w3o](https://www.bbc.com/news/articles/c5y7jxe88w3o)
 - RSS feed: $source
 - date published: 2024-12-04T08:46:52+00:00

Yoon's shock move was a bid to get the kind of grip on power that has eluded him since he was elected.

## S Korea opposition files motion to impeach Yoon
 - [https://www.bbc.com/news/articles/c8rjd064012o](https://www.bbc.com/news/articles/c8rjd064012o)
 - RSS feed: $source
 - date published: 2024-12-04T05:50:24+00:00

The country faces an uncertain future after its leader Yoon Suk Yeol suddenly declared and reversed martial law.

## 'Deeply disturbed': South Koreans react to President Yoon's martial law order
 - [https://www.bbc.com/news/videos/c0q0z5qvwywo](https://www.bbc.com/news/videos/c0q0z5qvwywo)
 - RSS feed: $source
 - date published: 2024-12-04T05:00:25+00:00

People in Seoul express anxiety and confusion following the president's now-rescinded martial law order.

## India-Bangladesh tensions soar amid protests
 - [https://www.bbc.com/news/articles/ceql54yxy89o](https://www.bbc.com/news/articles/ceql54yxy89o)
 - RSS feed: $source
 - date published: 2024-12-04T01:45:33+00:00

Ties between once-close neighbours nosedived after a recent attack on a Bangladeshi consulate in India.

