# Source:The Dave Cullen Show, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg, language:en-US

## Laughably Cringe Movie
 - [https://www.youtube.com/watch?v=KKYtpviqyi8](https://www.youtube.com/watch?v=KKYtpviqyi8)
 - RSS feed: $source
 - date published: 2024-12-04T13:40:41+00:00

Buy Deus v Machina eBook: https://www.amazon.com/dp/B0DNKMSD96 
Paperback: https://www.amazon.com/Deus-Machina-Cody-Stockton-Mystery/dp/1399995782 
Amazon UK: https://www.amazon.co.uk/Deus-Machina-Cody-Stockton-Mystery-ebook/dp/B0DNKMSD96 

Tip me: https://www.subscribestar.com/dave-cullen/tip
Support my Work on Paychute: https://www.paychute.com/c/davecullenshow
Subscribestar: https://www.subscribestar.com/dave-cullen

Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

KEEP UP ON SOCIAL MEDIA:
https://gab.com/DaveCullen
Minds.com: https://www.minds.com/davecullen
Subscribe on Odysee: https://odysee.com/@TheDaveCullenShow:7

