# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 RIDICULOUS Game Theories That Are Clearly TRUE
 - [https://www.youtube.com/watch?v=KB6n8NM3lCg](https://www.youtube.com/watch?v=KB6n8NM3lCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-08-04T15:00:46+00:00

Sometimes the simplest explanation is not entirely true.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1     

0:00 Intro 
0:42 Number 10
2:24 Number 9
4:50 Number 8
6:30 Number 7
8:09 Number 6
10:20 Number 5
12:08 Number 4
13:39 Number 3
15:05 Number 2
17:16 Number 1

