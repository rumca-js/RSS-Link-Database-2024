# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Baldur's Gate 3 was so big that Larian has developed a 'Simpsons did it' problem: 'Whenever we're talking about things, we say we did that in BG3'
 - [https://www.pcgamer.com/games/baldurs-gate/baldurs-gate-3-was-so-big-that-larian-has-developed-a-simpsons-did-it-problem-whenever-were-talking-about-things-we-say-we-did-that-in-bg3](https://www.pcgamer.com/games/baldurs-gate/baldurs-gate-3-was-so-big-that-larian-has-developed-a-simpsons-did-it-problem-whenever-were-talking-about-things-we-say-we-did-that-in-bg3)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-04T13:00:45+00:00

With two more RPGs in the pipeline, it wants to avoid repetition.

## Crafting in crafting games may suck, but it seems surprisingly decent in the updated rules for Dungeons & Dragons of all things
 - [https://www.pcgamer.com/games/rpg/crafting-in-crafting-games-may-suck-but-it-seems-surprisingly-decent-in-the-updated-rules-for-dungeons-and-dragons-of-all-things](https://www.pcgamer.com/games/rpg/crafting-in-crafting-games-may-suck-but-it-seems-surprisingly-decent-in-the-updated-rules-for-dungeons-and-dragons-of-all-things)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-04T05:01:59+00:00

I've got a +3 in punching trees.

## Elden Ring's latest patch tried to sneak a big 'ole chair into a boss arena like we wouldn't notice and immediately ponder the lore implications
 - [https://www.pcgamer.com/games/rpg/elden-rings-latest-patch-tried-to-sneak-a-big-ole-chair-into-boss-arena-like-we-wouldnt-notice-and-immediately-ponder-the-lore-implications](https://www.pcgamer.com/games/rpg/elden-rings-latest-patch-tried-to-sneak-a-big-ole-chair-into-boss-arena-like-we-wouldnt-notice-and-immediately-ponder-the-lore-implications)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-04T03:33:37+00:00

What does the chair mean? And why now?

## Today's Wordle answer for Sunday, August 4
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-august-4-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-august-4-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-04T03:00:09+00:00

A hint to help you out and today's Wordle answer if you need it.

## Don't expect Dragon Age: The Veilguard before October at the absolute earliest
 - [https://www.pcgamer.com/games/rpg/dont-expect-dragon-age-the-veilguard-before-october-at-the-absolute-earliest](https://www.pcgamer.com/games/rpg/dont-expect-dragon-age-the-veilguard-before-october-at-the-absolute-earliest)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-04T00:12:38+00:00

Time to fill September up with other games.

