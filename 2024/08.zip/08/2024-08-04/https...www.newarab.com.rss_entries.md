# Source:The New Arab, URL:https://www.newarab.com/rss, language:en

## Starmer: Far-right rioters will 'regret' worst disorder in years
 - [https://www.newarab.com/news/starmer-far-right-rioters-will-regret-worst-disorder-years](https://www.newarab.com/news/starmer-far-right-rioters-will-regret-worst-disorder-years)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T16:57:20+00:00

UK Prime Minister Keir Starmer strongly condemned an attack Sunday on a hotel housing asylum seekers, describing it as “far-right thuggery".

## Algerian teen Nemour makes history with uneven bars Olympic gold
 - [https://www.newarab.com/news/algerian-teen-nemour-makes-history-uneven-bars-olympic-gold-0](https://www.newarab.com/news/algerian-teen-nemour-makes-history-uneven-bars-olympic-gold-0)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T16:51:46+00:00

17-year-old Kaylia Nemour has become the first African to win a gold medal on uneven bars at the Olympics

## UK police arrest over 100 as far-right riots grip the country
 - [https://www.newarab.com/news/uk-police-arrest-over-100-far-right-riots-grip-country](https://www.newarab.com/news/uk-police-arrest-over-100-far-right-riots-grip-country)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T16:22:06+00:00

UK police have arrested at least 116 people across the country this weekend, as far-right riots fuelled by misinformation continue and spread

## Egyptian authorities arrest former government official
 - [https://www.newarab.com/news/egyptian-authorities-arrest-former-government-official](https://www.newarab.com/news/egyptian-authorities-arrest-former-government-official)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T15:54:42+00:00

Yehia Hussein Abdel Hady was arrested by plainclothes security personnel while he was in a car, and has been handed a 15-day detention.

## Sudan paramilitaries shell besieged Darfur city, killing 23: activists
 - [https://www.newarab.com/news/sudan-paramilitaries-shell-besieged-darfur-city-killing-23-activists-0](https://www.newarab.com/news/sudan-paramilitaries-shell-besieged-darfur-city-killing-23-activists-0)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T15:19:38+00:00

Shelling by Sudanese paramilitary forces resulted in the deaths of at least 23 people on Saturday in the besieged city of El-Fasher in Darfur.

## Bangladesh protesters demand PM resign as death toll mounts
 - [https://www.newarab.com/news/bangladesh-protesters-demand-pm-resign-death-toll-mounts](https://www.newarab.com/news/bangladesh-protesters-demand-pm-resign-death-toll-mounts)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T13:57:08+00:00

The death toll from clashes between Bangladeshi protesters demanding Prime Minister Sheikh Hasina resign and pro-government supporters has risen to at least 50.

## Biden 'lashes out at Netanyahu' over captive and ceasefire deal
 - [https://www.newarab.com/news/biden-lashes-out-netanyahu-over-captive-and-ceasefire-deal](https://www.newarab.com/news/biden-lashes-out-netanyahu-over-captive-and-ceasefire-deal)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T13:23:48+00:00

The heated phone conversation came after Hamas leader Ismail Haniyeh was killed in Iran, pushing a ceasefire deal further away.

## Kamala Harris wins backing of key Muslim group over Gaza stance
 - [https://www.newarab.com/news/kamala-harris-wins-backing-key-muslim-group-over-gaza-stance](https://www.newarab.com/news/kamala-harris-wins-backing-key-muslim-group-over-gaza-stance)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T12:17:44+00:00

A key US organisation, which is part of the Black Muslim Leadership Council NGO, has endorsed Harris over her stance on Israel’s war on Gaza.

## Israel strike kills 17 at school compound: Gaza officials
 - [https://www.newarab.com/news/israel-strike-kills-17-school-compound-gaza-officials](https://www.newarab.com/news/israel-strike-kills-17-school-compound-gaza-officials)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T11:41:21+00:00

Israeli strikes early Sunday killed 17 people in Gaza, including four who were sheltering in a tent camp for displaced Palestinians inside a hospital complex.

## Gaza prisoners describe 'horrific' abuse in Israel's Ofer jail
 - [https://www.newarab.com/news/gaza-prisoners-describe-horrific-abuse-israels-ofer-jail](https://www.newarab.com/news/gaza-prisoners-describe-horrific-abuse-israels-ofer-jail)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T11:23:52+00:00

Palestinian prisoners have been beaten and tortured at Israel's Ofer prison with attack dogs and tear gas used on them in their cells.

## Two dead in Israel stabbing, assailant killed: medics
 - [https://www.newarab.com/news/two-dead-israel-stabbing-assailant-killed-medics](https://www.newarab.com/news/two-dead-israel-stabbing-assailant-killed-medics)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T09:47:06+00:00

Two people were killed and two others wounded in a stabbing attack in central Israel, with the assailant later dying after being shot.

## Israel kills 25 in attack on school; 2 dead in Tel Aviv stabbing
 - [https://www.newarab.com/news/israel-kills-25-attack-school-2-dead-tel-aviv-stabbing](https://www.newarab.com/news/israel-kills-25-attack-school-2-dead-tel-aviv-stabbing)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T09:11:22+00:00

Dozens of people were killed in an Israeli strike on schools in the Gaza Strip on Sunday, while two Israelis were killed in a stabbing attack near Tel Aviv

## Israel kills dozens at Gaza school; 2 dead in Tel Aviv stabbing
 - [https://www.newarab.com/news/israel-kills-dozens-gaza-school-2-dead-tel-aviv-stabbing](https://www.newarab.com/news/israel-kills-dozens-gaza-school-2-dead-tel-aviv-stabbing)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-04T09:11:22+00:00

Dozens of people were killed in an Israeli strike on a school in the Gaza Strip on Saturday, while two Israelis were killed in a stabbing attack near Tel Aviv

