# Source:Android Authority, URL:https://www.androidauthority.com/feed, language:en-US

## How much energy does ChatGPT consume? More than you think, but it’s not all bad news
 - [https://www.androidauthority.com/chatgpt-energy-consumption-3466882](https://www.androidauthority.com/chatgpt-energy-consumption-3466882)
 - RSS feed: https://www.androidauthority.com/feed
 - date published: 2024-08-04T17:00:54+00:00

AI requires a lot of electricity, but is that really such a bad thing?

## AI summaries in Apple Mail put Gmail to absolute shame
 - [https://www.androidauthority.com/ai-summaries-apple-mail-feature-3466934](https://www.androidauthority.com/ai-summaries-apple-mail-feature-3466934)
 - RSS feed: https://www.androidauthority.com/feed
 - date published: 2024-08-04T15:00:22+00:00

Apple Intelligence now reads my emails so I don’t have to.

## Two years on, the Pixel Buds Pro have aged like fine wine
 - [https://www.androidauthority.com/pixel-buds-pro-two-years-updates-3465178](https://www.androidauthority.com/pixel-buds-pro-two-years-updates-3465178)
 - RSS feed: https://www.androidauthority.com/feed
 - date published: 2024-08-04T13:00:27+00:00

The Pixel Buds Pro deserves more praise than it gets.

## New leak suggests Apple could launch two (!) foldables in 2026
 - [https://www.androidauthority.com/apple-two-foldables-2026-3467724](https://www.androidauthority.com/apple-two-foldables-2026-3467724)
 - RSS feed: https://www.androidauthority.com/feed
 - date published: 2024-08-04T04:49:34+00:00

It looks like Apple could offer two distinct foldable devices in 2026.

