# Source:Reddit - Front Page, URL:https://www.reddit.com/.rss, language:en-US

## Najbardziej depresyjne miasta w PL?
 - [https://www.reddit.com/r/Polska/comments/1ek39gq/najbardziej_depresyjne_miasta_w_pl](https://www.reddit.com/r/Polska/comments/1ek39gq/najbardziej_depresyjne_miasta_w_pl)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T19:14:01+00:00

<!-- SC_OFF --><div class="md"><p>Jak w tytule - milo będzie, jeśli przykłady podacie z uzasadnieniem.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bluedabad"> /u/bluedabad </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ek39gq/najbardziej_depresyjne_miasta_w_pl/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ek39gq/najbardziej_depresyjne_miasta_w_pl/">[comments]</a></span>

## Deep
 - [https://www.reddit.com/r/funny/comments/1ek1w34/deep](https://www.reddit.com/r/funny/comments/1ek1w34/deep)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T18:17:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/funny/comments/1ek1w34/deep/"> <img alt="Deep " src="https://external-preview.redd.it/MjhwcGVxY2J2b2dkMaa_1TbP5UvXVdp1N0KYcJSWMHHUBQ9zKpD-akWwQtWu.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=2a058885f8d8b903aff7526ed20269f45741c008" title="Deep " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ActivityCreative1121"> /u/ActivityCreative1121 </a> &#32; to &#32; <a href="https://www.reddit.com/r/funny/"> r/funny </a> <br /> <span><a href="https://v.redd.it/bqn7fzbbvogd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/funny/comments/1ek1w34/deep/">[comments]</a></span> </td></tr></table>

## Guys, need advice on who should I use for this picture?
 - [https://www.reddit.com/r/Genshin_Impact/comments/1ek1l9p/guys_need_advice_on_who_should_i_use_for_this](https://www.reddit.com/r/Genshin_Impact/comments/1ek1l9p/guys_need_advice_on_who_should_i_use_for_this)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T18:04:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Genshin_Impact/comments/1ek1l9p/guys_need_advice_on_who_should_i_use_for_this/"> <img alt="Guys, need advice on who should I use for this picture?" src="https://preview.redd.it/ksqfuioysogd1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=c7be41ee693fa97e491eac65687093d994b9a772" title="Guys, need advice on who should I use for this picture?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/noctora"> /u/noctora </a> &#32; to &#32; <a href="https://www.reddit.com/r/Genshin_Impact/"> r/Genshin_Impact </a> <br /> <span><a href="https://i.redd.it/ksqfuioysogd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Genshin_Impact/comments/1ek1l9p/guys_need_advice_on_who_should_i_use_for_this/">[comments]</a></span> </td></tr></table>

## Goodbye world. It's been... real.
 - [https://www.reddit.com/r/wallstreetbets/comments/1ek0oxg/goodbye_world_its_been_real](https://www.reddit.com/r/wallstreetbets/comments/1ek0oxg/goodbye_world_its_been_real)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T17:27:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/wallstreetbets/comments/1ek0oxg/goodbye_world_its_been_real/"> <img alt="Goodbye world. It's been... real. " src="https://preview.redd.it/yhu5betgmogd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9a9c963bacfc357b8b935644b25ee54d5de9d971" title="Goodbye world. It's been... real. " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>What an absolute and total failure.<br /> Go fucking figure the market collapses when I go all in one last time. So long everybody🫡</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ACOUSTIDELIC36"> /u/ACOUSTIDELIC36 </a> &#32; to &#32; <a href="https://www.reddit.com/r/wallstreetbets/"> r/wallstreetbets </a> <br /> <span><a href="https://i.redd.it/yhu5betgmogd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/wallstreetbets/comments/1ek0oxg/goodbye_world_its_been_real/">[comments]</a></span> </td></tr></table>

## Sweden's Truls Möregårdh pulls off a snake shot in table tennis at the Olympics final
 - [https://www.reddit.com/r/Damnthatsinteresting/comments/1ek0m8x/swedens_truls_möregårdh_pulls_off_a_snake_shot_in](https://www.reddit.com/r/Damnthatsinteresting/comments/1ek0m8x/swedens_truls_möregårdh_pulls_off_a_snake_shot_in)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T17:24:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1ek0m8x/swedens_truls_möregårdh_pulls_off_a_snake_shot_in/"> <img alt="Sweden's Truls Möregårdh pulls off a snake shot in table tennis at the Olympics final" src="https://external-preview.redd.it/ZWp1ZjV5eHVsb2dkMYSiz-lJ3ZLTFvXKVXp9i08bE90NKyAdNB7_8hXkId6V.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=b044a8814e35f06881b3c78d8c11a9d1a605ea7f" title="Sweden's Truls Möregårdh pulls off a snake shot in table tennis at the Olympics final" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mountain-of-Snow"> /u/Mountain-of-Snow </a> &#32; to &#32; <a href="https://www.reddit.com/r/Damnthatsinteresting/"> r/Damnthatsinteresting </a> <br /> <span><a href="https://v.redd.it/q1aw9xxulogd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1ek0m8x/swedens_truls_möregårdh_pulls_off_a_snake_shot_in/">[comments]</a></span> </td></tr></table>

## I dont think any Championship is worth this much abuse.
 - [https://www.reddit.com/r/formuladank/comments/1ejzs3w/i_dont_think_any_championship_is_worth_this_much](https://www.reddit.com/r/formuladank/comments/1ejzs3w/i_dont_think_any_championship_is_worth_this_much)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T16:49:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/formuladank/comments/1ejzs3w/i_dont_think_any_championship_is_worth_this_much/"> <img alt="I dont think any Championship is worth this much abuse. " src="https://external-preview.redd.it/eGZwc3k3bmpmb2dkMWX7BwpzzUkHeJmI-_SaeltEIZklGodlXVCGXnQAtqA4.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=58af5608f9bf23c3ee7d1acc75cbee596198628b" title="I dont think any Championship is worth this much abuse. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sexnandosexlonso"> /u/sexnandosexlonso </a> &#32; to &#32; <a href="https://www.reddit.com/r/formuladank/"> r/formuladank </a> <br /> <span><a href="https://v.redd.it/a46g66jlfogd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/formuladank/comments/1ejzs3w/i_dont_think_any_championship_is_worth_this_much/">[comments]</a></span> </td></tr></table>

## (NSFW) Reddit, what was your “Oh shit, this person is a psychopath” moment when meeting people?
 - [https://www.reddit.com/r/AskReddit/comments/1ejzgf2/nsfw_reddit_what_was_your_oh_shit_this_person_is](https://www.reddit.com/r/AskReddit/comments/1ejzgf2/nsfw_reddit_what_was_your_oh_shit_this_person_is)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T16:35:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Ok_Sample_1624"> /u/Ok_Sample_1624 </a> &#32; to &#32; <a href="https://www.reddit.com/r/AskReddit/"> r/AskReddit </a> <br /> <span><a href="https://www.reddit.com/r/AskReddit/comments/1ejzgf2/nsfw_reddit_what_was_your_oh_shit_this_person_is/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/AskReddit/comments/1ejzgf2/nsfw_reddit_what_was_your_oh_shit_this_person_is/">[comments]</a></span>

## Uzależnienie, hazard, zjazd psychiczny
 - [https://www.reddit.com/r/Polska/comments/1ejzbnb/uzależnienie_hazard_zjazd_psychiczny](https://www.reddit.com/r/Polska/comments/1ejzbnb/uzależnienie_hazard_zjazd_psychiczny)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T16:30:06+00:00

<!-- SC_OFF --><div class="md"><p>Cześć, od około 5 lat zacząłem obstawiać różne mecze piłki nożnej, ale też hokeja, piłki ręcznej, siatkówki lub koszykówki, jednak moim głównym tematem są mecze piłki nożnej. W tym czasie wygrałem 26 tysięcy złotych a przegrałem 54 tysiące. </p> <p>Ostatnie pół roku to pasmo praktycznie samych porażek, stawiam kupony za różne stawki przeważnie od 30 - 200 złotych, gram codziennie, czasami kilka razy dziennie, jeżeli jeden kupon nie wejdzie, stawiam kolejny, czasami jest ich kilka w ciągu jednego dnia. </p> <p>Zrobiłem się agresywny, nadpobudliwy, i jednocześnie depresyjny, nie mogę przeżyć tego że przegrałem tyle pieniędzy, chce zrobić ciągle wszystko żeby to odegrać, wygrać kilka razy, odzyskać to co straciłem i przestać grać, ale cały czas przegrywam, trafię jeden kupon ale 10 kolejnych jest przegranych, czasami wydaje mi się że ciąży nade mną jakieś fatum. </p> <p>Siada mi głowa, wiem że gdybym odzyskał to co straciłem to przestałbym grać, ale nie 

## Belgian triathlete hospitalized for 4 days after swimming in the Seine, Belgian mixed triathlon relay team withdraws from the event
 - [https://www.reddit.com/r/europe/comments/1ejz8fx/belgian_triathlete_hospitalized_for_4_days_after](https://www.reddit.com/r/europe/comments/1ejz8fx/belgian_triathlete_hospitalized_for_4_days_after)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T16:26:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1ejz8fx/belgian_triathlete_hospitalized_for_4_days_after/"> <img alt="Belgian triathlete hospitalized for 4 days after swimming in the Seine, Belgian mixed triathlon relay team withdraws from the event" src="https://external-preview.redd.it/KJM4ArV21C_zla2ecYFCBKttFxe8YAkzkJ2sVLbWX1s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=27237f83ee10dd2e1a15d3a2db0a31ebea2e9416" title="Belgian triathlete hospitalized for 4 days after swimming in the Seine, Belgian mixed triathlon relay team withdraws from the event" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BelgianPolitics"> /u/BelgianPolitics </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br /> <span><a href="https://www.rtl.be/sport/tous-les-sports/jo-2024/jo-2024-une-triathlete-belge-hospitalisee-apres-sa-baignade-dans-la-seine/2024-08-04/article/697340">[link]</a></span> &#32; <span><a href="https://ww

## [request] how much extra propulsion does she get with the fake nails?
 - [https://www.reddit.com/r/theydidthemath/comments/1ejyx52/request_how_much_extra_propulsion_does_she_get](https://www.reddit.com/r/theydidthemath/comments/1ejyx52/request_how_much_extra_propulsion_does_she_get)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T16:12:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/theydidthemath/comments/1ejyx52/request_how_much_extra_propulsion_does_she_get/"> <img alt="[request] how much extra propulsion does she get with the fake nails? " src="https://preview.redd.it/u1gn9py49ogd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=04462863676978044a4889e42aa4ed52db703d89" title="[request] how much extra propulsion does she get with the fake nails? " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/redditor-16"> /u/redditor-16 </a> &#32; to &#32; <a href="https://www.reddit.com/r/theydidthemath/"> r/theydidthemath </a> <br /> <span><a href="https://i.redd.it/u1gn9py49ogd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/theydidthemath/comments/1ejyx52/request_how_much_extra_propulsion_does_she_get/">[comments]</a></span> </td></tr></table>

## My friend was able to hack into a billboard ad and played the ULTRAKILL trailer.
 - [https://www.reddit.com/r/Ultrakill/comments/1ejyfd4/my_friend_was_able_to_hack_into_a_billboard_ad](https://www.reddit.com/r/Ultrakill/comments/1ejyfd4/my_friend_was_able_to_hack_into_a_billboard_ad)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T15:52:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Ultrakill/comments/1ejyfd4/my_friend_was_able_to_hack_into_a_billboard_ad/"> <img alt="My friend was able to hack into a billboard ad and played the ULTRAKILL trailer." src="https://external-preview.redd.it/cWZxdzNqbGM1b2dkMYKh0l8zJQYtpls2TLCBKjWrQ35D-C9Sbnwk3YKp1OPs.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=4b97874f6f4e6f85513344118e4834c656fb7b97" title="My friend was able to hack into a billboard ad and played the ULTRAKILL trailer." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rude-Knowledge-6444"> /u/Rude-Knowledge-6444 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Ultrakill/"> r/Ultrakill </a> <br /> <span><a href="https://v.redd.it/lw7y64oc5ogd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Ultrakill/comments/1ejyfd4/my_friend_was_able_to_hack_into_a_billboard_ad/">[comments]</a></span> </td></tr></table>

## Nie doceniamy unii! 🇪🇺
 - [https://www.reddit.com/r/Polska/comments/1ejy71v/nie_doceniamy_unii](https://www.reddit.com/r/Polska/comments/1ejy71v/nie_doceniamy_unii)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T15:42:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ejy71v/nie_doceniamy_unii/"> <img alt="Nie doceniamy unii! 🇪🇺" src="https://preview.redd.it/fekduwrm3ogd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=63270797966bffdf19ba40151e3efbfab52ce54b" title="Nie doceniamy unii! 🇪🇺" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Piszę to z wakacji w Gruzji, wszystko super, kocham ten kraj itp itd nie o to chodzi. </p> <p>Nie doceniamy tego, że po wylądowaniu samolotem nie czeka się godzinę w kolejce aby pan spojrzał na ciebie z każdej strony, wbił pieczątkę i idziesz dalej</p> <p>Nie doceniamy nowych korków, po wróceniu tutaj do tych zwykłych, są denerwujące, zajmują dwie ręce żeby się napić. zdecydowanie wolę te które zostają w butelce. </p> <p>Nie doceniamy strefy Schengen i nie czekanie na wjazd do państwa.</p> <p>Nie doceniamy standardów bezpieczeństwa w pojazdach, tutaj ktoś po prostu wymontował pasy z taxi, a jakiś facet jeździł z łysą oponą (gładka jak papier)

## F-16s are flying over Ukraine
 - [https://www.reddit.com/r/interestingasfuck/comments/1ejxpmj/f16s_are_flying_over_ukraine](https://www.reddit.com/r/interestingasfuck/comments/1ejxpmj/f16s_are_flying_over_ukraine)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T15:21:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/interestingasfuck/comments/1ejxpmj/f16s_are_flying_over_ukraine/"> <img alt="F-16s are flying over Ukraine" src="https://external-preview.redd.it/ZWx2bm5kbXd6bmdkMS_vcYqf6DhUmSD5LY52X0s7LLpgxJr4mfhIXrxjQ7_u.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c13f8174fc058ab73dc2e15835e9552d4b893ba5" title="F-16s are flying over Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TotalSpaceNut"> /u/TotalSpaceNut </a> &#32; to &#32; <a href="https://www.reddit.com/r/interestingasfuck/"> r/interestingasfuck </a> <br /> <span><a href="https://v.redd.it/stcyjoauzngd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/interestingasfuck/comments/1ejxpmj/f16s_are_flying_over_ukraine/">[comments]</a></span> </td></tr></table>

## Olympics 2024 Gold Medal Match: N. Djokovic def. C. Alcaraz: 7-6(3), 7-6(2).
 - [https://www.reddit.com/r/tennis/comments/1ejx9ok/olympics_2024_gold_medal_match_n_djokovic_def_c](https://www.reddit.com/r/tennis/comments/1ejx9ok/olympics_2024_gold_medal_match_n_djokovic_def_c)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T15:01:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/tennis/comments/1ejx9ok/olympics_2024_gold_medal_match_n_djokovic_def_c/"> <img alt="Olympics 2024 Gold Medal Match: N. Djokovic def. C. Alcaraz: 7-6(3), 7-6(2)." src="https://preview.redd.it/6cfgstygwngd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cadcd99c15cab35f40871d0fc9927a380499c2a7" title="Olympics 2024 Gold Medal Match: N. Djokovic def. C. Alcaraz: 7-6(3), 7-6(2)." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>My, goodness! The mad lad has done it! 🥇GOLDovic! ✨</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/padfoony"> /u/padfoony </a> &#32; to &#32; <a href="https://www.reddit.com/r/tennis/"> r/tennis </a> <br /> <span><a href="https://i.redd.it/6cfgstygwngd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/tennis/comments/1ejx9ok/olympics_2024_gold_medal_match_n_djokovic_def_c/">[comments]</a></span> </td></tr></table>

## I want to taste his meat
 - [https://www.reddit.com/r/shitposting/comments/1ejvdli/i_want_to_taste_his_meat](https://www.reddit.com/r/shitposting/comments/1ejvdli/i_want_to_taste_his_meat)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T13:34:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shitposting/comments/1ejvdli/i_want_to_taste_his_meat/"> <img alt="I want to taste his meat" src="https://preview.redd.it/v9u4hohtgngd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=21c1773bf379d1c2d801cf9db2896bea3302390d" title="I want to taste his meat" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Finn_Supra"> /u/Finn_Supra </a> &#32; to &#32; <a href="https://www.reddit.com/r/shitposting/"> r/shitposting </a> <br /> <span><a href="https://i.redd.it/v9u4hohtgngd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/shitposting/comments/1ejvdli/i_want_to_taste_his_meat/">[comments]</a></span> </td></tr></table>

## not naming names but SOMEONE could easily kill his dumbass brother if he stopped being a fucking weeb
 - [https://www.reddit.com/r/whenthe/comments/1ejuwb7/not_naming_names_but_someone_could_easily_kill](https://www.reddit.com/r/whenthe/comments/1ejuwb7/not_naming_names_but_someone_could_easily_kill)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T13:10:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ejuwb7/not_naming_names_but_someone_could_easily_kill/"> <img alt="not naming names but SOMEONE could easily kill his dumbass brother if he stopped being a fucking weeb" src="https://preview.redd.it/yccypfdkcngd1.gif?width=320&amp;crop=smart&amp;s=a4c06871b9687596c6b9365c152ef255ce4fa186" title="not naming names but SOMEONE could easily kill his dumbass brother if he stopped being a fucking weeb" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/brianamargret"> /u/brianamargret </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://i.redd.it/yccypfdkcngd1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ejuwb7/not_naming_names_but_someone_could_easily_kill/">[comments]</a></span> </td></tr></table>

## why i dont like horror mods
 - [https://www.reddit.com/r/feedthebeast/comments/1ejuvsf/why_i_dont_like_horror_mods](https://www.reddit.com/r/feedthebeast/comments/1ejuvsf/why_i_dont_like_horror_mods)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T13:10:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/feedthebeast/comments/1ejuvsf/why_i_dont_like_horror_mods/"> <img alt="why i dont like horror mods" src="https://preview.redd.it/aq4oiktpbngd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=6be587dea82115105c1a58d623894037c265d69f" title="why i dont like horror mods" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/thaboar"> /u/thaboar </a> &#32; to &#32; <a href="https://www.reddit.com/r/feedthebeast/"> r/feedthebeast </a> <br /> <span><a href="https://i.redd.it/aq4oiktpbngd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/feedthebeast/comments/1ejuvsf/why_i_dont_like_horror_mods/">[comments]</a></span> </td></tr></table>

## Text between me and my dads girlfriend during a panic attack.
 - [https://www.reddit.com/r/mildlyinfuriating/comments/1ejutpk/text_between_me_and_my_dads_girlfriend_during_a](https://www.reddit.com/r/mildlyinfuriating/comments/1ejutpk/text_between_me_and_my_dads_girlfriend_during_a)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T13:07:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinfuriating/comments/1ejutpk/text_between_me_and_my_dads_girlfriend_during_a/"> <img alt="Text between me and my dads girlfriend during a panic attack. " src="https://b.thumbs.redditmedia.com/W1UsJks9glb25Qf8-JyQ4dG6Ry0t4Aje6tlwyuB2wFc.jpg" title="Text between me and my dads girlfriend during a panic attack. " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Ive recently started taking sertraline because my mental health has gotten slightly worse recently. Often it’ll make things worse before they get better, and they’ve given me a bit more anxiety/ panic. I got on a train (about 2.5 hours with a change) to go to an appointment. Right as I was about to get on the train I started having a pretty bad panic attack. I’m diagnosed with panic disorder, so have propranolol’s to stop it, as a lot of my anxiety is physical and not at all mental. I take one, but while it kicks in I message a few people; my dad, my mum, my girlfriend an

## Blind Paralympic Athlete Lex Gillette’s custom Nike Goggles
 - [https://www.reddit.com/r/pics/comments/1ejugjd/blind_paralympic_athlete_lex_gillettes_custom](https://www.reddit.com/r/pics/comments/1ejugjd/blind_paralympic_athlete_lex_gillettes_custom)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T12:48:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pics/comments/1ejugjd/blind_paralympic_athlete_lex_gillettes_custom/"> <img alt="Blind Paralympic Athlete Lex Gillette’s custom Nike Goggles" src="https://preview.redd.it/87m4gbwo8ngd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e79fb10b07a31ca23b6a45b7651a53e5bfb331b8" title="Blind Paralympic Athlete Lex Gillette’s custom Nike Goggles" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Beneficial_Form8563"> /u/Beneficial_Form8563 </a> &#32; to &#32; <a href="https://www.reddit.com/r/pics/"> r/pics </a> <br /> <span><a href="https://i.redd.it/87m4gbwo8ngd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pics/comments/1ejugjd/blind_paralympic_athlete_lex_gillettes_custom/">[comments]</a></span> </td></tr></table>

## Jesteśmy zgubieni Polska betonowa rośnie, a reszta się zwija
 - [https://www.reddit.com/r/Polska/comments/1eju2hf/jesteśmy_zgubieni_polska_betonowa_rośnie_a_reszta](https://www.reddit.com/r/Polska/comments/1eju2hf/jesteśmy_zgubieni_polska_betonowa_rośnie_a_reszta)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T12:27:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1eju2hf/jesteśmy_zgubieni_polska_betonowa_rośnie_a_reszta/"> <img alt="Jesteśmy zgubieni Polska betonowa rośnie, a reszta się zwija" src="https://preview.redd.it/ce69rpkx4ngd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=851df4e55e3832a24811c0ae7e726a13f788c2ad" title="Jesteśmy zgubieni Polska betonowa rośnie, a reszta się zwija" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/szymon362"> /u/szymon362 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://i.redd.it/ce69rpkx4ngd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eju2hf/jesteśmy_zgubieni_polska_betonowa_rośnie_a_reszta/">[comments]</a></span> </td></tr></table>

## AITA for refusing to let my abusive ex-husband see our kids after he completed anger management therapy
 - [https://www.reddit.com/r/AITAH/comments/1ejtoc8/aita_for_refusing_to_let_my_abusive_exhusband_see](https://www.reddit.com/r/AITAH/comments/1ejtoc8/aita_for_refusing_to_let_my_abusive_exhusband_see)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T12:05:34+00:00

<!-- SC_OFF --><div class="md"><p>I (34F) was married to my ex-husband (36M) for ten years. Throughout our marriage, he was verbally, emotionally, and sometimes physically abusive. He controlled every aspect of my life, from who I could see to what I could wear. The abuse escalated after our children were born (8F and 5M). I stayed for years because I feared what he might do if I tried to leave and because I believed he might change.</p> <p>Last year, after a particularly violent incident, I found the courage to leave and file for divorce. The court granted me full custody of our children with supervised visitation for him. He was ordered to attend anger management therapy and parenting classes.</p> <p>Recently, he completed his therapy and is now demanding unsupervised visits with the kids. He claims he's a changed man and has even presented a letter from his therapist supporting his request. However, my children are still traumatized. My daughter has nightmares, and my son is terrif

## Countries with constitutions that mention Jews or Judaism
 - [https://www.reddit.com/r/MapPorn/comments/1ejtejr/countries_with_constitutions_that_mention_jews_or](https://www.reddit.com/r/MapPorn/comments/1ejtejr/countries_with_constitutions_that_mention_jews_or)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T11:50:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/MapPorn/comments/1ejtejr/countries_with_constitutions_that_mention_jews_or/"> <img alt="Countries with constitutions that mention Jews or Judaism" src="https://preview.redd.it/05n004a0eg6a1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=49a651a5ba3b5408c8f2708b8d7860f9e8eb7a58" title="Countries with constitutions that mention Jews or Judaism" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Front-Neighborhood"> /u/Front-Neighborhood </a> &#32; to &#32; <a href="https://www.reddit.com/r/MapPorn/"> r/MapPorn </a> <br /> <span><a href="https://i.redd.it/05n004a0eg6a1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/MapPorn/comments/1ejtejr/countries_with_constitutions_that_mention_jews_or/">[comments]</a></span> </td></tr></table>

## "Testy płci" w sporcie [komentarz] - Uwaga! Naukowy Bełkot
 - [https://www.reddit.com/r/Polska/comments/1ejsvdj/testy_płci_w_sporcie_komentarz_uwaga_naukowy](https://www.reddit.com/r/Polska/comments/1ejsvdj/testy_płci_w_sporcie_komentarz_uwaga_naukowy)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T11:16:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ejsvdj/testy_płci_w_sporcie_komentarz_uwaga_naukowy/"> <img alt="&quot;Testy płci&quot; w sporcie [komentarz] - Uwaga! Naukowy Bełkot" src="https://external-preview.redd.it/91p9hs_XCFCGeDMPTi_xyTwwOCMMkxRWIQvWIytiGL8.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=b1315743d6d4a7aea7a7bcdad17abfb917f00545" title="&quot;Testy płci&quot; w sporcie [komentarz] - Uwaga! Naukowy Bełkot" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheBronzeSilverfish"> /u/TheBronzeSilverfish </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.youtube.com/watch?v=k2prGs6gHRw">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ejsvdj/testy_płci_w_sporcie_komentarz_uwaga_naukowy/">[comments]</a></span> </td></tr></table>

## Dlaczego moje pranie nie pachnie niczym?
 - [https://www.reddit.com/r/Polska/comments/1ejst2n/dlaczego_moje_pranie_nie_pachnie_niczym](https://www.reddit.com/r/Polska/comments/1ejst2n/dlaczego_moje_pranie_nie_pachnie_niczym)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T11:12:51+00:00

<!-- SC_OFF --><div class="md"><p>Robię pranie tak jak zawsze, ale od kilku prań moje pranie po wyjęciu pachnie... niczym. Po prostu jak woda. Wlewam płyn do prania, który ma zapach, a pranie i tak nie pachnie. Kiedyś używałem płynów do płukania, ale swędziała mnie po nich skóra i przestałem. Długo po odstawieniu tych zmiękczaczy moje pranie pachniało jednak płynem do prania. Mam wrażenie, że może z jakiegoś powodu teraz pierze się samą wodą.</p> <p>Próbowałem szukać i wszystkie porady dotyczą sytuacji, gdy pranie śmierdzi i każą wtedy czyścić bęben. Ale nie znalazłem nic o tym, że pranie sprawia wrażenie wypranego samą wodą.</p> <p>Czy to możliwe, że detergent jakoś nie dociera do bębna?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bearinthetown"> /u/bearinthetown </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ejst2n/dlaczego_moje_pranie_nie_pachnie

## Polish parenting?
 - [https://www.reddit.com/r/poland/comments/1ejsscp/polish_parenting](https://www.reddit.com/r/poland/comments/1ejsscp/polish_parenting)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T11:11:30+00:00

<!-- SC_OFF --><div class="md"><p>I’m a parent living in Poland but not from here and I was wondering about parenting here and the culture of how to raise kids. </p> <p>For example, parents here a very protective of their children such as always telling them to not do something, or insinuating to their children that they shouldn’t try to do something, because they “can’t do it”, or will get themselves hurt. </p> <p>To my ears it often comes off as not believing in your kids, and basically imprinting this in children from a young age. </p> <p>Do any of you feel this having been raised by Polish parents, that you may lack self confidence due to your upbringing? </p> <p>As I’m not a native Polish person, I could be getting this all wrong and they may be communicating something different then what I think, so please do not take any offence to my question. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/phtoa1"> /u/phtoa1 </a> &#32; to &#32; <a href=

## We need to get back Lithuania in the V4 and call it the V5
 - [https://www.reddit.com/r/2visegrad4you/comments/1ejsr25/we_need_to_get_back_lithuania_in_the_v4_and_call](https://www.reddit.com/r/2visegrad4you/comments/1ejsr25/we_need_to_get_back_lithuania_in_the_v4_and_call)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T11:09:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/2visegrad4you/comments/1ejsr25/we_need_to_get_back_lithuania_in_the_v4_and_call/"> <img alt="We need to get back Lithuania in the V4 and call it the V5" src="https://preview.redd.it/bh84wm8zqmgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5b6e40b046ba23edb1f304bfa7d97ee8a54c2ee1" title="We need to get back Lithuania in the V4 and call it the V5" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IAmGniotek"> /u/IAmGniotek </a> &#32; to &#32; <a href="https://www.reddit.com/r/2visegrad4you/"> r/2visegrad4you </a> <br /> <span><a href="https://i.redd.it/bh84wm8zqmgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/2visegrad4you/comments/1ejsr25/we_need_to_get_back_lithuania_in_the_v4_and_call/">[comments]</a></span> </td></tr></table>

## Czy odczuwasz presję sukcesu/otoczenia
 - [https://www.reddit.com/r/Polska/comments/1ejsqe6/czy_odczuwasz_presję_sukcesuotoczenia](https://www.reddit.com/r/Polska/comments/1ejsqe6/czy_odczuwasz_presję_sukcesuotoczenia)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T11:08:06+00:00

<!-- SC_OFF --><div class="md"><p>Pytanie kieruję raczej do młodych osób w wieku 16-25 lat. </p> <p>Wśród niektórych znajomych widać taką wyraźną presję na osiąganie sukcesów. Co dzień musisz być lepszy, musisz pracować 12 godzin dziennie, studia przed 25 rokiem życia, zarabiać miliony przed 30 rokiem życia... Odmian takiego myślenia jest wiele ale wszystkie prowadzą raczej do presji która dalej powoduje dużo niepokoju i raczej niezadowolenia z życia bo skupiamy się na tym czego nie mamy a nie na tym co mamy </p> <p>Czy wy odczuwacie taką presję? Bardzo chciałbym się dowiedzieć. Słyszałem że w UK była ankieta i na podstawie 4 tysięcy opinii, 60 procent osób (18-25 lat) odczuwało taką presję.</p> <p>Podzielcie się swoimi doświadczeniami.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Infamous-Dig5589"> /u/Infamous-Dig5589 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/P

## ...
 - [https://www.reddit.com/r/subnautica/comments/1ejspgy/_](https://www.reddit.com/r/subnautica/comments/1ejspgy/_)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T11:06:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/subnautica/comments/1ejspgy/_/"> <img alt="..." src="https://preview.redd.it/yrpyjh7fqmgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c66433379cef34ff8a49a39d44e41eabc8289700" title="..." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Revolutionary-Key419"> /u/Revolutionary-Key419 </a> &#32; to &#32; <a href="https://www.reddit.com/r/subnautica/"> r/subnautica </a> <br /> <span><a href="https://i.redd.it/yrpyjh7fqmgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/subnautica/comments/1ejspgy/_/">[comments]</a></span> </td></tr></table>

## Nagonka w polskich mediach na osoby mieszkające z rodzicami (Gniazdownicy)
 - [https://www.reddit.com/r/Polska/comments/1ejsd3g/nagonka_w_polskich_mediach_na_osoby_mieszkające_z](https://www.reddit.com/r/Polska/comments/1ejsd3g/nagonka_w_polskich_mediach_na_osoby_mieszkające_z)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T10:44:08+00:00

<!-- SC_OFF --><div class="md"><p>Ostatnio w mediach w Polsce po wyjściu statystyk gusu o osobach mieszkających z rodzicami jest straszna nagonka na takie osoby. Nazywanie ich pejoratywnie gniazdownikami porównywanie do dorosłych dzieci itp. Wczoraj w polsacie w głównych wydarzeniach o 18:50 poświęcono nawet 3 minuty temu zjawisku gniazdownictwa. W samym materiale nawet nie wspomniano oczywistych powodów dlaczego ludzie mieszkają z rodzicami czyli wysokie ceny nieruchomości i najmu oraz niezwykle drogi kredyt. A pierwsza osoba w wywiadzie zapytana dlaczego dorośli mieszkają z rodzicami odpowiada że nie ma takiej odpowiedzi i wiele czynników składa się na to XDDD Następnie przedstawienia sytuacji z włoch gdzie sąd nakazał wyprowadzkę dwóch 40 letnich synów od 70 letniej matki i o rodzicach w Polsce którzy chodzą do psychologa, bo ich dzieci mieszkają z nimi w jednym domu. Co myślicie o tym? To na prawdę aż taka tragedia jest że ludzie mieszkają z rodzicami i trzeba po nich jeździć w me

## Boat driver accidentally steered the boat into tree branch and messed up Kim's hair
 - [https://www.reddit.com/r/interestingasfuck/comments/1ejsabj/boat_driver_accidentally_steered_the_boat_into](https://www.reddit.com/r/interestingasfuck/comments/1ejsabj/boat_driver_accidentally_steered_the_boat_into)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T10:38:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/interestingasfuck/comments/1ejsabj/boat_driver_accidentally_steered_the_boat_into/"> <img alt="Boat driver accidentally steered the boat into tree branch and messed up Kim's hair" src="https://external-preview.redd.it/ang3NmpzdWlsbWdkMS63sVVJrDU_W6MzJDrwwkViDIypcKEKocqLUZoHzhkl.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=d11ce2c40fe788aaa2a454f9e46d447c59fc96f6" title="Boat driver accidentally steered the boat into tree branch and messed up Kim's hair" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Overall_Agent_0075"> /u/Overall_Agent_0075 </a> &#32; to &#32; <a href="https://www.reddit.com/r/interestingasfuck/"> r/interestingasfuck </a> <br /> <span><a href="https://v.redd.it/4w53004jlmgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/interestingasfuck/comments/1ejsabj/boat_driver_accidentally_steered_the_boat_into/">[comments]</a></span> </td></tr></table>

## I hate her music and her fans
 - [https://www.reddit.com/r/whenthe/comments/1ejs319/i_hate_her_music_and_her_fans](https://www.reddit.com/r/whenthe/comments/1ejs319/i_hate_her_music_and_her_fans)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T10:24:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ejs319/i_hate_her_music_and_her_fans/"> <img alt="I hate her music and her fans " src="https://preview.redd.it/gk9a6n20jmgd1.gif?width=640&amp;crop=smart&amp;s=c46944db009b5236ae48558b9e4dbccb116eacf9" title="I hate her music and her fans " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Gl1tchyVirus"> /u/Gl1tchyVirus </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://i.redd.it/gk9a6n20jmgd1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ejs319/i_hate_her_music_and_her_fans/">[comments]</a></span> </td></tr></table>

## Swimming gold medalist Ceccon sleeping in the park. He criticised the lack of A/C inside the Village
 - [https://www.reddit.com/r/pics/comments/1ejrpyx/swimming_gold_medalist_ceccon_sleeping_in_the](https://www.reddit.com/r/pics/comments/1ejrpyx/swimming_gold_medalist_ceccon_sleeping_in_the)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T09:59:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pics/comments/1ejrpyx/swimming_gold_medalist_ceccon_sleeping_in_the/"> <img alt="Swimming gold medalist Ceccon sleeping in the park. He criticised the lack of A/C inside the Village" src="https://external-preview.redd.it/7QVKkV13ZbwjPFdkyeUThDH3-G3MZ-sszj_GwjGcJaw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=67fa4603702d208f507dd91c7d930a0d35997170" title="Swimming gold medalist Ceccon sleeping in the park. He criticised the lack of A/C inside the Village" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PreviouslyMannara"> /u/PreviouslyMannara </a> &#32; to &#32; <a href="https://www.reddit.com/r/pics/"> r/pics </a> <br /> <span><a href="https://static.open.online/wp-content/uploads/2024/08/thomas-ceccon-dorme-parco.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pics/comments/1ejrpyx/swimming_gold_medalist_ceccon_sleeping_in_the/">[comments]</a></span> </td></tr></table>

## Międzyzdroje świeca pustkami. Mieszkańcy mówią o katastrofie
 - [https://www.reddit.com/r/Polska/comments/1ejrf4o/międzyzdroje_świeca_pustkami_mieszkańcy_mówią_o](https://www.reddit.com/r/Polska/comments/1ejrf4o/międzyzdroje_świeca_pustkami_mieszkańcy_mówią_o)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T09:38:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ejrf4o/międzyzdroje_świeca_pustkami_mieszkańcy_mówią_o/"> <img alt="Międzyzdroje świeca pustkami. Mieszkańcy mówią o katastrofie" src="https://external-preview.redd.it/qJ7fsqIPyj0w6S8sRNVYM6BJYF6M7Nwrn-wooZYPVfI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b062de86b35a2fbca6984503b7cbb1b23eb9019b" title="Międzyzdroje świeca pustkami. Mieszkańcy mówią o katastrofie" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Gamebyter"> /u/Gamebyter </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://biznes.interia.pl/finanse/news-miedzyzdroje-swieca-pustkami-mieszkancy-mowia-o-katastrofie-,nId,7749232">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ejrf4o/międzyzdroje_świeca_pustkami_mieszkańcy_mówią_o/">[comments]</a></span> </td></tr></table>

## Kto byłby lepszym prezydentem: Kosiniak czy Kamysz?
 - [https://www.reddit.com/r/Polska/comments/1ejr4an/kto_byłby_lepszym_prezydentem_kosiniak_czy_kamysz](https://www.reddit.com/r/Polska/comments/1ejr4an/kto_byłby_lepszym_prezydentem_kosiniak_czy_kamysz)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T09:15:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ejr4an/kto_byłby_lepszym_prezydentem_kosiniak_czy_kamysz/"> <img alt="Kto byłby lepszym prezydentem: Kosiniak czy Kamysz?" src="https://preview.redd.it/to9y9gmr6mgd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c0d119edfc2fd1a705828dce56c8c14aee5ec2d0" title="Kto byłby lepszym prezydentem: Kosiniak czy Kamysz?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tukannntg"> /u/tukannntg </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://i.redd.it/to9y9gmr6mgd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ejr4an/kto_byłby_lepszym_prezydentem_kosiniak_czy_kamysz/">[comments]</a></span> </td></tr></table>

## The suburb of Budapest has built a luxurious kindergarten that suspiciously looks like a private residence - with €550K of EU money. It doesn't accept any children.
 - [https://www.reddit.com/r/europe/comments/1ejr4a8/the_suburb_of_budapest_has_built_a_luxurious](https://www.reddit.com/r/europe/comments/1ejr4a8/the_suburb_of_budapest_has_built_a_luxurious)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T09:15:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1ejr4a8/the_suburb_of_budapest_has_built_a_luxurious/"> <img alt="The suburb of Budapest has built a luxurious kindergarten that suspiciously looks like a private residence - with €550K of EU money. It doesn't accept any children. " src="https://b.thumbs.redditmedia.com/STtX2VksrDxBrJ3GKxa8plokLklu0HFfGHzwfERsRpk.jpg" title="The suburb of Budapest has built a luxurious kindergarten that suspiciously looks like a private residence - with €550K of EU money. It doesn't accept any children. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GPwat"> /u/GPwat </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejr4a8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1ejr4a8/the_suburb_of_budapest_has_built_a_luxurious/">[comments]</a></span> </td></tr></table>

## What's problem ?
 - [https://www.reddit.com/r/meme/comments/1ejqygc/whats_problem](https://www.reddit.com/r/meme/comments/1ejqygc/whats_problem)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T09:03:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/meme/comments/1ejqygc/whats_problem/"> <img alt="What's problem ?" src="https://preview.redd.it/km3nouja4mgd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a9437eae82bd7592b7faf6169c5d86608e7662cf" title="What's problem ?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CallMe__Molly"> /u/CallMe__Molly </a> &#32; to &#32; <a href="https://www.reddit.com/r/meme/"> r/meme </a> <br /> <span><a href="https://i.redd.it/km3nouja4mgd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/meme/comments/1ejqygc/whats_problem/">[comments]</a></span> </td></tr></table>

## Dude won a bronze medal but,
 - [https://www.reddit.com/r/interestingasfuck/comments/1ejqlo7/dude_won_a_bronze_medal_but](https://www.reddit.com/r/interestingasfuck/comments/1ejqlo7/dude_won_a_bronze_medal_but)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T08:38:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/interestingasfuck/comments/1ejqlo7/dude_won_a_bronze_medal_but/"> <img alt="Dude won a bronze medal but, " src="https://preview.redd.it/hz6t2o750mgd1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=b1de50490d21a8ee41bc17c8b64d5bb099374fcb" title="Dude won a bronze medal but, " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Reioussy"> /u/Reioussy </a> &#32; to &#32; <a href="https://www.reddit.com/r/interestingasfuck/"> r/interestingasfuck </a> <br /> <span><a href="https://i.redd.it/hz6t2o750mgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/interestingasfuck/comments/1ejqlo7/dude_won_a_bronze_medal_but/">[comments]</a></span> </td></tr></table>

## 9th Anniversary Servant - Ereshkigal / Space Ereshkigal (Beast Class SSR)
 - [https://www.reddit.com/r/grandorder/comments/1ejqetb/9th_anniversary_servant_ereshkigal_space](https://www.reddit.com/r/grandorder/comments/1ejqetb/9th_anniversary_servant_ereshkigal_space)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T08:25:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/grandorder/comments/1ejqetb/9th_anniversary_servant_ereshkigal_space/"> <img alt="9th Anniversary Servant - Ereshkigal / Space Ereshkigal (Beast Class SSR)" src="https://a.thumbs.redditmedia.com/e0KqZyCqOR7qpzHiUkw6IDjhDyeLDNPxokQlXJ_hfe8.jpg" title="9th Anniversary Servant - Ereshkigal / Space Ereshkigal (Beast Class SSR)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/crazywarriorxx"> /u/crazywarriorxx </a> &#32; to &#32; <a href="https://www.reddit.com/r/grandorder/"> r/grandorder </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejqetb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/grandorder/comments/1ejqetb/9th_anniversary_servant_ereshkigal_space/">[comments]</a></span> </td></tr></table>

## 9th Anniversary - New Append Skills
 - [https://www.reddit.com/r/grandorder/comments/1ejq8iq/9th_anniversary_new_append_skills](https://www.reddit.com/r/grandorder/comments/1ejq8iq/9th_anniversary_new_append_skills)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T08:12:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/grandorder/comments/1ejq8iq/9th_anniversary_new_append_skills/"> <img alt="9th Anniversary - New Append Skills" src="https://preview.redd.it/08l9m4cgvlgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cf235754bf35e3feebc91ce46e5fbc07e8e861fc" title="9th Anniversary - New Append Skills" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>A4 Increases Critical Damage by 20-30% A5 Lowers cooldown of skill after use by 1T (respective skill).</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/crazywarriorxx"> /u/crazywarriorxx </a> &#32; to &#32; <a href="https://www.reddit.com/r/grandorder/"> r/grandorder </a> <br /> <span><a href="https://i.redd.it/08l9m4cgvlgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/grandorder/comments/1ejq8iq/9th_anniversary_new_append_skills/">[comments]</a></span> </td></tr></table>

## Snap your fingers and make anyone alive president of the US. Who do you pick?
 - [https://www.reddit.com/r/AskReddit/comments/1ejq3hs/snap_your_fingers_and_make_anyone_alive_president](https://www.reddit.com/r/AskReddit/comments/1ejq3hs/snap_your_fingers_and_make_anyone_alive_president)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T08:02:34+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/CliffHutchinsonEsc"> /u/CliffHutchinsonEsc </a> &#32; to &#32; <a href="https://www.reddit.com/r/AskReddit/"> r/AskReddit </a> <br /> <span><a href="https://www.reddit.com/r/AskReddit/comments/1ejq3hs/snap_your_fingers_and_make_anyone_alive_president/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/AskReddit/comments/1ejq3hs/snap_your_fingers_and_make_anyone_alive_president/">[comments]</a></span>

## Rtx 5060 would be big mistake to nvidia with 8GB vram.
 - [https://www.reddit.com/r/pcmasterrace/comments/1ejpzxa/rtx_5060_would_be_big_mistake_to_nvidia_with_8gb](https://www.reddit.com/r/pcmasterrace/comments/1ejpzxa/rtx_5060_would_be_big_mistake_to_nvidia_with_8gb)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T07:56:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pcmasterrace/comments/1ejpzxa/rtx_5060_would_be_big_mistake_to_nvidia_with_8gb/"> <img alt="Rtx 5060 would be big mistake to nvidia with 8GB vram." src="https://preview.redd.it/uhykd8cjslgd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c3bb90908b0fba027d39abe5b4deb381fb432358" title="Rtx 5060 would be big mistake to nvidia with 8GB vram." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/According_Ratio2010"> /u/According_Ratio2010 </a> &#32; to &#32; <a href="https://www.reddit.com/r/pcmasterrace/"> r/pcmasterrace </a> <br /> <span><a href="https://i.redd.it/uhykd8cjslgd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pcmasterrace/comments/1ejpzxa/rtx_5060_would_be_big_mistake_to_nvidia_with_8gb/">[comments]</a></span> </td></tr></table>

## Are we sure that Mechamaru isn't actually Gojo's student?
 - [https://www.reddit.com/r/Jujutsufolk/comments/1ejpxia/are_we_sure_that_mechamaru_isnt_actually_gojos](https://www.reddit.com/r/Jujutsufolk/comments/1ejpxia/are_we_sure_that_mechamaru_isnt_actually_gojos)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T07:51:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Jujutsufolk/comments/1ejpxia/are_we_sure_that_mechamaru_isnt_actually_gojos/"> <img alt="Are we sure that Mechamaru isn't actually Gojo's student?" src="https://preview.redd.it/s5xzp16qrlgd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=153929d4ba7e36dca18e1e01d5483ed1af73a4ee" title="Are we sure that Mechamaru isn't actually Gojo's student?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Only a student who's been taught by Gojo would look at two special grades (granted he didn't know 'Geto' was Kenjaku, but at that point in time Geto was already a special grade so it still counts), acknowledge the fact that he's at a disadvantage and STILL go &quot;Yeah, I'd win&quot; while he himself is a semi-grade one.</p> <p>The sheer BALLER energy this man emitted in the Mahito fight is nothing short of a Tokyo sorcerer. My guy got enlisted in the wrong school.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit

## 💥
 - [https://www.reddit.com/r/shitposting/comments/1ejpxej/_](https://www.reddit.com/r/shitposting/comments/1ejpxej/_)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T07:51:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shitposting/comments/1ejpxej/_/"> <img alt="💥" src="https://preview.redd.it/xnvkedeprlgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ef9996fd1b4b27915f601ea830a05fe99232c855" title="💥" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/heisenbingus"> /u/heisenbingus </a> &#32; to &#32; <a href="https://www.reddit.com/r/shitposting/"> r/shitposting </a> <br /> <span><a href="https://i.redd.it/xnvkedeprlgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/shitposting/comments/1ejpxej/_/">[comments]</a></span> </td></tr></table>

## Dude is packing
 - [https://www.reddit.com/r/memes/comments/1ejpvmn/dude_is_packing](https://www.reddit.com/r/memes/comments/1ejpvmn/dude_is_packing)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T07:48:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/memes/comments/1ejpvmn/dude_is_packing/"> <img alt="Dude is packing" src="https://preview.redd.it/0m3zywi4rlgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cbbd9acd5cbd0771fd1491d9da69c61dd63f605c" title="Dude is packing" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Old_Goldie"> /u/Old_Goldie </a> &#32; to &#32; <a href="https://www.reddit.com/r/memes/"> r/memes </a> <br /> <span><a href="https://i.redd.it/0m3zywi4rlgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/memes/comments/1ejpvmn/dude_is_packing/">[comments]</a></span> </td></tr></table>

## KT Rolster vs. OK BRION / LCK 2024 Summer - Week 7 / Post Match Discussion
 - [https://www.reddit.com/r/leagueoflegends/comments/1ejpqq1/kt_rolster_vs_ok_brion_lck_2024_summer_week_7](https://www.reddit.com/r/leagueoflegends/comments/1ejpqq1/kt_rolster_vs_ok_brion_lck_2024_summer_week_7)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T07:39:35+00:00

<!-- SC_OFF --><div class="md"><h1>LCK 2024 SUMMER</h1> <p><a href="https://watch.lolesports.com/">Official page</a> | <a href="https://lol.fandom.com/wiki/LCK/2024_Season/Summer_Season">Leaguepedia</a> | <a href="https://liquipedia.net/leagueoflegends/LCK/2024/Summer">Liquipedia</a> | <a href="https://eventvods.com/featured/lol?utm_source=reddit&amp;utm_medium=subreddit&amp;utm_campaign=post_match_threads">Eventvods.com</a> | <a href="http://lol.gamepedia.com/New_To_League/Welcome">New to LoL</a></p> <hr /> <h1>OKSavingsBank BRION 2-0 KT Rolster</h1> <p><strong>BRO</strong> | <a href="https://lol.fandom.com/wiki/BRION">Leaguepedia</a> | <a href="https://liquipedia.net/leagueoflegends/BRION">Liquipedia</a> | <a href="https://brionesports.gg/">Website</a> | <a href="https://www.twitter.com/Brionesports">Twitter</a> | <a href="https://facebook.com/officialbrionesports">Facebook</a> | <a href="https://www.youtube.com/channel/UCYQO6n0KZmwfwzWtm4_nAPA">YouTube</a><br /> <strong>KT</strong>

## Laptop na studia
 - [https://www.reddit.com/r/Polska/comments/1ejpff4/laptop_na_studia](https://www.reddit.com/r/Polska/comments/1ejpff4/laptop_na_studia)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T07:17:48+00:00

<!-- SC_OFF --><div class="md"><p>Niedługo wybieram się na studia. Potrzebuję dobrego laptopa, który będzie starczał na dłużej. Idę na filologię angielską więc raczej nie musi być mega wypasiony, co więcej rzadko gram w jakieś gry więc wielkich wymagań wobec tego też nie mam. Nie znam się zbyt dobrze na nich więc liczę na waszą pomoc i doświadczenie. Z góry dzięki :) BUDŻET 3.2K</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Curious_Trust_9158"> /u/Curious_Trust_9158 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ejpff4/laptop_na_studia/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ejpff4/laptop_na_studia/">[comments]</a></span>

## Maybe maybe maybe
 - [https://www.reddit.com/r/maybemaybemaybe/comments/1ejopoq/maybe_maybe_maybe](https://www.reddit.com/r/maybemaybemaybe/comments/1ejopoq/maybe_maybe_maybe)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T06:30:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/maybemaybemaybe/comments/1ejopoq/maybe_maybe_maybe/"> <img alt="Maybe maybe maybe " src="https://external-preview.redd.it/OWNpb2hiejRkbGdkMRx7AuuAiDa81Y5UwOo4RGAQAl8PpKY9PjrBrT-2y3hX.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=67e18d9e658cb720e3b1c967c9a3fa19366e2a71" title="Maybe maybe maybe " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Only-Reels"> /u/Only-Reels </a> &#32; to &#32; <a href="https://www.reddit.com/r/maybemaybemaybe/"> r/maybemaybemaybe </a> <br /> <span><a href="https://v.redd.it/qrfu4145dlgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/maybemaybemaybe/comments/1ejopoq/maybe_maybe_maybe/">[comments]</a></span> </td></tr></table>

## This is the ideal I/O panel form. You may not like it, but this is what peak performance looks like.
 - [https://www.reddit.com/r/pcmasterrace/comments/1ejomht/this_is_the_ideal_io_panel_form_you_may_not_like](https://www.reddit.com/r/pcmasterrace/comments/1ejomht/this_is_the_ideal_io_panel_form_you_may_not_like)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T06:24:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pcmasterrace/comments/1ejomht/this_is_the_ideal_io_panel_form_you_may_not_like/"> <img alt="This is the ideal I/O panel form. You may not like it, but this is what peak performance looks like." src="https://preview.redd.it/mooxnky0clgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b891c3424ca0828cf597f657ec4011ec56cef2d7" title="This is the ideal I/O panel form. You may not like it, but this is what peak performance looks like." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sawb11152"> /u/sawb11152 </a> &#32; to &#32; <a href="https://www.reddit.com/r/pcmasterrace/"> r/pcmasterrace </a> <br /> <span><a href="https://i.redd.it/mooxnky0clgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pcmasterrace/comments/1ejomht/this_is_the_ideal_io_panel_form_you_may_not_like/">[comments]</a></span> </td></tr></table>

## Help please
 - [https://www.reddit.com/r/skyrim/comments/1ejoekp/help_please](https://www.reddit.com/r/skyrim/comments/1ejoekp/help_please)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T06:10:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/skyrim/comments/1ejoekp/help_please/"> <img alt="Help please" src="https://preview.redd.it/zjb7s0bl9lgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aff2f362d659e0274aff7f6806bfc252cd119689" title="Help please" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NoAdministration1070"> /u/NoAdministration1070 </a> &#32; to &#32; <a href="https://www.reddit.com/r/skyrim/"> r/skyrim </a> <br /> <span><a href="https://i.redd.it/zjb7s0bl9lgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/skyrim/comments/1ejoekp/help_please/">[comments]</a></span> </td></tr></table>

## Burglary in Europe
 - [https://www.reddit.com/r/europe/comments/1ejo7jj/burglary_in_europe](https://www.reddit.com/r/europe/comments/1ejo7jj/burglary_in_europe)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T05:57:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1ejo7jj/burglary_in_europe/"> <img alt="Burglary in Europe" src="https://preview.redd.it/5ykxl60c7lgd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=049d2be04a72d7fddd5a5eeb7fad775bd197161e" title="Burglary in Europe" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/anna_avian"> /u/anna_avian </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br /> <span><a href="https://i.redd.it/5ykxl60c7lgd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1ejo7jj/burglary_in_europe/">[comments]</a></span> </td></tr></table>

## The Boys posting 🤩
 - [https://www.reddit.com/r/whenthe/comments/1ejnfgf/the_boys_posting](https://www.reddit.com/r/whenthe/comments/1ejnfgf/the_boys_posting)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T05:06:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ejnfgf/the_boys_posting/"> <img alt="The Boys posting 🤩" src="https://external-preview.redd.it/d3Q3bnh2dTh5a2dkMSbo-yQfDCnQUu8i_WZIgpGpXSsTu6bLwTw3O9CKD-io.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=30f0c89560009bb16ac77f5cd910b244d5f1888c" title="The Boys posting 🤩" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/deleting_accountNOW"> /u/deleting_accountNOW </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://v.redd.it/4tdznj29ykgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ejnfgf/the_boys_posting/">[comments]</a></span> </td></tr></table>

## Belle has Covid (by luizhtx)
 - [https://www.reddit.com/r/ZenlessZoneZero/comments/1ejn7k3/belle_has_covid_by_luizhtx](https://www.reddit.com/r/ZenlessZoneZero/comments/1ejn7k3/belle_has_covid_by_luizhtx)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T04:53:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/ZenlessZoneZero/comments/1ejn7k3/belle_has_covid_by_luizhtx/"> <img alt="Belle has Covid (by luizhtx)" src="https://preview.redd.it/6wkb6amwvkgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8c088ad3fd560434b834a2b66f54df3f822e9ae5" title="Belle has Covid (by luizhtx)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Bro's about to leave to buy milk</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/freshfruit2404"> /u/freshfruit2404 </a> &#32; to &#32; <a href="https://www.reddit.com/r/ZenlessZoneZero/"> r/ZenlessZoneZero </a> <br /> <span><a href="https://i.redd.it/6wkb6amwvkgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/ZenlessZoneZero/comments/1ejn7k3/belle_has_covid_by_luizhtx/">[comments]</a></span> </td></tr></table>

## To make a better profile picture.
 - [https://www.reddit.com/r/therewasanattempt/comments/1ejn7j5/to_make_a_better_profile_picture](https://www.reddit.com/r/therewasanattempt/comments/1ejn7j5/to_make_a_better_profile_picture)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T04:53:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/therewasanattempt/comments/1ejn7j5/to_make_a_better_profile_picture/"> <img alt="To make a better profile picture." src="https://b.thumbs.redditmedia.com/Uwx9Eq_UWn-Z9ffRyZ5vEQcScBvpU3cAu-YqYUSGwXI.jpg" title="To make a better profile picture." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TRANSBIANGODDES"> /u/TRANSBIANGODDES </a> &#32; to &#32; <a href="https://www.reddit.com/r/therewasanattempt/"> r/therewasanattempt </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejn7j5">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/therewasanattempt/comments/1ejn7j5/to_make_a_better_profile_picture/">[comments]</a></span> </td></tr></table>

## Brock Lesnar and his daughter Mya
 - [https://www.reddit.com/r/interestingasfuck/comments/1ejmuvh/brock_lesnar_and_his_daughter_mya](https://www.reddit.com/r/interestingasfuck/comments/1ejmuvh/brock_lesnar_and_his_daughter_mya)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T04:32:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/interestingasfuck/comments/1ejmuvh/brock_lesnar_and_his_daughter_mya/"> <img alt="Brock Lesnar and his daughter Mya" src="https://preview.redd.it/pun1dfs6skgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ad831d73f3b4859eb7cebe25eb0f24fc75190629" title="Brock Lesnar and his daughter Mya" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dontbelievethehype0"> /u/Dontbelievethehype0 </a> &#32; to &#32; <a href="https://www.reddit.com/r/interestingasfuck/"> r/interestingasfuck </a> <br /> <span><a href="https://i.redd.it/pun1dfs6skgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/interestingasfuck/comments/1ejmuvh/brock_lesnar_and_his_daughter_mya/">[comments]</a></span> </td></tr></table>

## How to troll a being beyond human comprehension in a few, easy steps:
 - [https://www.reddit.com/r/whenthe/comments/1ejmmeo/how_to_troll_a_being_beyond_human_comprehension](https://www.reddit.com/r/whenthe/comments/1ejmmeo/how_to_troll_a_being_beyond_human_comprehension)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T04:18:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ejmmeo/how_to_troll_a_being_beyond_human_comprehension/"> <img alt="How to troll a being beyond human comprehension in a few, easy steps: " src="https://external-preview.redd.it/N2l3eDliZHBwa2dkMR09yIgRcPc5vCyZWBHYaSSqG27jsctv1FthBX00wNbb.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=3830164fa458b6123131099a2f9cb1a3cccbfd58" title="How to troll a being beyond human comprehension in a few, easy steps: " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bird_eater_42"> /u/bird_eater_42 </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://v.redd.it/u62wupippkgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ejmmeo/how_to_troll_a_being_beyond_human_comprehension/">[comments]</a></span> </td></tr></table>

## Olmypic shooting target size.
 - [https://www.reddit.com/r/Damnthatsinteresting/comments/1ejmii6/olmypic_shooting_target_size](https://www.reddit.com/r/Damnthatsinteresting/comments/1ejmii6/olmypic_shooting_target_size)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T04:12:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1ejmii6/olmypic_shooting_target_size/"> <img alt="Olmypic shooting target size." src="https://b.thumbs.redditmedia.com/lVRQkhz5HxWkmkNJmzLVn_6ia2WwiOKxStgsYW3lrEM.jpg" title="Olmypic shooting target size." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sir00-00"> /u/Sir00-00 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Damnthatsinteresting/"> r/Damnthatsinteresting </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejmii6">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1ejmii6/olmypic_shooting_target_size/">[comments]</a></span> </td></tr></table>

## We found a marijuana plant while walking around my mom’s property
 - [https://www.reddit.com/r/mildlyinteresting/comments/1ejkstp/we_found_a_marijuana_plant_while_walking_around](https://www.reddit.com/r/mildlyinteresting/comments/1ejkstp/we_found_a_marijuana_plant_while_walking_around)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T02:37:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinteresting/comments/1ejkstp/we_found_a_marijuana_plant_while_walking_around/"> <img alt="We found a marijuana plant while walking around my mom’s property" src="https://preview.redd.it/tjw6mn9o7kgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ca9a0ed8ed3145423abec86852be3f0447e58c0a" title="We found a marijuana plant while walking around my mom’s property" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Similar_Set_6582"> /u/Similar_Set_6582 </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinteresting/"> r/mildlyinteresting </a> <br /> <span><a href="https://i.redd.it/tjw6mn9o7kgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/mildlyinteresting/comments/1ejkstp/we_found_a_marijuana_plant_while_walking_around/">[comments]</a></span> </td></tr></table>

## meirl
 - [https://www.reddit.com/r/meirl/comments/1ejksoy/meirl](https://www.reddit.com/r/meirl/comments/1ejksoy/meirl)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T02:37:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/meirl/comments/1ejksoy/meirl/"> <img alt="meirl" src="https://preview.redd.it/nlxmuj1p7kgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7ad62bb14e0579c076d921eb2e8a7356afd3b9b4" title="meirl" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bean_Moxie"> /u/Bean_Moxie </a> &#32; to &#32; <a href="https://www.reddit.com/r/meirl/"> r/meirl </a> <br /> <span><a href="https://i.redd.it/nlxmuj1p7kgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/meirl/comments/1ejksoy/meirl/">[comments]</a></span> </td></tr></table>

## Anime_irl
 - [https://www.reddit.com/r/anime_irl/comments/1ejkmaq/anime_irl](https://www.reddit.com/r/anime_irl/comments/1ejkmaq/anime_irl)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T02:28:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/falling-god-777"> /u/falling-god-777 </a> &#32; to &#32; <a href="https://www.reddit.com/r/anime_irl/"> r/anime_irl </a> <br /> <span><a href="https://i.redd.it/23psw5426kgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime_irl/comments/1ejkmaq/anime_irl/">[comments]</a></span>

## How long till you approach him?
 - [https://www.reddit.com/r/NotHowGirlsWork/comments/1ejk46m/how_long_till_you_approach_him](https://www.reddit.com/r/NotHowGirlsWork/comments/1ejk46m/how_long_till_you_approach_him)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T02:01:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/NotHowGirlsWork/comments/1ejk46m/how_long_till_you_approach_him/"> <img alt="How long till you approach him?" src="https://preview.redd.it/2mizbdz71kgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a6868aea956dc428bbd8d913d02fed9e895005df" title="How long till you approach him?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Fourthnightold"> /u/Fourthnightold </a> &#32; to &#32; <a href="https://www.reddit.com/r/NotHowGirlsWork/"> r/NotHowGirlsWork </a> <br /> <span><a href="https://i.redd.it/2mizbdz71kgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/NotHowGirlsWork/comments/1ejk46m/how_long_till_you_approach_him/">[comments]</a></span> </td></tr></table>

## Still 100 million views in a day lol
 - [https://www.reddit.com/r/memes/comments/1ejimg8/still_100_million_views_in_a_day_lol](https://www.reddit.com/r/memes/comments/1ejimg8/still_100_million_views_in_a_day_lol)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T00:44:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/memes/comments/1ejimg8/still_100_million_views_in_a_day_lol/"> <img alt="Still 100 million views in a day lol" src="https://external-preview.redd.it/cTc1MmN6aGhuamdkMZSfg1PKSzJN5ZWjIZBWM6MTdwOXasiECyiZyo7XpfOe.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=748b45faf310fe4bcaaa98e0b0c44bb560486206" title="Still 100 million views in a day lol" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PrestonG340"> /u/PrestonG340 </a> &#32; to &#32; <a href="https://www.reddit.com/r/memes/"> r/memes </a> <br /> <span><a href="https://v.redd.it/3nyylakhnjgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/memes/comments/1ejimg8/still_100_million_views_in_a_day_lol/">[comments]</a></span> </td></tr></table>

## South Park The Fractured but Whole still has the funniest difficulty setting in any game.
 - [https://www.reddit.com/r/gaming/comments/1ejht99/south_park_the_fractured_but_whole_still_has_the](https://www.reddit.com/r/gaming/comments/1ejht99/south_park_the_fractured_but_whole_still_has_the)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-04T00:03:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1ejht99/south_park_the_fractured_but_whole_still_has_the/"> <img alt="South Park The Fractured but Whole still has the funniest difficulty setting in any game. " src="https://preview.redd.it/5bnh02l9gjgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=498f4d0df23cdfb378dc51df65fe52ae9e4700e8" title="South Park The Fractured but Whole still has the funniest difficulty setting in any game. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Justapersonmaybe"> /u/Justapersonmaybe </a> &#32; to &#32; <a href="https://www.reddit.com/r/gaming/"> r/gaming </a> <br /> <span><a href="https://i.redd.it/5bnh02l9gjgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1ejht99/south_park_the_fractured_but_whole_still_has_the/">[comments]</a></span> </td></tr></table>

