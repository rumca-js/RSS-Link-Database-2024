# Source:/r/Warhammer40k - Unofficial Home of 40k on Reddit, URL:https://www.reddit.com/r/Warhammer40k/.rss, language:en

## "Does this read as..." is the most annoying question in the hobby.
 - [https://www.reddit.com/r/Warhammer40k/comments/1ek4mna/does_this_read_as_is_the_most_annoying_question](https://www.reddit.com/r/Warhammer40k/comments/1ek4mna/does_this_read_as_is_the_most_annoying_question)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T20:11:14+00:00

<!-- SC_OFF --><div class="md"><p>I know I'm an old man yelling at a cloud here, but back in the good old days converting minis and making cool unique versions of units was seen as a naturally good thing - going that extra mile to make your minis different from what was on the box.</p> <p>If you could do it with only official GW bits then that was even better because it made it tournament legal.</p> <p>Nowadays it seems like people need to 'check with the community' if they make the slightest alteration to a mini.</p> <p>&quot;Would you allow me to run this as a Lord Solar in a game?&quot;</p> <p>Well, if the base size is right and it has the correct equipment (or an obvious equivalent) then who the hell am I to even have an opinion on the matter - especially if it's made from GW bits (I personally don't care if people use third party bits, but I'm just mentioning it because some tournaments care).</p> <p>I'm just ranting here because it really seems like there are so many threads wit

## At last i finished my largest build - Astarmilitarum Valkyrie
 - [https://www.reddit.com/r/Warhammer40k/comments/1ek3lld/at_last_i_finished_my_largest_build](https://www.reddit.com/r/Warhammer40k/comments/1ek3lld/at_last_i_finished_my_largest_build)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T19:27:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ek3lld/at_last_i_finished_my_largest_build/"> <img alt="At last i finished my largest build - Astarmilitarum Valkyrie" src="https://b.thumbs.redditmedia.com/CEQMUSDCENNamTIfv0spBngbMPAX3-hKdEEpewTI3Mw.jpg" title="At last i finished my largest build - Astarmilitarum Valkyrie" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/fyris_minis"> /u/fyris_minis </a> <br /> <span><a href="https://www.reddit.com/gallery/1ek3lld">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ek3lld/at_last_i_finished_my_largest_build/">[comments]</a></span> </td></tr></table>

## The Imperial Agents Mobilise
 - [https://www.reddit.com/r/Warhammer40k/comments/1ek120p/the_imperial_agents_mobilise](https://www.reddit.com/r/Warhammer40k/comments/1ek120p/the_imperial_agents_mobilise)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T17:42:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/racer951y"> /u/racer951y </a> <br /> <span><a href="https://www.warhammer-community.com/2024/08/04/sunday-preview-the-imperial-agents-mobilise/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ek120p/the_imperial_agents_mobilise/">[comments]</a></span>

## Barabas Dantioch Reimagined
 - [https://www.reddit.com/r/Warhammer40k/comments/1ek10rn/barabas_dantioch_reimagined](https://www.reddit.com/r/Warhammer40k/comments/1ek10rn/barabas_dantioch_reimagined)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T17:41:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ek10rn/barabas_dantioch_reimagined/"> <img alt="Barabas Dantioch Reimagined" src="https://preview.redd.it/csz836qsoogd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=861b2c192f402407cd481773b03077ef158fe7eb" title="Barabas Dantioch Reimagined" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Vecypp"> /u/Vecypp </a> <br /> <span><a href="https://i.redd.it/csz836qsoogd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ek10rn/barabas_dantioch_reimagined/">[comments]</a></span> </td></tr></table>

## What armies do you have?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ek0gvl/what_armies_do_you_have](https://www.reddit.com/r/Warhammer40k/comments/1ek0gvl/what_armies_do_you_have)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T17:17:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ek0gvl/what_armies_do_you_have/"> <img alt="What armies do you have? " src="https://b.thumbs.redditmedia.com/2mgCf5SK0EuTRnnUpW9muzbMEvlpL1-h-qePrPBv5LQ.jpg" title="What armies do you have? " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>So I played 40k pretty regularly from 2001-2009 and played a nice 3000 pt Guard army back then with a small blood angels army and CSM army as secondaries, I ended up selling them all on ebay regretably, I got back into the hobby about 2 years ago and wanted to branch out a bit so I picked up a small combat patrol of Tau and got the big starter box set that came with tyranids and space marines and the astra militarum box set</p> <p>Ive been having a blast trying out different armies and getting to paint unique pieces, so Im curious what range armies everyone else runs, I have 6 now of varying pt values </p> <p>Orkz - 1500 Blood Angels - 1400 Astra Militarum - 1100 Chaos Spa

## Snagged this Battlefleet Gothic set at the Gencon auction
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejyve9/snagged_this_battlefleet_gothic_set_at_the_gencon](https://www.reddit.com/r/Warhammer40k/comments/1ejyve9/snagged_this_battlefleet_gothic_set_at_the_gencon)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T16:10:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyve9/snagged_this_battlefleet_gothic_set_at_the_gencon/"> <img alt="Snagged this Battlefleet Gothic set at the Gencon auction" src="https://b.thumbs.redditmedia.com/4BU-DTZlWyt_kOoMPeA5be9OEdrh7X7Lc8Hzzbx_rOo.jpg" title="Snagged this Battlefleet Gothic set at the Gencon auction" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>It doesn't have the rulebook but otherwise everything is intact (including a nifty comic!) Time to learn how to play it.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SgtMalarkey"> /u/SgtMalarkey </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejyve9">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyve9/snagged_this_battlefleet_gothic_set_at_the_gencon/">[comments]</a></span> </td></tr></table>

## First few test models for my Carolean Guardsmen, please let me know what you think about them
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejyvdh/first_few_test_models_for_my_carolean_guardsmen](https://www.reddit.com/r/Warhammer40k/comments/1ejyvdh/first_few_test_models_for_my_carolean_guardsmen)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T16:10:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyvdh/first_few_test_models_for_my_carolean_guardsmen/"> <img alt="First few test models for my Carolean Guardsmen, please let me know what you think about them" src="https://b.thumbs.redditmedia.com/7gRR4n_a1CdmGUXwwDYyK7yEbD8vkxxJTwek6ivGCkY.jpg" title="First few test models for my Carolean Guardsmen, please let me know what you think about them" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BlitzBurn_"> /u/BlitzBurn_ </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejyvdh">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyvdh/first_few_test_models_for_my_carolean_guardsmen/">[comments]</a></span> </td></tr></table>

## This is my best painted mini so far, what can I do to improve further?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejyury/this_is_my_best_painted_mini_so_far_what_can_i_do](https://www.reddit.com/r/Warhammer40k/comments/1ejyury/this_is_my_best_painted_mini_so_far_what_can_i_do)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T16:10:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyury/this_is_my_best_painted_mini_so_far_what_can_i_do/"> <img alt="This is my best painted mini so far, what can I do to improve further?" src="https://b.thumbs.redditmedia.com/8yHV2UAeNcsKXH0YuSM7UP4Kmoz64rZcUu5haycg_ag.jpg" title="This is my best painted mini so far, what can I do to improve further?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Character_Structure7"> /u/Character_Structure7 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejyury">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyury/this_is_my_best_painted_mini_so_far_what_can_i_do/">[comments]</a></span> </td></tr></table>

## How do you like my Stompa!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejyr3f/how_do_you_like_my_stompa](https://www.reddit.com/r/Warhammer40k/comments/1ejyr3f/how_do_you_like_my_stompa)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T16:05:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyr3f/how_do_you_like_my_stompa/"> <img alt="How do you like my Stompa!" src="https://b.thumbs.redditmedia.com/WIRZx4PYTvoMJuwQ79eyIJt2s2ReDtLArU-O3hpbNBM.jpg" title="How do you like my Stompa!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Took me a little while to finish but here he is. What do you think.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quinchie"> /u/Quinchie </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejyr3f">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyr3f/how_do_you_like_my_stompa/">[comments]</a></span> </td></tr></table>

## "Thunder Warriors" painted by myself :)
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejyd9g/thunder_warriors_painted_by_myself](https://www.reddit.com/r/Warhammer40k/comments/1ejyd9g/thunder_warriors_painted_by_myself)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T15:49:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyd9g/thunder_warriors_painted_by_myself/"> <img alt="&quot;Thunder Warriors&quot; painted by myself :)" src="https://b.thumbs.redditmedia.com/0bj9evQVgf91fw0v2LbTK80z5CzVPGWTYFidOxP1SdY.jpg" title="&quot;Thunder Warriors&quot; painted by myself :)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DanKCreations89"> /u/DanKCreations89 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejyd9g">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejyd9g/thunder_warriors_painted_by_myself/">[comments]</a></span> </td></tr></table>

## Custom decal / Painting
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejy2yj/custom_decal_painting](https://www.reddit.com/r/Warhammer40k/comments/1ejy2yj/custom_decal_painting)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T15:37:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejy2yj/custom_decal_painting/"> <img alt="Custom decal / Painting " src="https://b.thumbs.redditmedia.com/HU_F90FxykcmsXGQHOis0XpEkrnVKWfSDGYnx11XZ3U.jpg" title="Custom decal / Painting " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Did a custom decal and then painted in the edges for the shoulder plate of my Warmaster Titan. Pretty happy with how it turned out.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ghosthammer686"> /u/Ghosthammer686 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejy2yj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejy2yj/custom_decal_painting/">[comments]</a></span> </td></tr></table>

## So he is more or less done! More grimdark and dirty than I tend to paint
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejxulm/so_he_is_more_or_less_done_more_grimdark_and](https://www.reddit.com/r/Warhammer40k/comments/1ejxulm/so_he_is_more_or_less_done_more_grimdark_and)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T15:27:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejxulm/so_he_is_more_or_less_done_more_grimdark_and/"> <img alt="So he is more or less done! More grimdark and dirty than I tend to paint" src="https://a.thumbs.redditmedia.com/gduNEfSMxxX5P9OIcjpxrtuHo3_vsEFUyIjJqIaJ0W4.jpg" title="So he is more or less done! More grimdark and dirty than I tend to paint" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Was asked to make him more dirty and dark than the normal ultramarine look. Also not so much blue, was different to paint and there are more to be done with jetpack and a few minor areas but that will be once the other 4 marines are painted. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zerak88"> /u/zerak88 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejxulm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejxulm/so_he_is_more_or_less_done_more_grimdark_and/">[commen

## how do I go about cleaning these canopies?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejw3p1/how_do_i_go_about_cleaning_these_canopies](https://www.reddit.com/r/Warhammer40k/comments/1ejw3p1/how_do_i_go_about_cleaning_these_canopies)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T14:07:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejw3p1/how_do_i_go_about_cleaning_these_canopies/"> <img alt="how do I go about cleaning these canopies? " src="https://b.thumbs.redditmedia.com/jKBoCO6r2kPqXvJkFBaqn0PIuVrSsxktkvVjDdEVevI.jpg" title="how do I go about cleaning these canopies? " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>they're from the forgeworld Avenger Strike fighter (resin)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jackyjackpoo"> /u/jackyjackpoo </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejw3p1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejw3p1/how_do_i_go_about_cleaning_these_canopies/">[comments]</a></span> </td></tr></table>

## Black Templar Apothecary done! Definitely one of my favorite models.
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejvi4h/black_templar_apothecary_done_definitely_one_of](https://www.reddit.com/r/Warhammer40k/comments/1ejvi4h/black_templar_apothecary_done_definitely_one_of)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T13:39:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejvi4h/black_templar_apothecary_done_definitely_one_of/"> <img alt="Black Templar Apothecary done! Definitely one of my favorite models." src="https://b.thumbs.redditmedia.com/WmK5S1FdrvWuDmfpA-Aw4b6qdyGuf1dMNRte9yoDg3E.jpg" title="Black Templar Apothecary done! Definitely one of my favorite models." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/awqs12"> /u/awqs12 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejvi4h">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejvi4h/black_templar_apothecary_done_definitely_one_of/">[comments]</a></span> </td></tr></table>

## Ork kommandos burnaboy
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejulxq/ork_kommandos_burnaboy](https://www.reddit.com/r/Warhammer40k/comments/1ejulxq/ork_kommandos_burnaboy)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T12:56:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejulxq/ork_kommandos_burnaboy/"> <img alt="Ork kommandos burnaboy" src="https://preview.redd.it/7w8txz74angd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1e032f79b51aefcc0ca322caed0e3f723371bfb0" title="Ork kommandos burnaboy" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>How Do you think? I hope you guys like this</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WestSeaworthiness835"> /u/WestSeaworthiness835 </a> <br /> <span><a href="https://i.redd.it/7w8txz74angd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejulxq/ork_kommandos_burnaboy/">[comments]</a></span> </td></tr></table>

## C&C welcomed, is this too much/too little weathering?
 - [https://www.reddit.com/r/Warhammer40k/comments/1eju55w/cc_welcomed_is_this_too_muchtoo_little_weathering](https://www.reddit.com/r/Warhammer40k/comments/1eju55w/cc_welcomed_is_this_too_muchtoo_little_weathering)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T12:31:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eju55w/cc_welcomed_is_this_too_muchtoo_little_weathering/"> <img alt="C&amp;C welcomed, is this too much/too little weathering?" src="https://a.thumbs.redditmedia.com/edbyC2EHYhsNDug7sz3lZNCMQVv6eLB9NoJ9gqlGdR4.jpg" title="C&amp;C welcomed, is this too much/too little weathering?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I need feedback on this one, i'm afraid I went way overboard on the blood, especially on the face, do you have any advice?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Najdadinn"> /u/Najdadinn </a> <br /> <span><a href="https://www.reddit.com/gallery/1eju55w">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eju55w/cc_welcomed_is_this_too_muchtoo_little_weathering/">[comments]</a></span> </td></tr></table>

## 3 years in the hobby and this is my first completed squad.
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejta16/3_years_in_the_hobby_and_this_is_my_first](https://www.reddit.com/r/Warhammer40k/comments/1ejta16/3_years_in_the_hobby_and_this_is_my_first)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T11:42:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejta16/3_years_in_the_hobby_and_this_is_my_first/"> <img alt="3 years in the hobby and this is my first completed squad. " src="https://b.thumbs.redditmedia.com/gVyqCR5FHlk8h9BmKLucQ_bY9gkEEEdBbfPj7lYTusw.jpg" title="3 years in the hobby and this is my first completed squad. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Grabosss"> /u/Grabosss </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejta16">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejta16/3_years_in_the_hobby_and_this_is_my_first/">[comments]</a></span> </td></tr></table>

## Problem with painting
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejt4or/problem_with_painting](https://www.reddit.com/r/Warhammer40k/comments/1ejt4or/problem_with_painting)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T11:33:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejt4or/problem_with_painting/"> <img alt="Problem with painting" src="https://b.thumbs.redditmedia.com/YsUNKr0R1WPsbnffe3SGQ0BDC111XKdKswm5WLs0fKA.jpg" title="Problem with painting" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hi everyone, so I've come here because I suck at painting so any advice is welcome.</p> <p>But my biggest problem is, I've got a disease which make me shake my hand and all my bodie at random so painting is quite hard especially detail. I lose a lot of time repainting the same little fucking area 10 time because I paint another part i dont want cause of the shaking of my hand so if someone have a similar problem and have a solution please tell me.</p> <p>Also you can see different missed spot. But right now I'm just not ready to retry painting this guy.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/uli_chevalier"> /u/uli_chevalier </a> <br />

## This is now chapter's relic
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejsgxm/this_is_now_chapters_relic](https://www.reddit.com/r/Warhammer40k/comments/1ejsgxm/this_is_now_chapters_relic)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T10:51:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejsgxm/this_is_now_chapters_relic/"> <img alt="This is now chapter's relic" src="https://b.thumbs.redditmedia.com/cnwGbFHgTEwSH0U41Q18XllUXRys5qrJbNaIkKJ1aBA.jpg" title="This is now chapter's relic" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Feuerkr13ger"> /u/Feuerkr13ger </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejsgxm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejsgxm/this_is_now_chapters_relic/">[comments]</a></span> </td></tr></table>

## Were Thunder Warriors better than Astartes?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejscbp/were_thunder_warriors_better_than_astartes](https://www.reddit.com/r/Warhammer40k/comments/1ejscbp/were_thunder_warriors_better_than_astartes)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T10:42:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejscbp/were_thunder_warriors_better_than_astartes/"> <img alt="Were Thunder Warriors better than Astartes? " src="https://preview.redd.it/x1u85wk7mmgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bcbb23d8f0dcc098c6a67b2a70bebe6eabcb0dad" title="Were Thunder Warriors better than Astartes? " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just saw this and was surprised because I assumed Astartes were the successors and subsequently better than Thunder warriors. Is this true? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/seanstew73"> /u/seanstew73 </a> <br /> <span><a href="https://i.redd.it/x1u85wk7mmgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejscbp/were_thunder_warriors_better_than_astartes/">[comments]</a></span> </td></tr></table>

## Fairly happy with my first vehicle
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejrqyi/fairly_happy_with_my_first_vehicle](https://www.reddit.com/r/Warhammer40k/comments/1ejrqyi/fairly_happy_with_my_first_vehicle)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T10:01:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejrqyi/fairly_happy_with_my_first_vehicle/"> <img alt="Fairly happy with my first vehicle" src="https://preview.redd.it/ld04vguuemgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fbadb72fac2a2f7b3c98f7ad61a36f70d122b0ea" title="Fairly happy with my first vehicle" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>There’s quite a bit still left to do and tidy up, including the base, but I’m at the point where it’s “good enough” and I usually end up ruining paint jobs by trying too hard. Still struggle with white and lenses, but getting there. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NinjaDeathSheep"> /u/NinjaDeathSheep </a> <br /> <span><a href="https://i.redd.it/ld04vguuemgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejrqyi/fairly_happy_with_my_first_vehicle/">[comments]</a></span> </td></tr></table>

## Finished my first mini ever
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejrq6c/finished_my_first_mini_ever](https://www.reddit.com/r/Warhammer40k/comments/1ejrq6c/finished_my_first_mini_ever)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T10:00:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejrq6c/finished_my_first_mini_ever/"> <img alt="Finished my first mini ever " src="https://b.thumbs.redditmedia.com/T02dvu85khi65JqeUZAGwe6BRVCPMmF413KSYB00Uug.jpg" title="Finished my first mini ever " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mr____Grim"> /u/Mr____Grim </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejrq6c">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejrq6c/finished_my_first_mini_ever/">[comments]</a></span> </td></tr></table>

## First time painting fire, happy with the result.
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejr0m1/first_time_painting_fire_happy_with_the_result](https://www.reddit.com/r/Warhammer40k/comments/1ejr0m1/first_time_painting_fire_happy_with_the_result)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T09:08:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejr0m1/first_time_painting_fire_happy_with_the_result/"> <img alt="First time painting fire, happy with the result." src="https://b.thumbs.redditmedia.com/w1wYVZyV13GUMasIuwc3zOJLPYrY6wBA9jObNAgxvXk.jpg" title="First time painting fire, happy with the result." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Model is almost done, just some cleanup and the base.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/x0redfox0x"> /u/x0redfox0x </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejr0m1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejr0m1/first_time_painting_fire_happy_with_the_result/">[comments]</a></span> </td></tr></table>

## Hi, i just painted my first miniature, it's not the best but i'm so happy with It!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejq3y1/hi_i_just_painted_my_first_miniature_its_not_the](https://www.reddit.com/r/Warhammer40k/comments/1ejq3y1/hi_i_just_painted_my_first_miniature_its_not_the)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T08:03:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejq3y1/hi_i_just_painted_my_first_miniature_its_not_the/"> <img alt="Hi, i just painted my first miniature, it's not the best but i'm so happy with It!" src="https://preview.redd.it/wxg6xfjttlgd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c53a97b8dd72c9989d26ac1f6fb90281b105af62" title="Hi, i just painted my first miniature, it's not the best but i'm so happy with It!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/siepe_verde"> /u/siepe_verde </a> <br /> <span><a href="https://i.redd.it/wxg6xfjttlgd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejq3y1/hi_i_just_painted_my_first_miniature_its_not_the/">[comments]</a></span> </td></tr></table>

## Makeshift Terra’s wall
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejpfbb/makeshift_terras_wall](https://www.reddit.com/r/Warhammer40k/comments/1ejpfbb/makeshift_terras_wall)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T07:17:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejpfbb/makeshift_terras_wall/"> <img alt="Makeshift Terra’s wall" src="https://b.thumbs.redditmedia.com/uUwBG3IMkXJkoqquHIfcu97zYe43GQLDmW5y5scWPKU.jpg" title="Makeshift Terra’s wall" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/enternal_torument"> /u/enternal_torument </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejpfbb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejpfbb/makeshift_terras_wall/">[comments]</a></span> </td></tr></table>

## The Marlboro Marines! Any lore suggestions?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejmrn0/the_marlboro_marines_any_lore_suggestions](https://www.reddit.com/r/Warhammer40k/comments/1ejmrn0/the_marlboro_marines_any_lore_suggestions)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T04:27:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejmrn0/the_marlboro_marines_any_lore_suggestions/"> <img alt="The Marlboro Marines! Any lore suggestions?" src="https://b.thumbs.redditmedia.com/BIidnNaFZA7FBQuL2biV5tU_cpOFF5cyWiBGhmp3PKs.jpg" title="The Marlboro Marines! Any lore suggestions?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Snarkballs"> /u/Snarkballs </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejmrn0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejmrn0/the_marlboro_marines_any_lore_suggestions/">[comments]</a></span> </td></tr></table>

## Stompin’ into battle as fast as he possibly can
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejlev3/stompin_into_battle_as_fast_as_he_possibly_can](https://www.reddit.com/r/Warhammer40k/comments/1ejlev3/stompin_into_battle_as_fast_as_he_possibly_can)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T03:10:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejlev3/stompin_into_battle_as_fast_as_he_possibly_can/"> <img alt="Stompin’ into battle as fast as he possibly can" src="https://b.thumbs.redditmedia.com/ZlW6sDo7srS_cdhHPYxihYWl7DQz4hwBwKzKd5ZDq4c.jpg" title="Stompin’ into battle as fast as he possibly can" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>The White Scars don’t use too many terminators but hey, I couldn’t resist adding this guy to the Chapter ranks. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ricoisnotmyuncle"> /u/Ricoisnotmyuncle </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejlev3">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejlev3/stompin_into_battle_as_fast_as_he_possibly_can/">[comments]</a></span> </td></tr></table>

## Annihilation/last of us themed Leapers. What yall think?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejl3zk/annihilationlast_of_us_themed_leapers_what_yall](https://www.reddit.com/r/Warhammer40k/comments/1ejl3zk/annihilationlast_of_us_themed_leapers_what_yall)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T02:54:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejl3zk/annihilationlast_of_us_themed_leapers_what_yall/"> <img alt="Annihilation/last of us themed Leapers. What yall think?" src="https://b.thumbs.redditmedia.com/d4b_jV4-fRQwmgycI2bC4etvCLP-fidhqfYtyD5lzNg.jpg" title="Annihilation/last of us themed Leapers. What yall think?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zinski_irl"> /u/Zinski_irl </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejl3zk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejl3zk/annihilationlast_of_us_themed_leapers_what_yall/">[comments]</a></span> </td></tr></table>

## Time for a spin!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejkbyy/time_for_a_spin](https://www.reddit.com/r/Warhammer40k/comments/1ejkbyy/time_for_a_spin)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T02:12:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejkbyy/time_for_a_spin/"> <img alt="Time for a spin!" src="https://external-preview.redd.it/bzY4YzVrNzkza2dkMVEUDEJhsgllWmXyDS_hBxgLBNOzfGxpznDSc6BxnSKf.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c54a865a2c9cfbe6f8507dd3d320d61426c30b9" title="Time for a spin!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Over a year ago I posted a clip of me motorizing a gatling cannon. Here’s the follow up from the world’s slowest painter! I still want to paint/make lighting arcs off the gauntlet….maybe next year! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/napsalot19"> /u/napsalot19 </a> <br /> <span><a href="https://v.redd.it/jiig0n993kgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejkbyy/time_for_a_spin/">[comments]</a></span> </td></tr></table>

## lunar wolf stepping over recent kill
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejk622/lunar_wolf_stepping_over_recent_kill](https://www.reddit.com/r/Warhammer40k/comments/1ejk622/lunar_wolf_stepping_over_recent_kill)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T02:04:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejk622/lunar_wolf_stepping_over_recent_kill/"> <img alt=" lunar wolf stepping over recent kill" src="https://preview.redd.it/fw104qcp1kgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0922df77152b11f1bd56cb0bbe43456374ee0301" title=" lunar wolf stepping over recent kill" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dom5489"> /u/Dom5489 </a> <br /> <span><a href="https://i.redd.it/fw104qcp1kgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejk622/lunar_wolf_stepping_over_recent_kill/">[comments]</a></span> </td></tr></table>

## Bult some killa Kans with my grandma what yall think
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejjido/bult_some_killa_kans_with_my_grandma_what_yall](https://www.reddit.com/r/Warhammer40k/comments/1ejjido/bult_some_killa_kans_with_my_grandma_what_yall)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T01:29:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejjido/bult_some_killa_kans_with_my_grandma_what_yall/"> <img alt="Bult some killa Kans with my grandma what yall think" src="https://b.thumbs.redditmedia.com/fvsIP1CBW7ibvhiahEgrQ62qYcjpGVhomo4BStaoIAs.jpg" title="Bult some killa Kans with my grandma what yall think" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IrisTheprotogen"> /u/IrisTheprotogen </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejjido">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejjido/bult_some_killa_kans_with_my_grandma_what_yall/">[comments]</a></span> </td></tr></table>

## Does this work?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejjfp0/does_this_work](https://www.reddit.com/r/Warhammer40k/comments/1ejjfp0/does_this_work)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T01:25:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejjfp0/does_this_work/"> <img alt="Does this work?" src="https://preview.redd.it/92a9u38vujgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9976ce7489ba17d770b2464fe4a42d212e8d84b4" title="Does this work?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I keep going back and forth on whether the white boltgun works.</p> <p>I'm doing up a dark wolfspear scheme for killteam.</p> <p>I think it's the silencer. I could paint it black but then a mixture of black and white doesn't seem great either?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MrCalgar99"> /u/MrCalgar99 </a> <br /> <span><a href="https://i.redd.it/92a9u38vujgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejjfp0/does_this_work/">[comments]</a></span> </td></tr></table>

## Black Templars Ancient
 - [https://www.reddit.com/r/Warhammer40k/comments/1ejivmm/black_templars_ancient](https://www.reddit.com/r/Warhammer40k/comments/1ejivmm/black_templars_ancient)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T00:57:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ejivmm/black_templars_ancient/"> <img alt="Black Templars Ancient" src="https://a.thumbs.redditmedia.com/htGTPb38NfP2R1K_Nc-Mmsw7PWBix6aZxt6EGkLVEg8.jpg" title="Black Templars Ancient" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/crashalpha"> /u/crashalpha </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejivmm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ejivmm/black_templars_ancient/">[comments]</a></span> </td></tr></table>

## Ragnar complete!
 - [https://www.reddit.com/r/Warhammer40k/comments/1eji5sb/ragnar_complete](https://www.reddit.com/r/Warhammer40k/comments/1eji5sb/ragnar_complete)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-04T00:20:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eji5sb/ragnar_complete/"> <img alt="Ragnar complete!" src="https://a.thumbs.redditmedia.com/og6_eMX-mQzbJa67F9lj20gXDSp59HTyxpiXAhs0p78.jpg" title="Ragnar complete!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Finally completed my first hero model! Tired to go for the box art scheme but with some slight modifications to the fur color, gems, etc. hope y’all enjoy!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/frknloudzildjn"> /u/frknloudzildjn </a> <br /> <span><a href="https://www.reddit.com/gallery/1eji5sb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eji5sb/ragnar_complete/">[comments]</a></span> </td></tr></table>

