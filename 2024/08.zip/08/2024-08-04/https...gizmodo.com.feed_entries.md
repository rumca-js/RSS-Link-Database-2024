# Source:Gizmodo, URL:https://gizmodo.com/feed, language:en

## Watch a Little Robot Flap Its Wings Like a Rhinoceros Beetle
 - [https://gizmodo.com/watch-a-little-robot-flap-its-wings-like-a-rhinoceros-beetle-2000482972](https://gizmodo.com/watch-a-little-robot-flap-its-wings-like-a-rhinoceros-beetle-2000482972)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T20:40:07+00:00

<p><img alt="An up-close look at a Hercules beetle, a type of rhinoceros beetle" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/rhinoceros-beetle-robot-insect.jpg" width="1500" /></p>The robotic critter uniquely folds up its wings at rest and passively deploys them to fly.

## Colin Kaepernick Pisses Off Comics Industry with AI Comics Deal
 - [https://gizmodo.com/colin-kaepernick-lumi-genai-comics-2000482978](https://gizmodo.com/colin-kaepernick-lumi-genai-comics-2000482978)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T20:30:30+00:00

<p><img alt="Colin Kaepernick" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/colin-kaepernick.jpg" width="1500" /></p>As is the case with genAI in other industries, comics pros are not happy about the technology intruding on their space.

## Legendary Will Bring Neal Stephenson’s Seveneves to TV Life
 - [https://gizmodo.com/seveneves-tv-adaptation-neal-stephenson-2000482971](https://gizmodo.com/seveneves-tv-adaptation-neal-stephenson-2000482971)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T19:20:00+00:00

<p><img alt="Seveneves Cover" class="attachment-full size-full wp-post-image" height="1080" src="https://gizmodo.com/app/uploads/2024/08/seveneves-cover.jpg" width="1920" /></p>Still in the mood for shohws about space travel and humanity coming together? Legendary sure hopes you are.

## The Until Dawn Movie Nabs Peter Stormare to Replay His Video Game Role
 - [https://gizmodo.com/until-dawn-movie-cast-peter-stormare-2000482909](https://gizmodo.com/until-dawn-movie-cast-peter-stormare-2000482909)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T18:05:51+00:00

<p><img alt="Until Dawn Hill" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/until-dawn-hill.jpg" width="1500" /></p>Whatever this movie ends up being, at least Stormare will be there to do what players loved him doing in the original game.

## Larian Reveals Its Baldur’s Gate 4 That Never Was
 - [https://gizmodo.com/larian-baldurs-gate-4-scrapped-plans-2000482923](https://gizmodo.com/larian-baldurs-gate-4-scrapped-plans-2000482923)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T16:15:17+00:00

<p><img alt="Baldurs Gate" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/baldurs-gate.jpg" width="1500" /></p>More Baldur's Gate 3 wouldn't have been unappreciated, but it sounds like Larian needed to leave the Forgotten Realms for its own sake.

## Bruce Campell Says Evil Dead is Slaying Its Way to Animation
 - [https://gizmodo.com/evil-dead-animation-bruce-campbell-2000482910](https://gizmodo.com/evil-dead-animation-bruce-campbell-2000482910)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T14:00:11+00:00

<p><img alt="Evil Dead Ash" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/evil-dead-ash.jpg" width="1500" /></p>While the movies chug along, the supposed series may be the only way Campbell continues the groovy, bloody exploits of main man Ash Williams.

## Every TV Show Astronauts Can Watch on the ISS Right Now
 - [https://gizmodo.com/every-tv-show-astronauts-can-watch-on-the-iss-right-now-1851567279](https://gizmodo.com/every-tv-show-astronauts-can-watch-on-the-iss-right-now-1851567279)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T11:00:33+00:00

<p><img alt="Astronauts on board the International Space Station watch a Star Wars movie in 2017" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/2017-star-wars-movies-tv-shows-on-international-space-station-iss-nasa.jpg" width="1500" /></p>From <i>Andor</i> to <i>Yellowstone</i>, here's what astronauts can watch in space.

## Google Says AI Olympics Ad ‘Tested Well’ Before Inspiring Outrage
 - [https://gizmodo.com/google-says-ai-olympics-ad-tested-well-before-inspiring-outrage-2000482900](https://gizmodo.com/google-says-ai-olympics-ad-tested-well-before-inspiring-outrage-2000482900)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-04T00:36:01+00:00

<p><img alt="Google&#039;s logo is shown behind a silhouette hand holding a smartphone." class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/google-ai-ad-outrage-olympics.jpg" width="1500" /></p>Google tried turning Olympics fans into Gemini users. Instead, it made AI look like a weak substitute for parenting.

