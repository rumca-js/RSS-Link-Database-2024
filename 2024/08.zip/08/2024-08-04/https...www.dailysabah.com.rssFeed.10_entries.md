# Source:DAILYSABAH - Turkey News, URL:https://www.dailysabah.com/rssFeed/10, language:en-US

## Stargazers flock to Türkiye's Bursa for Perseid meteor shower
 - [https://www.dailysabah.com/turkiye/stargazers-flock-to-turkiyes-bursa-for-perseid-meteor-shower/news](https://www.dailysabah.com/turkiye/stargazers-flock-to-turkiyes-bursa-for-perseid-meteor-shower/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-08-04T11:23:00+00:00

Thousands of people gathered in Bursa's Karacabey district in northwestern Türkiye on Saturday to witness the Perseid meteor shower. Around 20,000 attendees, organized through...

## Turkish man's butterfly photography journey captures species for years
 - [https://www.dailysabah.com/turkiye/turkish-mans-butterfly-photography-journey-captures-species-for-years/news](https://www.dailysabah.com/turkiye/turkish-mans-butterfly-photography-journey-captures-species-for-years/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-08-04T11:23:00+00:00

Erdoğan Öğretmen, a civil servant, rekindled his childhood passion for photography 13 years ago when he bought a camera. Initially focusing on nature photography, he eventually dev...

