# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## 3d printed solar powered hydroponics
 - [https://www.reddit.com/r/3Dprinting/comments/1ek5pb2/3d_printed_solar_powered_hydroponics](https://www.reddit.com/r/3Dprinting/comments/1ek5pb2/3d_printed_solar_powered_hydroponics)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T20:57:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ek5pb2/3d_printed_solar_powered_hydroponics/"> <img alt="3d printed solar powered hydroponics " src="https://preview.redd.it/zwb7yqqunpgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7eaf525c76ebbdf1a1071992136c61032b81760b" title="3d printed solar powered hydroponics " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Made this using gutter downspout from home depot </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Anyhting_But_Stock"> /u/Anyhting_But_Stock </a> <br /> <span><a href="https://i.redd.it/zwb7yqqunpgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek5pb2/3d_printed_solar_powered_hydroponics/">[comments]</a></span> </td></tr></table>

## Why the difference in surface finish?
 - [https://www.reddit.com/r/3Dprinting/comments/1ek3v5d/why_the_difference_in_surface_finish](https://www.reddit.com/r/3Dprinting/comments/1ek3v5d/why_the_difference_in_surface_finish)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T19:39:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ek3v5d/why_the_difference_in_surface_finish/"> <img alt="Why the difference in surface finish? " src="https://preview.redd.it/mwrz1fny9pgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ecc728804f4920f37f22436b9870d7d3b65a2294" title="Why the difference in surface finish? " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Why does the same part have a different surface finish when printed on different printers with the same filament? The left was printed on an ender 3 and the right was printed on a Bambu a1. Does it have to do with the material of the nozzle? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/left-handed-frog"> /u/left-handed-frog </a> <br /> <span><a href="https://i.redd.it/mwrz1fny9pgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek3v5d/why_the_difference_in_surface_finish/">[comments]</a></span> </td></tr

## Ordered 6 nozzles on Amazon, someone messed up D-x
 - [https://www.reddit.com/r/3Dprinting/comments/1ek3rep/ordered_6_nozzles_on_amazon_someone_messed_up_dx](https://www.reddit.com/r/3Dprinting/comments/1ek3rep/ordered_6_nozzles_on_amazon_someone_messed_up_dx)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T19:34:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ek3rep/ordered_6_nozzles_on_amazon_someone_messed_up_dx/"> <img alt="Ordered 6 nozzles on Amazon, someone messed up D-x" src="https://b.thumbs.redditmedia.com/tkzAnN_ZPF73yZmoCS8lSEGY-I3mAjN4MCzbq2zHHXg.jpg" title="Ordered 6 nozzles on Amazon, someone messed up D-x" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Yes I'm going to try and return them</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ProdigalSun92"> /u/ProdigalSun92 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ek3rep">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek3rep/ordered_6_nozzles_on_amazon_someone_messed_up_dx/">[comments]</a></span> </td></tr></table>

## Working Pokemon Sky Pillar 3D print!
 - [https://www.reddit.com/r/3Dprinting/comments/1ek2vhj/working_pokemon_sky_pillar_3d_print](https://www.reddit.com/r/3Dprinting/comments/1ek2vhj/working_pokemon_sky_pillar_3d_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T18:58:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ek2vhj/working_pokemon_sky_pillar_3d_print/"> <img alt="Working Pokemon Sky Pillar 3D print!" src="https://b.thumbs.redditmedia.com/82WV-Jdvp9keKfim5umIw5m4eHGn2cu8_XVoRXz-ltA.jpg" title="Working Pokemon Sky Pillar 3D print!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This piece took a long time! Sadly this subreddit doesn’t allow video uploads so you can’t see it in action. Inspired by the art from @anima_nel on X and @pokemonshields on IG</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mushroom-burger"> /u/mushroom-burger </a> <br /> <span><a href="https://www.reddit.com/gallery/1ek2vhj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek2vhj/working_pokemon_sky_pillar_3d_print/">[comments]</a></span> </td></tr></table>

## Best CAD software for a beginner?
 - [https://www.reddit.com/r/3Dprinting/comments/1ek2cfr/best_cad_software_for_a_beginner](https://www.reddit.com/r/3Dprinting/comments/1ek2cfr/best_cad_software_for_a_beginner)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T18:36:32+00:00

<!-- SC_OFF --><div class="md"><p>I’m recently looking into 3D modeling and I’m ready to jump in and try using some CAD software. What’s your guys opinions on the software what would be the easiest and quickest way to start modeling! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Top-Reason7778"> /u/Top-Reason7778 </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek2cfr/best_cad_software_for_a_beginner/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek2cfr/best_cad_software_for_a_beginner/">[comments]</a></span>

## Need help finding an STL
 - [https://www.reddit.com/r/3Dprinting/comments/1ek22mg/need_help_finding_an_stl](https://www.reddit.com/r/3Dprinting/comments/1ek22mg/need_help_finding_an_stl)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T18:25:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ek22mg/need_help_finding_an_stl/"> <img alt="Need help finding an STL" src="https://preview.redd.it/f7drkr4swogd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3fc66c605e3751a8d8673065430be45386a6f19c" title="Need help finding an STL" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Can someone help me find an stl of this? Thanks </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rcav36101"> /u/Rcav36101 </a> <br /> <span><a href="https://i.redd.it/f7drkr4swogd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek22mg/need_help_finding_an_stl/">[comments]</a></span> </td></tr></table>

## PLA Print with UV Resin coating
 - [https://www.reddit.com/r/3Dprinting/comments/1ek1oty/pla_print_with_uv_resin_coating](https://www.reddit.com/r/3Dprinting/comments/1ek1oty/pla_print_with_uv_resin_coating)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T18:09:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ek1oty/pla_print_with_uv_resin_coating/"> <img alt="PLA Print with UV Resin coating" src="https://b.thumbs.redditmedia.com/nsCoP58P3uhYyy6vF1W_OFDZ6OUX73fbMETpWpj9s1Q.jpg" title="PLA Print with UV Resin coating" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Not my file, but my first attempt with UV resin to smooth layer lines. No sanding or crazy changes to the G-code. Just printed at standard Bambu A1 settings and coated it with resin with about 2 drops of Tamiya acrylic black paint mixed in to make it a wash to highlight the curvature. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Jpzmogan"> /u/Jpzmogan </a> <br /> <span><a href="https://www.reddit.com/gallery/1ek1oty">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek1oty/pla_print_with_uv_resin_coating/">[comments]</a></span> </td></tr></table>

## This one turned out pretty sweet.
 - [https://www.reddit.com/r/3Dprinting/comments/1ek1n09/this_one_turned_out_pretty_sweet](https://www.reddit.com/r/3Dprinting/comments/1ek1n09/this_one_turned_out_pretty_sweet)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T18:06:58+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/bedlamthreadz"> /u/bedlamthreadz </a> <br /> <span><a href="https://v.redd.it/by18mdk2qogd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek1n09/this_one_turned_out_pretty_sweet/">[comments]</a></span>

## Spent a few hrs yesterday trying to figure out why my silk PLA wouldn't stick to the bed...
 - [https://www.reddit.com/r/3Dprinting/comments/1ek0l6k/spent_a_few_hrs_yesterday_trying_to_figure_out](https://www.reddit.com/r/3Dprinting/comments/1ek0l6k/spent_a_few_hrs_yesterday_trying_to_figure_out)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T17:23:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ek0l6k/spent_a_few_hrs_yesterday_trying_to_figure_out/"> <img alt="Spent a few hrs yesterday trying to figure out why my silk PLA wouldn't stick to the bed... " src="https://a.thumbs.redditmedia.com/njgJMr6tSOnovdWP3otD_LrIu-3LJlT6nF6L6QfVwe8.jpg" title="Spent a few hrs yesterday trying to figure out why my silk PLA wouldn't stick to the bed... " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Jtparm"> /u/Jtparm </a> <br /> <span><a href="https://www.reddit.com/gallery/1ek0l6k">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ek0l6k/spent_a_few_hrs_yesterday_trying_to_figure_out/">[comments]</a></span> </td></tr></table>

## Has anyone used bone-white filament for lithopanes?
 - [https://www.reddit.com/r/3Dprinting/comments/1ejzq8y/has_anyone_used_bonewhite_filament_for_lithopanes](https://www.reddit.com/r/3Dprinting/comments/1ejzq8y/has_anyone_used_bonewhite_filament_for_lithopanes)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T16:46:54+00:00

<!-- SC_OFF --><div class="md"><p>I've only ever printed lithopanes with regular whites, and I'd like to try it in bone white, but before I order the filament, will the image show well enough or is too dark? Specifically referring to eSun PLA+ Bone White.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BlackJackT"> /u/BlackJackT </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejzq8y/has_anyone_used_bonewhite_filament_for_lithopanes/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejzq8y/has_anyone_used_bonewhite_filament_for_lithopanes/">[comments]</a></span>

## Can I ditch the spool holder and instead run my filament directly from the bar above the printer?
 - [https://www.reddit.com/r/3Dprinting/comments/1ejx5cq/can_i_ditch_the_spool_holder_and_instead_run_my](https://www.reddit.com/r/3Dprinting/comments/1ejx5cq/can_i_ditch_the_spool_holder_and_instead_run_my)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T14:56:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejx5cq/can_i_ditch_the_spool_holder_and_instead_run_my/"> <img alt="Can I ditch the spool holder and instead run my filament directly from the bar above the printer?" src="https://preview.redd.it/vck5zzdjvngd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=48320878df219947357a3f72e02111145ae8b4cb" title="Can I ditch the spool holder and instead run my filament directly from the bar above the printer?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Title. Just think it'd be convenient, and it'd give me some extra vertical space to add another shelf in here too.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Gixin1083"> /u/Gixin1083 </a> <br /> <span><a href="https://i.redd.it/vck5zzdjvngd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejx5cq/can_i_ditch_the_spool_holder_and_instead_run_my/">[comments]</a></span> </td></tr><

## 0.2mm is crazy!
 - [https://www.reddit.com/r/3Dprinting/comments/1ejwzkg/02mm_is_crazy](https://www.reddit.com/r/3Dprinting/comments/1ejwzkg/02mm_is_crazy)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T14:49:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejwzkg/02mm_is_crazy/"> <img alt="0.2mm is crazy!" src="https://b.thumbs.redditmedia.com/bJtP2j2kE_L7EAjIpVYQKfW4avNEH7YkqHazEpXD6MM.jpg" title="0.2mm is crazy!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Decided to redo the cursed Benchy to give it the quality it deserves </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MaskedPotat0"> /u/MaskedPotat0 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejwzkg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejwzkg/02mm_is_crazy/">[comments]</a></span> </td></tr></table>

## Help :/
 - [https://www.reddit.com/r/3Dprinting/comments/1ejuqok/help](https://www.reddit.com/r/3Dprinting/comments/1ejuqok/help)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T13:03:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejuqok/help/"> <img alt="Help :/" src="https://external-preview.redd.it/eWZybXVyNmFibmdkMc5ew2vckWj6VLSvggJPfB77OD5KCT5Z0UKYA4Uqbf4l.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c92b68680df14c88ceebdea4d910a334cec4c358" title="Help :/" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hi, I have had my 3d Printer for a Year now and it is making an awfull Sound for whatever reason. Could it be the bed leveling? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SafeWalk2209"> /u/SafeWalk2209 </a> <br /> <span><a href="https://v.redd.it/q94pkkcabngd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejuqok/help/">[comments]</a></span> </td></tr></table>

## Should I replace now my Nozzle
 - [https://www.reddit.com/r/3Dprinting/comments/1ejum05/should_i_replace_now_my_nozzle](https://www.reddit.com/r/3Dprinting/comments/1ejum05/should_i_replace_now_my_nozzle)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T12:56:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejum05/should_i_replace_now_my_nozzle/"> <img alt="Should I replace now my Nozzle" src="https://preview.redd.it/l3lsogw4angd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d47eb37671c99968fba88c462867bf0135b2cd64" title="Should I replace now my Nozzle" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This my nozzle in my Ender-3 V2</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mysterious_Sea_9951"> /u/Mysterious_Sea_9951 </a> <br /> <span><a href="https://i.redd.it/l3lsogw4angd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejum05/should_i_replace_now_my_nozzle/">[comments]</a></span> </td></tr></table>

## What program and process are you all using to make the hole patterns in a curved surface like this?
 - [https://www.reddit.com/r/3Dprinting/comments/1ejtspg/what_program_and_process_are_you_all_using_to](https://www.reddit.com/r/3Dprinting/comments/1ejtspg/what_program_and_process_are_you_all_using_to)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T12:12:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejtspg/what_program_and_process_are_you_all_using_to/"> <img alt="What program and process are you all using to make the hole patterns in a curved surface like this?" src="https://preview.redd.it/03h2u58a2ngd1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=074eae82085ba4030d3bedfa13df9bf310e8ad54" title="What program and process are you all using to make the hole patterns in a curved surface like this?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'd like to creat some desiccant boxes for my filament storage, but I'm unsure of how to create the holes. I have been using Tinkercad, but I'm able to use and willing to learn other cloud-based programs.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JustMakinStuff"> /u/JustMakinStuff </a> <br /> <span><a href="https://i.redd.it/03h2u58a2ngd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprintin

## My printer doesn't print the first layer normally and instead makes this weird texture. Can someone please help?
 - [https://www.reddit.com/r/3Dprinting/comments/1ejtm0k/my_printer_doesnt_print_the_first_layer_normally](https://www.reddit.com/r/3Dprinting/comments/1ejtm0k/my_printer_doesnt_print_the_first_layer_normally)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T12:02:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejtm0k/my_printer_doesnt_print_the_first_layer_normally/"> <img alt="My printer doesn't print the first layer normally and instead makes this weird texture. Can someone please help?" src="https://preview.redd.it/gv94tgnc0ngd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d0eb26577947f10af3dc414de8f1452a4fd892fa" title="My printer doesn't print the first layer normally and instead makes this weird texture. Can someone please help?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PeGameses"> /u/PeGameses </a> <br /> <span><a href="https://i.redd.it/gv94tgnc0ngd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejtm0k/my_printer_doesnt_print_the_first_layer_normally/">[comments]</a></span> </td></tr></table>

## Now that 3d builder has been dropped from the Microsoft store
 - [https://www.reddit.com/r/3Dprinting/comments/1ejsn7d/now_that_3d_builder_has_been_dropped_from_the](https://www.reddit.com/r/3Dprinting/comments/1ejsn7d/now_that_3d_builder_has_been_dropped_from_the)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T11:02:25+00:00

<!-- SC_OFF --><div class="md"><p>That effectively kills 3d builder. I teach some folks some introductory classes on 3d modeling. What would people recommend as a lower end entry point?</p> <p>I am thinking about TinkerCAD. These folks are not ready for fusion... Thoughts?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cebess"> /u/cebess </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejsn7d/now_that_3d_builder_has_been_dropped_from_the/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejsn7d/now_that_3d_builder_has_been_dropped_from_the/">[comments]</a></span>

## I'm gonna roll the dice for all of us.
 - [https://www.reddit.com/r/3Dprinting/comments/1ejsb3b/im_gonna_roll_the_dice_for_all_of_us](https://www.reddit.com/r/3Dprinting/comments/1ejsb3b/im_gonna_roll_the_dice_for_all_of_us)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T10:40:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejsb3b/im_gonna_roll_the_dice_for_all_of_us/"> <img alt="I'm gonna roll the dice for all of us." src="https://preview.redd.it/44g8eq1nlmgd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0436a5f37d9347590911a766e1492c8d66db9a2a" title="I'm gonna roll the dice for all of us." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/aruby727"> /u/aruby727 </a> <br /> <span><a href="https://i.redd.it/44g8eq1nlmgd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejsb3b/im_gonna_roll_the_dice_for_all_of_us/">[comments]</a></span> </td></tr></table>

## 3D printing service with free shipping and no minimum order
 - [https://www.reddit.com/r/3Dprinting/comments/1ejrgm8/3d_printing_service_with_free_shipping_and_no](https://www.reddit.com/r/3Dprinting/comments/1ejrgm8/3d_printing_service_with_free_shipping_and_no)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T09:40:55+00:00

<!-- SC_OFF --><div class="md"><p>Hello !</p> <p>I am looking for a 3D printing service but without minimum order and free shipping. I know in China websites shipping have always free shippping for small objects but I cannot find one for 3D printing.</p> <p>I only want to print in quantity 1 so I don't want to have minimum order or shipping more expansive than the price of the object. Shipping in a &quot;standard letter with air bubbles&quot; is good for me. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jvachez"> /u/jvachez </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejrgm8/3d_printing_service_with_free_shipping_and_no/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejrgm8/3d_printing_service_with_free_shipping_and_no/">[comments]</a></span>

## Skippy the 3D printed RC boat has passed her float test. Can't wait for the electronics to arrive. Twin jets should be fun.
 - [https://www.reddit.com/r/3Dprinting/comments/1ejrbcl/skippy_the_3d_printed_rc_boat_has_passed_her](https://www.reddit.com/r/3Dprinting/comments/1ejrbcl/skippy_the_3d_printed_rc_boat_has_passed_her)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T09:30:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejrbcl/skippy_the_3d_printed_rc_boat_has_passed_her/"> <img alt="Skippy the 3D printed RC boat has passed her float test. Can't wait for the electronics to arrive. Twin jets should be fun." src="https://external-preview.redd.it/MzVmYm50MWQ5bWdkMf6_E_1KsxlvBTXdy1GL8J3kHSxOmCx-O9yLqW6wD8-W.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=2f7fd5fe4da4569d1516b3f495aefc453afca26c" title="Skippy the 3D printed RC boat has passed her float test. Can't wait for the electronics to arrive. Twin jets should be fun." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Yota_Mota"> /u/Yota_Mota </a> <br /> <span><a href="https://v.redd.it/lxos2gbd9mgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejrbcl/skippy_the_3d_printed_rc_boat_has_passed_her/">[comments]</a></span> </td></tr></table>

## How to smooth my rough bottom?
 - [https://www.reddit.com/r/3Dprinting/comments/1ejpn2f/how_to_smooth_my_rough_bottom](https://www.reddit.com/r/3Dprinting/comments/1ejpn2f/how_to_smooth_my_rough_bottom)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T07:32:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejpn2f/how_to_smooth_my_rough_bottom/"> <img alt="How to smooth my rough bottom?" src="https://b.thumbs.redditmedia.com/u93b7YaU_7MT8fUOMDUukTsSTOTl9FKXm7rUMiqP2cU.jpg" title="How to smooth my rough bottom?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>My printer (Elegoo Neptune 3 Plus) seems dialed in but the bottom of my prints that are on supports always come out looking rough.</p> <p>I printed this skull upside down to reduce supports on the teeth and face but the back looks awful. On this project I'm going to sand fill and paint, but for many others I won't and it sometimes affects parts fitting together. </p> <p>Any help is appreciated. Thanks!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sumthingawsum"> /u/sumthingawsum </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejpn2f">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting

## When you make a present for someone and you rather keep it yourself
 - [https://www.reddit.com/r/3Dprinting/comments/1ejp905/when_you_make_a_present_for_someone_and_you](https://www.reddit.com/r/3Dprinting/comments/1ejp905/when_you_make_a_present_for_someone_and_you)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T07:05:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejp905/when_you_make_a_present_for_someone_and_you/"> <img alt="When you make a present for someone and you rather keep it yourself" src="https://external-preview.redd.it/eHIxem1zZGhqbGdkMQFAAkeR2Z-hiOjpLxYB7IV0qnL5H10hLGUm6HDzgQNX.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0033dbad4de51c7ce2c514d62c50917f849b1b0a" title="When you make a present for someone and you rather keep it yourself" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>But they were certainly impressed, so that makes it worth </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/S1lentA0"> /u/S1lentA0 </a> <br /> <span><a href="https://v.redd.it/r1mvvnohjlgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejp905/when_you_make_a_present_for_someone_and_you/">[comments]</a></span> </td></tr></table>

## First ever 3d print
 - [https://www.reddit.com/r/3Dprinting/comments/1ejodop/first_ever_3d_print](https://www.reddit.com/r/3Dprinting/comments/1ejodop/first_ever_3d_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T06:08:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejodop/first_ever_3d_print/"> <img alt="First ever 3d print" src="https://b.thumbs.redditmedia.com/cxqo8icNbwWrHCRl_HibkruwUkfQWLyliVaBnnZfCJo.jpg" title="First ever 3d print" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just set up my first 3d printer Elegoo Neptune 4 Pro, don’t know if that’s a good or bad printer (got it as a gift). </p> <p>Anyways, I just printed whatever file was on the flashdrive and was wondering if it looks good or not. There’s some stringing but I don’t think it’s that bad. </p> <p>Any tips for 3d printing in general would be very helpful 😭🙏</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Euphoric-Target-6054"> /u/Euphoric-Target-6054 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejodop">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejodop/first_ever_3d_print/">[comments]</a></span> </td></tr

## My wife is finally happy with the printer purchase
 - [https://www.reddit.com/r/3Dprinting/comments/1ejntpg/my_wife_is_finally_happy_with_the_printer_purchase](https://www.reddit.com/r/3Dprinting/comments/1ejntpg/my_wife_is_finally_happy_with_the_printer_purchase)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T05:31:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejntpg/my_wife_is_finally_happy_with_the_printer_purchase/"> <img alt="My wife is finally happy with the printer purchase " src="https://a.thumbs.redditmedia.com/XrkZMW3uK4r02m3O6t8B5tf2Vwp5tuSO0VYZP8T2Bh0.jpg" title="My wife is finally happy with the printer purchase " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>We have a WiFi extender in our bedroom with a bright RGB indicator light that sometimes lit up the whole room at night, especially blinking red if the internet went out. It worked well otherwise, but the light was too much. So, we decided to replace it. Instead, I used my 3D printing skills to create a flap cover by combining multiple models. Now the light looks cooler in the dark and my wife is impressed with how well it works. Functional prints like these are what it's all about.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/gumgum_bazuka"> /u/gumgum_bazu

## First effective use of Rub n Buff
 - [https://www.reddit.com/r/3Dprinting/comments/1ejnrdy/first_effective_use_of_rub_n_buff](https://www.reddit.com/r/3Dprinting/comments/1ejnrdy/first_effective_use_of_rub_n_buff)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T05:27:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejnrdy/first_effective_use_of_rub_n_buff/"> <img alt="First effective use of Rub n Buff" src="https://b.thumbs.redditmedia.com/L9BVggG1C5vG40hOknvOWzsH3d4nWJs_zLjdMyNauJU.jpg" title="First effective use of Rub n Buff" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/skipperjohnn"> /u/skipperjohnn </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejnqui">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejnrdy/first_effective_use_of_rub_n_buff/">[comments]</a></span> </td></tr></table>

## Fully 3d printed RC boat. "Skippy" by 3Dsets. 53.5cm (21") long. Printed on Ender V3 KE.
 - [https://www.reddit.com/r/3Dprinting/comments/1ejmek5/fully_3d_printed_rc_boat_skippy_by_3dsets_535cm](https://www.reddit.com/r/3Dprinting/comments/1ejmek5/fully_3d_printed_rc_boat_skippy_by_3dsets_535cm)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T04:06:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejmek5/fully_3d_printed_rc_boat_skippy_by_3dsets_535cm/"> <img alt="Fully 3d printed RC boat. &quot;Skippy&quot; by 3Dsets. 53.5cm (21&quot;) long. Printed on Ender V3 KE." src="https://b.thumbs.redditmedia.com/4RmXionAXUkJmCU8fYOd2o9JeTqouKlKsm6Y-M2Ow7k.jpg" title="Fully 3d printed RC boat. &quot;Skippy&quot; by 3Dsets. 53.5cm (21&quot;) long. Printed on Ender V3 KE." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Yota_Mota"> /u/Yota_Mota </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejmek5">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejmek5/fully_3d_printed_rc_boat_skippy_by_3dsets_535cm/">[comments]</a></span> </td></tr></table>

## My p1s hot end snapped off mid print
 - [https://www.reddit.com/r/3Dprinting/comments/1ejkcj3/my_p1s_hot_end_snapped_off_mid_print](https://www.reddit.com/r/3Dprinting/comments/1ejkcj3/my_p1s_hot_end_snapped_off_mid_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T02:13:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejkcj3/my_p1s_hot_end_snapped_off_mid_print/"> <img alt="My p1s hot end snapped off mid print " src="https://preview.redd.it/pi7g3mwe3kgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d37d01086501ff154d4252f0571c90afc0b6d2df" title="My p1s hot end snapped off mid print " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CandlesARG"> /u/CandlesARG </a> <br /> <span><a href="https://i.redd.it/pi7g3mwe3kgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejkcj3/my_p1s_hot_end_snapped_off_mid_print/">[comments]</a></span> </td></tr></table>

## Finally upgraded
 - [https://www.reddit.com/r/3Dprinting/comments/1ejkaeb/finally_upgraded](https://www.reddit.com/r/3Dprinting/comments/1ejkaeb/finally_upgraded)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T02:10:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejkaeb/finally_upgraded/"> <img alt="Finally upgraded" src="https://external-preview.redd.it/cTJqZnZ2dHAya2dkMaUYwI6YQitsiGSSfttvm2BQC5Io2OvjmwjDs8SM_Fjs.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f82bb482390e087274ce59c21f26e146068de098" title="Finally upgraded" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Went from ender 3 many years ago to the ender 3v2 a few years back then an anycubic, then an anycubic resin and now I just bout my first bamboo labs A1 combo. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Able-Tangelo8480"> /u/Able-Tangelo8480 </a> <br /> <span><a href="https://v.redd.it/16hpc5zp2kgd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejkaeb/finally_upgraded/">[comments]</a></span> </td></tr></table>

## Fallout Cosplay Props
 - [https://www.reddit.com/r/3Dprinting/comments/1ejjery/fallout_cosplay_props](https://www.reddit.com/r/3Dprinting/comments/1ejjery/fallout_cosplay_props)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T01:24:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejjery/fallout_cosplay_props/"> <img alt="Fallout Cosplay Props" src="https://b.thumbs.redditmedia.com/AhvtVE61PnkNo7NQlhNW-ZNCIcsj7ghwYXilC2dAtsI.jpg" title="Fallout Cosplay Props" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Went to SDCC as a vault dweller and these are the props we printed painted and used.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BigEnvironmental4429"> /u/BigEnvironmental4429 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejjery">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejjery/fallout_cosplay_props/">[comments]</a></span> </td></tr></table>

## benchy off 12 year old printer (150mm/s-300mm/s)
 - [https://www.reddit.com/r/3Dprinting/comments/1ejj2ri/benchy_off_12_year_old_printer_150mms300mms](https://www.reddit.com/r/3Dprinting/comments/1ejj2ri/benchy_off_12_year_old_printer_150mms300mms)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T01:07:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejj2ri/benchy_off_12_year_old_printer_150mms300mms/"> <img alt="benchy off 12 year old printer (150mm/s-300mm/s)" src="https://external-preview.redd.it/Z3Q4cGIwN2tyamdkMe9ePgLsHdxleLLGDsvQtlt54EHvnzvftUDw1XwmTHnE.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=b1fe40e9be4abe0dc99ad2f3d695ec226d0906f5" title="benchy off 12 year old printer (150mm/s-300mm/s)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>benchy off a stock 12 year old printer i got for free cuz it was “broken” off facebook marketplace… do better new companies. why are 3d printers getting worse in build quality and why are companies slowly moving towards less accessible firmwares???? i like that 3d printers have gotten cheaper but at what cost? why aren’t we as a community pushing to buy older printers and just updating them a little and running it off new slicers which kick ass compared to when those printers originally came out. isn’t that s

## A larger than usual dummy 13 😁 A1 for scale
 - [https://www.reddit.com/r/3Dprinting/comments/1ejj1vu/a_larger_than_usual_dummy_13_a1_for_scale](https://www.reddit.com/r/3Dprinting/comments/1ejj1vu/a_larger_than_usual_dummy_13_a1_for_scale)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T01:06:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejj1vu/a_larger_than_usual_dummy_13_a1_for_scale/"> <img alt="A larger than usual dummy 13 😁 A1 for scale" src="https://preview.redd.it/zv5ulz4erjgd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d460c4081186eda04983af1b603df1dbf1461c8b" title="A larger than usual dummy 13 😁 A1 for scale" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ActuaryProof1998"> /u/ActuaryProof1998 </a> <br /> <span><a href="https://i.redd.it/zv5ulz4erjgd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejj1vu/a_larger_than_usual_dummy_13_a1_for_scale/">[comments]</a></span> </td></tr></table>

## 3D Printing + Painting = Fun
 - [https://www.reddit.com/r/3Dprinting/comments/1ejis57/3d_printing_painting_fun](https://www.reddit.com/r/3Dprinting/comments/1ejis57/3d_printing_painting_fun)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T00:52:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejis57/3d_printing_painting_fun/"> <img alt="3D Printing + Painting = Fun" src="https://b.thumbs.redditmedia.com/1FUeM4Zu0AXrGxX9IBGY9CIJzCgtdIjXJQOWZAVlp-s.jpg" title="3D Printing + Painting = Fun" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>A buddy wanted me to print a rattle snake but paint it up a bit like a green tree viper. So I did. </p> <p>If you’ve ever thought of painting a print but have been scared, don’t be. Go buy a brush and some cheap craft paints and have fun. It’s super cool what you can make. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/_SmokeInternational_"> /u/_SmokeInternational_ </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejis57">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejis57/3d_printing_painting_fun/">[comments]</a></span> </td></tr></table>

## I designed and printed a coupler for a grey water hose and printed with a 1mm nozzle
 - [https://www.reddit.com/r/3Dprinting/comments/1ejirlm/i_designed_and_printed_a_coupler_for_a_grey_water](https://www.reddit.com/r/3Dprinting/comments/1ejirlm/i_designed_and_printed_a_coupler_for_a_grey_water)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-04T00:51:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ejirlm/i_designed_and_printed_a_coupler_for_a_grey_water/"> <img alt="I designed and printed a coupler for a grey water hose and printed with a 1mm nozzle" src="https://b.thumbs.redditmedia.com/HLT_gAAiVMa2IO0FPUU5C9F3U2kaoOzq6RW9DVPj2DI.jpg" title="I designed and printed a coupler for a grey water hose and printed with a 1mm nozzle" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cosmicdrift"> /u/cosmicdrift </a> <br /> <span><a href="https://www.reddit.com/gallery/1ejirlm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ejirlm/i_designed_and_printed_a_coupler_for_a_grey_water/">[comments]</a></span> </td></tr></table>

