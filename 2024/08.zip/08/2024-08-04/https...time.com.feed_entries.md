# Source:TIME, URL:https://time.com/feed, language:en-UK

## Team USA’s Noah Lyles, the World’s Fastest Man, Wins 100 M Olympic Gold
 - [https://time.com/7007483/team-usa-noah-lyles-wins-100-m-olympic-gold](https://time.com/7007483/team-usa-noah-lyles-wins-100-m-olympic-gold)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-04T19:57:39+00:00

Team USA's Noah Lyles, the defending world champion in the 100 m, won the Olympic gold medal in that race in Paris.

## Simone Biles Makes Public Plea Amid Triumphant Gold Medal Wins at Olympics
 - [https://time.com/7007579/simone-biles-public-plea-gold-medal-wins-olympics-paris](https://time.com/7007579/simone-biles-public-plea-gold-medal-wins-olympics-paris)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-04T18:27:16+00:00

Simone Biles made a plea for people to stop asking one particular question from athletes who are in the thrills of a medal win.

## Gymnast Sunisa Lee Earns Her Sixth Olympic Medal
 - [https://time.com/7007541/gymnast-sunisa-lee-earns-sixth-olympic-medal](https://time.com/7007541/gymnast-sunisa-lee-earns-sixth-olympic-medal)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-04T16:52:02+00:00

“I am just having a blast here,” the two-time Olympian said.

## U.K. Leader Condemns Attack on Asylum-Seeker Hotel as Far-Right Violence Spreads
 - [https://time.com/7007560/uk-prime-minister-keir-starmer-condemns-far-right-violence](https://time.com/7007560/uk-prime-minister-keir-starmer-condemns-far-right-violence)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-04T16:39:09+00:00

U.K. Prime Minister Keir Starmer strongly condemned an attack Sunday on a hotel housing asylum seekers.

## Novak Djokovic Grabbed the Only Thing Missing on His Mantle, an Olympic Gold Medal
 - [https://time.com/7007543/novak-djokovic-olympics-gold-medal-win](https://time.com/7007543/novak-djokovic-olympics-gold-medal-win)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-04T15:42:45+00:00

Novak Djokovic, the all-time leader in men’s Grand Slam singles titles, with 24, won his first Olympic gold medal on Sunday.

## Jamaica’s Shericka Jackson Pulls Out of Olympic 200-M Race. Here’s What We Know
 - [https://time.com/7007518/jamaica-shericka-jackson-withdraws-200m-race-olympics-reason-why](https://time.com/7007518/jamaica-shericka-jackson-withdraws-200m-race-olympics-reason-why)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-04T14:18:11+00:00

Two-time reigning 200 m world champion Shericka Jackson won't race for an individual medal at the Paris Summer Olympics.

## Lin Yu-Ting of Taiwan Clinches First Olympic Medal Amid Outcry Tied to Gender Misconceptions
 - [https://time.com/7007487/lin-yu-ting-taiwan-first-olympic-medal-gender-controversy-paris](https://time.com/7007487/lin-yu-ting-taiwan-first-olympic-medal-gender-controversy-paris)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-04T11:01:15+00:00

Boxer Lin Yu-ting of Taiwan clinched her first Olympic medal Sunday in front of a crowd that chanted her name.

