# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Harris’s Brother-in-Law Tony West, an Uber Executive, is a Key Adviser
 - [https://www.nytimes.com/2024/08/04/us/politics/kamala-harris-tony-west.html](https://www.nytimes.com/2024/08/04/us/politics/kamala-harris-tony-west.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-08-04T15:31:21+00:00

Tony West, the top lawyer for Uber, is weighing in on polling and running mates. His presence has made some liberals anxious.

