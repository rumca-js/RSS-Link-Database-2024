# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## As race riots escalate, British PM threatens dire consequences
 - [https://www.politico.eu/article/uk-british-pm-far-right-riot-race-keir-starmer-law-yvette-cooper-britain-mosques-muslim-violence-hate-southport/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/uk-british-pm-far-right-riot-race-keir-starmer-law-yvette-cooper-britain-mosques-muslim-violence-hate-southport/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T19:50:10+00:00

Far right rioters have targeted mosques and other buildings following the killing of three young girls in Southport last Monday.

## Ukraine has started flying long-awaited F-16s, Zelenskyy says
 - [https://www.politico.eu/article/ukraine-volodymyr-zelenskyy-f16-russia-war-fighter-jets/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/ukraine-volodymyr-zelenskyy-f16-russia-war-fighter-jets/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T15:14:35+00:00

A video clip posted by the Ukrainian president shows the U.S.-made fighter jets being flown by Ukrainian pilots.

## Turkish Cypriot leader says no reason for UN-led Cyprus talks
 - [https://www.politico.eu/article/turkey-ersin-tatar-cyprus-greece-no-reason-for-un-led-talks/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/turkey-ersin-tatar-cyprus-greece-no-reason-for-un-led-talks/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T13:10:10+00:00

The U.N. is seeking a trilateral meeting on Aug. 13 to explore ways to resume Cyprus reunification negotiations.

## 7 EU countries press Venezuela to release voting records of contested election
 - [https://www.politico.eu/article/venezuela-nicolas-maduro-eu-leaders-voting-records-of-contested-election/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/venezuela-nicolas-maduro-eu-leaders-voting-records-of-contested-election/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T12:24:20+00:00

France, Germany, Italy, Spain, the Netherlands, Poland and Portugal urge the Venezuelan government to "release promptly all the tally sheets" from controversial vote.

## How Donald Trump — and Kamala Harris — could surprise on Ukraine
 - [https://www.politico.com/news/magazine/2024/08/04/trump-harris-ukraine-2024-00172279?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/magazine/2024/08/04/trump-harris-ukraine-2024-00172279?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T11:30:32+00:00

Whatever happens in November, the next president’s approach to Russia’s war on Ukraine will determine America’s broader role in the world.

## Trump congratulates Putin on ‘great’ hostage swap
 - [https://www.politico.eu/article/donald-trump-congratulates-vladimir-putin-on-great-hostage-swap/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/donald-trump-congratulates-vladimir-putin-on-great-hostage-swap/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T10:47:17+00:00

The Republican nominee painted the Russian leader as the clear winner of a historic prisoner swap that led to the release of several Americans.

## Judge rejects Trump’s claim of ‘vindictive’ prosecution by Biden allies
 - [https://www.politico.com/news/2024/08/03/trump-biden-tanya-chutkan-00172566?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/08/03/trump-biden-tanya-chutkan-00172566?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T10:17:48+00:00

U.S. District Judge Tanya Chutkan swept aside Donald Trump’s attempt to dismiss his Washington, D.C., criminal case, saying he repeatedly mischaracterized the charges against him.

## France joins countries urging citizens to leave Lebanon, as Hezbollah strikes Israel
 - [https://www.politico.eu/article/france-lebanon-hezbollah-hamas-israel/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/france-lebanon-hezbollah-hamas-israel/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T09:47:05+00:00

French nationals are pressed to leave Lebanon "as soon as possible" amid a "highly volatile security context."

## Priced out of housing, many younger disillusioned voters embrace populism
 - [https://www.politico.com/news/2024/08/03/unaffordable-housing-populism-00172552?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/08/03/unaffordable-housing-populism-00172552?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T08:41:28+00:00

The scarcity of affordable homes to buy or rent has raised enthusiasm for politicians campaigning against immigration — though other causes for the crunch abound.

## Trump goes low as Harris gains ground
 - [https://www.politico.com/news/2024/08/03/trump-harris-georgia-00172560?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/08/03/trump-harris-georgia-00172560?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T07:49:44+00:00

In a succession of crude social media posts, Trump called Harris “low IQ,” “dumb” and lacking “mental capacity.”

## Everyone wants a piece of the swapped prisoners’ story
 - [https://www.politico.com/news/2024/08/03/swapped-prisoners-russia-00172558?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/08/03/swapped-prisoners-russia-00172558?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-04T07:44:53+00:00

There are many perspectives, and even those that seem at odds can be true at the same time.

