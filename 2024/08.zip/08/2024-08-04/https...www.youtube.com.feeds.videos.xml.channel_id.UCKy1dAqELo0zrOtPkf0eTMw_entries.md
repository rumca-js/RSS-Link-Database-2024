# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Subservience - Official Trailer (2024) Megan Fox, Michele Morrone
 - [https://www.youtube.com/watch?v=BVIZIJlGeok](https://www.youtube.com/watch?v=BVIZIJlGeok)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-04T16:11:49+00:00

Subservience is a sci-fi thriller distributed by XYZ Films.

Subservience Alice, a lifelike artificially intelligent android, who can take care of any family and home. Looking for help with the housework, a struggling father purchases Alice after his wife becomes sick. Alice suddenly becomes self-aware and wants everything her new family has to offer, starting with the affection of her owner – and she’ll kill to get it.

Subservience stars Megan Fox, Michele Morrone, Madeline Zima, and more. The film is directed by S.K. Dale and written by Will Honley and April Maguire. 

Subservience is releasing On Digital and On Demand on September 13.

#Subservience #IGN

## Angelic: The Chaos Theatre - Exclusive Open Alpha Launch Trailer
 - [https://www.youtube.com/watch?v=W0YEQm-Z_p4](https://www.youtube.com/watch?v=W0YEQm-Z_p4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-04T14:00:21+00:00

Check out this new Angelic: The Chaos Theatre trailer, announcing that the upcoming strategy RPG's open multiplayer Alpha test begins on August 6, 2024.

Embark on a dangerous journey and build a formidable squad as you customise your heroes' appearances, abilities, and equipment. Join forces to team up with your friends and take on other players, or compete against evolving AI opponents. Get a look at some Angelic: The Chaos Theatre gameplay and see its strategic turn-based battles in action. Angelic: The Chaos Theatre is available to wishlist on Steam and Epic Games Store.

#Gaming #Games #IGN

