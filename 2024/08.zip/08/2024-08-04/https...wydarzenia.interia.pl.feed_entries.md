# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## W drogę uderzyła silna burza. Karambol na niemieckiej autostradzie
 - [https://wydarzenia.interia.pl/zagranica/news-w-droge-uderzyla-silna-burza-karambol-na-niemieckiej-autostr,nId,7750583](https://wydarzenia.interia.pl/zagranica/news-w-droge-uderzyla-silna-burza-karambol-na-niemieckiej-autostr,nId,7750583)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T20:29:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-w-droge-uderzyla-silna-burza-karambol-na-niemieckiej-autostr,nId,7750583"><img align="left" alt="W drogę uderzyła silna burza. Karambol na niemieckiej autostradzie" src="https://i.iplsc.com/w-droge-uderzyla-silna-burza-karambol-na-niemieckiej-autostr/000JKIXSORSQ95XB-C321.jpg" /></a>Potężny karambol na niemieckiej autostradzie A4 Drezno-Erfurt w pobliżu miejscowości Chemnitz w Saksonii. Na trasie zderzyło się 25 samochodów. Wiadomo o pięciu osobach rannych, w tym dwóch ciężko. Do wypadków doszło, gdy w drogę uderzyła bardzo intensywna burza.</p><br clear="all" />

## Kto najlepszym premierem XXI wieku? Polacy wybrali w sondażu
 - [https://wydarzenia.interia.pl/kraj/news-kto-najlepszym-premierem-xxi-wieku-polacy-wybrali-w-sondazu,nId,7750568](https://wydarzenia.interia.pl/kraj/news-kto-najlepszym-premierem-xxi-wieku-polacy-wybrali-w-sondazu,nId,7750568)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T19:58:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kto-najlepszym-premierem-xxi-wieku-polacy-wybrali-w-sondazu,nId,7750568"><img align="left" alt="Kto najlepszym premierem XXI wieku? Polacy wybrali w sondażu" src="https://i.iplsc.com/kto-najlepszym-premierem-xxi-wieku-polacy-wybrali-w-sondazu/000JKIPN39Y70F6M-C321.jpg" /></a>Za najlepszego premiera XXI wieku 27,6 proc. ankietowanych uważa Donalda Tuska - wynika z najnowszego sondażu United Surveys. Na drugim miejscu uplasował się Mateusz Morawiecki z wynikiem 24,6 proc. Podium również zamyka polityk Prawa i Sprawiedliwości. Na Beatę Szydło wskazało 8,2 proc. respondentów.</p><br clear="all" />

## Pilne przygotowania do obrony w Izraelu. Media wskazują czas ataku
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-pilne-przygotowania-do-obrony-w-izraelu-media-wskazuja-czas-,nId,7750563](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-pilne-przygotowania-do-obrony-w-izraelu-media-wskazuja-czas-,nId,7750563)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T19:11:39+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-pilne-przygotowania-do-obrony-w-izraelu-media-wskazuja-czas-,nId,7750563"><img align="left" alt="Pilne przygotowania do obrony w Izraelu. Media wskazują czas ataku" src="https://i.iplsc.com/pilne-przygotowania-do-obrony-w-izraelu-media-wskazuja-czas/000JKISTSYGFTTMQ-C321.jpg" /></a>W Izraelu rozpoczęły się pilne przygotowania polityków i dowództwa wojskowego na wypadek ataków rakietowych ze strony Iranu i Hezbollahu. Uruchomiono między innymi procedury związane z alarmowaniem ludności cywilnej. Jak wynika z informacji portalu Axios, zmasowane uderzenie może nastąpić już w poniedziałek.</p><br clear="all" />

## 17-letnia Oliwia nie wróciła z wakacji. Trwają pilne poszukiwania
 - [https://wydarzenia.interia.pl/pomorskie/news-17-letnia-oliwia-nie-wrocila-z-wakacji-trwaja-pilne-poszukiw,nId,7750538](https://wydarzenia.interia.pl/pomorskie/news-17-letnia-oliwia-nie-wrocila-z-wakacji-trwaja-pilne-poszukiw,nId,7750538)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T18:42:14+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-17-letnia-oliwia-nie-wrocila-z-wakacji-trwaja-pilne-poszukiw,nId,7750538"><img align="left" alt="17-letnia Oliwia nie wróciła z wakacji. Trwają pilne poszukiwania" src="https://i.iplsc.com/17-letnia-oliwia-nie-wrocila-z-wakacji-trwaja-pilne-poszukiw/000JKII4OG6HX8D4-C321.jpg" /></a>Trwają poszukiwania Oliwii Jóźwiak z Rumi (woj. pomorskie). 17-latka nie wróciła z wakacyjnej przepustki do ośrodka opiekuńczego. Policja apeluje o kontakt do wszystkich osób, które widziały nastolatkę lub mają w sprawie przydatne informacje.
</p><br clear="all" />

## Myśliwce F-16 w Ukrainie, w Rosji poruszenie. "Z nami nie można żartować"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mysliwce-f-16-w-ukrainie-w-rosji-poruszenie-z-nami-nie-mozna,nId,7750531](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mysliwce-f-16-w-ukrainie-w-rosji-poruszenie-z-nami-nie-mozna,nId,7750531)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T18:12:07+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mysliwce-f-16-w-ukrainie-w-rosji-poruszenie-z-nami-nie-mozna,nId,7750531"><img align="left" alt="Myśliwce F-16 w Ukrainie, w Rosji poruszenie. &quot;Z nami nie można żartować&quot;" src="https://i.iplsc.com/mysliwce-f-16-w-ukrainie-w-rosji-poruszenie-z-nami-nie-mozna/000JKIM4TYBPLWQY-C321.jpg" /></a>- To nonsens. To nie koniec świata. Ile ich tam jest? Poważnie, przygotowujemy się - stwierdził Ramzan Kadyrow, odnoszą się do kwestii transferu myśliwców F-16 na Ukrainę. - Nie powinno się straszyć Rosjan tego typu informacjami - dodał przywódca Czeczenii. z Kolei wiceminister spraw zagranicznych Rosji Siergiej Riabkow ocenił, że przekazanie maszyn to &quot;eskalacja wojny ze strony Zachodu&quot;.</p><br clear="all" />

## Zacięta walka Harris i Trumpa. Minimalne różnice w najnowszym sondażu
 - [https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-zacieta-walka-harris-i-trumpa-minimalne-roznice-w-najnowszym,nId,7750499](https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-zacieta-walka-harris-i-trumpa-minimalne-roznice-w-najnowszym,nId,7750499)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T17:30:41+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-zacieta-walka-harris-i-trumpa-minimalne-roznice-w-najnowszym,nId,7750499"><img align="left" alt="Zacięta walka Harris i Trumpa. Minimalne różnice w najnowszym sondażu" src="https://i.iplsc.com/zacieta-walka-harris-i-trumpa-minimalne-roznice-w-najnowszym/000JKI4NA5UVULIQ-C321.jpg" /></a>Zacięta walka między Kamalą Harris a Donaldem Trumpem trwa w najlepsze, na co wskazuje najnowszy sondaż. Z badania przeprowadzonego na zlecenie CBS News wynika, że na demokratkę swój głos oddałoby 50 proc. ankietowanych. Jednak republikanin jest zaraz za nią z wynikiem 49 proc.</p><br clear="all" />

## Wulkan wywołał chaos na włoskim lotnisku. Samoloty do Polski z problemami
 - [https://wydarzenia.interia.pl/zagranica/news-wulkan-wywolal-chaos-na-wloskim-lotnisku-samoloty-do-polski-,nId,7750518](https://wydarzenia.interia.pl/zagranica/news-wulkan-wywolal-chaos-na-wloskim-lotnisku-samoloty-do-polski-,nId,7750518)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T16:55:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wulkan-wywolal-chaos-na-wloskim-lotnisku-samoloty-do-polski-,nId,7750518"><img align="left" alt="Wulkan wywołał chaos na włoskim lotnisku. Samoloty do Polski z problemami" src="https://i.iplsc.com/wulkan-wywolal-chaos-na-wloskim-lotnisku-samoloty-do-polski/000JKIEXSELS9WTE-C321.jpg" /></a>Wzmożona aktywność wulkanu Etna sparaliżowała chwilowo pracę lotniska w Katanii. Przekonali się o tym turyści z Polski, których samolot miał lądować w Katowicach o godz. 12:35, jednak w powietrze wzbił się we Włoszech dopiero około godz. 16. To spowodowało kolejne utrudnienia, tym razem dotyczące lotu z Polski do Katanii. Na katowickim lotnisku od godz. 13 czekało 171 pasażerów - ustaliła Interia.</p><br clear="all" />

## "Wiedzieli, że nie mają już dokąd wracać". Zobacz reportaż "Klucze"
 - [https://wydarzenia.interia.pl/historia/news-wiedzieli-ze-nie-maja-juz-dokad-wracac-zobacz-reportaz-klucz,nId,7747809](https://wydarzenia.interia.pl/historia/news-wiedzieli-ze-nie-maja-juz-dokad-wracac-zobacz-reportaz-klucz,nId,7747809)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T16:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/historia/news-wiedzieli-ze-nie-maja-juz-dokad-wracac-zobacz-reportaz-klucz,nId,7747809"><img align="left" alt="&quot;Wiedzieli, że nie mają już dokąd wracać&quot;. Zobacz reportaż &quot;Klucze&quot; " src="https://i.iplsc.com/wiedzieli-ze-nie-maja-juz-dokad-wracac-zobacz-reportaz-klucz/000JK2R47I0II3V7-C321.jpg" /></a>- Ludzie, wysiadając z pociągu, stawali na rampie i wyrzucali klucze do warszawskich mieszkań. To był rodzaj pożegnania z przeszłością i dowód, że wypędzeni mają świadomość, że nie mają do czego wracać - opowiada Małgorzata Bojanowska, dyrektorka Muzeum Dulag 121 w Pruszkowie. Poniżej publikujemy reportaż &quot;Klucze&quot; Stanisława Wryka, dziennikarza Polsat News i wnuka Edwarda Serwańskiego, inicjatora akcji &quot;Iskra Dog&quot; podczas Powstania Warszawskiego. </p><br clear="all" />

## Burza wokół Andrzeja Poczobuta. "Negocjacje toczą się innym trybem"
 - [https://wydarzenia.interia.pl/kraj/news-burza-wokol-andrzeja-poczobuta-negocjacje-tocza-sie-innym-tr,nId,7750483](https://wydarzenia.interia.pl/kraj/news-burza-wokol-andrzeja-poczobuta-negocjacje-tocza-sie-innym-tr,nId,7750483)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T16:15:37+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burza-wokol-andrzeja-poczobuta-negocjacje-tocza-sie-innym-tr,nId,7750483"><img align="left" alt="Burza wokół Andrzeja Poczobuta. &quot;Negocjacje toczą się innym trybem&quot;" src="https://i.iplsc.com/burza-wokol-andrzeja-poczobuta-negocjacje-tocza-sie-innym-tr/000JKI8K0PMYYYYY-C321.jpg" /></a>Negocjacje dotyczące uwolnienia Andrzeja Poczobuta toczą się innym trybem, bezpośrednio z Białorusią - przekazał wiceszef MSZ, odpowiadając na pytania dotyczące wielkiej wymiany więźniów w Ankarze. Po wydarzeniach w Turcji politycy opozycji zaczęli pytać, dlaczego polskim władzom nie udało się wynegocjować wolności dla polskiego działacza. - Uwzględniliśmy, poparliśmy i działaliśmy wedle prośby administracji pana prezydenta Joe Bidena - tłumaczył Szejna.</p><br clear="all" />

## Piekący skwar opanuje turystyczny raj. Szykują się na najgorętsze tygodnie
 - [https://wydarzenia.interia.pl/zagranica/news-piekacy-skwar-opanuje-turystyczny-raj-szykuja-sie-na-najgore,nId,7750466](https://wydarzenia.interia.pl/zagranica/news-piekacy-skwar-opanuje-turystyczny-raj-szykuja-sie-na-najgore,nId,7750466)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T15:39:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-piekacy-skwar-opanuje-turystyczny-raj-szykuja-sie-na-najgore,nId,7750466"><img align="left" alt="Piekący skwar opanuje turystyczny raj. Szykują się na najgorętsze tygodnie" src="https://i.iplsc.com/piekacy-skwar-opanuje-turystyczny-raj-szykuja-sie-na-najgore/000JKI3IS0M5SNT8-C321.jpg" /></a>Włochy od początku wakacji zmagają się z rekordowymi upałami. Jak się jednak okazuje, eksperci prognozują, że dopiero w tym miesiącu rozpocznie się najgorętszy okres tego lata. Mieszkańcy oraz turyści będą zmuszeni zmagać się z groźnymi skutkami upałów aż do połowy sierpnia.
</p><br clear="all" />

## Reżim odrzuca oferty pomocy. Nie chcą wsparcia nawet od Putina
 - [https://wydarzenia.interia.pl/zagranica/news-rezim-odrzuca-oferty-pomocy-nie-chca-wsparcia-nawet-od-putin,nId,7750490](https://wydarzenia.interia.pl/zagranica/news-rezim-odrzuca-oferty-pomocy-nie-chca-wsparcia-nawet-od-putin,nId,7750490)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T15:20:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rezim-odrzuca-oferty-pomocy-nie-chca-wsparcia-nawet-od-putin,nId,7750490"><img align="left" alt="Reżim odrzuca oferty pomocy. Nie chcą wsparcia nawet od Putina" src="https://i.iplsc.com/rezim-odrzuca-oferty-pomocy-nie-chca-wsparcia-nawet-od-putin/000JKI2ASKEAAJWY-C321.jpg" /></a>W związku ze zwalczaniem skutków potężnych powodzi, jakich doświadczyła Korea Północna, rząd otrzymał oferty pomocy. Jednak Kim Dzong Un nie chce wsparcia - odrzucił on propozycję od swojego sojusznika, jakim jest Władimir Putin. Prezydent Rosji zapewniał, że &quot;zawsze mogą na nich liczyć&quot;. Kim podziękował i podkreślił, że &quot;zwróci się o pomoc, jeśli okaże się to konieczne&quot;.</p><br clear="all" />

## Koniec spekulacji, są nagrania. Myśliwce F-16 na ukraińskim niebie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-koniec-spekulacji-sa-nagrania-mysliwce-f-16-na-ukrainskim-ni,nId,7750497](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-koniec-spekulacji-sa-nagrania-mysliwce-f-16-na-ukrainskim-ni,nId,7750497)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T15:03:31+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-koniec-spekulacji-sa-nagrania-mysliwce-f-16-na-ukrainskim-ni,nId,7750497"><img align="left" alt="Koniec spekulacji, są nagrania. Myśliwce F-16 na ukraińskim niebie" src="https://i.iplsc.com/koniec-spekulacji-sa-nagrania-mysliwce-f-16-na-ukrainskim-ni/000JKI7ZMS337P0W-C321.jpg" /></a>F-16 w Ukrainie. Jestem dumny ze wszystkich naszych chłopaków, którzy opanowują te samoloty i zaczęli już używać ich w naszym kraju - ogłosił Wołodymyr Zełenski. Prezydent Ukrainy w przemówieniu z okazji Dnia Sił Lotniczych oficjalnie potwierdził, że pierwsze zachodnie myśliwce są już do dyspozycji ukraińskiej armii.</p><br clear="all" />

## Pierwszy taki urząd w Polsce. Testują dyskutowane od dawna rozwiązanie
 - [https://wydarzenia.interia.pl/wielkopolskie/news-pierwszy-taki-urzad-w-polsce-testuja-dyskutowane-od-dawna-ro,nId,7747604](https://wydarzenia.interia.pl/wielkopolskie/news-pierwszy-taki-urzad-w-polsce-testuja-dyskutowane-od-dawna-ro,nId,7747604)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T14:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-pierwszy-taki-urzad-w-polsce-testuja-dyskutowane-od-dawna-ro,nId,7747604"><img align="left" alt="Pierwszy taki urząd w Polsce. Testują dyskutowane od dawna rozwiązanie" src="https://i.iplsc.com/pierwszy-taki-urzad-w-polsce-testuja-dyskutowane-od-dawna-ro/000JK9IAODU7EH6E-C321.jpg" /></a>O krótszym tygodniu pracy słyszymy od kilku miesięcy. Z tym hasłem na ustach szła do wyborów nie tylko Lewica, ale i Koalicja Obywatelska. Temat budzi wiele emocji. Urząd Miasta Leszna jako pierwszy w Polsce testuje krótszy tydzień pracy. Jak się sprawdza nowy system?  </p><br clear="all" />

## MSZ monitoruje sytuację. "Pełna gotowość do przeprowadzenia ewakuacji"
 - [https://wydarzenia.interia.pl/zagranica/news-msz-monitoruje-sytuacje-pelna-gotowosc-do-przeprowadzenia-ew,nId,7750477](https://wydarzenia.interia.pl/zagranica/news-msz-monitoruje-sytuacje-pelna-gotowosc-do-przeprowadzenia-ew,nId,7750477)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T14:00:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-msz-monitoruje-sytuacje-pelna-gotowosc-do-przeprowadzenia-ew,nId,7750477"><img align="left" alt="MSZ monitoruje sytuację. &quot;Pełna gotowość do przeprowadzenia ewakuacji&quot;" src="https://i.iplsc.com/msz-monitoruje-sytuacje-pelna-gotowosc-do-przeprowadzenia-ew/000JKHA062RMVK65-C321.jpg" /></a>- W razie eskalacji konfliktu na Bliskim Wschodzie polski rząd ma przygotowany plan szybkiej ewakuacji naszych obywateli, przy współpracy MSZ i MON - oświadczył wiceszef resortu spraw zagranicznych Andrzej Szejna. Dodał też, że służby dyplomatyczne i resort obrony &quot;są w pełnej gotowości&quot;. Szejna ponowił także apel do Polaków, w którym ostrzeżono przed podróżami do Libanu.</p><br clear="all" />

## Zmiany na rynku nieruchomości. Ważna informacja dla kupujących mieszkanie
 - [https://wydarzenia.interia.pl/kraj/news-zmiany-na-rynku-nieruchomosci-wazna-informacja-dla-kupujacyc,nId,7719092](https://wydarzenia.interia.pl/kraj/news-zmiany-na-rynku-nieruchomosci-wazna-informacja-dla-kupujacyc,nId,7719092)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T13:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiany-na-rynku-nieruchomosci-wazna-informacja-dla-kupujacyc,nId,7719092"><img align="left" alt="Zmiany na rynku nieruchomości. Ważna informacja dla kupujących mieszkanie " src="https://i.iplsc.com/zmiany-na-rynku-nieruchomosci-wazna-informacja-dla-kupujacyc/000I44IPYKVSB5UW-C321.jpg" /></a>Deweloperski Fundusz Gwarancyjny to rozwiązanie, z którym mogą się spotkać osoby planujące zakup mieszkania. Od lipca tego roku wszystkie osoby fizyczne zawierające umowy deweloperskie są objęte ochroną DFG. Na czym to polega? Wyjaśniamy.</p><br clear="all" />

## Silny wiatr porwał nagle dmuchany zamek. Nie żyje pięciolatek
 - [https://wydarzenia.interia.pl/zagranica/news-silny-wiatr-porwal-nagle-dmuchany-zamek-nie-zyje-pieciolatek,nId,7750458](https://wydarzenia.interia.pl/zagranica/news-silny-wiatr-porwal-nagle-dmuchany-zamek-nie-zyje-pieciolatek,nId,7750458)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T13:26:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-silny-wiatr-porwal-nagle-dmuchany-zamek-nie-zyje-pieciolatek,nId,7750458"><img align="left" alt="Silny wiatr porwał nagle dmuchany zamek. Nie żyje pięciolatek" src="https://i.iplsc.com/silny-wiatr-porwal-nagle-dmuchany-zamek-nie-zyje-pieciolatek/000JKH7MK9NGELR5-C321.jpg" /></a>Tragedia podczas meczu w USA. Nie żyje pięciolatek, który bawił się w dmuchanym zamku, gdy konstrukcję porwał wiatr. Ta wzniosła się na wysokość kilku metrów, a następnie uderzyła w ziemię. W zdarzeniu ucierpiał również inny kilkulatek, jednak nie odniósł on obrażeń zagrażających życiu.</p><br clear="all" />

## Podejrzany o spowodowanie głośnego wypadku już w Polsce. Wpadł w Paryżu
 - [https://wydarzenia.interia.pl/kraj/news-podejrzany-o-spowodowanie-glosnego-wypadku-juz-w-polsce-wpad,nId,7750439](https://wydarzenia.interia.pl/kraj/news-podejrzany-o-spowodowanie-glosnego-wypadku-juz-w-polsce-wpad,nId,7750439)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T11:41:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-podejrzany-o-spowodowanie-glosnego-wypadku-juz-w-polsce-wpad,nId,7750439"><img align="left" alt="Podejrzany o spowodowanie głośnego wypadku już w Polsce. Wpadł w Paryżu" src="https://i.iplsc.com/podejrzany-o-spowodowanie-glosnego-wypadku-juz-w-polsce-wpad/000JKH1AM73TX76B-C321.jpg" /></a>Do Polski przewieziony został 37-latek podejrzany o spowodowanie w 2020 r. na ul. Broniewskiego w Łodzi wypadku, w którym śmierć poniosły dwie osoby, a jedna w stanie ciężkim trafiła do szpitala. Mężczyzna ukrywał się od dnia wypadku i był poszukiwany Europejskim Nakazem Aresztowania. Został zatrzymany wiosną w Paryżu.</p><br clear="all" />

## Dramatyczne chwile na drodze. Nie żyje działacz PSL Marian Tokarski
 - [https://wydarzenia.interia.pl/lubelskie/news-dramatyczne-chwile-na-drodze-nie-zyje-dzialacz-psl-marian-to,nId,7750414](https://wydarzenia.interia.pl/lubelskie/news-dramatyczne-chwile-na-drodze-nie-zyje-dzialacz-psl-marian-to,nId,7750414)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T10:44:58+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-dramatyczne-chwile-na-drodze-nie-zyje-dzialacz-psl-marian-to,nId,7750414"><img align="left" alt="Dramatyczne chwile na drodze. Nie żyje działacz PSL Marian Tokarski" src="https://i.iplsc.com/dramatyczne-chwile-na-drodze-nie-zyje-dzialacz-psl-marian-to/000JKGSYD84TTMPO-C321.jpg" /></a>Nie żyje Marian Tokarski, były starosta powiatu biłgorajskiego, przez wiele lat działający w strukturach PSL. 74-latek zginął w tragicznym wypadku, do którego doszło w sobotę. Renault, którym podróżował, zderzyło się z ciężarówką. Mimo wysiłków medyków życia mężczyzny nie udało się uratować.</p><br clear="all" />

## Tragiczna sobota w Polsce. Coraz więcej czarnych punktów
 - [https://wydarzenia.interia.pl/kraj/news-tragiczna-sobota-w-polsce-coraz-wiecej-czarnych-punktow,nId,7750397](https://wydarzenia.interia.pl/kraj/news-tragiczna-sobota-w-polsce-coraz-wiecej-czarnych-punktow,nId,7750397)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T09:57:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tragiczna-sobota-w-polsce-coraz-wiecej-czarnych-punktow,nId,7750397"><img align="left" alt="Tragiczna sobota w Polsce. Coraz więcej czarnych punktów" src="https://i.iplsc.com/tragiczna-sobota-w-polsce-coraz-wiecej-czarnych-punktow/000JKGI6LLAL4UW2-C321.jpg" /></a>Tragiczna sobota na polskich drogach. W dziesięciu wypadkach drogowych zginęło jedenaście osób - poinformowała policja. W Starowlanach w województwie podlaskim doszło do śmierci w wyniku utonięcia. Tylko od początku wakacji odnotowano 242 wypadki ze skutkiem śmiertelnym.
</p><br clear="all" />

## Polski biskup zarządził modły za otwarcie igrzysk. "Szyderstwo"
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-polski-biskup-zarzadzil-modly-za-otwarcie-igrzysk-szyderstwo,nId,7750384](https://wydarzenia.interia.pl/swietokrzyskie/news-polski-biskup-zarzadzil-modly-za-otwarcie-igrzysk-szyderstwo,nId,7750384)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T09:05:38+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-polski-biskup-zarzadzil-modly-za-otwarcie-igrzysk-szyderstwo,nId,7750384"><img align="left" alt="Polski biskup zarządził modły za otwarcie igrzysk. &quot;Szyderstwo&quot;" src="https://i.iplsc.com/polski-biskup-zarzadzil-modly-za-otwarcie-igrzysk-szyderstwo/000JKG8CG9WSA3LN-C321.jpg" /></a>- Szyderstwo z 'Ostatniej Wieczerzy', dokonane podczas ceremonii otwarcia igrzysk olimpijskich w Paryżu, było celowym znieważeniem i wyszydzeniem naszych największych świętości - stwierdził biskup kielecki Jan Piotrowski. Duchowny zarządził odśpiewanie modlitwy błagalnej &quot;w celu wynagrodzenia Bogu&quot;. </p><br clear="all" />

## Burza wokół sojusznika Rosji. Polska dołączyła do apelu
 - [https://wydarzenia.interia.pl/zagranica/news-burza-wokol-sojusznika-rosji-polska-dolaczyla-do-apelu,nId,7750364](https://wydarzenia.interia.pl/zagranica/news-burza-wokol-sojusznika-rosji-polska-dolaczyla-do-apelu,nId,7750364)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T08:04:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-burza-wokol-sojusznika-rosji-polska-dolaczyla-do-apelu,nId,7750364"><img align="left" alt="Burza wokół sojusznika Rosji. Polska dołączyła do apelu" src="https://i.iplsc.com/burza-wokol-sojusznika-rosji-polska-dolaczyla-do-apelu/000JKG4CGFUX60GE-C321.jpg" /></a>Siedem państw Unii Europejskiej - w tym Polska - zaapelowały do Wenezueli o natychmiastową publikację dokumentów wyborczych. Po wyborach ogłoszono, że prezydent Nicolas Maduro ponownie został wybrany na tę funkcję. Opozycja twierdzi, że zwycięzcą głosowania jest Edmundo Gonzalez Urrutia. W kraju trwają wielkie protesty.</p><br clear="all" />

## Burze nie odpuszczają. Ostrzeżenia dla połowy kraju
 - [https://wydarzenia.interia.pl/kraj/news-burze-nie-odpuszczaja-ostrzezenia-dla-polowy-kraju,nId,7750359](https://wydarzenia.interia.pl/kraj/news-burze-nie-odpuszczaja-ostrzezenia-dla-polowy-kraju,nId,7750359)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T07:49:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burze-nie-odpuszczaja-ostrzezenia-dla-polowy-kraju,nId,7750359"><img align="left" alt="Burze nie odpuszczają. Ostrzeżenia dla połowy kraju" src="https://i.iplsc.com/burze-nie-odpuszczaja-ostrzezenia-dla-polowy-kraju/000JKG1PT2U3U2PH-C321.jpg" /></a>Silne burze i intensywne opady deszczu niemal w połowie kraju - ostrzega Instytut Meteorologii i Gospodarki Wodnej. Wyładowania atmosferyczne obserwowane będą w niedzielę w ośmiu województwach. Towarzyszyć może im mocny wiatr. Niebezpieczna pogoda utrzymywać ma się aż do końca dnia. Sprawdzamy, gdzie jest burza i kiedy można się jej spodziewać.</p><br clear="all" />

## Dyplomatyczny skandal. Ambasador Ukrainy wezwany na dywanik
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dyplomatyczny-skandal-ambasador-ukrainy-wezwany-na-dywanik,nId,7750352](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dyplomatyczny-skandal-ambasador-ukrainy-wezwany-na-dywanik,nId,7750352)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T07:27:37+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dyplomatyczny-skandal-ambasador-ukrainy-wezwany-na-dywanik,nId,7750352"><img align="left" alt="Dyplomatyczny skandal. Ambasador Ukrainy wezwany na dywanik" src="https://i.iplsc.com/dyplomatyczny-skandal-ambasador-ukrainy-wezwany-na-dywanik/000JKFYZWX2EV7C7-C321.jpg" /></a>Senegal ostro reaguje na wpis w mediach społecznościowych ambasadora Ukrainy w Dakarze. W tle jest sprawa rozbicia oddziału wagnerowców w Mali, którzy wpadli w zasadzkę Tuaregów.
</p><br clear="all" />

## Donald Trump gratuluje Władimirowi Putinowi. "Wspaniały interes"
 - [https://wydarzenia.interia.pl/zagranica/news-donald-trump-gratuluje-wladimirowi-putinowi-wspanialy-intere,nId,7750345](https://wydarzenia.interia.pl/zagranica/news-donald-trump-gratuluje-wladimirowi-putinowi-wspanialy-intere,nId,7750345)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T07:04:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-donald-trump-gratuluje-wladimirowi-putinowi-wspanialy-intere,nId,7750345"><img align="left" alt="Donald Trump gratuluje Władimirowi Putinowi. &quot;Wspaniały interes&quot;" src="https://i.iplsc.com/donald-trump-gratuluje-wladimirowi-putinowi-wspanialy-intere/000JKFYIJJ4XE5KD-C321.jpg" /></a>- Chciałbym pogratulować Władimirowi Putinowi kolejnego wspaniałego interesu - mówił Donald Trump podczas sobotniego wiecu wyborczego, w kontekście wymiany więźniów, do jakiej doszło w ubiegły czwartek w Ankarze. Zdaniem byłego amerykańskiego prezydenta, rosyjski przywódca zdołał &quot;przechytrzyć&quot; rząd USA.</p><br clear="all" />

## Złamana noga opakowana... w karton. Skandal na pogotowiu
 - [https://wydarzenia.interia.pl/zagranica/news-zlamana-noga-opakowana-w-karton-skandal-na-pogotowiu,nId,7750343](https://wydarzenia.interia.pl/zagranica/news-zlamana-noga-opakowana-w-karton-skandal-na-pogotowiu,nId,7750343)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T06:19:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zlamana-noga-opakowana-w-karton-skandal-na-pogotowiu,nId,7750343"><img align="left" alt="Złamana noga opakowana... w karton. Skandal na pogotowiu" src="https://i.iplsc.com/zlamana-noga-opakowana-w-karton-skandal-na-pogotowiu/000JKFWS3DJLFBBM-C321.jpg" /></a>Wielki skandal na pogotowiu w Mesynie na Sycylii. Gdy zabrakło szyn ortopedycznych, skorzystano z... kartonu. W ten sposób chciano pomóc mężczyźnie, który doznał złamania kości piszczelowej. - To jest niedopuszczalne. Ten, kto popełnił błąd, musi zapłacić - powiedział gubernator Renato Schifani. Zapadła już decyzja o konsekwencjach.</p><br clear="all" />

## Zakazy nad Bałykiem mogą zaskoczyć. Za co można dostać mandat na plaży?
 - [https://wydarzenia.interia.pl/ciekawostki/news-zakazy-nad-balykiem-moga-zaskoczyc-za-co-mozna-dostac-mandat,nId,7748496](https://wydarzenia.interia.pl/ciekawostki/news-zakazy-nad-balykiem-moga-zaskoczyc-za-co-mozna-dostac-mandat,nId,7748496)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T06:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-zakazy-nad-balykiem-moga-zaskoczyc-za-co-mozna-dostac-mandat,nId,7748496"><img align="left" alt="Zakazy nad Bałykiem mogą zaskoczyć. Za co można dostać mandat na plaży?" src="https://i.iplsc.com/zakazy-nad-balykiem-moga-zaskoczyc-za-co-mozna-dostac-mandat/000JK9EKQ7R8UNNC-C321.jpg" /></a>Czy na plaży można palić papierosy i rozpalić ognisko? Jak wygląda kwestia wprowadzania psów na plażę? Na te i wiele podobnych pytań dotyczących plażowania nad Bałtykiem warto znać odpowiedź jeszcze przed wyjazdem nad morze. Nieprzestrzeganie przepisów grozi mandatem. </p><br clear="all" />

## Rosjanie gromadzą siły. Ekspert: Przygotowują kolejny atak
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-gromadza-sily-ekspert-przygotowuja-kolejny-atak,nId,7750329](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-gromadza-sily-ekspert-przygotowuja-kolejny-atak,nId,7750329)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T05:43:11+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-gromadza-sily-ekspert-przygotowuja-kolejny-atak,nId,7750329"><img align="left" alt="Rosjanie gromadzą siły. Ekspert: Przygotowują kolejny atak" src="https://i.iplsc.com/rosjanie-gromadza-sily-ekspert-przygotowuja-kolejny-atak/000IX6BLVX3MTA18-C321.jpg" /></a>- Ukrywają się w piwnicach, w zniszczonych budynkach. Przygotowują się do przeprowadzenia kolejnego ataku, działań ofensywnych - twierdzi Oleg Żdanow. Ukraiński ekspert wojskowy przekonuje, że w najbliższym czasie Siły Zbrojne Ukrainy będą musiały sobie poradzić z kolejną próbą przełamania obrony w obwodzie charkowskim.</p><br clear="all" />

## Dramatyczne chwile na drodze. Ogromny pożar cysterny pod Płońskiem
 - [https://wydarzenia.interia.pl/mazowieckie/news-dramatyczne-chwile-na-drodze-ogromny-pozar-cysterny-pod-plon,nId,7750339](https://wydarzenia.interia.pl/mazowieckie/news-dramatyczne-chwile-na-drodze-ogromny-pozar-cysterny-pod-plon,nId,7750339)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T04:51:32+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-dramatyczne-chwile-na-drodze-ogromny-pozar-cysterny-pod-plon,nId,7750339"><img align="left" alt="Dramatyczne chwile na drodze. Ogromny pożar cysterny pod Płońskiem" src="https://i.iplsc.com/dramatyczne-chwile-na-drodze-ogromny-pozar-cysterny-pod-plon/000JKFUNSSNUC6TM-C321.jpg" /></a>Cysterna zderzyła się z samochodem osobowym na odcinku Płońsk - Nowe Miasto drogi wojewódzkiej nr 632. Doszło do wycieku i zapłonu ładunku z cysterny. Droga pozostaje zablokowana - powiedział asp. Artur Balcerski z Komendy Powiatowej Policji w Płońsku. Pasażerka osobówki trafiła do szpitala.</p><br clear="all" />

## Ostrzał rakietowy Izraela. Eksplozje rozświetliły niebo
 - [https://wydarzenia.interia.pl/zagranica/news-ostrzal-rakietowy-izraela-eksplozje-rozswietlily-niebo,nId,7750337](https://wydarzenia.interia.pl/zagranica/news-ostrzal-rakietowy-izraela-eksplozje-rozswietlily-niebo,nId,7750337)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-04T04:20:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ostrzal-rakietowy-izraela-eksplozje-rozswietlily-niebo,nId,7750337"><img align="left" alt="Ostrzał rakietowy Izraela. Eksplozje rozświetliły niebo" src="https://i.iplsc.com/ostrzal-rakietowy-izraela-eksplozje-rozswietlily-niebo/000JKFTJGH0JP1XM-C321.jpg" /></a>Libański Hezbollah wystrzelił z południa kraju rakiety w kierunku północnego Izraela. Eksplozje rozświetliły niebo podczas ostrzału rakietowego. - Wystrzelono około 30 pocisków - oznajmiła izraelska armia. Kilka dni wcześniej Izrael przeprowadził atak na stolicę Libanu.</p><br clear="all" />

