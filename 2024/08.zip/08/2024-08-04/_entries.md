## Key Takeaways From Berkshire Hathaway's Earnings
 - [https://finance.yahoo.com/news/key-takeaways-berkshire-hathaways-earnings-151833300.html](https://finance.yahoo.com/news/key-takeaways-berkshire-hathaways-earnings-151833300.html)
 - RSS feed: 
 - date published: 2024-08-04T17:16:53.419276+00:00

Warren Buffett's Berkshire Hathaway updated investors on its second-quarter financial results Saturday, revealing its cash pile rose to a record high as it made more cuts to its stake in Apple, while its operating profit surged as its insurance underwriting business made gains, and more.

## To preserve their work journalists take archiving into their own hands | Hacker News
 - [https://news.ycombinator.com/item?id=41146642](https://news.ycombinator.com/item?id=41146642)
 - RSS feed: 
 - date published: 2024-08-04T17:16:40.891250+00:00

To preserve their work journalists take archiving into their own hands | Hacker News

## What is going wrong for Intel? | Hacker News
 - [https://news.ycombinator.com/item?id=41146168](https://news.ycombinator.com/item?id=41146168)
 - RSS feed: 
 - date published: 2024-08-04T17:16:32.080385+00:00

What is going wrong for Intel? | Hacker News

## DARPA suggests turning legacy C code automatically into Rust
 - [https://go.theregister.com/feed/www.theregister.com/2024/08/03/darpa_c_to_rust](https://go.theregister.com/feed/www.theregister.com/2024/08/03/darpa_c_to_rust)
 - RSS feed: 
 - date published: 2024-08-04T17:16:11.492357+00:00

Who wants to make a TRACTOR pull request?

## Access to this page has been denied.
 - [https://www.investors.com/market-trend/stock-market-today/dow-jones-futures-apple-recession-fears/?src=A00220&amp;yptr=yahoo](https://www.investors.com/market-trend/stock-market-today/dow-jones-futures-apple-recession-fears/?src=A00220&amp;yptr=yahoo)
 - RSS feed: 
 - date published: 2024-08-04T17:16:08.621100+00:00

Access to this page has been denied.

## Yahoo is part of the Yahoo family of brands
 - [https://feedpress.me/link/20202/16761055/laura-ingraham-goes-vp-harris-015632050.html](https://feedpress.me/link/20202/16761055/laura-ingraham-goes-vp-harris-015632050.html)
 - RSS feed: 
 - date published: 2024-08-04T17:15:56.589836+00:00

Yahoo is part of the Yahoo family of brands

## fastcompany.com
 - [https://www.fastcompany.com/91164945/how-to-get-apple-intelligence-on-your-iphone-today-ios-18-beta-launch](https://www.fastcompany.com/91164945/how-to-get-apple-intelligence-on-your-iphone-today-ios-18-beta-launch)
 - RSS feed: 
 - date published: 2024-08-04T17:15:39.436652+00:00

fastcompany.com

## fastcompany.com
 - [https://www.fastcompany.com/91153265/5-insights-to-save-human-skills-ai](https://www.fastcompany.com/91153265/5-insights-to-save-human-skills-ai)
 - RSS feed: 
 - date published: 2024-08-04T17:15:39.133205+00:00

fastcompany.com

## 2 Ultra-High-Yield Dividend Stocks to Buy in August and Hold at Least a Decade
 - [https://finance.yahoo.com/news/2-ultra-high-yield-dividend-161300344.html](https://finance.yahoo.com/news/2-ultra-high-yield-dividend-161300344.html)
 - RSS feed: 
 - date published: 2024-08-04T17:15:37.242145+00:00

With an average yield above 7% at recent prices, these stocks could give your passive income stream a big boost.

## fastcompany.com
 - [https://www.fastcompany.com/91165778/offshore-wind-farms-electric-power-grid-transmission-lines-cut-costs](https://www.fastcompany.com/91165778/offshore-wind-farms-electric-power-grid-transmission-lines-cut-costs)
 - RSS feed: 
 - date published: 2024-08-04T17:15:28.710780+00:00

fastcompany.com

## fastcompany.com
 - [https://www.fastcompany.com/91165047/how-the-real-olivia-pope-would-have-handled-the-crowdstrike-outage-scandal](https://www.fastcompany.com/91165047/how-the-real-olivia-pope-would-have-handled-the-crowdstrike-outage-scandal)
 - RSS feed: 
 - date published: 2024-08-04T17:15:28.144373+00:00

fastcompany.com

## Afraid of a Bear Market? 3 High-Yield Stocks That Could Be Your Safe Haven in a Storm.
 - [https://finance.yahoo.com/news/afraid-bear-market-3-high-143900983.html](https://finance.yahoo.com/news/afraid-bear-market-3-high-143900983.html)
 - RSS feed: 
 - date published: 2024-08-04T17:14:47.935866+00:00

These high-yielding dividend stocks can supply a tangible return during a market downturn.

## Yahoo is part of the Yahoo family of brands
 - [https://feedpress.me/link/20202/16761037/donald-trump-agrees-fox-news-041527828.html](https://feedpress.me/link/20202/16761037/donald-trump-agrees-fox-news-041527828.html)
 - RSS feed: 
 - date published: 2024-08-04T16:09:17.374402+00:00

Yahoo is part of the Yahoo family of brands

## SoFi Stock Is Down Again After Earnings. When Will the Market Wake Up?
 - [https://finance.yahoo.com/news/sofi-stock-down-again-earnings-142100386.html](https://finance.yahoo.com/news/sofi-stock-down-again-earnings-142100386.html)
 - RSS feed: 
 - date published: 2024-08-04T16:08:45.969841+00:00

It delivered another blowout quarter, but the stock fell.

## CatCon Arrives at Pasadena Convention Center Without J.D. Vance
 - [https://www.tmz.com/2024/08/03/catcon-jd-vance-pasadena-childless-cat-ladies](https://www.tmz.com/2024/08/03/catcon-jd-vance-pasadena-childless-cat-ladies)
 - RSS feed: 
 - date published: 2024-08-04T00:00:00+00:00

California's furry felines will be out in force all weekend at CatCon -- but one person who probably won't be making a cameo is J.D. Vance!

## MSN
 - [https://feedpress.me/link/20202/16761056/ar-BB1r616U](https://feedpress.me/link/20202/16761056/ar-BB1r616U)
 - RSS feed: 
 - date published: 2024-08-04T00:00:00+00:00

MSN

## United States 104-83 Puerto Rico (Aug 3, 2024) Final Score - ESPN
 - [https://www.espn.com/mens-olympics-basketball/game?gameId=401690639](https://www.espn.com/mens-olympics-basketball/game?gameId=401690639)
 - RSS feed: 
 - date published: 2024-08-04T00:00:00+00:00

Game summary of the United States vs. Puerto Rico Mens-olympics-basketball game, final score 104-83, from August 3, 2024 on ESPN.

