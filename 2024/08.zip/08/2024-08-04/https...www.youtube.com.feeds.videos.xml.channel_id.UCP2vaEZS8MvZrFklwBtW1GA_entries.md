# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## Tile Shower Floor Tips - #shorts #homerepairtutor
 - [https://www.youtube.com/watch?v=9Z8gcFOUMag](https://www.youtube.com/watch?v=9Z8gcFOUMag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA
 - date published: 2024-08-04T11:00:11+00:00

The most important step is setting the tiles correctly at the drain. I back flat-troweled these 4" porcelain tiles and set them 1/16" from the grate. The critical part is making the drain level yet slightly lower than the tiles. If you're tiling a shower floor and need help, join our Video Library at homerepairtutor.com

