# Source:The Rubin Report, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng, language:en

## This Isn’t Normal. It’s the Beginning of a New Crisis | Scott Galloway
 - [https://www.youtube.com/watch?v=QdpColMeU2M](https://www.youtube.com/watch?v=QdpColMeU2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-08-04T13:45:06+00:00

Dave Rubin of “The Rubin Report” talks to Scott Galloway about his political stance as a "raging moderate"; the challenges moderates face from both political extremes; the importance of government support in his success; why the current state of affirmative action is failing and how a shift toward income-based support rather than race-based could help reform it; why government involvement in helping underprivileged kids is necessary; the struggles of young men in America; why young men are facing severe issues such as higher suicide rates, addiction, and incarceration compared to women, who are excelling in many areas; how societal changes, biased educational systems, and the impact of social media have negatively affected young men; why we need more support programs for young men; how mandatory national service can foster unity and understanding among different social groups; why telling young people to “follow their passion” is the worst advice you could give them and what we should

