# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## Philip Polkinghorne murder trial: Week two begins with ESR scientist cross examination
 - [https://www.nzherald.co.nz/nz/philip-polkinghorne-murder-trial-week-two-begins-with-esr-scientist-cross-examination/LQIB3MNPABG37EMSGUYTV5YVGY](https://www.nzherald.co.nz/nz/philip-polkinghorne-murder-trial-week-two-begins-with-esr-scientist-cross-examination/LQIB3MNPABG37EMSGUYTV5YVGY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T20:36:39+00:00

The jury of three men and nine women expects to hear from 62 witnesses in total.

## PM Christopher Luxon says ‘shocking’ student achievement results prompted hurry-up job on maths curriculum change
 - [https://www.nzherald.co.nz/nz/politics/pm-christopher-luxon-says-shocking-student-achievement-results-prompted-hurry-up-job-on-maths-curriculum-change/4VHO7O7XMBG5JI3U5LVBQFOJDI](https://www.nzherald.co.nz/nz/politics/pm-christopher-luxon-says-shocking-student-achievement-results-prompted-hurry-up-job-on-maths-curriculum-change/4VHO7O7XMBG5JI3U5LVBQFOJDI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T19:49:45+00:00

Luxon's conference maths announcement was pulled together in a few days.

## How police use Awhi app created in Tauranga to break reoffending cycle
 - [https://www.nzherald.co.nz/bay-of-plenty-times/news/how-police-use-the-awhi-app-to-get-people-out-of-the-reoffending-cycle/TDQOHNOV4ZEC3GTKFTZNATXDIQ](https://www.nzherald.co.nz/bay-of-plenty-times/news/how-police-use-the-awhi-app-to-get-people-out-of-the-reoffending-cycle/TDQOHNOV4ZEC3GTKFTZNATXDIQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T17:05:00+00:00

How two frontline BoP cops came up with an app idea to help people stop reoffending.

## Auckland’s Ponsonby Community Preschool could close after parents, board clash
 - [https://www.nzherald.co.nz/nz/aucklands-ponsonby-community-preschool-could-close-after-parents-board-clash/3UIF5FKXVBDM3EWR5RXNWBSKSY](https://www.nzherald.co.nz/nz/aucklands-ponsonby-community-preschool-could-close-after-parents-board-clash/3UIF5FKXVBDM3EWR5RXNWBSKSY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T17:00:00+00:00

Parents not happy at board plans to make preschool in upmarket suburb ‘more inclusive’.

## Early free access to ‘miracle drug’ Keytruda blocked, cancer groups say news ‘gutting’
 - [https://www.nzherald.co.nz/nz/early-free-access-to-miracle-drug-keytruda-blocked-cancer-groups-say-news-gutting/XO5VAYPXWBACZA7HYDT3VMY5YI](https://www.nzherald.co.nz/nz/early-free-access-to-miracle-drug-keytruda-blocked-cancer-groups-say-news-gutting/XO5VAYPXWBACZA7HYDT3VMY5YI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T17:00:00+00:00

Early access to the drug could make a significant difference in some patients' survival.

## House prices in Christchurch and Canterbury school zones: Search our interactive
 - [https://www.nzherald.co.nz/nz/house-prices-in-christchurch-and-canterbury-school-zones-search-our-interactive/ACYJWY6UYVAG3IHEGVUVIAH5TU](https://www.nzherald.co.nz/nz/house-prices-in-christchurch-and-canterbury-school-zones-search-our-interactive/ACYJWY6UYVAG3IHEGVUVIAH5TU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T17:00:00+00:00

We've calculated how much it costs to buy a house by school zone across the city.

## Kiwibank expansion plan deserves wide support - Matthew Hooton
 - [https://www.nzherald.co.nz/nz/kiwibank-expansion-plan-deserves-wide-support-matthew-hooton/D5GG763G6FCXTKMM3G5ZP7JKOA](https://www.nzherald.co.nz/nz/kiwibank-expansion-plan-deserves-wide-support-matthew-hooton/D5GG763G6FCXTKMM3G5ZP7JKOA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T17:00:00+00:00

OPINION: Willis’ proposal honours Jim Anderton and Trevor Mallard’s vision.

## What winter illnesses are spreading this year, and are we sicker than usual? - The Front Page
 - [https://www.nzherald.co.nz/nz/what-winter-illnesses-are-spreading-this-year-and-are-we-sicker-than-usual-the-front-page/3WVTOOSH3BHOBGPKAY534G4WBU](https://www.nzherald.co.nz/nz/what-winter-illnesses-are-spreading-this-year-and-are-we-sicker-than-usual-the-front-page/3WVTOOSH3BHOBGPKAY534G4WBU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T17:00:00+00:00

Hospital admissions have spiked in recent weeks as bugs spread around the country.

## Car collides with property in Fairview Heights, Auckland; wedged between house and retaining wall
 - [https://www.nzherald.co.nz/nz/car-collides-with-property-in-fairview-heights-auckland-wedged-between-house-and-retaining-wall/T5PGPJW34ZDEHMCQP6N2EUFSMY](https://www.nzherald.co.nz/nz/car-collides-with-property-in-fairview-heights-auckland-wedged-between-house-and-retaining-wall/T5PGPJW34ZDEHMCQP6N2EUFSMY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T09:59:21+00:00

Police said a crane may be needed to remove the car from where it is.

## NZ exclusive: International investigation exposes China’s world-dominating fishing tactics
 - [https://www.nzherald.co.nz/the-listener/world/nz-exclusive-international-investigation-exposes-chinas-world-dominating-fishing-tactics/CKGDXZX3UJGFTD3NJ6KEIK2ABM](https://www.nzherald.co.nz/the-listener/world/nz-exclusive-international-investigation-exposes-chinas-world-dominating-fishing-tactics/CKGDXZX3UJGFTD3NJ6KEIK2ABM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T09:00:00+00:00

Taking over from the inside: China's growing reach into local waters exposed.

## Riverton boat tragedy: Coastguard volunteer says survivor plucked from capsized boat, deceased trapped under vessel
 - [https://www.nzherald.co.nz/nz/riverton-boat-tragedy-coastguard-volunteer-says-survivor-plucked-from-capsized-boat-deceased-trapped-under-vessel/MKWODEGXGZB4PAYVJX6VMT4OPE](https://www.nzherald.co.nz/nz/riverton-boat-tragedy-coastguard-volunteer-says-survivor-plucked-from-capsized-boat-deceased-trapped-under-vessel/MKWODEGXGZB4PAYVJX6VMT4OPE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T07:56:45+00:00

Coastguard volunteers were on the scene within five minutes of a mayday call.

## Meth psychosis: Ethan Simon jailed for stabbing Burger King workers in South Auckland without provocation
 - [https://www.nzherald.co.nz/nz/crime/ethan-simon-jailed-for-stabbing-two-teen-workers-without-provocation-at-south-auckland-burger-king/PPEKFT4CCJGR5ENJN2XENZDSOE](https://www.nzherald.co.nz/nz/crime/ethan-simon-jailed-for-stabbing-two-teen-workers-without-provocation-at-south-auckland-burger-king/PPEKFT4CCJGR5ENJN2XENZDSOE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T06:00:00+00:00

Ethan Simon said he was especially sad about his victims' ages after learning what he did.

## Olympics 2024: Day 9 live updates - Ryan Fox, Daniel Hillier out to finish golf on a high
 - [https://www.nzherald.co.nz/sport/olympics/olympics-2024-day-9-live-updates-ryan-fox-daniel-hillier-out-to-finish-golf-on-a-high/L6W6Z7JJEZCZFFVOJNXUK25URA](https://www.nzherald.co.nz/sport/olympics/olympics-2024-day-9-live-updates-ryan-fox-daniel-hillier-out-to-finish-golf-on-a-high/L6W6Z7JJEZCZFFVOJNXUK25URA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T06:00:00+00:00

All the action you may have missed from day eight of the Paris Olympics 2024.

## Security guard assaulted in foiled jewellery store aggravated robbery in Mt Roskill
 - [https://www.nzherald.co.nz/nz/security-guard-assaulted-in-foiled-jewellery-store-aggravated-robbery-in-mt-roskill/RAZBUT5FT5AFZI2MJ24LDAIQ6M](https://www.nzherald.co.nz/nz/security-guard-assaulted-in-foiled-jewellery-store-aggravated-robbery-in-mt-roskill/RAZBUT5FT5AFZI2MJ24LDAIQ6M)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T05:53:13+00:00

Police are still hunting the armed offenders after they fled the scene.

## Found dead on Dargaville beach: Jo Sione-Lauaki renowned for her ‘Mamatanga’
 - [https://www.nzherald.co.nz/northern-advocate/news/found-dead-on-dargaville-beach-jo-sione-lauaki-renowned-for-her-mamatanga/AJMXYBAYHJCGHKMTCBLZDPTTBA](https://www.nzherald.co.nz/northern-advocate/news/found-dead-on-dargaville-beach-jo-sione-lauaki-renowned-for-her-mamatanga/AJMXYBAYHJCGHKMTCBLZDPTTBA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T05:17:20+00:00

Grieving whānau expect 600 people for Dargaville mum Jo Sione-Lauaki's tangi.

## Renters who lived rent-free for 15 months quash Tenancy Tribunal ruling ordering them to pay landlord $52k
 - [https://www.nzherald.co.nz/nz/renters-who-lived-rent-free-for-15-months-quash-tenancy-tribunal-ruling-ordering-them-to-pay-landlord-52k/PAPU7EME5FCJ3DXGAGBCX2RFL4](https://www.nzherald.co.nz/nz/renters-who-lived-rent-free-for-15-months-quash-tenancy-tribunal-ruling-ordering-them-to-pay-landlord-52k/PAPU7EME5FCJ3DXGAGBCX2RFL4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T03:00:50+00:00

The Camerons lived rent-free for 15 months, now they only have to fork out half the bill.

## Olympics 2024: Tom Walsh pushes past his pain in men’s shot put final in Paris
 - [https://www.nzherald.co.nz/sport/olympics/olympics-2024-tom-walsh-pushes-past-his-pain-in-mens-shot-put-final-in-paris/CZCQSYLTYVBETFIT7RW7KLNMRI](https://www.nzherald.co.nz/sport/olympics/olympics-2024-tom-walsh-pushes-past-his-pain-in-mens-shot-put-final-in-paris/CZCQSYLTYVBETFIT7RW7KLNMRI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-04T01:56:49+00:00

The two-time Olympic bronze medallist was unable to add a third in Paris.

