# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Dozens killed in Bangladesh protests calling for prime minister to resign
 - [https://www.nbcnews.com/video/dozens-killed-in-bangladesh-protests-216388165554](https://www.nbcnews.com/video/dozens-killed-in-bangladesh-protests-216388165554)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2024-08-04T19:46:51+00:00

Dozens of people were killed in a new round of violent clashes between student protesters and police in Bangladesh. Thousands had gathered in the country's capital Dhaka calling for Prime Minister Sheikh Hasina to resign.

## At least 27 killed in Bangladesh clashes, government declares curfew
 - [https://www.nbcnews.com/news/world/least-27-killed-bangladesh-clashes-government-declares-curfew-rcna165056](https://www.nbcnews.com/news/world/least-27-killed-bangladesh-clashes-government-declares-curfew-rcna165056)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2024-08-04T13:45:01+00:00

At least 27 people were killed and scores injured in clashes in Bangladesh on Sunday, as police fired tear gas and lobbed stun grenades to disperse tens of thousands of protesters calling for Prime Minister Sheikh Hasina to resign.

## Boxer from Taiwan shakes off gender questions to win fight and assure medal
 - [https://www.nbcnews.com/sports/olympics/lin-yu-ting-chinese-taipei-boxer-taiwan-shakes-gender-questions-wins-b-rcna165051](https://www.nbcnews.com/sports/olympics/lin-yu-ting-chinese-taipei-boxer-taiwan-shakes-gender-questions-wins-b-rcna165051)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2024-08-04T10:55:00+00:00

VILLEPINTE, France — Lin Yu-ting won her quarterfinal bout at the Paris Olympics against Bulgarian Svetlana Staneva in a unanimous decision on Sunday that assured a medal for the featherweight representing Chinese Taipei.

## The crowds are full and raucous at the Paris Olympics. Outside the events? Not so much.
 - [https://www.nbcnews.com/sports/olympics/crowds-are-full-raucous-paris-olympics-events-not-much-rcna164634](https://www.nbcnews.com/sports/olympics/crowds-are-full-raucous-paris-olympics-events-not-much-rcna164634)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2024-08-04T09:45:00+00:00

For athletes and audiences, these have been the Olympics when raucous crowds have roared once again following years of lockdown restrictions.

