# Source:Neowin, URL:https://www.neowin.net/news/rss, language:en-us

## Nvidia drivers confirmed to cause BSOD on Windows PCs without certain CPU instructions
 - [https://www.neowin.net/news/nvidia-drivers-confirmed-to-cause-bsod-on-windows-pcs-without-certain-cpu-instructions](https://www.neowin.net/news/nvidia-drivers-confirmed-to-cause-bsod-on-windows-pcs-without-certain-cpu-instructions)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T19:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1708599143_bsod_medium.jpg" /></div>If you have an older computer with a still-supported Nvidia graphics card, you may encounter a nasty compatibility problem, causing your computer to get stuck in a blue screen of death cycle. <a href="https://www.neowin.net/news/nvidia-drivers-confirmed-to-cause-bsod-on-windows-pcs-without-certain-cpu-instructions/">Read more...</a>

## Microsoft Edge is getting close to a 14% market share
 - [https://www.neowin.net/news/microsoft-edge-is-getting-close-to-a-14-market-share](https://www.neowin.net/news/microsoft-edge-is-getting-close-to-a-14-market-share)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T17:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1690886754_browsers_medium.jpg" /></div>Microsoft Edge is not making any major leaps in the desktop browser market, but, slow but steady, it continues to increase its share. According to the latest data, Edge is about to cross the 14% mark. <a href="https://www.neowin.net/news/microsoft-edge-is-getting-close-to-a-14-market-share/">Read more...</a>

## Apple has finally started mailing out settlement checks for bad MacBook butterfly keyboards
 - [https://www.neowin.net/news/apple-has-finally-started-mailing-out-settlement-checks-for-bad-macbook-butterfly-keyboards](https://www.neowin.net/news/apple-has-finally-started-mailing-out-settlement-checks-for-bad-macbook-butterfly-keyboards)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T13:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/11/1605030971_apple_medium.jpg" /></div>Apple has begun to mail out settlement checks to people who joined a class action lawsuit many years ago about the faulty butterfly keyboards that were put in some older MacBook notebooks. <a href="https://www.neowin.net/news/apple-has-finally-started-mailing-out-settlement-checks-for-bad-macbook-butterfly-keyboards/">Read more...</a>

## Nvidia reportedly ends production of its most popular consumer graphics card
 - [https://www.neowin.net/news/nvidia-reportedly-ends-production-of-its-most-popular-consumer-graphics-card](https://www.neowin.net/news/nvidia-reportedly-ends-production-of-its-most-popular-consumer-graphics-card)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T13:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/08/1722777663_rtx_3060_medium.jpg" /></div>A new report emerged about Nvidia about to end the manufacturing of one of its most popular consumer-grade graphics cards, the RTX 3060, which currently is the number one GPU on Steam. <a href="https://www.neowin.net/news/nvidia-reportedly-ends-production-of-its-most-popular-consumer-graphics-card/">Read more...</a>

## Get the TP-Link Deco AX3000 Wi-Fi 6 3-pack mesh wireless router system at its lowest price
 - [https://www.neowin.net/deals/get-the-tp-link-deco-ax3000-wi-fi-6-3-pack-mesh-wireless-router-system-at-its-lowest-price](https://www.neowin.net/deals/get-the-tp-link-deco-ax3000-wi-fi-6-3-pack-mesh-wireless-router-system-at-its-lowest-price)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T12:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/08/1722775137_tp-link-wifi-6-router_medium.jpg" /></div>The TP-Link Deco AX3000 Wi-Fi 6 3-pack mesh wireless router system can offer a strong internet connection that covers up to 6,500 square feet. It&#039;s currently at its lowest price of $169.98. <a href="https://www.neowin.net/deals/get-the-tp-link-deco-ax3000-wi-fi-6-3-pack-mesh-wireless-router-system-at-its-lowest-price/">Read more...</a>

## Microsoft 365 Roadmap Weekly: Copilot will soon help you make videos in Clipchamp and more
 - [https://www.neowin.net/news/microsoft-365-roadmap-weekly-copilot-will-soon-help-you-make-videos-in-clipchamp-and-more](https://www.neowin.net/news/microsoft-365-roadmap-weekly-copilot-will-soon-help-you-make-videos-in-clipchamp-and-more)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T12:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715087727_clipchamp-education_medium.jpg" /></div>This week, the Microsoft 365 Roadmap has a few interesting entries for upcoming features. They include adding Copilot support for the Clipchamp video editing tool to help create videos and more. <a href="https://www.neowin.net/news/microsoft-365-roadmap-weekly-copilot-will-soon-help-you-make-videos-in-clipchamp-and-more/">Read more...</a>

## Get this 4-port UGREEN 100W fast charger for just $40.99
 - [https://www.neowin.net/deals/get-this-4-port-ugreen-100w-fast-charger-for-just-4099](https://www.neowin.net/deals/get-this-4-port-ugreen-100w-fast-charger-for-just-4099)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T09:56:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1716843991_ugreen_100w_charger_medium.jpg" /></div>If you often carry multiple devices with you, charging them at once may be quite a chore. You can fix that with UGREEN&#039;s 100W four-port GaN charger, which is now available for just $40.99. <a href="https://www.neowin.net/deals/get-this-4-port-ugreen-100w-fast-charger-for-just-4099/">Read more...</a>

## Microsoft Weekly: 64 billion dollars in revenue, Skype goes ad-free, and more
 - [https://www.neowin.net/news/microsoft-weekly-64-billion-dollars-in-revenue-skype-goes-ad-free-and-more](https://www.neowin.net/news/microsoft-weekly-64-billion-dollars-in-revenue-skype-goes-ad-free-and-more)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T08:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1722243964_microsoft_weekly_medium.jpg" /></div>This week&#039;s Microsoft news recap is here with the latest financial report from Microsoft, ad-free Skype (a surprise to be sure), one Windows 11 preview build, gaming news, and more. <a href="https://www.neowin.net/news/microsoft-weekly-64-billion-dollars-in-revenue-skype-goes-ad-free-and-more/">Read more...</a>

## Google Search widget removes most customization options but adds Dynamic Color
 - [https://www.neowin.net/news/google-search-widget-removes-most-customization-options-but-adds-dynamic-color](https://www.neowin.net/news/google-search-widget-removes-most-customization-options-but-adds-dynamic-color)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T07:02:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/07/1658336048_google_medium.jpg" /></div>The latest beta update for the Google app is reportedly removing a lot of customization options, and now lets you choose from a set of color themes, however, adds the Dynamic Color option. <a href="https://www.neowin.net/news/google-search-widget-removes-most-customization-options-but-adds-dynamic-color/">Read more...</a>

## Not torrents, but illegal live-streaming sites are the biggest enemy of the 2024 Olympics
 - [https://www.neowin.net/news/not-torrents-but-illegal-live-streaming-sites-are-the-biggest-enemy-of-the-2024-olympics](https://www.neowin.net/news/not-torrents-but-illegal-live-streaming-sites-are-the-biggest-enemy-of-the-2024-olympics)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-08-04T06:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1719425898_parisolympics_0_medium.jpg" /></div>Piracy evolves, too. The Olympics demonstrated that torrents are a threat of the past, as websites with illegal live streams are now main cause of headaches for intellectual property rights holders. <a href="https://www.neowin.net/news/not-torrents-but-illegal-live-streaming-sites-are-the-biggest-enemy-of-the-2024-olympics/">Read more...</a>

