# Source:RP - Regiony, URL:https://regiony.rp.pl/rss/1441-regiony, language:pl-PL

## Hanna Zdanowska: Rządowe propozycje wymagają wyjaśnienia
 - [https://regiony.rp.pl/okiem-samorzadowca/art40914241-hanna-zdanowska-rzadowe-propozycje-wymagaja-wyjasnienia](https://regiony.rp.pl/okiem-samorzadowca/art40914241-hanna-zdanowska-rzadowe-propozycje-wymagaja-wyjasnienia)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-08-04T10:59:00+00:00

Dlaczego zapisano inny udział w podatku PIT czy CIT miastom na prawach powiatu, wobec tego, co zaproponowano miastom, które mają u siebie osobno powiat. Nie rozumiemy tego – mówi Hanna Zdanowska, prezydent Łodzi.

## Samorządy inwestują w infrastrukturę i komunikację
 - [https://regiony.rp.pl/inwestycje/art40914231-samorzady-inwestuja-w-infrastrukture-i-komunikacje](https://regiony.rp.pl/inwestycje/art40914231-samorzady-inwestuja-w-infrastrukture-i-komunikacje)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-08-04T10:56:00+00:00

Rozmachu nie ma, ale nie będzie się też czego wstydzić – tak w skrócie można podsumować planowane w tym roku przez lokalne władze inwestycje.

