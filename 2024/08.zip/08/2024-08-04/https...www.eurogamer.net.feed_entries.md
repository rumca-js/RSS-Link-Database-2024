# Source:Eurogamer.net Latest Articles Feed, URL:https://www.eurogamer.net/feed, language:en-gb

## Half-Life 3 may have been announced by a "voice actor who probably has never heard of Steam"
 - [https://www.eurogamer.net/half-life-3-may-have-been-announced-by-a-voice-actor-who-probably-has-never-heard-of-steam](https://www.eurogamer.net/half-life-3-may-have-been-announced-by-a-voice-actor-who-probably-has-never-heard-of-steam)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-04T20:29:45+00:00

<img src="https://assetsio.gnwcdn.com/half-life-2-art.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Brace yourself, Half-Life fans &ndash; rumours of Half-Life 3 have been resurrected once again, this time originating from the unassuming resume of a voice actor.</p><p>There's a chance that by the time you read this,  Natasha Chandel's <a href="https://www.natashachandel.com/resume/">website</a> has already been, uh, revised, but right now, if you scroll down to the "voice over" section, you'll see reference "Project White Sands (video game)".</p><p>Chandel did not name the character(s) she provided voice work for, but the project is clearly marked as belonging to Valve.</p> <p><a href="https://www.eurogamer.net/half-life-3-may-have-been-announced-by-a-voice-actor-who-probably-has-never-heard-of-steam">Read more</a></p>

## Call of Duty: Black Ops 6 images leak online, including multiplayer maps and menu screens
 - [https://www.eurogamer.net/call-of-duty-black-ops-6-images-leak-online-including-multiplayer-maps-and-menu-screens](https://www.eurogamer.net/call-of-duty-black-ops-6-images-leak-online-including-multiplayer-maps-and-menu-screens)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-04T13:07:57+00:00

<img src="https://assetsio.gnwcdn.com/BO6_Campaign_Park.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Images of Call of Duty: Black Ops 6 have leaked online, including multiplayer maps, menu screens, and perks.</p><p>Within hours, the screenshots were hit with copyright claims from Activision, adding credence to the claims they come from an in-development build. However, this is the internet, which means nothing's ever truly gone, and the images are still going up faster than Activision can remove them.</p><p>Whilst the map images have since been removed, the leaker claims the maps have partial titles, many of which will be familiar to Call of Duty players.</p> <p><a href="https://www.eurogamer.net/call-of-duty-black-ops-6-images-leak-online-including-multiplayer-maps-and-menu-screens">Read more</a></p>

## Visions of Mana running in 6DoF VR lets us live out the fantasy of a hybrid future
 - [https://www.eurogamer.net/visions-of-mana-running-in-6dof-vr-lets-us-live-out-the-fantasy-of-a-hybrid-future](https://www.eurogamer.net/visions-of-mana-running-in-6dof-vr-lets-us-live-out-the-fantasy-of-a-hybrid-future)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-04T13:00:00+00:00

<img src="https://assetsio.gnwcdn.com/b1_HcQK0XF.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>I'm a big old dreamer, me. I see a thing that I love, like VR, and I like to imagine the best outcomes for it. You know, like Sony actually bringing a new Astrobot to the PS VR2, or say, smaller, lighter, cheaper headsets for all. Obviously I'm disappointed every time - newer headsets seem to be getting <a href="https://www.eurogamer.net/apple-unveils-3499-augmented-reality-vision-pro-headset" target="_blank">impossibly expensive</a> and, well, of course Sony's gone done a Sony with the PS VR2.</p><p>One of my biggest dreams though, is that one day, in the future, every game released would come with a hybrid VR mode. A simple toggle at the start, like Capcom put in Resident Evil 7, that gives players the choice to either experience the game in VR, or enjoy it in flat screen on whatever TV or monitor they choose. </p><p>While this dream seems

## Humble Games' final release before "restructuring" has launched a Patreon "in these uncertain times"
 - [https://www.eurogamer.net/humble-games-final-release-before-restructuring-has-launched-a-patreon-in-these-uncertain-times](https://www.eurogamer.net/humble-games-final-release-before-restructuring-has-launched-a-patreon-in-these-uncertain-times)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-04T11:07:16+00:00

<img src="https://assetsio.gnwcdn.com/Key-Art-2.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Humble Games' last release before the studio was "restructured" last week, B&otilde;: Path of the Teal Lotus, has launched a Patreon to support the game "in these uncertain times".</p><p>Writing on X, the social media platform formerly known as Twitter, developer Squid Shock said that whilst it did not fault the team's work, Humble's changes "have meant we have missed out on critical post-launch support, which may put our studio's future at risk".</p><p>Although Humble has disputed the statements of former staff that characterised the layoffs as a shutdown, instead insisting laying off its staff is merely a "restructuring", Squid Shock also describes the changes as "shutting down".</p> <p><a href="https://www.eurogamer.net/humble-games-final-release-before-restructuring-has-launched-a-patreon-in-these-uncertain-times">Read more</a></p>

