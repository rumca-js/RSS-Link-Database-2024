# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Dokąd prowadzi rozwój AI? Historia Ilyi Sutskevera.
 - [https://www.youtube.com/watch?v=ZP8nA_D_y8E](https://www.youtube.com/watch?v=ZP8nA_D_y8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2024-08-04T16:00:28+00:00

🤯 Sztuczna Inteligencja doprowadzi do naszej zagłady! AI zje nas wszystkich! Będziemy żyć w Matriksie! Do tego Terminator, Skynet i inne lasery. Ale poza kasowymi produkcjami wprost z Hollywooda i głośnym krzyczeniem wielu znanych osób, które nie zawsze do końca wiedzą o czym tak właściwie mówią, to co tak naprawdę dzieje się na samym froncie rozwoju najnowszych technologii? Jakie zagrożenia czyhają na nas w trakcie ujarzmiania sztucznej inteligencji? I co z tym wszystkim ma wspólnego Ilya Sutskever oraz jego głośne odejście z OpenAI?
 
Źródła:
🌐 TRAINING RECURRENT NEURAL NETWORKS by Ilya Sutskever
https://www.cs.utoronto.ca/~ilya/pubs/ilya_sutskever_phd_thesis.pdf

📖 The Alignment Problem from a Deep Learning Perspective, R. Ngo, L. Chan, S. Mindermann
https://arxiv.org/abs/2209.00626

🏫 Google buys University of Toronto startup
https://www.cbc.ca/news/science/google-buys-university-of-toronto-startup-1.1373641

🤖 Introducing OpenAI
https://openai.com/index/introducing-openai/

🦾 Tim

