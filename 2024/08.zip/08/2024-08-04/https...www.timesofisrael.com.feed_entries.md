# Source:The Times of Israel, URL:https://www.timesofisrael.com/feed, language:en-US

## Report: Netanyahu decides not to seek normalization with Saudis before US election
 - [https://www.timesofisrael.com/report-netanyahu-decides-not-to-seek-normalization-with-saudis-before-us-election](https://www.timesofisrael.com/report-netanyahu-decides-not-to-seek-normalization-with-saudis-before-us-election)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T20:34:21+00:00

<p>Israel's Channel 12 suggests PM is waiting to see who is elected to White House this fall before deciding on approach to Riyadh</p>
<p>The post <a href="https://www.timesofisrael.com/report-netanyahu-decides-not-to-seek-normalization-with-saudis-before-us-election/">Report: Netanyahu decides not to seek normalization with Saudis before US election</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/07/FotoJet-5-1024x640.jpg" title="Report: Netanyahu decides not to seek normalization with Saudis before US election" width="160" /></figure>

## Hundreds mark hostage Ariel Bibas’s 5th birthday with bubbles, candles in Central Park
 - [https://www.timesofisrael.com/hundreds-mark-hostage-ariel-bibass-5th-birthday-with-bubbles-candles-in-central-park](https://www.timesofisrael.com/hundreds-mark-hostage-ariel-bibass-5th-birthday-with-bubbles-candles-in-central-park)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T20:10:26+00:00

<p>Bibas family plans march in honor of Ariel in Tel Aviv on Monday, while Israel Railways, Jerusalem honor him with orange lights</p>
<p>The post <a href="https://www.timesofisrael.com/hundreds-mark-hostage-ariel-bibass-5th-birthday-with-bubbles-candles-in-central-park/">Hundreds mark hostage Ariel Bibas&#8217;s 5th birthday with bubbles, candles in Central Park</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/WhatsApp-Image-2024-08-04-at-8.25.13-PM-1024x640.jpeg" title="Hundreds mark hostage Ariel Bibas&#8217;s 5th birthday with bubbles, candles in Central Park" width="160" /></figure>

## Master Sgt. Tomer Dolev, 34: IDF reservist had a love of travel
 - [https://www.timesofisrael.com/master-sgt-tomer-dolev-34-idf-reservist-with-a-love-for-global-travel](https://www.timesofisrael.com/master-sgt-tomer-dolev-34-idf-reservist-with-a-love-for-global-travel)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T20:06:18+00:00

<p>Killed in a friendly fire incident near Netiv Ha'asara on October 8, 2023</p>
<p>The post <a href="https://www.timesofisrael.com/master-sgt-tomer-dolev-34-idf-reservist-with-a-love-for-global-travel/">Master Sgt. Tomer Dolev, 34: IDF reservist had a love of travel</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/07/תומר-דולב-e1721325604556-1024x640.jpg" title="Master Sgt. Tomer Dolev, 34: IDF reservist had a love of travel" width="160" /></figure>

## Libby Cohen Meguri, 22: ‘God sprinkled her with charisma powder’
 - [https://www.timesofisrael.com/libby-cohen-meguri-22-god-sprinkled-her-with-charisma-powder](https://www.timesofisrael.com/libby-cohen-meguri-22-god-sprinkled-her-with-charisma-powder)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T20:01:37+00:00

<p>Murdered while trying to flee the Supernova music festival on October 7</p>
<p>The post <a href="https://www.timesofisrael.com/libby-cohen-meguri-22-god-sprinkled-her-with-charisma-powder/">Libby Cohen Meguri, 22: &#8216;God sprinkled her with charisma powder&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/07/Libby-Cohen-Meguri-1-e1722801648163-1024x640.jpeg" title="Libby Cohen Meguri, 22: &#8216;God sprinkled her with charisma powder&#8217;" width="160" /></figure>

## Amid war fears, at Ben Gurion Airport, it’s business as usual — just less of it
 - [https://www.timesofisrael.com/amid-war-fears-at-ben-gurion-airport-its-business-as-usual-just-less-of-it](https://www.timesofisrael.com/amid-war-fears-at-ben-gurion-airport-its-business-as-usual-just-less-of-it)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T19:48:01+00:00

<p>On a Sunday, after some 18 international carriers cancelled services to the Jewish state in anticipation of escalating hostilities, Israel's main airport was quieter than usual</p>
<p>The post <a href="https://www.timesofisrael.com/amid-war-fears-at-ben-gurion-airport-its-business-as-usual-just-less-of-it/">Amid war fears, at Ben Gurion Airport, it’s business as usual &#8212; just less of it</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/WhatsApp-Image-2024-08-04-at-4.42.33-PM-1-1024x640.jpeg" title="Amid war fears, at Ben Gurion Airport, it’s business as usual &#8212; just less of it" width="160" /></figure>

## Herzog calls for unity as attack looms: ‘Our enemies celebrate when they see division’
 - [https://www.timesofisrael.com/herzog-calls-for-unity-as-attack-looms-our-enemies-celebrate-when-they-see-division](https://www.timesofisrael.com/herzog-calls-for-unity-as-attack-looms-our-enemies-celebrate-when-they-see-division)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T19:16:19+00:00

<p>Speaking alongside president at memorial ceremony for Zeev Jabotinsky, PM says that 'our long hand strikes the Gaza Strip, Yemen, Beirut -- wherever is necessary'</p>
<p>The post <a href="https://www.timesofisrael.com/herzog-calls-for-unity-as-attack-looms-our-enemies-celebrate-when-they-see-division/">Herzog calls for unity as attack looms: &#8216;Our enemies celebrate when they see division&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/WhatsApp-Image-2024-08-04-at-21.00.26-1024x640.jpeg" title="Herzog calls for unity as attack looms: &#8216;Our enemies celebrate when they see division&#8217;" width="160" /></figure>

## Shin Bet said to prepare underground bunker for senior leadership amid Iranian threat
 - [https://www.timesofisrael.com/shin-bet-said-to-prepare-underground-bunker-for-senior-leadership-amid-iranian-threat](https://www.timesofisrael.com/shin-bet-said-to-prepare-underground-bunker-for-senior-leadership-amid-iranian-threat)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T19:14:03+00:00

<p>The National Management Center has not been used thus far in the war and can reportedly sustain hits from a range of existing weaponry while maintaining links to IDF headquarters</p>
<p>The post <a href="https://www.timesofisrael.com/shin-bet-said-to-prepare-underground-bunker-for-senior-leadership-amid-iranian-threat/">Shin Bet said to prepare underground bunker for senior leadership amid Iranian threat</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/IMG-20240608-WA0002-e1717852104632-1024x640.jpg" title="Shin Bet said to prepare underground bunker for senior leadership amid Iranian threat" width="160" /></figure>

## Iran said to dismiss US, Arab calls for restraint even if it sparks war
 - [https://www.timesofisrael.com/iran-said-to-dismiss-us-arab-nations-calls-for-restraint-even-if-it-sparks-war](https://www.timesofisrael.com/iran-said-to-dismiss-us-arab-nations-calls-for-restraint-even-if-it-sparks-war)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T18:51:13+00:00

<p>US warns Iranian attack will hamper relations with West; Israel preparing for multi-day assault; Netanyahu consulting with defense chiefs, considering 'preventative measures'</p>
<p>The post <a href="https://www.timesofisrael.com/iran-said-to-dismiss-us-arab-nations-calls-for-restraint-even-if-it-sparks-war/">Iran said to dismiss US, Arab calls for restraint even if it sparks war</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/04/AFP__20240415__34PF696__v1__HighRes__IranPalestinianIsraelUsConflict-1024x640.jpg" title="Iran said to dismiss US, Arab calls for restraint even if it sparks war" width="160" /></figure>

## 3 suspects in Sde Teiman abuse case released after new evidence presented
 - [https://www.timesofisrael.com/3-suspects-in-sde-teiman-abuse-case-released-after-new-evidence-presented](https://www.timesofisrael.com/3-suspects-in-sde-teiman-abuse-case-released-after-new-evidence-presented)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T17:55:17+00:00

<p>Remands of 5 other reservists extended until Tuesday, during ongoing investigation into suspected sexual abuse of Palestinian detainee</p>
<p>The post <a href="https://www.timesofisrael.com/3-suspects-in-sde-teiman-abuse-case-released-after-new-evidence-presented/">3 suspects in Sde Teiman abuse case released after new evidence presented</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/F240730CG312-1024x640.jpg" title="3 suspects in Sde Teiman abuse case released after new evidence presented" width="160" /></figure>

## Harris to interview vice president candidates Sunday evening ahead of deadline
 - [https://www.timesofisrael.com/harris-to-interview-vice-president-candidates-sunday-evening-ahead-of-deadline](https://www.timesofisrael.com/harris-to-interview-vice-president-candidates-sunday-evening-ahead-of-deadline)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T16:34:14+00:00

<p>The US vice president and presumptive Democratic candidate is expected to announce her running mate on Monday in a choice that will greatly affect her campaign</p>
<p>The post <a href="https://www.timesofisrael.com/harris-to-interview-vice-president-candidates-sunday-evening-ahead-of-deadline/">Harris to interview vice president candidates Sunday evening ahead of deadline</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AP24214026902864-1024x640.jpg" title="Harris to interview vice president candidates Sunday evening ahead of deadline" width="160" /></figure>

## IDF can now send location-based alerts to phones in case of large-scale attacks
 - [https://www.timesofisrael.com/idf-can-now-send-location-based-alerts-to-phones-in-case-of-large-scale-attacks](https://www.timesofisrael.com/idf-can-now-send-location-based-alerts-to-phones-in-case-of-large-scale-attacks)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T16:14:39+00:00

<p>New system can send messages based on positioning of cell towers -- not GPS, which has seen disruptions amid ongoing war; IDF says no current changes to instructions for civilians</p>
<p>The post <a href="https://www.timesofisrael.com/idf-can-now-send-location-based-alerts-to-phones-in-case-of-large-scale-attacks/">IDF can now send location-based alerts to phones in case of large-scale attacks</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/FotoJet-1-e1722783038823-1024x640.jpg" title="IDF can now send location-based alerts to phones in case of large-scale attacks" width="160" /></figure>

## Anne Frank statue in Amsterdam park vandalized again with pro-Palestinian graffiti
 - [https://www.timesofisrael.com/anne-frank-statue-in-amsterdam-park-vandalized-again-with-pro-palestinian-graffiti](https://www.timesofisrael.com/anne-frank-statue-in-amsterdam-park-vandalized-again-with-pro-palestinian-graffiti)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T15:03:47+00:00

<p>Police say this is the second time in less than a month that the memorial has been defaced; are investigating</p>
<p>The post <a href="https://www.timesofisrael.com/anne-frank-statue-in-amsterdam-park-vandalized-again-with-pro-palestinian-graffiti/">Anne Frank statue in Amsterdam park vandalized again with pro-Palestinian graffiti</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2017/04/20170117_104901-1024x640.jpg" title="Anne Frank statue in Amsterdam park vandalized again with pro-Palestinian graffiti" width="160" /></figure>

## IDF document shared with northern mayors sets out Hezbollah war scenarios
 - [https://www.timesofisrael.com/idf-document-shared-with-northern-mayors-sets-out-hezbollah-war-scenarios](https://www.timesofisrael.com/idf-document-shared-with-northern-mayors-sets-out-hezbollah-war-scenarios)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T14:05:25+00:00

<p>Security establishment sees potentially unprecedented rocket fire, major evacuations, power outages, water supply issues, disrupted telecom service and brief internet disruptions</p>
<p>The post <a href="https://www.timesofisrael.com/idf-document-shared-with-northern-mayors-sets-out-hezbollah-war-scenarios/">IDF document shared with northern mayors sets out Hezbollah war scenarios</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AFP__20240801__368K39W__v1__HighRes__LebanonIsraelPalestinianConflictShukrFuneral-e1722561255203-1024x640.jpg" title="IDF document shared with northern mayors sets out Hezbollah war scenarios" width="160" /></figure>

## Report: Terror groups trying to use Arab Israeli crime gangs to carry out attacks
 - [https://www.timesofisrael.com/report-terror-groups-trying-to-use-arab-israeli-crime-gangs-to-carry-out-attacks](https://www.timesofisrael.com/report-terror-groups-trying-to-use-arab-israeli-crime-gangs-to-carry-out-attacks)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T13:54:36+00:00

<p>Ministers told that weapons pilfered from Gaza war are making their way into Arab community and posing a serious threat to national security</p>
<p>The post <a href="https://www.timesofisrael.com/report-terror-groups-trying-to-use-arab-israeli-crime-gangs-to-carry-out-attacks/">Report: Terror groups trying to use Arab Israeli crime gangs to carry out attacks</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/photo_2024-02-18_07-51-23-1024x640.jpg" title="Report: Terror groups trying to use Arab Israeli crime gangs to carry out attacks" width="160" /></figure>

## Netanyahu warns Iran: We are ready, we’ll exact a heavy price for any aggression
 - [https://www.timesofisrael.com/netanyahu-warns-iran-we-are-ready-well-exact-a-heavy-price-for-any-aggression](https://www.timesofisrael.com/netanyahu-warns-iran-we-are-ready-well-exact-a-heavy-price-for-any-aggression)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T13:36:31+00:00

<p>PM tells cabinet Israel striking hard against Iranian's 'axis of evil,' is prepared for any offensive or defensive scenario; Gallant: Israel is 'prepared very strongly' for any attack</p>
<p>The post <a href="https://www.timesofisrael.com/netanyahu-warns-iran-we-are-ready-well-exact-a-heavy-price-for-any-aggression/">Netanyahu warns Iran: We are ready, we&#8217;ll exact a heavy price for any aggression</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/07/IMG_0650-1024x640.jpg" title="Netanyahu warns Iran: We are ready, we&#8217;ll exact a heavy price for any aggression" width="160" /></figure>

## Regulations enter into effect to ban starvation of hens to increase egg production
 - [https://www.timesofisrael.com/regulations-enter-into-effect-to-ban-starvation-of-hens-to-increase-egg-production](https://www.timesofisrael.com/regulations-enter-into-effect-to-ban-starvation-of-hens-to-increase-egg-production)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T13:15:10+00:00

<p>Denying hens food for eight to 12 days speeds up annual molting during which fewer eggs are laid and profits fall; animal welfare group: 'Cruel practice' crossed all lines</p>
<p>The post <a href="https://www.timesofisrael.com/regulations-enter-into-effect-to-ban-starvation-of-hens-to-increase-egg-production/">Regulations enter into effect to ban starvation of hens to increase egg production</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2022/06/egg-laying-chickens-1024x640.jpeg" title="Regulations enter into effect to ban starvation of hens to increase egg production" width="160" /></figure>

## IDF finds tunnel large enough for vehicles to drive through in Gaza-Egypt border area
 - [https://www.timesofisrael.com/idf-finds-tunnel-large-enough-for-vehicles-to-drive-through-in-gaza-egypt-border-area](https://www.timesofisrael.com/idf-finds-tunnel-large-enough-for-vehicles-to-drive-through-in-gaza-egypt-border-area)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T13:13:28+00:00

<p>At least 5 rockets launched from Gaza, triggering sirens near Ashdod and sparking blaze; military says it targeted Hamas cells operating out of 2 schools, Palestinians say 25 killed</p>
<p>The post <a href="https://www.timesofisrael.com/idf-finds-tunnel-large-enough-for-vehicles-to-drive-through-in-gaza-egypt-border-area/">IDF finds tunnel large enough for vehicles to drive through in Gaza-Egypt border area</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/6f766c19-2958-4b7d-8987-c7843ad52375-e1722772393977-1024x640.jpg" title="IDF finds tunnel large enough for vehicles to drive through in Gaza-Egypt border area" width="160" /></figure>

## Drone with Israel flag trolls Turkey’s Haniyeh-saluting TLV embassy
 - [https://www.timesofisrael.com/drone-with-israel-flag-trolls-turkeys-haniyeh-saluting-tel-aviv-embassy](https://www.timesofisrael.com/drone-with-israel-flag-trolls-turkeys-haniyeh-saluting-tel-aviv-embassy)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T12:08:25+00:00

<p>Turkish ambassador, recalled to Ankara since November, complains after UAV hoists Israeli national banner over Turkish flag, lowered to half-staff to honor slain Hamas leader</p>
<p>The post <a href="https://www.timesofisrael.com/drone-with-israel-flag-trolls-turkeys-haniyeh-saluting-tel-aviv-embassy/">Drone with Israel flag trolls Turkey&#8217;s Haniyeh-saluting TLV embassy</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/Screenshot-2024-08-04-122053-e1722764018436-1024x640.png" title="Drone with Israel flag trolls Turkey&#8217;s Haniyeh-saluting TLV embassy" width="160" /></figure>

## Jordan’s FM to make rare visit to Iran as US allies scramble to prevent escalation
 - [https://www.timesofisrael.com/jordans-fm-to-make-rare-visit-to-iran-as-us-allies-scramble-to-prevent-escalation](https://www.timesofisrael.com/jordans-fm-to-make-rare-visit-to-iran-as-us-allies-scramble-to-prevent-escalation)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T11:37:16+00:00

<p>Ayman Safadi will meet with Iranian counterpart in Tehran, making him first top Jordanian official to visit Islamic Republic in two decades</p>
<p>The post <a href="https://www.timesofisrael.com/jordans-fm-to-make-rare-visit-to-iran-as-us-allies-scramble-to-prevent-escalation/">Jordan&#8217;s FM to make rare visit to Iran as US allies scramble to prevent escalation</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AP24148494855499-e1722768238697-1024x640.jpg" title="Jordan&#8217;s FM to make rare visit to Iran as US allies scramble to prevent escalation" width="160" /></figure>

## Lebanon marks four years since devastating Beirut port blast as war fears loom
 - [https://www.timesofisrael.com/lebanon-marks-four-years-since-devastating-beirut-port-blast-as-war-fears-loom](https://www.timesofisrael.com/lebanon-marks-four-years-since-devastating-beirut-port-blast-as-war-fears-loom)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T11:36:33+00:00

<p>Several marches converge on area to commemorate over 220 victims and demand justice amid stalled probe that still has not attributed responsibility</p>
<p>The post <a href="https://www.timesofisrael.com/lebanon-marks-four-years-since-devastating-beirut-port-blast-as-war-fears-loom/">Lebanon marks four years since devastating Beirut port blast as war fears loom</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2021/07/AP21183446332821-1024x640.jpg" title="Lebanon marks four years since devastating Beirut port blast as war fears loom" width="160" /></figure>

## Help us give Lone Soldiers a Home - Sponsored Content
 - [https://my.israelgives.org/en/fundme/lscHousing?partner=timesofisrael](https://my.israelgives.org/en/fundme/lscHousing?partner=timesofisrael)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T10:40:33+00:00

<p>It's never been harder to serve in the IDF without family nearby. Lone Soldier's Center offers sanctuaries where soldiers can live, relax, and connect with peers in their native language. </p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/help-us-give-lone-soldiers-a-home/">Help us give Lone Soldiers a Home</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/LSC_11-1024x640.jpg" title="Help us give Lone Soldiers a Home" width="160" /></figure>

## Daily Briefing Aug. 4: Day 303 – Iran attack scenarios and how Israel could counter them
 - [https://www.timesofisrael.com/daily-briefing-aug-4-day-303-iran-attack-scenarios-and-how-israel-could-counter-them](https://www.timesofisrael.com/daily-briefing-aug-4-day-303-iran-attack-scenarios-and-how-israel-could-counter-them)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T10:23:48+00:00

<p>Military reporter Emanuel Fabian on fighting in Gaza, continued conflict along the norther border, airstrikes against Hamas terrorists in the West Bank - and Waze disruptions</p>
<p>The post <a href="https://www.timesofisrael.com/daily-briefing-aug-4-day-303-iran-attack-scenarios-and-how-israel-could-counter-them/">Daily Briefing Aug. 4: Day 303 &#8211; Iran attack scenarios and how Israel could counter them</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/F240801DC32-1024x640.jpg" title="Daily Briefing Aug. 4: Day 303 &#8211; Iran attack scenarios and how Israel could counter them" width="160" /></figure>

## Israel braces for Iran attack as US works to revive coalition that foiled April assault
 - [https://www.timesofisrael.com/israel-braces-for-iran-attack-as-us-works-to-revive-coalition-that-foiled-april-assault](https://www.timesofisrael.com/israel-braces-for-iran-attack-as-us-works-to-revive-coalition-that-foiled-april-assault)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T09:11:31+00:00

<p>Israel’s leaders said to discuss readiness for potential ‘all-out war,’ with concerns attack could be on 'several fronts'; CENTCOM head in Israel; Biden says he hopes Tehran stands down</p>
<p>The post <a href="https://www.timesofisrael.com/israel-braces-for-iran-attack-as-us-works-to-revive-coalition-that-foiled-april-assault/">Israel braces for Iran attack as US works to revive coalition that foiled April assault</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/F240801CG37-1024x640.jpg" title="Israel braces for Iran attack as US works to revive coalition that foiled April assault" width="160" /></figure>

## Jordan’s King Abdullah welcomes first grandchild in Amman
 - [https://www.timesofisrael.com/jordans-king-abdullah-welcomes-first-grandchild-in-amman](https://www.timesofisrael.com/jordans-king-abdullah-welcomes-first-grandchild-in-amman)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T07:51:07+00:00

<p>Princess Rajwa, 30, gives birth to baby girl Iman, a year after marrying king's heir and oldest son Hussein; Jordanian law precludes women from inheriting Hashemite throne</p>
<p>The post <a href="https://www.timesofisrael.com/jordans-king-abdullah-welcomes-first-grandchild-in-amman/">Jordan&#8217;s King Abdullah welcomes first grandchild in Amman</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/Screenshot-2024-08-04-100351-e1722755102332-1024x640.png" title="Jordan&#8217;s King Abdullah welcomes first grandchild in Amman" width="160" /></figure>

## Two dead, 2 hurt in terror stabbing spree in Holon; Palestinian attacker shot by police
 - [https://www.timesofisrael.com/one-dead-3-hurt-in-terror-stabbing-spree-in-holon-palestinian-attacker-shot-by-police](https://www.timesofisrael.com/one-dead-3-hurt-in-terror-stabbing-spree-in-holon-palestinian-attacker-shot-by-police)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T06:26:55+00:00

<p>Woman, 66, and man in 70s declared dead; security source says assailant did not have entry permit to Israel, had no prior security-related offenses</p>
<p>The post <a href="https://www.timesofisrael.com/one-dead-3-hurt-in-terror-stabbing-spree-in-holon-palestinian-attacker-shot-by-police/">Two dead, 2 hurt in terror stabbing spree in Holon; Palestinian attacker shot by police</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/F240804AVS02-1024x640.jpg" title="Two dead, 2 hurt in terror stabbing spree in Holon; Palestinian attacker shot by police" width="160" /></figure>

## Far-right protesters clash with police as disinformation-linked unrest sweeps UK
 - [https://www.timesofisrael.com/far-right-protesters-clash-with-police-as-disinformation-linked-unrest-sweeps-uk](https://www.timesofisrael.com/far-right-protesters-clash-with-police-as-disinformation-linked-unrest-sweeps-uk)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T06:16:08+00:00

<p>Starmer announces new security measures to counter anti-immigrant demonstrations sparked by falsities about background of stabber who killed 3 young girls</p>
<p>The post <a href="https://www.timesofisrael.com/far-right-protesters-clash-with-police-as-disinformation-linked-unrest-sweeps-uk/">Far-right protesters clash with police as disinformation-linked unrest sweeps UK</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AFP__20240803__369V4DU__v1__HighRes__BritainCrimePoliceUnrest-e1722748569197-1024x640.jpg" title="Far-right protesters clash with police as disinformation-linked unrest sweeps UK" width="160" /></figure>

## Suspected Houthi missile strike hits container ship in first attack in 2 weeks
 - [https://www.timesofisrael.com/suspected-houthi-missile-strike-hits-container-ship-in-first-attack-in-2-weeks](https://www.timesofisrael.com/suspected-houthi-missile-strike-hits-container-ship-in-first-attack-in-2-weeks)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T05:25:58+00:00

<p>Lull followed Israeli strike on Hodeidah after Yemeni rebels' deadly Tel Aviv drone attack; resumption of attacks by Iran-backed group comes after killing of Haniyeh in Tehran</p>
<p>The post <a href="https://www.timesofisrael.com/suspected-houthi-missile-strike-hits-container-ship-in-first-attack-in-2-weeks/">Suspected Houthi missile strike hits container ship in first attack in 2 weeks</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AFP__20240802__368N9YZ__v8__HighRes__TopshotYemenPalestinianLebanonIsraelConflictPro-e1722747493124-1024x640.jpg" title="Suspected Houthi missile strike hits container ship in first attack in 2 weeks" width="160" /></figure>

## Iran state TV says Haniyeh was killed by short-range projectile, not bomb as reported
 - [https://www.timesofisrael.com/iran-state-tv-says-haniyeh-was-killed-by-short-range-projectile-not-bomb-as-reported](https://www.timesofisrael.com/iran-state-tv-says-haniyeh-was-killed-by-short-range-projectile-not-bomb-as-reported)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T04:46:05+00:00

<p>Seven-kilogram warhead caused blast, says Revolutionary Guard statement, which repeats call to avenge attack 'designed and carried out by the Zionist regime and supported by the US'</p>
<p>The post <a href="https://www.timesofisrael.com/iran-state-tv-says-haniyeh-was-killed-by-short-range-projectile-not-bomb-as-reported/">Iran state TV says Haniyeh was killed by short-range projectile, not bomb as reported</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/07/AFP__20240730__367D7RP__v2__HighRes__IranPoliticsPresident-e1722745610128-1024x640.jpg" title="Iran state TV says Haniyeh was killed by short-range projectile, not bomb as reported" width="160" /></figure>

## Report chronicles emboldening of Hezbollah amid Netanyahu-Gallant tensions in 2023
 - [https://www.timesofisrael.com/report-chronicles-emboldening-of-hezbollah-amid-netanyahu-gallant-tensions-in-2023](https://www.timesofisrael.com/report-chronicles-emboldening-of-hezbollah-amid-netanyahu-gallant-tensions-in-2023)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T03:39:11+00:00

<p>Probe says PM nixed meeting on response to infiltration from Lebanon on day he fired Gallant; intel officers were at IDF HQ on Oct. 6, handling Gaza threat unrelated to Hamas invasion</p>
<p>The post <a href="https://www.timesofisrael.com/report-chronicles-emboldening-of-hezbollah-amid-netanyahu-gallant-tensions-in-2023/">Report chronicles emboldening of Hezbollah amid Netanyahu-Gallant tensions in 2023</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2022/11/Collage-Maker-11-Nov-2022-12.22-PM-1024x640.jpg" title="Report chronicles emboldening of Hezbollah amid Netanyahu-Gallant tensions in 2023" width="160" /></figure>

## Know thine enemy: When the PLO hosted 80 scholars at a Beirut Israel studies center
 - [https://www.timesofisrael.com/know-thine-enemy-when-the-plo-hosted-80-scholars-at-a-beirut-israel-studies-center](https://www.timesofisrael.com/know-thine-enemy-when-the-plo-hosted-80-scholars-at-a-beirut-israel-studies-center)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T03:23:05+00:00

<p>Historian Jonathan Marc Gribetz's ‘Reading Herzl in Beirut’ excavates a forgotten decades-long PLO research center that helped shift some Palestinians’ thinking regarding Israel</p>
<p>The post <a href="https://www.timesofisrael.com/know-thine-enemy-when-the-plo-hosted-80-scholars-at-a-beirut-israel-studies-center/">Know thine enemy: When the PLO hosted 80 scholars at a Beirut Israel studies center</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/12/AP741114020-e1722183616775-1024x640.jpg" title="Know thine enemy: When the PLO hosted 80 scholars at a Beirut Israel studies center" width="160" /></figure>

## Security chiefs, negotiators, US all said blaming Netanyahu for tanking hostage talks
 - [https://www.timesofisrael.com/security-chiefs-negotiators-us-said-all-blaming-netanyahu-for-tanking-hostage-talks](https://www.timesofisrael.com/security-chiefs-negotiators-us-said-all-blaming-netanyahu-for-tanking-hostage-talks)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T01:50:50+00:00

<p>'There's no security reason to delay deal,' Gallant quoted as telling PM, whose office claims that Hamas, rather than the premier, has been introducing new demands to hinder negotiations</p>
<p>The post <a href="https://www.timesofisrael.com/security-chiefs-negotiators-us-said-all-blaming-netanyahu-for-tanking-hostage-talks/">Security chiefs, negotiators, US all said blaming Netanyahu for tanking hostage talks</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/10/KBG_GPO7868-1024x640.jpg" title="Security chiefs, negotiators, US all said blaming Netanyahu for tanking hostage talks" width="160" /></figure>

## At limited weekly rallies amid fears of attack, protesters accuse PM of foiling deal
 - [https://www.timesofisrael.com/at-limited-weekly-rallies-amid-fears-of-attack-protesters-accuse-pm-of-foiling-deal](https://www.timesofisrael.com/at-limited-weekly-rallies-amid-fears-of-attack-protesters-accuse-pm-of-foiling-deal)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-04T01:02:53+00:00

<p>Hostages' relatives say negotiating team's weekend trip to Cairo a sham, pan alleged Israeli hit on Haniyeh for undermining deal with Hamas; some block Tel Aviv highway, 5 arrested</p>
<p>The post <a href="https://www.timesofisrael.com/at-limited-weekly-rallies-amid-fears-of-attack-protesters-accuse-pm-of-foiling-deal/">At limited weekly rallies amid fears of attack, protesters accuse PM of foiling deal</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/F240803AVS211-e1722714749653-1024x640.jpg" title="At limited weekly rallies amid fears of attack, protesters accuse PM of foiling deal" width="160" /></figure>

