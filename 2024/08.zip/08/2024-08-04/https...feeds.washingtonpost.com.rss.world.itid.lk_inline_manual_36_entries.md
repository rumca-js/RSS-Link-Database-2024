# Source:The Washington Post - World, URL:https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36, language:en-US

## Dozens killed as anti-government protests resume in Bangladesh
 - [https://www.washingtonpost.com/world/2024/08/04/bangladesh-protests-cufew-death-toll](https://www.washingtonpost.com/world/2024/08/04/bangladesh-protests-cufew-death-toll)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-08-04T17:41:49+00:00

A nationwide curfew was imposed in Bangladesh as fresh protests in the country turned violent.

## Stabbing near Tel Aviv, strike in Gaza amid fears of wider Mideast war
 - [https://www.washingtonpost.com/world/2024/08/04/israel-gaza-strikes-holon-stabbing-war](https://www.washingtonpost.com/world/2024/08/04/israel-gaza-strikes-holon-stabbing-war)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-08-04T15:11:15+00:00

Two people were killed in stabbing in Holon; Israeli authorities described it as a terror attack. Gazan authorities said an Israeli strike on refugee camps near a hospital killed four people.

## 116 arrested in U.K. as violent far-right protests erupt over deadly stabbing
 - [https://www.washingtonpost.com/world/2024/08/04/uk-riots-protests-southport-stabbing-arrests](https://www.washingtonpost.com/world/2024/08/04/uk-riots-protests-southport-stabbing-arrests)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-08-04T13:01:13+00:00

Demonstrations in cities like Liverpool, Hull and Bristol turned violent, prompting arrests. Misinformation about a knife attack in Southport, England, spurred far-right protests.

## Israeli raids in West Bank cities help fuel militant violence
 - [https://www.washingtonpost.com/world/2024/08/04/israeli-raids-west-bank-cities-help-fuel-militant-violence](https://www.washingtonpost.com/world/2024/08/04/israeli-raids-west-bank-cities-help-fuel-militant-violence)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-08-04T06:00:00+00:00

In the city of Jenin, the impact of the raids — and their role in fueling Palestinian militancy — is especially stark.

