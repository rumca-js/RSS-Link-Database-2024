# Source:Polygon -  All, URL:https://www.polygon.com/rss/index.xml, language:en

## House of the Dragon star Kieran Bew wanted to look like his dragon
 - [https://www.polygon.com/24212224/house-dragon-hugh-hammer-vermithor-interview-episode](https://www.polygon.com/24212224/house-dragon-hugh-hammer-vermithor-interview-episode)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2024-08-04T18:00:00+00:00

<figure>
      <img alt="Hugh Hammer (Kieran Bew) standing in front of Vermithor looking shocked" src="https://cdn.vox-cdn.com/thumbor/KSSe61WR8-PpfiDG19IP1c1PRuk=/0x0:5616x3159/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73501127/HOTD_207_082523_OU_2621.0.jpg" />
        <figcaption>Photo: Ollie Upton/HBO</figcaption>
    </figure>

  <p>‘I felt like it was a slightly funny joke about people who have dogs, end up looking like their dogs’</p>
  <p>
    <a href="https://www.polygon.com/24212224/house-dragon-hugh-hammer-vermithor-interview-episode">Continue reading&hellip;</a>
  </p>

## What time does Diablo 4 season 5 start?
 - [https://www.polygon.com/diablo-4-guides/24211784/season-5-release-time-date](https://www.polygon.com/diablo-4-guides/24211784/season-5-release-time-date)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2024-08-04T17:00:00+00:00

<figure>
      <img alt="A hero in Diablo 4 poses in flaming armor in front of a demon" src="https://cdn.vox-cdn.com/thumbor/l5B4XsbqARthAqrTPlrT4NSZHB0=/539x83:1760x770/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73501045/DIV_S5_BattlePass_01.0.png" />
        <figcaption>Image: Blizzard Entertainment</figcaption>
    </figure>

  <p>What’s new in Diablo 4’s Season of the Infernal Hordes</p>
  <p>
    <a href="https://www.polygon.com/diablo-4-guides/24211784/season-5-release-time-date">Continue reading&hellip;</a>
  </p>

## Every banned Pokémon episode and why they were pulled from TV
 - [https://www.polygon.com/anime/24209763/every-banned-pokemon-episode](https://www.polygon.com/anime/24209763/every-banned-pokemon-episode)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2024-08-04T15:00:00+00:00

<figure>
      <img alt="A two by two header image featuring screenshots of several Pokémon episodes that have been banned throughout the history of the anime series." src="https://cdn.vox-cdn.com/thumbor/CiRCGdO-a2Mj80AUqfOZHPP3bQc=/0x363:4542x2918/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73500926/pokemone_banned_episodes_header.0.jpg" />
        <figcaption>Graphic: Toussaint Egan/Polygon | Source images: OLM/The Pokémon Company</figcaption>
    </figure>


  		<p>You ain’t gonna catch these any time soon</p>
  <p>
    <a href="https://www.polygon.com/anime/24209763/every-banned-pokemon-episode">Continue reading&hellip;</a>
  </p>

