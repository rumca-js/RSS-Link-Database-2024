# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## 'Catastrophic' famine is 'man-made and 100% preventable', experts say
 - [https://news.sky.com/story/sudan-famine-zamzam-camp-starvation-is-man-made-and-100-preventable-experts-say-13190871](https://news.sky.com/story/sudan-famine-zamzam-camp-starvation-is-man-made-and-100-preventable-experts-say-13190871)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-04T16:14:00+00:00

About half a million residents in the Zamzam displacement camp, North Darfur, are living in extreme strife and in a state of famine. A doctor working there describes the humanitarian situation as "catastrophic".

## Simone Biles issues plea after winning her latest gold medal
 - [https://news.sky.com/story/simone-biles-says-stop-asking-whats-next-as-she-hunts-for-two-more-golds-13190587](https://news.sky.com/story/simone-biles-says-stop-asking-whats-next-as-she-hunts-for-two-more-golds-13190587)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-04T11:31:00+00:00

Simone Biles has asked people to stop asking athletes "what's next?" after they win a medal at the Olympics.

## Second boxer caught up in gender row secures Olympic medal
 - [https://news.sky.com/story/paris-2024-olympics-second-boxer-caught-up-in-gender-row-lin-yu-ting-secures-medal-13190580](https://news.sky.com/story/paris-2024-olympics-second-boxer-caught-up-in-gender-row-lin-yu-ting-secures-medal-13190580)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-04T11:27:00+00:00

A second boxer at the centre of an Olympics gender controversy is guaranteed a medal after reaching the featherweight semi-finals in Paris.

## 'She's done us proud': Tiny island celebrates first-ever Olympic medal
 - [https://news.sky.com/story/st-lucia-celebrates-as-julien-alfred-wins-islands-first-ever-olympic-medal-13190534](https://news.sky.com/story/st-lucia-celebrates-as-julien-alfred-wins-islands-first-ever-olympic-medal-13190534)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-04T09:40:00+00:00

Ecstatic fans on the tiny Caribbean island of St Lucia were overcome with joy after Julien Alfred swept to victory in the Olympic women's 100m, stunning a global audience that had booked her American rival as the firm favourite.

## <a href="https://www.skysports.com/olympics/live-blog/32461/13116598/olympics-2024-live-news-updates-from-paris-todays-events-and-latest-results">Team GB beaten by 10-man India in hockey; major star pulls out of 200m | Olympics live from Sky Sports</a>
 - [https://news.sky.com/story/olympics-2024-live-news-updates-from-paris-todays-events-and-latest-results-13190499](https://news.sky.com/story/olympics-2024-live-news-updates-from-paris-todays-events-and-latest-results-13190499)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-04T08:00:00+00:00



## Western products still available in Russia: Magnum and Burger King explain reasons
 - [https://news.sky.com/story/from-whoppers-to-magnums-the-firms-staying-put-in-russia-despite-ukraine-war-13190468](https://news.sky.com/story/from-whoppers-to-magnums-the-firms-staying-put-in-russia-despite-ukraine-war-13190468)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-04T05:34:00+00:00

Some Western companies still operating in Russia are pausing their plans to exit, despite the continued efforts to isolate the country's economy.

## Opposition leader comes out of hiding as protests continue after contested election
 - [https://news.sky.com/story/venezuela-elections-opposition-figure-maria-corina-machado-comes-out-of-hiding-as-protests-continue-after-contested-maduro-win-13190447](https://news.sky.com/story/venezuela-elections-opposition-figure-maria-corina-machado-comes-out-of-hiding-as-protests-continue-after-contested-maduro-win-13190447)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-04T01:57:00+00:00

Thousands have continued to march and attend protests in Venezuela as an opposition leader emerged from hiding to denounce President Nicolas Maduro's contested election victory.

