# Source:The Hill, URL:https://thehill.com/news/feed, language:en-US

## Georgia Republican condemns GOP for staying mum as Trump ‘throws sucker punches’ at Kemp
 - [https://thehill.com/homenews/campaign/4810299-geoff-duncan-condemns-gop-donald-trump-attacks](https://thehill.com/homenews/campaign/4810299-geoff-duncan-condemns-gop-donald-trump-attacks)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-08-04T16:53:14+00:00



## Emhoff acknowledges affair in first marriage: 'I took responsibility'
 - [https://thehill.com/homenews/administration/4809905-second-gentleman-doug-emhoff-admits-affair-first-wedding](https://thehill.com/homenews/administration/4809905-second-gentleman-doug-emhoff-admits-affair-first-wedding)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-08-04T02:58:23+00:00



## What's in the cardboard box medalists get at the Paris Olympics?
 - [https://thehill.com/blogs/in-the-know/4809403-whats-in-the-cardboard-box-medalists-get-at-the-paris-olympics](https://thehill.com/blogs/in-the-know/4809403-whats-in-the-cardboard-box-medalists-get-at-the-paris-olympics)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-08-04T02:14:45+00:00



## Scaramucci: 'Disaster' if Trump doesn't debate Harris
 - [https://thehill.com/homenews/campaign/4809870-anthony-scaramucci-donald-trump-kamala-harris-2024-debate](https://thehill.com/homenews/campaign/4809870-anthony-scaramucci-donald-trump-kamala-harris-2024-debate)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-08-04T02:13:16+00:00



## Don Lemon's case against Elon Musk 'should settle': Attorney
 - [https://thehill.com/policy/technology/4808969-don-lemon-elon-musk-lawsuit-scrapped-x-show-attorney-suggests-settlement](https://thehill.com/policy/technology/4808969-don-lemon-elon-musk-lawsuit-scrapped-x-show-attorney-suggests-settlement)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-08-04T01:34:08+00:00



## Vance continues attack on Harris's background in Atlanta: 'Pretty weird'
 - [https://thehill.com/homenews/campaign/4809810-jd-vance-kamala-harris-background-atlanta-rally](https://thehill.com/homenews/campaign/4809810-jd-vance-kamala-harris-background-atlanta-rally)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-08-04T01:20:54+00:00



## Trump makes Harris, Brian Kemp focal point of attacks at Georgia rally
 - [https://thehill.com/homenews/campaign/4809757-donald-trump-kamala-harris-brian-kemp-election-atlanta-rally-2024](https://thehill.com/homenews/campaign/4809757-donald-trump-kamala-harris-brian-kemp-election-atlanta-rally-2024)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-08-04T00:27:42+00:00



