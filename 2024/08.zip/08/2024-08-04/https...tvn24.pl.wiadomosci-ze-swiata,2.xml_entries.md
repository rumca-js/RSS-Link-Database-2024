# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Izrael zbombardował dwie szkoły w Strefie Gazy. Lokalne władze: zginęło co najmniej 30 osób
 - [https://tvn24.pl/swiat/strefa-gazy-izrael-zbombardowal-dwie-szkoly-w-strefie-gazy-palestynskie-wladze-zginelo-co-najmniej-30-osob-st8030673?source=rss](https://tvn24.pl/swiat/strefa-gazy-izrael-zbombardowal-dwie-szkoly-w-strefie-gazy-palestynskie-wladze-zginelo-co-najmniej-30-osob-st8030673?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T20:14:41+00:00

<img alt="Izrael zbombardował dwie szkoły w Strefie Gazy. Lokalne władze: zginęło co najmniej 30 osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8682336-izrael-kontynuuje-naloty-na-strefe-gazy-ph8030675/alternates/LANDSCAPE_1280" />
    Izraelskie wojska zaatakowały dwie szkoły w mieście Gaza. W atakach zginęło - jak przekazują lokalne władze - co najmniej 30 osób, przede wszystkim kobiety i dzieci. "Zniszczone placówki były wykorzystywane przez Hamas do celów terrorystycznych" - komentowała izraelska armia.

## Zalane ulice i powalone drzewa na Pomorzu
 - [https://tvn24.pl/tvnmeteo/polska/zalane-ulice-i-powalone-drzewa-na-pomorzu-st8030667?source=rss](https://tvn24.pl/tvnmeteo/polska/zalane-ulice-i-powalone-drzewa-na-pomorzu-st8030667?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T19:40:06+00:00

<img alt="Zalane ulice i powalone drzewa na Pomorzu" src="https://kontakt24.tvn24.pl/najnowsze/cdn-zdjecie-9246161-przewrocone-drzewo-po-intensywnej-ulewie-jantar-pomorskie-ph8030656/alternates/LANDSCAPE_1280" />
    Niedzielne burze spowodowały szkody na północy kraju. W województwie pomorskim strażacy interweniowali w związku z powalonymi drzewami i zalanymi drogami. Na Kontakt 24 otrzymaliśmy zdjęcia.

## "Ten atak nastąpi. Jaki będzie? Nikt tego nie wie"
 - [https://tvn24.pl/swiat/ten-atak-nastapi-jaki-bedzie-nikt-tego-nie-wie-st8030616?source=rss](https://tvn24.pl/swiat/ten-atak-nastapi-jaki-bedzie-nikt-tego-nie-wie-st8030616?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T19:19:10+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9351296-izraelska-zelazna-kopula-w-czasie-ataku-ph8030627/alternates/LANDSCAPE_1280" />
    Odwet na pewno nastąpi, choćby dla opinii publicznej w Iranie jest on niezbędny - powiedział w "Faktach po Faktach" w TVN24 doktor Maciej Kozłowski, były ambasador Polski w Izraelu. Zaznaczył, że "decyzja zapadnie na pewno w Teheranie, Izrael może tylko zareagować". Doktor habilitowany Łukasz Fyderek z Uniwersytetu Jagiellońskiego wskazał, że do przełamania izraelskich systemów potrzebny jest atak zmasowany, a to jest scenariusz, który prowadzi "do rollercoastera eskalacji".

## Pani Anita nie jest w stanie samodzielnie funkcjonować. Otyłość spowodowała u niej wiele chorób
 - [https://fakty.tvn24.pl/zobacz-fakty/pani-anita-nie-jest-w-stanie-samodzielnie-funkcjonowac-otylosc-spowodowala-u-niej-wiele-chorob-st8030497?source=rss](https://fakty.tvn24.pl/zobacz-fakty/pani-anita-nie-jest-w-stanie-samodzielnie-funkcjonowac-otylosc-spowodowala-u-niej-wiele-chorob-st8030497?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T18:16:46+00:00

<img alt="Pani Anita nie jest w stanie samodzielnie funkcjonować. Otyłość spowodowała u niej wiele chorób" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-4780845-kijowska-ph8030586/alternates/LANDSCAPE_1280" />
    Od lat nie wychodziła z domu, od miesięcy jest przykuta do łóżka. Pani Anita jest więźniem własnego ciała. Otyłość spowodowała niewydolność krążeniowo-oddechową i olbrzymi obrzęk nóg. Nie jest w stanie samodzielnie funkcjonować, a jej życie wisi na włosku.

## "Bardzo trudno jest zarejestrować tak wyjątkowe sceny"
 - [https://tvn24.pl/tvnmeteo/ciekawostki/rzadka-scena-ze-swiata-przyrody-na-nagraniu-st8030574?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/rzadka-scena-ze-swiata-przyrody-na-nagraniu-st8030574?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T18:05:24+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3421510-wilki-ph8030590/alternates/LANDSCAPE_1280" />
    Nagranie rzadkiej sceny ze świata przyrody, dostaliśmy na Kontakt 24. Widać na nim, jak grupa wilków spotyka w lesie dzika bez nogi. - Widząc jego determinację we własnej obronie wiedziały, że nie warto ryzykować - stwierdził autor filmu.

## Wjechała do rzeki. W aucie była jej córka
 - [https://tvn24.pl/polska/napekow-wjechala-do-rzeki-w-aucie-byla-jej-corka-st8030566?source=rss](https://tvn24.pl/polska/napekow-wjechala-do-rzeki-w-aucie-byla-jej-corka-st8030566?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T17:29:22+00:00

<img alt="Wjechała do rzeki. W aucie była jej córka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7513229-kobieta-wjechala-autem-do-rzeki-ph8030543/alternates/LANDSCAPE_1280" />
    49-letnia kobieta zjechała z drogi i wjechała samochodem do rzeki w Napękowie w województwie świętokrzyskim. Jej 8-letnia córka trafiła do szpitala.

## Pogoda na jutro - poniedziałek 05.08. Miejscami poniżej 20 stopni
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-0508-miejscami-ponizej-20-stopni-st8030503?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-0508-miejscami-ponizej-20-stopni-st8030503?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T17:21:38+00:00

<img alt="Pogoda na jutro - poniedziałek 05.08. Miejscami poniżej 20 stopni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x0amdv-deszcz-7020018/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. Poniedziałek 05.08 w wielu regionach kraju zapowiada się chłodno i deszczowo. Synoptycy przewidują również burze. Aura na przeważającym obszarze Polski niekorzystnie wpłynie na samopoczucie.

## Uwierzyli w szybki zysk, stracili oszczędności życia. Po metodzie "na wnuczka" przyszła metoda "na inwestycję"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/uwierzyli-w-szybki-zysk-stracili-oszczednosci-zycia-po-metodzie-na-wnuczka-przyszla-metoda-na-inwestycje-st8030452?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/uwierzyli-w-szybki-zysk-stracili-oszczednosci-zycia-po-metodzie-na-wnuczka-przyszla-metoda-na-inwestycje-st8030452?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T15:56:29+00:00

<img alt="Uwierzyli w szybki zysk, stracili oszczędności życia. Po metodzie " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-9851989-oszustwa-ph8030457/alternates/LANDSCAPE_1280" />
    Mechanizmy się zmieniają, są inne haczyki, ale efekt wciąż ten sam - z okradanych kont znikają wielkie sumy. Oszuści zachęcają do inwestycji, tworzą fałszywe reklamy, kuszą zyskiem, wyciągają dane i zabierają pieniądze. Czujność i nieufność, gdy chodzi o pieniądze i konta, jest bardzo ważna.

## Żona premiera Hiszpanii pozwała sędziego, który prowadzi jej sprawę
 - [https://tvn24.pl/swiat/zona-premiera-hiszpanii-pozwala-sedziego-ktory-prowadzi-jej-sprawe-st8030458?source=rss](https://tvn24.pl/swiat/zona-premiera-hiszpanii-pozwala-sedziego-ktory-prowadzi-jej-sprawe-st8030458?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T15:25:13+00:00

<img alt="Żona premiera Hiszpanii pozwała sędziego, który prowadzi jej sprawę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6593599-gettyimages-2007866880-ph8030460/alternates/LANDSCAPE_1280" />
    Begona Gomez, żona premiera Hiszpanii Pedro Sancheza, pozwała sędziego prowadzącego sprawę, w której jest oskarżona o korupcję - przekazali jej obrońcy. Skargę złożyła przed Wyższym Sądem Wspólnoty Autonomicznej Madrytu, wskazując, że nadużycie polegało na ujawnieniu objętych klauzulą tajności szczegółów procesu. Wcześniej sędziego pozwał jej mąż.

## Wołodymyr Zełenski pokazał F-16
 - [https://tvn24.pl/swiat/wolodymyr-zelenski-pokazal-f-16-st8030454?source=rss](https://tvn24.pl/swiat/wolodymyr-zelenski-pokazal-f-16-st8030454?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T14:58:16+00:00

<img alt="Wołodymyr Zełenski pokazał F-16" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7409943-f-16-nad-ukraina-ph8030473/alternates/LANDSCAPE_1280" />
    Piloci ukraińskich sił powietrznych zaczęli latać samolotami F-16 - potwierdził prezydent Wołodymyr Zełenski. Pokazał również nagranie myśliwców, które zostały dostarczone na Ukrainę po ponad dwóch latach od wybuchu inwazji zbrojnej Rosji.

## Nie mówiła do teściów "mamo" i "tato". Sąd uznał ją winną
 - [https://tvn24.pl/swiat/nie-mowila-do-tesciow-mamo-i-tato-sad-uznal-ja-winna-st8030434?source=rss](https://tvn24.pl/swiat/nie-mowila-do-tesciow-mamo-i-tato-sad-uznal-ja-winna-st8030434?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T14:42:26+00:00

<img alt="Nie mówiła do teściów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1060993-shutterstock1121758775-ph8030440/alternates/LANDSCAPE_1280" />
    Turecki najwyższy sąd apelacyjny podtrzymał decyzję sądu niższej instancji, który uznał kobietę za winną rozwodu między innymi z powodu nienazywania teściów "mamą" i "tatą". Kobieta obwiniła męża o zaniedbywanie jej i dzieci oraz wysyłanie agresywnych wiadomości.

## Pożar przy bazie Rosjan. "Szybciutko wyjeżdżają"
 - [https://tvn24.pl/swiat/mariupol-pozar-przy-bazie-rosjan-szybciutko-wyjezdzaja-st8030419?source=rss](https://tvn24.pl/swiat/mariupol-pozar-przy-bazie-rosjan-szybciutko-wyjezdzaja-st8030419?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T14:32:11+00:00

<img alt="Pożar przy bazie Rosjan. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6399628-dym-w-rejonie-bazy-wojskowej-rosjan-w-mariupolu-ph8030422/alternates/LANDSCAPE_1280" />
    W okolicach bazy wojskowej Rosjan w Mariupolu wybuchł pożar - przekazał Petro Andriuszczenko, doradca mera miasta, przebywającego poza jego granicami. Andriuszczenko poinformował, że pożar "jest obserwowany przez całe miasto, a Rosjanie szybciutko wyjeżdżają".

## "Generalny piekący skwar" we Włoszech. Temperatura będzie tylko rosnąć
 - [https://tvn24.pl/tvnmeteo/swiat/upaly-we-wloszech-temperatura-bedzie-tylko-rosnac-st8030423?source=rss](https://tvn24.pl/tvnmeteo/swiat/upaly-we-wloszech-temperatura-bedzie-tylko-rosnac-st8030423?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T14:14:11+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vf4k1t-upalna-pogoda-w-rzymie-6236130/alternates/LANDSCAPE_1280" />
    We Włoszech rozpoczyna się najgorętszy okres lata, w którym codziennie ma być notowany wzrost temperatury. Kulminacja upałów nastąpi 13 i 14 sierpnia - zapowiadają tamtejsi synoptycy.

## Kreml ugiął się pod presją USA i Arabii Saudyjskiej
 - [https://tvn24.pl/swiat/kreml-ugial-sie-pod-presja-usa-i-arabii-saudyjskiej-st8030250?source=rss](https://tvn24.pl/swiat/kreml-ugial-sie-pod-presja-usa-i-arabii-saudyjskiej-st8030250?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T14:02:44+00:00

<img alt="Kreml ugiął się pod presją USA i Arabii Saudyjskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5979-rebelianci-huti-biora-udzial-w-manewrach-wojskowych-majacych-na-celu-wyrazenie-solidarnosci-z-narodem-palestynskim-ph7417877/alternates/LANDSCAPE_1280" />
    Rosja wstrzymała dostawy uzbrojenia dla rebeliantom Huti w Jemenie z powodu presji wywieranej przez USA i Arabię Saudyjską - poinformowała amerykańska telewizja CNN. Zdaniem analityków, plany Rosji, dotyczące dozbrajania rebeliantów Huti, pokazują jej rosnące partnerstwo wojskowe z Iranem. "Kreml w ten sposób chce także zmusić Zachód, by przestał wspierać Ukrainę" - oceniają.

## Kosiniak-Kamysz: Marian Tokarski zginął w wypadku
 - [https://tvn24.pl/lublin/kosiniak-kamysz-marian-tokarski-zginal-w-wypadku-st8030411?source=rss](https://tvn24.pl/lublin/kosiniak-kamysz-marian-tokarski-zginal-w-wypadku-st8030411?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T13:34:33+00:00

<img alt="Kosiniak-Kamysz: Marian Tokarski zginął w wypadku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9749552-marian-tokarski-ph8030408/alternates/LANDSCAPE_1280" />
    Marian Tokarski, były starosta biłgorajski, działacz Polskiego Stronnictwa Ludowego, zmarł na skutek obrażeń odniesionych w wypadku drogowym. Miał 75 lat. Władysław Kosiniak-Kamysz napisał w mediach społecznościowych, że Tokarski był "oddany swojej małej ojczyźnie, gotowy nieść pomoc każdemu, kto jej potrzebuje".

## Bywa ciężko, "ale nie mamy dokąd uciekać"
 - [https://tvn24.pl/biznes/dlafirm/browary-rzemieslnicze-w-polsce-wiele-browarow-nie-ma-pomyslu-na-siebie-i-wypada-z-rynku-st8017595?source=rss](https://tvn24.pl/biznes/dlafirm/browary-rzemieslnicze-w-polsce-wiele-browarow-nie-ma-pomyslu-na-siebie-i-wypada-z-rynku-st8017595?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T12:49:31+00:00

<img alt="Bywa ciężko, " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-7947293-andrzej-czech-browar-ursa-maior-ph8017994/alternates/LANDSCAPE_1280" />
    - To była duża inwestycja, bardzo ryzykowna. Podejście do finansowania robiliśmy w 2011 roku. Browary rzemieślnicze w ogóle nie istniały w świadomości instytucji finansowych. Nikt nie wiedział, co to jest i rozmowy z bankami były ciężkie - wspomina Andrzej Czech, właściciel Ursa Maior, jednego z pierwszych rzemieślniczych browarów w Polsce. - Później fala jednak popłynęła i piwa rzemieślnicze stały się modne. Z jednej strony być może i jest łatwiej, a z drugiej wiele browarów nie ma pomysłu na siebie i wypada z rynku - stwierdza w rozmowie z biznesową redakcją tvn24.pl.

## Polskie MSZ ponawia ostrzeżenia. "Rząd gotowy na każdą ewentualność"
 - [https://tvn24.pl/swiat/liban-bliski-wschod-polskie-msz-ostrzega-wskazane-jest-opuszczenie-zagrozonego-rejonu-st8030373?source=rss](https://tvn24.pl/swiat/liban-bliski-wschod-polskie-msz-ostrzega-wskazane-jest-opuszczenie-zagrozonego-rejonu-st8030373?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T12:37:27+00:00

<img alt="Polskie MSZ ponawia ostrzeżenia. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4397586-bejrut-ph8030367/alternates/LANDSCAPE_1280" />
    Polski resort dyplomacji ponawia ostrzeżenia przed podróżami do Libanu. - Zaznaczamy w naszych komunikatach, że jeżeli sytuacja nie wymaga bezwzględnej konieczności pozostawania na terytorium Libanu, to wskazane jest opuszczenie zagrożonych rejonów - powiedział w niedzielę wiceminister Andrzej Szejna. Wczoraj władze USA i Wielkiej Brytanii zaapelowały do swoich obywateli, aby ci opuścili Liban.

## Wiatr porwał dmuchany zamek pełen dzieci. Jedno nie przeżyło
 - [https://tvn24.pl/tvnmeteo/swiat/usa-wiatr-porwal-dmuchany-zamek-pelen-dzieci-jedno-nie-przezylo-st8030256?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-wiatr-porwal-dmuchany-zamek-pelen-dzieci-jedno-nie-przezylo-st8030256?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T12:30:00+00:00

<img alt="Wiatr porwał dmuchany zamek pełen dzieci. Jedno nie przeżyło" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5576456-waldorf-w-stanie-maryland-ph8030354/alternates/LANDSCAPE_1280" />
    Silny wiatr porwał dmuchaniec pełen bawiących się na nim dzieci w amerykańskim stanie Maryland. Jednego dziecko zginęło, a drugie zostało ranne.

## Trump gratuluje Putinowi zawarcia "wspaniałej umowy"
 - [https://tvn24.pl/swiat/wymiana-wiezniow-rosji-z-zachodem-donald-trump-pogratulowal-wladimirowi-putinowi-wspanialej-umowy-st8030350?source=rss](https://tvn24.pl/swiat/wymiana-wiezniow-rosji-z-zachodem-donald-trump-pogratulowal-wladimirowi-putinowi-wspanialej-umowy-st8030350?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T12:07:14+00:00

<img alt="Trump gratuluje Putinowi zawarcia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5083091-putin-ph8030345/alternates/LANDSCAPE_1280" />
    Donald Trump nie zwalnia w krytykowaniu administracji Joe Bidena i demokratów. Na ostatnim wiecu pogratulował prezydentowi Rosji Władimirowi "wspaniałej" wymiany więźniów z Zachodem. Kandydat Partii Republikańskiej w listopadowych wyborach prezydenckich przedstawił rosyjskiego przywódcę jako zwycięzcę historycznego wydarzenia, które doprowadziło do uwolnienia kilku Amerykanów. Żadnego z uwolnionych Amerykanów nie przedstawił na wiecu nawet z nazwiska - podkreśla "The Washington Post".

## Sami zawodnicy "robią cyrk z tej olimpiady"?
 - [https://konkret24.tvn24.pl/swiat/igrzyska-olimpijskie-paryz-2024-sami-zawodnicy-robia-cyrk-z-tej-olimpiady-st8029557?source=rss](https://konkret24.tvn24.pl/swiat/igrzyska-olimpijskie-paryz-2024-sami-zawodnicy-robia-cyrk-z-tej-olimpiady-st8029557?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T12:00:23+00:00

<img alt="Sami zawodnicy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6729106-sami-zawodnicy-robia-cyrk-z-tej-olimpiady-no-nie-ph8028834/alternates/LANDSCAPE_1280" />
    Kontrowersje i ironiczne komentarze budzi popularne w mediach społecznościowych zdjęcie mające przedstawiać zawodnika igrzysk w Paryżu strzelającego do tyłu. Oczywiście, takiej dyscypliny nie ma – to fotomontaż.

## Pogoda na 16 dni: sierpniowy szczyt temperatury na horyzoncie
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-16-dni-sierpniowy-szczyt-temperatury-na-horyzoncie-dlugoterminowa-prognoza-pogody-tomasza-wasilewskiego-st8030297?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-16-dni-sierpniowy-szczyt-temperatury-na-horyzoncie-dlugoterminowa-prognoza-pogody-tomasza-wasilewskiego-st8030297?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T11:48:20+00:00

<img alt="Pogoda na 16 dni: sierpniowy szczyt temperatury na horyzoncie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9282897-16-dni-16-ph8030328/alternates/LANDSCAPE_1280" />
    Najgorętsza pogoda czeka nas w połowie miesiąca. Jak duże czekają nas upały? Sprawdź długoterminową prognozę pogody na 16 dni przygotowaną przez Tomasza Wasilewskiego.

## Rachunki mogą poszybować. Rząd zapowiada "odpowiednie działania osłonowe"
 - [https://tvn24.pl/biznes/z-kraju/ets2-rzad-zapowiada-wprowadzenie-dzialan-oslonowych-st8030349?source=rss](https://tvn24.pl/biznes/z-kraju/ets2-rzad-zapowiada-wprowadzenie-dzialan-oslonowych-st8030349?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T11:32:36+00:00

<img alt="Rachunki mogą poszybować. Rząd zapowiada " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nj00qz-rachunki-oplaty-shutterstock_2232534015-7349878/alternates/LANDSCAPE_1280" />
    Odpowiednie działania osłonowe i inwestycyjne planowane przez rząd mają maksymalnie złagodzić skutki wprowadzenia drugiej wersji Europejskiego Systemu Handlu Emisjami (ETS2) - powiedział wiceszef Ministerstwa Funduszy i Polityki Regionalnej Jan Szyszko. Dodał, że cześć z nich będzie finansowana ze Społecznego Funduszu Klimatycznego, z którego Polsce przypadnie około 50 miliardów złotych.

## "Dywan" z prusaków, w mieszkaniu stos śmieci. "Nie jestem w stanie spać"
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-zbieracz-w-bloku-na-gibalskiego-st8030150?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-zbieracz-w-bloku-na-gibalskiego-st8030150?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T11:13:33+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-874975-lokator-przynosi-do-swojego-mieszkania-smieci-ph8030168/alternates/LANDSCAPE_1280" />
    W tym mieszkaniu niełatwo było otworzyć drzwi na oścież, bo przeszkadzały śmieci. Prusaki i inne uwielbiające brud insekty przechodzą swobodnie do mieszkań sąsiadów z bloku. Zaalarmowane służby podejmują działania, ale wszyscy są zgodni - człowieka, który robi ze swojego mieszkania śmietnisko, bardzo trudno jest zmusić do porządku. Sytuacja, w której karaluchy od sąsiada chodzą po ich ścianach, może trwać latami.

## Auto prowadzone przez nieletniego rozbiło się na wiadukcie
 - [https://tvn24.pl/polska/skalmierzyce-auto-prowadzone-przez-nieletniego-rozbilo-sie-na-wiadukcie-st8030293?source=rss](https://tvn24.pl/polska/skalmierzyce-auto-prowadzone-przez-nieletniego-rozbilo-sie-na-wiadukcie-st8030293?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T10:59:57+00:00

<img alt="Auto prowadzone przez nieletniego rozbiło się na wiadukcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4625632-policja-interweniowala-w-skalmierzycach-zdjecie-ilustracyjne-ph7984892/alternates/LANDSCAPE_1280" />
    Do niebezpiecznego wypadku doszło w niedzielę na wiadukcie w miejscowości Skalmierzyce (woj. wielkopolskie). Nietrzeźwy 17-latek rozbił się na barierze. Autem wiózł cztery inne osoby.

## Janusz Kowalski przeprasza. "Temu PiS-owskiemu misiu musi się ostro palić pod stopami"
 - [https://tvn24.pl/polska/janusz-kowalski-przeprasza-byla-opozycje-bartosz-arlukowicz-musi-mu-sie-ostro-palic-pod-stopami-st8030208?source=rss](https://tvn24.pl/polska/janusz-kowalski-przeprasza-byla-opozycje-bartosz-arlukowicz-musi-mu-sie-ostro-palic-pod-stopami-st8030208?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T10:26:01+00:00

<img alt="Janusz Kowalski przeprasza. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7808219-pap202303091j0-ph8030318/alternates/LANDSCAPE_1280" />
    My w Prawie i Sprawiedliwości ogólnie nie uważamy, że jesteśmy nieomylni - powiedział w "Kawie na Ławie" Tobiasz Bocheński, komentując przeprosiny Janusza Kowalskiego pod adresem byłej opozycji. - Temu PiS-owskiemu misiu musi się ostro palić pod stopami. Jak już Kowalski lata po telewizorach i przeprasza za Kaczyńskiego, to znaczy, że jest gorąco - stwierdził Bartosz Arłukowicz z PO. Joanna Mucha z Trzeciej Drogi powiedziała, że nie wierzy w skruchę Kowalskiego. - Być może to jest pierwszy krok do tego, żeby ratować się z tonącego okrętu - oceniła.

## Gdzie jest burza? Grzmi, pada wieje
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-0408-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st8030286?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-0408-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st8030286?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T10:21:02+00:00

<img alt="Gdzie jest burza? Grzmi, pada wieje" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dl3ose-burze-i-deszcz-5753503/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W niedzielę 04.08 nad Polską pojawiają się wyładowania atmosferyczne. Wiatr w porywach rozpędza się do 70 kilometrów na godzinę. Śledź aktualną sytuację pogodową w kraju na tvnmeteo.pl.

## Gdzie jest burza? Pierwsze wyładowania nad Polską
 - [https://tvn24.pl/tvnmeteo/prognoza/gdzie-jest-burza-burze-w-polsce-w-niedziele-0408-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st8030286?source=rss](https://tvn24.pl/tvnmeteo/prognoza/gdzie-jest-burza-burze-w-polsce-w-niedziele-0408-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st8030286?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T10:21:02+00:00

<img alt="Gdzie jest burza? Pierwsze wyładowania nad Polską" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9704237-piorun-ph3149388/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W niedzielę 04.08 nad Polską pojawiają się wyładowania atmosferyczne. Grzmi, wieje i pada. Śledź aktualną sytuację pogodową w kraju na tvnmeteo.pl.

## Ekspedientki miały dość natarczywego klienta, właśnie usłyszał wyrok
 - [https://tvn24.pl/tvnwarszawa/okolice/grojec-wyrok-dla-klienta-ktory-nekal-ekspedientki-st8030248?source=rss](https://tvn24.pl/tvnwarszawa/okolice/grojec-wyrok-dla-klienta-ktory-nekal-ekspedientki-st8030248?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T10:12:47+00:00

<img alt="Ekspedientki miały dość natarczywego klienta, właśnie usłyszał wyrok " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2956245-ekspedientki-mialy-dosc-natarczywego-klienta-zdjecie-ilustracyjne-ph8030258/alternates/LANDSCAPE_1280" />
    Jest wyrok za nękanie ekspedientek. Na osiem miesięcy więzienia w zawieszeniu na trzy lata skazał sąd w Grójcu (Mazowieckie) 48-latka, który kilka razy dziennie przychodził do sklepu. Nagabywał i przynosił kobietom kwiaty. Kiedy odrzucały jego zaloty, stawał się agresywny i im groził.

## Ukraińcy górą osiem tysięcy razy. Wołodymyr Zełenski dziękuje siłom powietrznym
 - [https://tvn24.pl/swiat/ukraina-sily-powietrzne-zestrzelily-osiem-tysiecy-rosyjskich-celow-od-poczatku-inwazji-st8030134?source=rss](https://tvn24.pl/swiat/ukraina-sily-powietrzne-zestrzelily-osiem-tysiecy-rosyjskich-celow-od-poczatku-inwazji-st8030134?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T10:12:21+00:00

<img alt="Ukraińcy górą osiem tysięcy razy. Wołodymyr Zełenski dziękuje siłom powietrznym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7180226-sily-powietrzne-ukrainy-ph8030153/alternates/LANDSCAPE_1280" />
    Dowódca ukraińskich sił powietrznych Mykoła Ołeszczuk poinformował, że w ciągu dwóch i pół roku żołnierze tej formacji zestrzeliły ponad osiem tysięcy rosyjskich celów: rakiet, dronów szturmowych, samolotów i śmigłowców.

## Sprawca śmiertelnego wypadku zatrzymany po czterech latach. Polaka odnaleziono w Paryżu
 - [https://tvn24.pl/lodz/sprawca-smiertelnego-wypadku-zatrzymany-po-czterech-latach-polaka-odnaleziono-w-paryzu-st8030167?source=rss](https://tvn24.pl/lodz/sprawca-smiertelnego-wypadku-zatrzymany-po-czterech-latach-polaka-odnaleziono-w-paryzu-st8030167?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T09:48:28+00:00

<img alt="Sprawca śmiertelnego wypadku zatrzymany po czterech latach. Polaka odnaleziono w Paryżu" src="https://tvn24.pl/lodz/cdn-zdjecie-446768-sprawca-smiertelnego-wypadku-zatrzymany-po-4-latach-polaka-odnaleziono-w-paryzu-ph8030185/alternates/LANDSCAPE_1280" />
    Dzięki współpracy polskich i francuskich policjantów w Paryżu doszło do zatrzymania mężczyzny, który w lutym 2020 r. doprowadził do śmiertelnego wypadku na jednej z łódzkich ulic. Był poszukiwany Europejskim Nakazem Aresztowania i Czerwoną Notą Interpolu.

## Kolejna erupcja Etny. Opóźnione loty
 - [https://tvn24.pl/tvnmeteo/swiat/etna-znow-wybuchla-opoznione-loty-st8030138?source=rss](https://tvn24.pl/tvnmeteo/swiat/etna-znow-wybuchla-opoznione-loty-st8030138?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T09:32:38+00:00

<img alt="Kolejna erupcja Etny. Opóźnione loty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8064458-etna-wybuchla-ph8030482/alternates/LANDSCAPE_1280" />
    W niedzielę ograniczony został ruch samolotów na lotnisku w Katanii na Sycylii z powodu wzmożonej aktywności wulkanu Etna. Pasażerów poproszono o to, by zwracali się do linii po informacje na temat ich lotów. Zdjęcia, na których widać erupcję, otrzymaliśmy na Kontakt 24.

## Buffett pozbywa się akcji Apple. Gigantyczna wyprzedaż
 - [https://tvn24.pl/biznes/ze-swiata/raport-wynikowy-berkshire-hathaway-spolki-warrena-buffetta-st8030103?source=rss](https://tvn24.pl/biznes/ze-swiata/raport-wynikowy-berkshire-hathaway-spolki-warrena-buffetta-st8030103?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T09:24:28+00:00

<img alt="Buffett pozbywa się akcji Apple. Gigantyczna wyprzedaż" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bkaoel-warren-buffett-7903133/alternates/LANDSCAPE_1280" />
    Spółka Berkshire Hathaway, należąca do Warrena Buffetta, zmniejszyła swoje udziały w technologicznym gigancie Apple o prawie 50 procent. Tak wynika z opublikowanego w sobotę raportu Berkshire.

## Jechał za szybko, potrącił rowerzystę. 25-latek zginął na miejscu
 - [https://tvn24.pl/rzeszow/jechal-za-szybko-potracil-rowerzyste-25-latek-zginal-na-miejscu-st8030136?source=rss](https://tvn24.pl/rzeszow/jechal-za-szybko-potracil-rowerzyste-25-latek-zginal-na-miejscu-st8030136?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T08:52:33+00:00

<img alt="Jechał za szybko, potrącił rowerzystę. 25-latek zginął na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3524149-wypadek-w-leszczach-ph8030144/alternates/LANDSCAPE_1280" />
    Tragiczny wypadek w miejscowości Leszcze na Podkarpaciu. Samochód osobowy potrącił rowerzystę. 25-letni poruszający się jednośladem zginął na miejscu.

## Pielgrzymi wyruszają na Jasną Górę, będą utrudnienia
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-pielgrzymi-wyruszaja-na-jasna-gore-beda-utrudnienia-st8030011?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-pielgrzymi-wyruszaja-na-jasna-gore-beda-utrudnienia-st8030011?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T08:26:38+00:00

<img alt="Pielgrzymi wyruszają na Jasną Górę, będą utrudnienia " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2428672-najstarsza-warszawska-pielgrzymka-wyruszyla-na-jasna-gore-zdjecie-archiwalne-ph6059244/alternates/LANDSCAPE_1280" />
    Urzędnicy przypominają: w poniedziałek i wtorek rano ruszają pielgrzymki do Częstochowy. Kierowcy i pasażerowie komunikacji publicznej muszą się liczyć z utrudnieniami.

## Masy błota zepchnęły samochody z autostrady
 - [https://tvn24.pl/tvnmeteo/swiat/masy-blota-zepchnely-samochody-z-autostrady-st8030071?source=rss](https://tvn24.pl/tvnmeteo/swiat/masy-blota-zepchnely-samochody-z-autostrady-st8030071?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T08:20:35+00:00

<img alt="Masy błota zepchnęły samochody z autostrady" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6595403-lawiny-blotne-w-prowincji-syczuan-ph8030125/alternates/LANDSCAPE_1280" />
    Osuwiska sparaliżowały część chińskiej prowincji Syczuan. W regionie doszło do ulewnych opadów deszczu, które spowodowały zejście lawin błotnych na obszarach miejskich oraz drogach. Zginęły co najmniej dwie osoby, 17 jest zaginionych.

## Wypadek w stolarni. Deska wypadła z maszyny i raniła pracownika zakładu
 - [https://tvn24.pl/trojmiasto/miastko-wypadek-w-stolarni-deska-wypadla-z-maszyny-i-ranila-pracownika-zakladu-st8030077?source=rss](https://tvn24.pl/trojmiasto/miastko-wypadek-w-stolarni-deska-wypadla-z-maszyny-i-ranila-pracownika-zakladu-st8030077?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T08:14:37+00:00

<img alt="Wypadek w stolarni. Deska wypadła z maszyny i raniła pracownika zakładu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2454448-lotnicze-pogotowie-ratunkowe-lpr-ph8028330/alternates/LANDSCAPE_1280" />
    60-latek z rozległymi obrażeniami został przetransportowany do szpitala, po tym jak drewniana deska z impetem wypadła z wielopiły i raniła go w brzuch. Mężczyzna przeszedł operację. Sprawę wypadku z Miastka (woj. pomorskie) bada policja.

## Grecja, Turcja i Morze Śródziemne. "Widzimy dwa kraje należące do NATO, niestety będące przeciwnikami"
 - [https://tvn24.pl/swiat/grecja-turcja-i-morze-srodziemne-widzimy-dwa-kraje-nalezace-do-nato-niestety-bedace-przeciwnikami-st8030010?source=rss](https://tvn24.pl/swiat/grecja-turcja-i-morze-srodziemne-widzimy-dwa-kraje-nalezace-do-nato-niestety-bedace-przeciwnikami-st8030010?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T08:09:06+00:00

<img alt="Grecja, Turcja i Morze Śródziemne. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2341233-grecja-wyspa-kasos-ph8030042/alternates/LANDSCAPE_1280" />
    Grecja i Turcja od czasu ubiegłorocznego trzęsienia ziemi obiecały sobie starania o "normalne stosunki" i rozmowy "w spokojnym tonie", ale brak porozumienia w sprawie tego, "co do kogo należy" na Morzu Śródziemnym powoduje silne napięcia - mówi ekspert greckiego think tanku Eliamep profesor Panagiotis Cakonas.

## Pożar na 21. piętrze wieżowca na Woli
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-pozar-na-21-pietrze-na-chlodnej-st8030069?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-pozar-na-21-pietrze-na-chlodnej-st8030069?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T08:04:47+00:00

<img alt="Pożar na 21. piętrze wieżowca na Woli" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-489495-pozar-na-chlodnej-ph8030074/alternates/LANDSCAPE_1280" />
    Ogień pojawił się w jednym z wieżowców w na Woli. Strażacy wstępnie ocenili, że paliła się instalacja.

## LOT przedłużył zawieszenie lotów do Izraela
 - [https://tvn24.pl/biznes/z-kraju/lot-przedluzyl-zawieszenie-lotow-do-izraela-st8030097?source=rss](https://tvn24.pl/biznes/z-kraju/lot-przedluzyl-zawieszenie-lotow-do-izraela-st8030097?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T08:00:44+00:00

<img alt="LOT przedłużył zawieszenie lotów do Izraela    " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6f486b-pll-lot-odwoluje-rejsy-do-izraela-zdj-ilustracyjne-7380035/alternates/LANDSCAPE_1280" />
    Polskie Linie Lotnicze LOT przedłużyły zawieszenie lotów do i z Izraela oraz odwołały połączenia z Warszawy do Tel Awiwu 4 i 5 sierpnia oraz powrotne 5 i 6 sierpnia. W piątek przewoźnik odwołał osiem połączeń z Izraelem i Libanem "po przeprowadzeniu analizy bezpieczeństwa operacji lotniczych".

## Motocykl zderzył się z samochodem. Nie żyje jedna osoba
 - [https://tvn24.pl/lodz/milosna-motocykl-zderzyl-sie-z-samochodem-nie-zyje-jedna-osoba-st8030021?source=rss](https://tvn24.pl/lodz/milosna-motocykl-zderzyl-sie-z-samochodem-nie-zyje-jedna-osoba-st8030021?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T07:41:05+00:00

<img alt="Motocykl zderzył się z samochodem. Nie żyje jedna osoba" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2696691-wypadek-w-milosnej-nie-zyje-motocyklista-ph8030014/alternates/LANDSCAPE_1280" />
    Po zderzeniu z samochodem osobowym na drodze krajowej numer 91 w Miłosnej (województwo łódzkie) zginął motocyklista.

## Zamiast pieniędzy mają dostać bony. Rząd złamał umowę
 - [https://tvn24.pl/biznes/ze-swiata/zimbabwe-rzad-nie-wyplacil-pieniedzy-bialym-rolnikom-za-wywlaszczenie-st8030053?source=rss](https://tvn24.pl/biznes/ze-swiata/zimbabwe-rzad-nie-wyplacil-pieniedzy-bialym-rolnikom-za-wywlaszczenie-st8030053?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T07:38:53+00:00

<img alt="Zamiast pieniędzy mają dostać bony. Rząd złamał umowę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xw98au-zimbabwe-ph7968910/alternates/LANDSCAPE_1280" />
    Rząd Zimbabwe złamał zawartą w 2020 roku z wywłaszczonymi białymi farmerami umowę o rekompensatę. Zamiast obiecanych pieniędzy zaproponował bony skarbowe. W sobotę farmerzy odrzucili tę ofertę.

## Nie żyje uczestnik Biegu św. Dominika
 - [https://tvn24.pl/trojmiasto/gdansk-nie-zyje-uczestnik-biegu-sw-dominika-st8029955?source=rss](https://tvn24.pl/trojmiasto/gdansk-nie-zyje-uczestnik-biegu-sw-dominika-st8029955?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T07:38:30+00:00

<img alt="Nie żyje uczestnik Biegu św. Dominika  " src="https://tvn24.pl/trojmiasto/cdn-zdjecie-750061-bieg-sw-dominika-w-gdansku-ph8030046/alternates/LANDSCAPE_1280" />
    Podczas sobotniego Biegu św. Dominika, będącego od lat nieodłączną częścią Jarmarku św. Dominika zmarł jeden z jego uczestników. Mężczyzna miał 71 lat.

## "Robicie różnicę". Pracownicy giganta dostaną wyjątkową nagrodę
 - [https://tvn24.pl/biznes/najnowsze/rolls-royce-przekaze-kazdemu-pracownikowi-150-akcji-st8029554?source=rss](https://tvn24.pl/biznes/najnowsze/rolls-royce-przekaze-kazdemu-pracownikowi-150-akcji-st8029554?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T07:35:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1193390-shutterstock1089511877-ph8029506/alternates/LANDSCAPE_1280" />
    Rolls-Royce ogłosił niedawno, że odnotował zyski w wysokości 1,1 miliarda funtów w pierwszej połowie tego roku, czyli prawie dwukrotnie więcej niż w tym samym okresie w 2023 roku. Firma postanowiła podzielić się zyskiem z pracownikami. Każdy z 42 tysięcy zatrudnionych na całym świecie otrzyma 150 akcji wartych obecnie około 700 funtów, czyli równowartość 3,5 tysiąca złotych.

## Wypadek w Legionowie, motocyklista w szpitalu
 - [https://tvn24.pl/tvnwarszawa/ulice/wypadek-w-legionowie-motocyklista-w-szpitalu-st8030022?source=rss](https://tvn24.pl/tvnwarszawa/ulice/wypadek-w-legionowie-motocyklista-w-szpitalu-st8030022?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T07:27:30+00:00

<img alt="Wypadek w Legionowie, motocyklista w szpitalu " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4412688-wypadek-w-legionowie-ph8030027/alternates/LANDSCAPE_1280" />
    Motocyklista został przetransportowany do szpitala po wypadku w Legionowie. Jednoślad, który prowadził, zderzył się z autem osobowym.

## Cysterna zderzyła się z autem osobowym, zaczęła płonąć
 - [https://tvn24.pl/tvnwarszawa/ulice/joniec-plochocin-cysterna-zderzyla-sie-z-autem-osobowym-zaczela-plonac-st8029992?source=rss](https://tvn24.pl/tvnwarszawa/ulice/joniec-plochocin-cysterna-zderzyla-sie-z-autem-osobowym-zaczela-plonac-st8029992?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T07:22:11+00:00

<img alt="Cysterna zderzyła się z autem osobowym, zaczęła płonąć " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5708290-droga-byla-zablokowana-ph8029990/alternates/LANDSCAPE_1280" />
    Jedna osoba ucierpiała w wypadku pod Płońskiem. Doszło tam do zderzenia cysterny i auta osobowego. Samochód ciężarowy stanął w płomieniach, na miejscu pracowało kilkanaście zastępów straży. Trasa przez wiele godzin była zablokowana.

## Ulubione wakacyjne kierunki Polaków. Nowy raport
 - [https://tvn24.pl/biznes/pieniadze/ulubione-wakacyjne-kierunki-polakow-nowy-raport-st8030035?source=rss](https://tvn24.pl/biznes/pieniadze/ulubione-wakacyjne-kierunki-polakow-nowy-raport-st8030035?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T07:08:25+00:00

<img alt="Ulubione wakacyjne kierunki Polaków. Nowy raport" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7012913-plaza-grecja-rodos-tsampika-shutterstock2393935475-ph8008561/alternates/LANDSCAPE_1280" />
    W pierwszej połowie tegorocznych wakacji największą popularnością cieszyły się Turcja, Grecja i Egipt - wynika z raportu Wakacje.pl. Firma szacuje, że w tym roku oferta biur podróży na okres wakacyjny jest o 23-24 procent większa niż rok wcześniej.

## Szykują się utrudnienia dla tysięcy urlopowiczów. Jest zapowiedź strajku
 - [https://tvn24.pl/biznes/ze-swiata/portugalia-pracownicy-linii-lotniczej-easyjet-zapowiedzieli-trzydniowy-strajk-w-sierpniu-st8030002?source=rss](https://tvn24.pl/biznes/ze-swiata/portugalia-pracownicy-linii-lotniczej-easyjet-zapowiedzieli-trzydniowy-strajk-w-sierpniu-st8030002?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T06:59:10+00:00

<img alt="Szykują się utrudnienia dla tysięcy urlopowiczów. Jest zapowiedź strajku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9153847-shutterstock707532757-ph7789466/alternates/LANDSCAPE_1280" />
    Personel pokładowy linii Easyjet w Portugalii zapowiedział trzydniowy strajk, który może skomplikować urlop tysiącom osób planujących wypoczynek w tym kraju w połowie sierpnia.

## Spadł deszcz, w jezdni powstała dziura głęboka na dwa metry
 - [https://tvn24.pl/tvnmeteo/swiat/meksyk-spadl-deszcz-w-jezdni-powstala-dziura-gleboka-na-dwa-metry-st8029981?source=rss](https://tvn24.pl/tvnmeteo/swiat/meksyk-spadl-deszcz-w-jezdni-powstala-dziura-gleboka-na-dwa-metry-st8029981?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T06:58:25+00:00

<img alt="Spadł deszcz, w jezdni powstała dziura głęboka na dwa metry" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6938140-zapadlisko-w-meksykanskiej-morelii-ph8030006/alternates/LANDSCAPE_1280" />
    Ulewy spowodowały zapadnięcie się drogi w Meksyku. Dziura w ziemi była głęboka na dwa metry. Jak podały lokalne media, gwałtowne opady rozerwały biegnącą pod jezdnią kanalizację burzową, powodując zapadlisko.

## "Big Brother", "Masterchef" i "Magia Nagości" na żywo. Dojeżdżali na nie elektrycznymi pojazdami
 - [https://tvn24.pl/premium/big-brother-masterchef-i-magia-nagosci-na-zywo-dojezdzali-na-nie-elektrycznymi-pojazdami-st7906859?source=rss](https://tvn24.pl/premium/big-brother-masterchef-i-magia-nagosci-na-zywo-dojezdzali-na-nie-elektrycznymi-pojazdami-st7906859?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T06:55:52+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6184623-jedno-z-konkursowych-dan-popisowych-ph7911969/alternates/LANDSCAPE_1280" />
    Poznań 1929 był stolicą nowoczesności, przemysłu, sztuki i rozrywki. Wszystko "made in Poland". Latem przyjeżdżały tu nawet pary w podróży poślubnej, a górale utyskiwali, że stolica Wielkopolski zabrała turystów Zakopanemu.

## Wyniki Lotto z 3 sierpnia 2024. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-3-sierpnia-2024-jakie-liczby-padly-podczas-ostatniego-losowania-st8029983?source=rss](https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-3-sierpnia-2024-jakie-liczby-padly-podczas-ostatniego-losowania-st8029983?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T06:51:40+00:00

<img alt="Wyniki Lotto z 3 sierpnia 2024. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lojhor-lotto-s-shutterstock_275295956-5128640/alternates/LANDSCAPE_1280" />
    W sobotnim losowaniu Lotto nie padła główna wygrana. Kumulacja rośnie do trzech milionów złotych. Oto wyniki losowania Lotto oraz Lotto Plus z 3 sierpnia 2024 roku.

## Zakończył się festiwal Dwa Brzegi. Rozmowa z Dorotą Stalińską i Dorotą Pomykałą
 - [https://tvn24.pl/kultura-i-styl/festiwal-dwa-brzegi-rozmowa-z-dorota-stalinska-i-dorota-pomykala-laureatkami-za-role-w-filmie-moje-stare-st8029956?source=rss](https://tvn24.pl/kultura-i-styl/festiwal-dwa-brzegi-rozmowa-z-dorota-stalinska-i-dorota-pomykala-laureatkami-za-role-w-filmie-moje-stare-st8029956?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T06:22:05+00:00

<img alt="Zakończył się festiwal Dwa Brzegi. Rozmowa z Dorotą Stalińską i Dorotą Pomykałą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-579109-tvn24-clean2024080406412945272aac-kf8029959/alternates/LANDSCAPE_1280" />
    Zakończył się festiwal filmowy BNP Paribas Dwa Brzegi w Kazimierzu Dolnym. W trakcie wydarzenia odbyły się pokazy filmowe i spotkania z filmowymi twórcami. Z Laureatkami 18. edycji festiwalu nagrodzonymi za film "Moje stare" - aktorkami Dorotą Stalińską i Dorotą Pomykałą - rozmawiała Ewelina Witenberg.

## Alarmy przed burzami dla kolejnych regionów. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/prognoza/burze-w-niedziele-0408-imgw-ostrzega-st8029944?source=rss](https://tvn24.pl/tvnmeteo/prognoza/burze-w-niedziele-0408-imgw-ostrzega-st8029944?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T04:43:35+00:00

<img alt="Alarmy przed burzami dla kolejnych regionów. IMGW ostrzega" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5957638-pochmurno-chmury-burza-ph7989684/alternates/LANDSCAPE_1280" />
    IMGW rozszerzył zasięg ostrzeżeń meteorologicznych przed burzami o trzy województwa na południu kraju. Niebezpiecznie będzie od godzin porannych do późnej nocy. Sprawdź, gdzie aura zapowiada się groźnie.

## Fala zamieszek na Wyspach. Dziesiątki osób w areszcie
 - [https://tvn24.pl/swiat/wielka-brytania-kolejne-zamieszki-po-zabojstwie-w-southport-st8029922?source=rss](https://tvn24.pl/swiat/wielka-brytania-kolejne-zamieszki-po-zabojstwie-w-southport-st8029922?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-04T04:03:56+00:00

<img alt="Fala zamieszek na Wyspach. Dziesiątki osób w areszcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4832227-uczestnicy-demonstracji-w-manchesterze-ph8030295/alternates/LANDSCAPE_1280" />
    Brytyjska policja poinformowała w niedzielę, że w trakcie sobotnich zamieszek, które wybuchły w  różnych miastach kraju, aresztowano ponad 90 osób. Protestujący wyszli na ulice po zabiciu w Southport koło Liverpoolu trzech kilkuletnich dziewczynek. Premier Keir Starmer zapewnił, że policja ma pełne wsparcie rządu w podejmowaniu działań przeciw ekstremistom.

