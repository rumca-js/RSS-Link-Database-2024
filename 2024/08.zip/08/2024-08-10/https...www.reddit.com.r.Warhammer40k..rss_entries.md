# Source:/r/Warhammer40k - Unofficial Home of 40k on Reddit, URL:https://www.reddit.com/r/Warhammer40k/.rss, language:en

## I present to you: (the Rest of) My Gue'vesa Human Tau Army!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep48hr/i_present_to_you_the_rest_of_my_guevesa_human_tau](https://www.reddit.com/r/Warhammer40k/comments/1ep48hr/i_present_to_you_the_rest_of_my_guevesa_human_tau)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T21:45:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep48hr/i_present_to_you_the_rest_of_my_guevesa_human_tau/"> <img alt="I present to you: (the Rest of) My Gue'vesa Human Tau Army!" src="https://b.thumbs.redditmedia.com/oJntkGBzaMSx96IVQncEYxlr5mBsKdXEl-ebpFsHLAE.jpg" title="I present to you: (the Rest of) My Gue'vesa Human Tau Army!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Since my strike team did so well, i wanted to show off the rest too! (With good lighting) - Breacher Team - Stealth Teams - Ghostkeel (human pilot that isnt visible rn) - Pathfinder Team (not painted yet, obviously) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/the_rand0m_"> /u/the_rand0m_ </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep48hr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep48hr/i_present_to_you_the_rest_of_my_guevesa_human_tau/">[comments]</a></span> </td></tr></table>

## (WIP) Slaanesh Demon prince
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep3u7w/wip_slaanesh_demon_prince](https://www.reddit.com/r/Warhammer40k/comments/1ep3u7w/wip_slaanesh_demon_prince)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T21:27:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3u7w/wip_slaanesh_demon_prince/"> <img alt="(WIP) Slaanesh Demon prince " src="https://b.thumbs.redditmedia.com/pCq8Wa2qFeSfJbC-fnJRwx2ucA0bjb6h3YwWlAjRjgQ.jpg" title="(WIP) Slaanesh Demon prince " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Covid striked me while I was busy painting this big guy for days. There's still a lot to paint but I don't really feel like pushing it for now. Anyway let me know what you think of the mini or how to improve it; thanks :) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/pipinette"> /u/pipinette </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep3u7w">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3u7w/wip_slaanesh_demon_prince/">[comments]</a></span> </td></tr></table>

## What's you/your groups unique Warhammer quirk
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep3ppt/whats_youyour_groups_unique_warhammer_quirk](https://www.reddit.com/r/Warhammer40k/comments/1ep3ppt/whats_youyour_groups_unique_warhammer_quirk)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T21:21:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3ppt/whats_youyour_groups_unique_warhammer_quirk/"> <img alt="What's you/your groups unique Warhammer quirk " src="https://preview.redd.it/osnrq7yolwhd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=d1b2b0ffcdf8fa8bb26ee0d30eb9fc96213c354a" title="What's you/your groups unique Warhammer quirk " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Mine is building, priming then basing my models before painting. Makes the painting stage a little harder but I think its a lot way then a big grey pile and when you line them up in the cabinet with finished models they look like selections in a game that aren't unlocked yet.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GlintNestSteve"> /u/GlintNestSteve </a> <br /> <span><a href="https://i.redd.it/osnrq7yolwhd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3ppt/whats_youyour_g

## Green is best!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep3gy4/green_is_best](https://www.reddit.com/r/Warhammer40k/comments/1ep3gy4/green_is_best)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T21:10:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3gy4/green_is_best/"> <img alt="Green is best!" src="https://preview.redd.it/nn6ine5ljwhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7fc417410ef47c0401df7fcef015738e95fb5b02" title="Green is best!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HipHopDaRobot"> /u/HipHopDaRobot </a> <br /> <span><a href="https://i.redd.it/nn6ine5ljwhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3gy4/green_is_best/">[comments]</a></span> </td></tr></table>

## Grimdark Primaris Reiver #1
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep3fof/grimdark_primaris_reiver_1](https://www.reddit.com/r/Warhammer40k/comments/1ep3fof/grimdark_primaris_reiver_1)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T21:08:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3fof/grimdark_primaris_reiver_1/"> <img alt="Grimdark Primaris Reiver #1" src="https://b.thumbs.redditmedia.com/HIG4g03ZADb3jl3VDBOjq_mQptGnPhGa90-xbv5Wo6M.jpg" title="Grimdark Primaris Reiver #1" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I love painting grimy, battle-worn space marines. I know the bolt pistol is a lil boring but I like the minimal, scratchy/stipple weaponry style</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/hanprobably"> /u/hanprobably </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep3fof">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep3fof/grimdark_primaris_reiver_1/">[comments]</a></span> </td></tr></table>

## Look what my fiance grabbed me from our Warhammer store!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep38on/look_what_my_fiance_grabbed_me_from_our_warhammer](https://www.reddit.com/r/Warhammer40k/comments/1ep38on/look_what_my_fiance_grabbed_me_from_our_warhammer)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T20:59:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep38on/look_what_my_fiance_grabbed_me_from_our_warhammer/"> <img alt="Look what my fiance grabbed me from our Warhammer store!" src="https://b.thumbs.redditmedia.com/B_YDr-uon1nBUuWGX3nlipLccgf99Lqy2c7qy-7LxRY.jpg" title="Look what my fiance grabbed me from our Warhammer store!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SadCanOfPringles"> /u/SadCanOfPringles </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep38on">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep38on/look_what_my_fiance_grabbed_me_from_our_warhammer/">[comments]</a></span> </td></tr></table>

## My Fiance painted 2 wardogs for my birthday! She wanted to go for a "Folk Horror" vibe, and I think she killed it, especially for not having much experience painting prior!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep36q4/my_fiance_painted_2_wardogs_for_my_birthday_she](https://www.reddit.com/r/Warhammer40k/comments/1ep36q4/my_fiance_painted_2_wardogs_for_my_birthday_she)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T20:57:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep36q4/my_fiance_painted_2_wardogs_for_my_birthday_she/"> <img alt="My Fiance painted 2 wardogs for my birthday! She wanted to go for a &quot;Folk Horror&quot; vibe, and I think she killed it, especially for not having much experience painting prior!" src="https://b.thumbs.redditmedia.com/wpTzS_brC24oUrIySHQFQZiOOMt4vGJUOUs4gJGHQYg.jpg" title="My Fiance painted 2 wardogs for my birthday! She wanted to go for a &quot;Folk Horror&quot; vibe, and I think she killed it, especially for not having much experience painting prior!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bblock222"> /u/Bblock222 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep36q4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep36q4/my_fiance_painted_2_wardogs_for_my_birthday_she/">[comments]</a></span> </td></tr></table>

## When GW takes your stubber, make a heavy sniper
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep32sn/when_gw_takes_your_stubber_make_a_heavy_sniper](https://www.reddit.com/r/Warhammer40k/comments/1ep32sn/when_gw_takes_your_stubber_make_a_heavy_sniper)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T20:52:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep32sn/when_gw_takes_your_stubber_make_a_heavy_sniper/"> <img alt="When GW takes your stubber, make a heavy sniper" src="https://preview.redd.it/8i8bqy9ggwhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fbfd17df8636bb2f2a17cb10eeba5c95bd47a065" title="When GW takes your stubber, make a heavy sniper" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Since Kasrkin can bring a Hot-shot Marksman Rifle, I figured this was a good way to use a Grenadier model that otherwise would see no love in modern 40k</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Neknoh"> /u/Neknoh </a> <br /> <span><a href="https://i.redd.it/8i8bqy9ggwhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep32sn/when_gw_takes_your_stubber_make_a_heavy_sniper/">[comments]</a></span> </td></tr></table>

## New foam Orkyness
 - [https://www.reddit.com/r/Warhammer40k/comments/1ep0rmo/new_foam_orkyness](https://www.reddit.com/r/Warhammer40k/comments/1ep0rmo/new_foam_orkyness)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T19:06:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ep0rmo/new_foam_orkyness/"> <img alt="New foam Orkyness" src="https://b.thumbs.redditmedia.com/L8Cb4qu54ZqaV5DK83LntBCJyXSSomNz45tCb5DyK4U.jpg" title="New foam Orkyness" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>New mostly foam 40K Ork Chain Axe build. Power spikes on top, grabby rippy skull at front, main Waaaargh skull chain axe under, rear saw on the hilt. Roughly life size. Hope you like!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bazcardz"> /u/Bazcardz </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep0rmo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ep0rmo/new_foam_orkyness/">[comments]</a></span> </td></tr></table>

## Red scorpion eradicator squad
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoy86s/red_scorpion_eradicator_squad](https://www.reddit.com/r/Warhammer40k/comments/1eoy86s/red_scorpion_eradicator_squad)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T17:15:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoy86s/red_scorpion_eradicator_squad/"> <img alt="Red scorpion eradicator squad" src="https://preview.redd.it/11iog3urdvhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=56fb1ee0891c69bc33a41c0f1e4fd607e088c535" title="Red scorpion eradicator squad" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>My latest squad done, tried some new things with oils , what do you guys think of it?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Najdadinn"> /u/Najdadinn </a> <br /> <span><a href="https://i.redd.it/11iog3urdvhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoy86s/red_scorpion_eradicator_squad/">[comments]</a></span> </td></tr></table>

## Currently building the Gladiator, why are there so many open seams?
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoxprf/currently_building_the_gladiator_why_are_there_so](https://www.reddit.com/r/Warhammer40k/comments/1eoxprf/currently_building_the_gladiator_why_are_there_so)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T16:54:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoxprf/currently_building_the_gladiator_why_are_there_so/"> <img alt="Currently building the Gladiator, why are there so many open seams?" src="https://b.thumbs.redditmedia.com/qX5MlKaHI_EpiJ-uLlHI5wbqfH-I6rf_gjOjG1ICc0g.jpg" title="Currently building the Gladiator, why are there so many open seams?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>What am I doing wrong? The pieces don’t quite fit together perfectly</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/chumbuckethand"> /u/chumbuckethand </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoxprf">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoxprf/currently_building_the_gladiator_why_are_there_so/">[comments]</a></span> </td></tr></table>

## The triumph is finished!
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoxi33/the_triumph_is_finished](https://www.reddit.com/r/Warhammer40k/comments/1eoxi33/the_triumph_is_finished)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T16:45:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoxi33/the_triumph_is_finished/"> <img alt="The triumph is finished!" src="https://b.thumbs.redditmedia.com/HjkxLCkypdKA7yVoh3FQMhGxx7QUgZXq_eT3bz-FadM.jpg" title="The triumph is finished!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IsThisUsernameFree"> /u/IsThisUsernameFree </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoxi33">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoxi33/the_triumph_is_finished/">[comments]</a></span> </td></tr></table>

## A lonely Adeptus Arbites I just finished
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoxdx7/a_lonely_adeptus_arbites_i_just_finished](https://www.reddit.com/r/Warhammer40k/comments/1eoxdx7/a_lonely_adeptus_arbites_i_just_finished)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T16:40:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoxdx7/a_lonely_adeptus_arbites_i_just_finished/"> <img alt="A lonely Adeptus Arbites I just finished" src="https://preview.redd.it/r1on907h7vhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c4162c8da64173e97e6e0ddd79c8b441b8271ede" title="A lonely Adeptus Arbites I just finished" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MobileAlfalfa"> /u/MobileAlfalfa </a> <br /> <span><a href="https://i.redd.it/r1on907h7vhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoxdx7/a_lonely_adeptus_arbites_i_just_finished/">[comments]</a></span> </td></tr></table>

## Surprise drop troop tease during AOS Skaven preview
 - [https://www.reddit.com/r/Warhammer40k/comments/1eox3j5/surprise_drop_troop_tease_during_aos_skaven](https://www.reddit.com/r/Warhammer40k/comments/1eox3j5/surprise_drop_troop_tease_during_aos_skaven)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T16:27:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eox3j5/surprise_drop_troop_tease_during_aos_skaven/"> <img alt="Surprise drop troop tease during AOS Skaven preview" src="https://a.thumbs.redditmedia.com/ohgtBSgHhMhwHXdCbSj9rguCZtJPeitJjF7WuZJBqH4.jpg" title="Surprise drop troop tease during AOS Skaven preview" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheScurrilousScribe"> /u/TheScurrilousScribe </a> <br /> <span><a href="https://www.reddit.com/gallery/1eox3j5">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eox3j5/surprise_drop_troop_tease_during_aos_skaven/">[comments]</a></span> </td></tr></table>

## My custom Night Lords Daemon Prince brought to life
 - [https://www.reddit.com/r/Warhammer40k/comments/1eow9bj/my_custom_night_lords_daemon_prince_brought_to](https://www.reddit.com/r/Warhammer40k/comments/1eow9bj/my_custom_night_lords_daemon_prince_brought_to)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T15:51:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eow9bj/my_custom_night_lords_daemon_prince_brought_to/"> <img alt="My custom Night Lords Daemon Prince brought to life" src="https://a.thumbs.redditmedia.com/O9CnG2VorRgXGupSXOABv0UdpQmfDfgZZx27kHnElg4.jpg" title="My custom Night Lords Daemon Prince brought to life" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Model by @Joshpmcd on instagram, Art by <a href="https://grohgrog.artstation.com/">https://grohgrog.artstation.com/</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ProphetVIII"> /u/ProphetVIII </a> <br /> <span><a href="https://www.reddit.com/gallery/1eow9bj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eow9bj/my_custom_night_lords_daemon_prince_brought_to/">[comments]</a></span> </td></tr></table>

## I made a chaos undivided war banner.
 - [https://www.reddit.com/r/Warhammer40k/comments/1eovu4k/i_made_a_chaos_undivided_war_banner](https://www.reddit.com/r/Warhammer40k/comments/1eovu4k/i_made_a_chaos_undivided_war_banner)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T15:33:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eovu4k/i_made_a_chaos_undivided_war_banner/"> <img alt="I made a chaos undivided war banner. " src="https://b.thumbs.redditmedia.com/nIWyjIM5caQqTF7cVthy0gPRr1cVpQOUyyhemOk1ahQ.jpg" title="I made a chaos undivided war banner. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sbercot"> /u/sbercot </a> <br /> <span><a href="https://www.reddit.com/gallery/1eovu4k">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eovu4k/i_made_a_chaos_undivided_war_banner/">[comments]</a></span> </td></tr></table>

## Repulsor Done ❌⚜️❌
 - [https://www.reddit.com/r/Warhammer40k/comments/1eovt2k/repulsor_done](https://www.reddit.com/r/Warhammer40k/comments/1eovt2k/repulsor_done)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T15:32:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eovt2k/repulsor_done/"> <img alt="Repulsor Done ❌⚜️❌" src="https://a.thumbs.redditmedia.com/fPc2jPUV7Kbzf29ZayVrCIXV1cb-3_aG12SuJE1v2r4.jpg" title="Repulsor Done ❌⚜️❌" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>❌⚜️❌ Impulsor done ! ❌⚜️❌</p> <p>First battletest i'll bring the good old Bladeguards + Judicar, but as a lot of you wisely adviced i'll try Incursors for scout, grenade/shoot/haywire mine, and lieutenant + Hellblasters !</p> <p>See you soon for the big reclusiam kitbash Project 😁</p> <p>Instagram @captaingastustudio <a href="https://www.instagram.com/captaingatsustudio?igsh=YjIwajdrbzNibHpw">https://www.instagram.com/captaingatsustudio?igsh=YjIwajdrbzNibHpw</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Demonic_Tutor_22"> /u/Demonic_Tutor_22 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eovt2k">[link]</a></span> &#32; <span><a href="https:

## Biggest commission yet!
 - [https://www.reddit.com/r/Warhammer40k/comments/1eouxkc/biggest_commission_yet](https://www.reddit.com/r/Warhammer40k/comments/1eouxkc/biggest_commission_yet)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T14:54:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eouxkc/biggest_commission_yet/"> <img alt="Biggest commission yet!" src="https://preview.redd.it/oug6tulmouhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ecaacf7a2283cf2ba93793d062c4d9a3e1197ce9" title="Biggest commission yet!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This is about 6 different photos composited together of incredible minis from <a href="/u/AGderp">/u/AGderp</a> who was a true pleasure to work with! First time I got to do a paintover on armorcast models so that was a thrill. I owned an armorcast warhound when they first came out but don’t see them around much! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ArtistsEmpire"> /u/ArtistsEmpire </a> <br /> <span><a href="https://i.redd.it/oug6tulmouhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eouxkc/biggest_commission_yet/">[comments]</a></spa

## Leviathan Dreadnought (proxy as Brutalis in game)
 - [https://www.reddit.com/r/Warhammer40k/comments/1eouudz/leviathan_dreadnought_proxy_as_brutalis_in_game](https://www.reddit.com/r/Warhammer40k/comments/1eouudz/leviathan_dreadnought_proxy_as_brutalis_in_game)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T14:50:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eouudz/leviathan_dreadnought_proxy_as_brutalis_in_game/"> <img alt="Leviathan Dreadnought (proxy as Brutalis in game)" src="https://preview.redd.it/912d1mtxnuhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3a3d6b0774d01eea456e9fc62dda2295f1526fde" title="Leviathan Dreadnought (proxy as Brutalis in game)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Got him a 90 mm base and multi meltas (gonna track down a heavy stubber in time). C&amp;c is always welcome! :-) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/fpsh0oter"> /u/fpsh0oter </a> <br /> <span><a href="https://i.redd.it/912d1mtxnuhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eouudz/leviathan_dreadnought_proxy_as_brutalis_in_game/">[comments]</a></span> </td></tr></table>

## My first space marine
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoun5l/my_first_space_marine](https://www.reddit.com/r/Warhammer40k/comments/1eoun5l/my_first_space_marine)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T14:41:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoun5l/my_first_space_marine/"> <img alt="My first space marine" src="https://preview.redd.it/2g36qirbmuhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d8491a445799aefaad9230da70e39d0916c8bea0" title="My first space marine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plumb-phone-official"> /u/plumb-phone-official </a> <br /> <span><a href="https://i.redd.it/2g36qirbmuhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoun5l/my_first_space_marine/">[comments]</a></span> </td></tr></table>

## Finished the first tank for my Swamperial Guard army
 - [https://www.reddit.com/r/Warhammer40k/comments/1eorwqr/finished_the_first_tank_for_my_swamperial_guard](https://www.reddit.com/r/Warhammer40k/comments/1eorwqr/finished_the_first_tank_for_my_swamperial_guard)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T12:31:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eorwqr/finished_the_first_tank_for_my_swamperial_guard/"> <img alt="Finished the first tank for my Swamperial Guard army" src="https://a.thumbs.redditmedia.com/_FdZ9QAm1zH8RbNrteszHkFwc4w8zt2Yp3Z1jm86XZ0.jpg" title="Finished the first tank for my Swamperial Guard army" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SwampRatMiniatures"> /u/SwampRatMiniatures </a> <br /> <span><a href="https://www.reddit.com/gallery/1eorwqr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eorwqr/finished_the_first_tank_for_my_swamperial_guard/">[comments]</a></span> </td></tr></table>

## Rookie ruins question
 - [https://www.reddit.com/r/Warhammer40k/comments/1eora1n/rookie_ruins_question](https://www.reddit.com/r/Warhammer40k/comments/1eora1n/rookie_ruins_question)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T11:57:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eora1n/rookie_ruins_question/"> <img alt="Rookie ruins question " src="https://preview.redd.it/ooby26y1tthd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f60825962add95a7aa1d9efd0dd44cf656432065" title="Rookie ruins question " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>So I made some ruins but not exactly sure how the work. So I’m wondering in this case can we shoot without worrying about line of sight or is there an imaginary wall between them because of the footprint? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ok_Recording_3455"> /u/Ok_Recording_3455 </a> <br /> <span><a href="https://i.redd.it/ooby26y1tthd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eora1n/rookie_ruins_question/">[comments]</a></span> </td></tr></table>

## Kitbashes possible?
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoqr8f/kitbashes_possible](https://www.reddit.com/r/Warhammer40k/comments/1eoqr8f/kitbashes_possible)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T11:26:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoqr8f/kitbashes_possible/"> <img alt="Kitbashes possible?" src="https://preview.redd.it/ri9q2lihnthd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3d2c85c2224d6751848dde742439988ea9cf269d" title="Kitbashes possible?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'd buy the Kit anyway but i wanna know if there would be any heads or helmets over when everything is build, also with how many and what weapons does the kit come? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yyounggoose"> /u/yyounggoose </a> <br /> <span><a href="https://i.redd.it/ri9q2lihnthd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoqr8f/kitbashes_possible/">[comments]</a></span> </td></tr></table>

## Sun, terrain and beerhammer
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoqnb2/sun_terrain_and_beerhammer](https://www.reddit.com/r/Warhammer40k/comments/1eoqnb2/sun_terrain_and_beerhammer)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T11:19:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoqnb2/sun_terrain_and_beerhammer/"> <img alt="Sun, terrain and beerhammer" src="https://b.thumbs.redditmedia.com/J_dcJWBH7A0k3k6UKOWOW7lyvq6G8fpy3-FM3be4GMQ.jpg" title="Sun, terrain and beerhammer" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Finished my table in time for my friends to join a relaxed game of 1500pt beerhammer. Daemons vs Guard. Especially proud of the church as a centre piece.</p> <p>Got myself a little secondary map as well! Via 2 sewer holes on opposite sides of the primary map, you’ll go to the sewer map where there’s one objective to claim as well.</p> <p>Daemon is fully proxied and in a magnificent colourful avian theme with base colours on the greater daemons helping to identify who is who. Guard is a mechanised Vostroyan army with only Solar proxied. Too bad there isn’t an official model for that unit. </p> <p>We bent some rules for a good ol’ slaughterhouse matchup. (But of cours

## War don't ennoble men.
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoqb6j/war_dont_ennoble_men](https://www.reddit.com/r/Warhammer40k/comments/1eoqb6j/war_dont_ennoble_men)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T10:59:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoqb6j/war_dont_ennoble_men/"> <img alt="War don't ennoble men." src="https://b.thumbs.redditmedia.com/739EkeSB2q0-iyI-LzTwphtLmew3cYxVgrWlKb10RCk.jpg" title="War don't ennoble men." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Brunstan"> /u/Brunstan </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoqb6j">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoqb6j/war_dont_ennoble_men/">[comments]</a></span> </td></tr></table>

## A lovely smile.
 - [https://www.reddit.com/r/Warhammer40k/comments/1eopjx0/a_lovely_smile](https://www.reddit.com/r/Warhammer40k/comments/1eopjx0/a_lovely_smile)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T10:09:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eopjx0/a_lovely_smile/"> <img alt="A lovely smile." src="https://b.thumbs.redditmedia.com/dMpVLMFEf2LPCDyRkzWRfABbXaylOcivStDv7bcVBQs.jpg" title="A lovely smile." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bara_painting"> /u/bara_painting </a> <br /> <span><a href="https://www.reddit.com/gallery/1eopjx0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eopjx0/a_lovely_smile/">[comments]</a></span> </td></tr></table>

## Speed ​​Freaks is now available to play for free. How are your first impressions?
 - [https://www.reddit.com/r/Warhammer40k/comments/1eop4yn/speed_freaks_is_now_available_to_play_for_free](https://www.reddit.com/r/Warhammer40k/comments/1eop4yn/speed_freaks_is_now_available_to_play_for_free)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T09:40:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eop4yn/speed_freaks_is_now_available_to_play_for_free/"> <img alt="Speed ​​Freaks is now available to play for free. How are your first impressions?" src="https://preview.redd.it/9unz68hn4thd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b70f8a0b2f49e56db9af93bd8b5282b25f856676" title="Speed ​​Freaks is now available to play for free. How are your first impressions?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PanKotex"> /u/PanKotex </a> <br /> <span><a href="https://i.redd.it/9unz68hn4thd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eop4yn/speed_freaks_is_now_available_to_play_for_free/">[comments]</a></span> </td></tr></table>

## What do these battle honors mean on the imperial knight transfer sheet?
 - [https://www.reddit.com/r/Warhammer40k/comments/1eoocw0/what_do_these_battle_honors_mean_on_the_imperial](https://www.reddit.com/r/Warhammer40k/comments/1eoocw0/what_do_these_battle_honors_mean_on_the_imperial)
 - RSS feed: https://www.reddit.com/r/Warhammer40k/.rss
 - date published: 2024-08-10T08:45:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1eoocw0/what_do_these_battle_honors_mean_on_the_imperial/"> <img alt="What do these battle honors mean on the imperial knight transfer sheet? " src="https://preview.redd.it/1lvtwibuushd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a0bd5650ec11d2b0c4950685d0d126f3ff6f9820" title="What do these battle honors mean on the imperial knight transfer sheet? " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LinkinPorkchops"> /u/LinkinPorkchops </a> <br /> <span><a href="https://i.redd.it/1lvtwibuushd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1eoocw0/what_do_these_battle_honors_mean_on_the_imperial/">[comments]</a></span> </td></tr></table>

