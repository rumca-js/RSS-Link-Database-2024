# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Global excess deaths
 - [https://www.youtube.com/watch?v=yi5Ii9TARis](https://www.youtube.com/watch?v=yi5Ii9TARis)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-08-10T08:22:59+00:00

Spatiotemporal variation of excess all-cause mortality, in the world (125 countries), during the Covid period 2020-2023,

regarding socio economic factors,

and public-health and medical interventions

https://correlation-canada.org/covid-excess-mortality-125-countries/

https://www.worldtribune.com/researchers-study-of-125-countries-finds-no-evidence-covid-vaccines-provided-any-benefit/

