# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## ZUS masowo kontroluje Polaków. Sprawdza, jak wykorzystywane jest L4
 - [https://wydarzenia.interia.pl/kraj/news-zus-masowo-kontroluje-polakow-sprawdza-jak-wykorzystywane-je,nId,7751709](https://wydarzenia.interia.pl/kraj/news-zus-masowo-kontroluje-polakow-sprawdza-jak-wykorzystywane-je,nId,7751709)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T14:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zus-masowo-kontroluje-polakow-sprawdza-jak-wykorzystywane-je,nId,7751709"><img align="left" alt="ZUS masowo kontroluje Polaków. Sprawdza, jak wykorzystywane jest L4" src="https://i.iplsc.com/zus-masowo-kontroluje-polakow-sprawdza-jak-wykorzystywane-je/000J5HJ7WHNUAWR3-C321.jpg" /></a>W ostatnim półroczu wzrosła liczba kontroli osób przebywających na L4. Wynika to z faktu, że ZUS sięgnął po nową metodę, która zdecydowanie przyspieszyła prace w tym kierunku. Polacy mają do oddania Zakładowi Ubezpieczeń Społecznych miliony złotych w związku z próbami wyłudzenia zasiłku chorobowego. Czego nie wolno robić na L4 i jaką karą może się skończyć złamanie zakazów lekarskich?  </p><br clear="all" />

## Politycy gratulują siatkarzom. "Część wróci z prezydentem do kraju"
 - [https://wydarzenia.interia.pl/kraj/news-politycy-gratuluja-siatkarzom-czesc-wroci-z-prezydentem-do-k,nId,7755068](https://wydarzenia.interia.pl/kraj/news-politycy-gratuluja-siatkarzom-czesc-wroci-z-prezydentem-do-k,nId,7755068)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T13:35:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-politycy-gratuluja-siatkarzom-czesc-wroci-z-prezydentem-do-k,nId,7755068"><img align="left" alt="Politycy gratulują siatkarzom. &quot;Część wróci z prezydentem do kraju&quot;" src="https://i.iplsc.com/politycy-gratuluja-siatkarzom-czesc-wroci-z-prezydentem-do-k/000JLP6EXS8R8TEJ-C321.jpg" /></a>Część polskiej reprezentacji olimpijskiej powróci w sobotę razem z prezydentem do kraju - poinformowała Kancelaria Andrzeja Dudy. Politycy składają gratulacje polskim siatkarzom po meczu z Francją w finale Igrzysk Olimpijskich w Paryżu. - Daliście nam, Panowie, bardzo dużo radości, więc jakoś przebolejemy ten finał. Serdeczne dzięki! - napisał premier Donald Tusk. - Francji nie udało się pokonać, ale sukces ekipy Nikoli Grbicia i tak jest fenomenalny! - podkreślił z kolei były premier Mateusz Morawiecki. </p><br clear="all" />

## Rewolucyjna regulacja wchodzi w życie. Zmiany rozciągną się na dwa lata
 - [https://wydarzenia.interia.pl/kraj/news-rewolucyjna-regulacja-wchodzi-w-zycie-zmiany-rozciagna-sie-n,nId,7749214](https://wydarzenia.interia.pl/kraj/news-rewolucyjna-regulacja-wchodzi-w-zycie-zmiany-rozciagna-sie-n,nId,7749214)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T13:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rewolucyjna-regulacja-wchodzi-w-zycie-zmiany-rozciagna-sie-n,nId,7749214"><img align="left" alt="Rewolucyjna regulacja wchodzi w życie. Zmiany rozciągną się na dwa lata" src="https://i.iplsc.com/rewolucyjna-regulacja-wchodzi-w-zycie-zmiany-rozciagna-sie-n/000HD7XH8GIATDDP-C321.jpg" /></a>1 sierpnia 2024 roku Unia Europejska wprowadziła w życie AI Act, przełomowe rozporządzenie, które reguluje wykorzystanie sztucznej inteligencji. Nowe przepisy mają na celu zapewnienie, że rozwój AI będzie zgodny z europejskimi wartościami i nie zagrozi podstawowym prawom obywateli. Wszyscy odczujemy te zmiany. </p><br clear="all" />

## Jarosław Kaczyński zapowiada zmianę Konstytucji. "Konieczne"
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zapowiada-zmiane-konstytucji-konieczne,nId,7754983](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zapowiada-zmiane-konstytucji-konieczne,nId,7754983)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T12:27:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-zapowiada-zmiane-konstytucji-konieczne,nId,7754983"><img align="left" alt="Jarosław Kaczyński zapowiada zmianę Konstytucji. &quot;Konieczne&quot;" src="https://i.iplsc.com/jaroslaw-kaczynski-zapowiada-zmiane-konstytucji-konieczne/000JLNVRA098D6TM-C321.jpg" /></a>Mamy do czynienia z upadkiem Konstytucji idącym tak daleko, że w przyszłości potrzebne będzie jej odnowienie - zaznaczył Jarosław Kaczyński. Prezes PiS oskarżył rządzących o chęć cofnięcia reform rządu Zjednoczonej Prawicy. Kaczyński podkreślił, że wprowadzane obecnie zmiany w systemie sądownictwa są &quot;przygotowywane do procesów politycznych przeciwko niewinnym ludziom&quot;.</p><br clear="all" />

## Czerwone flagi na kąpieliskach. Służby wykryły poważne zagrożenie
 - [https://wydarzenia.interia.pl/kraj/news-czerwone-flagi-na-kapieliskach-sluzby-wykryly-powazne-zagroz,nId,7755044](https://wydarzenia.interia.pl/kraj/news-czerwone-flagi-na-kapieliskach-sluzby-wykryly-powazne-zagroz,nId,7755044)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T12:11:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czerwone-flagi-na-kapieliskach-sluzby-wykryly-powazne-zagroz,nId,7755044"><img align="left" alt="Czerwone flagi na kąpieliskach. Służby wykryły poważne zagrożenie " src="https://i.iplsc.com/czerwone-flagi-na-kapieliskach-sluzby-wykryly-powazne-zagroz/000JLO8OF2213A8B-C321.jpg" /></a>Sinice oraz bakterie E.coli wykryto na dziesięciu kąpieliskach w północnej Polsce. Czerwone flagi, oznaczające zakaz kąpieli, wywieszono w Sianożętach, Ustroniu Morskim, Gryficach, Stepnicy, Czaplinku i Szczecinku. Ograniczenia dotykają wczasowiczów w środku sezonu wakacyjnego. </p><br clear="all" />

## Zwrot w sprawie Romanowskiego. Giertych zapowiada nowy wniosek
 - [https://wydarzenia.interia.pl/kraj/news-zwrot-w-sprawie-romanowskiego-giertych-zapowiada-nowy-wniose,nId,7754979](https://wydarzenia.interia.pl/kraj/news-zwrot-w-sprawie-romanowskiego-giertych-zapowiada-nowy-wniose,nId,7754979)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T11:23:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zwrot-w-sprawie-romanowskiego-giertych-zapowiada-nowy-wniose,nId,7754979"><img align="left" alt="Zwrot w sprawie Romanowskiego. Giertych zapowiada nowy wniosek" src="https://i.iplsc.com/zwrot-w-sprawie-romanowskiego-giertych-zapowiada-nowy-wniose/000JLNZRR47Q5FQH-C321.jpg" /></a>Sąd Okręgowy w poszerzonym składzie ma rozpatrzyć zażalenie na aresztowanie złożone przez Marcina Romanowskiego. Po porażce Prokuratury Krajowej ws. wyłączenia sędziego Przemysława Dziwańskiego, nowy wniosek zapowiada Roman Giertych. Według prawnika oraz posła KO przedstawiciel wymiaru sprawiedliwości miał dopuścić się deliktu.</p><br clear="all" />

## Poruszający wpis premiera. "Pilnuj nas tam z góry"
 - [https://wydarzenia.interia.pl/kraj/news-poruszajacy-wpis-premiera-pilnuj-nas-tam-z-gory,nId,7755024](https://wydarzenia.interia.pl/kraj/news-poruszajacy-wpis-premiera-pilnuj-nas-tam-z-gory,nId,7755024)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T11:01:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-poruszajacy-wpis-premiera-pilnuj-nas-tam-z-gory,nId,7755024"><img align="left" alt="Poruszający wpis premiera. &quot;Pilnuj nas tam z góry&quot;" src="https://i.iplsc.com/poruszajacy-wpis-premiera-pilnuj-nas-tam-z-gory/000JLO3WO3FU1M3I-C321.jpg" /></a>&quot;Dwa tygodnie temu napisałem do Kasi Mrzygłockiej, żeby wracała do roboty, bo wszyscy za nią tęsknimy. Odpowiedziała, że jest gotowa i niech się wszyscy boją&quot; - napisał w sieci Donald Tusk. Były premier pożegnał zmarłą w sobotni poranek posłankę Koalicji Obywatelskiej. Izabela Katarzyna Mrzygłocka miała 65 lat.</p><br clear="all" />

## Czy koalicja przetrwa próbę czasu? Nowy sondaż, wyborcy podzieleni
 - [https://wydarzenia.interia.pl/kraj/news-czy-koalicja-przetrwa-probe-czasu-nowy-sondaz-wyborcy-podzie,nId,7755004](https://wydarzenia.interia.pl/kraj/news-czy-koalicja-przetrwa-probe-czasu-nowy-sondaz-wyborcy-podzie,nId,7755004)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-08-10T10:40:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czy-koalicja-przetrwa-probe-czasu-nowy-sondaz-wyborcy-podzie,nId,7755004"><img align="left" alt="Czy koalicja przetrwa próbę czasu? Nowy sondaż, wyborcy podzieleni " src="https://i.iplsc.com/czy-koalicja-przetrwa-probe-czasu-nowy-sondaz-wyborcy-podzie/000HWRJUYUC70DU8-C321.jpg" /></a>54 proc. ankietowanych uważa, że mimo istniejących napięć obecna koalicja rządząca utrzyma się do końca kadencji - wynika z sondażu United Surveys. Na zakończenie współpracy liczą przede wszystkim sympatycy opozycyjnych partii parlamentarnych. Wśród rządzących emocje rozgrzewa m.in. podejście do sprawy aborcji.</p><br clear="all" />

