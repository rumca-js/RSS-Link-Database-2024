# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## Gold medallist Lebron James: 'I don't see myself at LA2028'
 - [https://www.channelnewsasia.com/sport/gold-medallist-lebron-james-i-dont-see-myself-la2028-4540186](https://www.channelnewsasia.com/sport/gold-medallist-lebron-james-i-dont-see-myself-la2028-4540186)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T23:17:31+00:00



## Jalolov thanks Britain's doctors for aiding Uzbek coach during cardiac arrest
 - [https://www.channelnewsasia.com/sport/jalolov-thanks-britains-doctors-aiding-uzbek-coach-during-cardiac-arrest-4540181](https://www.channelnewsasia.com/sport/jalolov-thanks-britains-doctors-aiding-uzbek-coach-during-cardiac-arrest-4540181)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T23:10:33+00:00



## GPS spoofers 'hack time' on commercial airlines, researchers say
 - [https://www.channelnewsasia.com/business/gps-spoofers-hack-time-commercial-airlines-researchers-say-4540151](https://www.channelnewsasia.com/business/gps-spoofers-hack-time-commercial-airlines-researchers-say-4540151)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:36:15+00:00



## Taiwan's Lin says she blocked out gender dispute en route to gold
 - [https://www.channelnewsasia.com/sport/taiwans-lin-says-she-blocked-out-gender-dispute-en-route-gold-4540121](https://www.channelnewsasia.com/sport/taiwans-lin-says-she-blocked-out-gender-dispute-en-route-gold-4540121)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:03:05+00:00



## Runners-up Brazil can leave Paris with heads high, says coach Elias
 - [https://www.channelnewsasia.com/sport/runners-brazil-can-leave-paris-heads-high-says-coach-elias-4540126](https://www.channelnewsasia.com/sport/runners-brazil-can-leave-paris-heads-high-says-coach-elias-4540126)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:00:15+00:00



## Commentary: It’s time to rethink the idea of working age
 - [https://www.channelnewsasia.com/commentary/retirement-age-policy-economy-ageing-workforce-labour-4519631](https://www.channelnewsasia.com/commentary/retirement-age-policy-economy-ageing-workforce-labour-4519631)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:00:00+00:00

"Working age" as a measure fails to take in the complexities of people’s lives, says a lecturer from the Queen’s University Belfast.

## Commentary: Japan’s AI stance is betraying its anime artists
 - [https://www.channelnewsasia.com/commentary/japan-anime-creative-industries-ai-copyright-4537441](https://www.channelnewsasia.com/commentary/japan-anime-creative-industries-ai-copyright-4537441)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:00:00+00:00

From Studio Ghibli to Pokemon, Japan’s creatives have driven its influence and must be protected, says Catherine Thorbecke for Bloomberg Opinion.

## Commentary: Treasure him, Singapore. In 17-year-old Max Maeder, you have a gem
 - [https://www.channelnewsasia.com/commentary/max-maeder-olympic-medal-bronze-kitefoiling-maturity-elite-mentality-4537721](https://www.channelnewsasia.com/commentary/max-maeder-olympic-medal-bronze-kitefoiling-maturity-elite-mentality-4537721)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:00:00+00:00

Kitefoiler Max Maeder is not only an Olympic medallist, but a teenager with an exceptional maturity and elite mentality, says CNA's Matthew Mohan, who covered all the action at the 2024 Paris Olympics.

## Gen Z Filipinos, the loneliest youths in Southeast Asia, are struggling. This is how and why
 - [https://www.channelnewsasia.com/cna-insider/gen-z-filipinos-loneliest-youths-southeast-asia-struggling-4534976](https://www.channelnewsasia.com/cna-insider/gen-z-filipinos-loneliest-youths-southeast-asia-struggling-4534976)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:00:00+00:00

The pandemic and heavy use of social media are just two of the contributing factors to the social isolation faced by the country’s youth. The programme Insight delves deeper and finds out what is being done to help them.

## Historic divorce bill in the Philippines brings hope to aggrieved spouses but meets religious, political opposition
 - [https://www.channelnewsasia.com/asia/divorce-bill-philippines-religious-political-pushback-4534856](https://www.channelnewsasia.com/asia/divorce-bill-philippines-religious-political-pushback-4534856)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:00:00+00:00

Currently the only country apart from the Vatican where divorce is illegal, the Philippines could allow couples to part ways with the passing of the Absolute Divorce Act. But a path to potential relief for those trapped in unhappy and abusive marriages has been met by pushback in the Catholic-majority country.

## Residential parcel collection points bring convenience, neighbourly camaraderie; but safety concerns emerge
 - [https://www.channelnewsasia.com/singapore/shopee-residential-collection-point-online-shopping-4532511](https://www.channelnewsasia.com/singapore/shopee-residential-collection-point-online-shopping-4532511)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T22:00:00+00:00

Online shoppers can opt to pick up their Shopee purchases at these collection points, to save on delivery fees.

## Trump campaign accuses Iran of hacking its emails
 - [https://www.channelnewsasia.com/world/trump-campaign-accuses-iran-hacking-its-emails-4540096](https://www.channelnewsasia.com/world/trump-campaign-accuses-iran-hacking-its-emails-4540096)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T21:57:45+00:00



## These 2 millennials started their truffle business in their bedrooms; now they supply to Singapore’s top restaurants
 - [https://www.channelnewsasia.com/people/woodland-truffles-founder-benedict-dorai-marcus-heng-4529761](https://www.channelnewsasia.com/people/woodland-truffles-founder-benedict-dorai-marcus-heng-4529761)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T21:56:00+00:00

Benedict Dorai and Marcus Heng had no F&amp; B experience when they started Woodland Truffles back in 2019.

## Uzbekistan's Jalolov wins men's super heavyweight gold at Paris Games
 - [https://www.channelnewsasia.com/sport/uzbekistans-jalolov-wins-mens-super-heavyweight-gold-paris-games-4540101](https://www.channelnewsasia.com/sport/uzbekistans-jalolov-wins-mens-super-heavyweight-gold-paris-games-4540101)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-08-10T21:48:01+00:00



