# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## HOUSE OF A THOUSAND FURRIES - Safe for Australia version
 - [https://www.youtube.com/watch?v=iBWBAg-0jC0](https://www.youtube.com/watch?v=iBWBAg-0jC0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2024-08-10T18:22:30+00:00

PRAISE BE TO SPACE KING ► https://youtu.be/lknNsZgzG1g?feature=shared

Special thanks to our Patron Producers!
Albert Hutchins
Javen Mcadam Villenueve
Brandon William Thomas

Created by ► 
Tom Hinchliffe & Don Greger

Written by ► 
Tom Hinchliffe & Russell Denney

Cast ► 
Space Marine: Mark Manning + Don
Space Marine council: Tom
Primary dog mutant: Liv Mether
Youngest dog mutant: Alice Murphy
Father dog mutant: Tom
Mother dog mutant: Amelia Walkley
Furries, various: Don
Broccoli furry: Tom

Animatic ►
Corgan Faller

Project Management ►
BoyPorcelain https://www.instagram.com/boyporcelain/

Assets and Rigging ►
Corgan Faller
Mangolini  https://www.drawmango.com/
Michelle De Flaviis
Mike Castillo
Bela Nogueira
Shawn Han

Animation ►
Michelle De Flaviis
Fhilslife https://twitter.com/FhilsLifeJoe
Holly Gee
Kris B
YasHGG https://twitter.com/Yas_HGG
Phil Watson https://instagram.com/PawDrawsart
Perry https://twitter.com/perryhull
Sven van der Storke https://instagram.com/storktoons

COMPOS

