# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Canada Breaks National Record for Medals With Gold in Women’s Sprint Canoe and Men’s Breakdance, Silver in Men’s 800M
 - [https://www.theepochtimes.com/world/canada-takes-gold-in-womens-single-canoe-and-mens-breakdance-earns-silver-in-mens-800m-5703520](https://www.theepochtimes.com/world/canada-takes-gold-in-womens-single-canoe-and-mens-breakdance-earns-silver-in-mens-800m-5703520)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T21:55:22+00:00

Katie Vincent, from Mississauga, Ont., poses for photos with her two Olympic medals following the 200m canoe single final at the Summer Olympics, in Vaires-sur-Marne, France, on Aug. 10, 2024. (The Canadian Press/Adrian Wyld)

## German Open Water Athlete Falls Ill After Swimming in Seine River
 - [https://www.theepochtimes.com/sports/german-open-water-athlete-falls-ill-after-swimming-in-seine-river-5703472](https://www.theepochtimes.com/sports/german-open-water-athlete-falls-ill-after-swimming-in-seine-river-5703472)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T20:02:23+00:00

Germany's Leonie Beck competes during the marathon swimming women's 10 kilometers competition at the 2024 Summer Olympics in in Paris, France, on Aug. 8, 2024. (Vadim Ghirda/AP Photo)

## Ottawa Says It’s in Touch With Swiss Officials After Canadian Arrested on Suspicion of Spying for China
 - [https://www.theepochtimes.com/world/ottawa-says-its-in-touch-with-swiss-officials-after-canadian-arrested-on-suspicion-of-spying-for-china-5703433](https://www.theepochtimes.com/world/ottawa-says-its-in-touch-with-swiss-officials-after-canadian-arrested-on-suspicion-of-spying-for-china-5703433)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T17:49:32+00:00

The West Block of Parliament Hill is seen through the window of the Sir John A. Macdonald Building in Ottawa in a file photo. (The Canadian Press/Sean Kilpatrick)

## Tropical Storm Debby Remnants Brings Significant Rainfall to Montreal, Eastern Canada
 - [https://www.theepochtimes.com/world/tropical-storm-debby-remnants-brings-significant-rainfall-to-montreal-eastern-canada-5703418](https://www.theepochtimes.com/world/tropical-storm-debby-remnants-brings-significant-rainfall-to-montreal-eastern-canada-5703418)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T16:20:08+00:00

Vehicles drive slowly through water overflowing on to highway 30 in Vaudreuil-Dorion west of Montreal after heavy rains hit the area on August 9, 2024. (The Canadian Press/Peter McCabe)

## US Coast Guard Spots Russian Naval Vessel Near Alaska
 - [https://www.theepochtimes.com/us/us-coast-guard-spots-russian-naval-vessel-near-alaska-5703300](https://www.theepochtimes.com/us/us-coast-guard-spots-russian-naval-vessel-near-alaska-5703300)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T10:17:26+00:00

U.S. Coast Guard Cutter Alex Haley follows a Russian Federation naval ship south of the Aleutian Islands, Alaska, on Aug. 5, 2024. (U.S. Coast Guard)

## Catalan Separatist Leader Heads For Belgium After Evading Arrest in Spain
 - [https://www.theepochtimes.com/world/catalan-separatist-leader-heads-for-belgium-after-evading-arrest-in-spain-5702788](https://www.theepochtimes.com/world/catalan-separatist-leader-heads-for-belgium-after-evading-arrest-in-spain-5702788)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T09:20:17+00:00

Catalan separatist leader Carles Puigdemont returns to Barcelona, Spain, from seven years of self-imposed exile on Aug. 8, 2024. (Nacho Doce/Reuters)

## Cost of Living, Union Corruption in Focus as MPs Return
 - [https://www.theepochtimes.com/world/cost-of-living-union-corruption-in-focus-as-mps-return-5703144](https://www.theepochtimes.com/world/cost-of-living-union-corruption-in-focus-as-mps-return-5703144)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T04:00:48+00:00

CANBERRA, AUSTRALIA - MAY 14: Australia's Prime Minister Anthony Albanese (Front L) sits across from opposition leader Peter Dutton (Front R) during Question Time at Parliament House on May 14, 2024 in Canberra, Australia. Australia's Labor government is grappling with a slowing economy, weaker commodity prices, soaring housing costs and a softening labor market as it prepares to unveil its federal budget on May 14. To counter these headwinds, the budget is expected to feature smaller revenue upgrades compared to recent years, while outlining the government's interventionist policies aimed at boosting domestic manufacturing and the transition to green energy. Critics warn that such industrial policies risk fueling inflation and diverting resources from more productive sectors of the economy. The budget is seen as a key opportunity for the Labor government to deliver broad economic support that analysts say is fundamental to re-election chances next year. (Photo by Tracey Nearmy/Getty 

## An Aid Worker’s Airport Disappearance Stirs Fear of Repression Following Disputed Venezuela Election
 - [https://www.theepochtimes.com/world/an-aid-workers-airport-disappearance-stirs-fear-of-repression-following-disputed-venezuela-election-5702274](https://www.theepochtimes.com/world/an-aid-workers-airport-disappearance-stirs-fear-of-repression-following-disputed-venezuela-election-5702274)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T03:58:53+00:00

In this undated family photo, Venezuelan Edni Lopez, a political science professor and award-winning poet, flashes a vee sign at her home in Caracas, Venezuela. (Courtesy of family via AP)

## Amanda Knox Wasn’t Coerced but ‘Freely’ Accused a Bar Owner in Roommate’s Murder, Italian Court Says
 - [https://www.theepochtimes.com/world/amanda-knox-wasnt-coerced-but-freely-accused-a-bar-owner-in-roommates-murder-italian-court-says-5703058](https://www.theepochtimes.com/world/amanda-knox-wasnt-coerced-but-freely-accused-a-bar-owner-in-roommates-murder-italian-court-says-5703058)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T03:57:42+00:00

Amanda Knox arrives flanked by her husband, Christopher Robinson, right, and her lawyer, Luca Luparia Donati, left, at a court in Florence, Italy, June 5, 2024. (AP Photo/Antonio Calanni)

## Pacific Aid Bolstered as Leaders Head to New Caledonia
 - [https://www.theepochtimes.com/world/pacific-aid-bolstered-as-leaders-head-to-new-caledonia-5702786](https://www.theepochtimes.com/world/pacific-aid-bolstered-as-leaders-head-to-new-caledonia-5702786)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T03:00:43+00:00

Supplied image obtained Dec. 19, 2012; Pallets of emergency aid supplies are lined up and ready to be dispatched for delivery to cyclone ravaged Fiji. (AAP Image/Royal Australian Air Force)

## Health-Care ‘Serial Killers’ Could Potentially Abuse Canada’s Assisted Dying Program: Study
 - [https://www.theepochtimes.com/world/health-care-serial-killers-could-potentially-abuse-canadas-assisted-dying-program-study-5703093](https://www.theepochtimes.com/world/health-care-serial-killers-could-potentially-abuse-canadas-assisted-dying-program-study-5703093)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T02:27:56+00:00

A 60-year-old woman suffering from cancer rests in a hospital palliative care unit.  (Alain Jocard/AFP/Getty Images)

## Man Who Survived Removal of Part of Liver, Lung in Chinese Prison Speaks Out
 - [https://www.theepochtimes.com/china/man-who-survived-removal-of-part-of-liver-lung-in-chinese-prison-speaks-out-5703183](https://www.theepochtimes.com/china/man-who-survived-removal-of-part-of-liver-lung-in-chinese-prison-speaks-out-5703183)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T02:00:50+00:00

Cheng Peiming, a Falun Gong practitioner who had part of his liver and lung forcibly removed in a Chinese prison, speaks with an Epoch Times reporter after a press conference in Washington on Aug. 9, 2024. (Madalina Vasiliu/The Epoch Times)

## ‘Rubbish In, Rubbish Out’: Commonwealth Games Costings Slammed
 - [https://www.theepochtimes.com/world/rubbish-in-rubbish-out-commonwealth-games-costings-slammed-5702780](https://www.theepochtimes.com/world/rubbish-in-rubbish-out-commonwealth-games-costings-slammed-5702780)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T02:00:30+00:00

Commonwealth Games Australia CEO Craig Phillips speaks to media during a press conference in Melbourne, Australia, on July 18, 2023. (AAP Image/James Ross)

## Buyers Hover as Administrators Plot Course to Save Rex
 - [https://www.theepochtimes.com/world/buyers-hover-as-administrators-plot-course-to-save-rex-5702774](https://www.theepochtimes.com/world/buyers-hover-as-administrators-plot-course-to-save-rex-5702774)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T01:00:41+00:00

A Rex Airlines Boeing 737 departs Tullamarine Airport in Melbourne, Australia, on July 29, 2024. (William West/AFP via Getty Images)

## Budgets Running on Fumes as Car Costs Outpace Inflation
 - [https://www.theepochtimes.com/world/budgets-running-on-fumes-as-car-costs-outpace-inflation-5702767](https://www.theepochtimes.com/world/budgets-running-on-fumes-as-car-costs-outpace-inflation-5702767)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-08-10T00:00:19+00:00

Fuel prices are displayed at a Caltex fuel station in Albany, Western Australia, on March 29, 2024. (Susan Mortimer/The Epoch Times)

