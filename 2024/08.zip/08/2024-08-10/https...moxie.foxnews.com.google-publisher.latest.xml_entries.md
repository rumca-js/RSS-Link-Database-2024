# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Pilot, 35, identified from Brazil plane that spiraled out of sky and crashed, killing 62
 - [https://www.foxnews.com/world/pilot-35-identified-from-brazil-plane-spiraled-out-sky-crashed-killing-62](https://www.foxnews.com/world/pilot-35-identified-from-brazil-plane-spiraled-out-sky-crashed-killing-62)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T23:32:40+00:00

Capt. Danilo Santos Romano, 35, was identified as the pilot in the fatal Brazilian air disaster that killed all 62 people who were on board.

## Caitlin Clark calls Aaron Judge 'huge and swole' during visit to Yankees game
 - [https://www.foxnews.com/sports/caitlin-clark-calls-aaron-judge-huge-swole-during-visit-yankees-game](https://www.foxnews.com/sports/caitlin-clark-calls-aaron-judge-huge-swole-during-visit-yankees-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T23:08:35+00:00

WNBA rookie superstar Caitlin Clark met Yankees captain Aaron Judge for the first time and admitted he&apos;s &quot;way bigger than even people think.&quot;

## 'Beverly Hills, 90210' star Jennie Garth says menopause is a 'minefield': 'My body is fighting against me'
 - [https://www.foxnews.com/entertainment/beverly-hills-90210-star-jennie-garth-menopause-minefield-body-fighting-against-me](https://www.foxnews.com/entertainment/beverly-hills-90210-star-jennie-garth-menopause-minefield-body-fighting-against-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T22:51:40+00:00

&quot;Beverly Hills, 90210&quot; star Jennie Garth opened up about going through menopause. She said menopause was a &quot;daily minefield&quot; that affected her both physically and mentally.

## Country star Phil Vassar 'died twice' after heart attack and stroke: ‘I dropped dead’
 - [https://www.foxnews.com/entertainment/country-star-phil-vassar-died-twice-suffering-heart-attack-stroke-dropped-dead](https://www.foxnews.com/entertainment/country-star-phil-vassar-died-twice-suffering-heart-attack-stroke-dropped-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T22:36:18+00:00

Country music star Phil Vassar opened up about his health battles after he said he died twice and &quot;was dead for 30 minutes a couple of times.&quot;

## Uvalde school shooter’s uncle tried to intervene, but his call came 10 minutes after gunman was dead
 - [https://www.foxnews.com/us/uvalde-school-shooters-uncle-tried-intervene-call-10-minutes-gunman-dead](https://www.foxnews.com/us/uvalde-school-shooters-uncle-tried-intervene-call-10-minutes-gunman-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T22:30:19+00:00

Following a prolonged legal fight, Uvalde officials have released a collection of video and audio recordings from the 2022 mass shooting at Robb Elementary School.

## Jake Paul 'sick and tired' of US boxing's shortcomings at Paris Olympics, committed to fighting in 2028
 - [https://www.foxnews.com/sports/jake-paul-sick-tired-us-boxings-shortcomings-paris-olympics-committed-fighting-2028](https://www.foxnews.com/sports/jake-paul-sick-tired-us-boxings-shortcomings-paris-olympics-committed-fighting-2028)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T22:11:21+00:00

Jake Paul said he is committed to entering the ring in four years when fans and athletes from across the world descend on Los Angeles for the 2028 Summer Olympics.

## Steph Curry electrifies Team USA in 4th quarter on way to gold medal win at Paris Olympics
 - [https://www.foxnews.com/sports/steph-curry-electrifies-team-usa-4th-quarter-way-gold-medal-win-paris-olympics](https://www.foxnews.com/sports/steph-curry-electrifies-team-usa-4th-quarter-way-gold-medal-win-paris-olympics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T21:39:20+00:00

Stephen Curry scored 12 straight points, and the Americans defeated France 98-87 to win their fifth consecutive gold medal in men&apos;s basketball at the Paris Olympics.

## Carl Lewis pushes for drastic changes after US men's disastrous 4x100 relay: 'Time to blow up the system'
 - [https://www.foxnews.com/sports/carl-lewis-says-its-time-blow-up-system-after-another-disaster-u-s-mens-4x100-relay](https://www.foxnews.com/sports/carl-lewis-says-its-time-blow-up-system-after-another-disaster-u-s-mens-4x100-relay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T21:25:34+00:00

Nine-time Olympic gold medalist Carl Lewis wants to see some wholesale changes after the U.S. men&apos;s team&apos;s 4x100-meter relay race ended in disappointment again.

## Teenager going for a quick swim severely injured in shark attack
 - [https://www.foxnews.com/world/teenager-quick-swim-severely-injured-shark-attack](https://www.foxnews.com/world/teenager-quick-swim-severely-injured-shark-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T21:08:46+00:00

A 15-year-old from Colorado was severely injured when a shark attacked her while she was swimming on a family vacation in Belize this week.

## Large geological feature known as the 'Double Arch' and the 'Toilet Bowl' collapses in southern Utah
 - [https://www.foxnews.com/us/large-geological-feature-known-double-arch-toilet-bowl-collapses-southern-utah](https://www.foxnews.com/us/large-geological-feature-known-double-arch-toilet-bowl-collapses-southern-utah)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T21:02:46+00:00

National Park Service officials said a popular geological feature in Utah known as the &apos;Hole in the Roof,&apos; the &apos;Toilet Bowl&apos; and the &apos;Double Arch&apos; has collapsed.

## Trump campaign says internal communications were hacked, including Vance 'dossier,' by foreign sources
 - [https://www.foxnews.com/politics/trump-campaign-internal-communications-hacked-vance-dossier-foreign-sources](https://www.foxnews.com/politics/trump-campaign-internal-communications-hacked-vance-dossier-foreign-sources)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T21:01:22+00:00

Former President Trump&apos;s campaign said on Saturday that some of its internal communications had been hacked, possibly by Iran, which was also linked to a foiled assassination plot.

## Minnesota teacher pension fund under Walz accused of 'cooking the books' with unrealistic gains: report
 - [https://www.foxnews.com/politics/minnesota-teacher-pension-fund-under-walz-accused-cooking-books-unrealistic-gains-low-fees](https://www.foxnews.com/politics/minnesota-teacher-pension-fund-under-walz-accused-cooking-books-unrealistic-gains-low-fees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T20:53:29+00:00

Under Gov. Walz, Minnesota’s Teachers Retirement Association is accused by a pension investigator of hiding fees and reporting implausibly high returns, termed a &quot;Madoff miracle.&quot;

## British USWNT coach Emma Hayes after Olympic gold medal win: 'I love America'
 - [https://www.foxnews.com/sports/british-uswnt-coach-emma-hayes-after-olympic-gold-medal-win-i-love-america](https://www.foxnews.com/sports/british-uswnt-coach-emma-hayes-after-olympic-gold-medal-win-i-love-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T20:41:10+00:00

U.S. women&apos;s national team head coach Emma Hayes talked to NBC about the gold medal win over Brazil at the Paris Olympics Saturday night.

## Jordan Chiles' bronze medal may be withdrawn after appeal by Romania; leaves social media heartbroken
 - [https://www.foxnews.com/sports/jordan-chiles-bronze-medal-may-withdrawn-after-appeal-romania-leaves-social-media-heartbroken](https://www.foxnews.com/sports/jordan-chiles-bronze-medal-may-withdrawn-after-appeal-romania-leaves-social-media-heartbroken)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T20:37:02+00:00

Jordan Chiles could lose her Olympic bronze medal, which she won at the women&apos;s floor exercise final earlier in the week over a Romanian athlete

## Taiwan's Lin Yu-ting wins boxing gold medal amid Olympic gender controversy
 - [https://www.foxnews.com/sports/taiwans-lin-yu-ting-wins-boxing-gold-medal-amid-olympic-gender-controversy](https://www.foxnews.com/sports/taiwans-lin-yu-ting-wins-boxing-gold-medal-amid-olympic-gender-controversy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T20:18:02+00:00

Taiwanese boxer Lin Yu-ting dominated Poland&apos;s Julia Szeremeta to win boxing gold in the women&apos;s 57-kilogram division at the Paris Olympics on Saturday.

## Herbert Hoover’s humanitarian work is long remembered, but his presidency was tainted by the Great Depression
 - [https://www.foxnews.com/politics/herbert-hoovers-presidency](https://www.foxnews.com/politics/herbert-hoovers-presidency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T19:44:28+00:00

Herbert Hoover is remembered at &quot;the great humanitarian.&quot; Hoover took office in 1929, just months before the Great Depressions began in the United States.

## Team USA women's 4x400-meter relay dominates in gold medal win
 - [https://www.foxnews.com/sports/team-usa-womens-4x400-meter-relay-dominates-gold-medal-win](https://www.foxnews.com/sports/team-usa-womens-4x400-meter-relay-dominates-gold-medal-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T19:42:52+00:00

Team USA, featuring Shamier Little, Sydney McLaughlin-Levrone, Gabby Thomas and Alexis Holmes, won a gold medal in the women&apos;s 4x400-meter relay at the Paris Olympics.

## Christina Hall reveals she has a life coach amid nasty divorce from third ex-husband
 - [https://www.foxnews.com/entertainment/christina-hall-reveals-life-coach-amid-nasty-divorce-ex-husband](https://www.foxnews.com/entertainment/christina-hall-reveals-life-coach-amid-nasty-divorce-ex-husband)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T19:39:09+00:00

On Friday, Christina Hall who filed for divorce from her third husband, Josh Hall, last month — shared a life update and the lessons she&apos;s learned from her life coach.

## Team USA wins gold in men's 4x400-meter relay at Paris Olympics
 - [https://www.foxnews.com/sports/team-usa-wins-gold-mens-4x400-meter-relay-paris-olympics](https://www.foxnews.com/sports/team-usa-wins-gold-mens-4x400-meter-relay-paris-olympics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T19:23:21+00:00

Christopher Bailey, Vernon Norwood, Bryce Deadmon and Rai Benjamin won Team USA a gold medal in the 4x400-meter relay on Saturday at the Paris Olympics.

## Russian athletes allowed to take part Olympics closing ceremony despite banishment over Ukraine war
 - [https://www.foxnews.com/sports/russian-athletes-allowed-take-part-olympics-closing-ceremony-despite-banishment-over-ukraine-war](https://www.foxnews.com/sports/russian-athletes-allowed-take-part-olympics-closing-ceremony-despite-banishment-over-ukraine-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T19:04:33+00:00

Russian athletes will be able to participate in the Paris Olympics&apos; closing ceremonies on Sunday despite competing under a neutral banner.

## Kamala Harris beating Trump in ‘vibes,' says CNN host Fareed Zakaria
 - [https://www.foxnews.com/media/kamala-harris-beating-trump-vibes-says-cnn-host-fareed-zakaria](https://www.foxnews.com/media/kamala-harris-beating-trump-vibes-says-cnn-host-fareed-zakaria)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T19:00:16+00:00

CNN host Fareed Zakaria wrote Saturday that Vice President Harris and her running mate, Minnesota Gov. Tim Walz, are winning by leading a “vibes&quot;-heavy campaign.

## Passenger plane crashes in Brazil, killing all people on board, airline VoePass says
 - [https://www.foxnews.com/world/passenger-plane-crashes-brazil-killing-61-people-on-board-airline-voepass-says](https://www.foxnews.com/world/passenger-plane-crashes-brazil-killing-61-people-on-board-airline-voepass-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T18:45:07+00:00

A plane operated by the Brazilian airline VoePass has crashed in the country&apos;s Sao Paulo state on Friday, reports say.

## US assets deployed to Mideast will help Israel but will unlikely alter Iran's mind on retaliation, experts say
 - [https://www.foxnews.com/world/us-assets-deployed-mideast-help-israel-unlikely-impact-irans-mind-retaliation-experts-say](https://www.foxnews.com/world/us-assets-deployed-mideast-help-israel-unlikely-impact-irans-mind-retaliation-experts-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T18:26:35+00:00

The U.S. has deployed a dozen warships in recent months to the Middle East, diminishing the need for heavy redeployment of assets because the Navy maintains a robust presence in the region.

## American Masai Russell wins gold in women's 100-meter hurdles
 - [https://www.foxnews.com/sports/american-masai-russell-wins-gold-womens-100-meter-hurdles](https://www.foxnews.com/sports/american-masai-russell-wins-gold-womens-100-meter-hurdles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T18:24:46+00:00

American sprinter Masai Russell can call herself an Olympic gold medalist. When Russell crossed the finish line, she had won by one one-hundredth of a second.

## Woman found dead in O'Hare airport baggage machinery was a suicide: police
 - [https://www.foxnews.com/us/woman-found-ohare-airport-baggage-machinery-suicide-police](https://www.foxnews.com/us/woman-found-ohare-airport-baggage-machinery-suicide-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T17:57:43+00:00

Authorities say that the death of a woman whose body was discovered inside baggage machinery at O&apos;Hare International Airport has been ruled a suicide.

## Blake Lively sacrifices this 1 thing for Hollywood role: ‘I’ve put everything I have into this’
 - [https://www.foxnews.com/entertainment/blake-lively-sacrifices-1-thing-hollywood-role-ive-put-everything-i-have-this](https://www.foxnews.com/entertainment/blake-lively-sacrifices-1-thing-hollywood-role-ive-put-everything-i-have-this)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T17:55:58+00:00

&quot;Gossip Girl&quot; star Blake Lively revealed what it took for her to prepare for her new role in the movie &quot;It Ends With Us.&quot;

## Olympic Refugee Team B-girl disqualified over political statement during competition
 - [https://www.foxnews.com/sports/olympic-refugee-team-b-girl-disqualified-over-political-statement-during-competition](https://www.foxnews.com/sports/olympic-refugee-team-b-girl-disqualified-over-political-statement-during-competition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T17:42:12+00:00

Refugee Team Olympian Manizha Talash was disqualified from the breaking competition on Friday after wearing a cape that bore a political statement.

## Rod Stewart postpones 2 more shows after canceling 200th Las Vegas show
 - [https://www.foxnews.com/entertainment/rod-stewart-postpones-2-more-shows-after-canceling-200th-las-vegas-show](https://www.foxnews.com/entertainment/rod-stewart-postpones-2-more-shows-after-canceling-200th-las-vegas-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-08-10T17:31:53+00:00

Days after cancelling his 200th Las Vegas show, Rod Stewart announced the cancellation of two additional shows.

