# Source:RP - Cyfrowa, URL:https://cyfrowa.rp.pl/rss/2991-cyfrowa, language:pl-PL

## Rewolucja w leczeniu zębów. Pierwszy na świecie robot zastąpił dentystę
 - [https://cyfrowa.rp.pl/technologie/art40947811-rewolucja-w-leczeniu-zebow-pierwszy-na-swiecie-robot-zastapil-dentyste](https://cyfrowa.rp.pl/technologie/art40947811-rewolucja-w-leczeniu-zebow-pierwszy-na-swiecie-robot-zastapil-dentyste)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-08-10T05:16:00+00:00

Robot-dentysta przeprowadził w pełni zautomatyzowany zabieg na pacjencie. W przyszłości urządzenie, które współfinansuje ojciec Marka Zuckerberga, założyciela Facebooka, ma wykonywać koronę w zaledwie 15 minut.

