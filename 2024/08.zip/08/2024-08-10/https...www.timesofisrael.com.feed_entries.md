# Source:The Times of Israel, URL:https://www.timesofisrael.com/feed, language:en-US

## A Jewish bagel shop in Detroit closes after staff walk out on new ‘Zionist’ owner
 - [https://www.timesofisrael.com/a-jewish-bagel-shop-in-detroit-closes-after-staff-walk-out-on-new-zionist-owner](https://www.timesofisrael.com/a-jewish-bagel-shop-in-detroit-closes-after-staff-walk-out-on-new-zionist-owner)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T22:43:52+00:00

<p>Tensions over perceived gentrification and the ongoing Israel-Hamas conflict came to a head last month when workers publicly quit, making waves throughout the metro area</p>
<p>The post <a href="https://www.timesofisrael.com/a-jewish-bagel-shop-in-detroit-closes-after-staff-walk-out-on-new-zionist-owner/">A Jewish bagel shop in Detroit closes after staff walk out on new ‘Zionist’ owner</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/8-2-24-bagels-1-1024x640.jpg" title="A Jewish bagel shop in Detroit closes after staff walk out on new ‘Zionist’ owner" width="160" /></figure>

## Layoffs resume as Israeli hi-tech industry struggles to thrive in dark times
 - [https://www.timesofisrael.com/layoffs-resume-as-israeli-hi-tech-industry-struggles-to-thrive-in-dark-times](https://www.timesofisrael.com/layoffs-resume-as-israeli-hi-tech-industry-struggles-to-thrive-in-dark-times)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T22:43:48+00:00

<p>Fraught politics and the Gaza war are harming Israel's technology sector, but the US is also seeing a downturn, while Europe is closing in on both of them -- and fast</p>
<p>The post <a href="https://www.timesofisrael.com/layoffs-resume-as-israeli-hi-tech-industry-struggles-to-thrive-in-dark-times/">Layoffs resume as Israeli hi-tech industry struggles to thrive in dark times</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/F190221HP45-1024x640-1.jpg" title="Layoffs resume as Israeli hi-tech industry struggles to thrive in dark times" width="160" /></figure>

## Trump campaign says it was hacked, blames Iran without evidence
 - [https://www.timesofisrael.com/trump-campaign-says-it-was-hacked-blames-iran-without-evidence](https://www.timesofisrael.com/trump-campaign-says-it-was-hacked-blames-iran-without-evidence)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T21:39:59+00:00

<p>Politico says it has been receiving anonymous emails containing documents from inside Trump's campaign</p>
<p>The post <a href="https://www.timesofisrael.com/trump-campaign-says-it-was-hacked-blames-iran-without-evidence/">Trump campaign says it was hacked, blames Iran without evidence</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/07/AFP__20240720__364N72R__v1__HighRes__UsVotePoliticsTrumpVance-1024x640.jpg" title="Trump campaign says it was hacked, blames Iran without evidence" width="160" /></figure>

## Foreign Ministry rails at ‘extremist’ Norway after revoking its diplomats’ status
 - [https://www.timesofisrael.com/foreign-ministry-rails-at-extremist-norway-after-revoking-its-diplomats-status](https://www.timesofisrael.com/foreign-ministry-rails-at-extremist-norway-after-revoking-its-diplomats-status)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T20:58:34+00:00

<p>Spokesman cites Oslo's Palestinian state recognition, failure to call Hamas a terror group, support for ICC case; UK urges Israel 'to reconsider,' joining US and EU condemnations</p>
<p>The post <a href="https://www.timesofisrael.com/foreign-ministry-rails-at-extremist-norway-after-revoking-its-diplomats-status/">Foreign Ministry rails at &#8216;extremist&#8217; Norway after revoking its diplomats&#8217; status</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/03/AP24023807727955-1024x640.jpg" title="Foreign Ministry rails at &#8216;extremist&#8217; Norway after revoking its diplomats&#8217; status" width="160" /></figure>

## Smotrich fires back at Kirby, vows to maintain opposition to Gaza ‘surrender deal’
 - [https://www.timesofisrael.com/smotrich-fires-back-at-kirby-vows-to-maintain-opposition-to-gaza-surrender-deal](https://www.timesofisrael.com/smotrich-fires-back-at-kirby-vows-to-maintain-opposition-to-gaza-surrender-deal)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T20:27:45+00:00

<p>Far-right leader says he respects US but tells White House 'to respect Israeli democracy,' likens prospect of deal with Hamas to US reaching 'agreement with al-Qaeda and Bin Laden'</p>
<p>The post <a href="https://www.timesofisrael.com/smotrich-fires-back-at-kirby-vows-to-maintain-opposition-to-gaza-surrender-deal/">Smotrich fires back at Kirby, vows to maintain opposition to Gaza &#8216;surrender deal&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F240630YS200-e1719741594123-1024x640.jpg" title="Smotrich fires back at Kirby, vows to maintain opposition to Gaza &#8216;surrender deal&#8217;" width="160" /></figure>

## Hezbollah launches drones at north after IDF kills Hamas commander in Lebanon
 - [https://www.timesofisrael.com/hezbollah-launches-drones-at-north-after-idf-kills-hamas-commander-in-lebanon](https://www.timesofisrael.com/hezbollah-launches-drones-at-north-after-idf-kills-hamas-commander-in-lebanon)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T20:02:20+00:00

<p>Lebanese terror group says attack targeted base used by education corps, also fires rockets; Halevi meets Northern Command officers as Israel braces for response to Shukr killing</p>
<p>The post <a href="https://www.timesofisrael.com/hezbollah-launches-drones-at-north-after-idf-kills-hamas-commander-in-lebanon/">Hezbollah launches drones at north after IDF kills Hamas commander in Lebanon</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AFP__20240810__36CN6UZ__v1__HighRes__LebanonPalestinianIsraelConflict-e1723316668799-1024x640.jpg" title="Hezbollah launches drones at north after IDF kills Hamas commander in Lebanon" width="160" /></figure>

## New poll shows Harris leading Trump in 3 key US election battleground states
 - [https://www.timesofisrael.com/new-poll-shows-harris-leading-trump-in-3-key-us-election-battleground-states](https://www.timesofisrael.com/new-poll-shows-harris-leading-trump-in-3-key-us-election-battleground-states)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T17:54:22+00:00

<p>Survey shows Republican nominee trailing the VP by 4% in Wisconsin, Pennsylvania and Michigan, amid surging support for Democratic ticket since Biden quit race</p>
<p>The post <a href="https://www.timesofisrael.com/new-poll-shows-harris-leading-trump-in-3-key-us-election-battleground-states/">New poll shows Harris leading Trump in 3 key US election battleground states</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/07/AFP__20240722__364N89K__v1__HighRes__ComboUsPoliticsVoteTrumpHarris-e1721757166267-1024x640.jpg" title="New poll shows Harris leading Trump in 3 key US election battleground states" width="160" /></figure>

## US says warship docked in Cyprus can ‘support civilians’ if regional conflict erupts
 - [https://www.timesofisrael.com/us-says-warship-docked-in-cyprus-can-support-civilians-if-regional-conflict-erupts](https://www.timesofisrael.com/us-says-warship-docked-in-cyprus-can-support-civilians-if-regional-conflict-erupts)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T17:39:58+00:00

<p>Amphibious assault ship arrives in Limassol for pre-scheduled visit amid fears of broader Mideast war; Cyprus offers to facilitate evacuations if tensions boil over</p>
<p>The post <a href="https://www.timesofisrael.com/us-says-warship-docked-in-cyprus-can-support-civilians-if-regional-conflict-erupts/">US says warship docked in Cyprus can &#8216;support civilians&#8217; if regional conflict erupts</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AFP__20240809__36D877V__v2__HighRes__CyprusUsNavyShip-e1723309027131-1024x640.jpg" title="US says warship docked in Cyprus can &#8216;support civilians&#8217; if regional conflict erupts" width="160" /></figure>

## Australian university probes student meeting that backed destruction of Israel
 - [https://www.australianjewishnews.com/motion-backs-armed-resistance](https://www.australianjewishnews.com/motion-backs-armed-resistance)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T16:46:36+00:00

<p>Jewish students at U of Sydney said barred from speaking as motion passes urging a Palestinian state 'from the river to the sea' by means of 'armed resistance'</p>
<p>The post <a href="https://www.timesofisrael.com/australian-university-probes-student-meeting-that-backed-destruction-of-israel/">Australian university probes student meeting that backed destruction of Israel</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/Screenshot-2024-08-10-193714-e1723308006287-1024x640.png" title="Australian university probes student meeting that backed destruction of Israel" width="160" /></figure>

## Powder-keg port town of Haifa readies for Hezbollah strike: ‘We are very exposed’
 - [https://www.timesofisrael.com/powder-keg-port-town-of-haifa-readies-for-hezbollah-strike-we-are-very-exposed](https://www.timesofisrael.com/powder-keg-port-town-of-haifa-readies-for-hezbollah-strike-we-are-very-exposed)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T16:15:34+00:00

<p>Northern city still scarred by 2006 war with Iran-backed group; amid drone attacks, residents fear coast's combustible materials could fuel local repeat of Beirut's 2020 blast</p>
<p>The post <a href="https://www.timesofisrael.com/powder-keg-port-town-of-haifa-readies-for-hezbollah-strike-we-are-very-exposed/">Powder-keg port town of Haifa readies for Hezbollah strike: &#8216;We are very exposed&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AFP__20240809__36D366T__v4__HighRes__TopshotIsraelLebanonPalestinianConflict-e1723294601731-1024x640.jpg" title="Powder-keg port town of Haifa readies for Hezbollah strike: &#8216;We are very exposed&#8217;" width="160" /></figure>

## Israeli team wins silver in rhythmic gymnastics, claiming nation’s 7th medal of Games
 - [https://www.timesofisrael.com/israeli-team-wins-silver-in-rhythmic-gymnastics-claiming-nations-7th-medal-of-games](https://www.timesofisrael.com/israeli-team-wins-silver-in-rhythmic-gymnastics-claiming-nations-7th-medal-of-games)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T15:45:48+00:00

<p>Member of squad calls second-place finish 'the best thing that’s happened in our lives,' while her teammate says, 'We were so together and it was worth every second'</p>
<p>The post <a href="https://www.timesofisrael.com/israeli-team-wins-silver-in-rhythmic-gymnastics-claiming-nations-7th-medal-of-games/">Israeli team wins silver in rhythmic gymnastics, claiming nation&#8217;s 7th medal of Games</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AP24223522075090-1024x640.jpg" title="Israeli team wins silver in rhythmic gymnastics, claiming nation&#8217;s 7th medal of Games" width="160" /></figure>

## Doug Emhoff brings fight against global antisemitism surge to Paris Olympics
 - [https://www.timesofisrael.com/doug-emhoff-brings-fight-against-global-antisemitism-surge-to-paris-olympics](https://www.timesofisrael.com/doug-emhoff-brings-fight-against-global-antisemitism-surge-to-paris-olympics)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T15:41:38+00:00

<p>Democratic nominee's husband, who could become first Jewish spouse of a US president, attends commemoration of deadly 1982 attack on kosher deli, visits well-known falafel joint</p>
<p>The post <a href="https://www.timesofisrael.com/doug-emhoff-brings-fight-against-global-antisemitism-surge-to-paris-olympics/">Doug Emhoff brings fight against global antisemitism surge to Paris Olympics</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/AFP__20240809__36D28YU__v2__HighRes__FranceHistoryReligionAttackCeremony-e1723300646978-1024x640.jpg" title="Doug Emhoff brings fight against global antisemitism surge to Paris Olympics" width="160" /></figure>

## Amid global criticism, Israel names 19 it says it killed in terror HQ at Gaza school
 - [https://www.timesofisrael.com/israel-slammed-globally-after-hamas-claims-at-least-90-dead-in-strike-on-gaza-school](https://www.timesofisrael.com/israel-slammed-globally-after-hamas-claims-at-least-90-dead-in-strike-on-gaza-school)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T14:53:07+00:00

<p>White House 'deeply concerned' by strike; Egypt, Qatar fume; top EU diplomat slams unjustified 'massacres'; IDF dismisses Hamas claim 90 killed, says no major damage to school complex</p>
<p>The post <a href="https://www.timesofisrael.com/israel-slammed-globally-after-hamas-claims-at-least-90-dead-in-strike-on-gaza-school/">Amid global criticism, Israel names 19 it says it killed in terror HQ at Gaza school</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/22479cd4-c7a8-4b59-9850-2ce3ce2b09d3-e1723309738426-1024x640.jpg" title="Amid global criticism, Israel names 19 it says it killed in terror HQ at Gaza school" width="160" /></figure>

## Iran’s president reappoints UN-sanctioned official to lead atomic agency
 - [https://www.timesofisrael.com/irans-president-reappoints-un-sanctioned-official-to-lead-atomic-agency](https://www.timesofisrael.com/irans-president-reappoints-un-sanctioned-official-to-lead-atomic-agency)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T14:36:34+00:00

<p>Mohammad Eslami, who worked for years in Iran's military industries, remains blacklisted for alleged role in nuclear proliferation and nuclear arms development</p>
<p>The post <a href="https://www.timesofisrael.com/irans-president-reappoints-un-sanctioned-official-to-lead-atomic-agency/">Iran&#8217;s president reappoints UN-sanctioned official to lead atomic agency</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/12/AP23346464255533-e1703676796537-1024x640.jpg" title="Iran&#8217;s president reappoints UN-sanctioned official to lead atomic agency" width="160" /></figure>

## Hostages’ families, anti-government groups rally to mark 10 months since Oct. 7
 - [https://www.timesofisrael.com/hostages-families-anti-government-groups-gear-up-to-mark-10-months-since-oct-7](https://www.timesofisrael.com/hostages-families-anti-government-groups-gear-up-to-mark-10-months-since-oct-7)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-08-10T13:47:14+00:00

<p>Weekly protests in all major cities seek to put pressure on government to seal hostage-ceasefire deal</p>
<p>The post <a href="https://www.timesofisrael.com/hostages-families-anti-government-groups-gear-up-to-mark-10-months-since-oct-7/">Hostages&#8217; families, anti-government groups rally to mark 10 months since Oct. 7</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/08/F240803AVS211-e1722714749653-1024x640.jpg" title="Hostages&#8217; families, anti-government groups rally to mark 10 months since Oct. 7" width="160" /></figure>

