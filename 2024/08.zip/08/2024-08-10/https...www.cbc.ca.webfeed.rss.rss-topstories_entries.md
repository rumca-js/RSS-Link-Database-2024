# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## 'Really, that song?': Celine Dion disavows Trump's usage of My Heart Will Go On at rally
 - [https://www.cbc.ca/news/entertainment/celine-dion-trump-rally-my-heart-will-go-on-1.7291413?cmp=rss](https://www.cbc.ca/news/entertainment/celine-dion-trump-rally-my-heart-will-go-on-1.7291413?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-08-10T17:21:15+00:00

<img alt="Singer Celine Dion wearing a sparkling dress, performing at the 2024 Paris Olympics opening ceremony." height="349" src="https://i.cbc.ca/1.7277213.1722031034!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/celine-dion-olympics.jpg" title="Céline Dion closed out the 2024 Paris Olympics opening ceremony on July 26, marking the singer&apos;s first public performance in more than four years." width="620" /><p>My Heart Will Go On helped propel Dion to super stardom as it was used in the 1997 Oscar-winning blockbluster film Titanic. </p>

## It took 10 years for a Beachcombers fan to find and restore this boat that starred in series
 - [https://www.cbc.ca/player/play/9.6472775?cmp=rss](https://www.cbc.ca/player/play/9.6472775?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-08-10T10:00:00+00:00

<img alt="A still of a speedboat flying along water." height="349" src="https://i.cbc.ca/ais/806d1081-f75a-41ea-a36c-a98c154f6e9d,1722976932255/full/max/0/default.jpg?im=Crop%2Crect%3D%280%2C0%2C1919%2C1079%29%3BResize%3D%28620%29" title="" width="620" /><p>Deano Fatovic, a huge fan of the long-running CBC show, was able to find the Highballer II boat after a decade of searching. He now plans to get the vessel operational and eventually donate it to a Gibsons, B.C., museum.</p>

## Canada joins international condemnation of deadly Israeli strike on Gaza school compound
 - [https://www.cbc.ca/news/world/airstrike-100-gaza-city-august-10-1.7291161?cmp=rss](https://www.cbc.ca/news/world/airstrike-100-gaza-city-august-10-1.7291161?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-08-10T09:21:55+00:00

<img alt="People survey damage to a building hit by a rocket." height="349" src="https://i.cbc.ca/1.7291350.1723315324!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/israel-palestinians.JPG" title="Palestinians look at the damage at the site of an Israeli strike on a school sheltering displaced people, amid the Israel-Hamas conflict, in Gaza City August 10, 2024. REUTERS/Mahmoud Issa     TPX IMAGES OF THE DAY" width="620" /><p>An Israeli airstrike on a Gaza City school compound housing displaced Palestinian families killed around 100 people, the Gaza Civil Emergency Service said on Saturday, while Israel said the toll was inflated and 19 militants were among the dead.</p>

## I'm a napper — and proud to call myself one
 - [https://www.cbc.ca/news/canada/first-person-napping-sleeping-1.7284084?cmp=rss](https://www.cbc.ca/news/canada/first-person-napping-sleeping-1.7284084?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-08-10T04:00:00+00:00

<img alt="A man sleeps on a couch while holding a grey cat." height="349" src="https://i.cbc.ca/1.7284140.1722626928!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/jordan-kawchuk.jpg" title="Jordan Kawchuk enjoys a nap with his cat, Makie, in this photo from 2005.  " width="620" /><p>For most of his life, Jordan Kawchuk accepted the idea that napping is for the weak. But he realized over time that he shouldn't feel guilty about napping because it makes him a better person.</p>

## U.S. voters split on whether Trump or Harris will be better for the economy — and them
 - [https://www.cbc.ca/news/world/american-voters-us-economy-1.7289112?cmp=rss](https://www.cbc.ca/news/world/american-voters-us-economy-1.7289112?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-08-10T04:00:00+00:00

<img alt="Bey is an African American woman wearing a white Blacks for Trump hat. She is holding a navy blue Trump-Vance sign with the slogan Make America Great Again on it." height="349" src="https://i.cbc.ca/1.7290918.1723250050!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/saiyda-bey.jpg" title="Saiyda Bey works three jobs to pay her bills. The 33-year-old north Philadelphia resident believes life will be better if Donald Trump is elected president." width="620" /><p>Americans are divided on which presidential candidate will make life better for middle and lower income families. Neither Donald Trump nor Kamala Harris has released a detailed economic platform, yet polls suggest many Americans believe Republicans are focused on the economy and tax cuts while Democrats have promised to tax the rich and corporations.</p>

## Your kid wants to get into hammer throwing. What are coaches looking for?
 - [https://www.cbc.ca/sports/olympics/summer/athletics/olympics-coaching-unique-sports-1.7290164?cmp=rss](https://www.cbc.ca/sports/olympics/summer/athletics/olympics-coaching-unique-sports-1.7290164?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-08-10T04:00:00+00:00

<img alt="Canadian hammer thrower Camryn Rogers competes during women&apos;s hammer throw qualification at the Paris Olympics on Aug. 4, 2024 at Stade de France." height="349" src="https://i.cbc.ca/1.7285078.1722771343!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/rogers-camryn-240804-1180.jpg" title="Camryn Rogers of Richmond, B.C. qualified for the Olympic women&apos;s hammer throw final on Tuesday when she met the 73.00-metre entry standard with a 74.69 effort in the second round of qualification on Sunday at Stade de France. " width="620" /><p>Ethan Katzberg and Camryn Rogers have made niche sports like hammer throw cool in Canada. So how does a new fan pursue these specialized sports?</p>

