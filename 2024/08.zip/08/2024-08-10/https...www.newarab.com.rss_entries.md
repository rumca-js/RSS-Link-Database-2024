# Source:The New Arab, URL:https://www.newarab.com/rss, language:en

## Over 100 killed in Israeli strike on Gaza school, world condemns
 - [https://www.newarab.com/news/over-100-killed-israeli-strike-gaza-school-world-condemns](https://www.newarab.com/news/over-100-killed-israeli-strike-gaza-school-world-condemns)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T16:50:10+00:00

The Al-Tabeen school victims were killed as they performed dawn prayers in the shelter, with at least three Israeli missiles ripping through the complex.

## Top Iraqi Shia cleric warns of Mid East escalation amid Gaza war
 - [https://www.newarab.com/news/top-iraqi-shia-cleric-warns-mid-east-escalation-amid-gaza-war](https://www.newarab.com/news/top-iraqi-shia-cleric-warns-mid-east-escalation-amid-gaza-war)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T16:22:21+00:00

Sistani made a statement urging the end of the Gaza war, and warned of 'catastrophic consequences' that could impact the region in the event of a wider conflict

## Iran president names sanctioned official as nuclear agency head
 - [https://www.newarab.com/news/iran-president-names-sanctioned-official-nuclear-agency-head](https://www.newarab.com/news/iran-president-names-sanctioned-official-nuclear-agency-head)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T15:37:21+00:00

Eslami, re-appointed by Pezeshkian, will continue his work as chief of Iran's civilian nuclear programme, and serve as one of several vice presidents.

## Prisoner groups say 10,000 Palestinians arrested in WB since Oct
 - [https://www.newarab.com/news/prisoner-groups-say-10000-palestinians-arrested-wb-oct](https://www.newarab.com/news/prisoner-groups-say-10000-palestinians-arrested-wb-oct)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T14:49:18+00:00

Over 10,000 Palestinians have been arrested in the occupied West Bank since October, Palestinian prisoners groups have said in a statement.

## Libya: At least nine killed in militia infighting in Tripoli
 - [https://www.newarab.com/news/libya-least-nine-killed-militia-infighting-tripoli](https://www.newarab.com/news/libya-least-nine-killed-militia-infighting-tripoli)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T14:32:09+00:00

The clashes occurred on Friday between the rival Rahba al-Duruae militia and al-Shahida Sabriya militia groups, killing at least nine.

## Kamala Harris tells protesters ‘now is time for ceasefire'
 - [https://www.newarab.com/news/kamala-harris-tells-protesters-now-time-ceasefire](https://www.newarab.com/news/kamala-harris-tells-protesters-now-time-ceasefire)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T12:53:05+00:00

Responding to pro-Palestine protesters in Arizona, Harris said that she was working ‘around the clock’ for a truce deal.

## Olympic breakdancer disqualified for 'Free Afghan Women' slogan
 - [https://www.newarab.com/news/olympic-breakdancer-disqualified-free-afghan-women-slogan](https://www.newarab.com/news/olympic-breakdancer-disqualified-free-afghan-women-slogan)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T12:47:24+00:00

Manizha Talash, an Olympic refugee breakdancer originally from Afghanistan, was disqualified due to the slogan being deemed as 'political'.

## US charges former Syria prison chief with immigration fraud
 - [https://www.newarab.com/news/us-charges-former-syria-prison-chief-immigration-fraud](https://www.newarab.com/news/us-charges-former-syria-prison-chief-immigration-fraud)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T11:41:00+00:00

Al-Sheikh, who oversaw torture in a Syrian prison, has been charged with attempted naturalisation fraud and obtaining a green card through false statements.

## Jordan denies allowing Israel to use airspace if Iran attacks
 - [https://www.newarab.com/news/jordan-denies-allowing-israel-use-airspace-if-iran-attacks](https://www.newarab.com/news/jordan-denies-allowing-israel-use-airspace-if-iran-attacks)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T11:14:28+00:00

An official Jordanian statement says Jordan will not allow any party to use their airspace for military purposes, as Israel anticipates an attack from Iran.

## Iran to carry out Ayatollah order to 'harshly punish' Israel
 - [https://www.newarab.com/news/iran-carry-out-ayatollah-order-harshly-punish-israel](https://www.newarab.com/news/iran-carry-out-ayatollah-order-harshly-punish-israel)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T10:42:32+00:00

The Revolutionary Guards deputy said the punishment over Haniyeh's assassination will be 'implemented in the best possible way'.

## Netanyahu says occupied West Bank ‘part of our homeland’
 - [https://www.newarab.com/news/netanyahu-says-occupied-west-bank-part-our-homeland](https://www.newarab.com/news/netanyahu-says-occupied-west-bank-part-our-homeland)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T09:40:41+00:00

Israel’s prime minister Benjamin Netanyahu made the remarks in an interview with TIME Magazine, adding he opposes a sovereign Palestinian state.

## Gaza Journalist Tamim Muammar killed in Israeli air strike
 - [https://www.newarab.com/news/gaza-journalist-tamim-muammar-killed-israeli-air-strike](https://www.newarab.com/news/gaza-journalist-tamim-muammar-killed-israeli-air-strike)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T08:33:39+00:00

Palestine Voice radio journalist Tamim Muammar was killed along with several family members in an Israeli air strike which targeted their home.

## More than 100 killed in Gaza City school strike, world condemns
 - [https://www.newarab.com/news/more-100-killed-gaza-city-school-strike-world-condemns](https://www.newarab.com/news/more-100-killed-gaza-city-school-strike-world-condemns)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T08:23:33+00:00

An Israeli strike has killed over 100 Palestinians sheltering in a Gaza City school, with Israeli forces using 2,000 pound bombs for the attack.

## US military base attacked by drone in Syria
 - [https://www.newarab.com/news/us-military-base-attacked-drone-syria](https://www.newarab.com/news/us-military-base-attacked-drone-syria)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T01:43:18+00:00

A US military base in north-eastern Syria was reportedly hit by multiple drones with damage assessments still ongoing.

## Iran says Guards navy gets 'large number' of new missiles
 - [https://www.newarab.com/news/iran-says-guards-navy-gets-large-number-new-missiles](https://www.newarab.com/news/iran-says-guards-navy-gets-large-number-new-missiles)
 - RSS feed: https://www.newarab.com/rss
 - date published: 2024-08-10T01:34:34+00:00

Iranian state TV on Friday said that 'a large number of new anti-ship cruise missiles were added to the IRGC naval forces by the order of the Guards chief'.

