# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Kalendarium - niedziela 11 sierpnia
 - [https://pro.rp.pl/kalendarium/art40946521-kalendarium-niedziela-11-sierpnia](https://pro.rp.pl/kalendarium/art40946521-kalendarium-niedziela-11-sierpnia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T22:04:00+00:00

Co dziś nowego w prawie i gospodarce? Co opublikowano w Dzienniku Ustaw, jakie akty prawne wchodzą w życie, jakie ważne interpretacje wydały sądy, co ogłosił GUS, a co zapowiedział rząd? Oto nasze subiektywne kalendarium dla profesjonalistów.

## Paryż 2024. Kiedy ceremonia zamknięcia? Kto z Polaków startuje ostatniego dnia?
 - [https://sport.rp.pl/paryz-2024/art40937631-paryz-2024-kiedy-ceremonia-zamkniecia-kto-z-polakow-startuje-ostatniego-dnia](https://sport.rp.pl/paryz-2024/art40937631-paryz-2024-kiedy-ceremonia-zamkniecia-kto-z-polakow-startuje-ostatniego-dnia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T21:30:00+00:00

W niedzielę ostatni dzień igrzysk olimpijskich w Paryżu. Wystartuje zaledwie czworo Polaków w dwóch sportach. Trudno liczyć na medale. Wieczorem zgaśnie znicz olimpijski.

## Zmiany w naborze dotyczącym wsparcia dla branży HoReCa
 - [https://pro.rp.pl/finanse/art40950141-zmiany-w-naborze-dotyczacym-wsparcia-dla-branzy-horeca](https://pro.rp.pl/finanse/art40950141-zmiany-w-naborze-dotyczacym-wsparcia-dla-branzy-horeca)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T21:15:14+00:00

O dwa dni przesunięty został termin, w którym przedsiębiorcy mogą składać wnioski o wsparcie na rozszerzenie lub zmianę profilu dotychczasowej działalności prowadzonej w sektorach takich jak hotelarstwo, gastronomia (HoReCa), turystyka lub kultura.

## Paryż 2024. Cud się nie zdarzył. Amerykańscy koszykarze piąty raz z rzędu ze złotem
 - [https://sport.rp.pl/koszykowka/art40950121-paryz-2024-cud-sie-nie-zdarzyl-amerykanscy-koszykarze-piaty-raz-z-rzedu-ze-zlotem](https://sport.rp.pl/koszykowka/art40950121-paryz-2024-cud-sie-nie-zdarzyl-amerykanscy-koszykarze-piaty-raz-z-rzedu-ze-zlotem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T21:12:00+00:00

Amerykański dream team - tak jak trzy lata temu w Tokio - pokonał w finale turnieju olimpijskiego Francuzów 98:87 (20:15, 29:26, 23:25, 26:21).

## Żużel. Niespodzianka w indywidualnych mistrzostwach Polski. Bartosz Zmarzlik stracił tytuł
 - [https://sport.rp.pl/moto/art40950021-zuzel-niespodzianka-w-indywidualnych-mistrzostwach-polski-bartosz-zmarzlik-stracil-tytul](https://sport.rp.pl/moto/art40950021-zuzel-niespodzianka-w-indywidualnych-mistrzostwach-polski-bartosz-zmarzlik-stracil-tytul)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T19:58:27+00:00

Po raz trzeci w karierze tytuł indywidualnego mistrza Polski na żużlu wywalczył Maciej Janowski. Zawodnik Sparty Wrocław był perfekcyjny w ostatniej rundzie krajowego czempionatu w Lublinie. Srebro wywalczył Patryk Dudek a brąz Bartosz Zmarzlik.

## Paryż 2024. Julia Szeremeta nic więcej nie mogła zrobić. Srebro na Roland Garros
 - [https://sport.rp.pl/paryz-2024/art40950031-paryz-2024-julia-szeremeta-nic-wiecej-nie-mogla-zrobic-srebro-na-roland-garros](https://sport.rp.pl/paryz-2024/art40950031-paryz-2024-julia-szeremeta-nic-wiecej-nie-mogla-zrobic-srebro-na-roland-garros)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T19:54:00+00:00

Julia Szeremeta zdecydowanie przegrała walkę finałową turnieju bokserskiego w kategorii 57 kg z Lin Yu Ting z Tajwanu. Wywalczyła srebrny medal, pierwszy w historii polskiego pięściarstwa kobiet.

## Putin ułaskawił Termirlana Eskerchanowa.  Jeden z zabójców Borysa Niemcowa walczy na Ukrainie
 - [https://www.rp.pl/konflikty-zbrojne/art40950041-putin-ulaskawil-termirlana-eskerchanowa-jeden-z-zabojcow-borysa-niemcowa-walczy-na-ukrainie](https://www.rp.pl/konflikty-zbrojne/art40950041-putin-ulaskawil-termirlana-eskerchanowa-jeden-z-zabojcow-borysa-niemcowa-walczy-na-ukrainie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T19:00:00+00:00

Jeden z skazanych w sprawie karnej za zabójstwo Borysa Niemcowa, były policjant z Czeczenii Temirlan Eskerchanow, został zwolniony z więzienia i bierze udział w działaniach wojennych na Ukrainie - informuje niezależny rosyjski portal "The Moscow Times".

## Sondaż Siena Polls dla "NYT". Czy stany swingujące przechylają się na stronę Kamali Harris?
 - [https://www.rp.pl/polityka/art40949341-sondaz-siena-polls-dla-nyt-czy-stany-swingujace-przechylaja-sie-na-strone-kamali-harris](https://www.rp.pl/polityka/art40949341-sondaz-siena-polls-dla-nyt-czy-stany-swingujace-przechylaja-sie-na-strone-kamali-harris)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T17:06:00+00:00

Sondaże, przeprowadzone w tym tygodniu przez ośrodek badawczy  Siena Polls dla dziennika "The New York Times" w Michigan, Wisconsin i Pensylwanii, wskazują na znaczącą zmianę w poparciu dla Partii Demokratycznej od czasu, gdy prezydent Biden zrezygnował ze starań o reelekcję.

## Rosyjski oligarcha krytykuje inwazję Rosji na Ukrainę. Coraz ostrzej
 - [https://www.rp.pl/biznes/art40949021-rosyjski-oligarcha-krytykuje-inwazje-rosji-na-ukraine-coraz-ostrzej](https://www.rp.pl/biznes/art40949021-rosyjski-oligarcha-krytykuje-inwazje-rosji-na-ukraine-coraz-ostrzej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T16:13:52+00:00

Każdy, kto publicznie wypowiada się przeciwko atakowi na Ukrainę w Rosji, stąpa po cienkim lodzie. Jednak miliarder Oleg Deripaska wielokrotnie odważył się na ostrożną krytykę. Teraz bliski Kremlowi oligarcha zajmuje zaskakująco jasne stanowisko wobec wojny – wywołując ostre reakcje w ojczyźnie.

## Spór o handel e-samochodami Chin z Unią trafia do WTO
 - [https://www.rp.pl/handel/art40948921-spor-o-handel-e-samochodami-chin-z-unia-trafia-do-wto](https://www.rp.pl/handel/art40948921-spor-o-handel-e-samochodami-chin-z-unia-trafia-do-wto)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T15:39:27+00:00

Chiny zaskarżyły w WTO cła antydumpingowe Unii Europejskiej na swoje e-auta. Bruksela jest absolutnie pewna słuszności swej decyzji.

## BBC chce zwrotu pokaźnej premii od byłego prezentera. „Zdyskredytował nas”
 - [https://www.rp.pl/media/art40948951-bbc-chce-zwrotu-pokaznej-premii-od-bylego-prezentera-zdyskredytowal-nas](https://www.rp.pl/media/art40948951-bbc-chce-zwrotu-pokaznej-premii-od-bylego-prezentera-zdyskredytowal-nas)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T15:10:16+00:00

BBC nakazała byłemu prezenterowi Huw Edwardsowi zwrot ponad 200 000 funtów (ponad milion złotych), które otrzymał w formie wynagrodzenia po aresztowaniu w listopadzie ubiegłego roku pod zarzutem posiadania „nieprzyzwoitych zdjęć dzieci”. Prezenter przyznał się do winy przed sadem.

## Tych bankructw można było uniknąć. Raport KRD
 - [https://pro.rp.pl/finanse/art40950071-tych-bankructw-mozna-bylo-uniknac-raport-krd](https://pro.rp.pl/finanse/art40950071-tych-bankructw-mozna-bylo-uniknac-raport-krd)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T14:56:00+00:00

219 upadłości firm i 2261 ogłoszonych restrukturyzacji oraz 141,1 mln zł strat po stronie wierzycieli odnotowano w I półroczu 2024 r.  Co 4. firma, która zbankrutowała, potrzebowała na to trzech lat – w tym czasie pogrążała kolejnych wierzycieli - ujawnia Krajowy Rejestr Długów.

## Białoruś rozmieszcza systemy rakietowe w pobliżu granicy z Ukrainą
 - [https://www.rp.pl/konflikty-zbrojne/art40948961-bialorus-rozmieszcza-systemy-rakietowe-w-poblizu-granicy-z-ukraina](https://www.rp.pl/konflikty-zbrojne/art40948961-bialorus-rozmieszcza-systemy-rakietowe-w-poblizu-granicy-z-ukraina)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T14:49:00+00:00

Aleksander Łukaszenko nakazał wzmocnienie sił zbrojnych wzdłuż granicy z obwodami kijowskim i czernihowskim Ukrainy. Trafi tam broń zdolna zagrozić Polsce i krajom bałtyckim.

## Boeing wraca do korzeni. A nowy prezes do fabryki pod Seattle
 - [https://www.rp.pl/transport/art40948801-boeing-wraca-do-korzeni-a-nowy-prezes-do-fabryki-pod-seattle](https://www.rp.pl/transport/art40948801-boeing-wraca-do-korzeni-a-nowy-prezes-do-fabryki-pod-seattle)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T14:18:47+00:00

O Kellym Ortbergu, nowym prezesie Boeinga dzisiaj z całą pewnością wiadomo dwie rzeczy: jeśli uda mu się misja naprawy firmy, będzie bohaterem narodowym. Jeśli polegnie będzie „tylko” bardzo bogaty.

## Artur Bartkiewicz: Szymon Hołownia ma problem. Ruszył jak w biegu na 100 metrów, a rywalizuje w maratonie
 - [https://www.rp.pl/komentarze/art40948821-artur-bartkiewicz-szymon-holownia-ma-problem-ruszyl-jak-w-biegu-na-100-metrow-a-rywalizuje-w-maratonie](https://www.rp.pl/komentarze/art40948821-artur-bartkiewicz-szymon-holownia-ma-problem-ruszyl-jak-w-biegu-na-100-metrow-a-rywalizuje-w-maratonie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T13:58:00+00:00

Na przełomie stycznia i lutego w sondażu prezydenckim Szymon Hołownia miał poparcie na poziomie Mateusza Morawieckiego i Rafała Trzaskowskiego. Dziś przegrywa w sondażu nie tylko z nimi, ale też z Krzysztofem Bosakiem. Co takiego się stało?

## Tragedia na Mount Blanc. Alpinista spadł ze szczytu podczas wspinaczki
 - [https://www.rp.pl/spoleczenstwo/art40948901-tragedia-na-mount-blanc-alpinista-spadl-ze-szczytu-podczas-wspinaczki](https://www.rp.pl/spoleczenstwo/art40948901-tragedia-na-mount-blanc-alpinista-spadl-ze-szczytu-podczas-wspinaczki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T13:54:00+00:00

Podczas wspinaczki na Mount Blanc – najwyższy szczyt Europy – alpinista spadł z wysokości około 4000 metrów. Mimo interwencji służb, mężczyzny nie udało się uratować.

## Kreml ucieka przed sankcjami na Ocean Lodowaty
 - [https://www.rp.pl/handel/art40948781-kreml-ucieka-przed-sankcjami-na-ocean-lodowaty](https://www.rp.pl/handel/art40948781-kreml-ucieka-przed-sankcjami-na-ocean-lodowaty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T13:42:59+00:00

Projekt Wielkiego Północnego Szlaku Morskiego ma dać Kremlowi najkrótsze połączenie handlowe z Azją i ucieczkę przed sankcjami. Przeszkód jest jednak tak wiele, że władze nie określiły nawet daty realizacji projektu ani jego kosztów.

## Sławny dyrygent oskarżony o sprzyjanie reżimowi w Wenezueli
 - [https://www.rp.pl/muzyka-klasyczna/art40948831-slawny-dyrygent-oskarzony-o-sprzyjanie-rezimowi-w-wenezueli](https://www.rp.pl/muzyka-klasyczna/art40948831-slawny-dyrygent-oskarzony-o-sprzyjanie-rezimowi-w-wenezueli)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T13:32:00+00:00

Gustavo Dudamel, jeden z najsłynniejszych dyrygentów na świecie i nowy szef Nowojorskich Filharmoników, musi zmierzyć się z oskarżeniami o popieranie dyktatory Maduro i milczeniu po sfałszowanych wyborach i protestach w Wenezueli.

## Kamil Kołsut: Julia Szeremeta zjednoczyła Polaków, a teraz Polskę dzieli
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art40948401-kamil-kolsut-julia-szeremeta-zjednoczyla-polakow-a-teraz-polske-dzieli](https://www.rp.pl/opinie-polityczno-spoleczne/art40948401-kamil-kolsut-julia-szeremeta-zjednoczyla-polakow-a-teraz-polske-dzieli)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T09:35:00+00:00

Sukces, który odniosła Julia Szeremeta, jednoczył Polskę, ale jej poglądy mogą ją podzielić.

## Wojna Rosji z Ukrainą. Dzień 899
 - [https://www.rp.pl/konflikty-zbrojne/art40947661-wojna-rosji-z-ukraina-dzien-899](https://www.rp.pl/konflikty-zbrojne/art40947661-wojna-rosji-z-ukraina-dzien-899)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-08-10T04:00:00+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę.

