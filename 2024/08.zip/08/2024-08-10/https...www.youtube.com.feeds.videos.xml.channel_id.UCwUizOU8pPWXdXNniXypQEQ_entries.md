# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Brainwashing You with Kamala's Very Diverse VP Pick!
 - [https://www.youtube.com/watch?v=5dFFq3mRoM4](https://www.youtube.com/watch?v=5dFFq3mRoM4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2024-08-10T15:00:05+00:00

Get your Freedom Merch Here - https://awakenwithjp.com/shop

Upcoming LIVE shows - https://awakenwithjp.com/pages/tour

Kamala has a new VP pick and he is absolutely amazing! 

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

