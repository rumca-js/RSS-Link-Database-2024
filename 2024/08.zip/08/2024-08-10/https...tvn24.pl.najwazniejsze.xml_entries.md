# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Julia Szeremeta na podium olimpijskim
 - [https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/julia-szeremeta-odebrala-srebrny-medal-olimpijski-w-boksie_vid30000593/video.shtml?source=rss](https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/julia-szeremeta-odebrala-srebrny-medal-olimpijski-w-boksie_vid30000593/video.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T21:00:22+00:00

<img alt="Julia Szeremeta na podium olimpijskim" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6697870-julia-szeremeta-odebrala-medal-ph8038512/alternates/LANDSCAPE_1280" />
    Zobacz ceremonię medalową, na której Polka odebrała srebrny medal.

## Szeremeta po finale. "Plan udał się połowicznie"
 - [https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-julia-szeremeta-w-rozmowie-z-eurosportem-po-finale_sto20028259/story.shtml?source=rss](https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-julia-szeremeta-w-rozmowie-z-eurosportem-po-finale_sto20028259/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T20:53:56+00:00

<img alt="Szeremeta po finale. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-203102-julia-szeremeta-i-sebastian-szczesny/alternates/LANDSCAPE_1280" />
    W swoim olimpijskim debiucie wywalczyła w Paryżu srebro.

## "Sp... robotę, bo to był konkurs na żałośnie niskim poziomie"
 - [https://eurosport.tvn24.pl/lekkoatletyka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-maria-andrejczyk-o-finale-olimpijskim-w-rzucie-oszczepem_sto20028219/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-maria-andrejczyk-o-finale-olimpijskim-w-rzucie-oszczepem_sto20028219/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T20:18:28+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-411678-maria-andrejczyk-byla-8-na-io-w-paryzu/alternates/LANDSCAPE_1280" />
    Andrejczyk żałuje straconej szansy.

## Szeremeta ze srebrem
 - [https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-julia-szeremeta-wywalczyla-srebro-w-boksie.-w-finale-przegrala-z-lin-yu-ting_sto20028225/story.shtml?source=rss](https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-julia-szeremeta-wywalczyla-srebro-w-boksie.-w-finale-przegrala-z-lin-yu-ting_sto20028225/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T19:53:00+00:00

<img alt="Szeremeta ze srebrem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3677067-julia-szeremeta-bez-zlotego-medalu-ph8038492/alternates/LANDSCAPE_1280" />
    W sobotnim finale w Paryżu przegrała jednogłośnie z Lin Yu Ting z Tajwanu.

## Bez przyrządów z ręką w kieszeni. Tak wyglądał człowiek, w którym "się gotowało"
 - [https://eurosport.tvn24.pl/strzelectwo/igrzyska-olimpijskie-paryz-2024/2024/yusuf-dikec-turecki-wicemistrz-olimpijski-w-strzelectwie-zdradza-kulisy-slynnego-wystepu-w-paryzu_sto20027906/story.shtml?source=rss](https://eurosport.tvn24.pl/strzelectwo/igrzyska-olimpijskie-paryz-2024/2024/yusuf-dikec-turecki-wicemistrz-olimpijski-w-strzelectwie-zdradza-kulisy-slynnego-wystepu-w-paryzu_sto20027906/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T19:23:32+00:00

<img alt="Bez przyrządów z ręką w kieszeni. Tak wyglądał człowiek, w którym " src="https://tvn24.pl/najnowsze/cdn-zdjecie-263064-yusuf-dikec-zrobil-furore/alternates/LANDSCAPE_1280" />
    Turek Yusuf Dikec, wicemistrz olimpijski w strzelectwie, stał się rozpoznawalny po występie na igrzyskach w Paryżu.

## Zamrożenie cen energii, bon energetyczny "nie rozwiązują problemu". "Musimy zmienić podejście"
 - [https://tvn24.pl/go/programy,7/rozmowy-o-koncu-swiata-odcinki,499186/odcinek-66,S00E66,1430947?source=rss](https://tvn24.pl/go/programy,7/rozmowy-o-koncu-swiata-odcinki,499186/odcinek-66,S00E66,1430947?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T16:35:00+00:00

<img alt="Zamrożenie cen energii, bon energetyczny " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6851878-wiatrak-ph8037380/alternates/LANDSCAPE_1280" />
    Eksperci w rozmowie z Magdą Łucyan o bezpieczeństwie energetycznym.

## Kurek zaprasza kibiców na lotnisko
 - [https://eurosport.tvn24.pl/siatkowka/igrzyska-olimpijskie-paryz-2024/2024/kiedy-siatkarze-wracaja-do-polski-o-ktorej-przylot-polakow-z-igrzysk_sto20028113/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/igrzyska-olimpijskie-paryz-2024/2024/kiedy-siatkarze-wracaja-do-polski-o-ktorej-przylot-polakow-z-igrzysk_sto20028113/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T16:12:00+00:00

<img alt="Kurek zaprasza kibiców na lotnisko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9502491-polscy-siatkarze-ze-srebrnymi-medalami-igrzysk-olimpijskich-w-paryzu/alternates/LANDSCAPE_1280" />
    Kiedy siatkarze wracają do Polski? O której przylot Polaków z igrzysk?

## "Wszystkie światowe media mówią o tym, że Rosja poniosła porażkę"
 - [https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-129,S00E129,1431681?source=rss](https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-129,S00E129,1431681?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T15:33:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-203592-wladimir-putin-ph8038361/alternates/LANDSCAPE_1280" />
    Jacek Stawiski i Marcin Wrona mówili o akcji wojsk ukraińskich w obwodzie kurskim w Rosji.

## Incydent podczas miesięcznicy smoleńskiej
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/miesiecznika-smolenska-jaroslaw-kaczynski-wyprowadzony-z-rownowagi-putinowska-szmato-st8038342?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/miesiecznika-smolenska-jaroslaw-kaczynski-wyprowadzony-z-rownowagi-putinowska-szmato-st8038342?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T15:05:10+00:00

<img alt="Incydent podczas miesięcznicy smoleńskiej " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3783580-prezes-prawa-i-sprawiedliwosci-jaroslaw-kaczynski-podczas-obchodow-miesiecznicy-katastrofy-smolenskiej-ph8038330/alternates/LANDSCAPE_1280" />
    Kaczyński do jednego z protestujących: putinowska szmato.

## Połowa Grecji za chwilę znajdzie się w "czerwonej strefie"
 - [https://tvn24.pl/tvnmeteo/swiat/wysokie-zagrozenie-pozarowe-w-grecji-apeluje-do-wszystkich-obywateli-o-czujnosc-st8038304?source=rss](https://tvn24.pl/tvnmeteo/swiat/wysokie-zagrozenie-pozarowe-w-grecji-apeluje-do-wszystkich-obywateli-o-czujnosc-st8038304?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T14:48:50+00:00

<img alt="Połowa Grecji za chwilę znajdzie się w " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1089818-pozary-w-grecji-ph7984791/alternates/LANDSCAPE_1280" />
    Ogień łatwo się wznieca, bo jest sucho i gorąco.

## Rybak złowił pierwszego w historii zaginionego rekina Lego
 - [https://tvn24.pl/swiat/wielka-brytania-wyjatkowy-rekin-z-lego-w-rybackiej-sieci-zaginal-27-lat-temu-gdy-ladunek-z-klockami-wpadl-do-morza-st8038292?source=rss](https://tvn24.pl/swiat/wielka-brytania-wyjatkowy-rekin-z-lego-w-rybackiej-sieci-zaginal-27-lat-temu-gdy-ladunek-z-klockami-wpadl-do-morza-st8038292?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T14:44:06+00:00

<img alt="Rybak złowił pierwszego w historii zaginionego rekina Lego   " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4679827-rekin-ph8038293/alternates/LANDSCAPE_1280" />
    To pierwsza odnaleziona figurka rekina z ponad 50 tysięcy zaginionych na morzu sztuk.

## Kaczyński: gdybyśmy rządzili, on byłby prezydentem
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-gdybysmy-rzadzili-mariusz-blaszczak-bylby-prezydentem-st8038295?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-gdybysmy-rzadzili-mariusz-blaszczak-bylby-prezydentem-st8038295?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T14:35:18+00:00

<img alt="Kaczyński: gdybyśmy rządzili, on byłby prezydentem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5376142-jaroslaw-kaczynski-ph8038346/alternates/LANDSCAPE_1280" />
    Prezes PiS na konferencji prasowej.

## Pogoda na długi weekend sierpniowy
 - [https://tvn24.pl/tvnmeteo/najnowsze/pogoda-nadlugi-weekend-sierpniowy-2024nadciaga-fala-upalow-przed-nami-uderzenie-goraca-st8038196?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/pogoda-nadlugi-weekend-sierpniowy-2024nadciaga-fala-upalow-przed-nami-uderzenie-goraca-st8038196?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T13:54:57+00:00

<img alt="Pogoda na długi weekend sierpniowy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8820881-pogoda-ph8038267/alternates/LANDSCAPE_1280" />
    Sprawdź szczegóły prognozy.

## Zapomnieli o smutku. Srebrne medale na szyjach polskich siatkarzy
 - [https://eurosport.tvn24.pl/siatkowka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-polscy-siatkarze-odebrali-srebrne-medale.-zobacz-ceremonie-dekoracji_sto20028030/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-polscy-siatkarze-odebrali-srebrne-medale.-zobacz-ceremonie-dekoracji_sto20028030/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T13:39:39+00:00

<img alt="Zapomnieli o smutku. Srebrne medale na szyjach polskich siatkarzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8133296-polscy-siatkarze-odebrali-srebrne-medale-olimpijskie-ph8038302/alternates/LANDSCAPE_1280" />
    Pokonani w finale, ale na podium uśmiechnięci. Polscy siatkarze odebrali srebrne medale olimpijskie.

## Falstart deweloperów
 - [https://tvn24.pl/biznes/nieruchomosci/ekspert-o-kredycie-na-start-nie-obawiam-sie-lawiny-kolejek-st8038245?source=rss](https://tvn24.pl/biznes/nieruchomosci/ekspert-o-kredycie-na-start-nie-obawiam-sie-lawiny-kolejek-st8038245?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T13:37:03+00:00

<img alt="Falstart deweloperów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9265538-nieruchomosci-mieszkanie-budowa-deweloper-budownictwo-ph8032134/alternates/LANDSCAPE_1280" />
    "To korzystna sytuacja dla kupujących".

## Setki milionów rozdane przed wyborami. Kaczyński: mieliśmy świadomość, że możemy utracić władzę
 - [https://tvn24.pl/polska/370-milionow-rozdane-przez-kancelarie-morawieckiego-w-wroku-wyborczym-kaczynski-mielismy-swiadomosc-ze-mozemy-utracic-wladze-st8038156?source=rss](https://tvn24.pl/polska/370-milionow-rozdane-przez-kancelarie-morawieckiego-w-wroku-wyborczym-kaczynski-mielismy-swiadomosc-ze-mozemy-utracic-wladze-st8038156?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T12:16:19+00:00

<img alt="Setki milionów rozdane przed wyborami. Kaczyński: mieliśmy świadomość, że możemy utracić władzę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9535715-jaroslaw-kaczynski-na-konferencji-w-siedzibie-pis-ph8038159/alternates/LANDSCAPE_1280" />
    Premier informował w piątek, że w ubiegłym roku KPRM udzieliła dotacje celowe o łącznej wartości 370 milionów złotych.

## Samolot Donalda Trumpa lądował awaryjnie
 - [https://tvn24.pl/swiat/samolot-donalda-trumpa-ladowal-awaryjnie-st8038107?source=rss](https://tvn24.pl/swiat/samolot-donalda-trumpa-ladowal-awaryjnie-st8038107?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T11:02:01+00:00

<img alt="Samolot Donalda Trumpa lądował awaryjnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7911-en016283990873-1-ph8038116/alternates/LANDSCAPE_1280" />
    W drodze na wiec wyborczy.

## Pękł lodowiec, miasto pod wodą
 - [https://tvn24.pl/tvnmeteo/najnowsze/pekl-lodowiec-miasto-pod-woda-st8038118?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/pekl-lodowiec-miasto-pod-woda-st8038118?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T11:00:25+00:00

<img alt="Pękł lodowiec, miasto pod wodą" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6944750-powodz-w-juneau-stolicy-alaski-ph8038129/alternates/LANDSCAPE_1280" />
    Ponad 100 domów zostało zalanych.

## Edyta Bartosiewicz o "najlepszej rzeczy, jaka mogła się wydarzyć w jej życiu"
 - [https://tvn24.pl/kultura-i-styl/edyta-bartosiewicz-to-najlepsza-rzecz-jaka-mogla-sie-wydarzyc-w-moim-zyciu-st8038013?source=rss](https://tvn24.pl/kultura-i-styl/edyta-bartosiewicz-to-najlepsza-rzecz-jaka-mogla-sie-wydarzyc-w-moim-zyciu-st8038013?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T10:40:01+00:00

<img alt="Edyta Bartosiewicz o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2812691-edyta-bartosiewicz-ph8038001/alternates/LANDSCAPE_1280" />
    W rozmowie z TVN24.

## Rosyjski miliarder ma kłopoty
 - [https://tvn24.pl/biznes/ze-swiata/rosyjski-miliarder-skrytykowany-za-wezwanie-do-zawieszenia-broni-to-cios-w-plecy-st8038010?source=rss](https://tvn24.pl/biznes/ze-swiata/rosyjski-miliarder-skrytykowany-za-wezwanie-do-zawieszenia-broni-to-cios-w-plecy-st8038010?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T09:40:38+00:00

<img alt="Rosyjski miliarder ma kłopoty" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie4173398375d7d3b456a0c194d745402d-oleg-deripaska-musial-oddac-prywatne-odrzutowce-4576566/alternates/LANDSCAPE_1280" />
    Został skrytykowany za antywojenne wystąpienie.

## "Urodziłam się jako kobieta, żyłam jako kobieta i rywalizowałam jako kobieta". Ma złoto
 - [https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/imane-khelif-mistrzynia-olimpijska.-w-finale-pokonala-yang-liu_sto20027928/story.shtml?source=rss](https://eurosport.tvn24.pl/boks/igrzyska-olimpijskie-paryz-2024/2024/imane-khelif-mistrzynia-olimpijska.-w-finale-pokonala-yang-liu_sto20027928/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T09:35:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8218684-imane-khelif-mistrzynia-olimpijska-ph8038047/alternates/LANDSCAPE_1280" />
    Nie było niespodzianki.

## Broń warta 125 milionów dolarów pojedzie na Ukrainę
 - [https://tvn24.pl/swiat/bron-warta-125-milionow-dolarow-pojedzie-na-ukraine-st8037866?source=rss](https://tvn24.pl/swiat/bron-warta-125-milionow-dolarow-pojedzie-na-ukraine-st8037866?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T08:47:25+00:00

<img alt="Broń warta 125 milionów dolarów pojedzie na Ukrainę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4538931-ukrainskie-wojsko-ph8036750/alternates/LANDSCAPE_1280" />
    899 dni temu rozpoczęła się rosyjska inwazja.

## Przejazd tunelem POW nie będzie już darmowy dla wszystkich
 - [https://tvn24.pl/tvnwarszawa/ursynow/warszawa-przejazd-tunelem-pow-juz-nie-bedzie-za-darmo-st8036451?source=rss](https://tvn24.pl/tvnwarszawa/ursynow/warszawa-przejazd-tunelem-pow-juz-nie-bedzie-za-darmo-st8036451?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T08:47:02+00:00

<img alt="Przejazd tunelem POW nie będzie już darmowy dla wszystkich" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9555656-tunel-pow-ph7342045/alternates/LANDSCAPE_1280" />
    Od początku listopada.

## Brat premiera zdobył fortunę, ale nie wie skąd
 - [https://tvn24.pl/biznes/ze-swiata/hiszpania-brat-premiera-david-sanchez-nie-umie-wyjasnic-skad-zdobyl-fortune-st8037955?source=rss](https://tvn24.pl/biznes/ze-swiata/hiszpania-brat-premiera-david-sanchez-nie-umie-wyjasnic-skad-zdobyl-fortune-st8037955?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T08:36:31+00:00

<img alt="Brat premiera zdobył fortunę, ale nie wie skąd" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7666735-pap2024071706s-ph8015764/alternates/LANDSCAPE_1280" />
    Skandal w Hiszpanii.

## Ukraińcy weszli w Rosję "jak w masło". Generał Bieniek o tym, co dalej
 - [https://tvn24.pl/swiat/ukraincy-weszli-w-rosje-jak-w-maslo-general-bieniek-o-tym-co-dalej-st8037940?source=rss](https://tvn24.pl/swiat/ukraincy-weszli-w-rosje-jak-w-maslo-general-bieniek-o-tym-co-dalej-st8037940?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T08:14:57+00:00

<img alt="Ukraińcy weszli w Rosję " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7649514-ukrainska-ofensywa-w-obwodzie-kurskim-ph8036436/alternates/LANDSCAPE_1280" />
    Na antenie TVN24.

## Mają problem, który narasta od 30 lat. "To ma masowy charakter"
 - [https://tvn24.pl/go/programy,7/horyzont-odcinki,11393/odcinek-4503,S00E4503,1430970?source=rss](https://tvn24.pl/go/programy,7/horyzont-odcinki,11393/odcinek-4503,S00E4503,1430970?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T08:10:00+00:00

<img alt="Mają problem, który narasta od 30 lat. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8385404-wielka-brytania-zamieszki-w-sunderland-2-sierpnia-policyjny-samochod-zostal-podpalony-ph8032832/alternates/LANDSCAPE_1280" />
    Dr Przemysław Biskup o zamieszkach, które wybuchły po zabójstwie trzech kilkuletnich dziewczynek w Southport.

## 90 lat ma, wzięcia już nie
 - [https://tvn24.pl/biznes/dla-seniora/waclaw-dominiak-90-letni-krawiec-od-ponad-pol-wieku-prowadzi-punkt-krawiecki-elegant-w-warszawie-st8033103?source=rss](https://tvn24.pl/biznes/dla-seniora/waclaw-dominiak-90-letni-krawiec-od-ponad-pol-wieku-prowadzi-punkt-krawiecki-elegant-w-warszawie-st8033103?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T07:17:41+00:00

<img alt="90 lat ma, wzięcia już nie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9579945-waclaw-dominiak-uslugi-krawieckie-elegant-ph8033875/alternates/LANDSCAPE_1280" />
    "Żeby zarobić i 20 złotych, to biorę co jest".

## Cindy jest lesbijką, nie może wrócić do kraju. Ale zdobyła pierwszy, historyczny medal
 - [https://tvn24.pl/premium/igrzyska-olimpijskie-w-paryzu-2024-kto-potrzebuje-reprezentacji-uchodzcow-st8037687?source=rss](https://tvn24.pl/premium/igrzyska-olimpijskie-w-paryzu-2024-kto-potrzebuje-reprezentacji-uchodzcow-st8037687?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T06:40:34+00:00

<img alt="Cindy jest lesbijką, nie może wrócić do kraju. Ale zdobyła pierwszy, historyczny medal" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3372748-cindy-ngamba-ma-juz-pewny-medal/alternates/LANDSCAPE_1280" />
    Trening tak, paszport nie. Kto potrzebuje reprezentacji uchodźców?

## "Siostra ma tu syna. Idę z nią, bo się zapłacze"
 - [https://tvn24.pl/krakow/trzebinia-otworzyli-cmentarz-w-sierszy-na-ktorym-powstalo-zapadlisko-st8036939?source=rss](https://tvn24.pl/krakow/trzebinia-otworzyli-cmentarz-w-sierszy-na-ktorym-powstalo-zapadlisko-st8036939?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T06:25:25+00:00

<img alt="" id="Id" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2518054-cmentarz-w-trzebini-zostal-otwarty-po-pracach-uzdatniajacych-teren-ph8036888/alternates/LANDSCAPE_1280" />
    Otworzyli cmentarz, na którym zapadła się ziemia.

## Na niebie zaroi się od spadających gwiazd. Kiedy je oglądać
 - [https://tvn24.pl/tvnmeteo/ciekawostki/perseidy-2024-kiedy-ogladac-spadajace-gwiazdy-deszcz-meteorow-sie-zbliza-st8037879?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/perseidy-2024-kiedy-ogladac-spadajace-gwiazdy-deszcz-meteorow-sie-zbliza-st8037879?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T06:03:37+00:00

<img alt="Na niebie zaroi się od spadających gwiazd. Kiedy je oglądać" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-27x3mg-maksimum-roju-perseidow-przypada-12-sierpnia-4946945/alternates/LANDSCAPE_1280" />
    Zbliża się maksimum roju Perseidów.

## Susan Wojcicki nie żyje
 - [https://tvn24.pl/swiat/susan-wojcicki-nie-zyje-byla-szefowa-youtube-miala-56-lat-st8037881?source=rss](https://tvn24.pl/swiat/susan-wojcicki-nie-zyje-byla-szefowa-youtube-miala-56-lat-st8037881?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T05:48:19+00:00

<img alt="Susan Wojcicki nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8663187-nie-zyje-susan-wojcicki-ph8037880/alternates/LANDSCAPE_1280" />
    Była szefowa serwisu YouTube miała 56 lat.

## Dwie groźne choroby w Hiszpanii
 - [https://tvn24.pl/swiat/dwie-grozne-choroby-w-hiszpanii-wiele-osob-w-szpitalach-czesc-zmarla-st8037856?source=rss](https://tvn24.pl/swiat/dwie-grozne-choroby-w-hiszpanii-wiele-osob-w-szpitalach-czesc-zmarla-st8037856?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T03:46:01+00:00

<img alt="Dwie groźne choroby w Hiszpanii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8908994-shutterstock1669246738-ph8037795/alternates/LANDSCAPE_1280" />
    Wiele osób w szpitalach, część zmarła.

## Tąpnięcie na światowych giełdach. Ekspert: USA chcą zmienić układ sił na świecie
 - [https://tvn24.pl/go/programy,7/byk-i-niedzwiedz--odcinki,356828/odcinek-1456,S00E1456,1430945?source=rss](https://tvn24.pl/go/programy,7/byk-i-niedzwiedz--odcinki,356828/odcinek-1456,S00E1456,1430945?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T03:10:00+00:00

<img alt="Tąpnięcie na światowych giełdach. Ekspert: USA chcą zmienić układ sił na świecie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1439362-shutterstock2048864135-ph8037227/alternates/LANDSCAPE_1280" />
    Rafał Zaorski o przyczynach poniedziałkowego zamieszania na globalnych rynkach akcji.

## "Oczywiście, że jestem wkurzony, chciałem Jaworka zatrzymać"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-4573,S00E4573,1430973?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-4573,S00E4573,1430973?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-08-10T03:05:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6079715-sprawa-jacka-jaworka-ph8037848/alternates/LANDSCAPE_1280" />
    Makabryczna zbrodnia, a potem trzy lata bezskutecznych poszukiwań. Jerzy Korczyński bada śledztwo w sprawie Jacka Jaworka.

