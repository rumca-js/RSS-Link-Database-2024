# Source:ZDNET, URL:https://www.zdnet.com/news/rss.xml, language:en-US

## Google's Pixel 8 is the real star of its Android lineup - and now it's $200 off
 - [https://www.zdnet.com/article/googles-pixel-8-is-the-real-star-of-its-android-lineup-and-its-30-off-for-amazon-prime-day/#ftag=RSSbaffb68](https://www.zdnet.com/article/googles-pixel-8-is-the-real-star-of-its-android-lineup-and-its-30-off-for-amazon-prime-day/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T23:00:21+00:00

The entry-level Pixel 8 might not get the same attention that the Pixel 8 Pro does, but due to its low price and impressive specs, that really needs to change.

## This easy email trick will make your inbox clutter vanish - without complex rules or multiple accounts
 - [https://www.zdnet.com/home-and-office/work-life/this-easy-email-trick-will-make-your-inbox-clutter-vanish/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/this-easy-email-trick-will-make-your-inbox-clutter-vanish/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T16:42:00+00:00

Is your inbox overflowing with ads, newsletters, and social media updates? This one feature that's built into most email solutions will fix that for you.

## Need Intel's Raptor Lake bug patch? You'll have to download and install it yourself
 - [https://www.zdnet.com/article/need-intels-raptor-lake-bug-patch-youll-have-to-download-and-install-it-yourself/#ftag=RSSbaffb68](https://www.zdnet.com/article/need-intels-raptor-lake-bug-patch-youll-have-to-download-and-install-it-yourself/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T16:01:00+00:00

The microcode bug patch for 13th- and 14th-generation Intel Core processors won't be made available via Windows Update.

## Wendy's AI-powered drive-thrus will be bilingual in these states
 - [https://www.zdnet.com/article/wendys-ai-powered-drive-thrus-will-be-bilingual-in-these-states/#ftag=RSSbaffb68](https://www.zdnet.com/article/wendys-ai-powered-drive-thrus-will-be-bilingual-in-these-states/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T15:52:00+00:00

Spanish-speaking customers in two states can now utilize AI ordering at select Wendy's locations.

## This tiny accessory gave my Android phone thermal vision superpowers. Here's how to use it
 - [https://www.zdnet.com/article/this-tiny-accessory-gave-my-android-phone-thermal-vision-superpowers-heres-how-to-use-it/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-tiny-accessory-gave-my-android-phone-thermal-vision-superpowers-heres-how-to-use-it/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T11:00:32+00:00

It might seem gimmicky, but this little gadget is now a must-have in my toolbox.

## I'm a diehard Pixel user, but I'm considering a change for two reasons (and I'm not alone)
 - [https://www.zdnet.com/article/im-a-diehard-pixel-user-but-im-considering-a-change-for-two-reasons-and-im-not-alone/#ftag=RSSbaffb68](https://www.zdnet.com/article/im-a-diehard-pixel-user-but-im-considering-a-change-for-two-reasons-and-im-not-alone/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T11:00:29+00:00

With the Pixel 9 release on the horizon, I'm wondering if it's time for me to switch to a different brand. Here's why.

## The most rugged Android phone I've tested also has a week-long battery life
 - [https://www.zdnet.com/article/the-most-rugged-android-phone-ive-tested-also-has-a-week-long-battery-life/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-most-rugged-android-phone-ive-tested-also-has-a-week-long-battery-life/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T11:00:23+00:00

If you need a phone that laughs in the face of inclement weather, the Doogee V Max Plus couldn't be more durable.

## I streamed with Logitech's Mevo Core camera and it almost beat my $3,600 Canon
 - [https://www.zdnet.com/article/i-streamed-with-logitechs-mevo-core-camera-and-it-almost-beat-my-3600-canon/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-streamed-with-logitechs-mevo-core-camera-and-it-almost-beat-my-3600-canon/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-08-10T10:00:22+00:00

Logitech's latest Mevo Core is the camera content creators and live streamers have been waiting for.

