# Source:The Dave Cullen Show, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg, language:en-US

## What Went Wrong? The League of Extraordinary Gentlemen
 - [https://www.youtube.com/watch?v=e1uRrAa2IZg](https://www.youtube.com/watch?v=e1uRrAa2IZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg
 - date published: 2024-08-10T14:10:01+00:00

Tip me: https://www.subscribestar.com/dave-cullen/tip
Support my Work on Paychute: https://www.paychute.com/c/davecullenshow
Subscribestar: https://www.subscribestar.com/dave-cullen

Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

KEEP UP ON SOCIAL MEDIA:
https://gab.com/DaveCullen
Minds.com: https://www.minds.com/davecullen
Subscribe on Odysee: https://odysee.com/@TheDaveCullenShow:7

