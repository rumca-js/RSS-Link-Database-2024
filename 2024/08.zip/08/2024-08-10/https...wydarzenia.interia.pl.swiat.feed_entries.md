# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Najnowszy sondaż z USA. Ma przewagę w kluczowych stanach
 - [https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-najnowszy-sondaz-z-usa-ma-przewage-w-kluczowych-stanach,nId,7755103](https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-najnowszy-sondaz-z-usa-ma-przewage-w-kluczowych-stanach,nId,7755103)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-08-10T15:45:37+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-najnowszy-sondaz-z-usa-ma-przewage-w-kluczowych-stanach,nId,7755103"><img align="left" alt="Najnowszy sondaż z USA. Ma przewagę w kluczowych stanach" src="https://i.iplsc.com/najnowszy-sondaz-z-usa-ma-przewage-w-kluczowych-stanach/000JLP95AS34DF2Y-C321.jpg" /></a>Kamala Harris wyprzedziła Donalda Trumpa w trzech kluczowych stanach - wynika z najnowszego sondażu. Obecna wiceprezydent USA w Michigan, Wisconsin i Pensylwanii prowadzi z przewagą 4 punktów procentowych. To w ostatnim czasie dla Harris kolejne pozytywne badanie opinii publicznej.</p><br clear="all" />

## Panika w rosyjskim obwodzie. Trwa masowa ewakuacja
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-panika-w-rosyjskim-obwodzie-trwa-masowa-ewakuacja,nId,7755106](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-panika-w-rosyjskim-obwodzie-trwa-masowa-ewakuacja,nId,7755106)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-08-10T15:05:57+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-panika-w-rosyjskim-obwodzie-trwa-masowa-ewakuacja,nId,7755106"><img align="left" alt="Panika w rosyjskim obwodzie. Trwa masowa ewakuacja" src="https://i.iplsc.com/panika-w-rosyjskim-obwodzie-trwa-masowa-ewakuacja/000JLP9U51PG6HYD-C321.jpg" /></a>&quot;Z przygranicznych rejonów obwodu kurskiego ewakuowano ponad 76 tys. osób&quot; - poinformowało w sobotę po południu regionalne Ministerstwo ds. Sytuacji Nadzwyczajnych. To efekt ofensywy Sił Zbrojnych Ukrainy, które od kilku dni prowadzą działania na terytorium Rosji. </p><br clear="all" />

