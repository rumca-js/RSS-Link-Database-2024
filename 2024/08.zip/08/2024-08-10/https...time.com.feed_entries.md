# Source:TIME, URL:https://time.com/feed, language:en-UK

## American Relay Teams Win Two Golds in the Last Events of a Dominant Olympic Track Meet for the U.S.
 - [https://time.com/7009855/american-relay-teams-win-two-golds](https://time.com/7009855/american-relay-teams-win-two-golds)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T22:30:43+00:00

Sydney McLaughlin-Levrone and Gabby Thomas brought the curtain down on track by romping to a win in women's 4x400 relay.

## Team USA Men’s Basketball Team Defeats France for Gold at Paris Olympics
 - [https://time.com/7009828/usa-france-gold](https://time.com/7009828/usa-france-gold)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T21:18:55+00:00

The U.S. men’s Olympic basketball team won a fifth consecutive Olympic gold medal.

## TikTokers Use ‘Not Ready to Make Nice’ by The Chicks to Criticize Kamala Harris—They Missed Context
 - [https://time.com/7009832/the-chicks-song-political-history](https://time.com/7009832/the-chicks-song-political-history)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T20:46:08+00:00

The hit song has been making the rounds on social media recently, but many missed the story behind it.

## Why Jordan Chiles’ Olympic Bronze Is In Jeopardy
 - [https://time.com/7009822/jordan-chiles-olympic-bronze-in-jeopardy](https://time.com/7009822/jordan-chiles-olympic-bronze-in-jeopardy)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T19:26:16+00:00

The placements in the women’s gymnastics floor final may be changed—again

## Trump Responds to Tim Walz Calling Him and J.D. Vance ‘Weird’: ‘We’re Very Solid People’
 - [https://time.com/7009800/donald-trump-responds-weird-label-jd-vance-tim-walz-commentary](https://time.com/7009800/donald-trump-responds-weird-label-jd-vance-tim-walz-commentary)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T18:35:25+00:00

"No, we're not weird. We're very solid people," Trump said, addressing the Montana crowd.

## U.S. Women’s Soccer Team Scores Victory at the Paris Olympics With Thrilling Gold Medal Win
 - [https://time.com/7009804/us-womens-soccer-team-gold-medal-win-paris-summer-olympics](https://time.com/7009804/us-womens-soccer-team-gold-medal-win-paris-summer-olympics)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T17:08:32+00:00

The United States Women’s National Soccer Team won the Olympic gold medal on Saturday at Parc des Princes, defeating Brazil in the final.

## Janja Garnbret Wins Gold in Boulder & Lead Final Becoming a Double Olympic Champion
 - [https://time.com/7009778/janja-garnbret-wins-olympic-gold-boulder-lead-final](https://time.com/7009778/janja-garnbret-wins-olympic-gold-boulder-lead-final)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T15:38:19+00:00

The athlete defended her gold medal in sports climbing on Saturday, becoming a double Olympic champion in the Boulder &#038; Lead event.

## Former YouTube CEO and Longtime Google Executive Susan Wojcicki Has Died at 56
 - [https://time.com/7009758/former-youtube-ceo-google-executive-susan-wojcicki-dies-at-56](https://time.com/7009758/former-youtube-ceo-google-executive-susan-wojcicki-dies-at-56)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T13:01:29+00:00

Susan Wojcicki, the former YouTube chief executive officer and longtime Google executive, has died, her husband said. She was 56.

## Ethiopian Runner Tamirat Tola Wins Men’s Marathon at Paris Olympics
 - [https://time.com/7009752/ethiopian-runner-tamirat-tola-wins-mens-marathon-at-paris-olympics](https://time.com/7009752/ethiopian-runner-tamirat-tola-wins-mens-marathon-at-paris-olympics)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T12:09:55+00:00

Ethiopian runner Tamirat Tola won the men's marathon at the Paris Olympics on Saturday to end Kenya's dominance of the race.

## Record-Breaking Wildfires Scorch More Than 1.4 Million Acres in Oregon, Authorities Say
 - [https://time.com/7009742/record-breaking-wildfires-scorch-over-million-acres-oregon-authorities](https://time.com/7009742/record-breaking-wildfires-scorch-over-million-acres-oregon-authorities)
 - RSS feed: https://time.com/feed
 - date published: 2024-08-10T11:49:25+00:00

Wildfires in Oregon have burned more acres of land in 2024 than in any year since reliable records began, authorities said Friday.

