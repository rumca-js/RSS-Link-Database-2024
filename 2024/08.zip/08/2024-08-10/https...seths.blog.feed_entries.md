# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Living in the future
 - [https://seths.blog/2024/08/living-in-the-future](https://seths.blog/2024/08/living-in-the-future)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-08-10T08:10:00+00:00

In a bad 1950s science fiction movie, you might see flying jetpacks, invisibility cloaks and ray guns. What we got instead is a device that fits in our pocket. It allows us to connect to more than a billion people. It knows where we are and where we&#8217;re going. It has all of our contacts, [&#8230;]

