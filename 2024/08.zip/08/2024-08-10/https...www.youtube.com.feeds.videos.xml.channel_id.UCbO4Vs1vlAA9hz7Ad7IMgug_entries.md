# Source:Guerrilla Miniature Games, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug, language:en

## GMG Reviews - NIGHT THIRST by Black Site Studio
 - [https://www.youtube.com/watch?v=YJd0Q1uLdLo](https://www.youtube.com/watch?v=YJd0Q1uLdLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug
 - date published: 2024-08-10T12:00:38+00:00

WittleGoblin's game of masquerading Vampires out for a blood-battle-royale is on the Review table today, published by Black Site Studio. 

Thanks to BSS for the complimentary copy of the book to review. 

You can pick up your own copy of B&amp;B Nightmare at https://blacksitestudio.com/en-ca/pages/nightthirst

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.gg/CCmeRy3

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/guerrilla-miniature-games/

GMG T-Shirts and Hoodies HERE: https://shop.spreadshirt.ca/guerrillaminiaturegames/

All Jingles and Music by Kevin McLeod: https://incompetech

## GMG Reviews - Warhammer 40,000: Boarding Actions by Games Workshop
 - [https://www.youtube.com/watch?v=butfSTSgctU](https://www.youtube.com/watch?v=butfSTSgctU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug
 - date published: 2024-08-10T09:00:34+00:00

Re-tooling a complete set of Missions, Boarding Patrol Mustering Sheets and rules-modifications for Warhammer 40,000 10th Edition, this compilation brings together the PDFs formerly hosted on Warhammer Community into one convenient tome. 

Big thanks to GW for the complimentary copy of the book to review. 

#adwip
#warhammer40k 
#warhammercommunity 

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/guerrilla-miniature-games/

GMG T-Shirts and Hoodies HERE: https://shop.spreadshirt.ca/guerrillaminiaturegames/

Intro 

## GMG Reviews - HILL KING  by Black Site Studio
 - [https://www.youtube.com/watch?v=OMv23Epcwmg](https://www.youtube.com/watch?v=OMv23Epcwmg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug
 - date published: 2024-08-10T09:00:30+00:00

Malev's micro-game of Royal Rumbling wrestlers that fight for glory up and down a hill made out of Jenga blocks, and published by Black Site Studio, is out now. 

Thanks to BSS for the complimentary copy of the book to review. 

You can pick up your own copy of Hill King at https://blacksitestudio.com/en-ca/pages/hillking

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.gg/CCmeRy3

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/guerrilla-miniature-games/

GMG T-Shirts and Hoodies HERE: https://shop.spreadshirt.ca/guerrillaminiaturegames/

All Jingles and Music by Kevin McLeod: https:

## GMG Reviews - CODEX: Imperial Agents by Games Workshop
 - [https://www.youtube.com/watch?v=NJImPF-5YNk](https://www.youtube.com/watch?v=NJImPF-5YNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug
 - date published: 2024-08-10T09:00:19+00:00

It's a long time coming but the various forces of the Inquisition have their own new Codex that also allows you to take a small selection of their units in other IMPERIUM armies! Let's dive in and check it out.                                                                                                                                                                                                                                                                                                                                                                                                      

Big thanks to GW for the complimentary copy of the book to review. 

#adwip
#warhammer40k 
#warhammercommunity 

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at GuerrillaMiniatureG

