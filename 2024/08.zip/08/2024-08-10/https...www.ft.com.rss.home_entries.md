# Source:FT - International homepage, URL:https://www.ft.com/rss/home, language:en

## US takes fifth straight Olympic gold in basketball with win over France
 - [https://www.ft.com/content/59581bc1-ad10-4702-858b-c426ed4ea2a0](https://www.ft.com/content/59581bc1-ad10-4702-858b-c426ed4ea2a0)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T22:57:35+00:00

Steph Curry led the Americans as an Olympic rookie making his first and possibly last Games appearance at age 36

## Israeli air strike on Gaza shelter kills around 100 people
 - [https://www.ft.com/content/8ca25c61-e1ae-4f19-960c-a22fa2fc998a](https://www.ft.com/content/8ca25c61-e1ae-4f19-960c-a22fa2fc998a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T17:18:16+00:00

Military says it targeted a ‘Hamas command and control centre’ where militants were planning attacks

## Former YouTube chief Susan Wojcicki dies at 56
 - [https://www.ft.com/content/c82b7fc6-c6de-40e2-ad20-41d78557bb21](https://www.ft.com/content/c82b7fc6-c6de-40e2-ad20-41d78557bb21)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T15:00:11+00:00

Early Google staffer and one of the most influential women in Silicon Valley has died of lung cancer

## Marcum Asia seeks new path after exclusion from deal for US parent
 - [https://www.ft.com/content/a79026ae-8d1b-4c79-8ccb-0a0896685567](https://www.ft.com/content/a79026ae-8d1b-4c79-8ccb-0a0896685567)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T12:00:27+00:00

Firm with annual revenues of about $50mn will be able to use brand during transition period

## The hunt for Argentina’s ‘alter egos’ in $16bn US court fight
 - [https://www.ft.com/content/6bae962c-6a54-4a31-a196-621fcd0a1fdf](https://www.ft.com/content/6bae962c-6a54-4a31-a196-621fcd0a1fdf)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T12:00:27+00:00

Oil company YPF, the country’s central bank and flag carrier are among the assets targeted by plaintiffs

## US junk loan funds suffer biggest outflows in 4 years
 - [https://www.ft.com/content/97811b4d-e245-4322-8a0e-5ac215d822ab](https://www.ft.com/content/97811b4d-e245-4322-8a0e-5ac215d822ab)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T12:00:27+00:00

Investors withdrew $2.5bn during market plunge on fears of economic slowdown and lower coupons if interest rates fall

## Where have OpenAI’s founders gone?
 - [https://www.ft.com/content/638f67f7-5375-47fc-b3a7-af7c9e05b9e0](https://www.ft.com/content/638f67f7-5375-47fc-b3a7-af7c9e05b9e0)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T12:00:27+00:00

Only two of 11 co-founders of ChatGPT maker are still active at the $86bn company after a series of exits this year

## Graham Thorpe, cricketer, 1969-2024
 - [https://www.ft.com/content/3fb13407-534f-4e90-9d00-b0c6ba9bc660](https://www.ft.com/content/3fb13407-534f-4e90-9d00-b0c6ba9bc660)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T04:00:27+00:00

The left-handed batsman was a shining light in an often dark period for the English game

## Rumble in the Hamptons
 - [https://www.ft.com/content/7af3f4d2-5e51-4079-b223-81dd66702b3c](https://www.ft.com/content/7af3f4d2-5e51-4079-b223-81dd66702b3c)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T04:00:27+00:00

For decades the sleepy Long Island hamlet of Montauk and its beloved Lobster Deck resisted gentrification. Enter Wall Street heavyweight Marc Rowan

## Running wild: across Lofoten on a ‘trail and sail’ adventure
 - [https://www.ft.com/content/b7038d5e-eb9a-497a-b64f-d6fc48243cc5](https://www.ft.com/content/b7038d5e-eb9a-497a-b64f-d6fc48243cc5)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T04:00:27+00:00

A new yacht-based trip offers thrilling scenery and total escape from crowded trails

## The culture wars have flipped
 - [https://www.ft.com/content/0c6f0e2f-ebe2-43ac-936f-58a55fa281c3](https://www.ft.com/content/0c6f0e2f-ebe2-43ac-936f-58a55fa281c3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T04:00:27+00:00

The critics of cancel culture and echo chambers have turned into an intolerant tribe of their own

## The yen carry trade sell-off marks a step change in the business cycle
 - [https://www.ft.com/content/c0ce569e-87f2-4eb6-8921-814e83a71d6d](https://www.ft.com/content/c0ce569e-87f2-4eb6-8921-814e83a71d6d)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T04:00:27+00:00

Gyrations in global markets come at a time of a monetary policy shift between the US and Japan

## What has surprised me about childlessness
 - [https://www.ft.com/content/598eb83e-027a-4664-9ff0-39efbe944c2d](https://www.ft.com/content/598eb83e-027a-4664-9ff0-39efbe944c2d)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-08-10T04:00:27+00:00

There are some perverse outcomes amid all the fun

