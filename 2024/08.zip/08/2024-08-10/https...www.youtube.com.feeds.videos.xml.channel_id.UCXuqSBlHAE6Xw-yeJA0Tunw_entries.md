# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I’m auctioning HIS collection - Tech Hoarders 2
 - [https://www.youtube.com/watch?v=1mHI2sA3KGI](https://www.youtube.com/watch?v=1mHI2sA3KGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-08-10T14:59:54+00:00

Join us in War Thunder for FREE at https://playwt.link/joinltt Get an exclusive bonus using our link - thanks for supporting the channel!

It’s never easy saying goodbye. And today Linus is making one of his employees say farewell to YEARS of retro collecting. He’s got everything, from modded Nintendos, to rare Playstations, to one of a kind Segas, to consoles that are worth TOO MUCH! It’s like reality TV, but better because it’s actually real this time, and you can get some of these valuable collectables yourself…

Check out the auction and score some of David’s cool retro collection: https://urbanauctions.ca/Browse?FullTextQuery=ltt

Discuss on the forum: https://linustechtips.com/topic/1579118-i%E2%80%99m-auctioning-his-collection-tech-hoarders-2/

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► GET A VPN: http://www.piavpn.com/linus
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: 

## Google Is A Monopoly - WAN Show August 9, 2024
 - [https://www.youtube.com/watch?v=J2SvnnVBDk0](https://www.youtube.com/watch?v=J2SvnnVBDk0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-08-10T03:18:27+00:00

Get your game on! Check out the MSI MAG X670E TOMAHAWK WIFI Motherboard at https://lmg.gg/sXyzQ

Build your business the website it deserves! Visit https://www.squarespace.com/WAN and use offer code WAN for 10% off

Keep your precious files safe! Get a 15-day free trial for unlimited backup at https://www.backblaze.com/landing/podcast-wan.html

Check out the Secretlab Titan Evo Ergonomic Gaming chair and more at https://lmg.gg/secretlabwan

Get a special deal on Private Internet Access VPN today at https://www.piavpn.com/LinusWan

The Special Edition of the DeltaHub x LTT Carpio 2.0 Wrist Rest is now live! There’s only 2000 units available so go check it out at: https://go.deltahub.io/carpio-ltt-edition-wanshow

Subscribe to Floatplane and get early access to ALL Scrapyard Wars releases this season, plus tons of extras and who knows, maybe we’ll be giving some stuff out there too. Join us over at https://lmg.gg/scrapwars24

Our Scrapyard Wars Episode 3 Giveaway is live now! Enter for 

