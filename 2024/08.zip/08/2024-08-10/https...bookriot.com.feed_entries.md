# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## All the News Book Riot Covered This Week
 - [https://bookriot.com/today-in-books-august-10-2024](https://bookriot.com/today-in-books-august-10-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-08-10T15:00:00+00:00

How to explain book bans 101, the most read books of the week on Goodreads, and more.

## Book Riot’s YA Book Deals of the Day for August 10, 2024
 - [https://bookriot.com/book-riots-ya-book-deals-of-the-day-for-august-10-2024](https://bookriot.com/book-riots-ya-book-deals-of-the-day-for-august-10-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-08-10T15:00:00+00:00

14 outstanding YA books you can grab for under $4 this weekend.

## Enter for a chance to win $1000 for a poolside retreat!
 - [https://bookriot.com/enter-for-a-chance-to-win-1000-for-a-poolside-retreat-3](https://bookriot.com/enter-for-a-chance-to-win-1000-for-a-poolside-retreat-3)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-08-10T15:00:00+00:00



## The Most Popular Stories of the Week
 - [https://bookriot.com/best-of-book-riot-august-10-2024](https://bookriot.com/best-of-book-riot-august-10-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-08-10T15:00:00+00:00

Utah's statewide book ban, the most read books of the week on Goodreads, compelling YA historical fantasy, and more.

## The Best Queer Romance Novels According to a Queer Book Professional
 - [https://bookriot.com/the-best-queer-romance-novels-according-to-a-queer-book-professional](https://bookriot.com/the-best-queer-romance-novels-according-to-a-queer-book-professional)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-08-10T14:00:00+00:00

What's your favorite queer romance novel?

## Book Riot’s Deals of the Day for August 10, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-august-10-2024](https://bookriot.com/book-riots-deals-of-the-day-for-august-10-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-08-10T13:00:00+00:00

A Golden Girl Memoir, a Healing Coming-of-Age Novel, Young Love in a Bookstore, a Middle Eastern Romantasy, and More in Today's Best Book Deals

