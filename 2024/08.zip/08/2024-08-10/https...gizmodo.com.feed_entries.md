# Source:Gizmodo, URL:https://gizmodo.com/feed, language:en

## FDA Holds Back MDMA Psychedelic Therapy Over Safety, Efficacy Concerns
 - [https://gizmodo.com/fda-holds-back-mdma-psychedelic-therapy-over-safety-efficacy-concerns-2000485535](https://gizmodo.com/fda-holds-back-mdma-psychedelic-therapy-over-safety-efficacy-concerns-2000485535)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T19:34:35+00:00

<p><img alt="A close-up of the United States Food and Drug" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/fda-rejects-mdma-treatment-lykos.jpg" width="1500" /></p>Lykos, the developer of the MDMA-assisted therapy for PTSD, called the FDA's request for more phase 3 research "deeply disappointing."

## Pacific Rim Wants to End Its Saga as Kickstarter Graphic Novels
 - [https://gizmodo.com/pacific-rim-final-breach-graphic-novel-kickstarter-2000484522](https://gizmodo.com/pacific-rim-final-breach-graphic-novel-kickstarter-2000484522)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T19:15:02+00:00

<p><img alt="Pacific Rim2" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/pacific-rim2.jpg" width="1500" /></p>Legendary is canceling the apocalypse one last time in a crowdfunded trilogy of comics, and hopes you want to help make it happen.

## The Batman Is Coming Back to Theaters
 - [https://gizmodo.com/the-batman-re-release-penguin-preview-2000484519](https://gizmodo.com/the-batman-re-release-penguin-preview-2000484519)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T17:20:11+00:00

<p><img alt="Pattinson The Batman" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/pattinson-the-batman.jpg" width="1500" /></p>WB is bringing one of its best superhero films in years back to the big screen, and a look at <i>The Penguin</i> along for the ride.

## Percy Jackson Sets Sail For a Perilous Season 2
 - [https://gizmodo.com/percy-jackson-season-2-d23-teaser-2000485522](https://gizmodo.com/percy-jackson-season-2-d23-teaser-2000485522)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T16:55:45+00:00

<p><img alt="Percy Jackson" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/percy-jackson.jpg" width="1500" /></p>Disney+'s adaptation of the Rick Riordan books will return in 2025, and it's taking Percy and friends to the Bermuda Triangle.

## Daredevil: Born Again Season 2 Is a Go as New Season 1 Footage Debuts
 - [https://gizmodo.com/daredevil-born-again-season-2-trailer-footage-charlie-cox-2000485495](https://gizmodo.com/daredevil-born-again-season-2-trailer-footage-charlie-cox-2000485495)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T16:20:50+00:00

<p><img alt="Daredevil Cast D23" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/Daredevil-cast-d23.jpg" width="1500" /></p>Charlie Cox, Jon Bernthal, Deborah Ann Woll, Elden Henson, and Vincent D'Onofrio were at D23 2024 to share footage from Marvel's return to <i>Daredevil</i>.

## M3GAN’s Soulm8te Spinoff Has Found Its Android Star
 - [https://gizmodo.com/soulm8te-lily-sullivan-m3gan-spinoff-2000485353](https://gizmodo.com/soulm8te-lily-sullivan-m3gan-spinoff-2000485353)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T15:35:55+00:00

<p><img alt="M3gan Blumhouse" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/m3gan-blumhouse.jpg" width="1500" /></p>While M3GAN gets up to her old tricks in 2025, Lily Sullivan will add some erotic terror to Blumhouse's new franchise.

## Tron: Ares Has Music By Nine Inch Nails, and We Saw the First Footage
 - [https://gizmodo.com/tron-ares-d23-trailer-footage-description-nine-inch-nails-2000485488](https://gizmodo.com/tron-ares-d23-trailer-footage-description-nine-inch-nails-2000485488)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T14:30:50+00:00

<p><img alt="Tron Ares D23" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/Tron-Ares-D23.jpg" width="1500" /></p>Jared Leto, Greta Lee, Evan Peters, and Jeff Bridges debuted the new <i>Tron</i> film at D23 2024.

## Behold, Your New, Live-Action Stitch
 - [https://gizmodo.com/lilo-stitch-remake-first-look-d23-2000485451](https://gizmodo.com/lilo-stitch-remake-first-look-d23-2000485451)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T13:45:31+00:00

<p><img alt="Stitch Live Action" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/stitch-live-action.jpg" width="1500" /></p>Heyyyyy, we finally get a look at the Lilo &amp; Stitch remake and Stitch himself looks surprisingly not half bad.

## Reminder: Don’t Go Roaming Overseas
 - [https://gizmodo.com/reminder-dont-go-roaming-overseas-2000485338](https://gizmodo.com/reminder-dont-go-roaming-overseas-2000485338)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T12:00:29+00:00

<p><img alt="A photo of a toggle for Roaming Charges" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/Roaming-Charges.jpg" width="1500" /></p>Buying an all-inclusive SIM to travel overseas is a better value than letting your U.S. carrier do the roaming for you.

## How (and When) to Use Gemini AI in Gmail and Google Docs
 - [https://gizmodo.com/how-and-when-to-use-gemini-ai-in-gmail-and-google-docs-2000484837](https://gizmodo.com/how-and-when-to-use-gemini-ai-in-gmail-and-google-docs-2000484837)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T10:00:52+00:00

<p><img alt="Gemini in Gmail" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/00-hero-e1723232100144.jpg" width="1500" /></p>Here's where Google's Gemini-powered writing assistance pops up and how you can best use it.

## Mufasa: The Lion King Shares a Sweeping New Trailer
 - [https://gizmodo.com/mufasa-the-lion-king-shares-a-sweeping-new-trailer-2000485319](https://gizmodo.com/mufasa-the-lion-king-shares-a-sweeping-new-trailer-2000485319)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T05:04:39+00:00

<p><img alt="Disney Lion King Mufasa" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/disney-lion-king-mufasa.jpg" width="1500" /></p>Barry Jenkins' live action-meets-CGI prequel to the 2019 smash hit—itself a remake of the 1994 animated classic—hits theaters in December.

## The First Teaser for Disney’s Live-Action Snow White Makes a Song and Dance of It
 - [https://gizmodo.com/snow-white-live-action-trailer-disney-rachel-zegler-gal-gadot-2000485476](https://gizmodo.com/snow-white-live-action-trailer-disney-rachel-zegler-gal-gadot-2000485476)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T04:53:39+00:00

<p><img alt="Disney Snow White Rachel Zegler" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/Disney-Snow-White-Rachel-Zegler.jpg" width="1500" /></p>Starring Rachel Zegler as Snow White and Gal Gadot as the Evil Queen, Disney's latest live-action remake hits theaters March 2025.

## The First Footage From The Mandalorian & Grogu Is As Cold As Ice
 - [https://gizmodo.com/mandalorian-and-grogu-d23-footage-description-disney-star-wars-2000485454](https://gizmodo.com/mandalorian-and-grogu-d23-footage-description-disney-star-wars-2000485454)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T04:29:57+00:00

<p><img alt="Mandalorian Season 3 Star Wars Grogu" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/Mandalorian-Season-3-Star-Wars-Grogu.jpg" width="1500" /></p>The first <i>Star Wars</i> movie since <i>The Rise of Skywalker</i> hits theaters May 22, 2026.

## Agatha All Along Reveals a Suitably Bewitching New Trailer
 - [https://gizmodo.com/sdcc-2024-agatha-all-along-trailer-marvel-disney-plus-2000477049](https://gizmodo.com/sdcc-2024-agatha-all-along-trailer-marvel-disney-plus-2000477049)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T04:02:41+00:00

<p><img alt="Agatha All Along Cast" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/07/Agatha_All_Along_cast.jpg" width="1500" /></p>Marvel's <i>WandaVision</i> spin-off starring Kathryn Hahn as Agatha Harkness hits Disney+ September 18.

## Andor Confirms the Return of an Old Friend for Season 2
 - [https://gizmodo.com/andor-season-2-k-2so-star-wars-alan-tudyk-disney-plus-2000485330](https://gizmodo.com/andor-season-2-k-2so-star-wars-alan-tudyk-disney-plus-2000485330)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T03:37:00+00:00

<p><img alt="Star Wars Rogue One Cassian And K2" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/star-wars-rogue-one-cassian-and-k2.jpg" width="1500" /></p>Alan Tudyk will return as <i>Rogue One</i>'s heroically acerbic droid K-2SO when <i>Andor</i> season 2 hits Disney+ next year.

## Star Wars: Skeleton Crew‘s First Trailer Unleashes a Galactic Adventure
 - [https://gizmodo.com/star-wars-skeleton-crew-trailer-release-date-disney-plus-2000485277](https://gizmodo.com/star-wars-skeleton-crew-trailer-release-date-disney-plus-2000485277)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T03:25:29+00:00

<p><img alt="Star Wars Skeleton Crew First Look Jude Law" class="attachment-full size-full wp-post-image" height="1281" src="https://gizmodo.com/app/uploads/2024/07/star-wars-skeleton-crew-first-look-jude-law-1.jpg" width="1920" /></p>The next live-action <i>Star Wars</i> series, starring Jude Law, hits Disney+ December 3.

## Pixar Is Making Incredibles 3
 - [https://gizmodo.com/incredibles-3-pixar-disney-announcement-release-date-2000485438](https://gizmodo.com/incredibles-3-pixar-disney-announcement-release-date-2000485438)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T03:09:04+00:00

<p><img alt="Incredibles 2" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/incredibles-2.jpg" width="1500" /></p>Brad Bird is returning to the world of superheroes for a new <i>Incredibles</i> movie.

## Avatar 3 Is Now Officially Avatar: Fire and Ash
 - [https://gizmodo.com/avatar-3-title-fire-and-ash-james-cameron-2000485224](https://gizmodo.com/avatar-3-title-fire-and-ash-james-cameron-2000485224)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T02:44:11+00:00

<p><img alt="Avatar The Way Of Water" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/avatar_the_way_of_water.jpg" width="1500" /></p>The third film in the trilogy follows smash hits <i>Avatar</i> and <i>Avatar: The Way of Water</i>, and arrives in December 2025.

## Moana 2 Crashes Into D23 With a New Trailer
 - [https://gizmodo.com/moana-2-disney-d23-trailer-2000485441](https://gizmodo.com/moana-2-disney-d23-trailer-2000485441)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-08-10T02:41:20+00:00

<p><img alt="Moana 2 Moana Maui" class="attachment-full size-full wp-post-image" height="1000" src="https://gizmodo.com/app/uploads/2024/08/moana-2-moana-maui.jpg" width="1500" /></p>Adventure! The ocean! Evil coconuts! The new D23 trailer for Moana 2's got all that and more, folks!

