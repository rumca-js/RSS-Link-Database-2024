# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Elon Musk’s embrace of Trump is turning off these Tesla lovers
 - [https://www.washingtonpost.com/technology/2024/08/10/musk-tesla-trump-fans](https://www.washingtonpost.com/technology/2024/08/10/musk-tesla-trump-fans)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-08-10T11:00:00+00:00

The entrepreneur’s provocative online posts repel some EV buyers, but he may be winning over some conservatives, analysts and consumers say.

## The friendliest social network you’ve never heard of
 - [https://www.washingtonpost.com/technology/2024/08/10/front-porch-forum-vermont-research-new-public](https://www.washingtonpost.com/technology/2024/08/10/front-porch-forum-vermont-research-new-public)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-08-10T10:05:00+00:00

On Front Porch Forum, politics is fair game but unkindness is strictly prohibited.

