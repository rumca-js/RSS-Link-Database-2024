# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## Indian airline tests feature that lets women book seats away from men
 - [https://www.reddit.com/r/news/comments/1ep53gi/indian_airline_tests_feature_that_lets_women_book](https://www.reddit.com/r/news/comments/1ep53gi/indian_airline_tests_feature_that_lets_women_book)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T22:25:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Silent-Resort-3076"> /u/Silent-Resort-3076 </a> <br /> <span><a href="https://www.cbsnews.com/news/indigo-tests-feature-that-lets-women-book-seats-away-from-men/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ep53gi/indian_airline_tests_feature_that_lets_women_book/">[comments]</a></span>

## Algerian boxer Imane Khelif, at centre of Olympics gender row, files legal complaint over online harassment
 - [https://www.reddit.com/r/news/comments/1ep4dh2/algerian_boxer_imane_khelif_at_centre_of_olympics](https://www.reddit.com/r/news/comments/1ep4dh2/algerian_boxer_imane_khelif_at_centre_of_olympics)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T21:51:37+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/CrispyMiner"> /u/CrispyMiner </a> <br /> <span><a href="https://news.sky.com/story/algerian-boxer-imane-khelif-at-centre-of-olympic-gender-row-files-legal-complaint-over-online-harassment-13195264">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ep4dh2/algerian_boxer_imane_khelif_at_centre_of_olympics/">[comments]</a></span>

## Steph Curry dazzles again as USA beat France for gold in men’s basketball final
 - [https://www.reddit.com/r/news/comments/1ep3oyk/steph_curry_dazzles_again_as_usa_beat_france_for](https://www.reddit.com/r/news/comments/1ep3oyk/steph_curry_dazzles_again_as_usa_beat_france_for)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T21:20:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/SkillImmediate6393"> /u/SkillImmediate6393 </a> <br /> <span><a href="https://www.theguardian.com/sport/article/2024/aug/10/usa-france-mens-basketball-final-olympics-paris-2024-result">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ep3oyk/steph_curry_dazzles_again_as_usa_beat_france_for/">[comments]</a></span>

## Judge in Maryland rules Baltimore ‘baby bonus’ proposal is unconstitutional
 - [https://www.reddit.com/r/news/comments/1ep28l9/judge_in_maryland_rules_baltimore_baby_bonus](https://www.reddit.com/r/news/comments/1ep28l9/judge_in_maryland_rules_baltimore_baby_bonus)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T20:13:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/WhileFalseRepeat"> /u/WhileFalseRepeat </a> <br /> <span><a href="https://apnews.com/article/baltimore-baby-bonus-lawsuit-ed948a9eb6d994bc5c0465f4910f03c2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ep28l9/judge_in_maryland_rules_baltimore_baby_bonus/">[comments]</a></span>

## CAS voids inquiry that led to Jordan Chiles' Olympic bronze
 - [https://www.reddit.com/r/news/comments/1ep18gh/cas_voids_inquiry_that_led_to_jordan_chiles](https://www.reddit.com/r/news/comments/1ep18gh/cas_voids_inquiry_that_led_to_jordan_chiles)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T19:28:22+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/lala_b11"> /u/lala_b11 </a> <br /> <span><a href="https://abcnews.go.com/Sports/cas-voids-inquiry-led-jordan-chiles-olympic-bronze/story?id=112745591">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ep18gh/cas_voids_inquiry_that_led_to_jordan_chiles/">[comments]</a></span>

## Court of Arbitration Renders Decision on Floor Finals Regarding Jordan Chiles' Score
 - [https://www.reddit.com/r/news/comments/1ep0qpb/court_of_arbitration_renders_decision_on_floor](https://www.reddit.com/r/news/comments/1ep0qpb/court_of_arbitration_renders_decision_on_floor)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T19:05:39+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/3vo1utionhyenna"> /u/3vo1utionhyenna </a> <br /> <span><a href="https://www.tas-cas.org/fileadmin/user_upload/CAS_Media_Release_ParisOG_15-16.pdf">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ep0qpb/court_of_arbitration_renders_decision_on_floor/">[comments]</a></span>

## Uvalde shooter’s uncle begged police to let him talk to the gunman
 - [https://www.reddit.com/r/news/comments/1ep09ys/uvalde_shooters_uncle_begged_police_to_let_him](https://www.reddit.com/r/news/comments/1ep09ys/uvalde_shooters_uncle_begged_police_to_let_him)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T18:45:04+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Tuna_Sushi"> /u/Tuna_Sushi </a> <br /> <span><a href="https://www.nbcnews.com/news/us-news/uvalde-school-massacre-videos-911-calls-released-rcna166091">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ep09ys/uvalde_shooters_uncle_begged_police_to_let_him/">[comments]</a></span>

## Medical examiner determines dead woman found entangled in O'Hare baggage machinery died by suicide
 - [https://www.reddit.com/r/news/comments/1eotxb1/medical_examiner_determines_dead_woman_found](https://www.reddit.com/r/news/comments/1eotxb1/medical_examiner_determines_dead_woman_found)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T14:09:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Big-Heron4763"> /u/Big-Heron4763 </a> <br /> <span><a href="https://apnews.com/article/woman-dead-baggage-entangled-chicago-ohare-80fe0d75d63c3b610e83c7f2da298c5f">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eotxb1/medical_examiner_determines_dead_woman_found/">[comments]</a></span>

## Texas orders hospitals to collect migrant data
 - [https://www.reddit.com/r/news/comments/1eoswid/texas_orders_hospitals_to_collect_migrant_data](https://www.reddit.com/r/news/comments/1eoswid/texas_orders_hospitals_to_collect_migrant_data)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T13:21:12+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://www.bbc.com/news/articles/cd6yv7231n1o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eoswid/texas_orders_hospitals_to_collect_migrant_data/">[comments]</a></span>

## Former YouTube CEO Susan Wojcicki dies, aged 56
 - [https://www.reddit.com/r/news/comments/1eoqzqm/former_youtube_ceo_susan_wojcicki_dies_aged_56](https://www.reddit.com/r/news/comments/1eoqzqm/former_youtube_ceo_susan_wojcicki_dies_aged_56)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T11:40:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/cardscook77"> /u/cardscook77 </a> <br /> <span><a href="https://www.theguardian.com/technology/article/2024/aug/10/former-youtube-ceo-susan-wojcick-dies-aged-56">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eoqzqm/former_youtube_ceo_susan_wojcicki_dies_aged_56/">[comments]</a></span>

## Dog scheduled for teeth cleaning was spayed by vet instead, owner says
 - [https://www.reddit.com/r/news/comments/1eopasx/dog_scheduled_for_teeth_cleaning_was_spayed_by](https://www.reddit.com/r/news/comments/1eopasx/dog_scheduled_for_teeth_cleaning_was_spayed_by)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T09:52:11+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Silent-Resort-3076"> /u/Silent-Resort-3076 </a> <br /> <span><a href="https://www.nbcchicago.com/news/local/dog-scheduled-for-teeth-cleaning-was-spayed-by-chicago-vet-instead-owner-says/3515251/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eopasx/dog_scheduled_for_teeth_cleaning_was_spayed_by/">[comments]</a></span>

## US releases $3.5 billion to Israel to spend on US weapons and military equipment.
 - [https://www.reddit.com/r/news/comments/1eojn3f/us_releases_35_billion_to_israel_to_spend_on_us](https://www.reddit.com/r/news/comments/1eojn3f/us_releases_35_billion_to_israel_to_spend_on_us)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T03:50:32+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Stevogangstar"> /u/Stevogangstar </a> <br /> <span><a href="https://wtvbam.com/2024/08/09/us-releases-3-5-billion-to-israel-to-spend-on-us-weapons-military-equipment-cnn-reports/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eojn3f/us_releases_35_billion_to_israel_to_spend_on_us/">[comments]</a></span>

## Tourist is caught carving initials into 2,000-year-old home at Pompeii
 - [https://www.reddit.com/r/news/comments/1eofucw/tourist_is_caught_carving_initials_into](https://www.reddit.com/r/news/comments/1eofucw/tourist_is_caught_carving_initials_into)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T00:35:20+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Warcraft_Fan"> /u/Warcraft_Fan </a> <br /> <span><a href="https://www.cnn.com/2024/08/09/travel/tourist-caught-carving-initials-pompeii/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eofucw/tourist_is_caught_carving_initials_into/">[comments]</a></span>

## Meta beats censorship lawsuit by RFK Jr's anti-vaccine group
 - [https://www.reddit.com/r/news/comments/1eofhn4/meta_beats_censorship_lawsuit_by_rfk_jrs](https://www.reddit.com/r/news/comments/1eofhn4/meta_beats_censorship_lawsuit_by_rfk_jrs)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T00:18:02+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://www.reuters.com/legal/meta-beats-censorship-lawsuit-by-rfk-jrs-anti-vaccine-group-2024-08-09/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eofhn4/meta_beats_censorship_lawsuit_by_rfk_jrs/">[comments]</a></span>

## Bodycam video shows Baltimore officers opening fire on fleeing teen moments after seeing his gun
 - [https://www.reddit.com/r/news/comments/1eofgra/bodycam_video_shows_baltimore_officers_opening](https://www.reddit.com/r/news/comments/1eofgra/bodycam_video_shows_baltimore_officers_opening)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-08-10T00:16:50+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Entropologic"> /u/Entropologic </a> <br /> <span><a href="https://apnews.com/article/baltimore-police-shooting-william-gardner-bodycam-22dd3efccbc372d635aaaee21c79b77d">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1eofgra/bodycam_video_shows_baltimore_officers_opening/">[comments]</a></span>

