# Source:Science News, URL:https://www.sciencenews.org/feed, language:en-US

## Of frogs and the people who love them
 - [https://www.sciencenews.org/article/of-frogs-and-the-people-who-love-them](https://www.sciencenews.org/article/of-frogs-and-the-people-who-love-them)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-08-10T11:00:00+00:00

Editor in chief Nancy Shute discusses frogs and chytrid fungus, trilobite fossils and a dinosaur named after the Norse god of mischief.

## Readers ponder sign language in ancient humans, looped universe
 - [https://www.sciencenews.org/article/sign-language-ancient-humans-universe](https://www.sciencenews.org/article/sign-language-ancient-humans-universe)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-08-10T11:00:00+00:00

A sign of our past? Deaf experimental psychologist Rain Bosworth has found that babies have an intrinsic ability to recognize sign language, Meghan Rosen reported in “Primed to sign” (SN: 4/26/24). Reader Suzanne Lijek wondered if our innate sensitivity to sign language could stem from its use by ancient humans. Our ancestors probably communicated through [&#8230;]

