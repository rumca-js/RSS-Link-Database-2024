# Source:The Hill News, URL:https://thehill.com/feed, language:en-US

## Los Angeles mayor says 2028 Olympic games will be car-free
 - [https://thehill.com/homenews/state-watch/4822378-los-angeles-mayor-2028-olympics-car-free](https://thehill.com/homenews/state-watch/4822378-los-angeles-mayor-2028-olympics-car-free)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T23:44:44+00:00



## Uvalde officials release bodycam footage from Robb Elementary shooting
 - [https://thehill.com/homenews/state-watch/4822360-uvalde-school-shooting-bodycam-footage-release](https://thehill.com/homenews/state-watch/4822360-uvalde-school-shooting-bodycam-footage-release)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T22:43:05+00:00



## Celine Dion hits Trump for using her music at Montana rally
 - [https://thehill.com/blogs/in-the-know/4822298-celine-dion-hits-trump-using-her-music-montana-rally](https://thehill.com/blogs/in-the-know/4822298-celine-dion-hits-trump-using-her-music-montana-rally)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T21:04:16+00:00



## Walz pick highlights partisan divisions on free school lunches
 - [https://thehill.com/homenews/campaign/4820875-universal-school-meals-partisan-divide](https://thehill.com/homenews/campaign/4820875-universal-school-meals-partisan-divide)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T21:00:00+00:00



## Trump campaign says its internal communications were hacked
 - [https://thehill.com/homenews/campaign/4822252-trump-campaign-internal-communications-hacked](https://thehill.com/homenews/campaign/4822252-trump-campaign-internal-communications-hacked)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T20:17:25+00:00



## Sunday shows preview: Trump-Harris showdown heats up
 - [https://thehill.com/homenews/sunday-talk-shows/4822214-sunday-shows-preview-trump-harris-showdown-heats-up](https://thehill.com/homenews/sunday-talk-shows/4822214-sunday-shows-preview-trump-harris-showdown-heats-up)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T19:37:34+00:00



## Buttigieg says Trump’s attacks on Walz are ‘pretty mushy and lazy’
 - [https://thehill.com/homenews/campaign/4822213-buttigieg-trumps-attacks-walz](https://thehill.com/homenews/campaign/4822213-buttigieg-trumps-attacks-walz)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T19:29:16+00:00



## Former California legislator suggests Trump mixed up Black men in helicopter story
 - [https://thehill.com/homenews/campaign/4822198-former-california-legislator-suggests-trump-mixed-up-black-men-helicopter-story](https://thehill.com/homenews/campaign/4822198-former-california-legislator-suggests-trump-mixed-up-black-men-helicopter-story)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T19:19:05+00:00



## White House: Deadly strike on Gaza school ‘underscores urgency’ for cease-fire
 - [https://thehill.com/policy/international/4822139-white-house-deadly-strike-gaza-school-cease-fire](https://thehill.com/policy/international/4822139-white-house-deadly-strike-gaza-school-cease-fire)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T18:38:15+00:00



## Pelosi calls Trump’s attacks on Harris’s IQ ‘pathetic’
 - [https://thehill.com/homenews/house/4822156-pelosi-trumps-attacks-harriss-iq-pathetic](https://thehill.com/homenews/house/4822156-pelosi-trumps-attacks-harriss-iq-pathetic)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T18:30:01+00:00



## Susan Wojcicki, former YouTube CEO, dead at 56
 - [https://thehill.com/policy/technology/4822101-susan-wojcicki-former-youtube-ceo-dead-at-56](https://thehill.com/policy/technology/4822101-susan-wojcicki-former-youtube-ceo-dead-at-56)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T18:13:53+00:00



## Relief funds eased COVID learning loss but could have done more
 - [https://thehill.com/opinion/education/4818888-federal-funds-learning-loss-recovery](https://thehill.com/opinion/education/4818888-federal-funds-learning-loss-recovery)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T18:00:00+00:00



## Harris campaign: Walz ‘misspoke’ on handling weapons ‘in war’
 - [https://thehill.com/homenews/campaign/4822064-kamala-harris-tim-walz-military-record-misspoke-war](https://thehill.com/homenews/campaign/4822064-kamala-harris-tim-walz-military-record-misspoke-war)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T17:49:46+00:00



## Stellantis to shed more than 2,400 workers over discontinued Ram truck
 - [https://thehill.com/business/4822065-jeep-maker-stellantis-announces-2450-layoffs](https://thehill.com/business/4822065-jeep-maker-stellantis-announces-2450-layoffs)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T17:10:28+00:00



## Why a policy of targeted assassination is doomed to fail
 - [https://thehill.com/opinion/international/4820686-why-a-policy-of-targeted-assassination-is-doomed-to-fail](https://thehill.com/opinion/international/4820686-why-a-policy-of-targeted-assassination-is-doomed-to-fail)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T17:00:00+00:00



## Ex-Trump defense chief urges Walz to clarify military record amid scrutiny
 - [https://thehill.com/homenews/campaign/4822007-former-defense-secretary-mark-esper-tim-walz-military-record](https://thehill.com/homenews/campaign/4822007-former-defense-secretary-mark-esper-tim-walz-military-record)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T16:27:04+00:00



## Trump stokes fears with ‘unconstitutional’ Harris talk
 - [https://thehill.com/homenews/campaign/4821089-donald-trump-kamala-harris-unconstitutional](https://thehill.com/homenews/campaign/4821089-donald-trump-kamala-harris-unconstitutional)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T16:00:00+00:00



## Why RFK Jr. should lead the investigation of the Trump assassination attempt
 - [https://thehill.com/opinion/campaign/4820797-why-rfk-jr-should-lead-the-investigation-of-the-trump-assassination-attempt](https://thehill.com/opinion/campaign/4820797-why-rfk-jr-should-lead-the-investigation-of-the-trump-assassination-attempt)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T16:00:00+00:00



## Beto O’Rourke champions Harris-Walz ticket: ‘Instead of hatred, there is hope’
 - [https://thehill.com/homenews/campaign/4821941-beto-orourke-kamala-harris-tim-walz-campaign-2024](https://thehill.com/homenews/campaign/4821941-beto-orourke-kamala-harris-tim-walz-campaign-2024)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T15:44:52+00:00



## RFK Jr. slams ‘monolithic media’ over lack of air time
 - [https://thehill.com/homenews/campaign/4821947-rfk-jr-monolithic-media-coverage-2024](https://thehill.com/homenews/campaign/4821947-rfk-jr-monolithic-media-coverage-2024)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T15:29:09+00:00



## Sonya Massey’s killing demands better policing, not less police
 - [https://thehill.com/opinion/criminal-justice/4818960-police-community-trust-shooting](https://thehill.com/opinion/criminal-justice/4818960-police-community-trust-shooting)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T15:00:00+00:00



## Trump hits NYT while doubling down on near-crash helicopter story
 - [https://thehill.com/homenews/media/4821889-donald-trump-new-york-times-willie-brown-helicopter-story](https://thehill.com/homenews/media/4821889-donald-trump-new-york-times-willie-brown-helicopter-story)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T14:41:57+00:00



## A Harris-Walz administration would be a nightmare for free speech
 - [https://thehill.com/opinion/civil-rights/4820490-harris-walz-administration-free-speech](https://thehill.com/opinion/civil-rights/4820490-harris-walz-administration-free-speech)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T14:30:00+00:00



## Israeli airstrike on Gaza school used for shelter kills at least 80
 - [https://thehill.com/policy/international/4821880-israeli-airstrike-gaza-schools-deadly](https://thehill.com/policy/international/4821880-israeli-airstrike-gaza-schools-deadly)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T14:06:49+00:00



## It’s time for Biden to stop the mass collection of travelers’ social media information
 - [https://thehill.com/opinion/4820492-biden-ends-surveillance-state](https://thehill.com/opinion/4820492-biden-ends-surveillance-state)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T14:00:00+00:00



## Trump trails Harris by 4 points in 3 key swing states: Poll
 - [https://thehill.com/homenews/campaign/4821835-donald-trump-kamala-harris-swing-states-nyt-poll](https://thehill.com/homenews/campaign/4821835-donald-trump-kamala-harris-swing-states-nyt-poll)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T13:38:24+00:00



## Sununu says age no longer a factor in 2024 election
 - [https://thehill.com/homenews/campaign/4821814-chris-sununu-donald-trump-kamala-harris-2024-election](https://thehill.com/homenews/campaign/4821814-chris-sununu-donald-trump-kamala-harris-2024-election)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T13:07:09+00:00



## Harris’s press avoidance strategy is un-American, and it’s working just fine.
 - [https://thehill.com/opinion/campaign/4820576-harris-campaign-media-avoidance](https://thehill.com/opinion/campaign/4820576-harris-campaign-media-avoidance)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T13:00:00+00:00



## Trump in Montana blasts Walz as ‘freakish’
 - [https://thehill.com/homenews/campaign/4821777-donald-trump-tim-walz-kamala-harris-montana-rally](https://thehill.com/homenews/campaign/4821777-donald-trump-tim-walz-kamala-harris-montana-rally)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T12:12:33+00:00



## How the Constitution’s 25th Amendment helped the nation move beyond Watergate
 - [https://thehill.com/opinion/congress-blog/4821496-25th-amendment-role-nixon-resignation](https://thehill.com/opinion/congress-blog/4821496-25th-amendment-role-nixon-resignation)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T12:00:00+00:00



## Harris walks perilous line between viral and ‘cringe’
 - [https://thehill.com/homenews/campaign/4819006-harris-campaign-digital-strategy](https://thehill.com/homenews/campaign/4819006-harris-campaign-digital-strategy)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T10:00:00+00:00



## RFK Jr. and third parties could pose danger for Trump, polling suggests
 - [https://thehill.com/homenews/campaign/4821389-donald-trump-rfk-jr-kamala-harris](https://thehill.com/homenews/campaign/4821389-donald-trump-rfk-jr-kamala-harris)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T10:00:00+00:00



## Ukraine’s surprise attack into Russia ups ante for Putin
 - [https://thehill.com/policy/defense/4821208-ukraines-surprise-attack-into-russia-ups-ante-for-putin](https://thehill.com/policy/defense/4821208-ukraines-surprise-attack-into-russia-ups-ante-for-putin)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T10:00:00+00:00



## Trump slams Tester’s record in Congress, calls him a ‘radical left lunatic’ at Montana rally
 - [https://thehill.com/homenews/campaign/4821726-trum-tester-radical-left-lunatic-montana-rally](https://thehill.com/homenews/campaign/4821726-trum-tester-radical-left-lunatic-montana-rally)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T06:44:30+00:00



## Biden says ‘most important thing’ is to ‘defeat Trump’
 - [https://thehill.com/homenews/administration/4821647-biden-says-most-important-thing-defeat-trump](https://thehill.com/homenews/administration/4821647-biden-says-most-important-thing-defeat-trump)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T03:08:13+00:00



## RFK Jr. claims he will be on the ballot in all 50 states
 - [https://thehill.com/homenews/campaign/4821626-rfk-jr-claims-ballot-all-50-states](https://thehill.com/homenews/campaign/4821626-rfk-jr-claims-ballot-all-50-states)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T03:04:47+00:00



## Michigan Senate hopefuls Slotkin, Rogers say they were targeted in swatting incident
 - [https://thehill.com/homenews/campaign/4821600-michigan-slotkin-rogers-targeted-swatting-incident](https://thehill.com/homenews/campaign/4821600-michigan-slotkin-rogers-targeted-swatting-incident)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T02:13:57+00:00



## Harris tells Gaza protesters ‘now is the time’ for cease-fire deal
 - [https://thehill.com/homenews/campaign/4821594-harris-gaza-protesters-cease-fire-deal](https://thehill.com/homenews/campaign/4821594-harris-gaza-protesters-cease-fire-deal)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T01:42:26+00:00



## Walz mocks Trump over crowd size at Arizona rally
 - [https://thehill.com/homenews/campaign/4821586-walz-mocks-trump-crowd-size-arizona-rally](https://thehill.com/homenews/campaign/4821586-walz-mocks-trump-crowd-size-arizona-rally)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T01:24:27+00:00



## Watch live: Trump speaks at campaign event in Montana
 - [https://thehill.com/homenews/4820513-watch-live-trump-speaks-at-campaign-event-in-montana](https://thehill.com/homenews/4820513-watch-live-trump-speaks-at-campaign-event-in-montana)
 - RSS feed: https://thehill.com/feed
 - date published: 2024-08-10T01:00:00+00:00



