# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Why the Army's feminized approach isn't helping
 - [https://www.youtube.com/watch?v=eOmnmma25gE](https://www.youtube.com/watch?v=eOmnmma25gE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-08-10T17:00:24+00:00



## Here Are Examples Of Real Anti-White Racism
 - [https://www.youtube.com/watch?v=PEO5YdSj_xU](https://www.youtube.com/watch?v=PEO5YdSj_xU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-08-10T15:00:21+00:00

PDS Debt - PDS Debt is offering a free debt analysis. It only takes thirty seconds. Get yours at https://PDSDebt.com/Walsh 

Anti-white racism is real and it's a growing problem. That is why my new movie 'Am I Racist?' is so important. Pre-sale tickets go on sale August 15th. Visit www.amiracist.com for more details.

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Humans were meant to have kids
 - [https://www.youtube.com/watch?v=BnF_G8_0bLY](https://www.youtube.com/watch?v=BnF_G8_0bLY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-08-10T05:00:12+00:00



## This journey goes places you won’t except.
 - [https://www.youtube.com/watch?v=WcXDl3vyQOc](https://www.youtube.com/watch?v=WcXDl3vyQOc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-08-10T01:00:14+00:00

Tickets for my new film “Am I Racist?” will be available for presale on August 15th.

## The Radical Left Is Using Gen Z Women As Pawns. Here's What We Should Do
 - [https://www.youtube.com/watch?v=nbhDDKcBsu4](https://www.youtube.com/watch?v=nbhDDKcBsu4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-08-10T00:00:23+00:00

Unmarried women are more liberal than they've ever been as the political gender divide grows deeper. Why is this happening? And what can we do about it?

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep. 1419 - https://bit.ly/4dAiAYP

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

