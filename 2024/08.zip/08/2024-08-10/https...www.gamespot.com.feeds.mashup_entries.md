# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## Firearms Expert Reacts to Hunt Showdown PART 3
 - [https://www.gamespot.com/videos/firearms-expert-reacts-to-hunt-showdown-part-3/2300-6464794](https://www.gamespot.com/videos/firearms-expert-reacts-to-hunt-showdown-part-3/2300-6464794)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T14:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4348267-fer_huntp3_v2_site.jpg" width="480" /> Jonathan Ferguson, a weapons expert and Keeper of Firearms &amp; Artillery at the Royal Armouries, breaks down a range of the historical monster-slaying weapons of Hunt: Showdown, including the Bomb Lance, the cut-down Obrez Mosin and the vaguely horrific Pennyshot.

## Pixar Announces Incredibles 3 At D23
 - [https://www.gamespot.com/articles/pixar-announces-incredibles-3-at-d23/1100-6525698/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/pixar-announces-incredibles-3-at-d23/1100-6525698/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T07:01:00+00:00

<p>This year marks the 20th anniversary of The Incredibles, director Brad Bird's ode to the Fantastic Four, James Bond, and more. In the two decades since then, only a single sequel--2018's Incredibles 2--has arrived. But at D23, Pixar confirmed that Incredibles 3 is in development, with Bird slated to direct as he has for the first two films.</p><p>Pixar's Pete Docter made the announcement at the very end of the studio's presentation, and he didn't offer any other details. Docter didn't even say if the film has a release date, but it was clearly well-received news at the show.</p><div><blockquote align="center" class="twitter-tweet"><p dir="ltr">‘Incredible 3’ coming soon! <a href="https://twitter.com/hashtag/D23?src=hash&amp;ref_src=twsrc^tfw">#D23</a> <a href="https://t.co/4ZaqQhCjGZ">pic.twitter.com/4ZaqQhCjGZ</a></p>  — Deadline Hollywood (@DEADLINE) <a href="https://twitter.com/DEADLINE/status/1822106975771181281?ref_src=twsrc^tfw">August 10, 2024</a></blockquote>              <

## New Trailer For Agatha All Along Walks The Witches' Road
 - [https://www.gamespot.com/articles/new-trailer-for-agatha-all-along-walks-the-witches-road/1100-6525697/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/new-trailer-for-agatha-all-along-walks-the-witches-road/1100-6525697/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T06:40:00+00:00

<p><a href="https://www.gamespot.com/reviews/wandavision-review-disney-kicks-off-mcu-phase-4-in-style/1900-6417630/">WandaVision</a> was the first Marvel Studios series on Disney+ in 2021, but it's taken the better part of three years to get back to Kathryn Hahn's witch, Agatha Harkness, after she was left powerless in the finale. But in the new trailer for <a href="https://www.gamespot.com/articles/agatha-all-along-gets-mysterious-and-scary-first-trailer/1100-6524757/">Agatha All Along</a>, Agatha has a plan to reclaim everything she lost and more... if her new coven can help her reach the end of the Witches' Road.</p><div>          </div><p>It seems like there's a high price for the power that Agatha wants, and she's perfectly willing to let her so-called friends and allies in the coven pay it before she does. There's no sign of Wanda Maximoff in this trailer, but it does appear that the show will offer an even deeper dive into the world of magic than we've seen before in the MCU. D

## Disney Reveals First Tron: Ares Footage At D23
 - [https://www.gamespot.com/articles/disney-reveals-first-tron-ares-footage-at-d23/1100-6525696/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/disney-reveals-first-tron-ares-footage-at-d23/1100-6525696/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T06:06:00+00:00

<p>It's been 42 years since Tron premiered in theaters, and 14 years since Tron: Legacy was released. The third installment, <a href="https://www.gamespot.com/articles/tron-3-gets-official-title-image-and-2025-release-date/1100-6521503/">Tron: Ares</a>, has been in the works for years. But at D23, Disney was finally ready to share the first look at the next chapter in the franchise. </p><p>Jared Leto plays the title character, Ares, a program who has come from the Grid and entered the real world. Leto was on hand for the preview alongside Greta Lee, Evan Peters, and original Tron star Jeff Bridges. Peters will be playing Julian Dillinger, a character who is presumably related to David Warner's Ed Dillinger from the first film. Cillian Murphy portrayed Dillinger's son, Edward Dillinger, Jr., in Tron: Legacy. </p><p>Peters' character was featured prominently in the preview as Dillinger gives a keynote speech about intelligent life coming and AI programs coming to our world. Bridges appe

## Ironheart's First Clips Premiere At D23
 - [https://www.gamespot.com/articles/ironhearts-first-clips-premiere-at-d23/1100-6525695/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/ironhearts-first-clips-premiere-at-d23/1100-6525695/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T05:45:00+00:00

<p>Ever since Disney announced plans to cut back on the number of Marvel shows heading to Disney+, the <a href="https://www.gamespot.com/reviews/black-panther-wakanda-forever-review-long-live-the-king/1900-6417996/">Black Panther: Wakanda Forever</a> spin-off series, <a href="https://www.gamespot.com/articles/marvels-ironheart-series-has-found-its-writer-report/1100-6490690/">Ironheart</a>, has been kind of on the backburner. But at D23, Marvel finally debuted some new footage of Dominique Thorne reprising her role as Riri Williams in her own show.</p><p>Marvel hasn't dropped any of the Ironheart clips online yet, but we can tell you that Riri is back at MIT, and she no longer has the same resources that she had in Wakanda Forever. Community's Jim Rash reappears as the Dean of MIT from Captain America: Civil War, and it seems like Riri may be expelled from the school.</p><p>More than anything else, Riri wants to rebuild her Ironheart armor. That's where Anthony Ramos' Parker Robbins c

## Marvel Debuts Daredevil: Born Again Trailer At D23
 - [https://www.gamespot.com/articles/marvel-debuts-daredevil-born-again-trailer-at-d23/1100-6525694/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/marvel-debuts-daredevil-born-again-trailer-at-d23/1100-6525694/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T05:13:00+00:00

<p>Speak the devil's name, and he shall appear. <a href="https://www.gamespot.com/articles/daredevil-born-agains-charlie-cox-explains-why-foggy-and-karen-had-to-come-back/1100-6523447/">Daredevil: Born Again</a> and the rest of Marvel's upcoming Disney+ original series were missing from <a href="https://www.gamespot.com/gallery/san-diego-comic-con-2024-biggest-news-announcements-trailers/2900-5626/">Comic-Con 2024</a>. But Marvel made it up to fans at D23 when the studio premiered the first trailer for Daredevil: Born Again. The footage hasn't been officially released online yet. But if these clips are any indication, fans of the first Daredevil series will be very happy.</p><p>The common theme in the trailer is that Daredevil is kicking a lot of ass. Matt Murdock is back, and he's a force of nature. A few familiar faces from the previous show are seen, including Karen, Foggy, and even Wilson Fisk, the Kingpin of crime. Daredevil Season 3 apparently hasn't been retconned, because Fisk

## Marvel Shares First Glimpse Of Human Torch's Costume In The Fantastic Four
 - [https://www.gamespot.com/articles/marvel-shares-first-glimpse-of-human-torchs-costume-in-the-fantastic-four/1100-6525693/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/marvel-shares-first-glimpse-of-human-torchs-costume-in-the-fantastic-four/1100-6525693/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T04:31:00+00:00

<p>Thanks to a hectic production schedule, <a href="https://www.gamespot.com/articles/marvels-fantastic-four-movie-receives-new-subtitle/1100-6525360/">The Fantastic Four: First Steps</a> didn't begin filming until July 29, the day after Comic-Con. That wasn't enough time to get a trailer together, but Marvel didn't come to D23 empty-handed. During the presentation for the Fantastic Four reboot, Marvel shared the first look at Joseph Quinn's Human Torch costume in the film.</p><div><blockquote align="center" class="twitter-tweet"><p dir="ltr">The first look at Joseph Quinn in costume as Johnny Storm in THE FANTASTIC FOUR: FIRST STEPS! <a href="https://t.co/q3fu922Gs5">pic.twitter.com/q3fu922Gs5</a></p>  — MCU - The Direct (@MCU_Direct) <a href="https://twitter.com/MCU_Direct/status/1822118263490277506?ref_src=twsrc^tfw">August 10, 2024</a></blockquote>              </div><p>As you can see from the pic, it's not an exact recreation of Johnny Storm's costume from the comics. It looks mo

## First The Mandalorian And Grogu Footage Revealed At D23
 - [https://www.gamespot.com/articles/first-the-mandalorian-and-grogu-footage-revealed-at-d23/1100-6525692/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/first-the-mandalorian-and-grogu-footage-revealed-at-d23/1100-6525692/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T04:04:00+00:00

<p>It's been almost five years since a Star Wars movie was in theaters, but that's going to change in 2026 when <a href="https://www.gamespot.com/articles/the-mandalorian-and-grogu-getting-a-big-screen-star-wars-movie/1100-6520197/">The Mandalorian &amp; Grogu</a> arrives just in time for the 49th anniversary of the franchise. At D23, fans discovered that the film has already started production, and the first footage was screened for the crowd.</p><p>Because the movie has only been shooting for a few weeks, there wasn't a lot to show off. Lucasfilm started with a flashback to the first meeting of Pedro Pascal's Din Djarin and Grogu from the first episode of The Mandalorian. From there, we saw a glimpse of their further adventures, which include going up against an AT-AT.</p><p>Grogu still leaves the shooting to his daddy, but they also spend some quiet time together to share some soup. Zeb from Star Wars Rebels briefly shows up as well. Additionally, Grogu was seen on a ship alongside

## Star Wars: Skeleton Crew Trailer Drops At D23 - Watch Now
 - [https://www.gamespot.com/articles/star-wars-skeleton-crew-trailer-drops-at-d23-watch-now/1100-6525691/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/star-wars-skeleton-crew-trailer-drops-at-d23-watch-now/1100-6525691/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T03:43:00+00:00

<p>Star Wars isn't sitting out of this year's D23, and Lucasfilm started off its presentation with a first look at the next Disney+ live-action series: <a href="https://www.gamespot.com/articles/star-wars-skeleton-crew-will-be-released-late-in-2024/1100-6523172/">Skeleton Crew</a>. Jude Law came out to the stage before the premiere of the new trailer for the show, which briefly teases his character, a Force user named Jod Na Nawood.</p><div>          </div><p>The show has been described as a homage to the Amblin sci-fi movies from the '80s, and that's definitely the vibe of the trailer. Four young children discover a starship hidden in the woods, and wind up stuck when it leaves their planet behind with no apparent way to get home. The series is about the kids' attempts to survive in the galaxy and reunite with their families. </p><p>Ravi Cabot-Conyers, Ryan Kiera Armstrong, Kyriana Kratter, and Robert Timothy Smith are playing the four kids at the heart of the show. Three of them app

## Toy Story 5 Story Details Revealed, Hits Theaters In 2026
 - [https://www.gamespot.com/articles/toy-story-5-story-details-revealed-hits-theaters-in-2026/1100-6525690/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/toy-story-5-story-details-revealed-hits-theaters-in-2026/1100-6525690/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T03:20:00+00:00

<p>Next year marks the 30th anniversary of Toy Story, the first fully CGI animated film that put Pixar on the map. And at D23, the next chapter of the franchise was officially unveiled. Toy Story 5 is coming to theaters in 2026, and Pixar veteran Andrew Stanton will be the director.</p><p>Stanton has been with Pixar since the first Toy Story, and he co-wrote all four of the previous films. He also co-directed A Bug's Life before going solo as the director on Finding Nemo, WALL-E, and Finding Dory.</p><p>After coming out on stage at D23, Stanton revealed the first promo artwork from Toy Story 5, which also teased the new threat facing the toys: Technology.</p><a href="https://www.gamespot.com/articles/toy-story-5-story-details-revealed-hits-theaters-in-2026/1100-6525690/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

## Avatar 3 Gets Official Title At D23
 - [https://www.gamespot.com/articles/avatar-3-gets-official-title-at-d23/1100-6525689/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/avatar-3-gets-official-title-at-d23/1100-6525689/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T02:57:00+00:00

<p><a href="https://www.gamespot.com/articles/avatar-3-will-introduce-evil-navi-james-cameron-says/1100-6510321/">Avatar 3</a> may have skipped <a href="https://www.gamespot.com/gallery/san-diego-comic-con-2024-biggest-news-announcements-trailers/2900-5626/">Comic-Con 2024</a>, but it's out in force for D23. Director James Cameron and stars Sam Worthington and Zoe Saldana took the stage to share the first details for Avatar 3, which now has an official name. It will be called Avatar: Fire and Ash.</p><p>Because the film is still too early in its post-production, there wasn't any new footage to show off. However, Cameron and company did show a sizzle reel of production art before revealing the title of the film.</p><div><blockquote align="center" class="twitter-tweet"><p dir="ltr">New <a href="https://twitter.com/hashtag/Avatar3?src=hash&amp;ref_src=twsrc^tfw">#Avatar3</a> concept art is shown along with a title reveal - <a href="https://twitter.com/hashtag/Avatar?src=hash&amp;ref_src=

## Adventure Time Fans Can Get 75 Comic Books For Only $18
 - [https://www.gamespot.com/articles/adventure-time-fans-can-get-75-comic-books-for-only-18/1100-6525651/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/adventure-time-fans-can-get-75-comic-books-for-only-18/1100-6525651/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T01:24:00+00:00

<div class="norewrite" title="6525651 - Adventure Time Preorder and Humble Bundle">    <div class="buylink__container">                                                                                                                                                                                               <div class="buylink__item">                  <div class="buylink__image-container clickable">                                            <img alt="" class="buylink__image" src="https://www.gamespot.com/a/uploads/square_avatar/1702/17023653/4347681-81mp3kuzbql._sl1500.jpg" />                                 <a href="https://www.amazon.com/Adventure-Time-Compendium-Vol-North/dp/1637155298?tag=gamespot-preorders-20"></a>                              </div>                   <div class="buylink__text">                      <p class="buylink__title text-bold">                        <a href="https://www.amazon.com/Adventure-Time-Compendium-Vol-North/dp/1637155298?tag=gamespot-preorders

## Lego Finally Releases Peppa Pig Duplos For Parents To Step On
 - [https://www.gamespot.com/articles/lego-finally-releases-peppa-pig-duplos-for-parents-to-step-on/1100-6525591/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/lego-finally-releases-peppa-pig-duplos-for-parents-to-step-on/1100-6525591/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-08-10T00:35:00+00:00

<p>Lego's Duplo line allows toddlers to build fun playsets out of bricks while parents <a href="https://www.gamespot.com/gallery/lego-darth-jar-jar-and-his-dark-falcon-ship-could-most-certainly-vaporize-the-death-star/2900-5630/">put together a parody of the Millennium Falcon featuring Darth Jar Jar</a>. With bright colors and easy-to-handle shapes, youngsters can snap together their very own Lego sets while also developing motor skills. <a href="https://clicks.trx-hub.com/xid/fandom_32094_gamespot?q=https://click.linksynergy.com/deeplink?id=VZfI20jEa0c&amp;mid=13923&amp;u1=subid_value&amp;murl=https://www.lego.com/en-us/themes/duplo&amp;p=http://www.gamespot.com/feeds/mashup/&amp;event_type=click">Duplo</a> has crossed over with a bunch of popular brands over the years, but its latest collaboration stars a true (toddler) icon: Peppa Pig. <a href="https://www.amazon.com/s?k=peppa pig duplo&amp;crid=2YAWD8CXI4ZYV&amp;sprefix=peppa pig duplo,aps,85&amp;ref=nb_sb_noss_1&amp;tag=gamespot-

