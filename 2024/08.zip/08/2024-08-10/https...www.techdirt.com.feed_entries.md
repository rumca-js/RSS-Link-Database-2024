# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## This Week In Techdirt History: August 4th – 10th
 - [https://www.techdirt.com/2024/08/10/this-week-in-techdirt-history-august-4th-10th](https://www.techdirt.com/2024/08/10/this-week-in-techdirt-history-august-4th-10th)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-08-10T18:57:00+00:00

Five Years Ago This week in 2019, &#8220;free speech defender&#8221; Devin Nunes filed more lawsuits against critics and vowed they weren&#8217;t the last, the New York Times joined the parade of media organizations that were totally and completely misrepresenting Section 230, and the recording industry was reaping what it sowed in the world of copyright [&#8230;]

## US Appeals Court Sends Dispute Between French Cognac Cartel And Music Label Back To USPTO
 - [https://www.techdirt.com/2024/08/09/us-appeals-court-sends-dispute-between-french-cognac-cartel-and-music-label-back-to-uspto](https://www.techdirt.com/2024/08/09/us-appeals-court-sends-dispute-between-french-cognac-cartel-and-music-label-back-to-uspto)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-08-10T02:39:00+00:00

You know, when you&#8217;ve written as much as I have about trademark disputes, there are times when you think you&#8217;ve seen everything, only to have the universe remind you that the depth of silliness around trademarks can always get deeper. The subject of today&#8217;s conversation is going to be a certification mark. While afforded similar [&#8230;]

