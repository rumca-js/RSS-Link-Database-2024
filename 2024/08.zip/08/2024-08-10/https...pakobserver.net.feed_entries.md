# Source:Pakistan Observer, URL:https://pakobserver.net/feed, language:en-US

## Apple iPhone 14 New Price in Pakistan with Azadi Deal
 - [https://pakobserver.net/apple-iphone-14-new-price-in-pakistan-with-azadi-deal](https://pakobserver.net/apple-iphone-14-new-price-in-pakistan-with-azadi-deal)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T17:35:26+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/Mazuma-Mobile_-The-iPhone-14-differences-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />As tech enthusiasts are closely looking at iPhone 16 launch, old Apple phones like iPhone 14 are still decent option if you are little on a budget. As Pakistan jacked up phone prices, and slapped new taxes; iPhone 14 is still solid choice as the device offers strong performance with A15 Bionic chip, a robust [&#8230;]

## New School Timings in Punjab announced starting August 15
 - [https://pakobserver.net/new-school-timings-in-punjab-announced-starting-august-15](https://pakobserver.net/new-school-timings-in-punjab-announced-starting-august-15)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T17:05:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/rwrwr-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; Summer vacations in schools across Punjab including the provincial capital Lahore are about to end from next week, and the government announced new school timings staring August 15, 2024. Punjab School Education Department announced schedule for new school hours starting August 15 when schools will resume after summer break. New School Timings in [&#8230;]

## After PM’s ouster, Bangladesh student protests force Pro-Hasina Judges to step down
 - [https://pakobserver.net/after-pms-ouster-bangladesh-student-protests-force-pro-hasina-judges-to-step-down](https://pakobserver.net/after-pms-ouster-bangladesh-student-protests-force-pro-hasina-judges-to-step-down)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T16:47:56+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/d2sd-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />DHAKA &#8211; Situation in Bangladesh remains tensed despite disgraced exit of Sheikh Hasina, as now Chief Justice Obaidul Hassan has resigned amid new protests at the Supreme Court. The protests, led by students and other demonstrators, demanded resignation of top judiciary officials, who according to them were part of Hasina&#8217;s autocratic rule. Chief Jusitce along with [&#8230;]

## KP CM announces 2KW Solar System via Ehsaas Program; Details inside
 - [https://pakobserver.net/kp-cm-announces-2kw-solar-system-via-ehsaas-program-details-inside](https://pakobserver.net/kp-cm-announces-2kw-solar-system-via-ehsaas-program-details-inside)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T16:21:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/fdfd2fd3f-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Khyber Pakhtunkhwa Chief Minister Ali Amin Gandapur has announced to distribute 2KW free solar systems to one lac families in the region as cost of inflated bills forced people to go for green energy. Chief Minister Gandapur said 100,000 households will receive 2 kilowatt solar systems including Panels, Inverters, Wiring, Fans, and Bulbs. He said [&#8230;]

## Lady Dolphin Police Squad hits Faisalabad Streets to combat crime
 - [https://pakobserver.net/lady-dolphin-police-squad-hits-faisalabad-streets-to-combat-crime](https://pakobserver.net/lady-dolphin-police-squad-hits-faisalabad-streets-to-combat-crime)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T14:54:52+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/2sd3s2d-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Punjab Police&#8217;s Female Dolphin Squad is now on Faisalabad streets to combat street Crime in the region. This initiative is the latest step to advance women&#8217;s roles in policing by transitioning traditional duties from men to women officers. Women in patrolling forces are now reality as Punjab police promotes gender equality and female officers bring [&#8230;]

## Why are WhatsApp, Facebook, Instagram facing disruption in Pakistan?
 - [https://pakobserver.net/why-are-whatsapp-facebook-instagram-facing-disruption-in-pakistan](https://pakobserver.net/why-are-whatsapp-facebook-instagram-facing-disruption-in-pakistan)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T14:35:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/sd23s2dsd-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />If you are facing issues while using Facebook, Instagram, WhatsApp or any other application, you are not alone, and thousands are reporting these issues. Social media users across the country are facing challenges over the weekend due to significant internet disruptions affecting various cities from Friday. Besides TikTok and Facebook, WhatsApp and other social media [&#8230;]

## BISE Lahore Intermediate Parts 2 Annual Results Date revealed
 - [https://pakobserver.net/bise-lahore-intermediate-parts-2-annual-results-date-revealed](https://pakobserver.net/bise-lahore-intermediate-parts-2-annual-results-date-revealed)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T12:51:59+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/d2sd3sd-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; After announcement of Matric exams, all eyes are on Intermediate Part 1 and Part 2 results, with Board of Intermediate and Secondary Education Lahore and other boards set to announce the results on September 4. Punjab Boards Committee of Chairmen (PBCC) annuonced the Intermediate results date. As per the announcement, HSSC Part 2 [&#8230;]

## Pakistan’s Olympic Hero Arshad Nadeem to be Honored with Hilal-e-Imtiaz
 - [https://pakobserver.net/pakistans-olympic-hero-arshad-nadeem-to-be-honored-with-hilal-e-imtiaz](https://pakobserver.net/pakistans-olympic-hero-arshad-nadeem-to-be-honored-with-hilal-e-imtiaz)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T12:26:56+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/2as3asd-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; Star Athlete Arshad Nadeem made hisotory at Olympics with massive Javelin throw of 92.97 metres to clinch Pakistan&#8217;s first track and field Gold, and now he will be accorded with second highest civilian award Hilal-e-Imtiaz. Nadeem, who hailed from small village of Mian Channu, secured country&#8217;s first individual gold medal at Paris Olympics, [&#8230;]

## Bait-ul Maal’s Rs2Billion Scandal surfaces as Auditor General reveals massive financial irregularities
 - [https://pakobserver.net/bait-ul-maals-rs2billion-scandal-surfaces-as-auditor-general-reveals-massive-financial-irregularities](https://pakobserver.net/bait-ul-maals-rs2billion-scandal-surfaces-as-auditor-general-reveals-massive-financial-irregularities)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T11:22:06+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/swfs2f-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; Pakistan Baitul Maal was formed to provide financial assistance to the underprivileged, but Auditor General of Pakistan (AGP) revealed staggering irregularities of Rs2billion. A report shared by a local news channel said financial irregularities, that amounts to over Rs2 billions, have emerged at Pakistan Baitul Maal. The audit revealed discrepancies exceeding Rs2 billion, [&#8230;]

## Shocking details of terrorist group’s involvement in robberies, extortion in Pakistan revealed
 - [https://pakobserver.net/shocking-details-of-terrorist-groups-involvement-in-robberies-extortion-in-pakistan-revealed](https://pakobserver.net/shocking-details-of-terrorist-groups-involvement-in-robberies-extortion-in-pakistan-revealed)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-08-10T10:36:10+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/08/ttp-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The terrorist group, TTP, has been found involved in widespread criminal activities, including robberies and extortion, revealed documentary evidence recovered from terrorists killed by security forces recently. Besides spreading terrorism in Pakistan, the terrorists of Fitna-al-Khawarj have been involved in serious cases of robbery and extortion. In the southern Khyber Pakhtunkhwa region, particularly [&#8230;]

