# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Crazy Steph Curry picture which encapsulated USA’s gold medal win over France
 - [https://www.telegraph.co.uk/olympics/2024/08/10/steph-curry-wembanyama-basketball-usa-france-olympics-gold](https://www.telegraph.co.uk/olympics/2024/08/10/steph-curry-wembanyama-basketball-usa-france-olympics-gold)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T22:54:16+00:00



## Dutch rider disqualified for headbutt on GB’s Ollie Wood in chaotic Madison final
 - [https://www.telegraph.co.uk/olympics/2024/08/10/track-cycling-live-team-gb-mens-madison-keirin-paris-2024](https://www.telegraph.co.uk/olympics/2024/08/10/track-cycling-live-team-gb-mens-madison-keirin-paris-2024)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T22:29:46+00:00



## Caden Cunningham has to settle for Olympic silver but vows to become ‘king of taekwondo’
 - [https://www.telegraph.co.uk/olympics/2024/08/10/caden-cunningham-taekwondo-silver-paris-2024](https://www.telegraph.co.uk/olympics/2024/08/10/caden-cunningham-taekwondo-silver-paris-2024)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T22:13:20+00:00



## Imane Khelif files legal complaint for cyber harassment after ‘digital lynching’
 - [https://www.telegraph.co.uk/olympics/2024/08/10/imane-khelif-files-legal-complaint-cyber-harassment-paris](https://www.telegraph.co.uk/olympics/2024/08/10/imane-khelif-files-legal-complaint-cyber-harassment-paris)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T22:09:26+00:00



## Team GB win six medals on day 15 of Paris 2024 Olympic Games
 - [https://www.telegraph.co.uk/olympics/2024/08/10/paris-2024-day-15-live-latest-updates-games](https://www.telegraph.co.uk/olympics/2024/08/10/paris-2024-day-15-live-latest-updates-games)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T22:04:11+00:00



## Relay medals underpin Great Britain’s athletics success in Paris
 - [https://www.telegraph.co.uk/olympics/2024/08/10/relay-medals-team-gb-britain-athletics-paris-2024-olympics](https://www.telegraph.co.uk/olympics/2024/08/10/relay-medals-team-gb-britain-athletics-paris-2024-olympics)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T21:57:24+00:00



## Georgia Bell goes from parkrun to Olympic bronze – while working in cyber security
 - [https://www.telegraph.co.uk/olympics/2024/08/10/athletics-live-mens-800m-womens-1500m-paris-2024-latest](https://www.telegraph.co.uk/olympics/2024/08/10/athletics-live-mens-800m-womens-1500m-paris-2024-latest)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T21:18:36+00:00



## Lin Yu-ting shuts out noise to claim controversial gold in women’s boxing
 - [https://www.telegraph.co.uk/olympics/2024/08/10/lin-yu-ting-vs-julia-szeremeta-live-boxing-olympic-updates](https://www.telegraph.co.uk/olympics/2024/08/10/lin-yu-ting-vs-julia-szeremeta-live-boxing-olympic-updates)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T20:44:22+00:00



## ‘We jump’: High jumpers refuse to split gold – three years after duo shared top spot on podium
 - [https://www.telegraph.co.uk/olympics/2024/08/10/olympics-high-jump-final-kerr-mcewen-tamberi-gold-medal](https://www.telegraph.co.uk/olympics/2024/08/10/olympics-high-jump-final-kerr-mcewen-tamberi-gold-medal)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T20:31:40+00:00



## Kate Shortman and Izzy Thorpe deliver historic silver medal in artistic swimming
 - [https://www.telegraph.co.uk/olympics/2024/08/10/kate-shortman-izzy-thorpe-win-silver-artistic-swimming](https://www.telegraph.co.uk/olympics/2024/08/10/kate-shortman-izzy-thorpe-win-silver-artistic-swimming)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T20:11:37+00:00



## Positive signs for Man Utd’s new chapter despite defeat by City in Community Shield
 - [https://www.telegraph.co.uk/football/2024/08/10/man-city-vs-man-utd-live-score-updates-community-shield0](https://www.telegraph.co.uk/football/2024/08/10/man-city-vs-man-utd-live-score-updates-community-shield0)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T19:44:20+00:00



## Thomas Bach to step down as IOC president next year
 - [https://www.telegraph.co.uk/olympics/2024/08/10/thomas-bach-step-down-ioc-president-2025](https://www.telegraph.co.uk/olympics/2024/08/10/thomas-bach-step-down-ioc-president-2025)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T19:32:26+00:00



## ‘That was for my dad’: Emma Hayes guides US to Olympic gold just 10 weeks after taking charge
 - [https://www.telegraph.co.uk/olympics/2024/08/10/emma-hayes-us-olympic-gold-10-weeks-dad-brazil](https://www.telegraph.co.uk/olympics/2024/08/10/emma-hayes-us-olympic-gold-10-weeks-dad-brazil)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T18:53:32+00:00



## ‘Competing is my form of therapy’: Noah Williams delight after winning individual diving bronze
 - [https://www.telegraph.co.uk/olympics/2024/08/10/noah-williams-diving-bronze-olympics-team-gb-platform-final](https://www.telegraph.co.uk/olympics/2024/08/10/noah-williams-diving-bronze-olympics-team-gb-platform-final)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T18:23:45+00:00



## Ahmed Elgendy wins modern pentathlon after Joe Choong left himself too much to do
 - [https://www.telegraph.co.uk/olympics/2024/08/10/modern-pentathlon-live-latest-updates-joe-choong-paris-2024](https://www.telegraph.co.uk/olympics/2024/08/10/modern-pentathlon-live-latest-updates-joe-choong-paris-2024)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T17:41:16+00:00



## German Olympian ‘vomits nine times’ after swimming in Seine
 - [https://www.telegraph.co.uk/olympics/2024/08/10/leonie-beck-marathon-swim-paris-2024-sick-seine](https://www.telegraph.co.uk/olympics/2024/08/10/leonie-beck-marathon-swim-paris-2024-sick-seine)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T17:17:13+00:00



## Olympic organisers vow to replace damaged Olympic medals in wake of criticism
 - [https://www.telegraph.co.uk/olympics/2024/08/10/bronze-medals-paris-mint-chaumet-nyjah-huston-yasmin-harper](https://www.telegraph.co.uk/olympics/2024/08/10/bronze-medals-paris-mint-chaumet-nyjah-huston-yasmin-harper)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T16:53:01+00:00



## Brenden Aaronson both hero and villain in Leeds’ draw with Portsmouth
 - [https://www.telegraph.co.uk/football/2024/08/10/leeds-vs-portsmouth-report-brenden-aaronson-hero-villain](https://www.telegraph.co.uk/football/2024/08/10/leeds-vs-portsmouth-report-brenden-aaronson-hero-villain)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T16:37:55+00:00



## Russia evacuates towns in Kursk over Ukrainian attacks
 - [https://www.telegraph.co.uk/world-news/2024/08/10/ukraine-russia-war-latest-news21-kursk-offensive-nuclear](https://www.telegraph.co.uk/world-news/2024/08/10/ukraine-russia-war-latest-news21-kursk-offensive-nuclear)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T16:37:03+00:00



## Team GB medical staff save life of Uzbek boxing coach after cardiac arrest
 - [https://www.telegraph.co.uk/olympics/2024/08/10/team-gb-staff-uzbek-boxing-coach-cardiac-arrest-paris-2024](https://www.telegraph.co.uk/olympics/2024/08/10/team-gb-staff-uzbek-boxing-coach-cardiac-arrest-paris-2024)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T15:37:43+00:00



## Giant couscous, car horns and presidential approval: How Algeria celebrated Imane Khelif’s win
 - [https://www.telegraph.co.uk/olympics/2024/08/10/how-algeria-celebrated-imane-khelif-olympic-boxing-gold-win](https://www.telegraph.co.uk/olympics/2024/08/10/how-algeria-celebrated-imane-khelif-olympic-boxing-gold-win)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T15:04:59+00:00



## Australia’s Raygun defended after Olympics performance ‘set breaking back 40 years’
 - [https://www.telegraph.co.uk/olympics/2024/08/10/australia-raygun-defended-olympics-paris-2024-breaking](https://www.telegraph.co.uk/olympics/2024/08/10/australia-raygun-defended-olympics-paris-2024-breaking)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T15:00:00+00:00



## Team GB track cyclists print ‘extra round’ on wheels in dig at France
 - [https://www.telegraph.co.uk/olympics/2024/08/10/team-gb-track-cyclists-extra-round-wheels-france-olympics](https://www.telegraph.co.uk/olympics/2024/08/10/team-gb-track-cyclists-extra-round-wheels-france-olympics)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T13:00:00+00:00



## Emile Cairess fourth in marathon in one of Britain’s best performances of Paris Games
 - [https://www.telegraph.co.uk/olympics/2024/08/10/emile-cairess-fourth-marathon-team-gb-bradford-brownlee](https://www.telegraph.co.uk/olympics/2024/08/10/emile-cairess-fourth-marathon-team-gb-bradford-brownlee)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T11:15:17+00:00



## Jazmin Sawyers: Michael Johnson’s plan to shake up athletics has one glaring flaw
 - [https://www.telegraph.co.uk/olympics/2024/08/10/jazmin-sawyers-michael-johnson-plan-shake-up-athletics-flaw](https://www.telegraph.co.uk/olympics/2024/08/10/jazmin-sawyers-michael-johnson-plan-shake-up-athletics-flaw)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T09:53:38+00:00



## Six medals for Team GB on day 14 as Toby Roberts claims gold in men’s climbing
 - [https://www.telegraph.co.uk/olympics/2024/08/09/paris-2024-day-14-live-latest-updates-games](https://www.telegraph.co.uk/olympics/2024/08/09/paris-2024-day-14-live-latest-updates-games)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-08-10T05:08:07+00:00



