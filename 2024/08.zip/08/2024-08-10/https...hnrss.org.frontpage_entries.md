# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Algorithmic price-fixing of rents is here
 - [https://www.theatlantic.com/ideas/archive/2024/08/ai-price-algorithms-realpage/679405](https://www.theatlantic.com/ideas/archive/2024/08/ai-price-algorithms-realpage/679405)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T22:11:24+00:00

<p>Article URL: <a href="https://www.theatlantic.com/ideas/archive/2024/08/ai-price-algorithms-realpage/679405/">https://www.theatlantic.com/ideas/archive/2024/08/ai-price-algorithms-realpage/679405/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41212616">https://news.ycombinator.com/item?id=41212616</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## US FDA approves nasal spray alternative to EpiPen for allergic reactions
 - [https://www.reuters.com/business/healthcare-pharmaceuticals/us-fda-approves-first-nasal-spray-allergic-reactions-2024-08-09](https://www.reuters.com/business/healthcare-pharmaceuticals/us-fda-approves-first-nasal-spray-allergic-reactions-2024-08-09)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T21:30:46+00:00

<p>Article URL: <a href="https://www.reuters.com/business/healthcare-pharmaceuticals/us-fda-approves-first-nasal-spray-allergic-reactions-2024-08-09/">https://www.reuters.com/business/healthcare-pharmaceuticals/us-fda-approves-first-nasal-spray-allergic-reactions-2024-08-09/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41212364">https://news.ycombinator.com/item?id=41212364</a></p>
<p>Points: 38</p>
<p># Comments: 5</p>

## AMD's Strix Point: Zen 5 Hits Mobile
 - [https://chipsandcheese.com/2024/08/10/amds-strix-point-zen-5-hits-mobile](https://chipsandcheese.com/2024/08/10/amds-strix-point-zen-5-hits-mobile)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T21:18:51+00:00

<p>Article URL: <a href="https://chipsandcheese.com/2024/08/10/amds-strix-point-zen-5-hits-mobile/">https://chipsandcheese.com/2024/08/10/amds-strix-point-zen-5-hits-mobile/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41212271">https://news.ycombinator.com/item?id=41212271</a></p>
<p>Points: 37</p>
<p># Comments: 14</p>

## Stapler: I remade a 32 year old classic Macintosh app
 - [https://blog.gingerbeardman.com/2024/08/10/stapler-i-remade-a-32-year-old-classic-macintosh-app](https://blog.gingerbeardman.com/2024/08/10/stapler-i-remade-a-32-year-old-classic-macintosh-app)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T21:03:04+00:00

<p>Article URL: <a href="https://blog.gingerbeardman.com/2024/08/10/stapler-i-remade-a-32-year-old-classic-macintosh-app/">https://blog.gingerbeardman.com/2024/08/10/stapler-i-remade-a-32-year-old-classic-macintosh-app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41212193">https://news.ycombinator.com/item?id=41212193</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Susan Wojcicki, former YouTube CEO, dies at 56
 - [https://www.cnn.com/2024/08/10/business/susan-wojcicki-obit/index.html](https://www.cnn.com/2024/08/10/business/susan-wojcicki-obit/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T19:48:52+00:00

<p>Article URL: <a href="https://www.cnn.com/2024/08/10/business/susan-wojcicki-obit/index.html">https://www.cnn.com/2024/08/10/business/susan-wojcicki-obit/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41211766">https://news.ycombinator.com/item?id=41211766</a></p>
<p>Points: 10</p>
<p># Comments: 3</p>

## Things I Won't Work With: Dimethylcadmium
 - [https://www.science.org/content/blog-post/things-i-won-t-work-dimethylcadmium](https://www.science.org/content/blog-post/things-i-won-t-work-dimethylcadmium)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T19:11:39+00:00

<p>Article URL: <a href="https://www.science.org/content/blog-post/things-i-won-t-work-dimethylcadmium">https://www.science.org/content/blog-post/things-i-won-t-work-dimethylcadmium</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41211540">https://news.ycombinator.com/item?id=41211540</a></p>
<p>Points: 80</p>
<p># Comments: 42</p>

## DEF CON's response to the badge controversy
 - [https://old.reddit.com/r/Defcon/comments/1ep00ln/def_cons_response_to_the_badge_controversy](https://old.reddit.com/r/Defcon/comments/1ep00ln/def_cons_response_to_the_badge_controversy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T19:07:23+00:00

<p>Article URL: <a href="https://old.reddit.com/r/Defcon/comments/1ep00ln/def_cons_response_to_the_badge_controversy/">https://old.reddit.com/r/Defcon/comments/1ep00ln/def_cons_response_to_the_badge_controversy/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41211519">https://news.ycombinator.com/item?id=41211519</a></p>
<p>Points: 146</p>
<p># Comments: 103</p>

## Interval parsing grammars for file format parsing (2023)
 - [https://dl.acm.org/doi/10.1145/3591264](https://dl.acm.org/doi/10.1145/3591264)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T17:42:02+00:00

<p>Article URL: <a href="https://dl.acm.org/doi/10.1145/3591264">https://dl.acm.org/doi/10.1145/3591264</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41211039">https://news.ycombinator.com/item?id=41211039</a></p>
<p>Points: 83</p>
<p># Comments: 17</p>

## OneText (YC W23) is hiring a lead TypeScript/Node engineer
 - [https://gist.github.com/bluepnume/8f2376b0893bc6b85564e7359359ecd4](https://gist.github.com/bluepnume/8f2376b0893bc6b85564e7359359ecd4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T17:00:01+00:00

<p>Article URL: <a href="https://gist.github.com/bluepnume/8f2376b0893bc6b85564e7359359ecd4">https://gist.github.com/bluepnume/8f2376b0893bc6b85564e7359359ecd4</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41210742">https://news.ycombinator.com/item?id=41210742</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Show HN: Pg_replicate – Build Postgres replication applications in Rust
 - [https://github.com/supabase/pg_replicate](https://github.com/supabase/pg_replicate)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T15:00:41+00:00

<p>Article URL: <a href="https://github.com/supabase/pg_replicate">https://github.com/supabase/pg_replicate</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41209994">https://news.ycombinator.com/item?id=41209994</a></p>
<p>Points: 102</p>
<p># Comments: 9</p>

## PEP 750: Tag Strings for Writing Domain-Specific Languages
 - [https://discuss.python.org/t/pep-750-tag-strings-for-writing-domain-specific-languages/60408](https://discuss.python.org/t/pep-750-tag-strings-for-writing-domain-specific-languages/60408)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T14:57:00+00:00

<p>Article URL: <a href="https://discuss.python.org/t/pep-750-tag-strings-for-writing-domain-specific-languages/60408">https://discuss.python.org/t/pep-750-tag-strings-for-writing-domain-specific-languages/60408</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41209966">https://news.ycombinator.com/item?id=41209966</a></p>
<p>Points: 65</p>
<p># Comments: 42</p>

## OpenSnitch is a GNU/Linux interactive application firewall
 - [https://github.com/evilsocket/opensnitch](https://github.com/evilsocket/opensnitch)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T14:15:52+00:00

<p>Article URL: <a href="https://github.com/evilsocket/opensnitch">https://github.com/evilsocket/opensnitch</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41209688">https://news.ycombinator.com/item?id=41209688</a></p>
<p>Points: 238</p>
<p># Comments: 52</p>

## Ray Tracing Harmonic Functions
 - [https://markjgillespie.com/Research/harnack-tracing/index.html](https://markjgillespie.com/Research/harnack-tracing/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T13:45:12+00:00

<p>Article URL: <a href="https://markjgillespie.com/Research/harnack-tracing/index.html">https://markjgillespie.com/Research/harnack-tracing/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41209452">https://news.ycombinator.com/item?id=41209452</a></p>
<p>Points: 36</p>
<p># Comments: 5</p>

## Deep Live Cam: Real-time face swapping and one-click video deepfake tool
 - [https://deeplive.cam](https://deeplive.cam)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T13:05:48+00:00

<p>Article URL: <a href="https://deeplive.cam">https://deeplive.cam</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41209181">https://news.ycombinator.com/item?id=41209181</a></p>
<p>Points: 190</p>
<p># Comments: 143</p>

## A wonderful coincidence or an expected connection: why π² ≈ g
 - [https://roitman.io/blog/91](https://roitman.io/blog/91)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T12:24:54+00:00

<p>Article URL: <a href="https://roitman.io/blog/91">https://roitman.io/blog/91</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41208988">https://news.ycombinator.com/item?id=41208988</a></p>
<p>Points: 340</p>
<p># Comments: 228</p>

## Command-Line Utility to Backup Google Mail, Calendar and Contacts to Files
 - [https://github.com/WeeJeWel/node-google-backup](https://github.com/WeeJeWel/node-google-backup)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T11:13:37+00:00

<p>Article URL: <a href="https://github.com/WeeJeWel/node-google-backup">https://github.com/WeeJeWel/node-google-backup</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41208704">https://news.ycombinator.com/item?id=41208704</a></p>
<p>Points: 39</p>
<p># Comments: 12</p>

## Linearizability: A correctness condition for concurrent objects
 - [http://muratbuffalo.blogspot.com/2024/08/linearizability-correctness-condition.html](http://muratbuffalo.blogspot.com/2024/08/linearizability-correctness-condition.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T06:51:39+00:00

<p>Article URL: <a href="http://muratbuffalo.blogspot.com/2024/08/linearizability-correctness-condition.html">http://muratbuffalo.blogspot.com/2024/08/linearizability-correctness-condition.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41207793">https://news.ycombinator.com/item?id=41207793</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## How the SNES Graphics System Works
 - [https://fabiensanglard.net/snes_ppus_how/index.html](https://fabiensanglard.net/snes_ppus_how/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T05:48:43+00:00

<p>Article URL: <a href="https://fabiensanglard.net/snes_ppus_how/index.html">https://fabiensanglard.net/snes_ppus_how/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41207608">https://news.ycombinator.com/item?id=41207608</a></p>
<p>Points: 22</p>
<p># Comments: 0</p>

## Caltech Develops First Noninvasive Method to Continually Measure Blood Pressure
 - [https://www.caltech.edu/about/news/caltech-team-develops-first-noninvasive-method-to-continually-measure-true-blood-pressure](https://www.caltech.edu/about/news/caltech-team-develops-first-noninvasive-method-to-continually-measure-true-blood-pressure)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T03:53:04+00:00

<p>Article URL: <a href="https://www.caltech.edu/about/news/caltech-team-develops-first-noninvasive-method-to-continually-measure-true-blood-pressure">https://www.caltech.edu/about/news/caltech-team-develops-first-noninvasive-method-to-continually-measure-true-blood-pressure</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41207182">https://news.ycombinator.com/item?id=41207182</a></p>
<p>Points: 183</p>
<p># Comments: 47</p>

## Shanghai's Automotive Metamorphosis
 - [https://arun.is/blog/shanghai-cars](https://arun.is/blog/shanghai-cars)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-08-10T03:16:14+00:00

<p>Article URL: <a href="https://arun.is/blog/shanghai-cars/">https://arun.is/blog/shanghai-cars/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=41207048">https://news.ycombinator.com/item?id=41207048</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

