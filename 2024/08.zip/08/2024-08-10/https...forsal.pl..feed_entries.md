# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Na Święto Wojska Polskiego przybędzie w Polsce 13 nowych generałów
 - [https://forsal.pl/kraj/bezpieczenstwo/artykuly/9566752,na-swieto-wojska-polskiego-przybedzie-w-polsce-13-nowych-generalow.html](https://forsal.pl/kraj/bezpieczenstwo/artykuly/9566752,na-swieto-wojska-polskiego-przybedzie-w-polsce-13-nowych-generalow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-08-10T13:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VMpktkuTURBXy84MTEyOGM5Yy0xYzM3LTQzYWYtYTc5Mi1kY2UxM2QwZWUzZmYuanBlZ5GTBc0BHcyg" />Tak wielu nominacji nie widzieliśmy już od dawna. Za rosnącym rozmiarem armii wzrasta też liczba generałów. W przeddzień święta Wojska Polskiego awans otrzyma 19 oficerów, z czego 13 na pierwszy stopień generalski.

## Przykład min. edukacji B. Nowackiej łączenia uczniów w grupy w roku szkolnym 2024/2025
 - [https://forsal.pl/kraj/aktualnosci/artykuly/9566747,min-edukacji-b-nowacka-podala-przyklad-laczenia-uczniow-w-grupy-w-roku-szkolnym-20242025.html](https://forsal.pl/kraj/aktualnosci/artykuly/9566747,min-edukacji-b-nowacka-podala-przyklad-laczenia-uczniow-w-grupy-w-roku-szkolnym-20242025.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-08-10T11:17:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LZWktkuTURBXy9jNDkxNzFjNy1hNDZjLTQ5ZmItYTA1Ni03OTBjNWE1NjdhZjYuanBlZ5GTBc0BHcyg" />MEN wprowadził w drodze rozporządzenia możliwość łączenia uczniów w jedną, większą grupę. Możliwość dotyczy lekcji religii. I budzi sprzeciw strony kościelnej, która wskazuje, że konsultacje nowego rozporządzenia to za mało. Potrzebne jest porozumienie między MEN a przedstawicielami kościoła.

## NSA: O abonamencie RTV Poczta Polska przypomniała sobie po 12 latach. I ... wygrała sprawę
 - [https://forsal.pl/finanse/artykuly/9566742,nsa-o-abonamencie-rtv-poczta-polska-przypomniala-sobie-po-12-latach-i--wygrala-sprawe.html](https://forsal.pl/finanse/artykuly/9566742,nsa-o-abonamencie-rtv-poczta-polska-przypomniala-sobie-po-12-latach-i--wygrala-sprawe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-08-10T10:06:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/124ktkuTURBXy9jYzk4NDYwMy1iYzhiLTQ0NTMtOWU4Yy0yODA3YTQzNTUxOTEuanBlZ5GTBc0BHcyg" />W ciągu ostatnich lat zapadło kilka wyroków sądów, których wspólną cechą jest odrzucenie przez sąd twierdzeń obywatela, że wyrejestrował odbiornik RTV 20 lat temu, a ponieważ Poczta-Polska przez kilkanaście lat nie interesowała się abonamentem, to myślał, że nie miał żadnych zaległości.

## Kończą się igrzyska olimpijskie, a kryzys pomaga Trumpowi [NAJWAŻNIEJSZE W GOSPODARCE]
 - [https://forsal.pl/gospodarka/artykuly/9566687,koncza-sie-igrzyska-olimpijskie-a-kryzys-pomaga-trumpowi-najwazniejs.html](https://forsal.pl/gospodarka/artykuly/9566687,koncza-sie-igrzyska-olimpijskie-a-kryzys-pomaga-trumpowi-najwazniejs.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-08-10T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NUqktkuTURBXy81ODhjNzhkZC03ZWUwLTRhNDgtOTVmMC02ZGIzY2ViNjc5NTQuanBlZ5GTBc0BHcyg" />W chwili gdy piszę te słowa, świat z jednej strony żyje nieprzewidzianymi konsekwencjami podwyżki stóp procentowych w Japonii, które doprowadziły do wyprzedaży na światowych parkietach, a z drugiej trwającymi Igrzyskami Olimpijskimi. W jednym i w drugim wypadku nikt w Polsce nie może czuć się zbyt szczęśliwy.

## W 2025 r. zmiany w zasiłku pielęgnacyjnym (215,84 zł) i rodzinnym (95,00 zł, 124,00 zł, 135,00 zł). [Liczba uprawnionych]
 - [https://forsal.pl/finanse/artykuly/9564470,w-2025-r-zmiany-w-zasilku-pielegnacyjnym-21584-zl-i-rodzinnym-9500-zl-12400-zl-13500-zl-liczba-uprawnionych.html](https://forsal.pl/finanse/artykuly/9564470,w-2025-r-zmiany-w-zasilku-pielegnacyjnym-21584-zl-i-rodzinnym-9500-zl-12400-zl-13500-zl-liczba-uprawnionych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-08-10T00:18:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/csAktkuTURBXy9jNGMzOTBiYy02MDI3LTQ4NjEtODBiOC1lOWFjNTkwNGYxZTkuanBlZ5GTBc0BHcyg" />W 2025 r. rząd będzie wypłacał miesięcznie zasiłek pielęgnacyjny przeszło milionowi Polaków (średnio każdego miesiąca). Jest to wzrost o około 50 000 osób względem 2023 r. Za to liczba osób pobierających zasiłek rodzinny spadnie poniżej 1 mln do około 742 900 uprawnionych (mniej o 275 600 osób).

