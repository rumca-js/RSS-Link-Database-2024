# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Australian Government Magazine Enlists AI to Write Articles
 - [https://www.theepochtimes.com/world/australian-government-magazine-enlists-ai-to-write-articles-5702619](https://www.theepochtimes.com/world/australian-government-magazine-enlists-ai-to-write-articles-5702619)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-08-10T23:25:52+00:00

An unnamed Chinese hacker uses a computer at an office in Dongguan, in China's southern Guangdong Province, on Aug. 4, 2020. (Nicolas Asfouri/AFP via Getty Images)

