# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Firearms Expert Reacts to Hunt: Showdown PART 3
 - [https://www.youtube.com/watch?v=Lw4vmMf6xZ4](https://www.youtube.com/watch?v=Lw4vmMf6xZ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-08-10T14:00:17+00:00

Jonathan Ferguson, a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries, breaks down a range of the historical monster-slaying weapons of Hunt: Showdown, including the Bomb Lance, the cut-down Obrez Mosin and the vaguely horrific Pennyshot.

In the latest video in the Firearm Expert Reacts series, Jonathan Ferguson--a weapons expert and Keeper of Firearms & Artillery at the Royal Armouries--breaks down guns from Hunt: Showdown, and compares them to their potential real-life counterparts.

00:00 Intro
00:30 Bornheim No 3
04:22 Bomb Lance
06:08 Caldwell Marathon
07:28 Drilling
08:53 Springfield Krag-Jørgensen
11:10 Mako 1895
12:39 Martini-Henry
16:52 Harston Quick Magazine Loader
18:42 Caldwell 92 New Army
21:03 Obrez Mosin
23:07 Pennyshot
24:52 Vetterli 71 Karabiner

Firearms Expert Reacts playlist - https://www.youtube.com/watch?v=y4T78VQoWUs&amp;list=PLpg6WLs8kxGMgYb13XjPgOKbm5O-CDq7R

If you're interested in seeing more of Jonathan's work, you can check out mor

