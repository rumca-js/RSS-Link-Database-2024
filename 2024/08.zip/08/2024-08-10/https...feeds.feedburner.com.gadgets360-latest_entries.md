# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## Ola Electric Shares Surge on Debut as Investors Bet on Increasing EV Adoption
 - [https://www.gadgets360.com/auto/news/ola-electric-shares-surge-increasing-ev-adoption-6308738](https://www.gadgets360.com/auto/news/ola-electric-shares-surge-increasing-ev-adoption-6308738)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T14:33:56+00:00

Ola Electric's $734 million IPO is India's biggest so far in 2024

## Signal Private Messenger Blocked in Russia by Roskomnadzor: Report
 - [https://www.gadgets360.com/apps/news/signal-private-messenger-blocked-russia-roskomnadzor-report-6308261](https://www.gadgets360.com/apps/news/signal-private-messenger-blocked-russia-roskomnadzor-report-6308261)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T13:27:02+00:00

Signal has reportedly been blocked in Russia for violating laws linked to anti-terrorist operations

## Amazon Great Freedom Festival 2024 Sale: Best Deals on Home Theatre Systems, Bluetooth Speakers
 - [https://www.gadgets360.com/internet/features/amazon-great-freedom-festival-2024-sale-deals-home-theatre-systems-bluetooth-speakers-6307278](https://www.gadgets360.com/internet/features/amazon-great-freedom-festival-2024-sale-deals-home-theatre-systems-bluetooth-speakers-6307278)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T12:39:27+00:00

Projectors from several brands are available at discounted prices during Amazon's ongoing sale

## Honor Magic V3 Global Model Listed on Geekbench With Snapdragon 8 Gen 3 Chipset
 - [https://www.gadgets360.com/mobiles/news/honor-magic-v3-specifications-leak-geekbench-listing-6307277](https://www.gadgets360.com/mobiles/news/honor-magic-v3-specifications-leak-geekbench-listing-6307277)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T10:39:17+00:00

Honor Magic V3 runs on Android 14-based MagicOS 8.0.1

## vivo V40 Series: Setting a New Benchmark in the Mid-Premium Smartphone Segment
 - [https://www.gadgets360.com/mobiles/sponsored/vivo-v40-series-setting-a-new-benchmark-in-the-mid-premium-smartphone-segment-6306580](https://www.gadgets360.com/mobiles/sponsored/vivo-v40-series-setting-a-new-benchmark-in-the-mid-premium-smartphone-segment-6306580)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T08:28:07+00:00

‍‍‍‍‍

## Amazon Great Freedom Festival 2024 Sale: Top Deals and Discounts on Monitors and Printers
 - [https://www.gadgets360.com/internet/features/amazon-great-freedom-festival-sale-2024-sale-monitors-printers-deals-discounts-offers-6306427](https://www.gadgets360.com/internet/features/amazon-great-freedom-festival-sale-2024-sale-monitors-printers-deals-discounts-offers-6306427)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T08:18:54+00:00

Amazon Great Freedom Festival 2024 sale ends on August 12

## Redmi Note 14, Poco X7 Neo Surface on BIS Certification Website Ahead of Anticipated Debut
 - [https://www.gadgets360.com/mobiles/news/redmi-note-14-poco-x7-neo-bis-certification-website-specifications-expected-6305836](https://www.gadgets360.com/mobiles/news/redmi-note-14-poco-x7-neo-bis-certification-website-specifications-expected-6305836)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T06:27:44+00:00

Redmi Note 13 was launched in India earlier this year

## Elon Musk's X Sued for $20 Million in Shares by Ex-Twitter Chairman
 - [https://www.gadgets360.com/social-networking/news/elon-musk-x-lawsuit-former-twitter-chairman-6305593](https://www.gadgets360.com/social-networking/news/elon-musk-x-lawsuit-former-twitter-chairman-6305593)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-08-10T05:13:20+00:00

Elon Musk rebranded Twitter to X in July 2023

