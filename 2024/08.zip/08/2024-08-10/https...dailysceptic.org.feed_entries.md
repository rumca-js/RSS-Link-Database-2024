# Source:Daily sceptic, URL:https://dailysceptic.org/feed, language:en-US

## News Round-Up
 - [https://dailysceptic.org/2024/08/11/news-round-up-1247](https://dailysceptic.org/2024/08/11/news-round-up-1247)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T23:23:11+00:00

<p>A summary of the most interesting stories in the past 24 hours that challenge the prevailing orthodoxy about the ‘climate emergency’, public health ‘crises’ and the supposed moral defects of Western civilisation.</p>
<p>The post <a href="https://dailysceptic.org/2024/08/11/news-round-up-1247/">News Round-Up</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Richard Dawkins’s Facebook Account Deleted After he Posted that Genetically Male Boxers Should Not Fight Women
 - [https://dailysceptic.org/2024/08/10/richard-dawkinss-facebook-account-deleted-after-he-posted-that-genetically-male-boxers-should-not-fight-women](https://dailysceptic.org/2024/08/10/richard-dawkinss-facebook-account-deleted-after-he-posted-that-genetically-male-boxers-should-not-fight-women)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T16:00:00+00:00

<p>Richard Dawkins's Facebook account has been deleted after he posted that genetically male boxers should not fight women. Could anything sum up more perfectly the dire state of free speech today?</p>
<p>The post <a href="https://dailysceptic.org/2024/08/10/richard-dawkinss-facebook-account-deleted-after-he-posted-that-genetically-male-boxers-should-not-fight-women/">Richard Dawkins&#8217;s Facebook Account Deleted After he Posted that Genetically Male Boxers Should Not Fight Women</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Labour Will Not Make ‘Misgendering’ Trans People a Hate Crime
 - [https://dailysceptic.org/2024/08/10/labour-will-not-make-misgendering-trans-people-a-hate-crime](https://dailysceptic.org/2024/08/10/labour-will-not-make-misgendering-trans-people-a-hate-crime)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T14:00:00+00:00

<p>Labour has "no plans" to make it a hate crime to 'misgender' trans people, a Home Office Minister has said, rowing back on previous comments made by Keir Starmer that "every" LGBT crime should be an aggravated offence.</p>
<p>The post <a href="https://dailysceptic.org/2024/08/10/labour-will-not-make-misgendering-trans-people-a-hate-crime/">Labour Will Not Make &#8216;Misgendering&#8217; Trans People a Hate Crime</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Iraq Proposes Lowering Legal Age of Marriage for Girls to Nine
 - [https://dailysceptic.org/2024/08/10/iraq-proposes-lowering-legal-age-of-marriage-for-girls-to-nine](https://dailysceptic.org/2024/08/10/iraq-proposes-lowering-legal-age-of-marriage-for-girls-to-nine)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T12:00:00+00:00

<p>A conservative coalition forming the largest bloc in the Iraqi parliament has pushed proposals to lower the legal age of marriage for girls to just nine years old, sparking backlash from activists and rights groups.</p>
<p>The post <a href="https://dailysceptic.org/2024/08/10/iraq-proposes-lowering-legal-age-of-marriage-for-girls-to-nine/">Iraq Proposes Lowering Legal Age of Marriage for Girls to Nine</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Boris Johnson: Keir Starmer is “Deaf” to Immigration Concerns
 - [https://dailysceptic.org/2024/08/10/boris-johnson-keir-starmer-is-deaf-to-immigration-concerns](https://dailysceptic.org/2024/08/10/boris-johnson-keir-starmer-is-deaf-to-immigration-concerns)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T10:00:00+00:00

<p>Sir Keir Starmer’s response to the riots shows he is "deaf" to public concerns over immigration and he has only made things worse, Boris Johnson has said in his first intervention since the unrest.</p>
<p>The post <a href="https://dailysceptic.org/2024/08/10/boris-johnson-keir-starmer-is-deaf-to-immigration-concerns/">Boris Johnson: Keir Starmer is &#8220;Deaf&#8221; to Immigration Concerns</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Harris Lurches Even Further to the Left
 - [https://dailysceptic.org/2024/08/10/harris-lurches-even-further-to-the-left](https://dailysceptic.org/2024/08/10/harris-lurches-even-further-to-the-left)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T08:00:00+00:00

<p>By picking Walz – the Minnesota Governor blasted by his state Senate for supporting the BLM riots – as her VP running mate, Kamala Harris has lurched even further to the Left, says Tony Morrison.</p>
<p>The post <a href="https://dailysceptic.org/2024/08/10/harris-lurches-even-further-to-the-left/">Harris Lurches Even Further to the Left</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Were the ‘Spontaneous’ Anti-Racism Rallies Even Real?
 - [https://dailysceptic.org/2024/08/10/were-the-spontaneous-anti-racism-rallies-even-real](https://dailysceptic.org/2024/08/10/were-the-spontaneous-anti-racism-rallies-even-real)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T06:00:00+00:00

<p>Were the anti-racism rallies that appeared 'spontaneously' on Wednesday to oppose 100 largely non-existent 'far Right riots' even real, asks Steven Tucker. Yes, people were there, but who was really behind it?</p>
<p>The post <a href="https://dailysceptic.org/2024/08/10/were-the-spontaneous-anti-racism-rallies-even-real/">Were the &#8216;Spontaneous&#8217; Anti-Racism Rallies Even Real?</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## News Round-Up
 - [https://dailysceptic.org/2024/08/10/news-round-up-1246](https://dailysceptic.org/2024/08/10/news-round-up-1246)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-08-10T00:48:56+00:00

<p>A summary of the most interesting stories in the past 24 hours that challenge the prevailing orthodoxy about the ‘climate emergency’, public health ‘crises’ and the supposed moral defects of Western civilisation.</p>
<p>The post <a href="https://dailysceptic.org/2024/08/10/news-round-up-1246/">News Round-Up</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

