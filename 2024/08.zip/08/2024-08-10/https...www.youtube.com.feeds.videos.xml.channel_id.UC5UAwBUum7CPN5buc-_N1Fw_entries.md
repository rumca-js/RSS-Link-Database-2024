# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Nvidia pilfers Youtube for AI, GNOME HDR, Immutable Manjaro: Linux & Open Source News
 - [https://www.youtube.com/watch?v=urC7PKlM3Qo](https://www.youtube.com/watch?v=urC7PKlM3Qo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2024-08-10T15:08:23+00:00

Get the free report on the increase in Linux CVEs, and how they can affect your organization: https://tuxcare.com/downloadables/a-look-at-3-months-of-linux-kernel-cves/?utm_campaign=The%20Linux%20Experiment&amp;utm_source=youtube&amp;utm_medium=social 

Grab a brand new laptop or desktop running Linux: https://www.tuxedocomputers.com/en#


👏 SUPPORT THE CHANNEL:
Get access to:
- a Daily Linux News show
- a weekly patroncast for more personal thoughts
- polls on the next topics I cover,
- your name in the credits

YouTube: https://www.youtube.com/@TheLinuxEXP/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want:
https://paypal.me/thelinuxexp
Liberapay: https://liberapay.com/TheLinuxExperiment/

👕 GET TLE MERCH
Support the channel AND get cool new gear: https://the-linux-experiment.creator-spring.com/

🎙️ LINUX AND OPEN SOURCE NEWS PODCAST:
Listen to the latest Linux and open source news, with more in depth coverage, and ad-free!  https://podcas

