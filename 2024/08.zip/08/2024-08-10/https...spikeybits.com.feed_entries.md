# Source:Spikey Bits, URL:https://spikeybits.com/feed, language:en-US

## New WH40k Preview: Look to the Skies Announced By GW
 - [https://spikeybits.com/warhammer-40k/new-wh40k-preview-look-to-the-skies-announced-by-gw](https://spikeybits.com/warhammer-40k/new-wh40k-preview-look-to-the-skies-announced-by-gw)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-08-10T18:30:17+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/08/jump-tempestus-scion-rumors-wal-hor-warhammer-40k-new.jpg"><img alt="jump tempestus scion rumors wal hor warhammer 40k new Jump pack scions 2 look to the skies preview chalnath dispatches" class="aligncenter wp-image-466052 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/08/jump-tempestus-scion-rumors-wal-hor-warhammer-40k-new.jpg" width="1280" /></a>Uncover the latest Warhammer 40k Chalnath Dispatches teasers, from Jump</p>
<p><a href="https://spikeybits.com/warhammer-40k/new-wh40k-preview-look-to-the-skies-announced-by-gw/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/new-wh40k-preview-look-to-the-skies-announced-by-gw/">New WH40k Preview: Look to the Skies Announced By GW</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New AoS Starter Sets & Warcry Available Now!
 - [https://spikeybits.com/warhammer-40k/new-aos-starter-sets-warcry-available-now](https://spikeybits.com/warhammer-40k/new-aos-starter-sets-warcry-available-now)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-08-10T17:45:39+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/07/aos-starter-sets-now-available.png"><img alt="aos starter sets now available" class="aligncenter size-full wp-image-465110" height="720" src="https://spikeybits.com/wp-content/uploads/2024/07/aos-starter-sets-now-available.png" width="1280" /></a></p>
<p>Here are the pricing and links for Games Workshop&#8217;s three new Age of Sigmar Starter sets and Warcry, which are all available now!</p>
<p><span id="more-465840"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
<div></p>
<p><a href="https://spikeybits.com/warhammer-40k/new-aos-starter-sets-warcry-available-now/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/new-aos-starter-sets-warcry-available-now/">New AoS Starter Sets &#038; Warcry Available Now!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New Skaven AoS Miniatures Revealed For Winning the Slaughter At Hel Crown
 - [https://spikeybits.com/guides/aos-skaven-hel-crown-winner-preview-miniatures-guide](https://spikeybits.com/guides/aos-skaven-hel-crown-winner-preview-miniatures-guide)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-08-10T17:00:13+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/08/new-skaven-battletome-hel-crown-preview-age-of-sigmar.jpg"><img alt="new skaven battletome hel crown preview age of sigmar" class="aligncenter size-full wp-image-466043" height="720" src="https://spikeybits.com/wp-content/uploads/2024/08/new-skaven-battletome-hel-crown-preview-age-of-sigmar.jpg" width="1280" /></a></p>
<p>The Skaven won Hel Crown, and new AoS models, miniatures, and a battletome featuring clans Moulder, Skyre, and Verminous were revealed!</p>
<p><span></p>
<p><a href="https://spikeybits.com/guides/aos-skaven-hel-crown-winner-preview-miniatures-guide/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/guides/aos-skaven-hel-crown-winner-preview-miniatures-guide/">New Skaven AoS Miniatures Revealed For Winning the Slaughter At Hel Crown</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New GW Warhammer Preview, Updated Roadmaps & 40k Rumors
 - [https://spikeybits.com/warhammer-40k/top-posts-week-of-aug-10-2024](https://spikeybits.com/warhammer-40k/top-posts-week-of-aug-10-2024)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-08-10T15:30:12+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/06/warhammer-40k-codex-roadmap-release-date-schedule-10th-edition.png"><img alt="warhammer 40k codex roadmap release date schedule 10th edition" class="aligncenter size-full wp-image-464009" height="720" src="https://spikeybits.com/wp-content/uploads/2024/06/warhammer-40k-codex-roadmap-release-date-schedule-10th-edition.png" width="1280" /></a></p>
<p>Don&#8217;t miss the scoop on Games Workshop&#8217;s recent events, new board games, latest releases, and sweet hobby products for</p>
<p><a href="https://spikeybits.com/warhammer-40k/top-posts-week-of-aug-10-2024/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/top-posts-week-of-aug-10-2024/">New GW Warhammer Preview, Updated Roadmaps &#038; 40k Rumors</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New Warhammer 40k Imperial Agents Release: First Look
 - [https://spikeybits.com/warhammer-40k/new-warhammer-40k-imperial-agents-battleforce-codex-pricing-links](https://spikeybits.com/warhammer-40k/new-warhammer-40k-imperial-agents-battleforce-codex-pricing-links)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-08-10T10:30:43+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2023/10/warhammer-logo-wal-hor-store-GW-first-look-pre-orders-new-release.png"><img alt="warhammer-logo-wal-hor-store-GW-first-look-pre-orders-new-release" class="aligncenter size-full wp-image-446574" height="720" src="https://spikeybits.com/wp-content/uploads/2023/10/warhammer-logo-wal-hor-store-GW-first-look-pre-orders-new-release.png" width="1280" /></a></p>
<p>Here are the pricing and links for the new Imperial Agents battleforce, characters, and codex releases that are on pre-order now.</p>
<p><span id="more-465942"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p><p><a href="https://spikeybits.com/warhammer-40k/new-warhammer-40k-imperial-agents-battleforce-codex-pricing-links/"></a></p><p><a href="https://spikeybits.com/warhammer-40k/new-warhammer-40k-imperial-agents-battleforce-codex-pricing-links/"></a><

