# Source:The Rubin Report, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng, language:en

## Elon Musk Notices Something About the Trump Verdict No One Noticed
 - [https://www.youtube.com/watch?v=qbVPzW6MR2M](https://www.youtube.com/watch?v=qbVPzW6MR2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-08-10T00:15:02+00:00

Dave Rubin of “The Rubin Report” reacts to a DM clip of Elon Musk's reaction to Donald Trump receiving a guilty verdict in his hush-money trial in New York.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=i7fdAnAcybA&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#DaveRubinReacts #RubinReport #ElonMusk #Trump #Guity #Convicted #DaveRubin #shorts

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy. To hear what Dave has to 

