# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Former YouTube CEO Susan Wojcicki Dies at 56
 - [https://www.wired.com/story/susan-wojcicki-former-youtube-ceo-dies-at-56](https://www.wired.com/story/susan-wojcicki-former-youtube-ceo-dies-at-56)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2024-08-10T17:47:10+00:00

Susan Wojcicki is one of this era's great unsung executives—and was crucial to Google's trajectory from its very beginnings in her garage.

