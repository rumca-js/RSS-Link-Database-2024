# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Polityczna scena rozgrzana po walce Szeremety. Sypią się gratulacje
 - [https://wydarzenia.interia.pl/zagranica/news-polityczna-scena-rozgrzana-po-walce-szeremety-sypia-sie-grat,nId,7755183](https://wydarzenia.interia.pl/zagranica/news-polityczna-scena-rozgrzana-po-walce-szeremety-sypia-sie-grat,nId,7755183)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T20:28:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polityczna-scena-rozgrzana-po-walce-szeremety-sypia-sie-grat,nId,7755183"><img align="left" alt="Polityczna scena rozgrzana po walce Szeremety. Sypią się gratulacje" src="https://i.iplsc.com/polityczna-scena-rozgrzana-po-walce-szeremety-sypia-sie-grat/000JLPWKJ9PRSNWL-C321.jpg" /></a>Julia Szeremeta zdobyła srebrny medal igrzysk w Paryżu w bokserskiej kat. 57 kg po porażce w finale z Tajwanką Yu Ting Lin. Po walce media społecznościowe zalała fala gratulacji. &quot; Takie walki zapadają w pamięć! Dla nas każda runda była mistrzowska&quot; - napisał szef MON Władysław Kosiniak Kamysz. </p><br clear="all" />

## Atak Ukrainy w Rosji. Amerykanie: Próbujemy lepiej zrozumieć, co robią
 - [https://wydarzenia.interia.pl/zagranica/news-atak-ukrainy-w-rosji-amerykanie-probujemy-lepiej-zrozumiec-c,nId,7755179](https://wydarzenia.interia.pl/zagranica/news-atak-ukrainy-w-rosji-amerykanie-probujemy-lepiej-zrozumiec-c,nId,7755179)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T20:07:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-atak-ukrainy-w-rosji-amerykanie-probujemy-lepiej-zrozumiec-c,nId,7755179"><img align="left" alt="Atak Ukrainy w Rosji. Amerykanie: Próbujemy lepiej zrozumieć, co robią" src="https://i.iplsc.com/atak-ukrainy-w-rosji-amerykanie-probujemy-lepiej-zrozumiec-c/000JLPRK2G7LE8WX-C321.jpg" /></a>Próbujemy lepiej zrozumieć, co robią, jakie są ich cele, jaka jest ich strategia - przekazał rzecznik Rady Bezpieczeństwa Narodowego John Kirby, mówiąc o ataku Ukrainy na rosyjski obwód kurski. Podczas konferencji był pytany także o użycie amerykańskiej broni przez Ukrainę w Rosji. - Nie ma zmian w naszej polityce - zaznaczył.</p><br clear="all" />

## Chcą skonfiskować fortunę byłego premiera Ukrainy. Nowa inicjatywa USA
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-chca-skonfiskowac-fortune-bylego-premiera-ukrainy-nowa-inicj,nId,7755152](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-chca-skonfiskowac-fortune-bylego-premiera-ukrainy-nowa-inicj,nId,7755152)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T19:40:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-chca-skonfiskowac-fortune-bylego-premiera-ukrainy-nowa-inicj,nId,7755152"><img align="left" alt="Chcą skonfiskować fortunę byłego premiera Ukrainy. Nowa inicjatywa USA" src="https://i.iplsc.com/chca-skonfiskowac-fortune-bylego-premiera-ukrainy-nowa-inicj/000JLPL95TP3CHEH-C321.jpg" /></a>Resort sprawiedliwości USA próbuje skonfiskować 200 mln dolarów skradzionych przez byłego ukraińskiego premiera Pawło Łazarenkę i przejętych przez sądy w rajach podatkowych, gdzie je ukrywał. Amerykanie chcą przekazać pieniądze władzom w Kijowie. Ukraina pogrążona w wojnie rozpętanej przez Rosję znajduje się w trudnej sytuacji finansowej. </p><br clear="all" />

## Białoruś przerzuca siły bliżej granicy z Ukrainą. "Próba pomocy Putinowi"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-bialorus-przerzuca-sily-blizej-granicy-z-ukraina-proba-pomoc,nId,7755140](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-bialorus-przerzuca-sily-blizej-granicy-z-ukraina-proba-pomoc,nId,7755140)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T19:22:03+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-bialorus-przerzuca-sily-blizej-granicy-z-ukraina-proba-pomoc,nId,7755140"><img align="left" alt="Białoruś przerzuca siły bliżej granicy z Ukrainą. &quot;Próba pomocy Putinowi&quot;" src="https://i.iplsc.com/bialorus-przerzuca-sily-blizej-granicy-z-ukraina-proba-pomoc/000JLPOYGDKNNCSW-C321.jpg" /></a>Alaksandr Łukaszenka nakazał wzmocnienie sił zbrojnych wzdłuż granicy z ukraińskimi obwodami: kijowskim i czernihowskim. Przerzut sił obejmuje wysłanie jednostek sił specjalnych, lądowych i rakietowych w tym wyrzutni Polonez i Iskander. Jeden z ukraińskich urzędników nie ma wątpliwości - taki ruch ma pomóc Putinowi w obliczu ataku na teren Rosji i odwrócić uwagę Ukraińców.
</p><br clear="all" />

## Na Bałtyku rozpęta się sztorm. IMGW alarmuje. "Śmiertelne zagrożenie"
 - [https://wydarzenia.interia.pl/kraj/news-na-baltyku-rozpeta-sie-sztorm-imgw-alarmuje-smiertelne-zagro,nId,7755157](https://wydarzenia.interia.pl/kraj/news-na-baltyku-rozpeta-sie-sztorm-imgw-alarmuje-smiertelne-zagro,nId,7755157)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T18:51:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-na-baltyku-rozpeta-sie-sztorm-imgw-alarmuje-smiertelne-zagro,nId,7755157"><img align="left" alt="Na Bałtyku rozpęta się sztorm. IMGW alarmuje. &quot;Śmiertelne zagrożenie&quot;" src="https://i.iplsc.com/na-baltyku-rozpeta-sie-sztorm-imgw-alarmuje-smiertelne-zagro/000JLPNUMXSA05RD-C321.jpg" /></a>Instytut Meteorologii i Gospodarki Wodnej ostrzega przed sztormem na Bałtyku. Prędkość wiatru może osiągnąć 9 stopni w skali Beauforta. IMGW wskazuje, że warunki do żeglowania przez weekend będą bardzo trudne. 
</p><br clear="all" />

## Tysiące turystów lekceważy ostrzeżenia. Alarmujące dane ze szpitali
 - [https://wydarzenia.interia.pl/zagranica/news-tysiace-turystow-lekcewazy-ostrzezenia-alarmujace-dane-ze-sz,nId,7755097](https://wydarzenia.interia.pl/zagranica/news-tysiace-turystow-lekcewazy-ostrzezenia-alarmujace-dane-ze-sz,nId,7755097)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T18:05:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tysiace-turystow-lekcewazy-ostrzezenia-alarmujace-dane-ze-sz,nId,7755097"><img align="left" alt="Tysiące turystów lekceważy ostrzeżenia. Alarmujące dane ze szpitali" src="https://i.iplsc.com/tysiace-turystow-lekcewazy-ostrzezenia-alarmujace-dane-ze-sz/000JLPF04DHDF321-C321.jpg" /></a>Coraz więcej turystów, zwłaszcza zagranicznych, trafia do szpitali w Rzymie z powodu upałów - alarmują lekarze. Najczęściej są w stanie odwodnienia i przegrzania organizmu. Jako jeden z głównych czynników ryzyka medycy wskazują oczekiwanie w długich kolejkach w trakcie zwiedzania, choć eksperci alarmują, by unikać przebywania na słońcu. Oblężenie przeżywają także szpitale w innych włoskich miastach.</p><br clear="all" />

## Kamiński grzmi ws. rosyjskiego szpiega. "KE skompromitowała się"
 - [https://wydarzenia.interia.pl/zagranica/news-kaminski-grzmi-ws-rosyjskiego-szpiega-ke-skompromitowala-sie,nId,7755130](https://wydarzenia.interia.pl/zagranica/news-kaminski-grzmi-ws-rosyjskiego-szpiega-ke-skompromitowala-sie,nId,7755130)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T17:47:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kaminski-grzmi-ws-rosyjskiego-szpiega-ke-skompromitowala-sie,nId,7755130"><img align="left" alt="Kamiński grzmi ws. rosyjskiego szpiega. &quot;KE skompromitowała się&quot;" src="https://i.iplsc.com/kaminski-grzmi-ws-rosyjskiego-szpiega-ke-skompromitowala-sie/000JLPDJM73W9JY9-C321.jpg" /></a>&quot;Komisja Europejska skompromitowała się, atakując Polskę w swoim raporcie na temat 'praworządności'&quot; - ocenił europoseł, polityk PiS Mariusz Kamiński. Sprawa dotyczy rosyjskiego szpiega Pablo Goznaleza, którego nazwisko pojawia się w raporcie dla zobrazowania sytuacji w Polsce, gdzie &quot;dziennikarze w dalszym ciągu napotykają trudności w wykonywaniu swojej pracy&quot;. Goznalez, a właściwie rosyjski agent wywiadu wojskowego GRU Paweł Rubcow, był jednym z więźniów objętych ostatnią wymianą między Rosją a Zachodem.</p><br clear="all" />

## Prezydent Serbii o ryzyku "zamachu stanu". "Poinformowali mnie Rosjanie"
 - [https://wydarzenia.interia.pl/zagranica/news-prezydent-serbii-o-ryzyku-zamachu-stanu-poinformowali-mnie-r,nId,7755131](https://wydarzenia.interia.pl/zagranica/news-prezydent-serbii-o-ryzyku-zamachu-stanu-poinformowali-mnie-r,nId,7755131)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T17:14:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezydent-serbii-o-ryzyku-zamachu-stanu-poinformowali-mnie-r,nId,7755131"><img align="left" alt="Prezydent Serbii o ryzyku &quot;zamachu stanu&quot;. &quot;Poinformowali mnie Rosjanie&quot;" src="https://i.iplsc.com/prezydent-serbii-o-ryzyku-zamachu-stanu-poinformowali-mnie-r/000IYMBE0QO9AL61-C321.jpg" /></a>- Służby rosyjskie poinformowały mnie o planowanym w Serbii zamachu stanu - powiedział serbski prezydent Aleksandar Vuczić cytowany w sobotę przez telewizję N1. Jak dodał, powołując się na doniesienia Rosjan, w jego kraju przygotowywane mają być zamieszki, których celem jest &quot;doprowadzenie do siłowego przejęcia władzy&quot;.

</p><br clear="all" />

## Pilnie wzywają ukraińskiego przedstawiciela. Białoruś wysuwa żądania
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-pilnie-wzywaja-ukrainskiego-przedstawiciela-bialorus-wysuwa-,nId,7755142](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-pilnie-wzywaja-ukrainskiego-przedstawiciela-bialorus-wysuwa-,nId,7755142)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T17:04:31+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-pilnie-wzywaja-ukrainskiego-przedstawiciela-bialorus-wysuwa-,nId,7755142"><img align="left" alt="Pilnie wzywają ukraińskiego przedstawiciela. Białoruś wysuwa żądania" src="https://i.iplsc.com/pilnie-wzywaja-ukrainskiego-przedstawiciela-bialorus-wysuwa/000HA791N14JDBDY-C321.jpg" /></a>Białoruskie MSZ wezwało ukraińskiego chargé d’affaires w związku z naruszeniem przestrzeni powietrznej - informuje Reuters. Szef resortu zapowiedział, że w &quot;przypadku powtórzenia się prowokacji strona białoruska zastrzega sobie prawo do podjęcia kroków odwetowych w celu obrony swojego terytorium&quot;. Wcześniej Alaksandr Łukaszenka alarmował o rzekomym naruszeniu przestrzeni powietrznej przez ukraińskie drony na terenie swojego kraju.</p><br clear="all" />

## Tragedia na drodze w Lubelskiem. Uderzyła w tira, zginęła na miejscu
 - [https://wydarzenia.interia.pl/lubelskie/news-tragedia-na-drodze-w-lubelskiem-uderzyla-w-tira-zginela-na-m,nId,7755123](https://wydarzenia.interia.pl/lubelskie/news-tragedia-na-drodze-w-lubelskiem-uderzyla-w-tira-zginela-na-m,nId,7755123)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-08-10T16:33:50+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-tragedia-na-drodze-w-lubelskiem-uderzyla-w-tira-zginela-na-m,nId,7755123"><img align="left" alt="Tragedia na drodze w Lubelskiem. Uderzyła w tira, zginęła na miejscu" src="https://i.iplsc.com/tragedia-na-drodze-w-lubelskiem-uderzyla-w-tira-zginela-na-m/000JLPDR9WR4B73T-C321.jpg" /></a>Tragiczny wypadek na drodze krajowej nr 12 w Lubelskiem. Po zderzeniu auta osobowego z ciężarówką w Tytusinie życie straciła kobieta. W wypadku poszkodowane zostało także podróżujące z nią dziecko. Służby przetransportowały je śmigłowcem LPR do szpitala. Kierowca tira był trzeźwy.</p><br clear="all" />

