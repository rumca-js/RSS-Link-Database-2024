# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 20 Best Space Games That LET YOU EXPLORE & BUILD
 - [https://www.youtube.com/watch?v=S_GZnYRj1ro](https://www.youtube.com/watch?v=S_GZnYRj1ro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-08-10T17:00:16+00:00

If you love space games, we've got 20 great ones for you...whether you're building, fighting, or exploring!
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1     


0:00 Intro 
0:20 Deliver Us The Moon
1:22 FTL: Faster Than Light      
2:22 Homeworld 3 Remastered Collection 
3:19 The Universim  
4:06 Breathedge 
4:54 Chorus   
5:38 Stellaris
6:22 Moonbase Alpha      
7:07 Astroneer        
7:40 Kerbal Space Program       
8:36 Endless Space 2        
9:10 Everspace 2         
9:50 Hardspace Shipbreaker 
10:37 Surviving Mars 
11:16 Starfield      
12:06 Outer Wilds      
12:57 Eve Online    
12:40 Elite Dangerous        
14:23 Mass Effect Legendary Edition       
15:26 No Man’s Sky

## 20 Traps That CAUGHT MILLIONS of Cheaters
 - [https://www.youtube.com/watch?v=SIyJB7H4ntI](https://www.youtube.com/watch?v=SIyJB7H4ntI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-08-10T15:00:25+00:00

Cheaters in video games sometimes get caught. Here are some examples of traps set for cheaters by the game makers.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1     


0:00 Intro
0:23 Number 20
1:23 Number 19
2:30 Number 18
4:20 Number 17
5:25 Number 16
6:44 Number 15
8:56 Number 14
10:15 Number 13
11:31 Number 12
12:55 Number 11
13:52 Number 10
15:14 Number 9
16:08 Number 8
17:27 Number 7
18:15 Number 6
19:36 Number 5
20:35 Number 4
21:41 Number 3
22:39 Number 2
23:36 Number 1

