# Source:404 Media, URL:https://www.404media.co/rss, language:en

## DEF CON Badge Maker Pulled Off Stage Amid Claims of Non-Payment and Failed Work
 - [https://www.404media.co/def-con-badge-maker-pulled-off-stage-amid-claims-of-non-payment-and-failed-work](https://www.404media.co/def-con-badge-maker-pulled-off-stage-amid-claims-of-non-payment-and-failed-work)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-08-10T20:06:57+00:00

Entropic Engineering, the small company that helped manufacture this year’s DEF CON badge, claims the conference organizers failed to pay for completed work. DEF CON says the company went well over budget.

