# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## The First Refugee to Win an Olympic Medal #olympics #refugees
 - [https://www.youtube.com/watch?v=IPtEYTY0pZE](https://www.youtube.com/watch?v=IPtEYTY0pZE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2024-08-10T17:15:35+00:00

Cindy Ngamba becomes the first refugee to win an Olympic medal 🏅

