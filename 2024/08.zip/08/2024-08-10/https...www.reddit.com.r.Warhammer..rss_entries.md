# Source:All things Warhammer!, URL:https://www.reddit.com/r/Warhammer/.rss, language:en

## Claw Lord on Gnawbeast!
 - [https://www.reddit.com/r/Warhammer/comments/1ep53ax/claw_lord_on_gnawbeast](https://www.reddit.com/r/Warhammer/comments/1ep53ax/claw_lord_on_gnawbeast)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T22:25:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1ep53ax/claw_lord_on_gnawbeast/"> <img alt="Claw Lord on Gnawbeast! " src="https://b.thumbs.redditmedia.com/5zkQLKc_CukaUjQSKthLHCtzdyPGmn16vNIqPmGgZdc.jpg" title="Claw Lord on Gnawbeast! " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dchsknight"> /u/dchsknight </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep53ax">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1ep53ax/claw_lord_on_gnawbeast/">[comments]</a></span> </td></tr></table>

## What's happened with massive increase painting quality?
 - [https://www.reddit.com/r/Warhammer/comments/1ep444g/whats_happened_with_massive_increase_painting](https://www.reddit.com/r/Warhammer/comments/1ep444g/whats_happened_with_massive_increase_painting)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T21:39:55+00:00

<!-- SC_OFF --><div class="md"><p>I first got I to WH in the 90s and now just read lore and TWWH but seeing the state of the mini painting in here, has technology or something come on leaps and bounds recently? I see these minis gorgeously painted on here and without exaggerating most are significantly better than any of the Golden Demon winners I used to see in White Dwarf back in the day. Just seeing the Swamp tank and the red and black fade theme ones and they're better than any I remember back then. There was one post where he showed an improvement over six months from a decent Space marine to an almost expertly shaded and highlighted one. They're better than the professional GW staff painters from the 90s. What's changed? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Correct_Horror_NZ"> /u/Correct_Horror_NZ </a> <br /> <span><a href="https://www.reddit.com/r/Warhammer/comments/1ep444g/whats_happened_with_massive_increase_painting/">[link]

## Gobbos
 - [https://www.reddit.com/r/Warhammer/comments/1ep3wsj/gobbos](https://www.reddit.com/r/Warhammer/comments/1ep3wsj/gobbos)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T21:30:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1ep3wsj/gobbos/"> <img alt="Gobbos" src="https://b.thumbs.redditmedia.com/FjlZJ3lkMaxcShfBLaY0jH4j1b56JB8kIu7Rmybprwk.jpg" title="Gobbos" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>These lads were fun! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BrimstoneOmega"> /u/BrimstoneOmega </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep3wsj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1ep3wsj/gobbos/">[comments]</a></span> </td></tr></table>

## Is making your own chaos god allowed?
 - [https://www.reddit.com/r/Warhammer/comments/1ep1zxs/is_making_your_own_chaos_god_allowed](https://www.reddit.com/r/Warhammer/comments/1ep1zxs/is_making_your_own_chaos_god_allowed)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T20:02:41+00:00

<!-- SC_OFF --><div class="md"><p>I have a cool idea for a renegade chapter but it doesn’t really fit with any of the main 4 gods so I was wondering if stuff like making your own chaos gods is ok or not?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/parmesan24"> /u/parmesan24 </a> <br /> <span><a href="https://www.reddit.com/r/Warhammer/comments/1ep1zxs/is_making_your_own_chaos_god_allowed/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1ep1zxs/is_making_your_own_chaos_god_allowed/">[comments]</a></span>

## Custom kitbashed minis for killteam
 - [https://www.reddit.com/r/Warhammer/comments/1ep1cxp/custom_kitbashed_minis_for_killteam](https://www.reddit.com/r/Warhammer/comments/1ep1cxp/custom_kitbashed_minis_for_killteam)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T19:33:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1ep1cxp/custom_kitbashed_minis_for_killteam/"> <img alt="Custom kitbashed minis for killteam" src="https://a.thumbs.redditmedia.com/75QTlBy6ebl2X21WSLdYhllOtTTyq7vnT1sq5YI9554.jpg" title="Custom kitbashed minis for killteam" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Loadouts not necessarily legal but just to look cool</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/gryffon_skull_minis"> /u/gryffon_skull_minis </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep1cxp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1ep1cxp/custom_kitbashed_minis_for_killteam/">[comments]</a></span> </td></tr></table>

## In honor of our great victory! He's done!
 - [https://www.reddit.com/r/Warhammer/comments/1eozpra/in_honor_of_our_great_victory_hes_done](https://www.reddit.com/r/Warhammer/comments/1eozpra/in_honor_of_our_great_victory_hes_done)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T18:20:12+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Sengel123"> /u/Sengel123 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eozn9i">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eozpra/in_honor_of_our_great_victory_hes_done/">[comments]</a></span>

## New Kill Team?
 - [https://www.reddit.com/r/Warhammer/comments/1eozgy3/new_kill_team](https://www.reddit.com/r/Warhammer/comments/1eozgy3/new_kill_team)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T18:09:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eozgy3/new_kill_team/"> <img alt="New Kill Team?" src="https://external-preview.redd.it/tJrzY6Rm-dxMFnvKl5FccxpmAIuPAFDyQa8THp9dfCk.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=f449ad628a11fb9c51deb8bd05ac0595384abf22" title="New Kill Team?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LongWarVet"> /u/LongWarVet </a> <br /> <span><a href="https://m.youtube.com/watch?v=OaB45hpW6GA">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eozgy3/new_kill_team/">[comments]</a></span> </td></tr></table>

## Some rust effect tests for my Iron Warriors. Do you have any other tips and experiences?
 - [https://www.reddit.com/r/Warhammer/comments/1eoyuwo/some_rust_effect_tests_for_my_iron_warriors_do](https://www.reddit.com/r/Warhammer/comments/1eoyuwo/some_rust_effect_tests_for_my_iron_warriors_do)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T17:43:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eoyuwo/some_rust_effect_tests_for_my_iron_warriors_do/"> <img alt="Some rust effect tests for my Iron Warriors. Do you have any other tips and experiences?" src="https://preview.redd.it/wd12ljqpivhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=581d0ed59430ef6e7b142a51adc2880484286503" title="Some rust effect tests for my Iron Warriors. Do you have any other tips and experiences?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Eliphor"> /u/Eliphor </a> <br /> <span><a href="https://i.redd.it/wd12ljqpivhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoyuwo/some_rust_effect_tests_for_my_iron_warriors_do/">[comments]</a></span> </td></tr></table>

## Finally getting back to painting, also starting to learn to play the game! Check out my Praetor Prime!
 - [https://www.reddit.com/r/Warhammer/comments/1eoyrrr/finally_getting_back_to_painting_also_starting_to](https://www.reddit.com/r/Warhammer/comments/1eoyrrr/finally_getting_back_to_painting_also_starting_to)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T17:39:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eoyrrr/finally_getting_back_to_painting_also_starting_to/"> <img alt="Finally getting back to painting, also starting to learn to play the game! Check out my Praetor Prime!" src="https://b.thumbs.redditmedia.com/ECrFAdcdu6B0phLyycQ24Lyhrf3L65zD4a7B6iFV2yI.jpg" title="Finally getting back to painting, also starting to learn to play the game! Check out my Praetor Prime!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IndianaScones1999"> /u/IndianaScones1999 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoyrrr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoyrrr/finally_getting_back_to_painting_also_starting_to/">[comments]</a></span> </td></tr></table>

## Vampire Lord on Zombie Dragon
 - [https://www.reddit.com/r/Warhammer/comments/1eoyrnp/vampire_lord_on_zombie_dragon](https://www.reddit.com/r/Warhammer/comments/1eoyrnp/vampire_lord_on_zombie_dragon)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T17:39:10+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/LadyAmarell"> /u/LadyAmarell </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoyrcg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoyrnp/vampire_lord_on_zombie_dragon/">[comments]</a></span>

## The triumph is finished!
 - [https://www.reddit.com/r/Warhammer/comments/1eoxids/the_triumph_is_finished](https://www.reddit.com/r/Warhammer/comments/1eoxids/the_triumph_is_finished)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T16:45:24+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/IsThisUsernameFree"> /u/IsThisUsernameFree </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoxi33">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoxids/the_triumph_is_finished/">[comments]</a></span>

## Better look at some new minis + cover art for Skaven Battletome
 - [https://www.reddit.com/r/Warhammer/comments/1eoxdee/better_look_at_some_new_minis_cover_art_for](https://www.reddit.com/r/Warhammer/comments/1eoxdee/better_look_at_some_new_minis_cover_art_for)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T16:39:30+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/talamantis"> /u/talamantis </a> <br /> <span><a href="https://www.reddit.com/gallery/1eox1gg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoxdee/better_look_at_some_new_minis_cover_art_for/">[comments]</a></span>

## A lonely Adeptus Arbites
 - [https://www.reddit.com/r/Warhammer/comments/1eoxdda/a_lonely_adeptus_arbites](https://www.reddit.com/r/Warhammer/comments/1eoxdda/a_lonely_adeptus_arbites)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T16:39:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eoxdda/a_lonely_adeptus_arbites/"> <img alt="A lonely Adeptus Arbites" src="https://preview.redd.it/xqw6qgy97vhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4b2470b03fbca6c5536ae98bebb45bd60a782a9e" title="A lonely Adeptus Arbites" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MobileAlfalfa"> /u/MobileAlfalfa </a> <br /> <span><a href="https://i.redd.it/xqw6qgy97vhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoxdda/a_lonely_adeptus_arbites/">[comments]</a></span> </td></tr></table>

## Best warhammer range, best warhammer race, yes-yes
 - [https://www.reddit.com/r/Warhammer/comments/1eoxaed/best_warhammer_range_best_warhammer_race_yesyes](https://www.reddit.com/r/Warhammer/comments/1eoxaed/best_warhammer_range_best_warhammer_race_yesyes)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T16:35:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eoxaed/best_warhammer_range_best_warhammer_race_yesyes/"> <img alt="Best warhammer range, best warhammer race, yes-yes" src="https://b.thumbs.redditmedia.com/Glaf6q7IQU-X6-UIiqMUNSBcZeazylu8LgQiqvHPYAw.jpg" title="Best warhammer range, best warhammer race, yes-yes" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Altruistic-Teach5899"> /u/Altruistic-Teach5899 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoxaed">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoxaed/best_warhammer_range_best_warhammer_race_yesyes/">[comments]</a></span> </td></tr></table>

## New Skaven models! the rats won Hel Crown
 - [https://www.reddit.com/r/Warhammer/comments/1eowojx/new_skaven_models_the_rats_won_hel_crown](https://www.reddit.com/r/Warhammer/comments/1eowojx/new_skaven_models_the_rats_won_hel_crown)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T16:09:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eowojx/new_skaven_models_the_rats_won_hel_crown/"> <img alt="New Skaven models! the rats won Hel Crown" src="https://b.thumbs.redditmedia.com/K5rBf-hoPyYWdzpTAA4QRG6eBFoQy1vPvcEt09dHXCc.jpg" title="New Skaven models! the rats won Hel Crown" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/spider-venomized"> /u/spider-venomized </a> <br /> <span><a href="https://www.reddit.com/gallery/1eowojx">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eowojx/new_skaven_models_the_rats_won_hel_crown/">[comments]</a></span> </td></tr></table>

## My custom Night Lords Daemon Prince brought to life.
 - [https://www.reddit.com/r/Warhammer/comments/1eowa0u/my_custom_night_lords_daemon_prince_brought_to](https://www.reddit.com/r/Warhammer/comments/1eowa0u/my_custom_night_lords_daemon_prince_brought_to)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T15:52:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eowa0u/my_custom_night_lords_daemon_prince_brought_to/"> <img alt="My custom Night Lords Daemon Prince brought to life." src="https://b.thumbs.redditmedia.com/xhsxyBKLCQCssB7m2YGQb-48XnPplOBSGbpgGdcIGTU.jpg" title="My custom Night Lords Daemon Prince brought to life." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Model by @Joshpmcd on instagram, Art by <a href="https://grohgrog.artstation.com/">https://grohgrog.artstation.com/</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ProphetVIII"> /u/ProphetVIII </a> <br /> <span><a href="https://www.reddit.com/gallery/1eowa0u">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eowa0u/my_custom_night_lords_daemon_prince_brought_to/">[comments]</a></span> </td></tr></table>

## Reuplusor Done ❌⚜️❌
 - [https://www.reddit.com/r/Warhammer/comments/1eovw0x/reuplusor_done](https://www.reddit.com/r/Warhammer/comments/1eovw0x/reuplusor_done)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T15:35:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eovw0x/reuplusor_done/"> <img alt="Reuplusor Done ❌⚜️❌" src="https://b.thumbs.redditmedia.com/XHg98lzrav1KRIwNkZSTF1noObwgUfE37NQQIH2tmzE.jpg" title="Reuplusor Done ❌⚜️❌" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>❌⚜️❌ Impulsor done ! ❌⚜️❌</p> <p>First battletest i'll bring the good old Bladeguards + Judicar, but as a lot of you wisely adviced i'll try Incursors for scout, grenade/shoot/haywire mine, and lieutenant + Hellblasters !</p> <p>See you soon for the big reclusiam kitbash Project 😁</p> <p>Instagram @captaingastustudio <a href="https://www.instagram.com/captaingatsustudio?igsh=YjIwajdrbzNibHpw">https://www.instagram.com/captaingatsustudio?igsh=YjIwajdrbzNibHpw</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Demonic_Tutor_22"> /u/Demonic_Tutor_22 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eovw0x">[link]</a></span> &#32; <span><a href="https:

## Lumineth Vanari Sentinels
 - [https://www.reddit.com/r/Warhammer/comments/1eov707/lumineth_vanari_sentinels](https://www.reddit.com/r/Warhammer/comments/1eov707/lumineth_vanari_sentinels)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T15:05:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eov707/lumineth_vanari_sentinels/"> <img alt="Lumineth Vanari Sentinels" src="https://preview.redd.it/oee4pg1mquhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9847a82cae2cfdf3a6028366e0c38ef7e5e49670" title="Lumineth Vanari Sentinels" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/A_Simple_Peach"> /u/A_Simple_Peach </a> <br /> <span><a href="https://i.redd.it/oee4pg1mquhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eov707/lumineth_vanari_sentinels/">[comments]</a></span> </td></tr></table>

## Has anyone gotten the wrong sprue in a box before?
 - [https://www.reddit.com/r/Warhammer/comments/1eot4or/has_anyone_gotten_the_wrong_sprue_in_a_box_before](https://www.reddit.com/r/Warhammer/comments/1eot4or/has_anyone_gotten_the_wrong_sprue_in_a_box_before)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T13:32:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eot4or/has_anyone_gotten_the_wrong_sprue_in_a_box_before/"> <img alt="Has anyone gotten the wrong sprue in a box before? " src="https://preview.redd.it/8yy76b2y9uhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d600d62ec68342daaf984cb0df83f68e9f0fb0f2" title="Has anyone gotten the wrong sprue in a box before? " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Picked up my first box of warhammer in over 4 years and it's missing the sprue I need and double the same one up. I'm a little upset about it.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RoninWargaming"> /u/RoninWargaming </a> <br /> <span><a href="https://i.redd.it/8yy76b2y9uhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eot4or/has_anyone_gotten_the_wrong_sprue_in_a_box_before/">[comments]</a></span> </td></tr></table>

## Is there any tutorial from this artist? Or similar (not my image)
 - [https://www.reddit.com/r/Warhammer/comments/1eoshc4/is_there_any_tutorial_from_this_artist_or_similar](https://www.reddit.com/r/Warhammer/comments/1eoshc4/is_there_any_tutorial_from_this_artist_or_similar)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T13:00:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eoshc4/is_there_any_tutorial_from_this_artist_or_similar/"> <img alt="Is there any tutorial from this artist? Or similar (not my image)" src="https://preview.redd.it/nog4r5za4uhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b34c3e7911a22d959b02e702311d32f6876fcd9f" title="Is there any tutorial from this artist? Or similar (not my image)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I have kept a white dwarf issue 483 for ages all down to one picture that I am inspired to try to paint from. </p> <p>The artist is Matt Seymour. Yhr image taken is from page 57</p> <p>I love this peice and think it's so well done but other then this magazine I have seen nothing else from the person. </p> <p>Any idea who it is and any link to a tutorial by them or similar information on how to get these amazing results. It just pops so much. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/u

## First tank added to my Swamperial Guard army
 - [https://www.reddit.com/r/Warhammer/comments/1eorvzb/first_tank_added_to_my_swamperial_guard_army](https://www.reddit.com/r/Warhammer/comments/1eorvzb/first_tank_added_to_my_swamperial_guard_army)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T12:30:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eorvzb/first_tank_added_to_my_swamperial_guard_army/"> <img alt="First tank added to my Swamperial Guard army " src="https://b.thumbs.redditmedia.com/oGqfaaIOC7s6MRfrBIeqRUGrCSQrSrSiQLyNcfRxSeE.jpg" title="First tank added to my Swamperial Guard army " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SwampRatMiniatures"> /u/SwampRatMiniatures </a> <br /> <span><a href="https://www.reddit.com/gallery/1eorvzb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eorvzb/first_tank_added_to_my_swamperial_guard_army/">[comments]</a></span> </td></tr></table>

## What is a soldier without war?
 - [https://www.reddit.com/r/Warhammer/comments/1eoqb8b/what_is_a_soldier_without_war](https://www.reddit.com/r/Warhammer/comments/1eoqb8b/what_is_a_soldier_without_war)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T10:59:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eoqb8b/what_is_a_soldier_without_war/"> <img alt="What is a soldier without war?" src="https://a.thumbs.redditmedia.com/D9RY2AeNWuv-kqSOYykliGu1f6HF1uUHk2G1VaF46P4.jpg" title="What is a soldier without war?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Brunstan"> /u/Brunstan </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoqb8b">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoqb8b/what_is_a_soldier_without_war/">[comments]</a></span> </td></tr></table>

## Blood Angels Eradicators
 - [https://www.reddit.com/r/Warhammer/comments/1eoi085/blood_angels_eradicators](https://www.reddit.com/r/Warhammer/comments/1eoi085/blood_angels_eradicators)
 - RSS feed: https://www.reddit.com/r/Warhammer/.rss
 - date published: 2024-08-10T02:24:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer/comments/1eoi085/blood_angels_eradicators/"> <img alt="Blood Angels Eradicators" src="https://b.thumbs.redditmedia.com/siLh85ECqWVl5-4NdboEET2GsW9VzYe0hUVJkfAZqzM.jpg" title="Blood Angels Eradicators" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/warpainter_o_o"> /u/warpainter_o_o </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoi085">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer/comments/1eoi085/blood_angels_eradicators/">[comments]</a></span> </td></tr></table>

