# Source:Eurogamer.net Latest Articles Feed, URL:https://www.eurogamer.net/feed, language:en-gb

## PlayStation is introducing user reviews on the PS Store
 - [https://www.eurogamer.net/playstation-is-introducing-user-reviews-on-the-ps-store](https://www.eurogamer.net/playstation-is-introducing-user-reviews-on-the-ps-store)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-10T21:00:26+00:00

<img src="https://assetsio.gnwcdn.com/Helldivers-2-art.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>It looks like PlayStation is introducing user reviews on the PS Store.</p><p>In a thread entitled "When did PlayStation start allowing written reviews?", an eagle-eyed PS5 owner noted on the PlayStation subreddit that the company was inviting user reviews for a select number of games.</p><p>Whilst fans have long been able to rate games from zero to five stars out of five, this is the first time players have been invited to leave a written review.</p> <p><a href="https://www.eurogamer.net/playstation-is-introducing-user-reviews-on-the-ps-store">Read more</a></p>

## Call of Duty Black Ops 6's campaign cutscenes have leaked online
 - [https://www.eurogamer.net/call-of-duty-black-ops-6s-campaign-cutscenes-have-leaked-online](https://www.eurogamer.net/call-of-duty-black-ops-6s-campaign-cutscenes-have-leaked-online)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-10T20:41:19+00:00

<img src="https://assetsio.gnwcdn.com/BO6_Campaign_Capitol-Station_02.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Brace yourself, Call of Duty fans - it seems the cinematics from Black Ops 6's single-player campaign have leaked online.</p><p>Just like last week, <a href="https://www.eurogamer.net/call-of-duty-black-ops-6-images-leak-online-including-multiplayer-maps-and-menu-screens">when multiplayer images leaked</a>, the video was hit with copyright claims from Activision within hours, intimating that it's authentic.</p><p>According to <a href="https://insider-gaming.com/black-ops-6-campaign-leaked/">InsiderGaming</a>, the cutscenes - which did not have audible sound - were "extracted from the beta build of Black Ops 6", after some players managed to access the beta ahead of its formal release via jailbroken PS4 consoles.</p> <p><a href="https://www.eurogamer.net/call-of-duty-black-ops-6s-campaign-cutscenes-have-leaked-online">Rea

## Fallout London's volunteer modding team to launch as a new indie studio
 - [https://www.eurogamer.net/fallout-londons-volunteer-modding-team-to-launch-as-a-new-indie-studio](https://www.eurogamer.net/fallout-londons-volunteer-modding-team-to-launch-as-a-new-indie-studio)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-10T14:20:03+00:00

<img src="https://assetsio.gnwcdn.com/Untitled-1_ObOWV39.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Team Folon &ndash; the volunteer squad of developers who have released the ambitious <a href="https://www.eurogamer.net/fallout-4-walkthrough-and-guide-4019">Fallout 4</a> mod, Fallout London &ndash; is set to launch itself as a new indie studio.</p><p>Talking to the BBC (via <a href="https://www.pcgamesn.com/fallout-london/developer-new-indie-studio">PCGN</a>), Folon's project lead, Dean Carter, admitted that "as much as I love the fact that this is a free project - that we can offer this thing for free for all the community - free doesn't pay our bills".</p><p>"What has been great for us is that a lot of people who have really enjoyed [Fallout London] have donated to us, and we're channelling that into Team Folon, which is what we're going to be moving into," Carter said.</p> <p><a href="https://www.eurogamer.net/fallout-londons-vo

## GTA 6 won't be on a subscription service on day one because Take-Two's "decisions are rational," says CEO
 - [https://www.eurogamer.net/gta-6-wont-be-on-a-subscription-service-on-day-one-because-take-twos-decisions-are-rational-says-ceo](https://www.eurogamer.net/gta-6-wont-be-on-a-subscription-service-on-day-one-because-take-twos-decisions-are-rational-says-ceo)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-10T13:33:46+00:00

<img src="https://assetsio.gnwcdn.com/Grand-Theft-Auto-VI-Trailer-1-1-9-screenshot.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p><a href="https://www.eurogamer.net/companies/take-two-interactive">Take-Two Interactive</a> boss Strauss Zelnick said the company is not tempted to put its game on subscription services like Xbox Game Pass on day one because "our decisions are rational".</p><p>Talking to our sister site <a href="http://gamesindustry.biz/">GamesIndustry.biz</a>, Zelnick said that whilst he accepted "offering a frontline title with a premium price in a subscription service, day and date, will push consumers to that subscription service for at least a period of time", "it won't affect [Take-Two's] decisions [not to offer AAA games on subscription services on day one]".</p><p>With "15 immersive core" games on Take-Two's books for 2026 and 2027 - one of which is <a href="https://www.eurogamer.net/gta-6-everything-we-know-so-far-9

## Can video games match the warmth of summer? No, but an Odyssey and a Wildlife Adventure are the next best thing
 - [https://www.eurogamer.net/can-video-games-match-the-warmth-of-summer-no-but-an-odyssey-and-a-wildlife-adventure-are-the-next-best-thing](https://www.eurogamer.net/can-video-games-match-the-warmth-of-summer-no-but-an-odyssey-and-a-wildlife-adventure-are-the-next-best-thing)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-08-10T09:00:00+00:00

<img src="https://assetsio.gnwcdn.com/odyssey2.jpeg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>I was born in the UK, and I've lived all my life here, but I've never quite been able to reconcile myself with the weather.</p><p>Most of the year passes in a grey, eternally chilly manner, often paying host to a weak drizzle of rain. The sun is simply known as a stranger in a strange land that visits during summer, but there are no guarantees of that either. I wake up, day after day, to an ashen tone outside the window, and I try to keep myself warm by bundling up under a duvet that I tug up to my chin. Even when it's warm inside, it's still miserable to look out at the grey world through that window, and it gets particularly grim in Autumn, when darkness arrives as early as five o'clock in the afternoon, and soggy leaves and mud cover pavements.</p><p>When we do get real heat and sunshine, however, the feeling is almost indescribable. Life 

