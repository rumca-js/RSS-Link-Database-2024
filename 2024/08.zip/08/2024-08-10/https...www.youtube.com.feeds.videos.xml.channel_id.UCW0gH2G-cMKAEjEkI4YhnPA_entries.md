# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Middle-earth games (& more!) at Gen Con 2024!
 - [https://www.youtube.com/watch?v=Kz50Hhqho3k](https://www.youtube.com/watch?v=Kz50Hhqho3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2024-08-10T16:00:16+00:00

I recently went to Gen Con, the largest tabletop gaming convention in North America!  While there, I saw a lot of Middle-earth games - saw some new ones and caught up on new happenings with classic ones!

The One Ring RPG Moria Expansion: https://amzn.to/3YDHmTq

LOTR Duel for Middle-earth at BoardGameGeek: https://boardgamegeek.com/boardgame/421006/the-lord-of-the-rings-duel-for-middle-earth

LOTR Confrontation: https://gamefound.com/en/projects/ghost-galaxy-games/lord-of-the-rings-the-confrontation-ultimate-edition

MESBG Rise of Angmar News: https://www.warhammer-community.com/2024/08/08/middle-earth-strategy-battle-game-the-rise-of-angmar/

MESBG New Edition & War of the Rohirrim: https://www.warhammer-community.com/2024/08/08/new-edition-of-middle-earth-strategy-battle-game-coming-soon/

Star Wars Unlimited: https://starwarsunlimited.com/

Cosmere RPG: https://www.kickstarter.com/projects/brotherwise/the-stormlight-archive-rpg?ref=section-homepage-view-more-discovery-p1

A huge t

