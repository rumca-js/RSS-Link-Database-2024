# Source:DER SPIEGEL - Schlagzeilen, URL:https://www.spiegel.de/schlagzeilen/index.rss, language:de

## Olympia 2024: Beachvolleyballer Nils Ehlers und Clemens Wickler verlieren Finale - nach starken Turnier
 - [https://www.spiegel.de/sport/olympia/olympia-2024-beachvolleyballer-nils-ehlers-und-clemens-wickler-verlieren-finale-nach-starken-turnier-a-7c2c88bd-345b-4c62-8845-158f9136e479#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-beachvolleyballer-nils-ehlers-und-clemens-wickler-verlieren-finale-nach-starken-turnier-a-7c2c88bd-345b-4c62-8845-158f9136e479#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T22:16:00+00:00

Nils Ehlers und Clemens Wickler spielen erst seit 2021 zusammen, bei großen Ereignissen klappte wenig. Nun kamen sie bis ins Olympiafinale. Auch wenn sie gegen Schweden chancenlos waren, begeisterten sie die Fans.

## Ehrendoktorwürde: Jamie Lee Curtis dankt Regisseur John Carpenter für ihr »ganzes Leben«
 - [https://www.spiegel.de/panorama/leute/ehrendoktorwuerde-jamie-lee-curtis-dankt-regisseur-john-carpenter-fuer-ihr-ganzes-leben-a-9c032ef3-8377-4155-9ea4-7b6173e4ddcc#ref=rss](https://www.spiegel.de/panorama/leute/ehrendoktorwuerde-jamie-lee-curtis-dankt-regisseur-john-carpenter-fuer-ihr-ganzes-leben-a-9c032ef3-8377-4155-9ea4-7b6173e4ddcc#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T22:09:00+00:00

Die Oscarpreisträgerin darf sich ab sofort »Doktor« nennen. In ihrer emotionalen Dankesrede wendet sie sich an den Regisseur, der sie berühmt gemacht hat. Dann verteilt sie gute Ratschläge an die anderen Absolventen.

## Olympia 2024: Alle Medaillen vom Samstag, dem 15. Tag
 - [https://www.spiegel.de/sport/olympia/olympia-2024-alle-medaillen-vom-samstag-dem-15-tag-a-c71da744-e9e7-4cd1-bf4e-c59a9cafe9ff#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-alle-medaillen-vom-samstag-dem-15-tag-a-c71da744-e9e7-4cd1-bf4e-c59a9cafe9ff#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T21:44:00+00:00

Esther Henseleit kämpft sich beim olympischen Golfturnier auf der Schlussrunde auf Platz zwei. Ihre unerwartete Silbermedaille ist historisch. Alle Medaillenentscheidungen des Tages im Überblick.

## Weißes Gold aus Serbien: Tausende demonstrieren gegen Lithium-Abbau im Jadartal
 - [https://www.spiegel.de/ausland/weisses-gold-aus-serbien-tausende-demonstrieren-gegen-lithium-abbau-im-jadartal-a-46a79719-a382-4e5a-8856-1535bef8de29#ref=rss](https://www.spiegel.de/ausland/weisses-gold-aus-serbien-tausende-demonstrieren-gegen-lithium-abbau-im-jadartal-a-46a79719-a382-4e5a-8856-1535bef8de29#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T21:42:00+00:00

Serbien hat die größten Lithiumvorkommen Europas. Im Juli hatte die Regierung in Belgrad den Abbau genehmigt und danach zugesagt, die Förderung werde umweltverträglich erfolgen. Das zweifeln die Demonstranten an.

## Olympia 2024: Beachvolleyballer Nils Ehlers und Clemens Wickler verlieren Finale gegen David Åhman/Jonathan Hellvig
 - [https://www.spiegel.de/sport/olympia/olympia-2024-beachvolleyballer-nils-ehlers-und-clemens-wickler-verlieren-finale-gegen-david-ahman-jonathan-hellvig-a-dd5ea29f-be7d-4b37-b104-793ca17ce588#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-beachvolleyballer-nils-ehlers-und-clemens-wickler-verlieren-finale-gegen-david-ahman-jonathan-hellvig-a-dd5ea29f-be7d-4b37-b104-793ca17ce588#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T21:09:00+00:00

Überraschend erreichten die Beachvolleyballer Nils Ehlers und Clemens Wickler das Finale des Olympischen Turniers. Aber dort unterliefen ihnen gegen das schwedische Topteam David Åhman/Jonathan Hellvig zu viele Fehler.

## Olympia 2024: IOC-Präsident Thomas Bach tritt 2025- Wer folgt auf die Bach-Ära?
 - [https://www.spiegel.de/sport/olympia/olympia-2024-ioc-praesident-thomas-bach-tritt-2025-wer-folgt-auf-die-bach-aera-a-33884e11-280e-42c0-b6d7-9a3335f488ee#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-ioc-praesident-thomas-bach-tritt-2025-wer-folgt-auf-die-bach-aera-a-33884e11-280e-42c0-b6d7-9a3335f488ee#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T20:54:00+00:00

Lange ließ Thomas Bach offen, ob er die Olympische Charta ändern will, um Präsident zu bleiben. Doch nun kündigte der Deutsche seinen Abschied an. Das Zeitalter der weißen Europäer an der IOC-Spitze könnte damit enden.

## 2. Fußball-Bundesliga: Hertha BSC holt in wilder Schlussphase Remis gegen den Hamburger SV
 - [https://www.spiegel.de/sport/fussball/2-fussball-bundesliga-hertha-bsc-holt-in-wilder-schlussphase-remis-gegen-den-hamburger-sv-a-8ad83130-1592-4db2-b110-1b0a4272b447#ref=rss](https://www.spiegel.de/sport/fussball/2-fussball-bundesliga-hertha-bsc-holt-in-wilder-schlussphase-remis-gegen-den-hamburger-sv-a-8ad83130-1592-4db2-b110-1b0a4272b447#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T20:34:00+00:00

Im Kalender stand ein Topspiel – und es wurde auch eins. In einer wilden Schlussphase erzielte Hertha BSC den verdienten Ausgleich, nachdem beim HSV ein fast schon vergessener Stürmer für die Führung gesorgt hatte.

## Telefonat mit Premier Starmer: König Charles dankt Einsatzkräften nach den Unruhen in Großbritannien
 - [https://www.spiegel.de/ausland/telefonat-mit-premier-starmer-koenig-charles-dankt-einsatzkraeften-nach-den-unruhen-in-grossbritannien-a-30c059dc-6ca1-4634-8f47-abb0a36e40c9#ref=rss](https://www.spiegel.de/ausland/telefonat-mit-premier-starmer-koenig-charles-dankt-einsatzkraeften-nach-den-unruhen-in-grossbritannien-a-30c059dc-6ca1-4634-8f47-abb0a36e40c9#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T20:20:00+00:00

Bislang hat König Charles III. sich nicht zu den rechtsradikalen Krawallen geäußert. Nun dankt er Polizei und Feuerwehr für ihren Einsatz. Auch die Gegendemonstrationen haben den Monarchen ermutigt.

## Olympia 2024: Wie unser Reporter versuchte, am Jedermann-Marathon teilzunehmen
 - [https://www.spiegel.de/sport/olympia/olympia-2024-wie-unser-reporter-versuchte-am-jedermann-marathon-teilzunehmen-a-fea36e36-f9f6-4000-8a22-774133b8e234#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-wie-unser-reporter-versuchte-am-jedermann-marathon-teilzunehmen-a-fea36e36-f9f6-4000-8a22-774133b8e234#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T20:09:00+00:00

Olympia ist nur für die Profis? Nicht in Paris. Am Abend vor der Abschlussfeier wird es einen Marathon für Amateurläufer geben. Unser Reporter hat versucht, einen Platz zu bekommen.

## Olympia 2024: Boxerin Imane Khelif klagt gegen Online-Hasskommentare
 - [https://www.spiegel.de/sport/olympia/olympia-2024-boxerin-imane-khelif-klagt-gegen-online-hasskommentare-a-a18ef836-7228-4a79-abff-5105cfa325e5#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-boxerin-imane-khelif-klagt-gegen-online-hasskommentare-a-a18ef836-7228-4a79-abff-5105cfa325e5#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T19:56:00+00:00

Um die algerische Olympiasiegerin Imane Khelif gibt es hitzige Debatten, im Mittelpunkt steht ein nicht näher spezifizierter Geschlechtstest. Nun wehrt sich die Boxerin juristisch gegen Hass und Hetze im Internet.

## Russland-Ukraine-Krieg: Wolodymyr Selenskyj äußert sich erstmals zur Kursk-Offensive
 - [https://www.spiegel.de/ausland/russland-ukraine-krieg-wolodymyr-selenskyj-aeussert-sich-erstmals-zur-kursk-offensive-a-21ee02b1-addf-4740-9315-76cbc3a30991#ref=rss](https://www.spiegel.de/ausland/russland-ukraine-krieg-wolodymyr-selenskyj-aeussert-sich-erstmals-zur-kursk-offensive-a-21ee02b1-addf-4740-9315-76cbc3a30991#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T19:47:00+00:00

Seit fünf Tagen kämpfen ukrainische Truppen auf russischem Boden in der Region Kursk und gehen dabei ins Risiko. Präsident Selenskyj betont jetzt in seiner abendlichen Videoansprache: Der Druck auf den Aggressor sei nötig.

## Olympia 2024: Bodenturnerin Ana Bărbosu bekommt Bronze von Jordan Chiles nach Protest
 - [https://www.spiegel.de/sport/olympia/olympia-2024-bodenturnerin-ana-barbosu-bekommt-bronze-von-jordan-chiles-nach-protest-a-7182f27d-19bc-46dd-a8ce-5c0f0214ffeb#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-bodenturnerin-ana-barbosu-bekommt-bronze-von-jordan-chiles-nach-protest-a-7182f27d-19bc-46dd-a8ce-5c0f0214ffeb#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T19:31:00+00:00

Die Rumänin Ana Bărbosu oder die US-Amerikanerin Jordan Chiles? Über die Drittplatzierte im Bodenturnen der Frauen gibt es Streit. Der Internationale Sportgerichtshof entschied nun: Die Medaille muss neu vergeben werden.

## Touristen drohen Geldstrafen: Drei Deutsche sollen US-Nationalpark mit Paintballs verunstaltet haben
 - [https://www.spiegel.de/panorama/justiz/touristen-drohen-geldstrafen-drei-deutsche-sollen-us-nationalpark-mit-paintballs-verunstaltet-haben-a-a23d3641-fa50-40fa-9aae-e07cb57c0bd4#ref=rss](https://www.spiegel.de/panorama/justiz/touristen-drohen-geldstrafen-drei-deutsche-sollen-us-nationalpark-mit-paintballs-verunstaltet-haben-a-a23d3641-fa50-40fa-9aae-e07cb57c0bd4#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T18:39:00+00:00

Parkranger fanden Farbspritzer auf Schildern und Toiletten im Joshua Tree Nationalpark. Sie haben Anzeige gegen drei Deutsche gestellt, die eine Paintball-Pistole und Steinschleudern bei sich hatten.

## Neue Umfragen sehen Harris in drei Swing States vor Trump
 - [https://www.spiegel.de/ausland/neue-umfragen-sehen-harris-in-drei-swing-states-vor-trump-a-69a200f8-41c6-407d-9563-22a9698403d0#ref=rss](https://www.spiegel.de/ausland/neue-umfragen-sehen-harris-in-drei-swing-states-vor-trump-a-69a200f8-41c6-407d-9563-22a9698403d0#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T18:36:00+00:00

Michigan, Wisconsin, Pennsylvania: Laut einer Umfrage der »New York Times« und des Siena College liegt die demokratische US-Präsidentschaftskandidatin Kamala Harris dort nun vor dem Republikaner Donald Trump.

## Ukraine-Russland-Konflikt: Mehr als 76.000 Menschen aus Kursk-Region umgesiedelt
 - [https://www.spiegel.de/ausland/russland-ukraine-news-weiter-gefechte-im-russischen-grenzland-a-7fb24ea6-2a65-4eec-902b-5c2bb819c192#ref=rss](https://www.spiegel.de/ausland/russland-ukraine-news-weiter-gefechte-im-russischen-grenzland-a-7fb24ea6-2a65-4eec-902b-5c2bb819c192#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T18:11:00+00:00

Die Gefechte in der Region Kursk dauern an. Nun schafft der russische Zivilschutz die Bevölkerung mit Bussen aus den umkämpften Gebieten. Laut dem Verteidigungsministerium haben russische Panzer Stellung bezogen.

## Zuwachs für »Banksys Zoo«: Weiteres tierisches Graffiti in London aufgetaucht
 - [https://www.spiegel.de/panorama/gesellschaft/zuwachs-fuer-banksys-zoo-weiteres-tierisches-graffiti-in-london-aufgetaucht-a-3234ee8f-4dcd-4ee2-9a9d-9dff1e9163d5#ref=rss](https://www.spiegel.de/panorama/gesellschaft/zuwachs-fuer-banksys-zoo-weiteres-tierisches-graffiti-in-london-aufgetaucht-a-3234ee8f-4dcd-4ee2-9a9d-9dff1e9163d5#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T17:55:00+00:00

Banksys neuestes Werk zeigt eine Katzensilhouette. Das Motiv heizt die Spekulationen um die aktuelle Serie des Künstlers weiter an. Und nur wenige Stunden nach der Enthüllung war die Katze nicht mehr zu sehen.

## Olympia 2024: IOC-Präsident Bach tritt regelkonform 2025 ab
 - [https://www.spiegel.de/sport/olympia/olympia-2024-ioc-praesident-bach-tritt-regelkonform-2025-ab-a-eac15ca9-ca06-4fba-a43d-50e15584b2f1#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-ioc-praesident-bach-tritt-regelkonform-2025-ab-a-eac15ca9-ca06-4fba-a43d-50e15584b2f1#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T17:29:00+00:00

Der Präsident des Internationalen Olympischen Komitees darf nicht länger als zwölf Jahre im Amt bleiben. Thomas Bach hatte zuletzt offen gelassen, ob er sich um eine Änderung dieser Regel bemühen wird.

## Zum 100. Geburtstag von Jean-François Lyotard: Happy Birthday, Postmoderne!
 - [https://www.spiegel.de/kultur/zum-100-geburtstag-von-jean-francois-lyotard-happy-birthday-postmoderne-a-7cde195d-94a2-42d7-88c3-40a36783bf1d#ref=rss](https://www.spiegel.de/kultur/zum-100-geburtstag-von-jean-francois-lyotard-happy-birthday-postmoderne-a-7cde195d-94a2-42d7-88c3-40a36783bf1d#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T17:19:00+00:00

Er ist der Namensgeber jener Theorie, die die Zertrümmerung der Institutionen vorantrieb. Heute wäre Jean-François Lyotard, Philosoph und Pate der Postmoderne, 100 Jahre alt geworden.

## Robert Downey Jr. lehnte Iron-Man-Auftritt in »Deadpool & Wolverine« ab
 - [https://www.spiegel.de/kultur/kino/robert-downey-jr-lehnte-iron-man-auftritt-in-deadpool-wolverine-ab-a-44b2e9ac-7c6f-4dad-89bc-6b21a7336e8b#ref=rss](https://www.spiegel.de/kultur/kino/robert-downey-jr-lehnte-iron-man-auftritt-in-deadpool-wolverine-ab-a-44b2e9ac-7c6f-4dad-89bc-6b21a7336e8b#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T17:09:00+00:00

In »Avengers: Endgame« stirbt der Superheld, mit dem das Marvel Cinematic Universe einst startete: Tony Stark alias Iron Man. Jetzt wäre ein hübscher Gastauftritt drin gewesen, aber der Schauspieler hatte andere Pläne.

## Gefangenenaustausch mit Russland: Oleg Orlow will im Exil weiterhin für Menschenrechte kämpfen
 - [https://www.spiegel.de/ausland/gefangenenaustausch-mit-russland-oleg-orlow-will-im-exil-weiterhin-fuer-menschenrechte-kaempfen-a-203045ec-b9ab-4469-b7c0-ca2635fed462#ref=rss](https://www.spiegel.de/ausland/gefangenenaustausch-mit-russland-oleg-orlow-will-im-exil-weiterhin-fuer-menschenrechte-kaempfen-a-203045ec-b9ab-4469-b7c0-ca2635fed462#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T16:47:00+00:00

Oleg Orlow ist einer von 16 Inhaftierten, die im Gefangenenaustausch mit Russland freigekommen sind. Der 71-jährige Menschenrechtler will seine Arbeit im Exil fortsetzen – und spricht sich für weitere Deals mit Moskau aus.

## Ukraine: Kriegsmarine attackiert Gasturm – angeblich 40 russische Soldaten getötet
 - [https://www.spiegel.de/ausland/ukraine-kriegsmarine-attackiert-gasturm-angeblich-40-russische-soldaten-getoetet-a-77cc576b-b4ee-4529-91de-ce7c7cc85dd6#ref=rss](https://www.spiegel.de/ausland/ukraine-kriegsmarine-attackiert-gasturm-angeblich-40-russische-soldaten-getoetet-a-77cc576b-b4ee-4529-91de-ce7c7cc85dd6#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T16:17:00+00:00

Die ukrainische Kriegsmarine hat nach eigenen Angaben einen Gasförderturm im Schwarzen Meer attackiert. Etwa 40 russische Soldaten seien getötet worden, der Angriff habe dem Schutz ziviler Schiffe gedient.

## Olympia 2024: Heiratsanträge, Poesie, Romantik – die Spiele der Liebe
 - [https://www.spiegel.de/sport/olympia/olympia-2024-heiratsantraege-poesie-romantik-die-spiele-der-liebe-a-2c9568fc-8091-4048-961a-8133198e08e1#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-heiratsantraege-poesie-romantik-die-spiele-der-liebe-a-2c9568fc-8091-4048-961a-8133198e08e1#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T15:52:00+00:00

Die Olympischen Spiele bieten nicht nur große sportliche Leistungen, sondern auch große Gefühle. Wie kann es auch anders sein in der Stadt der Liebe? Ein Rückblick fürs Herz.

## Retten, Löschen, Bergen, Schützen: Die Hamburger Feuerwehr im Einsatz - SPIEGEL TV begleitet die Lebensretter
 - [https://www.spiegel.de/panorama/gesellschaft/retten-loeschen-bergen-schuetzen-die-hamburger-feuerwehr-im-einsatz-spiegel-tv-begleitet-die-lebensretter-a-b3139165-1e9a-4a7d-9904-65815d239af1#ref=rss](https://www.spiegel.de/panorama/gesellschaft/retten-loeschen-bergen-schuetzen-die-hamburger-feuerwehr-im-einsatz-spiegel-tv-begleitet-die-lebensretter-a-b3139165-1e9a-4a7d-9904-65815d239af1#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T15:48:00+00:00

Ob Brände, Bomben oder Vermisstenfall, täglich rückt die Hamburger Feuerwehr Hunderte Male aus. SPIEGEL TV hat sie bei ihren Einsätzen durch die Hansestadt begleitet.

## Disney: Neue Filme und Serien bekanntgegeben
 - [https://www.spiegel.de/kultur/kino/disney-neue-filme-und-serien-bekanntgegeben-a-9eccc998-97d6-444b-aac8-3146111f689e#ref=rss](https://www.spiegel.de/kultur/kino/disney-neue-filme-und-serien-bekanntgegeben-a-9eccc998-97d6-444b-aac8-3146111f689e#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T15:05:00+00:00

Disney hat auf dem Fan-Event D23 präsentiert, welche Filme und Serien bald die Kinokassen und Wohnzimmer erobern sollen. Darunter sind Fortsetzungen von »Avatar« und »König der Löwen«, aber auch ein paar Überraschungen.

## Olympia 2024: Drei deutsche Schwimmer nach Rennen in der Seine erkrankt
 - [https://www.spiegel.de/sport/olympia/olympia-2024-drei-deutsche-schwimmer-nach-rennen-in-der-seine-erkrankt-a-38b7eebe-6250-4530-9b6e-1a4a53897831#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-drei-deutsche-schwimmer-nach-rennen-in-der-seine-erkrankt-a-38b7eebe-6250-4530-9b6e-1a4a53897831#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T15:00:00+00:00

Die Wasserqualität der Seine sorgte vor den olympischen Freiwasserrennen für Diskussionen. Nun sind die Wettkämpfe vorbei. Für drei von vier Teilnehmenden aus Deutschland haben sie gesundheitliche Folgen.

## Publizistin Ingrid Brodnig: Werden die österreichischen Nationalratswahlen im Netz entschieden? (Podcast)
 - [https://www.spiegel.de/ausland/publizistin-ingrid-brodnig-werden-die-oesterreichischen-nationalratswahlen-im-netz-entschieden-podcast-a-8f158353-8b10-4e44-aa9b-6abb26af3f96#ref=rss](https://www.spiegel.de/ausland/publizistin-ingrid-brodnig-werden-die-oesterreichischen-nationalratswahlen-im-netz-entschieden-podcast-a-8f158353-8b10-4e44-aa9b-6abb26af3f96#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T14:55:00+00:00

Ende September stehen in Österreich die Nationalratswahlen an. Im Interview erklärt die Publizistin Ingrid Brodnig, wie viel Einfluss die Parteien über TikTok, Instagram und Facebook nehmen – und welche Rolle Wut dabei spielt.

## Olympia 2024: Deutschlands Basketballer verlieren letztes Spiel von Gordon Herbert
 - [https://www.spiegel.de/sport/olympia/olympia-2024-deutschlands-basketballer-verlieren-letztes-spiel-von-gordon-herbert-a-5300aa7b-409f-4848-b4e2-74ada0c95c6a#ref=rss](https://www.spiegel.de/sport/olympia/olympia-2024-deutschlands-basketballer-verlieren-letztes-spiel-von-gordon-herbert-a-5300aa7b-409f-4848-b4e2-74ada0c95c6a#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T14:51:00+00:00

Mit Gordon Herbert als Bundestrainer begann die erfolgreichste Ära des deutschen Basketballs. Bei seinem letzten Spiel ließen ihn die Spieler im Stich, das Team hatte im Kampf um Bronze keine Chance. Nun steht ein Umbruch an.

## Russland-Ukraine-Krieg: Militärexperte Gustav C. Gressel warnt vor ukrainischem Vorstoß auf russisches Gebiet
 - [https://www.spiegel.de/ausland/russland-ukraine-krieg-militaerexperte-gustav-c-gressel-warnt-vor-ukrainischem-vorstoss-auf-russisches-gebiet-a-796f8e55-b102-4829-966e-99f3f8165c7e#ref=rss](https://www.spiegel.de/ausland/russland-ukraine-krieg-militaerexperte-gustav-c-gressel-warnt-vor-ukrainischem-vorstoss-auf-russisches-gebiet-a-796f8e55-b102-4829-966e-99f3f8165c7e#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T14:27:00+00:00

Erstmals sind reguläre ukrainische Truppen bei Kursk auf russisches Gebiet vorgedrungen. Der Militärexperte Gustav C. Gressel erklärt, was die Ukraine mit der Operation bezweckt – und warum ihr der Angriff gefährlich werden könnte.

## Sturm auf das Kapitol: US-Gericht verhängt 20 Jahre Haft für gewalttätigen Randalierer
 - [https://www.spiegel.de/ausland/sturm-auf-das-kapitol-us-gericht-verhaengt-20-jahre-haft-fuer-gewalttaetigen-randalierer-a-1d85b799-c7fe-4b42-9b44-858018065922#ref=rss](https://www.spiegel.de/ausland/sturm-auf-das-kapitol-us-gericht-verhaengt-20-jahre-haft-fuer-gewalttaetigen-randalierer-a-1d85b799-c7fe-4b42-9b44-858018065922#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T14:25:00+00:00

Ein US-Gericht hat einen Kalifornier zu 20 Jahren Haft verurteilt. Laut Staatsanwaltschaft gehörte er beim Angriff auf das US-Kapitol zu den »gewalttätigsten Randalierern«, sie hatte eine noch höhere Strafe gefordert.

## Taylor Swift-Konzerte in Wien: Abgesagt aus Sicherheitsgründen – Hinweise auf Anschlagspläne wohl bereits Tage zuvor
 - [https://www.spiegel.de/ausland/taylor-swift-konzerte-in-wien-abgesagt-aus-sicherheitsgruenden-hinweise-auf-anschlagsplaene-wohl-bereits-tage-zuvor-a-5fda722f-806b-4d0e-973f-bab30ae718ed#ref=rss](https://www.spiegel.de/ausland/taylor-swift-konzerte-in-wien-abgesagt-aus-sicherheitsgruenden-hinweise-auf-anschlagsplaene-wohl-bereits-tage-zuvor-a-5fda722f-806b-4d0e-973f-bab30ae718ed#ref=rss)
 - RSS feed: https://www.spiegel.de/schlagzeilen/index.rss
 - date published: 2024-08-10T14:03:00+00:00

Aus Sicherheitsgründen wurden drei Konzerte von Taylor Swift in Wien kurzfristig abgesagt. Nun wird berichtet, dass es schon früh Hinweise auf Anschlagspläne gab – was die zuständigen Behörden bestreiten.

