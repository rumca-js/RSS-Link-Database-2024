# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Kena: Bridge of Spirits - Official Xbox Pre-Order Trailer
 - [https://www.youtube.com/watch?v=LzrVEG0PjYs](https://www.youtube.com/watch?v=LzrVEG0PjYs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T20:45:00+00:00

Kena: Bridge of Spirits is a third-person action-adventure platformer developed by Ember Lab. Players will embody Kena to aid in untangling the past and help spirits trapped in a forgotten village with the help of the spirit companions the Rot. Kena: Bridge of Spirits is coming to Xbox One and Xbox Series X|S on August 15 alongside the release on PlayStation 4 (PS4), PlayStation 5 (PS5), and PC.

#KenaBridgeOfSpirits #Xbox #Gaming

## Alabaster Dawn - Official Reveal Trailer
 - [https://www.youtube.com/watch?v=5xlqNCqNCUI](https://www.youtube.com/watch?v=5xlqNCqNCUI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T17:00:04+00:00

Here's your look at the Alabaster Dawn reveal trailer for the upcoming game from the creators of CrossCode. The trailer for Alabaster Dawn gives us a peek at the gorgeous world, some of the threats you'll encounter, and combat from this upcoming action RPG. In Alabaster Dawn, the shadow of Nyx has fallen—warping the world into a wasteland and vanishing the gods and their people. Now, Juno the Outcast Chosen, awakes to an impossible task: bring it all back.

Alabaster Dawn will be available on PC/Linux, with consoles planned as well.

#AlabasterDawn #Gaming #IGN

## Deadpool & Wolverine - Official 'Flame On' Teaser Trailer
 - [https://www.youtube.com/watch?v=IhgnF17xdnY](https://www.youtube.com/watch?v=IhgnF17xdnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T16:30:03+00:00

Watch this teaser trailer for Deadpool & Wolverine as we get a taste of a long-awaited cameo with a familiar face...

Deadpool & Wolverine have teamed up to save a universe or two, have epic fights in tight costumes, and officially indoctrinate Deadpool into the Marvel Cinematic Universe as Marvel Jesus. Take a look at the latest trailer for Deadpool & Wolverine starring Ryan Reynolds, Hugh Jackman, Emma Corrin, Morena Baccarin, Rob Delaney, Leslie Uggams, Karan Soni, and Matthew Macfadyen.

Kevin Feige, Ryan Reynolds, Shawn Levy and Lauren Shuler Donner produce with Louis D’Esposito, Wendy Jacobson, Mary McLaglen, Josh McLaglen, Rhett Reese, Paul Wernick, George Dewey and Simon Kinberg serving as executive producers. Deadpool & Wolverine is written by Ryan Reynolds & Rhett Reese & Paul Wernick & Zeb Wells & Shawn Levy. 

Deadpool & Wolverine is in theaters now.

#DeadpoolAndWolverine #IGN #FlameOn

## Delta Force: Hawk Ops - Official Terry Musa Operator Overview Trailer
 - [https://www.youtube.com/watch?v=NZ7_BiJTAsk](https://www.youtube.com/watch?v=NZ7_BiJTAsk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T16:00:16+00:00

Delta Force: Hawk Ops is a free-to-play first-person multiplayer action shooter game developed by Timi Studio. Check out the latest trailer for the operator Terry Musa, callsign Shepherd, an Engineer Operator within the game. Shepherd is armed with a toolkit of devious sonic traps, making him adept at protecting his team. Delta Force: Hawk Ops is launching soon on PlayStation 5 (PS5), Xbox Series X|S, iOS, Android, and PC (Steam) with the PC Alpha test available now.

#DeltaForceHawkOps #TerryMusa #IGN

## Fatal Fury: City of the Wolves - Official Terry Bogard Gameplay Trailer
 - [https://www.youtube.com/watch?v=f6xLvxL-FPA](https://www.youtube.com/watch?v=f6xLvxL-FPA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T15:00:41+00:00

Fatal Fury: City of the Wolves marks the return of the classic 2D fighting game franchise developed by SNK Corporation. Check out the gameplay trailer for Terry Bogard, South Town’s very own Legendary Hungry Wolf. Fatal Fury: City of the Wolves launches in early 2025 for PlayStation 4 (PS4), PlayStation 5 (PS5), Xbox Series X|S, PC (Steam and Epic Games Store).

#FatalFuryCityOfTheWolves #TerryBogard #Gaming

## Delta Force: Hawk Ops - Official Roy Smee Operator Overview Trailer
 - [https://www.youtube.com/watch?v=OIL2c5iNJ-E](https://www.youtube.com/watch?v=OIL2c5iNJ-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T14:06:12+00:00

Delta Force: Hawk Ops is a free-to-play first-person multiplayer action shooter game developed by Timi Studio. Check out the latest trailer for the operator Roy Smee, callsign Stinger, a Support Operator within the game. Stinger carries a life-saving Hive Tech Pistol that can deliver vital health boosts to himself and his team. Delta Force: Hawk Ops is launching soon on PlayStation 5 (PS5), Xbox Series X|S, iOS, Android, and PC (Steam) with the PC Alpha test available now.

#DeltaForceHawkOps #RoySmee #Gaming

## Snow White live-action vs animated #d23
 - [https://www.youtube.com/watch?v=GrsC3pGJxkA](https://www.youtube.com/watch?v=GrsC3pGJxkA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T06:51:28+00:00



## Mufasa: The Lion King - Official Trailer (2024) Aaron Pierre, Mads Mikkelsen | D23 2024
 - [https://www.youtube.com/watch?v=0iYk8amHOX4](https://www.youtube.com/watch?v=0iYk8amHOX4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T05:09:17+00:00

Experience the epic story of how an orphan became a King. #Mufasa: The Lion King, only in theaters December 20.

Exploring the unlikely rise of the beloved king of the Pride Lands, “Mufasa: The Lion King” enlists Rafiki to relay the legend of Mufasa to young lion cub Kiara, daughter of Simba and Nala, with Timon and Pumbaa lending their signature schtick. Told in flashbacks, the story introduces Mufasa as an orphaned cub, lost and alone until he meets a sympathetic lion named Taka—the heir to a royal bloodline. The chance meeting sets in motion an expansive journey of an extraordinary group of misfits searching for their destiny—their bonds will be tested as they work together to evade a threatening and deadly foe. 
 
New and returning cast members were called on to lend their voices to the film:
- Aaron Pierre as Mufasa
- Kelvin Harrison Jr. as Taka, a lion prince with a bright future who accepts Mufasa into his family as a brother
- Tiffany Boone as Sarabi
- Kagiso Lediga as Young R

## Tron: Ares composer revealed #d23
 - [https://www.youtube.com/watch?v=6xb9mdiIWv8](https://www.youtube.com/watch?v=6xb9mdiIWv8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T05:04:26+00:00



## Disney’s Snow White - Official Teaser Trailer (2025) Rachel Zegler | D23 2024
 - [https://www.youtube.com/watch?v=QYcYx4Z-YV8](https://www.youtube.com/watch?v=QYcYx4Z-YV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T04:54:01+00:00

Disney invites you to return to the story that started it all 🍎 Experience #SnowWhite, only in theaters March 21, 2025.

“Disney’s Snow White” is a live action musical reimagining of the classic 1937 film. The magical music adventure journeys back to the timeless story with beloved characters Bashful, Doc, Dopey, Grumpy, Happy, Sleepy, and Sneezy. “Disney’s Snow White” is directed by Marc Webb and produced by Marc Platt and Jared LeBoff, with Callum McDougall serving as executive producer, and features all-new original songs from Benj Pasek and Justin Paul.

#IGN #D23

## Live-action Stitch from Lilo & Stitch remake #D23
 - [https://www.youtube.com/watch?v=Zl8d21ZQqno](https://www.youtube.com/watch?v=Zl8d21ZQqno)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T04:47:59+00:00



## Percy Jackson and the Olympians Season 2 - Official Teaser (2025) Walker Scobell | D23 2024
 - [https://www.youtube.com/watch?v=ap9NNailOSk](https://www.youtube.com/watch?v=ap9NNailOSk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T04:16:11+00:00

Off to the races. 🔱 #PercyJackson and the Olympians Season 2 is officially in production and streaming 2025.

#IGN #D23

## Agatha All Along - Official Trailer (2024) Kathryn Hahn, Aubrey Plaza | D23 2024
 - [https://www.youtube.com/watch?v=L5ET-y0ie60](https://www.youtube.com/watch?v=L5ET-y0ie60)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T04:06:28+00:00

This Halloween season, stream Marvel Television’s #AgathaAllAlong. The two-episode premiere arrives September 18 on ‪Disney Plus.

#IGN #D23

## Skeleton Crew - Official Trailer (2024) Jude Law | D23 2024
 - [https://www.youtube.com/watch?v=-bSoHjSzxEg](https://www.youtube.com/watch?v=-bSoHjSzxEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T03:30:26+00:00

Get ready for a brand new Star Wars adventure.

Watch the trailer for Skeleton Crew, streaming with a two-episode series premiere December 3 on Disney+.

#IGN #D23

## Toy Story 5 - Official Teaser Trailer (2026) Tim Allen | D23 2024
 - [https://www.youtube.com/watch?v=F8N0-ViM254](https://www.youtube.com/watch?v=F8N0-ViM254)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-08-10T03:21:10+00:00

Get excited for their next chapter as Woody, Buzz, Jessie, and the gang all return for Toy Story 5, coming to theaters Summer 2026!

#IGN #D23

