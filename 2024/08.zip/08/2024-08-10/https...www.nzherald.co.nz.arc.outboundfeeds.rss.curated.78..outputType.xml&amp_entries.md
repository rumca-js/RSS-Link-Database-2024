# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## All Blacks Rugby Championship hopes in jeopardy after Wellington loss to Pumas
 - [https://www.nzherald.co.nz/sport/rugby/all-blacks/all-blacks-rugby-championship-hopes-in-jeopardy-after-wellington-loss-to-pumas/2L5UCUVNXZAB5JEM4ZMD47YVQA](https://www.nzherald.co.nz/sport/rugby/all-blacks/all-blacks-rugby-championship-hopes-in-jeopardy-after-wellington-loss-to-pumas/2L5UCUVNXZAB5JEM4ZMD47YVQA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T21:48:34+00:00

Pumas triumph over All Blacks, Robertson vows to improve for Eden Park rematch.

## Joaquin Phoenix quits Todd Haynes’ gay romance movie at late stage
 - [https://www.nzherald.co.nz/entertainment/joaquin-phoenix-quits-todd-haynes-gay-romance-movie-at-late-stage/LJJTMXPVGZF53GCATUWNCGXWYY](https://www.nzherald.co.nz/entertainment/joaquin-phoenix-quits-todd-haynes-gay-romance-movie-at-late-stage/LJJTMXPVGZF53GCATUWNCGXWYY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T21:40:49+00:00

Filming for the movie was due to begin in Mexico in a matter of days.

## Olympics 2024: Lydia Ko makes history, adding gold to Olympic silver and bronze
 - [https://www.nzherald.co.nz/sport/olympics/olympics-2024-lydia-ko-makes-history-adding-gold-to-olympic-silver-and-bronze/UK6W6EIYO5ADPF4YSYTQ7KRMMM](https://www.nzherald.co.nz/sport/olympics/olympics-2024-lydia-ko-makes-history-adding-gold-to-olympic-silver-and-bronze/UK6W6EIYO5ADPF4YSYTQ7KRMMM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T20:43:44+00:00

Silver in Rio, bronze in Tokyo, and now gold for Ko in Paris.

## Olympics 2024: New Zealand win most gold medals with nine in Paris
 - [https://www.nzherald.co.nz/sport/olympics/olympics-2024-new-zealand-win-most-gold-medals-with-nine-in-paris/STQAA5LRSJGDBFUOLSGGYLAUQE](https://www.nzherald.co.nz/sport/olympics/olympics-2024-new-zealand-win-most-gold-medals-with-nine-in-paris/STQAA5LRSJGDBFUOLSGGYLAUQE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T20:10:09+00:00

New Zealand has reached a new golden height in Paris.

## Olympics 2024: Hamish Kerr leaps to history with thrilling high jump gold
 - [https://www.nzherald.co.nz/sport/olympics/olympics-2024-hamish-kerr-leaps-to-history-with-thrilling-high-jump-gold/GQ52SINUIREQBN7HNLT4IPY4UA](https://www.nzherald.co.nz/sport/olympics/olympics-2024-hamish-kerr-leaps-to-history-with-thrilling-high-jump-gold/GQ52SINUIREQBN7HNLT4IPY4UA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T19:22:19+00:00

Hamish Kerr has become the first New Zealander reach an Olympic podium in the high jump.

## Christchurch serial rape trial: Four of 15 women tell their story
 - [https://www.nzherald.co.nz/nz/christchurch-serial-rape-trial-four-of-15-women-tell-their-story/GXNOHLJUXJEA7KLPGZGTP6NCXY](https://www.nzherald.co.nz/nz/christchurch-serial-rape-trial-four-of-15-women-tell-their-story/GXNOHLJUXJEA7KLPGZGTP6NCXY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T17:00:00+00:00

Former footballer denies accusations at High Court trial in Christchurch.

## Lake Wanaka court decision may end 170-year Treaty injustice for Ngāi Tahu - but mountain bikers are nervous
 - [https://www.nzherald.co.nz/nz/politics/lake-wanaka-court-decision-may-end-170-year-treaty-injustice-for-ngai-tahu-but-mountain-bikers-are-nervous/W7TURUGY7RDS5HNO6BFGOPKTKM](https://www.nzherald.co.nz/nz/politics/lake-wanaka-court-decision-may-end-170-year-treaty-injustice-for-ngai-tahu-but-mountain-bikers-are-nervous/W7TURUGY7RDS5HNO6BFGOPKTKM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T17:00:00+00:00

Some of a Wānaka forest with popular trails can now become 150 homes on prime real estate

## Police push to ban 3D-printed gun blueprints amid rise in manufacturing by organised crime
 - [https://www.nzherald.co.nz/nz/police-push-to-ban-3d-printed-gun-blueprints-amid-rise-in-manufacturing-by-organised-crime/V4KJFQZT5FHWRJ2MMOMPG4MSPU](https://www.nzherald.co.nz/nz/police-push-to-ban-3d-printed-gun-blueprints-amid-rise-in-manufacturing-by-organised-crime/V4KJFQZT5FHWRJ2MMOMPG4MSPU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T17:00:00+00:00

Police also want 'starter guns' and 'gel blasters' banned fearing they can be converted

## We’re getting close to an energy crisis - Heather du Plessis-Allan
 - [https://www.nzherald.co.nz/nz/were-getting-close-to-an-energy-crisis-heather-du-plessis-allan/WL3KPZEI4NH47OY7EBS7WUD6ZY](https://www.nzherald.co.nz/nz/were-getting-close-to-an-energy-crisis-heather-du-plessis-allan/WL3KPZEI4NH47OY7EBS7WUD6ZY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-08-10T17:00:00+00:00

OPINION: Our electricity prices last week were said to be the highest in the world.

