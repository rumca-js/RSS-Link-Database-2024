# Source:Observer, URL:http://www.observer.com/feed, language:en

## Teatro Nuovo Revives a Forgotten Bel Canto Opera by a Woman Composer for the First Time in Nearly 200 Years
 - [https://observer.com/2024/08/teatro-nuovo-anna-di-resburgo-carolina-uccelli](https://observer.com/2024/08/teatro-nuovo-anna-di-resburgo-carolina-uccelli)
 - RSS feed: http://www.observer.com/feed
 - date published: 2024-08-10T12:00:49+00:00

If this revival of the 19th Century opera by Carolina Uccelli didn’t reveal a hidden masterpiece, "Anna" does provide a glimpse into what might have been had Uccelli kept composing.

