# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## Over the Next Hill Returns on the Queen Éolynn!
 - [https://www.enworld.org/threads/over-the-next-hill-returns-on-the-queen-%C3%89olynn.706066](https://www.enworld.org/threads/over-the-next-hill-returns-on-the-queen-%C3%89olynn.706066)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-08-10T13:49:00+00:00

<div class="bbWrapper">Includes a strange crew working the decks and a sturgeon riverlord, as any riverboat should.</div>

## Outgunned Brings A Little Dice Dice, Bang Bang To Your Table
 - [https://www.enworld.org/threads/outgunned-brings-a-little-dice-dice-bang-bang-to-your-table.706056](https://www.enworld.org/threads/outgunned-brings-a-little-dice-dice-bang-bang-to-your-table.706056)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-08-10T10:31:00+00:00

<div class="bbWrapper">The best cinematic action RPG since Feng Shui.</div>

