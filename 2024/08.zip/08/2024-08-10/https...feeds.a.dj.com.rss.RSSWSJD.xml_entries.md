# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Former YouTube CEO Susan Wojcicki Dies at Age 56
 - [https://www.wsj.com/articles/former-youtube-ceo-susan-wojcicki-dies-at-age-56-58d1911d?mod=rss_Technology](https://www.wsj.com/articles/former-youtube-ceo-susan-wojcicki-dies-at-age-56-58d1911d?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-08-10T16:13:00+00:00

The Silicon Valley native joined Google as one of its earliest employees, was instrumental in its rise and stepped down last year after nearly a decade running its video platform.

## Tech Bros Are Betting They Can Help Win a War With China
 - [https://www.wsj.com/articles/anduril-drones-palmer-luckey-china-ukraine-china-951494ec?mod=rss_Technology](https://www.wsj.com/articles/anduril-drones-palmer-luckey-china-ukraine-china-951494ec?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-08-10T01:00:00+00:00

Billions of dollars of venture capital is flowing into defense-tech startups focused on futuristic, AI-enabled weapons. Palmer Luckey’s Anduril is their biggest bet.

## The Screen Time You Shouldn't Feel Bad About
 - [https://www.wsj.com/articles/the-screen-time-you-shouldnt-feel-bad-about-72ec85f3?mod=rss_Technology](https://www.wsj.com/articles/the-screen-time-you-shouldnt-feel-bad-about-72ec85f3?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-08-10T01:00:00+00:00

Understanding what you actually do on your phone can help you make smarter adjustments.

## Why Every Big Tech Company Has Failed to Dethrone Nvidia as King of AI
 - [https://www.wsj.com/articles/ai-nvidia-apple-amd-jensen-huang-software-bb581f5a?mod=rss_Technology](https://www.wsj.com/articles/ai-nvidia-apple-amd-jensen-huang-software-bb581f5a?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-08-10T01:00:00+00:00

Nvidia, like Apple, shows that if you want to become a giant, you’ve got to be as good at software as you are at hardware.

