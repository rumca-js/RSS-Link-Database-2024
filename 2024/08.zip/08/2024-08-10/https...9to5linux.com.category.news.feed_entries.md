# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## HandBrake 1.8.2 Video Transcoder Adds FFmpeg 7.0.2 Support and Fixes Bugs
 - [https://9to5linux.com/handbrake-1-8-2-video-transcoder-adds-ffmpeg-7-0-2-support-and-fixes-bugs](https://9to5linux.com/handbrake-1-8-2-video-transcoder-adds-ffmpeg-7-0-2-support-and-fixes-bugs)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-08-10T11:52:36+00:00

<p>HandBrake 1.8.2 open-source video transcoder software is now available for download with various bug fixes for Linux and Windows systems, as well as updated components. Here's what's changed.</p>
<p>The post <a href="https://9to5linux.com/handbrake-1-8-2-video-transcoder-adds-ffmpeg-7-0-2-support-and-fixes-bugs">HandBrake 1.8.2 Video Transcoder Adds FFmpeg 7.0.2 Support and Fixes Bugs</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

