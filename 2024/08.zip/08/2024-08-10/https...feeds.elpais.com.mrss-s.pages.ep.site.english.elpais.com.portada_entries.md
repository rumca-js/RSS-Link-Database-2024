# Source:EL PAÍS in English, URL:https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada, language:en

## Catherine Zeta-Jones, the A-lister who couldn’t escape ageism
 - [https://english.elpais.com/people/2024-08-10/catherine-zeta-jones-the-a-lister-who-couldnt-escape-ageism.html](https://english.elpais.com/people/2024-08-10/catherine-zeta-jones-the-a-lister-who-couldnt-escape-ageism.html)
 - RSS feed: https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada
 - date published: 2024-08-10T04:05:00+00:00

After going public with her bipolar diagnosis and celebrating her 25th anniversary with Michael Douglas, the Welshwoman says she’s still loving life, even if she’s had to take an undesired step back from moviemaking

## How Wikipedia is surviving in the age of ChatGPT
 - [https://english.elpais.com/technology/2024-08-10/how-wikipedia-is-surviving-in-the-age-of-chatgpt.html](https://english.elpais.com/technology/2024-08-10/how-wikipedia-is-surviving-in-the-age-of-chatgpt.html)
 - RSS feed: https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada
 - date published: 2024-08-10T04:05:00+00:00

Faced with advances in artificial intelligence, volunteers at the great online encyclopedia are strengthening their control to prevent the site from being filled with misinformation or promotional content

## Innocent professor or secret agent? Shujun Wang, the Chinese American academic who has been convicted of espionage in New York
 - [https://english.elpais.com/usa/2024-08-10/innocent-professor-or-secret-agent-shujun-wang-the-chinese-american-academic-who-has-been-convicted-of-espionage-in-new-york.html](https://english.elpais.com/usa/2024-08-10/innocent-professor-or-secret-agent-shujun-wang-the-chinese-american-academic-who-has-been-convicted-of-espionage-in-new-york.html)
 - RSS feed: https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada
 - date published: 2024-08-10T04:05:00+00:00

Accused of being an informant amid U.S.-China tensions, the 75-year-old man was a member and volunteer at a pro-democracy dissident organization in Brooklyn

## Liquid animals: Why getting into water feels so good
 - [https://english.elpais.com/science-tech/2024-08-10/liquid-animals-why-getting-into-water-feels-so-good.html](https://english.elpais.com/science-tech/2024-08-10/liquid-animals-why-getting-into-water-feels-so-good.html)
 - RSS feed: https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada
 - date published: 2024-08-10T04:05:00+00:00

Humans have been experiencing the benefits of bathing and swimming for millenia. However, until very recently, science hadn’t studied this in detail

## Should you take vitamin D? Here’s the science
 - [https://english.elpais.com/health/2024-08-10/should-you-take-vitamin-d-heres-the-science.html](https://english.elpais.com/health/2024-08-10/should-you-take-vitamin-d-heres-the-science.html)
 - RSS feed: https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada
 - date published: 2024-08-10T04:05:00+00:00

Some people take too much, and too many get too little. Experts explain who needs D supplements, and why

## The mysterious nightclub created by David Lynch now has a location in New York
 - [https://english.elpais.com/culture/2024-08-10/the-mysterious-nightclub-created-by-david-lynch-now-has-a-location-in-new-york.html](https://english.elpais.com/culture/2024-08-10/the-mysterious-nightclub-created-by-david-lynch-now-has-a-location-in-new-york.html)
 - RSS feed: https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada
 - date published: 2024-08-10T04:05:00+00:00

After its success in Paris and Ibiza, the new headquarters in the Big Apple  – designed by Crosby Studios – has made the club’s concept a world leader in interior design

## The rise of renewable energy puts China on track to end its CO₂ emissions growth
 - [https://english.elpais.com/climate/2024-08-10/the-rise-of-renewable-energy-puts-china-on-track-to-end-its-co-emissions-growth.html](https://english.elpais.com/climate/2024-08-10/the-rise-of-renewable-energy-puts-china-on-track-to-end-its-co-emissions-growth.html)
 - RSS feed: https://feeds.elpais.com/mrss-s/pages/ep/site/english.elpais.com/portada
 - date published: 2024-08-10T04:05:00+00:00

The advance of solar and wind power has displaced coal as the world’s leading emitter of greenhouse gases

