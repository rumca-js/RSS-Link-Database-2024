# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## USA chcą skonfiskować majątek rosyjskiego oligarchy. Ma trafić na Ukrainę
 - [https://www.bankier.pl/wiadomosc/USA-chca-skonfiskowac-majatek-rosyjskiego-oligarchy-Ma-trafic-na-Ukraine-8795539.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-chca-skonfiskowac-majatek-rosyjskiego-oligarchy-Ma-trafic-na-Ukraine-8795539.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T18:22:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/3da405cf02e593-948-568-0-0-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Resort sprawiedliwości USA próbuje skonfiskować 200 mln dol. skradzionych przez byłego ukraińskiego premiera Pawło Łazarenkę i przejętych przez sądy w rajach podatkowych, gdzie je ukrywał, by przekazać je Ukrainie - poinformował portal Voice of America.]]&gt;

## Teren byłego obozu koncentracyjnego sprzedany deweloperowi
 - [https://www.bankier.pl/wiadomosc/Teren-bylego-obozu-koncentracyjnego-sprzedany-deweloperowi-8795535.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Teren-bylego-obozu-koncentracyjnego-sprzedany-deweloperowi-8795535.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T17:55:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/224ffc257644af-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Teren byłego obozu koncentracyjnego w pobliżu Halberstadt w Saksonii-Anhalt, w którym zginęło ponad 4,3 tys. osób, został sprzedany inwestorowi z branży nieruchomości - poinformował tygodnik "Spiegel". Transakcja wywołała konsternację.]]&gt;

## W obwodzie kurskim ewakuowano 76 tys. osób. "Trwa ofensywa sił ukraińskich"
 - [https://www.bankier.pl/wiadomosc/W-obwodzie-kurskim-ewakuowano-76-tys-osob-Trwa-ofensywa-sil-ukrainskich-8795531.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-obwodzie-kurskim-ewakuowano-76-tys-osob-Trwa-ofensywa-sil-ukrainskich-8795531.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T17:02:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/d58748c06da442-948-568-0-269-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 76 tys. osób ewakuowano z regionów graniczących z Ukrainą w obwodzie kurskim na zachodzie Rosji - poinformował w sobotę miejscowy wydział resortu ds. sytuacji nadzwyczajnych. Od wtorku w tym regionie trwa ofensywa sił ukraińskich.]]&gt;

## Zamach stanu w Serbii? Prezydent Vuczić: Rosjanie mnie poinformowali
 - [https://www.bankier.pl/wiadomosc/Zamach-stanu-w-Serbii-Prezydent-Vuczic-Rosjanie-mnie-poinformowali-8795517.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zamach-stanu-w-Serbii-Prezydent-Vuczic-Rosjanie-mnie-poinformowali-8795517.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T15:23:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/e9baf9e8ba1a98-948-568-80-0-2600-1560.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Służby rosyjskie poinformowały mnie o planowanym w Serbii zamachu stanu - powiedział serbski prezydent Aleksandar Vuczić, cytowany w sobotę przez telewizję N1.]]&gt;

## Prawie połowa Włochów chce przeciwdziałania nadmiernej turystyce
 - [https://www.bankier.pl/wiadomosc/Prawie-polowa-Wlochow-chce-przeciwdzialania-nadmiernej-turystyce-8795514.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prawie-polowa-Wlochow-chce-przeciwdzialania-nadmiernej-turystyce-8795514.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T15:10:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/ebb62d9bb1fdd8-948-567-0-65-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawie połowa Włochów opowiada się za wprowadzeniem kroków, które zredukują konsekwencje tak zwanej nadmiernej turystyki. Wyniki sondażu opublikowano w szczycie sezonu turystycznego, który w tym roku mija pod znakiem rekordowego napływu turystów, przede wszystkim zagranicznych.]]&gt;

## Finlandia wprowadza zakaz korzystania ze smartfonów podczas lekcji
 - [https://www.bankier.pl/wiadomosc/Finlandia-wprowadza-zakaz-korzystania-ze-smartfonow-podczas-lekcji-8794228.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finlandia-wprowadza-zakaz-korzystania-ze-smartfonow-podczas-lekcji-8794228.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T15:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/74487fb7dcdbfc-948-568-0-0-2564-1538.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szkoła ma być wolna od "tiktoków" i innych kanałów mediów społecznościowych pochłaniających uwagę dzieci i młodzieży. W Helsinkach od czwartku, wraz z początkiem nowego roku szkolnego, wprowadzono jednolity zakaz korzystania z telefonów komórkowych w czasie godzin lekcyjnych. Po smartfona można sięgnąć tylko do pomocy w nauce i na polecenie nauczyciela – poinformowały władze fińskiej stolicy.]]&gt;

## Harris prowadzi w trzech kluczowych stanach
 - [https://www.bankier.pl/wiadomosc/Harris-prowadzi-w-trzech-kluczowych-stanach-8795511.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Harris-prowadzi-w-trzech-kluczowych-stanach-8795511.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T14:23:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/bce741d97b9783-948-568-0-9-3699-2219.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wiceprezydent USA Kamala Harris wyprzedza Donalda Trumpa w trzech kluczowych stanach - Michigan, Wisconsin i Pensylwanii - o 4 pkt proc. - wynika z opublikowanego w sobotę sondażu ośrodka Siena Polls dla dziennika "New York Times".]]&gt;

## Kaczyński o Błaszczaku: gdybyśmy rządzili, byłby prezydentem
 - [https://www.bankier.pl/wiadomosc/Kaczynski-o-Blaszczaku-gdybysmy-rzadzili-bylby-prezydentem-8795503.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-o-Blaszczaku-gdybysmy-rzadzili-bylby-prezydentem-8795503.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T13:14:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/7437b360738886-948-568-43-130-3433-2060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak powiedział w sobotę dziennikarzom prezes PiS Jarosław Kaczyński, jest on przekonany, że gdyby w Polsce rządził PiS, to prezydentem byłby przewodniczący klubu Mariusz Błaszczak.]]&gt;

## Astronauci wysłani przez Boeinga pozostaną w kosmosie na dłużej. NASA rozważa opcje
 - [https://www.bankier.pl/wiadomosc/Astronauci-wyslani-przez-Boeinga-pozostana-w-kosmosie-na-dluzej-NASA-rozwaza-opcje-8794326.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Astronauci-wyslani-przez-Boeinga-pozostana-w-kosmosie-na-dluzej-NASA-rozwaza-opcje-8794326.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T13:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/6c41997020a95a-948-568-24-13-1008-605.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Astronauci NASA Suni Williams i Butch Wilmore 
polecieli na Międzynarodową Stację Kosmiczną 5 czerwca 2024 r. i mieli 
pozostać tam około 10 dni. Firma Boeing, zapewniająca podwózkę na ten 
wyjazd, przedłużyła im jednak tę przyjemność. Kapsuła Starliner doznała 
usterki i NASA rozważa sprowadzenie załogi na ziemię innym pojazdem. Na 
przykład tym od firmy, której nazwa kończy się na "X", a zaczyna na 
"Space".]]&gt;

## Musk wpływa na kampanię wyborczą w USA? Jego mylące czy fałszywe posty na X mają ponad 1,2 mld wyświetleń
 - [https://www.bankier.pl/wiadomosc/Musk-wplywa-na-kampanie-wyborcza-w-USA-Jego-mylace-czy-falszywe-posty-na-X-maja-ponad-1-2-mld-wyswietlen-8794834.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Musk-wplywa-na-kampanie-wyborcza-w-USA-Jego-mylace-czy-falszywe-posty-na-X-maja-ponad-1-2-mld-wyswietlen-8794834.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T13:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/faf0782beaedb1-948-568-97-0-3166-1899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fałszywe lub mylące informacje na temat wyborów w USA przekazywane przez Elona Muska w  jego sieci społecznościowej X miały  w tym roku ponad 1,2 mld wyświetleń. Centrum do Walki z Nienawiścią Online (CCDH) podkreśliło wpływ miliardera wspierającego Donald Trumpa na kampanię wyborczą.]]&gt;

## Uciążliwa nowa zakopianka. Mieszkańcy wsi żądają ekranów akustycznych i odszkodowań
 - [https://www.bankier.pl/wiadomosc/Uciazliwa-nowa-zakopianka-Mieszkancy-wsi-zadaja-ekranow-akustycznych-i-odszkodowan-8794561.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Uciazliwa-nowa-zakopianka-Mieszkancy-wsi-zadaja-ekranow-akustycznych-i-odszkodowan-8794561.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T12:30:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/e1bbba61743ea3-948-568-178-244-4042-2425.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mieszkańcy wsi Lasek (Nowy Targ), nad którą po estakadzie na wysokości 20 m biegnie nowa zakopianka, chcą ekranów akustycznych i rekompensat za uciążliwości związane z budową. GDDKiA na razie nie zamierza stawiać ekranów i twierdzi, że odszkodowań można domagać się indywidualnie od wykonawcy.]]&gt;

## Łukaszenka: Nad Białorusią zniszczono kilka celów wystrzelonych przez Ukrainę
 - [https://www.bankier.pl/wiadomosc/Lukaszenka-Nad-Bialorusia-zniszczono-kilka-celow-wystrzelonych-przez-Ukraine-8795495.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lukaszenka-Nad-Bialorusia-zniszczono-kilka-celow-wystrzelonych-przez-Ukraine-8795495.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T11:47:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/490629c3f8be79-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Białoruskie siły obrony powietrznej zniszczyły w piątek nad terytorium kraju kilka celów, najprawdopodobniej dronów, wystrzelonych z Ukrainy – powiedział w sobotę prezydent Aleksandr Łukaszenka, cytowany przez białoruską agencję informacyjną BiełTA.]]&gt;

## Co trzeci podróżny nie kupuje ubezpieczenia turystycznego. "Nic się nie stanie"
 - [https://www.bankier.pl/wiadomosc/Co-trzeci-podrozny-nie-kupuje-ubezpieczenia-turystycznego-Nic-sie-nie-stanie-8792655.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-trzeci-podrozny-nie-kupuje-ubezpieczenia-turystycznego-Nic-sie-nie-stanie-8792655.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T11:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/37bc772ef03e43-948-568-2-192-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />34 proc. Polaków nie zamierza kupować ubezpieczenia turystycznego podczas tegorocznego lata. Średni budżet, jaki w tym roku zamierzają przeznaczyć Polacy na swój urlop, wzrósł rdr o 608 zł i wynosi obecnie 5 tys. 464 zł - wynika z raportu Allianz Partners.]]&gt;

## Dostali telefony, ale ich nie zatrzymają? Ci olimpijczycy stracą okolicznościowe samsungi
 - [https://www.bankier.pl/wiadomosc/Dostali-telefony-ale-ich-nie-zatrzymaja-Ci-olimpijczycy-straca-okolicznosciowe-samsungi-8795109.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dostali-telefony-ale-ich-nie-zatrzymaja-Ci-olimpijczycy-straca-okolicznosciowe-samsungi-8795109.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T11:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/9b093a74474641-948-568-129-226-1254-752.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszyscy sportowcy biorący udział w Igrzyskach Olimpijskich otrzymali od firmy Samsung, będącej sponsorem imprezy, olimpijską wersję smartfona Galaxy Z Flip 6. Okazuje się jednak, że pochodzący z Korei Północnej uczestnicy mogą nie dostać pozwolenia na zabranie telefonów ze sobą do kraju.]]&gt;

## Elektrownia jądrowa Kursk pracuje normalnie
 - [https://www.bankier.pl/wiadomosc/Rosatom-elektrownia-jadrowa-Kursk-pracuje-normalnie-8795478.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosatom-elektrownia-jadrowa-Kursk-pracuje-normalnie-8795478.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T10:03:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/5/e87261103bf9b0-920-552-35-57-920-552.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Elektrownia jądrowa Kursk w mieście Kurczatow w obwodzie kurskim na zachodzie Rosji działa normalnie – podał w sobotę państwowy koncern Rosatom, cytowany przez Reutersa. Od kilku dni w obwodzie trwa ofensywa sił ukraińskich, w piątek władze informowały o walkach w odległości kilkudziesięciu kilometrów od siłowni.]]&gt;

## Praca przymusowa ciągle żywa. Zatrudnieni w budżetówce odwoływani z urlopów na zbiór bawełny
 - [https://www.bankier.pl/wiadomosc/Praca-przymusowa-ciagle-zywa-Zatrudnieni-w-budzetowce-odwolywani-z-urlopow-na-zbior-bawelny-8793156.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Praca-przymusowa-ciagle-zywa-Zatrudnieni-w-budzetowce-odwolywani-z-urlopow-na-zbior-bawelny-8793156.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T09:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/e6a931df1cd745-948-568-0-265-3936-2361.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pracownicy sektora budżetowego w położonym na zachodzie Turkmenistanu wilajecie (obwodzie) balkańskim, w tym nauczyciele i lekarze, zostali zmuszeni do przerwania urlopów i pomocy przy przycinaniu oraz zbiorze bawełny - poinformował Azatlyk, turkmeńska sekcja portalu Radia Swoboda.]]&gt;

## Te kraje UE produkują najwięcej lodów. Niemcy wytwarzają najtaniej
 - [https://www.bankier.pl/wiadomosc/Te-kraje-UE-produkuja-najwiecej-lodow-Niemcy-wytwarzaja-najtaniej-8793863.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Te-kraje-UE-produkuja-najwiecej-lodow-Niemcy-wytwarzaja-najtaniej-8793863.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T09:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/b072440289fc1a-948-568-43-0-1800-1080.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kraje UE w 2023 roku wyprodukowały 3,2 mld litrów lodów, o 1,4 proc. mniej rdr - podał Eurostat.]]&gt;

## Nie żyje była szefowa YouTube. Susan Wojcicki była najbardziej wpływową kobietą internetu wg "Time"
 - [https://www.bankier.pl/wiadomosc/Susan-Wojcicki-nie-zyje-Byla-szefowa-YouTube-przegrala-z-rakiem-8795460.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Susan-Wojcicki-nie-zyje-Byla-szefowa-YouTube-przegrala-z-rakiem-8795460.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T08:18:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/ae503eb077908b-948-568-0-0-948-568.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie żyje była dyrektor generalna YouTube i jedna z pierwszych pracownic Google - Susan Wojcicki. 56-latka przegrała dwuletnią walkę z rakiem. Sundar Pichai, CEO Google, poinformował o jej śmierci w sobotę na platformie X.]]&gt;

## Cudzoziemcy pracują poniżej kwalifikacji. Polska powyżej średniej UE
 - [https://www.bankier.pl/wiadomosc/Cudzoziemcy-pracuja-ponizej-kwalifikacji-Polska-powyzej-sredniej-UE-8795454.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cudzoziemcy-pracuja-ponizej-kwalifikacji-Polska-powyzej-sredniej-UE-8795454.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T07:46:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/aa7d481b1d3943-945-567-0-0-2180-1308.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />48 proc. cudzoziemców zatrudnionych w Polsce ma wyższe kwalifikacje niż oczekuje pracodawca - informuje w Tygodniku Gospodarczym Polski Instytut Ekonomiczny (PIE). W Unii Europejskiej średni odsetek obcokrajowców pracujących poniżej kwalifikacji wynosi 39,4 proc.]]&gt;

## Kolejny urząd miasta w Polsce skróci czas pracy. "Warto dbać o taki balans między życiem prywatnym a zawodowym"
 - [https://www.bankier.pl/wiadomosc/Kolejny-urzad-miasta-w-Polsce-skroci-czas-pracy-Warto-dbac-o-taki-balans-miedzy-zyciem-prywatnym-a-zawodowym-8794173.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejny-urzad-miasta-w-Polsce-skroci-czas-pracy-Warto-dbac-o-taki-balans-miedzy-zyciem-prywatnym-a-zawodowym-8794173.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T07:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/8f697679fa0403-948-568-0-0-3727-2236.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od września w Urzędzie Miasta we Włocławku zostanie wprowadzony 35-godzinny tydzień pracy. Nie zmieni się czas funkcjonowania i dostępności urzędu dla mieszkańców - poinformował prezydent miasta Krzysztof Kukucki.]]&gt;

## Tak Rosja i Chiny chcą ominąć zachodnie sankcje i to już niebawem
 - [https://www.bankier.pl/wiadomosc/Tak-Rosja-i-Chiny-chca-ominac-zachodnie-sankcje-i-to-juz-niebawem-8794738.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-Rosja-i-Chiny-chca-ominac-zachodnie-sankcje-i-to-juz-niebawem-8794738.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T07:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/dfe22158869835-948-568-160-0-3750-2249.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosja i Chiny mogą już jesienią rozpocząć wymianę barterową, by podczas płatności ominąć zachodnie sankcje oraz system bankowy uważnie monitorowany przez USA - pisze Reuters, powołując się na źródła w rosyjskim sektorze handlowym i finansowym.]]&gt;

## Poparcie dla wprowadzenia euro w Polsce coraz mniejsze
 - [https://www.bankier.pl/wiadomosc/Poparcie-dla-wprowadzenia-euro-w-Polsce-coraz-mniejsze-8795436.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Poparcie-dla-wprowadzenia-euro-w-Polsce-coraz-mniejsze-8795436.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T05:46:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/dc71b2bb45f28e-948-568-120-0-3720-2231.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poparcie dla wprowadzenia "za kilka lat" europejskiej waluty w Polsce wynosi obecnie 30,7 proc., co stanowi spadek z 34,9 proc. rok do roku - wynika z badania zrealizowanego na zlecenie Fundacji Wolności Gospodarczej. Jak zaznaczono, silny spadek poparcia miał miejsce wśród kobiet.]]&gt;

## Dzieci w biurze. Czy firma może zakazać przyprowadzania pociech przez pracowników?
 - [https://www.bankier.pl/wiadomosc/Dzieci-w-biurze-Czy-firma-moze-zakazac-przyprowadzania-pociech-przez-pracownikow-8790118.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dzieci-w-biurze-Czy-firma-moze-zakazac-przyprowadzania-pociech-przez-pracownikow-8790118.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T05:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/5/56303e6f21ee3a-948-568-0-0-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Są wakacje, czas, który dla wielu rodzin z małymi 
dziećmi bywa trudny pod względem możliwości zapewnienia opieki nad 
pociechami. A może by tak wziąć je od czasu do czasu do biura? Czy 
pracodawca może nam tego zakazać?]]&gt;

## Już niemal 6000 osób w konkursie „Wakacje na giełdzie”
 - [https://www.bankier.pl/wiadomosc/Juz-niemal-6000-osob-w-konkursie-Wakacje-na-gieldzie-8795094.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Juz-niemal-6000-osob-w-konkursie-Wakacje-na-gieldzie-8795094.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T05:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/f/0411fbcacd313f-948-568-20-50-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zawierucha na giełdach tylko zaostrzyła apetyty inwestorów. Mamy dużą frekwencję, wysokie zyski liderów i… sporą „rowerową” niespodziankę dla młodszych uczestników konkursu.  ]]&gt;

## Krwawy tydzień na rynkach. Krach w Japonii wywołał tsunami spadków na światowych giełdach
 - [https://www.bankier.pl/wiadomosc/Krwawy-tydzien-na-rynkach-Krach-w-Japonii-wywolal-tsunami-spadkow-na-swiatowych-gieldach-8794867.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Krwawy-tydzien-na-rynkach-Krach-w-Japonii-wywolal-tsunami-spadkow-na-swiatowych-gieldach-8794867.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T05:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/0/67d344ecceb155-948-567-0-34-1150-689.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sytuacja na japońskiej giełdzie spowodowała przelanie
 się czerwonego tsunami przez wszystkie światowe rynki (a prawdziwe 
tsunami uderzyło niewiele później). Rzucimy też okiem między innymi na 
to, jakie trendy kształtują się na rynku mieszkań oraz co z tymi 
kryptowalutami. Oto najciekawsze wykresy ostatnich kilku dni.]]&gt;

## Ulgi na rynku nieruchomości nie będzie. Ceny mieszkań nadal będą rosnąć
 - [https://www.bankier.pl/wiadomosc/Ulgi-na-rynku-nieruchomosci-nie-bedzie-Ceny-mieszkan-nadal-beda-rosnac-8793829.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ulgi-na-rynku-nieruchomosci-nie-bedzie-Ceny-mieszkan-nadal-beda-rosnac-8793829.html?utm_source=RSS&amp;utm_medium=RSS&amp;utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-08-10T05:00:00+00:00

<img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/b77a6f72d6f862-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost cen na rynku pierwotnym i wtórnym w III i IV kwartale ustabilizuje się na poziomie zbliżonym do 10 proc., przy założeniu utrzymania głównych zmiennych makroekonomicznych - prognozują ekonomiści Polskiego Instytutu Ekonomicznego.]]&gt;

