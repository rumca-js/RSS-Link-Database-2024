# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## 1940s - Mexico & Veracruz in color [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=BN8cCKhaje8](https://www.youtube.com/watch?v=BN8cCKhaje8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2024-08-10T22:11:07+00:00

I colorized, restored and created a sound design for this video of Mexico City and Veracruz 1940s, we can see what's going on in broad daylight.

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔sound design added only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

B&amp;W Video Source: Internet Archive

Join this channel to benefit from exclusive advantages and also to support us: https://www.youtube.com/channel/UC1W8ShdwtfgjRHdbl1Lctcw/join

