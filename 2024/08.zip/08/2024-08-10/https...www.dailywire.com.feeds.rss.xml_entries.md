# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## MSNBC Host Jonathan Capehart: Kamala Harris Told Her Team That Her Boost In Polls Is Just ‘Sugar High’
 - [https://www.dailywire.com/news/msnbc-host-jonathan-capehart-kamala-harris-told-her-team-that-her-boost-in-polls-is-just-sugar-high](https://www.dailywire.com/news/msnbc-host-jonathan-capehart-kamala-harris-told-her-team-that-her-boost-in-polls-is-just-sugar-high)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T18:12:06+00:00

MSNBC host Jonathan Capehart warned Democrats late this week that the hundreds of millions of dollars in positive earned media that Vice President Kamala Harris has gotten in recent weeks may be coming to an end soon as the &#8220;sugar high&#8221; wears off. Capehart, who is a columnist at The Washington Post, made the remarks ...

## ‘Really, That Song?’: Celine Dion Gets Mad At Trump For ‘Titanic’ Rally Music Choice
 - [https://www.dailywire.com/news/really-that-song-celine-dion-gets-mad-at-trump-for-titanic-rally-music-choice](https://www.dailywire.com/news/really-that-song-celine-dion-gets-mad-at-trump-for-titanic-rally-music-choice)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T18:08:17+00:00

Celine Dion made it clear she&#8217;s upset with former President Donald Trump’s campaign after she said it used one of her songs at a rally in Montana on Friday. In a post on Saturday on X, the 56-year-old Grammy winner’s management team on behalf of Dion and her record label released a statement about how ...

## Iran Hacks Trump Campaign, Obtains File On JD Vance: Trump Official
 - [https://www.dailywire.com/news/iran-hacks-trump-campaign-obtains-file-on-jd-vance-trump-official](https://www.dailywire.com/news/iran-hacks-trump-campaign-obtains-file-on-jd-vance-trump-official)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T15:09:14+00:00

The Islamic Republic of Iran, the world&#8217;s leading state sponsor of terrorism, has reportedly hacked Republican presidential nominee Donald Trump&#8217;s campaign. Politico began receiving internal campaign documents from the campaign late last month from an anonymous AOL email account that used the name &#8220;Robert.&#8221; The emails contained internal communications from a top Trump campaign official ...

## Another Fighter Who Failed Gender Tests Wins Gold In Women’s Boxing, Bloodies Opponent
 - [https://www.dailywire.com/news/another-fighter-who-failed-gender-tests-wins-gold-in-womens-boxing-bloodies-opponent](https://www.dailywire.com/news/another-fighter-who-failed-gender-tests-wins-gold-in-womens-boxing-bloodies-opponent)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T15:01:38+00:00

A fighter who failed past gender eligibility tests won gold in the women&#8217;s Olympic featherweight final match on Saturday. Lin Yu-ting of Taiwan, 28, absolutely dominated 20-year-old fighter Julia Szeremeta of Poland, leaving the female fighter bloodied. Lin, who physically towered over Szeremeta, won the match in a unanimous decision. &#8220;These two right now are ...

## Tim Walz’s Boss In National Guard Blasts Him For Cowardly Exit: ‘He Did Something Wrong In Service’
 - [https://www.dailywire.com/news/tim-walzs-boss-in-national-guard-blasts-him-for-cowardly-exit-he-did-something-wrong-in-service](https://www.dailywire.com/news/tim-walzs-boss-in-national-guard-blasts-him-for-cowardly-exit-he-did-something-wrong-in-service)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T14:26:14+00:00

Minnesota Governor Tim Walz&#8217;s direct superior in the National Guard said this week that Walz went behind his back to get out of having to deploy to Iraq because Walz knew that he would have said no. Doug Julin — who oversaw Walz in the Minnesota National Guard as a more senior command sergeant in ...

## Trump Decries ‘Vicious’ Illegal Immigrant Suspected Of Murdering Nashville Restaurant Owner
 - [https://www.dailywire.com/news/trump-decries-vicious-illegal-immigrant-suspected-of-murdering-nashville-restaurant-owner](https://www.dailywire.com/news/trump-decries-vicious-illegal-immigrant-suspected-of-murdering-nashville-restaurant-owner)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T14:13:39+00:00

Speaking at a packed rally on Friday night in Montana, former President Donald Trump lamented the death of a Nashville business owner who police say was killed by an illegal immigrant from Mexico in a deadly hit-and-run. During his rally, Trump spoke about 42-year-old Matt Carney, a restaurant owner who died in Nashville on July ...

## Vance Says Harris Would ‘Build That Border Wall In Five Seconds’ If Illegals Were Journalists
 - [https://www.dailywire.com/news/vance-says-harris-would-build-that-border-wall-in-five-seconds-if-illegals-were-journalists](https://www.dailywire.com/news/vance-says-harris-would-build-that-border-wall-in-five-seconds-if-illegals-were-journalists)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T14:04:29+00:00

Trump VP pick JD Vance mocked VP Kamala Harris on Friday over both her poor job as the Biden administration&#8217;s &#8220;border czar&#8221; and her continued refusal to take real questions from reporters. &#8220;If we could convince Kamala Harris that illegal aliens are actually journalists trying to ask her questions she&#8217;d build that border wall in ...

## ‘Yeah, I Am Radical’: New Trump Ad Use Kamala’s Own Words Against Her
 - [https://www.dailywire.com/news/yeah-i-am-radical-new-trump-ad-use-kamalas-own-words-against-her](https://www.dailywire.com/news/yeah-i-am-radical-new-trump-ad-use-kamalas-own-words-against-her)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-08-10T09:25:09+00:00

During a rally on Friday, former President Donald Trump played a new ad which takes aim at Vice President Kamala Harris by using her own past remarks against her. Harris, the Democrats&#8217; effective 2024 presidential nominee, has an extremely left-wing history in politics, and voiced similarly radical positions during her failed 2020 presidential run. Video ...

