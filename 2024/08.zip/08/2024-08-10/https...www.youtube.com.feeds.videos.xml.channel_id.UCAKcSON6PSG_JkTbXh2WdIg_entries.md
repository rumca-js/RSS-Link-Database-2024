# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Reiki performs at Carbon Sound Presents: Minnesota Music Month showcase (full performance)
 - [https://www.youtube.com/watch?v=nCxYrBORQ3o](https://www.youtube.com/watch?v=nCxYrBORQ3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2024-08-10T02:00:21+00:00

Reiki performs at Carbon Sound Presents: Minnesota Music Month showcase
Support The Current: https://support.mpr.org/youtube

Singer/songwriter and producer Reiki performed at Carbon Sound Presents: Minnesota Music Month showcase in April, featuring MMYYKK, XINA and Zora. 

Watch Reiki’s full performance above.

Video Segments
00:00:00 Leave Ya Side
00:03:53 Chaos
00:09:41 NVM
00:15:00 Rage
00:17:30 Break The Waves
00:19:33 Dripping Sweat

Musicians
Reiki Michael Hall - vocals
Jake Beitel - guitar
Henry Breen - bass
Jon Lindquist - drums

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.com/thecurrent/
https://www.threads.net/@thecurrent
https://www.tiktok.com/@thecurrent.org

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#Reiki #music #minneapolis

