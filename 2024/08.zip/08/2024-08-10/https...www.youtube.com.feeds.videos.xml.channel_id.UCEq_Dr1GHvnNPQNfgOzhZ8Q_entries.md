# Source:Solid jj, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q, language:en-US

## Green Lantern's Powers are BULLSH*T
 - [https://www.youtube.com/watch?v=plfivKFI-Dw](https://www.youtube.com/watch?v=plfivKFI-Dw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q
 - date published: 2024-08-10T18:56:43+00:00

The Justice League discuss why Green Lantern's powers are kind of goofy. Like if you think about it. Like for a bit. Like Superman and Batman thought about it and that's the conclusion they reach. Like just think about it. For a second. Seriously. Please.

10% Gamer Supps (Code: SOLID) ▼
https://gamersupps.gg/SOLID

Art by @TheFrenchPineapple 

Twitch: https://twitch.tv/solidjj
Podcast: @JoeSchmoesPodcast 

Second channel:​⁠ @Solidusjj 
Patreon: https://patreon.com/solidjj
BadTakeDelete Discord: https://discord.gg/X5ttfJR6es

