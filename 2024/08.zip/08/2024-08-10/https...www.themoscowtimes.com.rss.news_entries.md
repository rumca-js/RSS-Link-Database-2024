# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Russia Evacuates Tens of Thousands Amid Ukraine Incursion
 - [https://www.themoscowtimes.com/2024/08/10/russia-evacuates-tens-of-thousands-amid-ukraine-incursion-a85987](https://www.themoscowtimes.com/2024/08/10/russia-evacuates-tens-of-thousands-amid-ukraine-incursion-a85987)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-08-10T16:21:00+00:00

Russia has struggled to put down the major Ukrainian incursion for a fifth day.

## Live: Ukraine Presses Onward With Kursk Incursion
 - [https://www.themoscowtimes.com/2024/08/10/live-ukraine-presses-onward-with-kursk-incursion-a85985](https://www.themoscowtimes.com/2024/08/10/live-ukraine-presses-onward-with-kursk-incursion-a85985)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-08-10T06:38:00+00:00

Russia says evacuated more than 76K from border area.
								Rosatom head warns of “threat” to Kursk nuclear power plant.
								Counter-terrorism regime declared in three Russian border regions.
												All the latest breaking news and developments in the Ukrainian incursion into Russia's Kursk region.

