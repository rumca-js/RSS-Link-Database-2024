# Source:It's FOSS News, URL:https://news.itsfoss.com/rss, language:en-US

## Raspberry Pi Pico 2 Released With A Pinch Of RISC-V
 - [https://news.itsfoss.com/raspberry-pi-pico-2](https://news.itsfoss.com/raspberry-pi-pico-2)
 - RSS feed: https://news.itsfoss.com/rss
 - date published: 2024-08-10T04:15:13+00:00

The Raspberry Pi Pico 2 is available for just $5!

