# Source:The RISC-V Instruction Set Architecture, URL:https://www.reddit.com/r/RISCV/.rss, language:en

## VeeR EL2 RISC-V SOC
 - [https://www.reddit.com/r/RISCV/comments/1eoozui/veer_el2_riscv_soc](https://www.reddit.com/r/RISCV/comments/1eoozui/veer_el2_riscv_soc)
 - RSS feed: https://www.reddit.com/r/RISCV/.rss
 - date published: 2024-08-10T09:30:51+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone,</p> <p>I'm interested in the open-source hardware movement. I am currently working on reverse engineering the VeeR EL2 RISC-V SoC and trying to understand its microarchitecture. The VeeR EL2 is developed by Westrendigital, and they have closed-sourced its microarchitecture.</p> <p>I am writing to ask for guidance and resources that can help me with my mission.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Healthy-Buy9660"> /u/Healthy-Buy9660 </a> <br /> <span><a href="https://www.reddit.com/r/RISCV/comments/1eoozui/veer_el2_riscv_soc/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/RISCV/comments/1eoozui/veer_el2_riscv_soc/">[comments]</a></span>

