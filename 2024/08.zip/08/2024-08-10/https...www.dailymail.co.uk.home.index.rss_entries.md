# Source:Daily Mail - Home, URL:https://www.dailymail.co.uk/home/index.rss, language:en-gb

## Katie Price 'blew £10,000 in a month on designer clothes and takeaways' after being declared bankrupt
 - [https://www.dailymail.co.uk/tvshowbiz/article-13731655/Katie-Price-blew-10-000-month-designer-clothes-takeaways-declared-bankrupt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13731655/Katie-Price-blew-10-000-month-designer-clothes-takeaways-declared-bankrupt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T23:33:48+00:00

The former glamour model, 46, reportedly 'blew £10,000 in a month on designer clothes and takeaways' after she was declared bankrupt.

## Now one of the Archbishop of Canterbury 's own vicars condemns his attacks on Israel - as he says if you insist on talking politics, then get it right
 - [https://www.dailymail.co.uk/debate/article-13731491/Now-Archbishop-Canterbury-vicar-condemns-attacks-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13731491/Now-Archbishop-Canterbury-vicar-condemns-attacks-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:47:14+00:00

The Archbishop of Canterbury, Justin Welby , decided to wade in where angels fear to tread, and contribute his verdict on the politics of Israel-Palestine.

## Richard Kilty completed remarkable comeback with relay bronze after being stripped of Tokyo silver and battling back from surgery - no British Olympian has smiled wider in Paris, writes DAVID COVERDALE
 - [https://www.dailymail.co.uk/sport/olympics/article-13730935/Richard-Kiltyrelay-bronz-Tokyo-surgery-Olympian-Paris-DAVID-COVERDALE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13730935/Richard-Kiltyrelay-bronz-Tokyo-surgery-Olympian-Paris-DAVID-COVERDALE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:43:11+00:00

The 34-year-old received a bronze medal at the Stade de France on Friday night from the 4x100 metres relay.

## Danny Cipriani's estranged wife Victoria files for divorce with claims he blows £600 a month on drugs and admits she's 'heartbroken' over his new relationship with AnnaLynne McCord
 - [https://www.dailymail.co.uk/tvshowbiz/article-13731609/Danny-Ciprianis-estranged-wife-Victoria-files-divorce-claims-blows-600-month-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13731609/Danny-Ciprianis-estranged-wife-Victoria-files-divorce-claims-blows-600-month-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:28:49+00:00

In a new interview, Victoria, 42, claimed the former rugby player blew £600 a month on drugs, messaged other women and feels 'humiliated' by his new romance'

## Simone Biles rallies behind US gymnast Jordan Chiles who may LOSE her Olympic bronze medal five days after winning it on a technicality as her sister slams bombshell ruling that hands medal to Romanian opponent... but IOC won't be rushed on a decision
 - [https://www.dailymail.co.uk/sport/olympics/article-13731635/simone-biles-jordan-chiles-olympics-lose-bronze-medal-sister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13731635/simone-biles-jordan-chiles-olympics-lose-bronze-medal-sister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:09:37+00:00

The team USA poster girl said she was sending 'so much love' to her teammate, telling the 23-year-old to 'keep your chin up' as she faces being stripped of her medal.

## ROSS CLARK: Before carpeting Britain with your beloved solar panels, Ed, spare a thought for the slave labour building them in China
 - [https://www.dailymail.co.uk/debate/article-13731497/ROSS-CLARK-carpeting-Britain-beloved-solar-panels-Ed-spare-thought-slave-labour-building-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13731497/ROSS-CLARK-carpeting-Britain-beloved-solar-panels-Ed-spare-thought-slave-labour-building-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:07:37+00:00

ROSS CLARK: Ed Miliband's plan to plaster the countryside with solar panels is likely to create more jobs for Uyghur slaves in China than blue collar workers in Britain.

## Security chiefs: PM kept in dark by aide Sue Gray - Starmer's chief of staff accused of 'thinking she runs Britain' as MoS is told she blocked top-level briefings
 - [https://www.dailymail.co.uk/news/article-13731469/Security-chiefs-PM-kept-dark-aide-Sue-Gray-Starmers-chief-staff-accused-thinking-runs-Britain-MoS-told-blocked-level-briefings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731469/Security-chiefs-PM-kept-dark-aide-Sue-Gray-Starmers-chief-staff-accused-thinking-runs-Britain-MoS-told-blocked-level-briefings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:06:11+00:00

Whitehall sources have suggested that even Cabinet Secretary Simon Case has been forced to ask permission from Ms Gray to speak to the Prime Minister.

## Banksy's new cat artwork is 'taken down and could be thrown in a rubbish skip' just hours after it was first spotted - as meaning behind elusive artist's graffiti is revealed
 - [https://www.dailymail.co.uk/news/article-13731263/Banksys-new-cat-artwork-taken-thrown-rubbish-skip-just-hours-spotted-meaning-elusive-artists-graffiti-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731263/Banksys-new-cat-artwork-taken-thrown-rubbish-skip-just-hours-spotted-meaning-elusive-artists-graffiti-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:05:35+00:00

The black silhouette of a large cat stretching on an abandoned signage appeared in Cricklewood, north London overnight - with the artist confirming he was behind it with an Instagram post.

## Netherlands disqualified for 'endangering another rider' after Team GB's Ollie Wood appeared to be HEADBUTTED by Dutch rival and crashed in men's madison final
 - [https://www.dailymail.co.uk/sport/olympics/article-13731741/Netherlands-disqualified-endangering-Team-GB-Ollie-Wood-HEADBUTTED-mens-madison-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13731741/Netherlands-disqualified-endangering-Team-GB-Ollie-Wood-HEADBUTTED-mens-madison-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T22:01:28+00:00

The flashpoint came with 40 laps remaining in the madison, when Team GB's Ollie Wood was suddenly catapulted into a hard fall after his helmet was struck from behind by that of Jan Willem van Schip.

## 'This would be a disaster for us!' How the tiny village earmarked to be expanded to a city the size of Coventry with 350,000 people is fighting back - but can ANYTHING stop the bulldozers?
 - [https://www.dailymail.co.uk/news/article-13730365/This-disaster-tiny-village-Labour-wants-build-350-000-homes-fighting-stop-bulldozers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730365/This-disaster-tiny-village-Labour-wants-build-350-000-homes-fighting-stop-bulldozers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T21:43:15+00:00

Tempsford, a lovely higgledy-piggledy mix of thatched cottages, grand  houses and a smattering of more modern dwellings, has been earmarked as the prime candidate for a potential new 'supercity'.

## Lin Yu-ting joins fellow gender row boxer Imane Khelif in winning Olympic gold as she beats Julia Szeremeta in the women's featherweight final
 - [https://www.dailymail.co.uk/sport/boxing/article-13731455/Gender-row-boxer-Lin-Yu-Ting-joins-Imane-Khelif-winning-Olympic-gold-beats-Julia-Szeremeta-womens-featherweight-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/boxing/article-13731455/Gender-row-boxer-Lin-Yu-Ting-joins-Imane-Khelif-winning-Olympic-gold-beats-Julia-Szeremeta-womens-featherweight-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T21:35:44+00:00

SHEKHAR BHATIA AND NICK FAGGE IN PARIS: Lin reigned supreme and punched her way towards an Olympic gold medal to become the second woman here to hit her critics where it hurts.

## Amanda Abbington 'is questioned for a second time' by the BBC over her claims Giovanni Pernice made crude remarks amid Strictly misconduct probe
 - [https://www.dailymail.co.uk/tvshowbiz/article-13731451/Amanda-Abbington-questioned-second-time-BBC-bosses-Giovanni-Pernice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13731451/Amanda-Abbington-questioned-second-time-BBC-bosses-Giovanni-Pernice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T21:28:15+00:00

The Sherlock star, 50, is said to have been quizzed via video call last week as she sat down with two ex-Met detectives to discuss her allegations about the professional dancer, 33.

## Exposed: Websites where NHS doctors will sign you off sick for a £25 fee... even if you just fancy a day at the beach
 - [https://www.dailymail.co.uk/news/article-13731617/NHS-doctors-sign-sick-fancy-day-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731617/NHS-doctors-sign-sick-fancy-day-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T21:23:56+00:00

Doctors moonlighting for extra cash are signing buy-to-order sick notes without even a conversation with the patient, a Mail on Sunday investigation has uncovered.

## Inside Tyson Fury's youngest daughter Athena's lavish 3rd birthday party as wife Paris throws an all pink bash with makeovers and performers on stilts
 - [https://www.dailymail.co.uk/tvshowbiz/article-13731375/Tyson-Fury-daughter-Athenas-lavish-3rd-birthday-party-wife-Paris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13731375/Tyson-Fury-daughter-Athenas-lavish-3rd-birthday-party-wife-Paris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T21:09:55+00:00

Taking to Instagram Paris, 35, shared a glimpse of the celebrations which included performers on stilts.

## Hollywood A-list star looks unrecognisable as she tucks into a Pret sandwich on train to Edinburgh- but can you guess who it is?
 - [https://www.dailymail.co.uk/tvshowbiz/article-13730461/Hollywood-list-star-unrecognisable-Pret-sandwich-train-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13730461/Hollywood-list-star-unrecognisable-Pret-sandwich-train-Edinburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T20:57:07+00:00

A Hollywood A-list star stunned train staff after she tucked into her Pret sandwich en route to Edinburgh.

## Eight cancer doctors 'who dedicated their lives to saving others' among the 62 passengers and crew dead on doomed Brazil flight that plunged from the sky and exploded in a fireball when they were on their way to conference
 - [https://www.dailymail.co.uk/news/article-13731431/Eight-cancer-doctors-dedicated-lives-passengers-crew-dead-doomed-Brazil-flight-plunged-sky-exploded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731431/Eight-cancer-doctors-dedicated-lives-passengers-crew-dead-doomed-Brazil-flight-plunged-sky-exploded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T20:31:43+00:00

Six leading oncologists and two resident medics, in their final year of training, were on their way from their home city of Cascavel to a cancer conference in Sao Paulo when the crash happened.

## USA water polo player pulls rivals trunks in SHOCK viral underwater camera clip from Paris Olympics
 - [https://www.dailymail.co.uk/sport/olympics/article-13731075/USA-polo-trunks-SHOCK-underwater-viral-Paris-Olympics-clip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13731075/USA-polo-trunks-SHOCK-underwater-viral-Paris-Olympics-clip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T20:23:19+00:00

The moment was surprisingly shown as a replay on television and inevitably pounced upon by a viewer who recorded the footage and uploaded it to TikTok.

## Shocking moment racist thug, 39, spits at a bus driver and calls him a 'Muslim terrorist b*****d' after being refused on board because he couldn't pay for his journey
 - [https://www.dailymail.co.uk/news/article-13730967/Shocking-moment-racist-thug-spits-bus-driver-calls-Muslim-terrorist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730967/Shocking-moment-racist-thug-spits-bus-driver-calls-Muslim-terrorist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T20:15:59+00:00

Michael Mongan was caught on camera shouting at the driver and punching the protective screen around his seat at 12.25pm on Wednesday in west London.

## Hilarious moment Tui pilot channels his 'inner headteacher' as he tells off rowdy passengers and lays down ground rules for family flight to Tenerife
 - [https://www.dailymail.co.uk/news/article-13731331/Hilarious-moment-Tui-pilot-channels-inner-headteacher-tells-rowdy-passengers-lays-ground-rules-family-flight-Tenerife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731331/Hilarious-moment-Tui-pilot-channels-inner-headteacher-tells-rowdy-passengers-lays-ground-rules-family-flight-Tenerife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T20:03:25+00:00

The TUI captain was forced to lay down the ground rules after some passengers 'pushed the bounds of what was tolerable' in the departure lounge at Glasgow Airport.

## Jenna Ortega criticizes Hollywood for being 'politically correct' saying it results in a loss of 'integrity'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13731137/Jenna-Ortega-Hollywood-politically-correct-integrity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13731137/Jenna-Ortega-Hollywood-politically-correct-integrity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T19:58:04+00:00

Jenna Ortega opened up about her feelings about the politically correct nature of Hollywood. 'The business that we work in is so touchy-feely,' Ortega said in an interview with Vanity Fair.

## Now Jess Phillips takes a swipe at Elon Musk: Safeguarding minister calls social media site X a 'despotic place of misery' after No 10 criticises the billionaire's suggestion 'civil war is inevitable' after riots by racist thugs
 - [https://www.dailymail.co.uk/news/article-13731277/Jess-Phillips-Elon-Musk-social-media-site-X-despotic-place-misery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731277/Jess-Phillips-Elon-Musk-social-media-site-X-despotic-place-misery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T19:18:48+00:00

Jess Phillips said although she had previously been 'massively addicted to Twitter ', referencing the former name of X, she had removed the app from her phone after Mr Musk took over the company.

## Stephanie Davis is pregnant! Soap star announces she's expecting her first child with partner Joe McKalroy as she details 'rollercoaster' fertility struggles following devastating miscarriage
 - [https://www.dailymail.co.uk/tvshowbiz/article-13730827/stephanie-davis-pregenant-hollyoaks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13730827/stephanie-davis-pregenant-hollyoaks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T18:38:11+00:00

The soap star , 31, who already shares seven-year-old son Caben with ex and former CBB star Jeremy McConnell, revealed her pregnancy had been a 'rollercoaster'.

## Amir Khan hits out at far-right thugs draping themselves in Union Jack
 - [https://www.dailymail.co.uk/news/article-13730177/Amir-Khan-hits-far-right-thugs-draping-Union-Jack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730177/Amir-Khan-hits-far-right-thugs-draping-Union-Jack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T18:07:12+00:00

The Olympic boxer, who won a silver medal at Athens 2004, spoke out over thugs using the Southport attacks to legitimise widespread disorder.

## Keely Hodgkinson swaps Paris for Marbella as she celebrates Olympic 800M win on a luxury yacht - donning £850 Louis Vuitton sliders and £510 Chanel sunglasses
 - [https://www.dailymail.co.uk/femail/article-13730669/Keely-Hodgkinson-celebrates-Olympic-gold-yacht-spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13730669/Keely-Hodgkinson-celebrates-Olympic-gold-yacht-spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T18:00:15+00:00

The Team GB star, 22, said a family holiday in Marbella was her 'first priority' after winning gold. True to her word, the 22-yeard old was spotted boarding a yacht in Spain this weekend.

## Thomas Bach steps down as Olympics president - with Lord Coe in the frame to replace him - and insists he is 'no longer the best captain' after receiving criticism for defending gender row boxer Imane Khelif's right to compete
 - [https://www.dailymail.co.uk/sport/olympics/article-13731175/Thomas-Bach-step-Olympics-president-admits-no-longer-best-captain-Lord-Sebastian-Coe-emerges-contender-replace-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13731175/Thomas-Bach-step-Olympics-president-admits-no-longer-best-captain-Lord-Sebastian-Coe-emerges-contender-replace-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T17:59:07+00:00

It had been thought that the 70-year-old may try and change the IOC's 12-year limit to extend his term at the helm. However, Bach told the General Assembly in Paris that he would leave the post.

## Watchmaker creates timepiece with remains of Spitfire that went down over France during Second World War
 - [https://www.dailymail.co.uk/news/article-13731067/Watchmaker-creates-timepiece-Spitfire-France-Second-World-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731067/Watchmaker-creates-timepiece-Spitfire-France-Second-World-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T17:33:18+00:00

In a tribute to Britain's once golden industry of watchmaking, designer Colin Andrews created 60 of the pieces from parts of the wartime aircraft, of which 58 have already been sold for £19,950.

## How Red Emperor Xi Jinping cynically used Covid to create the ultimate Big Brother society: From ferocious lockdowns to apps that spied on citizens' every move... and up to a million Muslims herded into concentration camps
 - [https://www.dailymail.co.uk/news/article-13730639/How-Red-Emperor-Xi-Jinping-cynically-used-Covid-create-ultimate-Big-Brother-society-ferocious-lockdowns-apps-spied-citizens-million-Muslims-herded-concentration-camps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730639/How-Red-Emperor-Xi-Jinping-cynically-used-Covid-create-ultimate-Big-Brother-society-ferocious-lockdowns-apps-spied-citizens-million-Muslims-herded-concentration-camps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T17:16:40+00:00

All dictators know there is no disaster that cannot be turned to their advantage. Covid began in the reign of Xi, the Red Emperor who determined the Chinese response would be led by politics, not science.

## Pictured: Experienced pilot killed in Brazilian plane crash which left 61 others dead after passenger jet 'fell out of the sky and exploded'
 - [https://www.dailymail.co.uk/news/article-13731093/pictured-experienced-pilot-killed-Brazilian-plane-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13731093/pictured-experienced-pilot-killed-Brazilian-plane-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T17:02:51+00:00

Captain Danilo Santos Romano, 35, was named today as the first victim of the horror crash in the city of Vinhedo on Friday, local news has reported.

## Noah Williams wins BRONZE in men's 10m platform final in stunning performance - after claiming silver with Tom Daley in synchronised event
 - [https://www.dailymail.co.uk/sport/olympics/article-13730773/Noah-Williams-wins-BRONZE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13730773/Noah-Williams-wins-BRONZE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:53:05+00:00

DAVID COVERDALE AT THE AQUATICS CENTRE: Williams produced two stunning final routines to secure a brilliant bronze medal and give him another reason to smile.

## DAN HODGES: The three key decisions that stopped the riots revealed - but now Labour's 'frozen' on small boats
 - [https://www.dailymail.co.uk/debate/article-13730585/DAN-HODGES-three-key-decisions-stopped-riots-revealed-Labours-frozen-small-boats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13730585/DAN-HODGES-three-key-decisions-stopped-riots-revealed-Labours-frozen-small-boats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:52:52+00:00

The riots that scarred the country in the wake of the appalling Southport killings have been billed as the first major test for Sir Keir Starmer and his new administration. And they've passed.

## PETER HITCHENS: The riots ending is proof hard-line policing works. So why do the elites despise it?
 - [https://www.dailymail.co.uk/debate/article-13730839/PETER-HITCHENS-riots-ending-proof-hard-line-policing-works-elites-despise-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13730839/PETER-HITCHENS-riots-ending-proof-hard-line-policing-works-elites-despise-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:43:39+00:00

The great discovery of the past few days has been this: If police are visible, if wrongdoers are swiftly arrested, rapidly charged, prosecuted and quickly and frighteningly punished,  you get a grip on crime.

## Crush horror at Boardmasters: Footage shows crowd surge leaving concertgoers screaming in pain
 - [https://www.dailymail.co.uk/news/article-13730855/boardmasters-festival-crush-crowd-injured-footage-newquay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730855/boardmasters-festival-crush-crowd-injured-footage-newquay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:42:09+00:00

Multiple attendees have told MailOnline they believed people had been spiked, though this was denied by a spokesperson for the festival.

## Ben Affleck 'hasn't had the easiest summer' amid Jennifer Lopez marital woes but is 'working nonstop' as he 'thrives when he's busy'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13730785/Ben-Affleck-Jennifer-Lopez-marital-woes-working-busy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13730785/Ben-Affleck-Jennifer-Lopez-marital-woes-working-busy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:32:24+00:00

Amid claims JLo is 'humiliated' by the implosion of their marriage, Ben has been repeatedly spotted emerging from his office. A source said he 'thrives when he's busy.'

## Heartwarming moment major spat between Brazilian and Canadian beach volleyball players at the Olympics is defused as DJ plays John Lennon's 'Imagine', sparking mass sing-a-long
 - [https://www.dailymail.co.uk/sport/olympics/article-13730283/Beach-volleyball-Olympics-Brazil-Canada-DJ-John-Lennon-Imagineheated-row-Brazil-Canada-beach-volleyball-players-Olympics-defused-DJ-plays-John-Lennons-Imagine-sparking-mass-singalong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13730283/Beach-volleyball-Olympics-Brazil-Canada-DJ-John-Lennon-Imagineheated-row-Brazil-Canada-beach-volleyball-players-Olympics-defused-DJ-plays-John-Lennons-Imagine-sparking-mass-singalong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:13:32+00:00

During the third set of a back-and-forth contest on the sand at the Eiffel Tower Stadium, three players became embroiled in a shouting match.

## Man United star Rasmus Hojlund undergoes £1,400 laser acne treatment after his skin 'blew up'
 - [https://www.dailymail.co.uk/sport/olympics/article-13730233/Man-United-Rasmus-Hojlund-acne-treatment-Community-Shield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13730233/Man-United-Rasmus-Hojlund-acne-treatment-Community-Shield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:13:09+00:00

The United striker was filmed having facial laser treatment with KLNIK in Harvey Nichols Manchester.

## Incredible tale of how Nazi ace risked execution to save an American bomber pilot's life - before their secret encounter took another amazing twist
 - [https://www.dailymail.co.uk/news/article-13703123/nazi-saved-american-bomber-world-war-two.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13703123/nazi-saved-american-bomber-world-war-two.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:10:49+00:00

In 1943, Nazi pilot Franz Stigler had the chance to shoot down a defenseless American bomber Charlie Brown but instead helped save his life. Fifty years on their secret encounter took an astonishing twist.

## How self-styled Blake Lively pulled off a two week fashion extravaganza with her enviable wardrobe to promote new film with floral inspired 'method dressing', braless looks and vintage throwbacks
 - [https://www.dailymail.co.uk/tvshowbiz/article-13722913/How-self-styled-Blake-Lively-pulled-two-week-fashion-extravaganza-enviable-wardrobe-promote-new-film-floral-inspired-method-dressing-braless-looks-vintage-throwbacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13722913/How-self-styled-Blake-Lively-pulled-two-week-fashion-extravaganza-enviable-wardrobe-promote-new-film-floral-inspired-method-dressing-braless-looks-vintage-throwbacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:07:33+00:00

Inspired by her character, Blake, 36, has opted for  floral looks including a Oscar de la Renta mini, a Vivienne Westwood dress and a Dauphinette showstopper.

## Revealed: The heroic British cancan dancers who risked horrific injuries as they braved torrential rain to dazzle at the Paris Olympics' opening ceremony
 - [https://www.dailymail.co.uk/news/article-13730261/The-heroic-British-cancan-dancers-risked-horrific-injuries-braved-torrential-rain-dazzle-Paris-Olympics-opening-ceremony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730261/The-heroic-British-cancan-dancers-risked-horrific-injuries-braved-torrential-rain-dazzle-Paris-Olympics-opening-ceremony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:05:59+00:00

Among the troupe were nine British dancers who tread the boards of the iconic club every night, performing their elaborate cabaret show to an international audience

## Step aside, Olympics... it's time for the wife-carrying championships! Hungarian husbands lug their spouses through muddy puddles in bizarre challenge dating back more than 1,000 years
 - [https://www.dailymail.co.uk/news/article-13730741/olympics-wife-carrying-championships-hungary-husbands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730741/olympics-wife-carrying-championships-hungary-husbands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:05:52+00:00

A group of men scrambled through rugged terrain and muddy puddles whilst they lugged their partners on their backs, in an attempt to be the first to cross the finish line

## Ex Olympian Zara Tindall impresses on her beloved horse Classicals Euro Star at the NAF Magic International Horse Trials
 - [https://www.dailymail.co.uk/femail/article-13730815/Ex-Olympian-Zara-Tindall-NAF-Magic-International-Horse-Trials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13730815/Ex-Olympian-Zara-Tindall-NAF-Magic-International-Horse-Trials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T16:05:05+00:00

The 43-year-old, who scooped an Olympic medal at London 2012, was competing at the NAF Magic International Horse Trials this weekend.

## Concertgoers left 'crying in agony' with broken bones after crush at Boardmasters festival
 - [https://www.dailymail.co.uk/news/article-13730143/concertgoers-injured-crowd-surge-boardmasters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730143/concertgoers-injured-crowd-surge-boardmasters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T15:58:23+00:00

During DJ and producer Sammy Virji's performance on The Point stage, two 'massive' crowd surges were reported, forcing his performance to be cancelled.

## Woman, 42, screamed racial abuse at a doctor when he got her a cup of tea because he felt sorry for her when he saw her sitting in the rain
 - [https://www.dailymail.co.uk/news/article-13730905/Woman-42-screamed-racial-abuse-doctor-got-cup-tea-felt-sorry-saw-sitting-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730905/Woman-42-screamed-racial-abuse-doctor-got-cup-tea-felt-sorry-saw-sitting-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T15:56:14+00:00

Chantelle Smith, 42, shouted racist slurs at the man as he walked past her on his way home in Darlington town centre on Thursday evening.

## Covering up antique urinal used by Winston Churchill in the Chancellor's private bathroom would cost £8,000, Rachel Reeves told
 - [https://www.dailymail.co.uk/news/article-13730227/Covering-antique-urinal-used-Winston-Churchill-Chancellors-private-bathroom-cost-8-000-Rachel-Reeves-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730227/Covering-antique-urinal-used-Winston-Churchill-Chancellors-private-bathroom-cost-8-000-Rachel-Reeves-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T15:47:48+00:00

Rachel Reeves has given up on her hopes of removing a urinal used by Winston Churchill from the chancellor's Treasury bathroom after seeing a bill of around £8,000 for the work.

## Travis Scott has been 'released with no charges' after Paris arrest following an argument with his bodyguard
 - [https://www.dailymail.co.uk/tvshowbiz/article-13730823/Travis-Scott-released-no-charges-Paris-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13730823/Travis-Scott-released-no-charges-Paris-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T15:46:21+00:00

Travis Scott was released from police custody in Paris following his arrest at the Four Seasons Hotel George V on Friday.

## Jay Slater's best friend Lucy Mae Law shares emotional tribute to the tragic teenager as she joins hundreds at his funeral
 - [https://www.dailymail.co.uk/news/article-13730779/jay-slater-lucy-mae-emotional-tribute-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730779/jay-slater-lucy-mae-emotional-tribute-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T15:43:20+00:00

While his family and closest friends read heartwarming eulogies and poetry inside, a sea of mourners dressed in blue gathered outside the chapel to watch the funeral on a large screen.

## Former X Factor star Dylan Holloway reveals Rylan's four-word response to him transitioning after singer shared his 'inspiring' story
 - [https://www.dailymail.co.uk/tvshowbiz/article-13730835/X-Factor-Dylan-Holloway-Rylan-four-word-response-transitioning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13730835/X-Factor-Dylan-Holloway-Rylan-four-word-response-transitioning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T15:29:49+00:00

Earlier this week the singer came out as transgender as he shared his inspiring story on social media, 12 years after impressing judges with his vocals on the hit ITV show.

## Royal Navy frigate keeps 'close watch' on two Chinese warships travelling through British waters
 - [https://www.dailymail.co.uk/news/article-13730475/royal-navy-frigate-watch-chinese-warship-british-waters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730475/royal-navy-frigate-watch-chinese-warship-british-waters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T15:26:20+00:00

The presence of Chinese Navy ships in the English Channel is not a common occurrence, but this is not the first time in recent memory that the Royal Navy has had to keep an eye on China's ships

## The plastic surgeries of the Trump family REVEALED - and their monstrous credit card bill for the ops
 - [https://www.dailymail.co.uk/health/article-13664679/hair-transplants-veneers-plastic-surgeries-Trump-family-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13664679/hair-transplants-veneers-plastic-surgeries-Trump-family-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T14:55:43+00:00

The Trumps are famous for their real estate empire, political aspirations and love of gold toilets. They are also well-known for their aesthetic enhancements.

## 'Hitman' is charged over shooting of nine-year-old girl outside Hackney restaurant
 - [https://www.dailymail.co.uk/news/article-13730715/Hitman-charged-shooting-nine-year-old-girl-outside-Hackney-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730715/Hitman-charged-shooting-nine-year-old-girl-outside-Hackney-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T14:05:08+00:00

Javon Reily, 32, of Farnborough, Hampshire, appeared at Westminster Magistrates' Court today charged with four counts of attempted murder.

## Inside brutal murder of 16-year-old girl and one of London's oldest cold cases in living memory: Jacqueline Johns was found naked close to Battersea Power Station... her killer was never found but 50 years on her family believe they KNOW who did it
 - [https://www.dailymail.co.uk/news/article-13709207/Inside-brutal-murder-16-year-old-girl-one-Londons-oldest-cold-cases-living-memory-Jacqueline-Johns-naked-close-Battersea-Power-Station-killer-never-50-years-family-believe-KNOW-did-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13709207/Inside-brutal-murder-16-year-old-girl-one-Londons-oldest-cold-cases-living-memory-Jacqueline-Johns-naked-close-Battersea-Power-Station-killer-never-50-years-family-believe-KNOW-did-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:59:55+00:00

Jacqueline Johns, 16, was found dead in London on October 1, 1973 - and almost 51 years on her murder has never been solved and no suspect found.

## Sven-Goran Eriksson gives an update on his health after his terminal cancer diagnosis - as the former England boss reveals why he 'feels sorry' for Gareth Southgate's successor
 - [https://www.dailymail.co.uk/sport/football/article-13730277/Sven-Goran-Eriksson-provides-update-health-terminal-cancer-diagnosis-England-Gareth-Southgate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13730277/Sven-Goran-Eriksson-provides-update-health-terminal-cancer-diagnosis-England-Gareth-Southgate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:49:43+00:00

Eriksson, 76, revealed in January that he had pancreatic cancer and is approaching the end of his life, with a 'best case' scenario seeing him only have a year left to live.

## A look at the friendly exes who have shirked bitter splits to jet off for family getaways - from Bradley Cooper and Irina Shayk to Gwyneth Paltrow and Chris Martin
 - [https://www.dailymail.co.uk/tvshowbiz/article-13723169/Divorce-vacation-exes-family-getaway-Bradley-Cooper-Irina-Shayk-Gwyneth-Paltrow-Chris-Martin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13723169/Divorce-vacation-exes-family-getaway-Bradley-Cooper-Irina-Shayk-Gwyneth-Paltrow-Chris-Martin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:33:55+00:00

Proving that not all celebrity splits need to be filled with drama, stars including Bradley Cooper and Gwyneth Paltrow have enjoyed so-called 'divor-cations' with their former spouses.

## After Ben Affleck's daughter urges everyone to wear a mask, the teens who say they NEVER stop wearing one
 - [https://www.dailymail.co.uk/health/article-13730263/Ben-Afflecks-daughter-urges-wear-mask-teens-say-NEVER-stop-wearing-one.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13730263/Ben-Afflecks-daughter-urges-wear-mask-teens-say-NEVER-stop-wearing-one.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:32:16+00:00

Kitty has worn a mask pretty much every time she's left the house since the start of the pandemic in 2020 and doesn't plan on taking it off anytime soon, despite feeling it alienates her from her peers.

## I landed my dream job after winning Bargain Hunt but filming the show was pure chaos - we got drunk and were evacuated from our hotel in the middle of the night
 - [https://www.dailymail.co.uk/tvshowbiz/article-13722463/bargain-hunt-dream-job-winning-chaos-drunk-evacuated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13722463/bargain-hunt-dream-job-winning-chaos-drunk-evacuated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:29:45+00:00

I landed by dream job after winning Bargain Hunt but filming the show was pure chaos - we got drunk and were evacuated from our hotel in the middle of the night.

## Sleep expert explains the reason why you should never sleep naked during a heatwave
 - [https://www.dailymail.co.uk/femail/article-13699235/Sleep-expert-explains-reason-never-sleep-naked-heatwave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13699235/Sleep-expert-explains-reason-never-sleep-naked-heatwave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:27:34+00:00

Speaking to Women's Health, sleep expert, Sophie Bostock, said sleeping naked can prevent individuals from getting the best quality of sleep possible in a heatwave.

## Gardening goes glamorous! Gen Z help horticulture shake off its stuffy image thanks to stylish influencers (and even a royal!) sharing their love for Insta-friendly gardens
 - [https://www.dailymail.co.uk/femail/gardening/article-13692975/influencers-tiktok-gardening-garden-girl-trend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/gardening/article-13692975/influencers-tiktok-gardening-garden-girl-trend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:25:18+00:00

There's been a boom in gardening influencers across the UK, with more and more youngsters sharing their inventive advice, from how to use edible flowers to building your own allotment.

## I'm an American in London... your fish and chips is nice but misses a key ingredient
 - [https://www.dailymail.co.uk/femail/article-13728027/american-london-fish-chips-ingredient.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13728027/american-london-fish-chips-ingredient.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:21:59+00:00

An American woman visiting London raved about her fish and chips but she believes a very key element is missing from the quintessentially British dish.

## Sun, sea and stitch-up! From fake 'rooms with a view' to hotels that didn't exist and a 4ft-high bathroom, the hilarious ways Brits have been duped by crafty travel agents
 - [https://www.dailymail.co.uk/news/article-13713401/Holiday-hell-nightmare-beach-poster-no-hotel-flooding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13713401/Holiday-hell-nightmare-beach-poster-no-hotel-flooding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:21:08+00:00

From rat-infested resorts and accommodation that does not exist to flooded hotels and toilets smeared with excrement, holidaymakers have described their worst trips

## 'She's just mud throwing!' Neighbours hit back after pensioner, 83, claims they made her life 'hell' in £25k war over 90cm strip of land at the back of her garden
 - [https://www.dailymail.co.uk/news/article-13727453/Shes-just-mud-throwing-Neighbours-hit-pensioner-83-claims-life-hell-25k-war-90cm-strip-land-garden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13727453/Shes-just-mud-throwing-Neighbours-hit-pensioner-83-claims-life-hell-25k-war-90cm-strip-land-garden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:16:44+00:00

EXCLUSIVE: Nora Boyle, 83, says her family has owned the tiny patch of land since the 1930s but neighbours disagree and a war has broken out in suburban Nottinghamshire.

## Chaos at Jeremy Clarkson's new Cotswolds pub as noisy neighbour interrupts filming of new series and locals say star may have made a crucial blunder when buying £1m boozer
 - [https://www.dailymail.co.uk/news/article-13726985/Jeremy-Clarkson-Cotswolds-pub-neighbour-filming-new-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13726985/Jeremy-Clarkson-Cotswolds-pub-neighbour-filming-new-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:14:47+00:00

Cameras keep having to stop rolling at The Windmill pub as some of the world's biggest military transporters fly directly over on training exercises from Brize Norton, Britain's biggest RAF base.

## Laura Muir's little-known career before she accidently stumbled into running career after taking it up as a hobby as she eyes gold in the 1500m final
 - [https://www.dailymail.co.uk/sport/olympics/article-13717773/Laura-Muirs-little-known-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13717773/Laura-Muirs-little-known-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:12:38+00:00

Laura Muir breezed through her 1500m semi-final on Thursday evening to book her place in the women's final on Saturday night.

## Reigning in the rain! The times the Royal Family have been caught in a downpour during engagements
 - [https://www.dailymail.co.uk/news/royals/article-13652171/Royal-Family-rain-King-Charles-Kate-Middleton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/royals/article-13652171/Royal-Family-rain-King-Charles-Kate-Middleton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:09:12+00:00

No matter how heavy the downpour, the Royal Family rarely miss an engagement due to poor weather. King Charles and Queen Camilla proved this last month in Jersey.

## Robbie Williams unveils his new teeth as he admits he 'absolutely abused' his old ones for years with cocaine as well as using them to open bottles
 - [https://www.dailymail.co.uk/tvshowbiz/article-13729589/Robbie-Williams-unveils-new-teeth-abused-old-ones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13729589/Robbie-Williams-unveils-new-teeth-abused-old-ones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:08:03+00:00

The 50-year-old singer took to his main Instagram grid on Friday to unveil his new gnashers, following a trip to the dentist.

## I'm a property expert... here is what to do if you find Japanese Knotweed when buying your home
 - [https://www.dailymail.co.uk/news/article-13727953/Im-property-expert-Japanese-Knotweed-buying-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13727953/Im-property-expert-Japanese-Knotweed-buying-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:05:18+00:00

Surveyor Andrew Kempston-Parkes urged buyers to make sure they do one thing if they do spot the invasive plant when they are looking around a potential dream home.

## Evil dogsitter made THREE sick boasts in warped TikTok videos just minutes after stabbing veteran 27 times and strangling him with handbag
 - [https://www.dailymail.co.uk/news/article-13723155/dogsitter-boasts-TikTok-stabbing-veteran-strangling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13723155/dogsitter-boasts-TikTok-stabbing-veteran-strangling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:03:15+00:00

Winter Swan-Miller recorded a video of herself saying she had to take a break from the platform for being 'bad', while the dead body of Stuart Maxwell Crocker lay behind her.

## Inside the 'slave' jail run by millionaire travellers: Shocking pictures reveal horrifying life of captive who was forced to sleep in faeces-soaked duvets and survived on left-over scraps
 - [https://www.dailymail.co.uk/news/article-13714051/inside-slave-jail-run-millionaire-travellers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13714051/inside-slave-jail-run-millionaire-travellers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T13:02:52+00:00

The Rooneys kept 18 homeless men slaves at Drinsey Nook in Lincolnshire to make more than £1.5million to fund a lavish lifestyle jetting off on holidays to Mexico and Barbados.

## Parents of Bebe King, six, who was stabbed to death at Taylor Swift dance class in Southport pay tribute to their 'shimmering star' - and reveal how her nine-year-old sister managed to escape after witnessing 'unimaginable act of violence'
 - [https://www.dailymail.co.uk/news/article-13730501/parents-bebe-king-stabbed-death-southport-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730501/parents-bebe-king-stabbed-death-southport-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:56:19+00:00

The family thanked the community for their 'outpouring of love and support' in an 'unimaginably difficult time' in a statement shared today

## Paris Olympics: Australian breakdancer Raygun hits back with tough message to her trolls and blasts IOC for scrapping the sport in 2028
 - [https://www.dailymail.co.uk/sport/olympics/article-13729731/Paris-Olympics-Australian-breakdancer-Raygun-hits-tough-message-trolls-blasts-IOC-scrapping-sport-2028.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13729731/Paris-Olympics-Australian-breakdancer-Raygun-hits-tough-message-trolls-blasts-IOC-scrapping-sport-2028.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:54:24+00:00

Rachael 'Raygun' Gunn sent the internet into hysterics with her debut Olympic Games performance overnight that failed to reap a single point in three rounds of heats.

## BBC presenter Gabby Logan leaves viewers shocked after using expletive phrase to describe Team USA's botched 4x100m final
 - [https://www.dailymail.co.uk/sport/olympics/article-13730141/BBC-presenter-Gabby-Logan-leaves-viewers-shocked-using-expletive-phrase-Team-USAs-botched-4x100m-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13730141/BBC-presenter-Gabby-Logan-leaves-viewers-shocked-using-expletive-phrase-Team-USAs-botched-4x100m-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:50:10+00:00

The US were a red-hot favourite to take home the gold but a bungled baton handover saw the team rapidly drop down the order before eventually being disqualified.

## Jay Slater's family turn out for funeral as pals wear blue in tribute to 'forever 19' beloved son who died in Tenerife
 - [https://www.dailymail.co.uk/news/article-13730031/mourners-funeral-jay-slater-death-tenerife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730031/mourners-funeral-jay-slater-death-tenerife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:48:16+00:00

Pictured for his final farewell at Accrington Cemetery Chapel Jay has been laid to rest in a bright blue coffin, with his name embossed on the side.

## The ultimate Olympic accessory? Keely Hodgkinson, KJ-T and Sydney McLaughlin-Levrone spark Paris 2024 trend for wearing tiaras after winning a medal
 - [https://www.dailymail.co.uk/femail/article-13730405/Has-tiara-ultimate-Olympic-accessory-Keely-Hodgkinson-KJ-T-Sydney-McLaughlin-Levrone-sparked-Paris-2024-trend-regal-headwear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13730405/Has-tiara-ultimate-Olympic-accessory-Keely-Hodgkinson-KJ-T-Sydney-McLaughlin-Levrone-sparked-Paris-2024-trend-regal-headwear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:43:33+00:00

Got a medal? You'll need a tiara to go with it. Female competitors winning a place on the podium in Paris have been celebrating their success with crowns and tiaras.

## 'Why do you hate me,' Mum asked. LOUISE THOMPSON reveals what caused rift with her parents… and the four steps that healed their relationship
 - [https://www.dailymail.co.uk/home/you/article-13714117/Why-hate-Mum-asked-LOUISE-THOMPSON-reveals-caused-rift-parents-four-steps-healed-relationship.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13714117/Why-hate-Mum-asked-LOUISE-THOMPSON-reveals-caused-rift-parents-four-steps-healed-relationship.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:34:58+00:00

The last person I wanted to fall out with was my mother. But from this challenge came some good: The two of us had a conversation we should have been having all our lives...

## Fantastic Four 2005 cast: Where are they now? Following Chris Evans' surprise cameo as Johnny Storm in Deadpool and Wolverine
 - [https://www.dailymail.co.uk/tvshowbiz/article-13684933/fantastic-four-2005-cast-chris-evans-johnny-storm-deadpool-wolverine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13684933/fantastic-four-2005-cast-chris-evans-johnny-storm-deadpool-wolverine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:21:20+00:00

The blockbuster adaptation starred the likes of Jessica Alba, Ioan Gruffudd and Kerry Washington, all of which went on to enjoy success in their acting careers.

## Inside the little-known mountain town dubbed 'the Switzerland of America' praised as being less 'stuck-up' than other popular resorts
 - [https://www.dailymail.co.uk/travel/article-13725629/ouray-colorado-mountain-town-switzerland-america-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13725629/ouray-colorado-mountain-town-switzerland-america-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:17:22+00:00

Say goodbye to influencer-packed Aspen and hello to the quaint town that has been dubbed as 'the Switzerland of America' thanks to its stunning views and humble community.

## Woman's tiny $530-a-month apartment in Paris leaves people stunned: 'She lives in a closet'
 - [https://www.dailymail.co.uk/femail/article-13724213/paris-student-tiny-apartment-leaves-people-stunned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13724213/paris-student-tiny-apartment-leaves-people-stunned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:12:39+00:00

Natalia Vega moved from Peru to the City of Lights in December 2021 and has since been posting about her fun-filled life as a student in France on her Instagram account, where she has many fans.

## Four-bed Tudor mansion boasting stunning lake views hits the market for £3.8m
 - [https://www.dailymail.co.uk/property/article-13730407/Four-bed-Tudor-mansion-lake-views-hits-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/property/article-13730407/Four-bed-Tudor-mansion-lake-views-hits-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:12:18+00:00

A Grade II listed Tudor mansion nestled in the Warwickshire countryside which comes with the ultimate work from home office and lake views is up for grabs for £3.8million.

## Bizarre moment leader of women's 10,000m final Rahel Daniel 'wanders off' midway through race in Paris - before being blocked from exiting stadium by Olympic officials
 - [https://www.dailymail.co.uk/sport/olympics/article-13729023/Bizarre-leader-women-Rahel-Daniel-Paris-Olympics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13729023/Bizarre-leader-women-Rahel-Daniel-Paris-Olympics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T12:01:06+00:00

The Eritrean runner was ahead of the field in the long-distance event under the lights at the Stade de France when she inexplicably decided to stroll of the track, leaving rivals free to overtake her.

## World's greatest marathon runner Eliud Kipchoge takes a TAXI to the finish line in Paris after he was forced to walk and then quit the race
 - [https://www.dailymail.co.uk/sport/football/article-13730327/Marathon-Eliud-Kipchoge-TAXI-Paris-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13730327/Marathon-Eliud-Kipchoge-TAXI-Paris-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:59:41+00:00

He handed his shoes and socks to fans lining the road as the crowd cheered and clapped before disappearing into an Olympic van, perhaps the last glimpse of a legend at the Games.

## How Lila Moss, 21, is cementing her place in the public eye thanks to her supermodel mother's looks (and her wardrobe)
 - [https://www.dailymail.co.uk/femail/article-13727933/How-Lila-Moss-21-cementing-place-public-eye-thanks-supermodel-mothers-looks-wardrobe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13727933/How-Lila-Moss-21-cementing-place-public-eye-thanks-supermodel-mothers-looks-wardrobe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:57:57+00:00

It's not just good looks that Lila, who also boasts a successful modelling career, has gained from her mother, she's also taking fashion inspiration from catwalk queen Kate.

## Olympic Breaking athlete disqualified over her 'political' outfit seconds into her routine - as she claims she 'wanted to show people what is possible'
 - [https://www.dailymail.co.uk/sport/olympics/article-13730183/Olympic-Breaking-athlete-disqualified-political-outfit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13730183/Olympic-Breaking-athlete-disqualified-political-outfit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:42:00+00:00

Talash received a roar of approval from the crowd at Urban Park in Paris and later explained why she had made the powerful statement.

## 'Miracle' in US church as Virgin Mary statue is filmed 'blinking' by stunned worshippers
 - [https://www.dailymail.co.uk/news/article-13720309/virgin-mary-statue-miracle-ohio-blinked-lady-fatima.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13720309/virgin-mary-statue-miracle-ohio-blinked-lady-fatima.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:39:58+00:00

The International Pilgrim Virgin Statue of Our Lady of Fatima was making its way across the region as part of a tour when it allegedly shut and open its eyes on August 2.

## Mother of boy, 17, who died on a school trip after getting into difficulty in the sea says she's not been given answers over what happened a month after the tragedy
 - [https://www.dailymail.co.uk/news/article-13730337/Mother-boy-17-died-school-trip-getting-difficulty-sea-says-shes-not-given-answers-happened-month-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730337/Mother-boy-17-died-school-trip-getting-difficulty-sea-says-shes-not-given-answers-happened-month-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:17:34+00:00

Samuel Oluwagbenga was on a trip with 49 of his fellow Uxbridge College pupils to the seaside village of West Wittering in West Sussex at the start of July when he died.

## Elderly woman, 89, left 'panicked' after her pension credit is stopped because the taxman tells her she is DEAD
 - [https://www.dailymail.co.uk/news/article-13729683/Elderly-woman-89-left-panicked-pension-credit-stopped-taxman-tells-DEAD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13729683/Elderly-woman-89-left-panicked-pension-credit-stopped-taxman-tells-DEAD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:14:45+00:00

Pensioner Elizabeth Harris, 89, of Carharrack, near Redruth, Cornwall, was left without her pension payments for three months after she was mistakenly declared 'dead' on a system.

## Scathing NASA report lays bare how Boeing's disastrous Starliner left two astronauts stranded in space
 - [https://www.dailymail.co.uk/sciencetech/article-13728271/nasa-report-boeing-starliner-astronauts-stranded-space.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13728271/nasa-report-boeing-starliner-astronauts-stranded-space.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:13:28+00:00

A damning new report from NASA has laid bare how 'Boeing's ineffective quality management' has stranded two astronauts onboard the International Space Station

## Sir Rod Stewart, 79, is forced to axe TWO more shows amid struggle with second health issue - just days after cancelling historic 200th Las Vegas concert
 - [https://www.dailymail.co.uk/tvshowbiz/rod-stewart/article-13730237/Sir-Rod-Stewart-cancel-shows-ill-health-covid19-historic-Las-Vegas-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/rod-stewart/article-13730237/Sir-Rod-Stewart-cancel-shows-ill-health-covid19-historic-Las-Vegas-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:10:22+00:00

Sir Rod Stewart has been forced to cancel a further two shows after being struck down with another health battle.

## Dutch hockey star receives her Olympics gold medal sporting two black eyes after suffering a sickening injury in semi-final win over Argentina
 - [https://www.dailymail.co.uk/sport/olympics/article-13730289/Netherlands-hockey-star-receives-gold-medal-sporting-two-black-eyes-suffering-sickening-injury-semi-final-win-Argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13730289/Netherlands-hockey-star-receives-gold-medal-sporting-two-black-eyes-suffering-sickening-injury-semi-final-win-Argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:05:43+00:00

During the semi-final win against Argentina on Wednesday, Burg was stood a couple of feet from her opponent when a powerful shot hit her in the face.

## Why do I get itchy lips on sunny days? DR ELLIE has the answer
 - [https://www.dailymail.co.uk/health/article-13730301/Why-itchy-lips-sunny-days-DR-ELLIE-answer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13730301/Why-itchy-lips-sunny-days-DR-ELLIE-answer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:02:02+00:00

For years I've suffered with swollen, itchy lips when I go out in the sun. I've tried putting factor 50 suncream on but it doesn't help. Do you think it could be an allergic reaction?

## THE CHIC LIST: I thought I knew everything about my favourite muse…
 - [https://www.dailymail.co.uk/home/you/article-13714375/THE-CHIC-LIST-thought-knew-favourite-muse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13714375/THE-CHIC-LIST-thought-knew-favourite-muse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:46+00:00

Fashion columnist and influencer Joanne Hegarty

## Por flavour! 8 delicious southern Spanish dishes from chef María José Sevilla
 - [https://www.dailymail.co.uk/home/you/article-13718381/Por-flavour-8-delicious-southern-Spanish-dishes-chef-Mar-Jos-Sevilla.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13718381/Por-flavour-8-delicious-southern-Spanish-dishes-chef-Mar-Jos-Sevilla.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:42+00:00

Chef María José Sevilla's delicious southern Spanish dishes brim with the taste of Andalucía

## TOPLINE FITNESS: How to improve your foot strength for better health
 - [https://www.dailymail.co.uk/home/you/article-13719473/TOPLINE-FITNESS-improve-foot-strength-better-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13719473/TOPLINE-FITNESS-improve-foot-strength-better-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:39+00:00

Stay on your toes: being able to lift your heels off the ground is a sign of good foot health

## Grow it long, go blonde and don't shampoo: How I nailed holiday hair at 64
 - [https://www.dailymail.co.uk/home/you/article-13714995/Grow-long-blonde-dont-shampoo-nailed-holiday-hair-64.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13714995/Grow-long-blonde-dont-shampoo-nailed-holiday-hair-64.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:36+00:00

Beauty renegade Christa D'Souza on how cheap conditioner 
plus benign neglect give her the best beach waves ever

## THE BIG PICTURE: A near-deserted beach at 7am in Positano
 - [https://www.dailymail.co.uk/home/you/article-13718301/THE-BIG-PICTURE-near-deserted-beach-7am-Positano.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13718301/THE-BIG-PICTURE-near-deserted-beach-7am-Positano.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:33+00:00

A sunny, splendid group of photos

## How green is this skirt?
 - [https://www.dailymail.co.uk/home/you/article-13714193/How-green-skirt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13714193/How-green-skirt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:30+00:00

How sustainable is your wardrobe? Jessica Carroll challenges fashion's eco credentials

## JEFF PRESTRIDGE: The winter fuel grab was so nasty... and this battle isn't over
 - [https://www.dailymail.co.uk/money/mailplus/article-13730349/JEFF-PRESTRIDGE-winter-fuel-grab-nasty-battle-isnt-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mailplus/article-13730349/JEFF-PRESTRIDGE-winter-fuel-grab-nasty-battle-isnt-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:27+00:00

Readers are spitting blood over Chancellor Rachel Reeves' decision to end immediately the universal right for pensioners to receive a tax-free annual winter fuel payment worth up to £300.

## THE CANNY COOK: Upside-down beetroot and goat's cheese tarts
 - [https://www.dailymail.co.uk/home/you/article-13718835/THE-CANNY-COOK-Upside-beetroot-goats-cheese-tarts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13718835/THE-CANNY-COOK-Upside-beetroot-goats-cheese-tarts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:27+00:00

These make a brilliant starter - or serve them as part of a sharing table

## From beefy tacos to top tequilas, TOM PARKER BOWLES reviews Taquero, a new hot spot in Nottingham
 - [https://www.dailymail.co.uk/home/you/article-13719121/From-beefy-tacos-tequilas-TOM-PARKER-BOWLES-reviews-Taquero-new-hot-spot-Nottingham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13719121/From-beefy-tacos-tequilas-TOM-PARKER-BOWLES-reviews-Taquero-new-hot-spot-Nottingham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:24+00:00

From beefy tacos to top tequilas, a new hot spot in Nottingham has the Mex factor for Tom

## CHARLOTTE KRISTENSEN's picnic cans
 - [https://www.dailymail.co.uk/home/you/article-13719143/CHARLOTTE-KRISTENSENs-picnic-cans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13719143/CHARLOTTE-KRISTENSENs-picnic-cans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:21+00:00

I'm a fan of the can

## EVERYONE'S TALKING ABOUT: Daniel Craig's style
 - [https://www.dailymail.co.uk/home/you/article-13717967/EVERYONES-TALKING-Daniel-Craigs-style.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13717967/EVERYONES-TALKING-Daniel-Craigs-style.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:14+00:00

So what does the 'real' Daniel Craig look like?

## How to get the 'grandpacore' look: Scarlett Dargan raids her dad's wardrobe and finds a fashion treasure trove
 - [https://www.dailymail.co.uk/home/you/article-13719377/How-grandpacore-look-Scarlett-Dargan-raids-dads-wardrobe-finds-fashion-treasure-trove.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13719377/How-grandpacore-look-Scarlett-Dargan-raids-dads-wardrobe-finds-fashion-treasure-trove.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:11+00:00

Get the 'grandpacore' catwalk look without 
the designer spend. Scarlett Dargan 
finds a fashion treasure trove hiding at home

## HOROSCOPES: Leos, someone needs your love!
 - [https://www.dailymail.co.uk/home/you/article-13722963/HOROSCOPES-Leos-needs-love.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13722963/HOROSCOPES-Leos-needs-love.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:08+00:00

Your stars for this week by Sally Brompton

## MY LIFE IN FOOD: Comedian and actor Omid Djalili
 - [https://www.dailymail.co.uk/home/you/article-13718737/MY-LIFE-FOOD-Comedian-actor-Omid-Djalili.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13718737/MY-LIFE-FOOD-Comedian-actor-Omid-Djalili.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:05+00:00

The comedian and actor, 58, tells Tom Parker Bowles about what he does with profiteroles, his disgrace after eating a chilli and five years of chips with everything

## 'I'm fed up with clothes that do nothing for my 5ft 3in frame': Sue, 62, gets a style makeover
 - [https://www.dailymail.co.uk/home/you/article-13718025/Im-fed-clothes-5ft-3in-frame-Sue-62-gets-style-makeover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13718025/Im-fed-clothes-5ft-3in-frame-Sue-62-gets-style-makeover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:01:02+00:00

YOU stylist Stephanie Sofokleous fixes readers' wardrobe problems

## Happy birthday to the Gruffalo: The bestselling children's book turns 25 this year
 - [https://www.dailymail.co.uk/home/you/article-13719425/Happy-birthday-Gruffalo-bestselling-childrens-book-turns-25-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13719425/Happy-birthday-Gruffalo-bestselling-childrens-book-turns-25-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:00:59+00:00

As the much-loved children's book turns 25, 
JULIA DONALDSON tells Hattie Crisell why performing 
her stories is just as important

## How's that for a stunning arrangement? Five cool ways to wear florals this summer
 - [https://www.dailymail.co.uk/home/you/article-13718251/Hows-stunning-arrangement-Five-cool-ways-wear-florals-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13718251/Hows-stunning-arrangement-Five-cool-ways-wear-florals-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:00:56+00:00

Delicate florals teamed with bold pieces… how's that for a stunning arrangement?

## From stripes to prints, 23 bold buys for your home
 - [https://www.dailymail.co.uk/home/you/article-13723573/From-stripes-prints-23-bold-buys-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13723573/From-stripes-prints-23-bold-buys-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:00:52+00:00

The most joyous new home trend means throwing together colour, pattern and shape 
- in the most artful way, of course. Victoria Gray shows how it's done

## I fell victim to a scary new phone scam: After a late-night ride in an unlicensed cab, Sachin Kureishi discovered his Sim card had been stolen - and with it his life savings
 - [https://www.dailymail.co.uk/home/you/article-13719285/I-fell-victim-scary-new-phone-scam-late-night-ride-unlicensed-cab-Sachin-Kureishi-discovered-Sim-card-stolen-life-savings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13719285/I-fell-victim-scary-new-phone-scam-late-night-ride-unlicensed-cab-Sachin-Kureishi-discovered-Sim-card-stolen-life-savings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:00:49+00:00

The morning after a late-night ride in an unlicensed cab, Sachin Kureishi discovered his Sim card had been stolen - and with it his life savings

## Behind that veneered smile and camp presenter persona, there's another RYLAN CLARK: 'I'm the most masculine person you'll ever meet'
 - [https://www.dailymail.co.uk/home/you/article-13718177/Behind-veneered-smile-camp-presenter-persona-theres-RYLAN-CLARK-Im-masculine-person-youll-meet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/you/article-13718177/Behind-veneered-smile-camp-presenter-persona-theres-RYLAN-CLARK-Im-masculine-person-youll-meet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T11:00:46+00:00

Behind that veneered smile and camp presenter persona, there's another RYLAN CLARK: a beer-drinking football fan and wannabe family man.

## Snared on their doorstep: The varying reactions of rioters as police arrest them at home following violent clashes
 - [https://www.dailymail.co.uk/news/article-13730229/varying-reactions-rioters-police-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730229/varying-reactions-rioters-police-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T10:27:51+00:00

Police have released footage of their interactions with those arrested for taking part in the clashes, with courts now expediting charging to crack down on rioters

## Team GB women's 10,000m finalist Megan Keith, who finished 23rd and was lapped by race leaders, is praised for 'Olympic grit' - after she got the 'loudest cheer of the night'
 - [https://www.dailymail.co.uk/femail/article-13730195/Team-GB-womens-10-000m-finalist-Megan-Keith-finished-23rd-lapped-race-leaders-praised-Olympic-grit-got-loudest-cheer-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13730195/Team-GB-womens-10-000m-finalist-Megan-Keith-finished-23rd-lapped-race-leaders-praised-Olympic-grit-got-loudest-cheer-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T10:26:27+00:00

Inverness Harriers runner Keith, 22, came 23rd and was lapped by the race's winner Kenya's Beatrice Chebet. She admitted the run was the 'hardest of my life'.

## Waitrose shoppers revolt as supermarket's toilet rolls become latest victim of shrinkflation
 - [https://www.dailymail.co.uk/news/article-13730187/Waitrose-shoppers-supermarkets-toilet-rolls-shrinkflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730187/Waitrose-shoppers-supermarkets-toilet-rolls-shrinkflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T10:19:58+00:00

Waitrose, owned by the John Lewis Partnership, cut the price of its own brand toilet roll from £5 for nine rolls to £4, claiming they were passing savings on to their customers.

## Olympic (beauty) routines! How Team GB's stars - including Keely Hodgkinson and Lina Nielsen - got performance ready in Paris, using makeup securing primers, styling gels and 'citrusy smells'
 - [https://www.dailymail.co.uk/femail/article-13718123/Olympic-beauty-routines-Team-GBs-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13718123/Olympic-beauty-routines-Team-GBs-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T10:07:56+00:00

FEMAIL takes a look at seven Team GB athletes who have lifted the lid on the beauty rituals and winner products that help them look as good as they feel while competing in the 2024 Paris Olympics.

## Huw Edwards 'pulled the wool over all our eyes', family friend reveals - as she admits she's struggling to come to terms with the disgraced presenter's double life
 - [https://www.dailymail.co.uk/news/article-13730295/huw-edwards-family-friend-struggling-presenters-double-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730295/huw-edwards-family-friend-struggling-presenters-double-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T09:46:50+00:00

'We knew him well, and yet we didn't,' adds the woman who, like so many others, is now questioning what she and her family really knew about the award-winning journalist.

## Moment thug who threw rocks at a TK Maxx store during riots in Plymouth is arrested - before being jailed for over two years
 - [https://www.dailymail.co.uk/news/article-13730105/Moment-thug-threw-rocks-TK-Maxx-store-riots-Plymouth-arrested-jailed-two-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730105/Moment-thug-threw-rocks-TK-Maxx-store-riots-Plymouth-arrested-jailed-two-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T09:45:07+00:00

Justin Crimp, 49, pleaded guilty to violent disorder and criminal damage to property valued at more than £5,000 after being identified from footage of the unrest on Monday.

## Congratulations! At 83, Calendar Cliff Richard is back to leave Harry Styles and Taylor Swift in his wake with his 47th set of annual poses - including snaps of him in his garden and on a cruise
 - [https://www.dailymail.co.uk/news/article-13729121/Calendar-Cliff-Richard-Harry-Styles-Taylor-Swift.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13729121/Calendar-Cliff-Richard-Harry-Styles-Taylor-Swift.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T09:12:12+00:00

The evergreen pop veteran has been releasing his annual poses since 1979 and regularly outsells the likes of the former One Direction star and Taylor Swift.

## 'I am a woman': Victorious gender scandal boxer Imane Khelif takes aim at her 'bullies and enemies' after claiming Olympic gold with dominant unanimous decision win over China's Yang Liu
 - [https://www.dailymail.co.uk/sport/olympics/article-13728667/Gender-scandal-boxer-Imane-Khelif-Olympic-boxing-GOLD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13728667/Gender-scandal-boxer-Imane-Khelif-Olympic-boxing-GOLD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T09:02:33+00:00

Imane Khelif, the Algerian boxer who has been at the centre of a gender scandal which has dominated the Paris Olympics , has claimed gold in the women's 66kg event after beating China's Yang Liu.

## I was in Tommy Robinson's inner circle... he HATES his own supporters: Woman who worked for EDL founder claims he wanted to get 'as far away as possible' from 'army' of fans and boasted about phone 'popping off' after Westminster terror attack
 - [https://www.dailymail.co.uk/news/article-13718197/tommy-robinson-twitter-messages-claims-hates-supporters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13718197/tommy-robinson-twitter-messages-claims-hates-supporters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:50:32+00:00

EXCLUSIVE: The former English Defence League leader, 41, is 'phone obsessed' with his iPhone 'glued to his hand', Lucy Brown told MailOnline.

## 'I am NOT a monster. I am not abusive.' Strictly star Graziano breaks silence after he was dropped from the show following anonymous complaints - and in world-first interview reveals what really happened...
 - [https://www.dailymail.co.uk/tvshowbiz/article-13728325/monster-abusive-Strictly-star-Graziano-dropped-Strictly-anonymous-complaints-world-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13728325/monster-abusive-Strictly-star-Graziano-dropped-Strictly-anonymous-complaints-world-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:48:21+00:00

Graziano Di Prima is in pieces. So much so that his large, loving family won't let him out of their sight - for fear he will take his own life. He confesses to me he has 'ugly thoughts'.

## BORIS JOHNSON: Time to pack the Factor 50, Keir, check out of Britain - and reflect on the frenzy of utter stupidity Labour's embarked on
 - [https://www.dailymail.co.uk/news/article-13727921/BORIS-JOHNSON-Time-pack-Factor-50-Keir-check-Britain-reflect-frenzy-utter-stupidity-Labours-embarked-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13727921/BORIS-JOHNSON-Time-pack-Factor-50-Keir-check-Britain-reflect-frenzy-utter-stupidity-Labours-embarked-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:31:23+00:00

I don't know where the Starmer family were going last Monday, when the rioters were so uncivilised as to delay their holiday. Possibly, it was somewhere in the European Union

## Children who do chores will be richer, slimmer and happier - as William and Kate say their three kids 'muck in' at home
 - [https://www.dailymail.co.uk/health/article-13715101/Children-chores-richer-slimmer-happier-Kate-Wills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13715101/Children-chores-richer-slimmer-happier-Kate-Wills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:21:24+00:00

A source revealed George, Charlotte and Louis roll up their sleeves and help to lay the table and clear the plates. But mucking in with household jobs could make them smarter and healthier, studies suggest.

## Following the TikTok 'trad wife' trend triggered my mental breakdown at just 27... while pregnant with my third child
 - [https://www.dailymail.co.uk/health/article-13719159/TikTok-trad-wife-trend-mental-breakdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13719159/TikTok-trad-wife-trend-mental-breakdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:20:25+00:00

Brianna Bell, 35, from Ontario Canada, was initially happy to be a stay-at-home mum. But at 27, she felt an overwhelming 'dissatisfaction' with her life and the 'toxic' values she followed.

## The great high society getaway! Socialites and minor royals are jetting off to plush destinations including Sardinia and Mauritius
 - [https://www.dailymail.co.uk/femail/article-13714621/The-great-high-society-getaway-Socialites-minor-royals-jetting-plush-destinations-including-Sardinia-Mauritius.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13714621/The-great-high-society-getaway-Socialites-minor-royals-jetting-plush-destinations-including-Sardinia-Mauritius.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:18:11+00:00

Jetting away to lavish destinations such as Sardinia, Mauritius, Barbados, Italy , Spain , Portugal and France the upper classes have made sure they soak up some vitamin D.

## Team GB star reveals the gruelling reality of being an Olympian including 6,000 calorie a day diet, 9 hour training sessions and frostbite from ice baths
 - [https://www.dailymail.co.uk/femail/article-13714679/Team-GB-star-reveals-gruelling-reality-Olympian-including-6-000-calorie-day-diet-9-hour-training-sessions-frostbite-ice-baths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13714679/Team-GB-star-reveals-gruelling-reality-Olympian-including-6-000-calorie-day-diet-9-hour-training-sessions-frostbite-ice-baths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:17:31+00:00

British Olympic speed skater, Sarah Lindsay, 44, who retired from her sport 14 years ago, looked back on her enthralling career in an interview with OK magazine.

## Netflix fans hooked on drama they 'can't switch off' but warn viewers 'it will p*** you off'
 - [https://www.dailymail.co.uk/news/article-13718319/Netflix-drama-switch-warn-viewers-emmy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13718319/Netflix-drama-switch-warn-viewers-emmy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:17:07+00:00

This 10 part series covers everything from poverty, abusive relationships, family dynamics, while allowing its audience to cling to hope that the protagonist will pull through in the end.

## Two bedroom terrace home is up for grabs for just £10k - but there's a catch that may make you think twice
 - [https://www.dailymail.co.uk/news/article-13710097/terraced-two-bedroom-home-catch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13710097/terraced-two-bedroom-home-catch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:16:35+00:00

A two-bedroom property overgrown with shrubbery is on sale for only £10,000 - but there is more to the deal than meets the eye.

## I'm a Hooters waitress... you can make a fortune in tips but here are the pros and cons of working here
 - [https://www.dailymail.co.uk/femail/article-13709533/Hooters-waitress-fortune-tips-pros-cons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13709533/Hooters-waitress-fortune-tips-pros-cons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:16:00+00:00

A Hooters waitress has revealed that while there are plenty of upsides to the job - such as the astronomical tips - the role still has its disadvantages.

## And you thought Mount Everest was big! Incredible interactive map reveals the tallest mountains in the Solar System - with the peaks on Earth dwarfed in comparison to those on other worlds
 - [https://www.dailymail.co.uk/sciencetech/article-13727243/interactive-map-tallest-mountains-Solar-System.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13727243/interactive-map-tallest-mountains-Solar-System.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:14:22+00:00

This incredible interactive map reveals the tallest mountains in the solar system and shows how these celestial peaks dwarf Earth's highest points.

## Bribe us! Flight attendants from BA, easyJet and more share 10 top travel hacks, from giving gifts to get ahead to why you should pack a Pot Noodle (and why booking seats in row 11 is a no-no)
 - [https://www.dailymail.co.uk/travel/article-13318989/British-Airways-easyjet-flight-attendant-hacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13318989/British-Airways-easyjet-flight-attendant-hacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:14:07+00:00

The travel hacks were revealed by cabin crew in a survey by private travel club Velloy. Which one do YOU think is the most useful?

## Cat owners warned over spate of poisonings by antifreeze which left pets unable to move and having to be put to sleep
 - [https://www.dailymail.co.uk/news/article-13730151/Cat-owners-warned-spate-poisonings-antifreeze-left-pets-unable-having-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13730151/Cat-owners-warned-spate-poisonings-antifreeze-left-pets-unable-having-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T08:12:37+00:00

The RSPCA has warned cat owners about the dangers of antifreeze as Ben McQueen's pet Luna was one of a number of cats to be poisoned in South Wales recently.

## Used EVs are now CHEAPER than petrol and diesel cars, market data shows
 - [https://www.dailymail.co.uk/money/electriccars/article-13724167/Used-EVs-CHEAPER-petrol-diesel-cars-market-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/electriccars/article-13724167/Used-EVs-CHEAPER-petrol-diesel-cars-market-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T07:55:08+00:00

Average retail prices for EVs are 8.5% cheaper than petrol at the three-year mark, rising to almost double that by year four, according to valuations specialists Cap Hpi.

## Is THIS Britain's worst designed home? New build £500k house compared to a 'detention centre' with 'insane' windows as critics ask 'did they run out of glass?'
 - [https://www.dailymail.co.uk/news/article-13727443/britain-worst-designed-home-new-build-detention-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13727443/britain-worst-designed-home-new-build-detention-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T07:52:42+00:00

A luxury new build has been likened to a detention centre as critics flock to social media to point out the property's bizarre lack of windows.

## The handbags favoured by the royals that are available for under £500: From Kate's £225 choice for the Wimbledon final to Princess Beatrice's £475 clutch for Buckingham Palace garden party
 - [https://www.dailymail.co.uk/news/royals/article-13643843/Royal-handbags-500-Kate-Middleton-Princess-Beatrice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/royals/article-13643843/Royal-handbags-500-Kate-Middleton-Princess-Beatrice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T07:29:13+00:00

We delve into handbags under £500 that are favoured by royals including the Princess of Wales, from brands such as LK Bennett, Anya Hindmarch, Strathberry and DeMellier.

## The home I want to buy has cracks on the ceiling and walls: Should I be worried?
 - [https://www.dailymail.co.uk/property/article-13719127/The-home-want-buy-cracks-ceiling-walls-worried.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/property/article-13719127/The-home-want-buy-cracks-ceiling-walls-worried.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T07:22:17+00:00

When it comes to cracks on ceilings and walls, what do I need to be worried about and looking out for? What problems could cracks be hiding?

## I was fined £400 for leaving a cabinet outside my own house for forty minutes by jobsworth council - but I took them on and WON
 - [https://www.dailymail.co.uk/news/article-13727579/fine-cabinet-outside-house-forty-minutes-council.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13727579/fine-cabinet-outside-house-forty-minutes-council.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T07:21:55+00:00

Paul Vale had just left the baby changing unit on the pavement when a council officer turned up and demanded it be moved immediately or a penalty would be issued.

## Love Island star Lucie Donlan puts £475k Cornwall cottage on the market less than 3 years after saying it was her 'dream' home
 - [https://www.dailymail.co.uk/tvshowbiz/article-13714549/Love-Island-Lucie-Donlan-Cornwall-cottage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13714549/Love-Island-Lucie-Donlan-Cornwall-cottage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T07:21:01+00:00

Lucie Donlan , who was part of ITV 's hit dating show back in 2019, renovated the quaint seaside house in Cubert, near Newquay alongside her fiancee Luke Mabbott .

## How much do you love your car? Poll reveals the most satisfying brands to own with 90k drivers having their say
 - [https://www.dailymail.co.uk/money/cars/article-13719009/Mosts-satisfying-car-brands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/cars/article-13719009/Mosts-satisfying-car-brands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T07:12:03+00:00

Here's a countdown of the top 10 most satisfying brands to own - and we'll reveal the full order from 1 to 32 of mainstream brands to see how yours ranks.

## Katie Price WANTS to be jailed so she can cash in on interviews behind bars, claim friends of the reality star - after a judge ordered her to appear in court and not go abroad again
 - [https://www.dailymail.co.uk/news/article-13729739/Katie-Price-jailed-interviews-judge-bankruptcy-court-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13729739/Katie-Price-jailed-interviews-judge-bankruptcy-court-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T01:42:48+00:00

The former glamour model, 46, is supposedly hoping to handed a prison sentence after she was arrested for failing to attend court over her ongoing bankruptcy court proceedings.

## Former Catalan separatist leader Carles Puigdemont 'back in Belgium' after evading arrest in Spain for the second time in seven years with dramatic dash in getaway car
 - [https://www.dailymail.co.uk/news/article-13729611/Catalan-separatist-leader-Carles-Puigdemont-Belgium-evading-arrest-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13729611/Catalan-separatist-leader-Carles-Puigdemont-Belgium-evading-arrest-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T01:33:38+00:00

Puigdemont, 61, made a much-anticipated return to Spain this week despite a pending arrest warrant against him for his role in a 2017 independence referendum deemed illegal by Spanish courts.

## AMANDA PLATELL: Whatever happened to Meghan the feminist?
 - [https://www.dailymail.co.uk/debate/article-13728337/AMANDA-PLATELL-Meghan-Markle-feminist-royal-family-Prince-Harry-American-Riviera-Orchard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13728337/AMANDA-PLATELL-Meghan-Markle-feminist-royal-family-Prince-Harry-American-Riviera-Orchard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T00:58:40+00:00

Having made millions from her narrative about the Royal Family, Meghan is taking the Netflix shilling. She's finished filming a cookery show to complement her jam brand American Riviera Orchard.

## When John died on a railway, police said it was an accident. Now his parents reveal truth about his death - from chilling threats to a mysterious letter - and ask the horrifying question: Has someone got away with murder?
 - [https://www.dailymail.co.uk/news/article-13728347/John-died-railway-police-accident-parents-truth-death-threats-mysterious-letter-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13728347/John-died-railway-police-accident-parents-truth-death-threats-mysterious-letter-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T00:56:03+00:00

No one would ever know John Merrick is buried in Streetly Cemetery in the West Midlands. His grave, in stark contrast to all the others, doesn't have a headstone.

## Lauryn Goodman's sister Chloe is 'not ready to forgive' her after Kyle Walker drama as she weighs in on financial demands her sibling made in family court showdown
 - [https://www.dailymail.co.uk/tvshowbiz/article-13729459/Lauryn-Goodman-sister-Chloe-Kyle-Walker-court-showdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13729459/Lauryn-Goodman-sister-Chloe-Kyle-Walker-court-showdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-08-10T00:09:37+00:00

The fall-out stemmed from Lauryn's decision to go public about her affair with the England and Manchester City footballer.

