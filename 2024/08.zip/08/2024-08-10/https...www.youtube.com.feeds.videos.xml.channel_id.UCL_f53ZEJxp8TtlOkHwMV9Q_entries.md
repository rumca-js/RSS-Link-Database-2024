# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## We've Left Truth Behind
 - [https://www.youtube.com/watch?v=_IZELGnvv6Q](https://www.youtube.com/watch?v=_IZELGnvv6Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-08-10T15:00:36+00:00



