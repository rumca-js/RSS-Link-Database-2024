# Source:Security Affairs, URL:https://securityaffairs.com/feed, language:en-US

## Is the INC ransomware gang behind the attack on McLaren hospitals?
 - [https://securityaffairs.com/166851/cyber-crime/mclaren-hospitals-attack.html](https://securityaffairs.com/166851/cyber-crime/mclaren-hospitals-attack.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-08-10T18:04:23+00:00

A INC Ransom ransomware attack this week disrupted IT and phone systems at McLaren Health Care hospitals. On Tuesday, an INC Ransom ransomware attack hit the McLaren Health Care hospitals and disrupted their IT and phone systems. The organizations did not disclose details about the attack, however Bleeping Computer noticed that employees at McLaren Bay [&#8230;]

## Crooks took control of a cow milking robot causing the death of a cow
 - [https://securityaffairs.com/166839/cyber-crime/cow-milking-robot-hacked.html](https://securityaffairs.com/166839/cyber-crime/cow-milking-robot-hacked.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-08-10T08:19:24+00:00

Crooks took control of a cow milking robot and demanded a ransom from a farmer who refused to pay it, resulting in the death of a cow. An extortion attempt had a tragic outcome, cybercriminals took control of a cow milking robot and demanded a ransom from a farmer, but he did not pay, resulting [&#8230;]

## Sonos smart speakers flaw allowed to eavesdrop on users
 - [https://securityaffairs.com/166823/hacking/sonos-smart-speakers-flaw.html](https://securityaffairs.com/166823/hacking/sonos-smart-speakers-flaw.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-08-10T00:00:55+00:00

NCC Group discovered vulnerabilities in Sonos smart speakers, including a flaw that could have allowed to eavesdrop on users. Researchers from NCC Group have discovered multiple vulnerabilities in Sonos smart speakers, including a flaw, tracked as CVE-2023-50809, that could have allowed eavesdropping on users. The researchers have disclosed the vulnerabilities during the BLACK HAT USA [&#8230;]

