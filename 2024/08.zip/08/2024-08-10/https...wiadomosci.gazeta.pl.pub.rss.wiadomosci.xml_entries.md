# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Koszmarny wypadek na Lubelszczyźnie, auto zmiażdżone. Kobieta nie żyje, 12-latek w ciężkim stanie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31219108,smiertelny-wypadek-na-lubelszczyznie-samochod-wjechal-pod-ciezarowke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31219108,smiertelny-wypadek-na-lubelszczyznie-samochod-wjechal-pod-ciezarowke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T20:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c1/c5/1d/z31219137M,Smiertelny-wypadek-na-Lubelszczyznie--Samochod-wje.jpg" vspace="2" />Kobieta, ktďż˝ra prowadziła samochďż˝d osobowy, zginęła w wypadku na drodze krajowej nr 12 na Lubelszczyźnie. Auto wjechało pod ciężarďż˝wkę i zostało niemal doszczętnie zmiażdżone. Trasa przez kilka godzin była zablokowana.

## Śmierć trzylatki w Siedlcach. Matka dziewczynki w areszcie. Prokuratura ujawnia wstrząsające szczegďż˝ły
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31219050,smierc-trzylatki-w-siedlcach-matka-dziecka-w-areszcie-media.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31219050,smierc-trzylatki-w-siedlcach-matka-dziecka-w-areszcie-media.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T19:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9f/c5/1d/z31219103M,Mazowsze--Smierc-trzylatki-w-Siedlcach--Matka-dzie.jpg" vspace="2" />Prokuratura przekazała najnowsze informacje w sprawie śmierci trzyletniej dziewczynki z Siedlec, w wojewďż˝dztwie mazowieckim. Na początku sierpnia jej ciało znaleziono w mieszkaniu. Emilia była dziewczynką z niepełnosprawnością i wymagała specjalnej pielęgnacji i opieki. Służby zatrzymały matkę dziecka.

## Siedmiomiesięczna Kasia zniknęła 38 lat temu. Zostały tylko ślady na śniegu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31190286,siedmiomiesieczna-kasia-zniknela-ze-szpitala-porywacz-pozostawil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31190286,siedmiomiesieczna-kasia-zniknela-ze-szpitala-porywacz-pozostawil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T17:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8b/be/1d/z31190411M,Ostatnie-znane-zdjecie-Kasi-Matei.jpg" vspace="2" />Kasia Mateja została porwana ze szpitala w Kartuzach jako siedmiomiesięczna dziewczynka. Mimo intensywnych działań służb nigdy nie została jednak odnaleziona. Dziś, już jako 39-letnia kobieta, żyje najprawdopodobniej w innej rodzinie, nie mając świadomości o swojej przeszłości. Sprawa porwania i towarzyszące jej okoliczności pozostają jednymi z najbardziej tajemniczych w historii polskiej kryminalistyki.

## Krytykował w sieci rządzących. Komisja Etyki TVP: Naruszył Zasady etyki. Dziennikarz jest na urlopie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218905,krytykowal-w-sieci-rzadzacych-media-tvp2-zawiesila-reportera.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218905,krytykowal-w-sieci-rzadzacych-media-tvp2-zawiesila-reportera.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T17:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0e/c5/1d/z31218958M,Siedziba-TVP-w-Warszawie-i-publikacja-nt--zawiesze.jpg" vspace="2" />"Presserwis" poinformował, że Bartłomiej Bublewicz, reporter "Panoramy" został zawieszony przez Telewizję Polską po tym, jak komentował w sieci bieżące wydarzenia polityczne. Sam dziennikarz sprawy nie komentuje, stwierdza jedynie, że jest na urlopie.

## Panika wśrďż˝d Rosjan. Zarządzono masową ewakuację. Putin rozpoczął krwawą zemstę za obwďż˝d kurski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218942,panika-wsrod-rosjan-zarzadzono-masowa-ewakuacje-putin-rozpoczal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218942,panika-wsrod-rosjan-zarzadzono-masowa-ewakuacje-putin-rozpoczal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T17:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/30/c5/1d/z31218992M,Ewakuacja-rosyjskiej-ludnosci--zdjecie-ilustracyjn.jpg" vspace="2" />Ponad 76 tysięcy osďż˝b zostało ewakuowanych z obszarďż˝w graniczących z Ukrainą w obwodzie kurskim w Rosji - poinformowało rosyjskie ministerstwo do spraw sytuacji nadzwyczajnych cytowane przez agencję TASS. Trwa tam ofensywa wojsk ukraińskich. Tymczasem reżim Putina zintensyfikował ataki na Ukrainę. Celem Rosjan padły obiekty cywilne.

## "Katastrofa paryska". "Igrzyska utopione w ściekach i odchodach". "Masowe dzieciobďż˝jstwo". To co będzie w niedzielę?!
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31216623,katastrofa-paryska-igrzyska-utopione-w-sciekach-i-odchodach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31216623,katastrofa-paryska-igrzyska-utopione-w-sciekach-i-odchodach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T17:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cb/c1/1d/z31199691M,Ceremonia-otwarcia-Igrzysk-Olimpijskich-w-Paryzu--.jpg" vspace="2" />Nie oglądałem ceremonii otwarcia igrzysk w Paryżu. Postanowiłem ją jednak "zobaczyć" oczami publicystďż˝w prawicy, tj. zrekonstruować, co się tam działo, wyłącznie z ich tekstďż˝w. I powiem wam: jestem przerażony! Naprawdę boję się teraz, co ci Francuzi pokażą na zamknięciu - pisze Grzegorz Wysocki w felietonie dla Gazeta.pl.

## Atak Izraela na szkołę w Strefie Gazy. Dziesiątki ofiar. Turcja grzmi, Borrell przerażony zdjęciami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218698,atak-izraela-na-szkole-w-strefie-gazy-dziesiatki-ofiar-turcja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218698,atak-izraela-na-szkole-w-strefie-gazy-dziesiatki-ofiar-turcja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T16:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e5/c5/1d/z31218917M,Kolejny-atak-Izraela-na-szkole-w-Strefie-Gazy--zdj.jpg" vspace="2" />Izrael przeprowadził kolejny nalot na budynek szkoły w Strefie Gazy. W wyniku ataku zginęło kilkadziesiąt osďż˝b. Dotychczas udało się zidentyfikować 70 ofiar. Turcja uznała działania Izraela za "nową zbrodnię przeciwko ludzkości". "Potrzebujemy natychmiastowego zawieszenia broni" - oświadczył z kolei szef MSZ Wielkiej Brytanii.

## Zaskakujące słowa Jarosława Kaczyńskiego. "Gdybyśmy rządzili, ten pan byłby prezydentem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218675,zaskakujace-slowa-jaroslawa-kaczynskiego-gdybysmy-rzadzili.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218675,zaskakujace-slowa-jaroslawa-kaczynskiego-gdybysmy-rzadzili.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T14:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fc/c5/1d/z31218684M,Jaroslaw-Kaczynski--prezes-PiS.jpg" vspace="2" />Podczas sobotniej konferencji prasowej Jarosław Kaczyński usłyszał pytanie o kandydata Prawa i Sprawiedliwości w przyszłorocznych wyborach prezydenckich. W odpowiedzi szef PiS wskazał na stojącego obok Mariusza Błaszczaka i stwierdził, że jest przekonany, iż gdyby jego formacja była przy władzy, to byłby on prezydentem.

## Kłęby czarnego dymu nad Dąbrową Gďż˝rniczą. Strażacy w akcji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218682,pozar-w-dabrowie-gorniczej-gesty-dym-nad-skladowiskiem-odpadow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218682,pozar-w-dabrowie-gorniczej-gesty-dym-nad-skladowiskiem-odpadow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T14:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/18/c5/1d/z31218712M,Slaskie--Pozar-w-Dabrowie-Gorniczej--Gesty-dym-nad.jpg" vspace="2" />W sobotę po południu w Dąbrowie Gďż˝rniczej wybuchł pożar składowiska odpadďż˝w. Nad miastem pojawiły się kłęby czarnego dymu. Na miejsce wezwano strażakďż˝w z Dąbrowy Gďż˝rniczej i pobliskiego Będzina.

## Kaczyńskiemu puściły nerwy. Zaatakował demonstranta. "Ty putinowska sz***o"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218487,kaczynski-wsciekly-na-miesiecznicy-smolenskiej-zaatakowal-demonstranta-ty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218487,kaczynski-wsciekly-na-miesiecznicy-smolenskiej-zaatakowal-demonstranta-ty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T14:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/c5/1d/z31218679M,Jaroslaw-Kaczynski.jpg" vspace="2" />Jarosław Kaczyński, jak co miesiąc, złożył w sobotę 10 sierpnia kwiaty pod pomnikiem ofiar katastrofy smoleńskiej. Oprďż˝cz prezesa PiS oraz innych przedstawicieli partii opozycyjnej na placu marszałka Jďż˝zefa Piłsudskiego pojawili się także działacze Obywateli RP oraz Komitetu Obrony Demokracji. Pomiędzy politykiem a demonstrantami doszło do słownej utarczki. Prezes PiS użył wulgaryzmďż˝w.

## Pamiętasz kultowe filmy z czasďż˝w PRL-u? Jeśli nie, nie licz na maksa
 - [https://wiadomosci.gazeta.pl/wiadomosci/13,129662,16519,pamietasz-kultowe-filmy-z-czasow-prl-u-w-tym-quizie-pytamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/13,129662,16519,pamietasz-kultowe-filmy-z-czasow-prl-u-w-tym-quizie-pytamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T14:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/0e/1c/z29418727M,Grafika-do-quizu-o-polskich-aktorkach.jpg" vspace="2" />W tym quizie szansę na komplet punktďż˝w mają tylko osoby, ktďż˝re wychowały się w PRL-u i doskonale pamiętają filmy z tamtych lat. Jeśli dacie radę rozpoznać wszystkie aktorki na zdjęciach, maksa macie w kieszeni!

## Pięciolatek potrącony na przejściu dla pieszych. Policja apeluje do kierowcďż˝w i rodzicďż˝w
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218407,pieciolatek-potracony-na-przejsciu-dla-pieszych-policja-apeluje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218407,pieciolatek-potracony-na-przejsciu-dla-pieszych-policja-apeluje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T13:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3a/c5/1d/z31218490M,Pieciolatek-potracony-na-pasach--Policja-opublikow.jpg" vspace="2" />W Piasecznie pięciolatek wjechał na rowerku na przejście dla pieszych i wpadł pod koła nadjeżdżającego samochodu. Chłopiec odniďż˝sł niegroźne obrażenia, a kierowcy odebrane zostało prawo jazdy. Policja opublikowała ku przestrodze nagranie z monitoringu. Ma rďż˝wnież apel do uczestnikďż˝w ruchu drogowego.

## Katastrofa samolotu w Brazylii. Mężczyzna cudem uniknął śmierci. "Uratował mi życie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218394,tragiczny-lot-pasazerskiego-samolotu-w-brazylii-mezczyzna-cudem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218394,tragiczny-lot-pasazerskiego-samolotu-w-brazylii-mezczyzna-cudem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T13:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/32/c5/1d/z31218482M,Katastrofa-pasazerskiego-samolotu-w-Brazylii--zdje.jpg" vspace="2" />W katastrofie pasażerskiego samolotu w Brazylii zginęły 62 osoby. Lokalne media dotarły do jednego z niedoszłych pasażerďż˝w tragicznego lotu, ktďż˝ry wraz z kilkoma innymi osobami nie został wpuszczony na pokład maszyny. - Uratował mi życie - mďż˝wił o jednym z pracownikďż˝w lotniska poruszony mężczyzna.

## Poruszająca wiadomość Donalda Tuska po śmierci posłanki. "Pilnuj nas tam z gďż˝ry"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218363,izabela-mrzyglocka-nie-zyje-donald-tusk-pilnuj-nas-tam-z-gory.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218363,izabela-mrzyglocka-nie-zyje-donald-tusk-pilnuj-nas-tam-z-gory.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T13:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/c3/1d/z31211137M,Premier-Donald-Tusk.jpg" vspace="2" />W sobotę 10 sierpnia poinformowano o śmierci Izabeli Katarzyny Mrzygłockiej, posłanki Koalicji Obywatelskiej z okręgu dolnośląskiego. "Była nietypową rzeczniczką dyscypliny, ciepłą i wyrozumiałą. Pilnuj nas tam z gďż˝ry, Kasiu" - napisał Donald Tusk w mediach społecznościowych.

## Ciąg dalszy sprawy Romanowskiego. Giertych złoży zawiadomienie na sędziego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218415,ciag-dalszy-sprawy-romanowskiego-giertych-zlozy-zawiadomienie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218415,ciag-dalszy-sprawy-romanowskiego-giertych-zlozy-zawiadomienie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T12:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f1/c5/1d/z31218417M,Roman-Giertych.jpg" vspace="2" />Roman Giertych zapowiedział, że zespďż˝ł ds. rozliczenia PiS złoży zawiadomienie o możliwości popełnienia deliktu dyscyplinarnego przez sędziego Przemysława Dziwańskiego. Wcześniej Prokuratura Krajowa wnioskowała o wyłączenie go ze sprawy Marcina Romanowskiego, lecz wniosek nie został uwzględniony.

## Urzędniczki od Funduszu Sprawiedliwości torturowane? Wiceszefowa MS przypomina słowa Ziobry
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218193,urzedniczki-od-funduszu-sprawiedliwosci-torturowane-wiceszefowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31218193,urzedniczki-od-funduszu-sprawiedliwosci-torturowane-wiceszefowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T10:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1f/c5/1d/z31218207M,Zbigniew-Ziobro--byly-szef-resortu-sprawiedliwosci.jpg" vspace="2" />Środowisko PiS oskarża władzę o stosowanie tortur wobec urzędniczek aresztowanych w ramach śledztwa dotyczącego Funduszu Sprawiedliwości. Maria Ejchart, wiceministerka sprawiedliwości, ocenia te zarzuty jako "narrację polityczną" oraz utrzymuje, że sytuacja aresztowanych "została szczegďż˝łowo sprawdzona". Wyjaśnia rďż˝wnież, z czego wynika decyzja o zastosowaniu "specjalnej ochrony".

## Łukaszenka twierdzi, że zestrzelono ukraińskie drony. "Siły powietrzne w stanie gotowości"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218224,lukaszenka-twierdzi-ze-zestrzelono-ukrainskie-drony-sily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218224,lukaszenka-twierdzi-ze-zestrzelono-ukrainskie-drony-sily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T10:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/84/c2/1d/z31204996M,Alaksandr-Lukaszenka--zdjecie-archiwalne-.jpg" vspace="2" />Alaksandr Łukaszenka twierdził, że ukraińskie drony naruszyły przestrzeń powietrzną Białorusi. Zapewnił, że wszystkie maszyny zostały zestrzelone. - Siły powietrzne zostały postawione w stan wysokiej gotowości - dodał, cytowany przez państwową agencję BiełTA.

## Miedwiediew znďż˝w się rozmarzył. Widzi rosyjskie czołgi w Berlinie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218176,miedwiediew-znow-sie-rozmarzyl-widzi-rosyjskie-czolgi-w-berlinie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31218176,miedwiediew-znow-sie-rozmarzyl-widzi-rosyjskie-czolgi-w-berlinie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T10:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/c4/1d/z31212320M,Dmitrij-Miedwiediew.jpg" vspace="2" />Dziennik "Bild" opisał, że niemieckie wozy opancerzone Marder są wykorzystywane w ukraińskiej ofensywie w obwodzie kurskim. Na te doniesienia odpowiedział Dmitrij Miedwiediew, ktďż˝ry zapowiedział, że Rosja "zrobi wszystko", aby jej czołgi dotarły do Berlina.

## Maturzyści odetchną z ulgą? "Wieczny" szef CKE odwołany po 10 latach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31217871,maturzysci-odetchna-z-ulga-wieczny-szef-cke-odwolany-po-10.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31217871,maturzysci-odetchna-z-ulga-wieczny-szef-cke-odwolany-po-10.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T10:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/56/1d/z30762606M,Marcin-Smolik--dyrektor-CKE.jpg" vspace="2" />"Minister Edukacji Barbara Nowacka z dniem 9 sierpnia 2024 r. odwołała ze stanowiska dyrektora Centralnej Komisji Egzaminacyjnej, Marcina Smolika" - czytamy w komunikacie resortu. Wcześniej o odwołanie Smolika apelowali nauczyciele.

## Adam Bodnar podjął decyzję ws. aborcji. Prokuratorzy otrzymali nowe wytyczne
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31217941,adam-bodnar-podjal-decyzje-ws-aborcji-prokuratorzy-otrzymali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31217941,adam-bodnar-podjal-decyzje-ws-aborcji-prokuratorzy-otrzymali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T08:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/c5/1d/z31217952M,Adam-Bodnar--prokurator-generalny.jpg" vspace="2" />Adam Bodnar wydał wytyczne dla prokuratorďż˝w w sprawie postępowań dotyczących aborcji. Wskazuje w nich między innymi na konieczność "zachowania najwyższego poziomu rzetelności i profesjonalizmu" oraz zwraca uwagę na poszanowanie godności kobiety.

## Nie żyje posłanka Koalicji Obywatelskiej. Izabela Mrzygłocka miała 65 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218084,nie-zyje-izabela-mrzyglocka-wiceprzewodniczaca-klubu-ko-miala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31218084,nie-zyje-izabela-mrzyglocka-wiceprzewodniczaca-klubu-ko-miala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T08:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a7/c5/1d/z31218087M,Nie-zyje-Izabela-Katarzyna-Mrzyglocka--byla-poslan.jpg" vspace="2" />Izabela Katarzyna Mrzygłocka, posłanka KO z okręgu dolnośląskiego i wiceprzewodnicząca klubu partii, zmarła po długiej i ciężkiej chorobie w wieku 65 lat.

## Media: Andrzej Duda leci na olimpiadę do Paryża. To będzie wyjątkowe spotkanie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31217947,nieoficjalnie-andrzej-duda-leci-do-paryza-spotka-sie-polska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31217947,nieoficjalnie-andrzej-duda-leci-do-paryza-spotka-sie-polska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T08:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4c/ce/1b/z29156172M,Prezydent-Andrzej-Duda.jpg" vspace="2" />Andrzej Duda jest w drodze do Paryża. Tam weźmie udział w meczu polskiej reprezentacji w siatkďż˝wkę, ktďż˝ra o godzinie 13 powalczy o złoty medal. Pďż˝źniej spotka się z brązową medalistką Natalią Kaczmarek - wynika z nieoficjalnych ustaleń Polskiej Agencji Prasowej.

## Partia Donalda Tuska zdecydowanym liderem sondażu. PiS truchta, ale nie nadąża. Reszta w tyle
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31217851,na-kogo-zaglosowaliby-dzis-polacy-ko-z-najwiekszym-wzrostem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31217851,na-kogo-zaglosowaliby-dzis-polacy-ko-z-najwiekszym-wzrostem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T07:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/c5/1d/z31217875M,Premier-Donald-Tusk--lider-Koalicji-Obywatelskiej.jpg" vspace="2" />Poparcie w Polsce tracą wszystkie ugrupowania polityczne poza dwiema największymi partiami - wynika z ostatniego sondażu Opinia24. Największy wzrost odnotowała wspďż˝łtworząca obecny rząd Koalicja Obywatelska. Straty w wolniejszym tempie odrabia rďż˝wnież jej największy konkurent - Prawo i Sprawiedliwość.

## Ukraina prze do przodu. W Rosji chaos. Kreml podejmuje stanowcze kroki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31217810,ukraina-prze-do-przodu-w-rosji-chaos-kreml-podejmuje-kolejne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,31217810,ukraina-prze-do-przodu-w-rosji-chaos-kreml-podejmuje-kolejne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T06:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c5/c5/1d/z31217861M,Wladimir-Putin.jpg" vspace="2" />Kreml ogłosił stan operacji antyterrorystycznej w trzech obwodach: kurskim, biełgorodzkim i briańskim. Ma to związek z trwającą od kilku dni ukraińską ofensywą na terytorium Rosji. "Reżim kijowski podjął bezprecedensową prďż˝bę destabilizacji sytuacji w wielu regionach naszego kraju" - czytamy w komunikacie Rosyjskiego Narodowego Komitetu Antyterrorystycznego.

## Ktďż˝rą partię pokazuje najczęściej TVP? Zaskakujący lider w Polskim Radiu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31217477,ktora-partie-pokazuje-najczesciej-tvp-zaskakujacy-lider-w-polskim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,31217477,ktora-partie-pokazuje-najczesciej-tvp-zaskakujacy-lider-w-polskim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T05:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cf/15/1d/z30497231M,Oczekiwanie-na-expose-Donalda-Tuska---screen-z-TVP.jpg" vspace="2" />Krajowa Rada Radiofonii i Telewizji przekazała nam dane dotyczące podziału czasu antenowego dla poszczegďż˝lnych partii politycznych w TVP i Polskim Radiu. Pewna rzecz może zaskakiwać.

## Znaleźli "narkotyk zombie" w przesyłce do Polski. Wielka kontrola KAS
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31217593,narkotyk-zombie-dotarl-do-woj-lubuskiego-w-przesylce-funkcjonariusze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,31217593,narkotyk-zombie-dotarl-do-woj-lubuskiego-w-przesylce-funkcjonariusze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ff/9f/1d/z31063295M,Fentanyl---narkotyk-zombie-.jpg" vspace="2" />Funkcjonariusze KAS przeprowadzili obszerne kontrole przesyłek, ktďż˝re wykazały, że wiele z nich zawierało nielegalne substancje. W jednej z nich znalazł się także fentanyl, nazywany "narkotykiem zombie".

## Horoskop dzienny - sobota 10 sierpnia 2024 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,31190859,horoskop-dzienny-sobota-10-sierpnia-2024-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,31190859,horoskop-dzienny-sobota-10-sierpnia-2024-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-08-10T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4f/be/1d/z31190863M,Horoskop-dzienny---sobota-10-sierpnia-2024.jpg" vspace="2" />Dla wielu znakďż˝w zodiaku sobota zapowiada się jako dzień pełen miłości i pozytywnych emocji. Rak i Skorpion powinny jednak mieć się na baczności. Ich spokďż˝j zaburzyć mogą bowiem ciężkie prďż˝by. Co czeka pozostałych?

