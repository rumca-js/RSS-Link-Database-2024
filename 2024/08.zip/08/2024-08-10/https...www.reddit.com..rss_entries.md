# Source:Reddit - Front Page, URL:https://www.reddit.com/.rss, language:en-US

## Przemoc wobec dzieci
 - [https://www.reddit.com/r/Polska/comments/1ep4jo7/przemoc_wobec_dzieci](https://www.reddit.com/r/Polska/comments/1ep4jo7/przemoc_wobec_dzieci)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T21:59:47+00:00

<!-- SC_OFF --><div class="md"><p>Byłam dzisiaj na imprezie rodzinnej i pod koniec mój 4-letni siostrzeniec się zapierał, że nie chce iść spać tylko się dalej bawić. I wtedy jego ojciec zaczął się na niego wydzierać i uderzył go kilka razy w tył głowy - nie mocno, ale było widać, że chciał małego zastraszyć. Wiele osób pewnie teraz pomyśli, że to żadna przemoc, ale każda przemoc fizyczna może mieć destrukcyjny wpływ na psychikę dziecka. Zresztą jeszcze zanim on wziął ślub z moją siostrą mówił, że uważa przemoc fizyczną wobec dziecka za coś normalnego. Czuję, że powinnam coś zrobić, jakoś to ukrócić, bo boję się, że dzieją się gorsze rzeczy za zamkniętymi drzwiami albo że ta przemoc będzie przybierała na sile, kiedy mój siostrzeniec będzie się stawał starszy. Nie wiem, czy próba przemówienia mojemu szwagrowi do rozumu coś da, bo jeszcze zanim się urodziło jego dziecko była kłótnia przy rodzinnym stole dotycząca jego poglądów na bicie dzieci i pomimo argumentów drugiej strony on zdania 

## [Highlight] Stephen Curry legendary run to end any France hope and win USA the gold medal
 - [https://www.reddit.com/r/nba/comments/1ep3mw9/highlight_stephen_curry_legendary_run_to_end_any](https://www.reddit.com/r/nba/comments/1ep3mw9/highlight_stephen_curry_legendary_run_to_end_any)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T21:18:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/nba/comments/1ep3mw9/highlight_stephen_curry_legendary_run_to_end_any/"> <img alt="[Highlight] Stephen Curry legendary run to end any France hope and win USA the gold medal" src="https://external-preview.redd.it/9DuodeBMPwf-Oi_8vrVSr6f8mVhnIW1V631wYOEPhPo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0bf69a21fd32fd99fde001baf0cec2875a3fe744" title="[Highlight] Stephen Curry legendary run to end any France hope and win USA the gold medal" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Meladroitdimage"> /u/Meladroitdimage </a> &#32; to &#32; <a href="https://www.reddit.com/r/nba/"> r/nba </a> <br /> <span><a href="https://streamable.com/kb71dp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/nba/comments/1ep3mw9/highlight_stephen_curry_legendary_run_to_end_any/">[comments]</a></span> </td></tr></table>

## No free Kachina + perma-free bennett
 - [https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1ep2ewj/no_free_kachina_permafree_bennett](https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1ep2ewj/no_free_kachina_permafree_bennett)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T20:21:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1ep2ewj/no_free_kachina_permafree_bennett/"> <img alt="No free Kachina + perma-free bennett" src="https://external-preview.redd.it/CTXsZBYmXu90tVYQboysLQxW2wi86TAerBjSpR9sq_4.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=b20af035229c79d25e84b2af6c6a79924283fd53" title="No free Kachina + perma-free bennett" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ukrisreng"> /u/ukrisreng </a> &#32; to &#32; <a href="https://www.reddit.com/r/Genshin_Impact_Leaks/"> r/Genshin_Impact_Leaks </a> <br /> <span><a href="https://i.imgur.com/dyB8JjK.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1ep2ewj/no_free_kachina_permafree_bennett/">[comments]</a></span> </td></tr></table>

## "Zbieram na wakacje" okazało się napiwkiem... dla szefa
 - [https://www.reddit.com/r/Polska/comments/1ep1x9x/zbieram_na_wakacje_okazało_się_napiwkiem_dla_szefa](https://www.reddit.com/r/Polska/comments/1ep1x9x/zbieram_na_wakacje_okazało_się_napiwkiem_dla_szefa)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T19:59:32+00:00

<!-- SC_OFF --><div class="md"><p>Robię urlopik w pipidówie nad morzem. Jak wszędzie w wakacje pracownikami w budkach z żarełkiem są najczęściej studenci. Na ladach stoją sympatyczne puszeczki, &quot;zbieram na wakacje&quot; &quot;piwko&quot; itp. Jedna puszka wydawała mi się jakoś zbyt fajna. Duża, idealne pismo i z kludeczką. Zapytałem miłą panią, czy dużo im wpada (pracowników było więcej) i czy jak wrzucę, czy to będzie dla całej zmiany. &quot;No wie Pan, to jest puszka szefa&quot;. Bulwers i osłupienie... Pani obok głośno się oburzyła, &quot;jak to dla szefa&quot;? Dziewczyna zza lady trochę zawstydzona tylko wzruszyła ramionami. Finalnie dałem napiwek do ręki i od teraz zawsze się pytam, do czyjej kieszeni ląduje kasa z sympatycznych puszek. Na szczęście był to jak na razie jednorazowy przypadek, ale z drugiej strony niezbyt często daję napiwki w tych budkach, chyba że ktoś mnie pozytywnie zaskoczy. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.c

## Lin Yu-Ting wygrała z Julią Szeremetą w finale boksu na Igrzyskach Olimpijskich
 - [https://www.reddit.com/r/Polska/comments/1ep1qbg/lin_yuting_wygrała_z_julią_szeremetą_w_finale](https://www.reddit.com/r/Polska/comments/1ep1qbg/lin_yuting_wygrała_z_julią_szeremetą_w_finale)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T19:50:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/pantrokator-bezsens"> /u/pantrokator-bezsens </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.sport.pl/igrzyska-olimpijskie/14,154863,31219112.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ep1qbg/lin_yuting_wygrała_z_julią_szeremetą_w_finale/">[comments]</a></span>

## In the upcoming live action reboot of the beloved classic Snow White (2025), Disney decided to create ugly CGI monstrosities instead of cast actual dwarf actors to play the Seven Dwarves
 - [https://www.reddit.com/r/shittymoviedetails/comments/1ep0g5s/in_the_upcoming_live_action_reboot_of_the_beloved](https://www.reddit.com/r/shittymoviedetails/comments/1ep0g5s/in_the_upcoming_live_action_reboot_of_the_beloved)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T18:52:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shittymoviedetails/comments/1ep0g5s/in_the_upcoming_live_action_reboot_of_the_beloved/"> <img alt="In the upcoming live action reboot of the beloved classic Snow White (2025), Disney decided to create ugly CGI monstrosities instead of cast actual dwarf actors to play the Seven Dwarves " src="https://preview.redd.it/0li8r013vvhd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a28d512b76a10f93a483057e236297928b916756" title="In the upcoming live action reboot of the beloved classic Snow White (2025), Disney decided to create ugly CGI monstrosities instead of cast actual dwarf actors to play the Seven Dwarves " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Beginning_Goose_6366"> /u/Beginning_Goose_6366 </a> &#32; to &#32; <a href="https://www.reddit.com/r/shittymoviedetails/"> r/shittymoviedetails </a> <br /> <span><a href="https://i.redd.it/0li8r013vvhd1.png">[link]</a></span> &#32; <span><a href="htt

## Wait until you see his face if he finds out that Banshee is male
 - [https://www.reddit.com/r/Grimdank/comments/1ep087i/wait_until_you_see_his_face_if_he_finds_out_that](https://www.reddit.com/r/Grimdank/comments/1ep087i/wait_until_you_see_his_face_if_he_finds_out_that)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T18:42:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Grimdank/comments/1ep087i/wait_until_you_see_his_face_if_he_finds_out_that/"> <img alt="Wait until you see his face if he finds out that Banshee is male" src="https://preview.redd.it/fayijl1dtvhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3f3c79548a2e4db2a16cc5dec00cdf6cc6a0f331" title="Wait until you see his face if he finds out that Banshee is male" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Stupiditygoesbrrr"> /u/Stupiditygoesbrrr </a> &#32; to &#32; <a href="https://www.reddit.com/r/Grimdank/"> r/Grimdank </a> <br /> <span><a href="https://i.redd.it/fayijl1dtvhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Grimdank/comments/1ep087i/wait_until_you_see_his_face_if_he_finds_out_that/">[comments]</a></span> </td></tr></table>

## My niece has 6 fingers on both hands [OC]
 - [https://www.reddit.com/r/mildlyinteresting/comments/1ep07kr/my_niece_has_6_fingers_on_both_hands_oc](https://www.reddit.com/r/mildlyinteresting/comments/1ep07kr/my_niece_has_6_fingers_on_both_hands_oc)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T18:41:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinteresting/comments/1ep07kr/my_niece_has_6_fingers_on_both_hands_oc/"> <img alt="My niece has 6 fingers on both hands [OC]" src="https://preview.redd.it/xtity9f7tvhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e32a569b2bf875337dd913fa6062d1d4ba83e680" title="My niece has 6 fingers on both hands [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mugheesdogar"> /u/mugheesdogar </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinteresting/"> r/mildlyinteresting </a> <br /> <span><a href="https://i.redd.it/xtity9f7tvhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/mildlyinteresting/comments/1ep07kr/my_niece_has_6_fingers_on_both_hands_oc/">[comments]</a></span> </td></tr></table>

## Bro is not making it home alive
 - [https://www.reddit.com/r/shitposting/comments/1ep06rd/bro_is_not_making_it_home_alive](https://www.reddit.com/r/shitposting/comments/1ep06rd/bro_is_not_making_it_home_alive)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T18:40:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shitposting/comments/1ep06rd/bro_is_not_making_it_home_alive/"> <img alt="Bro is not making it home alive " src="https://external-preview.redd.it/NXRtcmFjeXhzdmhkMRn6mhG6kGgqrbzXSGQ7Q_Fy87mshF3ZWFwkNe_dRt8w.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=5e026f893736e7ac27bdb8f14f134d5f6aca17c8" title="Bro is not making it home alive " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Only-Reels"> /u/Only-Reels </a> &#32; to &#32; <a href="https://www.reddit.com/r/shitposting/"> r/shitposting </a> <br /> <span><a href="https://v.redd.it/q5aahm7ysvhd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/shitposting/comments/1ep06rd/bro_is_not_making_it_home_alive/">[comments]</a></span> </td></tr></table>

## I am going to leave this here.
 - [https://www.reddit.com/r/whenthe/comments/1eozvcm/i_am_going_to_leave_this_here](https://www.reddit.com/r/whenthe/comments/1eozvcm/i_am_going_to_leave_this_here)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T18:27:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1eozvcm/i_am_going_to_leave_this_here/"> <img alt="I am going to leave this here." src="https://preview.redd.it/s43c0efjqvhd1.gif?width=320&amp;crop=smart&amp;s=66bfa2aa286ba514c6807b2c90d16301d5742532" title="I am going to leave this here." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SamolotPolski"> /u/SamolotPolski </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://i.redd.it/s43c0efjqvhd1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1eozvcm/i_am_going_to_leave_this_here/">[comments]</a></span> </td></tr></table>

## Czy Polacy tak mówią?
 - [https://www.reddit.com/r/learnpolish/comments/1eozic9/czy_polacy_tak_mówią](https://www.reddit.com/r/learnpolish/comments/1eozic9/czy_polacy_tak_mówią)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T18:10:58+00:00

<!-- SC_OFF --><div class="md"><p>Język polski nie jest moim językiem ojczystym i więc mam takie pytanie. Czy naprawdę brzmi to dziwne, jeżeli powiem «Szukam klucze» albo «Używam komórkę»? Albo «Pięć kobiet idą» zamiast «Pięć kobiet idzie». Czy Polacy też robią takie błędy? Bo w języku rosyjskim są takie same aspekty, ale nikt nawet nie zwróci uwagi, gdy powiesz nieprawidłowo. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Significant_Leg_5504"> /u/Significant_Leg_5504 </a> &#32; to &#32; <a href="https://www.reddit.com/r/learnpolish/"> r/learnpolish </a> <br /> <span><a href="https://www.reddit.com/r/learnpolish/comments/1eozic9/czy_polacy_tak_mówią/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/learnpolish/comments/1eozic9/czy_polacy_tak_mówią/">[comments]</a></span>

## Możecie spać spokojnie
 - [https://www.reddit.com/r/Polska/comments/1eoz6qu/możecie_spać_spokojnie](https://www.reddit.com/r/Polska/comments/1eoz6qu/możecie_spać_spokojnie)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T17:57:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1eoz6qu/możecie_spać_spokojnie/"> <img alt="Możecie spać spokojnie" src="https://preview.redd.it/5mlemx29lvhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c674e5f12a67e278b7fbe864e4697f590ec32d6a" title="Możecie spać spokojnie" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>PS. Tak, tym pojazdem porusza się naczelny syfiarz zwany też Dobromirem. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Kubolomo"> /u/Kubolomo </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://i.redd.it/5mlemx29lvhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eoz6qu/możecie_spać_spokojnie/">[comments]</a></span> </td></tr></table>

## Why is it hard to socialize (finding friends) in Poland?
 - [https://www.reddit.com/r/Polska/comments/1eoyq9q/why_is_it_hard_to_socialize_finding_friends_in](https://www.reddit.com/r/Polska/comments/1eoyq9q/why_is_it_hard_to_socialize_finding_friends_in)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T17:37:27+00:00

<!-- SC_OFF --><div class="md"><p>I am living almost a year in Warsaw. First 3-4 months It was hard to focus on socializing because of education and other stuff. But last 6-7 months, I am trying to find new friends in Warsaw. I am studying master's degree and working in IT company at the same time.</p> <p>However students in our class mostly groupped with their nationality so probably after education we won't have contact with each other and </p> <p>In work, most of the people in company ( Almost 90%) and all members in our team except me are polish. And everyone speaks in polish ( I am not so good at it, trying to learn slowly but I can understand most of the words). And I am trying to talk with them or spend time, get closer, but they ignore it everytime. </p> <p>Also I am going to gym and no one care about each other or tries to help or communicate. I went to some pubs several times and I can see that communications in pubs or bars are not very strong. People forget each other afte

## Fnatic vs. Team BDS / LEC 2024 Season Finals - Winners' Bracket Round 1 / Post-Match Discussion
 - [https://www.reddit.com/r/leagueoflegends/comments/1eoyh9t/fnatic_vs_team_bds_lec_2024_season_finals_winners](https://www.reddit.com/r/leagueoflegends/comments/1eoyh9t/fnatic_vs_team_bds_lec_2024_season_finals_winners)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T17:26:35+00:00

<!-- SC_OFF --><div class="md"><h3>LEC 2024 SUMMER PLAYOFFS</h3> <p><a href="https://watch.lolesports.com/">Official page</a> | <a href="https://lol.fandom.com/wiki/LEC/2024_Season/Summer_Playoffs">Leaguepedia</a> | <a href="https://liquipedia.net/leagueoflegends/LEC/2024/Summer/Playoffs">Liquipedia</a> | <a href="https://eventvods.com/featured/lol?utm_source=reddit&amp;utm_medium=subreddit&amp;utm_campaign=post_match_threads">Eventvods.com</a> | <a href="http://lol.gamepedia.com/New_To_League/Welcome">New to LoL</a> </p> <hr /> <h3>Team BDS 0-3 Fnatic</h3> <p><strong>BDS</strong> | <a href="https://lol.fandom.com/wiki/Team_BDS">Leaguepedia</a> | <a href="https://liquipedia.net/leagueoflegends/Team_BDS">Liquipedia</a> | <a href="https://www.bdsesport.com/">Website</a> | <a href="https://www.twitter.com/TeamBDS">Twitter</a> | <a href="https://www.facebook.com/BdsEsportsTeam">Facebook</a><br /> <strong>FNC</strong> | <a href="https://lol.fandom.com/wiki/Fnatic">Leaguepedia</a> | <a href

## Massive ecological protests against lithium mining in Serbia right now
 - [https://www.reddit.com/r/europe/comments/1eoy3mf/massive_ecological_protests_against_lithium](https://www.reddit.com/r/europe/comments/1eoy3mf/massive_ecological_protests_against_lithium)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T17:10:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1eoy3mf/massive_ecological_protests_against_lithium/"> <img alt="Massive ecological protests against lithium mining in Serbia right now" src="https://preview.redd.it/8c3u55ntcvhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=521ce5820bdbae0886baec56347b53ce50cb41dc" title="Massive ecological protests against lithium mining in Serbia right now" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Landrayi"> /u/Landrayi </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br /> <span><a href="https://i.redd.it/8c3u55ntcvhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1eoy3mf/massive_ecological_protests_against_lithium/">[comments]</a></span> </td></tr></table>

## true polish man
 - [https://www.reddit.com/r/2visegrad4you/comments/1eoxhzw/true_polish_man](https://www.reddit.com/r/2visegrad4you/comments/1eoxhzw/true_polish_man)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T16:44:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/2visegrad4you/comments/1eoxhzw/true_polish_man/"> <img alt="true polish man" src="https://external-preview.redd.it/MGlubjExdzk4dmhkMUL2m9vQAma1pK_XtU5w5HYqqT9yYa3dUBDWL1jCpQHH.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=6374da7d97ef8415a5369a308e7bf30dfea40898" title="true polish man" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Kalmarsus"> /u/Kalmarsus </a> &#32; to &#32; <a href="https://www.reddit.com/r/2visegrad4you/"> r/2visegrad4you </a> <br /> <span><a href="https://v.redd.it/hrkxrgea8vhd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/2visegrad4you/comments/1eoxhzw/true_polish_man/">[comments]</a></span> </td></tr></table>

## Meirl
 - [https://www.reddit.com/r/meirl/comments/1eowtc6/meirl](https://www.reddit.com/r/meirl/comments/1eowtc6/meirl)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T16:15:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/meirl/comments/1eowtc6/meirl/"> <img alt="Meirl" src="https://preview.redd.it/5bgnhgw33vhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a544a6b52ac5cbc15288876a1b759e2ef4ff0f9e" title="Meirl" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PreyToTheDemons"> /u/PreyToTheDemons </a> &#32; to &#32; <a href="https://www.reddit.com/r/meirl/"> r/meirl </a> <br /> <span><a href="https://i.redd.it/5bgnhgw33vhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/meirl/comments/1eowtc6/meirl/">[comments]</a></span> </td></tr></table>

## Elf friend [OC]
 - [https://www.reddit.com/r/comics/comments/1eovy8k/elf_friend_oc](https://www.reddit.com/r/comics/comments/1eovy8k/elf_friend_oc)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T15:38:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1eovy8k/elf_friend_oc/"> <img alt="Elf friend [OC]" src="https://preview.redd.it/5pcmt8iewuhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=08f37cc9c29fd6a213a93fe9e078ab98bad26598" title="Elf friend [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/merrivius"> /u/merrivius </a> &#32; to &#32; <a href="https://www.reddit.com/r/comics/"> r/comics </a> <br /> <span><a href="https://i.redd.it/5pcmt8iewuhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1eovy8k/elf_friend_oc/">[comments]</a></span> </td></tr></table>

## characteristic of males
 - [https://www.reddit.com/r/Funnymemes/comments/1eovma2/characteristic_of_males](https://www.reddit.com/r/Funnymemes/comments/1eovma2/characteristic_of_males)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T15:23:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/SweetAnnabellla"> /u/SweetAnnabellla </a> &#32; to &#32; <a href="https://www.reddit.com/r/Funnymemes/"> r/Funnymemes </a> <br /> <span><a href="https://i.redd.it/llk2l89rtuhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Funnymemes/comments/1eovma2/characteristic_of_males/">[comments]</a></span>

## Pielgrzymki, na boga dlaczego
 - [https://www.reddit.com/r/Polska/comments/1eov2h6/pielgrzymki_na_boga_dlaczego](https://www.reddit.com/r/Polska/comments/1eov2h6/pielgrzymki_na_boga_dlaczego)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T15:00:26+00:00

<!-- SC_OFF --><div class="md"><p>Spędzam mini wakacje u rodziców na wsi i ostatni tydzień przypomniał mi jak bardzo nie znoszę pielgrzymek. Jazda samochodem 5km/h za pielgrzymką która zajmuje 1.5 pasa i nie myśli się ogarnąć, ludzie odpoczywający siedząc na środku drogi bo ta biegnie przez las więc nieważne że asfalt, na pewno nikt tędy nie przejeżdża, śpiewy przez megafon kiedy przechodzą twoją ulicą o 4 rano(!) i nie pomyślą że ludzie w mijanych domach raczej jeszcze próbują spać, i ilość śmieci jaką po sobie zostawiają.. Mało rzeczy wzbudza we mnie taką agresję jak pielgrzymki latem. Naprawdę marzę żeby to kiedyś odeszło w niepamięć. Czy ktoś tu się łączy ze mną w irytacji czy tylko ja taka niekatolicka i niepolska wolałabym żeby do tej Częstochowy pojechali aubotusem? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Niawka"> /u/Niawka </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://

## Małżonek alkoholik - Jak się rozwieść bez zamieniania miejsca zamieszkania w chlew?
 - [https://www.reddit.com/r/Polska/comments/1eoulqp/małżonek_alkoholik_jak_się_rozwieść_bez](https://www.reddit.com/r/Polska/comments/1eoulqp/małżonek_alkoholik_jak_się_rozwieść_bez)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T14:39:55+00:00

<!-- SC_OFF --><div class="md"><p>Oczywiście napomnę, że rada prawna już jest w trakcie brania pod uwagę, aczkolwiek znam Internety i czasem mogą przynieść dodatkowe informacje. </p> <p>Otóż problem polega na tym, że jest to wspólność majątkowa i wiem, że sprawy sądowe takie jak rozwód, a potem podział majątku potrafi się dłużyć, a w szczególności gdy obie strony nie chcą zakończyć sprawy obustronnie (a to na pewno się nie stanie). Z tym człowiekiem na pewno nie da się mieszkać, szczególnie, że już normalnie po alkoholu ten człowiek bywa agresywny, a zapędzony w kąt przez rozwód nie wiadomo co mu strzeli do łba i raczej nikt z nas nie ma zamiaru ryzykować uszczerbkiem na zdrowiu, wystarczy, że raz trzymał pod poduszką nóż, bo cytując &quot;chcieliśmy go zamordować&quot;. Czy ktoś ma jakieś rady niekoniecznie muszą odnosić się do tytułu, a do sytuacji? Będę wdzięczny.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Maleficent-Bank-621"> /u/Malefic

## Żeński boks
 - [https://www.reddit.com/r/Polska/comments/1eosot8/żeński_boks](https://www.reddit.com/r/Polska/comments/1eosot8/żeński_boks)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T13:10:33+00:00

<!-- SC_OFF --><div class="md"><p>W sumie temat wałkowany już sto milionów razy, ale czemu nie. Ciekawi mnie czemu tyle osób chce koniecznie udowodnić całemu światu, że dzisiejsza przeciwniczka Szeremety jest facetem. Może są tu osoby, które mi wytłumaczą, bo strasznie nie jasne dla mnie to jest. Głównie dlatego, że każde źródło które podaje te rzekome informacje rzetelne nie jest, a informacje z realnych źródeł (wcześniejsze mecze, igrzyska, odwiecznie IOC) nic na takiego nie wskazuje. Nawet oświadczenie IBA na nic takiego nie wskazuje. Jako osoba która interesuje się boksem dość długo i już widziałem mecze tych kobiet, zastanawiam się czemu akurat teraz, a nie w żadnym poprzednim roku i co napędziło tą nagonkę, bo w zeszłym roku jak oglądałem na mś tą dyskwalifikacje to raczej był konsensus że ruscy kombinują, bo wszyscy co boks żeński oglądają wiedzą że większość kobiet tam ma podobną aparycję do tajki i algierki, takie modelki jak Szeremeta to wyjątki. Chce poznać trochę perspekty

## Even with a silver medal we're still ranked number 1 in the world, gotta love our boys 🇵🇱⛰️🦅🏐
 - [https://www.reddit.com/r/poland/comments/1eosalp/even_with_a_silver_medal_were_still_ranked_number](https://www.reddit.com/r/poland/comments/1eosalp/even_with_a_silver_medal_were_still_ranked_number)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T12:51:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/poland/comments/1eosalp/even_with_a_silver_medal_were_still_ranked_number/"> <img alt="Even with a silver medal we're still ranked number 1 in the world, gotta love our boys 🇵🇱⛰️🦅🏐" src="https://preview.redd.it/ampfn16n2uhd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=ef29098c3ceedfe14a9a466fbcbf6fd579e4ebde" title="Even with a silver medal we're still ranked number 1 in the world, gotta love our boys 🇵🇱⛰️🦅🏐" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/One_Perspective_8761"> /u/One_Perspective_8761 </a> &#32; to &#32; <a href="https://www.reddit.com/r/poland/"> r/poland </a> <br /> <span><a href="https://i.redd.it/ampfn16n2uhd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/poland/comments/1eosalp/even_with_a_silver_medal_were_still_ranked_number/">[comments]</a></span> </td></tr></table>

## My powerhouse water is white. How to fix???
 - [https://www.reddit.com/r/tf2/comments/1eorxsn/my_powerhouse_water_is_white_how_to_fix](https://www.reddit.com/r/tf2/comments/1eorxsn/my_powerhouse_water_is_white_how_to_fix)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T12:32:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/tf2/comments/1eorxsn/my_powerhouse_water_is_white_how_to_fix/"> <img alt="My powerhouse water is white. How to fix???" src="https://preview.redd.it/ds08tfv6zthd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1dce8442a999b25244347926f1e694f0fafecb4a" title="My powerhouse water is white. How to fix???" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Htosakos"> /u/Htosakos </a> &#32; to &#32; <a href="https://www.reddit.com/r/tf2/"> r/tf2 </a> <br /> <span><a href="https://i.redd.it/ds08tfv6zthd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/tf2/comments/1eorxsn/my_powerhouse_water_is_white_how_to_fix/">[comments]</a></span> </td></tr></table>

## Mamy srebro!
 - [https://www.reddit.com/r/Polska/comments/1eorvau/mamy_srebro](https://www.reddit.com/r/Polska/comments/1eorvau/mamy_srebro)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T12:29:13+00:00

<!-- SC_OFF --><div class="md"><p>Mamy srebro olimpijskie, szczerze powiem że należało im się. Byliśmy pewnie zbyt rozbici i skontuzjowani po meczu półfinałowym z USA w porównaniu do Francji, która była ŚWIE ŻUT KA jak bułki o 6:00 w lokalnej piekarni. Chłopacy dali z siebie wszystko, więcej nie mieli w silnikach moim zdaniem. Ale nie ma co się ustrzegać głupich błędów, których było dużo za dużo. W każdym razie gratulacje dla chłopaków i jestem jako kibic dumny bo jest z czego 🫡</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Crazy-Revolution9518"> /u/Crazy-Revolution9518 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1eorvau/mamy_srebro/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eorvau/mamy_srebro/">[comments]</a></span>

## Damn ciekawa grafika
 - [https://www.reddit.com/r/Polska/comments/1eopxmo/damn_ciekawa_grafika](https://www.reddit.com/r/Polska/comments/1eopxmo/damn_ciekawa_grafika)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T10:34:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1eopxmo/damn_ciekawa_grafika/"> <img alt="Damn ciekawa grafika" src="https://preview.redd.it/3dckz4a8ethd1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=46e25066119c38b5bb94b128e2aeee0a9237861a" title="Damn ciekawa grafika" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Better_Cry_2231"> /u/Better_Cry_2231 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://i.redd.it/3dckz4a8ethd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eopxmo/damn_ciekawa_grafika/">[comments]</a></span> </td></tr></table>

## Podwyżka wieku emerytalnego to pole minowe. Ale nie da się go ominąć [OPINIA]
 - [https://www.reddit.com/r/Polska/comments/1eoot10/podwyżka_wieku_emerytalnego_to_pole_minowe_ale](https://www.reddit.com/r/Polska/comments/1eoot10/podwyżka_wieku_emerytalnego_to_pole_minowe_ale)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-08-10T09:17:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1eoot10/podwyżka_wieku_emerytalnego_to_pole_minowe_ale/"> <img alt="Podwyżka wieku emerytalnego to pole minowe. Ale nie da się go ominąć [OPINIA]" src="https://external-preview.redd.it/LTRcKqqheiGe4RDjI8UnReG-aYkZPtIVeQUoOVxsSD0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=23f719d4b50524a0a8fcdfd3175b89dbae73bb91" title="Podwyżka wieku emerytalnego to pole minowe. Ale nie da się go ominąć [OPINIA]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/eMDeKaeS"> /u/eMDeKaeS </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.money.pl/emerytury/podwyzka-wieku-emerytalnego-to-pole-minowe-ale-nie-da-sie-go-ominac-opinia-7058277547215488a.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eoot10/podwyżka_wieku_emerytalnego_to_pole_minowe_ale/">[comments]</a></span> </td></tr></table>

