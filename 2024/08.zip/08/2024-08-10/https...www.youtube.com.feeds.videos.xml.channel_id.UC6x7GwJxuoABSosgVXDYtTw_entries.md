# Source:I Like To Make Stuff, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC6x7GwJxuoABSosgVXDYtTw, language:en

## 3D Scanning My Classic FJ40 to Make Modern Upgrades
 - [https://www.youtube.com/watch?v=d3zFok8pJWk](https://www.youtube.com/watch?v=d3zFok8pJWk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6x7GwJxuoABSosgVXDYtTw
 - date published: 2024-08-10T15:00:42+00:00

Save 20% on your system and your first month is free when you sign up for Fast Protect Monitoring. Visit https://SimpliSafe.com/iltms  to customize yours! Try SimpliSafe risk-free. If you don’t love it, return it for a full refund within 60 days.

Learn 3d modeling in Fusion at 10% off!
https://iliketomakestuff.podia.com/fusion-360-for-makers?coupon=CUPHOLDERZ10

Save at least 7% with discount code: REVOPRLTMS
US site: https://revopoint3d.com/MIRACO-ILikeToMakeStuff
Global site: https://global.revopoint3d.com/MIRACO-ILikeToMakeStuff

🛠 Join The Maker Alliance to directly support the channel and access exclusive videos, discounts, and our private Discord community! 
https://themakeralliance.com

Subscribe: http://bit.ly/ILikeToMakestuffSubscribe
Second Channel: http://bit.ly/iltms-2
Check out my Top Videos!: http://bit.ly/ILikeToMakeStuffTopVideos

Get digital plans, cool merch, and in depth articles at 
https://iliketomakestuff.com

TOOLS & SUPPLIES WE USE (affiliate links):
https://k

