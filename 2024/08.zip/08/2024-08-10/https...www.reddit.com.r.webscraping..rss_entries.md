# Source:webscraping, URL:https://www.reddit.com/r/webscraping/.rss, language:en

## SSL Handshake Latency
 - [https://www.reddit.com/r/webscraping/comments/1eoxho1/ssl_handshake_latency](https://www.reddit.com/r/webscraping/comments/1eoxho1/ssl_handshake_latency)
 - RSS feed: https://www.reddit.com/r/webscraping/.rss
 - date published: 2024-08-10T16:44:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/webscraping/comments/1eoxho1/ssl_handshake_latency/"> <img alt="SSL Handshake Latency" src="https://b.thumbs.redditmedia.com/SbhaL0-smCV13J3LerqXfffIH1_QeBYFkJsYiuPvpnY.jpg" title="SSL Handshake Latency" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>hello, as you can see in the picture below, the SSL handshake in the first API call put too much latency to my script to show the result, is there a way to expand the cache, or any other solution?.</p> <p>i tried to put a second script that call the API every 5 sec from the same client to make the communication permanently active, but nothing changes.</p> <p><a href="https://preview.redd.it/js5scqt17vhd1.png?width=1044&amp;format=png&amp;auto=webp&amp;s=e2955c2d9a4a6978b80f97d39fec512b4a2c91d3">https://preview.redd.it/js5scqt17vhd1.png?width=1044&amp;format=png&amp;auto=webp&amp;s=e2955c2d9a4a6978b80f97d39fec512b4a2c91d3</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="

