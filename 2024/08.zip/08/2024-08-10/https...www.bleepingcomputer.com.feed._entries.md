# Source:BleepingComputer, URL:https://www.bleepingcomputer.com/feed/, language:en-US

## Microsoft: Windows 11 22H2 reaches end of support in 60 days
 - [https://www.bleepingcomputer.com/news/microsoft/microsoft-windows-11-22h2-reaches-end-of-support-in-60-days](https://www.bleepingcomputer.com/news/microsoft/microsoft-windows-11-22h2-reaches-end-of-support-in-60-days)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-08-10T15:27:54+00:00

Microsoft has reminded customers that multiple editions of Windows 11 21H2 and 22H2 will reach the end of servicing in 60 days, on October 8, 2024. [...]

## WWH-Club credit card market admins arrested after cash spending spree
 - [https://www.bleepingcomputer.com/news/legal/wwh-club-credit-card-market-admins-arrested-after-cash-spending-spree](https://www.bleepingcomputer.com/news/legal/wwh-club-credit-card-market-admins-arrested-after-cash-spending-spree)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-08-10T14:16:26+00:00

U.S. law enforcement has arrested two suspected admins of the WWH-Club stolen credit card marketplace after they went on a cash spending spree in Florida. [...]

