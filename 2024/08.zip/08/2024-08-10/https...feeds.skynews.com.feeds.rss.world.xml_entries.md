# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Algerian boxer at centre of Olympics gender row files legal complaint over online harassment
 - [https://news.sky.com/story/algerian-boxer-imane-khelif-at-centre-of-olympic-gender-row-files-legal-complaint-over-online-harassment-13195264](https://news.sky.com/story/algerian-boxer-imane-khelif-at-centre-of-olympic-gender-row-files-legal-complaint-over-online-harassment-13195264)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T20:58:00+00:00

The Algerian boxer at the centre of a gender row at the Paris Olympics has filed a legal complaint saying she has been a victim of online harassment.

## World's fastest man happy to carry weight of medals - and a bigger mission
 - [https://news.sky.com/story/paris-olympics-worlds-fastest-man-noah-lyles-happy-to-carry-weight-of-medals-and-a-bigger-mission-13195215](https://news.sky.com/story/paris-olympics-worlds-fastest-man-noah-lyles-happy-to-carry-weight-of-medals-and-a-bigger-mission-13195215)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T20:24:00+00:00

Being weighed down by medals is welcome for Noah Lyles - now free of COVID-19, finally able to celebrate being the world's fastest man while addressing a bigger mission to unite the US.

## Australian professor's breakdancing routine goes viral as she fails to score point at Olympics
 - [https://news.sky.com/story/raygun-australian-professors-breakdancing-routine-goes-viral-as-she-fails-to-score-a-single-point-at-paris-olympics-13194828](https://news.sky.com/story/raygun-australian-professors-breakdancing-routine-goes-viral-as-she-fails-to-score-a-single-point-at-paris-olympics-13194828)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T15:06:00+00:00

Breakdancing has completed a head-spinning journey from its humble roots on the streets of New York to the global stage of the Paris Olympics - as toprocks and power moves were thrown down in the competition for the fist time.

## Team GB doctor and physio help save life of Uzbekistan boxing coach
 - [https://news.sky.com/story/team-gb-doctor-and-physio-help-save-life-of-uzbekistan-boxing-coach-13194723](https://news.sky.com/story/team-gb-doctor-and-physio-help-save-life-of-uzbekistan-boxing-coach-13194723)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T13:53:00+00:00

It is not only Team GB's athletes who are getting their "Olympic moment" at the Paris Games.

## Russia 'uses vacuum bomb capable of vaporising humans' in response to Ukraine's Kursk attack
 - [https://news.sky.com/story/russia-uses-vacuum-bomb-capable-of-vaporising-humans-in-response-to-ukraines-kursk-attack-13194590](https://news.sky.com/story/russia-uses-vacuum-bomb-capable-of-vaporising-humans-in-response-to-ukraines-kursk-attack-13194590)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T11:59:00+00:00

Russia says it has used a thermobaric bomb against Ukrainian forces as it announced a "counter-terrorism" operation to retaliate against Ukraine's shock incursion into Kursk.

## Kim Jong Un visits victims of catastrophic floods - as he rejects offer of outside help
 - [https://news.sky.com/story/kim-jong-un-visits-victims-of-north-korea-floods-and-says-thousands-will-be-brought-to-pyongyang-13194513](https://news.sky.com/story/kim-jong-un-visits-victims-of-north-korea-floods-and-says-thousands-will-be-brought-to-pyongyang-13194513)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T10:19:00+00:00

Kim Jong Un has visited flood-stricken communities in&#160;North Korea where thousands of people have been displaced.&#160;

## Chinese warships travel through UK waters
 - [https://news.sky.com/story/royal-navy-watches-chinese-warships-travelling-through-uk-waters-13194469](https://news.sky.com/story/royal-navy-watches-chinese-warships-travelling-through-uk-waters-13194469)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T08:36:00+00:00

Two Chinese warships have travelled through UK waters closely watched by a British frigate in a rare transit, the Royal Navy has revealed.

## Three theories around why Ukraine carried out audacious, high-risk incursion into Russia
 - [https://news.sky.com/story/three-theories-around-why-ukraine-carried-out-audacious-high-risk-incursion-into-russia-13194425](https://news.sky.com/story/three-theories-around-why-ukraine-carried-out-audacious-high-risk-incursion-into-russia-13194425)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T06:04:00+00:00

The sight of Ukrainian forces raising their flag over Russian territory is a humiliation for Vladimir Putin, but Ukraine's audacious incursion into Russia is a high-risk gamble.

## '80 people killed' in Israeli strike on school-turned-shelter in Gaza City
 - [https://news.sky.com/story/dozens-killed-in-israeli-strike-on-school-turned-shelter-in-gaza-city-palestinian-health-officials-say-13194413](https://news.sky.com/story/dozens-killed-in-israeli-strike-on-school-turned-shelter-in-gaza-city-palestinian-health-officials-say-13194413)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T03:24:00+00:00

The number of people killed in an Israeli strike on a school-turned-shelter in Gaza City has risen to 80, Palestinian health officials have said.

## 'God will take revenge on Israel, US and Britain': Inside building damaged in airstrike that killed Hezbollah military leader
 - [https://news.sky.com/story/god-will-take-revenge-inside-the-beirut-building-damaged-in-airstrike-that-killed-hezbollah-military-leader-13194407](https://news.sky.com/story/god-will-take-revenge-inside-the-beirut-building-damaged-in-airstrike-that-killed-hezbollah-military-leader-13194407)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-08-10T01:09:00+00:00

The rubble is still being cleared in Lebanon's capital Beirut where last week Israel assassinated Hezbollah's top military commander, Fuad Shukr, in an airstrike.

