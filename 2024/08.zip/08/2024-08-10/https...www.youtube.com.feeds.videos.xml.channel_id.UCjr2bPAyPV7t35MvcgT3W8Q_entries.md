# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## You'll Be Replaced And You'll Be Happy
 - [https://www.youtube.com/watch?v=m645VYVE0TU](https://www.youtube.com/watch?v=m645VYVE0TU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2024-08-10T12:44:54+00:00

The big tech is gradually erasing human-to-human interactions from our lives. This is a problem. Support my work: https://www.patreon.com/thehatedone 

This is Evil Corp. We have all these different brands under different logos and different names. But they are all the same. They are all doing the same thing. Setting and following the same trends on and on, squeezing every penny out of each of them into sterile homogenized neatly packaged products.

I know they are the same because I know why they are the same. And I am gonna tell you why they are the same. It’s my “one corporation” theory. And I also have a solution that I disclose at the end of this video. 

But first, I need to show you how much anti-human the corporate tech has become. How it’s not just a one off event and a pattern that has taken a life on its own and it make turns every piece of culture into the most bland fast-food version of the original with no taste, no texture, and no soul.

It’s no coincidence that this is

