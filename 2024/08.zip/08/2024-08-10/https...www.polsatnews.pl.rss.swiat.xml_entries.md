# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Białoruś ostrzega Ukrainę. To odpowiedź na ostatnie wydarzenia
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/bialorus-ostrzega-ukraine-to-odpowiedz-na-ostatnie-wydarzenia](https://www.polsatnews.pl/wiadomosc/2024-08-10/bialorus-ostrzega-ukraine-to-odpowiedz-na-ostatnie-wydarzenia)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T20:09:00+00:00

Białoruskie MSZ wezwało charge daffaires Ukrainy i przestrzegło Kijów przed naruszaniem przestrzeni powietrznej kraju. Wcześniej Alaksandr Łukaszenka oświadczył, że siły obrony powietrznej zniszczyły kilka obiektów wystrzelonych z Ukrainy.

## Julia Szeremeta ze srebrnym medalem. Polka walczyła do końca
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/julia-szeremeta-ze-srebrnym-medalem-polka-walczyla-do-konca](https://www.polsatnews.pl/wiadomosc/2024-08-10/julia-szeremeta-ze-srebrnym-medalem-polka-walczyla-do-konca)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T19:45:00+00:00

Julia Szeremeta zdobyła srebrny medal igrzysk olimpijskich w boksie. Niespełna 21-letnia zawodniczka przegrała w finale Yu Tin Ling z Tajwanu. Decyzja sędziów była jednogłośna.

## Polski siatkarz w "drużynie marzeń" igrzysk olimpijskich. Ogromne wyróżnienie
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/polski-siatkarz-w-druzynie-marzen-igrzysk-ogromne-wyroznienie](https://www.polsatnews.pl/wiadomosc/2024-08-10/polski-siatkarz-w-druzynie-marzen-igrzysk-ogromne-wyroznienie)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T19:38:00+00:00

Jakub Kochanowski trafił do drużyny marzeń wybranej przez organizatorów Igrzysk Olimpijskich 2024 w Paryżu. Siatkarz znalazł się w gronie najlepszych zawodników w swojej dyscyplinie, razem z reprezentantami Francji i Amerykaninem.

## Rosja chwali się nowymi myśliwcami. "Wprowadzono precyzyjną broń"
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/rosja-chwali-sie-nowymi-mysliwcami-wprowadzono-precyzyjna-bron](https://www.polsatnews.pl/wiadomosc/2024-08-10/rosja-chwali-sie-nowymi-mysliwcami-wprowadzono-precyzyjna-bron)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T18:42:00+00:00

Zakłady Lotnicze w Irkucku wyprodukowały i przekazały Ministerstwu Obrony Rosji nowe wielofunkcyjne myśliwce Su-30SM2 - poinformowały w mediach społecznościowych Zjednoczona Korporacja Lotnicza. Wzrosły możliwości bojowe samolotu - dodano.

## Burza po słowach niemieckiego polityka. Nie chce wysyłać broni na Ukrainę
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/burza-po-slowach-niemieckiego-polityka-nie-chce-wysylac-broni-na-ukraine](https://www.polsatnews.pl/wiadomosc/2024-08-10/burza-po-slowach-niemieckiego-polityka-nie-chce-wysylac-broni-na-ukraine)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T16:50:00+00:00

- Nie możemy dłużej dostarczać Ukrainie funduszy na broń, aby ta broń została zużyta i nic nie osiągnęła. Wszystko musi być proporcjonalne - powiedział premier Saksonii Michael Kretschmer, który dodał, że za ograniczeniem pomocy zbrojeniowej wypowiadał się już od samego początku. Jego słowa spotkały się ze zdecydowanym sprzeciwem. - Obrzydza mnie to - skomentował Marcus Faber.

## Służba więzienna szukała go od tygodnia. Kangur sam wrócił do zakładu karnego
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/sluzba-wiezienna-szukala-go-od-tygodnia-kangur-sam-wrocil-do-zakladu-karnego](https://www.polsatnews.pl/wiadomosc/2024-08-10/sluzba-wiezienna-szukala-go-od-tygodnia-kangur-sam-wrocil-do-zakladu-karnego)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T16:26:00+00:00

Przez ostatni tydzień strażnicy więzienni z Czech intensywnie poszukiwali kangura. Zwierzę uciekło z więzienia i pozostawało nieuchwytne. W sobotę mundurowi poinformowali o szczęśliwym finale sprawy. Kangur sam wrócił do zakładu karnego.

## Ukraińska armia naciera. Trwa ewakuacja tysięcy mieszkańców
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/ukrainska-armia-naciera-trwa-ewakuacja-tysiecy-mieszkancow](https://www.polsatnews.pl/wiadomosc/2024-08-10/ukrainska-armia-naciera-trwa-ewakuacja-tysiecy-mieszkancow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T15:51:00+00:00

Trwa ewakuacja ponad 76 tys. osób w obwodzie kurskim w związku z wtargnięciem ukraińskiej armii - przekazała rosyjska propagandowa agencja TASS, powołując się na Ministerstwo ds. Sytuacji Nadzwyczajnych. Od początku tygodnia ukraińskie siły prowadzą działania na terytoriach przygranicznych.

## Najnowszy sondaż przed wyborami w USA. "Fundamentalna zmiana" w kluczowych stanach
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/najnowszy-sondaz-przed-wyborami-w-usa-fundamentalna-zmiana-w-kluczowych-stanach](https://www.polsatnews.pl/wiadomosc/2024-08-10/najnowszy-sondaz-przed-wyborami-w-usa-fundamentalna-zmiana-w-kluczowych-stanach)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T15:08:00+00:00

Kamala Harris prześcignęła Donalda Trumpa o cztery punkty procentowe w stanach Michigan, Wisconsin i Pensylwanii, czyli tak zwanych swing states, gdzie wyborców demokratów i republikanów jest niemal po równo. To zdecydowany zwrot w porównaniu z wynikami sondaży z początku lipca, które uwzględniały start Joe Bidena. Media określiły najnowsze dane mianem fundamentalnej zmiany w wyścigu.

## "Alarm w rejonie Morza Bałtyckiego". Poderwano myśliwce
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/alarm-w-rejonie-morza-baltyckiego-poderwano-mysliwce](https://www.polsatnews.pl/wiadomosc/2024-08-10/alarm-w-rejonie-morza-baltyckiego-poderwano-mysliwce)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T13:35:00+00:00

Niemieckie siły powietrzne poinformowały przed godz. 12 o alarmie w rejonie Morza Bałtyckiego. Przekazały, że myśliwce z Laage w Szwecji oraz maszyny NATO monitorowały lot rosyjskiego Ił-20M. Samolot leciał bez planu lotu i kontaktu z cywilną kontrolą ruchu lotniczego - przekazało Luftwaffe.

## Polacy przegrali z Francją. Siatkarze wracają ze srebrnym medalem
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/polacy-przegrali-z-francja-siatkarze-wracaja-ze-srebrnym-medalem](https://www.polsatnews.pl/wiadomosc/2024-08-10/polacy-przegrali-z-francja-siatkarze-wracaja-ze-srebrnym-medalem)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T12:24:00+00:00

Polska reprezentacja mężczyzn w siatkówce przegrała z Francją, zdobywając srebrny medal. Mecz zakończył się wynikiem 3:0. Mimo porażki siatkarze i tak mogą cieszyć się wspaniałym osiągnięciem, bowiem ostatni medal w tej dyscyplinie na Igrzyskach Olimpijskich zdobyliśmy 48 lat temu.

## Rosyjski statek w pobliżu Alaski. Patrol ruszył za nim
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/rosyjski-statek-w-poblizu-alaski-patrol-ruszyl-za-nim](https://www.polsatnews.pl/wiadomosc/2024-08-10/rosyjski-statek-w-poblizu-alaski-patrol-ruszyl-za-nim)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T11:53:00+00:00

Amerykańska straż przybrzeżna podczas rutynowego patrolu na południe od Aleutów natknęła się na rosyjski statek. Jednostka znajdowała się na wodach międzynarodowych, ale w obrębie wyłącznej strefy ekonomicznej USA. Statek straży przybrzeżnej nie nawiązał łączności, ale podążał za nim, gdy ten przesuwał się na wschód - podano w komunikacie.

## Praca w Niemczech. Szukają nietypowego nauczyciela
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/praca-w-niemczech-szukaja-nietypowego-nauczyciela](https://www.polsatnews.pl/wiadomosc/2024-08-10/praca-w-niemczech-szukaja-nietypowego-nauczyciela)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T10:06:00+00:00

Pomoc w nauce pływania, tworzenie łóżek dla małych pand czy wyprowadzanie koni - to niektóre z ofert pracy w berlińskim zoo. Od kandydatów wymaga się nie tylko opieki nad zwierzętami, ale także ich szkolenia. Szczególną uwagę na liście wakatów przyciągnęło stanowisko kąpiącego dla młodej hipopotamicy.

## Tragedia na Mont Blanc. Alpinista spadł w przepaść
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/tragedia-na-mont-blanc-alpinista-spadl-w-przepasc](https://www.polsatnews.pl/wiadomosc/2024-08-10/tragedia-na-mont-blanc-alpinista-spadl-w-przepasc)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T10:02:00+00:00

Alpinista spadł z wysokości ok. 4000 metrów podczas wspinaczki na Mont Blanc. Mimo natychmiastowej interwencji służb nie udało się uratować jego życia. Ciało wspinacza zostało odnalezione kilka metrów niżej. W wyprawie brali udział jeszcze dwaj mężczyźni, ale im się nic nie stało. Policja prowadzi w tej sprawie dochodzenie.

## Alaksandr Łukaszenka: Ukraina naruszyła przestrzeń powietrzną Białorusi
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/alaksandr-lukaszenka-ukraina-naruszyla-przestrzen-powietrzna](https://www.polsatnews.pl/wiadomosc/2024-08-10/alaksandr-lukaszenka-ukraina-naruszyla-przestrzen-powietrzna)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T08:53:00+00:00

- Siły powietrzne Białorusi zostały postawione w stan najwyższej gotowości - oświadczył Alaksandr Łukaszenka. Dyktator twierdzi, że Ukraina naruszyła przestrzeń powietrzną Mińska. - Zniszczyliśmy obiekty, które uważamy za drony szturmowe. Wszelkie prowokacje nie pozostaną bez odpowiedzi - cytuje wypowiedź Łukaszenki agencja BelTA. Według dyktatora Białoruś miała zniszczyć około 12 obiektów.

## Pierwszy taki połów w historii. "Bezcenny skarb"
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/pierwszy-taki-polow-w-historii-bezcenny-skarb](https://www.polsatnews.pl/wiadomosc/2024-08-10/pierwszy-taki-polow-w-historii-bezcenny-skarb)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T08:20:00+00:00

Rybak z Wlk. Brytanii był zaskoczony, gdy odkrył, co zaplątało się w jego sieci. - Od razu wiedziałem, co to jest - mówił. Mężczyzna złowił jednego z tysięcy zaginionych rekinów-zabawek, które przed laty były częścią zestawu popularnych klocków. W 1997 r. podczas sztormu u wybrzeży Anglii fala zmiotła ze statku 62 kontenery. Wewnątrz jednego z nich znajdowało się blisko pięć milionów klocków Lego.

## "Błagałem, żeby mnie wpuścili". Przegapili tragiczny lot w Brazylii
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/blagalem-zeby-mnie-wpuscili-przegapili-tragiczny-lot-w-brazylii](https://www.polsatnews.pl/wiadomosc/2024-08-10/blagalem-zeby-mnie-wpuscili-przegapili-tragiczny-lot-w-brazylii)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T06:26:00+00:00

Co najmniej 10 osób przegapiło tragiczny lot samolotu, który rozbił się w piątek na obrzeżach Sao Paulo. Nikt nie przeżył katastrofy. - Nogi mi się trzęsą. Tylko Bóg wie, jak się czuję - mówiła jedna z osób, która spóźniła się na lot. Mężczyzna relacjonował, że pokłócił się z obsługą i błagał, by wpuścili go na pokład. - Uratowali mi życie - mówił.

## Atak na szkołę w Strefie Gazy. Izrael o "punkcie dowodzenia"
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/atak-na-szkole-w-strefie-gazy-izrael-o-punkcie-dowodzenia](https://www.polsatnews.pl/wiadomosc/2024-08-10/atak-na-szkole-w-strefie-gazy-izrael-o-punkcie-dowodzenia)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T06:17:00+00:00

Izrael zaatakował budynek szkoły w Strefie Gazy, w której miał znajdować się punkt dowodzenia Hamasu. Liczba ofiar może sięgać nawet do 100 osób, a dziesiątki poszkodowanych zostało rannych. W placówce znajdowali się wcześniej przesiedleni Palestyńczycy. Atak miał nastąpić podczas porannej modlitwy.

## Rosja reaguje na atak ze strony Ukrainy. Wprowadzono specjalne zasady
 - [https://www.polsatnews.pl/wiadomosc/2024-08-10/rosja-reaguje-na-atak-ze-strony-ukrainy-wprowadzono-specjalne-zasady](https://www.polsatnews.pl/wiadomosc/2024-08-10/rosja-reaguje-na-atak-ze-strony-ukrainy-wprowadzono-specjalne-zasady)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-08-10T05:09:00+00:00

Trzy obwody na terytorium Rosji - kurski, briański i biełgorodzki - zostały objęte specjalnym reżimem operacji antyterrorystycznej. To tereny, które miały zostać zaatakowane i częściowo zajęte przez armię Ukrainy. Kreml twierdzi, że takie działania były konieczne, aby zapewnić bezpieczeństwo obywatelom i zapobiec zamachom terrorystycznym ze strony kijowskiego reżimu.

