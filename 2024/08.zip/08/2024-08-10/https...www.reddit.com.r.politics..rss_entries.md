# Source:Reddit - Politics, URL:https://www.reddit.com/r/politics/.rss, language:en-US

## Trump’s 270-Page Dossier of JD Vance’s ‘Vulnerabilities’ Hacked by Iran
 - [https://www.reddit.com/r/politics/comments/1ep2x78/trumps_270page_dossier_of_jd_vances](https://www.reddit.com/r/politics/comments/1ep2x78/trumps_270page_dossier_of_jd_vances)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T20:44:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ep2x78/trumps_270page_dossier_of_jd_vances/"> <img alt="Trump’s 270-Page Dossier of JD Vance’s ‘Vulnerabilities’ Hacked by Iran" src="https://external-preview.redd.it/9DM1OKVakHQs-nm3dCpG3DDILSdYItxvkPX6NM6d2yQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=688f338fec1a011687c8d21e80fe255f9ea4768e" title="Trump’s 270-Page Dossier of JD Vance’s ‘Vulnerabilities’ Hacked by Iran" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/drtolmn69"> /u/drtolmn69 </a> <br /> <span><a href="https://www.thedailybeast.com/trumps-270-page-dossier-of-jd-vances-vulnerabilities-hacked-by-iran">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ep2x78/trumps_270page_dossier_of_jd_vances/">[comments]</a></span> </td></tr></table>

## Trump campaign says it was hacked
 - [https://www.reddit.com/r/politics/comments/1ep2bk5/trump_campaign_says_it_was_hacked](https://www.reddit.com/r/politics/comments/1ep2bk5/trump_campaign_says_it_was_hacked)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T20:17:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ep2bk5/trump_campaign_says_it_was_hacked/"> <img alt="Trump campaign says it was hacked" src="https://external-preview.redd.it/wxyXwSuiid0jiU90RU1coDlgx4OOGS0TypWUafXbzF4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=45a645bba4c7d16421ffd57e056138f53aa2b52b" title="Trump campaign says it was hacked" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Yourdataisunclean"> /u/Yourdataisunclean </a> <br /> <span><a href="https://www.axios.com/2024/08/10/trump-campaign-hacked">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ep2bk5/trump_campaign_says_it_was_hacked/">[comments]</a></span> </td></tr></table>

## Jesse Ventura Rips 'Rich White Boy' Donald Trump as 'Biggest Draft Dodger'
 - [https://www.reddit.com/r/politics/comments/1ep1xvn/jesse_ventura_rips_rich_white_boy_donald_trump_as](https://www.reddit.com/r/politics/comments/1ep1xvn/jesse_ventura_rips_rich_white_boy_donald_trump_as)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T20:00:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ep1xvn/jesse_ventura_rips_rich_white_boy_donald_trump_as/"> <img alt="Jesse Ventura Rips 'Rich White Boy' Donald Trump as 'Biggest Draft Dodger'" src="https://external-preview.redd.it/HcaOFY-llmQnOCnGvtXe9IX8l-Yv8gYIm6H0aIBp8tA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bb27da639b82ea605f1855c3496543a371894867" title="Jesse Ventura Rips 'Rich White Boy' Donald Trump as 'Biggest Draft Dodger'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://www.newsweek.com/jesse-ventura-rich-white-boy-donald-trump-draft-dodger-1937398">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ep1xvn/jesse_ventura_rips_rich_white_boy_donald_trump_as/">[comments]</a></span> </td></tr></table>

## Celine Dion Disavows Donald Trump’s Use of ‘My Heart Will Go On’ at Campaign Rally: ‘Really, That Song?’
 - [https://www.reddit.com/r/politics/comments/1ep1m7n/celine_dion_disavows_donald_trumps_use_of_my](https://www.reddit.com/r/politics/comments/1ep1m7n/celine_dion_disavows_donald_trumps_use_of_my)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T19:45:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ep1m7n/celine_dion_disavows_donald_trumps_use_of_my/"> <img alt="Celine Dion Disavows Donald Trump’s Use of ‘My Heart Will Go On’ at Campaign Rally: ‘Really, That Song?’" src="https://external-preview.redd.it/UBpvkmcIt-Q0pnx55QnHgMdeSIshuYxhb0CFm_Z0bT8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aafd5e2c26ed2bba04c68b8c7701e9f471ba408a" title="Celine Dion Disavows Donald Trump’s Use of ‘My Heart Will Go On’ at Campaign Rally: ‘Really, That Song?’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/fornuis"> /u/fornuis </a> <br /> <span><a href="https://variety.com/2024/music/news/celine-dion-disavows-donald-trump-my-heart-will-go-on-campaign-rally-really-that-song-1236102825/amp/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ep1m7n/celine_dion_disavows_donald_trumps_use_of_my/">[comments]</a></span> </td></tr></table>

## Donald Trump Privately Rants That Kamala Harris Is a ‘B***h’ as His Polls Plunge
 - [https://www.reddit.com/r/politics/comments/1ep104g/donald_trump_privately_rants_that_kamala_harris](https://www.reddit.com/r/politics/comments/1ep104g/donald_trump_privately_rants_that_kamala_harris)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T19:17:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ep104g/donald_trump_privately_rants_that_kamala_harris/"> <img alt="Donald Trump Privately Rants That Kamala Harris Is a ‘B***h’ as His Polls Plunge" src="https://external-preview.redd.it/zvkAm3NVO9O3-JkH-vH1jDzifjDma0kRkm_m-SmTBzk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=79f15314c1684bae68eca69f73355284f715d34b" title="Donald Trump Privately Rants That Kamala Harris Is a ‘B***h’ as His Polls Plunge" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MystikSpiralx"> /u/MystikSpiralx </a> <br /> <span><a href="https://www.thedailybeast.com/donald-trump-rants-that-kamala-harris-is-a-bh-as-his-polls-plunge-nyt-report">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ep104g/donald_trump_privately_rants_that_kamala_harris/">[comments]</a></span> </td></tr></table>

## Kamala Harris leads Trump in the critical swing states of Michigan, Pennsylvania, and Wisconsin, new poll says
 - [https://www.reddit.com/r/politics/comments/1ep0kgq/kamala_harris_leads_trump_in_the_critical_swing](https://www.reddit.com/r/politics/comments/1ep0kgq/kamala_harris_leads_trump_in_the_critical_swing)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T18:58:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ep0kgq/kamala_harris_leads_trump_in_the_critical_swing/"> <img alt="Kamala Harris leads Trump in the critical swing states of Michigan, Pennsylvania, and Wisconsin, new poll says" src="https://external-preview.redd.it/UYe6HIliDq5o8ERSoXS6fb65Cy95Q-1nexVvxmLJkJs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=78467b7155a043d0786c2ec95c88efe970a327de" title="Kamala Harris leads Trump in the critical swing states of Michigan, Pennsylvania, and Wisconsin, new poll says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plz-let-me-in"> /u/plz-let-me-in </a> <br /> <span><a href="https://www.businessinsider.com/kamala-harris-leads-trump-michigan-pennsylvania-wisconsin-swing-state-polls-2024-8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ep0kgq/kamala_harris_leads_trump_in_the_critical_swing/">[comments]</a></span> </td></tr></table>

## Trump Still Pining for Biden as Messaging Sputters Against Kamala Harris
 - [https://www.reddit.com/r/politics/comments/1ep0jab/trump_still_pining_for_biden_as_messaging](https://www.reddit.com/r/politics/comments/1ep0jab/trump_still_pining_for_biden_as_messaging)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T18:56:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ep0jab/trump_still_pining_for_biden_as_messaging/"> <img alt="Trump Still Pining for Biden as Messaging Sputters Against Kamala Harris" src="https://external-preview.redd.it/u-8C9CcVTB9z3sQrmWYkEb3VvJuvkuXYwhD7aluRcEQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e9e447d0bb4813d0451a82690fd9adda65cd0859" title="Trump Still Pining for Biden as Messaging Sputters Against Kamala Harris" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LosFelizCB"> /u/LosFelizCB </a> <br /> <span><a href="https://www.usnews.com/news/national-news/articles/2024-08-09/trump-still-pining-for-biden-as-messaging-sputters-against-kamala-harris">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ep0jab/trump_still_pining_for_biden_as_messaging/">[comments]</a></span> </td></tr></table>

## Trump Reportedly Refers To Harris As A 'Bitch' In Private
 - [https://www.reddit.com/r/politics/comments/1eozvnq/trump_reportedly_refers_to_harris_as_a_bitch_in](https://www.reddit.com/r/politics/comments/1eozvnq/trump_reportedly_refers_to_harris_as_a_bitch_in)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T18:27:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eozvnq/trump_reportedly_refers_to_harris_as_a_bitch_in/"> <img alt="Trump Reportedly Refers To Harris As A 'Bitch' In Private" src="https://external-preview.redd.it/xYXUThhHnVAj7kaogWUWMLtuI6kSLhQHMsONCMqZ8mg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0179e91353a3fff8c2e9915cc1ebe33bdf20676f" title="Trump Reportedly Refers To Harris As A 'Bitch' In Private" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Real-Work-1953"> /u/Real-Work-1953 </a> <br /> <span><a href="https://www.huffpost.com/entry/trump-reportedly-harris-bitch-private_n_66b79b0ae4b084249ca197f7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eozvnq/trump_reportedly_refers_to_harris_as_a_bitch_in/">[comments]</a></span> </td></tr></table>

## MAGA influencers say Trump is on track to lose the election
 - [https://www.reddit.com/r/politics/comments/1eoy64d/maga_influencers_say_trump_is_on_track_to_lose](https://www.reddit.com/r/politics/comments/1eoy64d/maga_influencers_say_trump_is_on_track_to_lose)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T17:13:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eoy64d/maga_influencers_say_trump_is_on_track_to_lose/"> <img alt="MAGA influencers say Trump is on track to lose the election" src="https://external-preview.redd.it/q-SV14q77IvB5keDEjhSaehGzv8UleW7fIxaAuE8qEg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b3cb05b0fd4fe90b26a4d2f3e6fcb41f2eebc728" title="MAGA influencers say Trump is on track to lose the election" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WayneCider"> /u/WayneCider </a> <br /> <span><a href="https://www.msnbc.com/the-reidout/reidout-blog/trump-election-laura-loomer-nick-fuentes-maga-rcna166003">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eoy64d/maga_influencers_say_trump_is_on_track_to_lose/">[comments]</a></span> </td></tr></table>

## Joy Ride: Upbeat Dems Are Spreading Optimism to a Divided (and Newly Delighted) Nation
 - [https://www.reddit.com/r/politics/comments/1eoxu3k/joy_ride_upbeat_dems_are_spreading_optimism_to_a](https://www.reddit.com/r/politics/comments/1eoxu3k/joy_ride_upbeat_dems_are_spreading_optimism_to_a)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T16:59:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eoxu3k/joy_ride_upbeat_dems_are_spreading_optimism_to_a/"> <img alt="Joy Ride: Upbeat Dems Are Spreading Optimism to a Divided (and Newly Delighted) Nation" src="https://external-preview.redd.it/RdAmxrJBHYhztml2_3EgfdKi66zZHXEbTJlFqmtD6xw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b90f68a0925d64d61a09e62a8daa7d9183cf1357" title="Joy Ride: Upbeat Dems Are Spreading Optimism to a Divided (and Newly Delighted) Nation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ice_Burn"> /u/Ice_Burn </a> <br /> <span><a href="https://www.vanityfair.com/news/story/democrats-optimism-2024-election">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eoxu3k/joy_ride_upbeat_dems_are_spreading_optimism_to_a/">[comments]</a></span> </td></tr></table>

## Saturday Morning Political Cartoon Thread
 - [https://www.reddit.com/r/politics/comments/1eox6vc/saturday_morning_political_cartoon_thread](https://www.reddit.com/r/politics/comments/1eox6vc/saturday_morning_political_cartoon_thread)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T16:31:46+00:00

<!-- SC_OFF --><div class="md"><p>It's Saturday, folks. Let's all kick back with a cup of coffee and share some cartoons!</p> <p>Feel free to share political cartoons in this thread. Besides our usual civility policy, there are three rules to follow:</p> <ol> <li><p>Every top-level comment must contain a political cartoon. This means no text-only top-level comments.</p></li> <li><p>It must be an original cartoon. This means no photographs, no edited cartoons, no AI generated images, no templates, no memes and no image macros. OC is allowed, as is animation.</p></li> <li><p>Each top-level comment should only have a maximum of 3 cartoons. </p></li> </ol> <p>That's all. Enjoy your weekend!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/optimalg"> /u/optimalg </a> <br /> <span><a href="https://www.reddit.com/r/politics/comments/1eox6vc/saturday_morning_political_cartoon_thread/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politic

## Kamala Harris Campaign Trolls Trump With Video of Empty Seats at His Rally
 - [https://www.reddit.com/r/politics/comments/1eox41b/kamala_harris_campaign_trolls_trump_with_video_of](https://www.reddit.com/r/politics/comments/1eox41b/kamala_harris_campaign_trolls_trump_with_video_of)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T16:28:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eox41b/kamala_harris_campaign_trolls_trump_with_video_of/"> <img alt="Kamala Harris Campaign Trolls Trump With Video of Empty Seats at His Rally" src="https://external-preview.redd.it/fBVo_FRzaWtVItj02Ua5Dw-0dvKwYThPRKI6NTzB8JY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9e7e8348724bfc9d81f31565846b1f9d74babb78" title="Kamala Harris Campaign Trolls Trump With Video of Empty Seats at His Rally" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Olive_Worried"> /u/Olive_Worried </a> <br /> <span><a href="https://www.newsweek.com/kamala-harris-donald-trump-rally-size-1937390">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eox41b/kamala_harris_campaign_trolls_trump_with_video_of/">[comments]</a></span> </td></tr></table>

## Trump bizarrely claims nobody knows his Democratic rival’s last name (it’s Harris)
 - [https://www.reddit.com/r/politics/comments/1eowyni/trump_bizarrely_claims_nobody_knows_his](https://www.reddit.com/r/politics/comments/1eowyni/trump_bizarrely_claims_nobody_knows_his)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T16:22:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eowyni/trump_bizarrely_claims_nobody_knows_his/"> <img alt="Trump bizarrely claims nobody knows his Democratic rival’s last name (it’s Harris)" src="https://external-preview.redd.it/c7rVbkKeEKYaizDo3ikvQHyjmItQb4yC90V6dCKuBKo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3e221c5f08b5cb6c02b6c9f8423c4b2d5174e7e3" title="Trump bizarrely claims nobody knows his Democratic rival’s last name (it’s Harris)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/theindependentonline"> /u/theindependentonline </a> <br /> <span><a href="https://www.independent.co.uk/news/world/americas/us-politics/trump-kamala-harris-montana-rally-b2594427.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eowyni/trump_bizarrely_claims_nobody_knows_his/">[comments]</a></span> </td></tr></table>

## 'We're Not Going Back': Seniors Agree with Kamala Harris and Tim Walz - We’re not going back on Social Security. We're not going back on Medicare. We're not going back on lower drug prices.
 - [https://www.reddit.com/r/politics/comments/1eownw9/were_not_going_back_seniors_agree_with_kamala](https://www.reddit.com/r/politics/comments/1eownw9/were_not_going_back_seniors_agree_with_kamala)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T16:09:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eownw9/were_not_going_back_seniors_agree_with_kamala/"> <img alt="'We're Not Going Back': Seniors Agree with Kamala Harris and Tim Walz - We’re not going back on Social Security. We're not going back on Medicare. We're not going back on lower drug prices." src="https://external-preview.redd.it/WIBwx3OiqbDJLV9QwgjBMPXh6kckkm1IcapRxdRUDQo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8cff1b21e60564feaabb1fb763e8e0fe1f3f436e" title="'We're Not Going Back': Seniors Agree with Kamala Harris and Tim Walz - We’re not going back on Social Security. We're not going back on Medicare. We're not going back on lower drug prices." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://www.commondreams.org/opinion/not-going-back-harris-walz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eownw9/were_not_going_bac

## Republicans who think ‘Tampon Tim’ is an insult are actually Walz’s best publicists
 - [https://www.reddit.com/r/politics/comments/1eowff9/republicans_who_think_tampon_tim_is_an_insult_are](https://www.reddit.com/r/politics/comments/1eowff9/republicans_who_think_tampon_tim_is_an_insult_are)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T15:59:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eowff9/republicans_who_think_tampon_tim_is_an_insult_are/"> <img alt="Republicans who think ‘Tampon Tim’ is an insult are actually Walz’s best publicists" src="https://external-preview.redd.it/Q-Ci7L1qTOoTdK2pO1vKXM_vswbKWmCp63oTe0m0VGg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c7080726dea6ad3e02fb91c193172aa76d6980bd" title="Republicans who think ‘Tampon Tim’ is an insult are actually Walz’s best publicists" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Iknowwecanmakeit"> /u/Iknowwecanmakeit </a> <br /> <span><a href="https://www.theguardian.com/commentisfree/article/2024/aug/10/republicans-tampon-tim-walz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eowff9/republicans_who_think_tampon_tim_is_an_insult_are/">[comments]</a></span> </td></tr></table>

## A sinking ship? Donald Trump campaign mocked for playing 'Titanic' song at rally
 - [https://www.reddit.com/r/politics/comments/1eovsae/a_sinking_ship_donald_trump_campaign_mocked_for](https://www.reddit.com/r/politics/comments/1eovsae/a_sinking_ship_donald_trump_campaign_mocked_for)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T15:31:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eovsae/a_sinking_ship_donald_trump_campaign_mocked_for/"> <img alt="A sinking ship? Donald Trump campaign mocked for playing 'Titanic' song at rally" src="https://external-preview.redd.it/h0xeoJ-EAKJx6PWxLuoWnMINpPisl5I5nKnu3j0gOjw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c801ff22aacc55eba6744bbb541022fec49a488" title="A sinking ship? Donald Trump campaign mocked for playing 'Titanic' song at rally" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RiskRough6345"> /u/RiskRough6345 </a> <br /> <span><a href="https://www.usatoday.com/story/news/politics/elections/2024/08/10/donald-trump-titanic-celine-dion/74747976007/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eovsae/a_sinking_ship_donald_trump_campaign_mocked_for/">[comments]</a></span> </td></tr></table>

## Tim Walz is dressing the part — and it's exactly what Harris needs
 - [https://www.reddit.com/r/politics/comments/1eovfgo/tim_walz_is_dressing_the_part_and_its_exactly](https://www.reddit.com/r/politics/comments/1eovfgo/tim_walz_is_dressing_the_part_and_its_exactly)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T15:15:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eovfgo/tim_walz_is_dressing_the_part_and_its_exactly/"> <img alt="Tim Walz is dressing the part — and it's exactly what Harris needs" src="https://external-preview.redd.it/EtdIJjDdxiS2i6S7NehmAX3lz6D_66JnzC6SURYxT5w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bad8c17bda60d6835bb16ae85089a1ab09246e0f" title="Tim Walz is dressing the part — and it's exactly what Harris needs" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BothZookeepergame612"> /u/BothZookeepergame612 </a> <br /> <span><a href="https://www.businessinsider.com/tim-walz-midwest-fashion-experts-harris-campaign-2024-8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eovfgo/tim_walz_is_dressing_the_part_and_its_exactly/">[comments]</a></span> </td></tr></table>

## Tim Walz is riding the wave of the vibes election: This moment is all about feelings. Enter a friendly Midwestern governor armed with dad jokes.
 - [https://www.reddit.com/r/politics/comments/1eov24h/tim_walz_is_riding_the_wave_of_the_vibes_election](https://www.reddit.com/r/politics/comments/1eov24h/tim_walz_is_riding_the_wave_of_the_vibes_election)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T15:00:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eov24h/tim_walz_is_riding_the_wave_of_the_vibes_election/"> <img alt="Tim Walz is riding the wave of the vibes election: This moment is all about feelings. Enter a friendly Midwestern governor armed with dad jokes." src="https://external-preview.redd.it/B54tD6K9Qm69Sa0gh1n2wUs1Ed_bNc3wZJ91SwAiAUY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=90a7de7eada823b3b571df17c6384655fb9e6180" title="Tim Walz is riding the wave of the vibes election: This moment is all about feelings. Enter a friendly Midwestern governor armed with dad jokes." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br /> <span><a href="https://www.vox.com/culture/366368/tim-walz-vibes-memes-vice-president">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eov24h/tim_walz_is_riding_the_wave_of_the_vibes_election/">[comments]</a></span> </td></tr></table>

## Trump's feud with Georgia Gov. Brian Kemp risks blowing the key state
 - [https://www.reddit.com/r/politics/comments/1eotrlv/trumps_feud_with_georgia_gov_brian_kemp_risks](https://www.reddit.com/r/politics/comments/1eotrlv/trumps_feud_with_georgia_gov_brian_kemp_risks)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T14:01:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eotrlv/trumps_feud_with_georgia_gov_brian_kemp_risks/"> <img alt="Trump's feud with Georgia Gov. Brian Kemp risks blowing the key state" src="https://external-preview.redd.it/RA4tAdQmXEax0Gckx_9iuovj9pdw4eOMbjksLqx9a-E.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=eadb29e604a204398f2742974ddae2c330395923" title="Trump's feud with Georgia Gov. Brian Kemp risks blowing the key state" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BothZookeepergame612"> /u/BothZookeepergame612 </a> <br /> <span><a href="https://www.businessinsider.com/trump-brian-kemp-relationship-georgia-election-2024-8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eotrlv/trumps_feud_with_georgia_gov_brian_kemp_risks/">[comments]</a></span> </td></tr></table>

## Arizona Republican Mayor Blasts 'Out Of Touch' GOP While Backing Kamala Harris | Mesa Mayor John Giles declared that he's putting his "country over party" at a campaign rally for the vice president.
 - [https://www.reddit.com/r/politics/comments/1eotfz8/arizona_republican_mayor_blasts_out_of_touch_gop](https://www.reddit.com/r/politics/comments/1eotfz8/arizona_republican_mayor_blasts_out_of_touch_gop)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T13:47:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eotfz8/arizona_republican_mayor_blasts_out_of_touch_gop/"> <img alt="Arizona Republican Mayor Blasts 'Out Of Touch' GOP While Backing Kamala Harris | Mesa Mayor John Giles declared that he's putting his &quot;country over party&quot; at a campaign rally for the vice president." src="https://external-preview.redd.it/jKCtvTXjCXFVW-198dN-rawoQQ67sBgjxAi17M3Hqrs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5ef46bc00d173ee924b6109b4ea2d1fc7030c233" title="Arizona Republican Mayor Blasts 'Out Of Touch' GOP While Backing Kamala Harris | Mesa Mayor John Giles declared that he's putting his &quot;country over party&quot; at a campaign rally for the vice president." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murky-Site7468"> /u/Murky-Site7468 </a> <br /> <span><a href="https://www.huffpost.com/entry/arizona-gop-mayor-john-giles-kamala-harris-rally_n_66b708c6e4b07f675172e881">[link]</a>

## Report: Trump calls Harris a "bitch"
 - [https://www.reddit.com/r/politics/comments/1eot6yz/report_trump_calls_harris_a_bitch](https://www.reddit.com/r/politics/comments/1eot6yz/report_trump_calls_harris_a_bitch)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T13:35:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eot6yz/report_trump_calls_harris_a_bitch/"> <img alt="Report: Trump calls Harris a &quot;bitch&quot;" src="https://external-preview.redd.it/B1rhUoSmFCj0e5dxBBuCrMMBWneuVgo3SGiQ6OkOD4c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=56bed4520fe8cc20c4e9618ffd02f3beb7ffe7d8" title="Report: Trump calls Harris a &quot;bitch&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NateGrey"> /u/NateGrey </a> <br /> <span><a href="https://www.axios.com/2024/08/10/trump-calls-harris-bitch-report">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eot6yz/report_trump_calls_harris_a_bitch/">[comments]</a></span> </td></tr></table>

## 'Our lives are on the line': Why many LGBTQ+ people hope for a Harris win
 - [https://www.reddit.com/r/politics/comments/1eosuss/our_lives_are_on_the_line_why_many_lgbtq_people](https://www.reddit.com/r/politics/comments/1eosuss/our_lives_are_on_the_line_why_many_lgbtq_people)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T13:18:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eosuss/our_lives_are_on_the_line_why_many_lgbtq_people/"> <img alt="'Our lives are on the line': Why many LGBTQ+ people hope for a Harris win " src="https://external-preview.redd.it/AUrUuqaKsOGhOFTkR0Ytjb5z6ouP_p985HsHC_eapg4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=224e7daa6427c11d0e3615e1f1343d4dd443ce7b" title="'Our lives are on the line': Why many LGBTQ+ people hope for a Harris win " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Economy_Computer_865"> /u/Economy_Computer_865 </a> <br /> <span><a href="https://www.latimes.com/politics/story/2024-08-08/election-harris-lgbtq-people-trump">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eosuss/our_lives_are_on_the_line_why_many_lgbtq_people/">[comments]</a></span> </td></tr></table>

## Trump tells his supporters what to do about Joe Rogan
 - [https://www.reddit.com/r/politics/comments/1eosiv7/trump_tells_his_supporters_what_to_do_about_joe](https://www.reddit.com/r/politics/comments/1eosiv7/trump_tells_his_supporters_what_to_do_about_joe)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T13:02:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eosiv7/trump_tells_his_supporters_what_to_do_about_joe/"> <img alt="Trump tells his supporters what to do about Joe Rogan" src="https://external-preview.redd.it/vsER6OuSnM_A72kHkbGAx8WOkZdQNzNZw3B_a7-O5ps.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=265206b399ae9b51ed0bf2da16f57553fd59fd2a" title="Trump tells his supporters what to do about Joe Rogan" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/njdotcom"> /u/njdotcom </a> <br /> <span><a href="https://www.nj.com/politics/2024/08/trump-tells-his-supporters-what-to-do-about-joe-rogan.html?utm_medium=social&amp;utm_source=redditsocial">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eosiv7/trump_tells_his_supporters_what_to_do_about_joe/">[comments]</a></span> </td></tr></table>

## Racism Is Why Trump Is So Popular
 - [https://www.reddit.com/r/politics/comments/1eoqury/racism_is_why_trump_is_so_popular](https://www.reddit.com/r/politics/comments/1eoqury/racism_is_why_trump_is_so_popular)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T11:32:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eoqury/racism_is_why_trump_is_so_popular/"> <img alt="Racism Is Why Trump Is So Popular" src="https://external-preview.redd.it/_XyNZGuIeNLroH3vo-vC6qWlzaglwR5fzuFghLGt5bc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=15846041ea6e36ce62592f8dab069338389a5e33" title="Racism Is Why Trump Is So Popular" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plz-let-me-in"> /u/plz-let-me-in </a> <br /> <span><a href="https://theintercept.com/2024/08/10/republicans-trump-vance-racism-white-nationalism/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eoqury/racism_is_why_trump_is_so_popular/">[comments]</a></span> </td></tr></table>

## Harris Leads Trump in Three Key States Times Siena Polls Find
 - [https://www.reddit.com/r/politics/comments/1eopyog/harris_leads_trump_in_three_key_states_times](https://www.reddit.com/r/politics/comments/1eopyog/harris_leads_trump_in_three_key_states_times)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T10:36:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eopyog/harris_leads_trump_in_three_key_states_times/"> <img alt="Harris Leads Trump in Three Key States Times Siena Polls Find" src="https://external-preview.redd.it/iLX7DxnYNyiQIuYNCQPeHPTSE0j3GSIwtFj3iKa6zYA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=789c500b09dee889b710ec983deaac05dbfb6cd3" title="Harris Leads Trump in Three Key States Times Siena Polls Find" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JorgJorgJorg"> /u/JorgJorgJorg </a> <br /> <span><a href="https://www.nytimes.com/2024/08/10/us/politics/harris-trump-battleground-polls.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eopyog/harris_leads_trump_in_three_key_states_times/">[comments]</a></span> </td></tr></table>

## Kamala Harris winning over white voters from Trump, polling suggests
 - [https://www.reddit.com/r/politics/comments/1eonszq/kamala_harris_winning_over_white_voters_from](https://www.reddit.com/r/politics/comments/1eonszq/kamala_harris_winning_over_white_voters_from)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-08-10T08:06:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1eonszq/kamala_harris_winning_over_white_voters_from/"> <img alt="Kamala Harris winning over white voters from Trump, polling suggests" src="https://external-preview.redd.it/CSQkiM-4DKWVq7hF17-zE5j7byYkluf0nzXa_Llgpnc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ba5c4f6ca923bd32993675758f400c2cccab83da" title="Kamala Harris winning over white voters from Trump, polling suggests" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Visual-Explorer-111"> /u/Visual-Explorer-111 </a> <br /> <span><a href="https://www.newsweek.com/kamala-harris-winning-white-voters-polling-1936979">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1eonszq/kamala_harris_winning_over_white_voters_from/">[comments]</a></span> </td></tr></table>

