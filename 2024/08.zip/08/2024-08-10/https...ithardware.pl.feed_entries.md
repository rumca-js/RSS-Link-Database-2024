# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## YouTube Premium wzgobacił się o funkcję, która powinna być darmowa
 - [https://ithardware.pl/aktualnosci/youtube_premium_wzgobacil_sie_o_funkcje_ktora_powinna_byc_darmowa-34449.html](https://ithardware.pl/aktualnosci/youtube_premium_wzgobacil_sie_o_funkcje_ktora_powinna_byc_darmowa-34449.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-08-10T18:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/34449_1.jpg" />            Ludzie spędzają mn&oacute;stwo czasu na YouTube i zdarza im się zasnąć podczas oglądania filmu. Dla takich os&oacute;b platforma przygotowała specjalną funkcję, szkoda tylko, że została zarezerwowana dla wersji Premium.

YouTube testuje tryb...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/youtube_premium_wzgobacil_sie_o_funkcje_ktora_powinna_byc_darmowa-34449.html">https://ithardware.pl/aktualnosci/youtube_premium_wzgobacil_sie_o_funkcje_ktora_powinna_byc_darmowa-34449.html</a></p>

## Civilization 7 z oknem premiery. Prezentacja gry jeszcze w sierpniu
 - [https://ithardware.pl/aktualnosci/civilization_7_nowe_szczegoly_na_temat_daty_premiery_prezentacja_gry_jeszcze_w_sierpniu-34448.html](https://ithardware.pl/aktualnosci/civilization_7_nowe_szczegoly_na_temat_daty_premiery_prezentacja_gry_jeszcze_w_sierpniu-34448.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-08-10T16:17:26+00:00

<img src="https://ithardware.pl/artykuly/min/34448_1.jpg" />            Poznaliśmy okno premiery&nbsp;Civilization 7, kt&oacute;re trafi do sprzedaży w 2025 roku. Docelowymi platformami są PC, PlayStation 5, PS4, Xbox Series X/S, Xbox One oraz Nintendo Switch.

Jak wynika z raportu finansowego Take-Two, do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/civilization_7_nowe_szczegoly_na_temat_daty_premiery_prezentacja_gry_jeszcze_w_sierpniu-34448.html">https://ithardware.pl/aktualnosci/civilization_7_nowe_szczegoly_na_temat_daty_premiery_prezentacja_gry_jeszcze_w_sierpniu-34448.html</a></p>

## Niemiecka policja ma pomysł na walkę z przestępczością. Chce rozdawać darmowego Netflixa
 - [https://ithardware.pl/aktualnosci/niemiecka_policja_ma_pomysl_na_walke_z_przestepczoscia_chce_rozdawac_darmowego_netflixa-34447.html](https://ithardware.pl/aktualnosci/niemiecka_policja_ma_pomysl_na_walke_z_przestepczoscia_chce_rozdawac_darmowego_netflixa-34447.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-08-10T15:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/34447_1.jpg" />            Niemiecka policja wpadła na zaskakujący pomysł, by w ramach walki z przestępczością rozdawać subskrypcje Netflixa. Propozycja jest skierowana do os&oacute;b posiadających nielegalny n&oacute;ż. Nie, nie jest to żart prima aprilis.

Jochen...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/niemiecka_policja_ma_pomysl_na_walke_z_przestepczoscia_chce_rozdawac_darmowego_netflixa-34447.html">https://ithardware.pl/aktualnosci/niemiecka_policja_ma_pomysl_na_walke_z_przestepczoscia_chce_rozdawac_darmowego_netflixa-34447.html</a></p>

## PlayStation Studios ma oferować więcej hitów. Sony ujawnia plan
 - [https://ithardware.pl/aktualnosci/playstation_studios_ma_oferowac_wiecej_hitow_sony_ujawnia_plan-34446.html](https://ithardware.pl/aktualnosci/playstation_studios_ma_oferowac_wiecej_hitow_sony_ujawnia_plan-34446.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-08-10T12:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/34446_1.jpg" />            PlayStation Studios przejdzie zmiany, kt&oacute;re w założeniu wpłyną na wydawanie większej ilości hit&oacute;w na konsole oraz komputery. Sony przedstawiło plan działania podczas spotkania poświęconego finansom.

Ghost of Tsushima na PC czy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/playstation_studios_ma_oferowac_wiecej_hitow_sony_ujawnia_plan-34446.html">https://ithardware.pl/aktualnosci/playstation_studios_ma_oferowac_wiecej_hitow_sony_ujawnia_plan-34446.html</a></p>

## Nie żyje Susan Wojcicki. Była szefowa YouTube odeszła w wieku 56 lat
 - [https://ithardware.pl/aktualnosci/nie_zyje_susan_wojcicki_byla_szefowa_youtube_odeszla_w_wieku_56_lat-34445.html](https://ithardware.pl/aktualnosci/nie_zyje_susan_wojcicki_byla_szefowa_youtube_odeszla_w_wieku_56_lat-34445.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-08-10T10:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/34445_1.jpg" />            Susan Wojcicki, kt&oacute;ra w przeszłości pełniła funkcję dyrektor generalnej YouTube zmarła wczoraj. Warto przypomnieć, że to właśnie w jej garażu powstała jedna z największych technologicznych korporacji, Google.

Dyrektor generalny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nie_zyje_susan_wojcicki_byla_szefowa_youtube_odeszla_w_wieku_56_lat-34445.html">https://ithardware.pl/aktualnosci/nie_zyje_susan_wojcicki_byla_szefowa_youtube_odeszla_w_wieku_56_lat-34445.html</a></p>

