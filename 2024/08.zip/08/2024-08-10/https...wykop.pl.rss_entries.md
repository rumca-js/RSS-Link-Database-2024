# Source:Wykop, URL:https://wykop.pl/rss, language:pl-PL

## No i stało się..kompromitacja polskich olimpijczyków! Tak źle nie było od 72 lat
 - [https://wykop.pl/link/7513541/no-i-stalo-sie-kompromitacja-polskich-olimpijczykow-tak-zle-nie-bylo-od-72-lat](https://wykop.pl/link/7513541/no-i-stalo-sie-kompromitacja-polskich-olimpijczykow-tak-zle-nie-bylo-od-72-lat)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T20:09:33+00:00

<img src="https://wykop.pl/cdn/c3397993/663b484ed50c560feab38bdd11816a28c4f1f61b5c931eafdbe7b44e070fc5a4,w104h74.jpg" /><br /> Bilans medalowy polskich sportowców w Paryżu to 1Z 3S 5B. Totalna kompromitacja naszych olimpijczyków, których do stolicy Francji pojechało 211. Ostani raz (niewiele) słabsze osiągnięcie odnotowaliśmy w 1952 roku w Helsinkach, w bardzo ciężkich powojennych czasach.

## Sędzia ostrzega, że nie zostaniesz zwolniony za kaucją, nawet jeśli tylko ...
 - [https://wykop.pl/link/7513525/sedzia-ostrzega-ze-nie-zostaniesz-zwolniony-za-kaucja-nawet-jesli-tylko](https://wykop.pl/link/7513525/sedzia-ostrzega-ze-nie-zostaniesz-zwolniony-za-kaucja-nawet-jesli-tylko)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T19:48:24+00:00

<img src="https://wykop.pl/cdn/c3397993/ad52120018504c9c6c01c40dca112e21b74296aecbe3457e19b41080c474d086,w104h74.jpg" /><br /> przyglądałeś się zamieszkom z boku. Niezależnie od tego, czy jesteś "aktywnym uczestnikiem", czy "ciekawskim obserwatorem", każdy zaangażowany w zamieszki zostanie zamknięty - informuje sąd w Belfaście.

## Julia Szeremeta wicemistrzynią olimpijską w boksie !
 - [https://wykop.pl/link/7513517/julia-szeremeta-wicemistrzynia-olimpijska-w-boksie](https://wykop.pl/link/7513517/julia-szeremeta-wicemistrzynia-olimpijska-w-boksie)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T19:46:04+00:00

<img src="https://wykop.pl/cdn/c3397993/56c52801f82e11cd9c026c3e28f69901815a8c0064be96099f90ccaeaf4d4a17,w104h74.jpg" /><br /> Julia Szeremeta wicemistrzynią olimpijską w kategorii wagowej do 57kg. To pierwszy medal w boksie dla Polski od 1992 roku a pierwszy srebrny od 1980. W finale przegrała z Lin Yu Ting z Tajwanu.

## Niemcy sprzedali teren byłego obozu koncentracyjnego inwestorowi z branży...
 - [https://wykop.pl/link/7513495/niemcy-sprzedali-teren-bylego-obozu-koncentracyjnego-inwestorowi-z-branzy-nieruc](https://wykop.pl/link/7513495/niemcy-sprzedali-teren-bylego-obozu-koncentracyjnego-inwestorowi-z-branzy-nieruc)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T18:51:46+00:00

<img src="https://wykop.pl/cdn/c3397993/bfd2df7ccb927ae0ad3e8a3ea2ded232746d8cb3e209c892206d54a238ccfed2,w104h74.jpg" /><br /> ...nieruchomości. Teren byłego obozu koncentracyjnego w pobliżu Halberstadt w Saksonii-Anhalt, w którym zginęło ponad 4,3 tys. osób,...

## Nie chciał przyjść do pracy w Żabce w niedzielę. Ajent odmówił mu wypłaty pensji
 - [https://wykop.pl/link/7513489/nie-chcial-przyjsc-do-pracy-w-zabce-w-niedziele-ajent-odmowil-mu-wyplaty-pensji](https://wykop.pl/link/7513489/nie-chcial-przyjsc-do-pracy-w-zabce-w-niedziele-ajent-odmowil-mu-wyplaty-pensji)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T18:39:33+00:00

<img src="https://wykop.pl/cdn/c3397993/a0b004e3e48b87fcf7a3e3d6cb91a5b4bb1f2be8f98d3ccbd38abd46e07c8deb,w104h74.jpg" /><br /> 19-letni Hubert pracował w Żabce nawet 10 godzin dziennie. Ajent chciał, żeby przyszedł też w niedzielę na 12 godzin. Nastolatek się nie zgodził. W konsekwencji przedsiębiorca odmówił mu wypłaty pensji.

## Budda sprawdzi sobie Twoje dane osobowe - piszemy do UODO !
 - [https://wykop.pl/link/7513487/budda-sprawdzi-sobie-twoje-dane-osobowe-piszemy-do-uodo](https://wykop.pl/link/7513487/budda-sprawdzi-sobie-twoje-dane-osobowe-piszemy-do-uodo)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T18:38:53+00:00

<img src="https://wykop.pl/cdn/c3397993/ebab71fa67e272dfbb0338ee51be9fc32e9f5228f131bc9063b45963fe849090,w104h74.jpg" /><br /> budda w ostatnim filmie (https://youtu.be/7uHHFK4gM3g?si=LItePbKi3K-7XCah&amp;t=385) przyznaje się, że sprawdza sobie dane osobowe ludzi biorących udział w loteriach firmy LUPULOS MEDIA - tym trzeba zainteresować UODO, wysyłamy więc mail na kancelaria@uodo.gov.pl

## Brytyjski policjant klęka przed murzynem
 - [https://wykop.pl/link/7513485/brytyjski-policjant-kleka-przed-murzynem](https://wykop.pl/link/7513485/brytyjski-policjant-kleka-przed-murzynem)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T18:31:55+00:00

<img src="https://wykop.pl/cdn/c3397993/ab0cfb6c0a2b2a67aaef7655dc878d0388361e91b8e44cf68b3d366fb12f94a1,w104h74.jpg" /><br /> taki zwykły dzień w Wielkiej Brytanii

## Toronto - muzulmańscy imigranci modlą się ...
 - [https://wykop.pl/link/7513481/toronto-muzulmanscy-imigranci-modla-sie](https://wykop.pl/link/7513481/toronto-muzulmanscy-imigranci-modla-sie)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T18:24:11+00:00

<img src="https://wykop.pl/cdn/c3397993/c5a10e7f64b702ee025718b79e5b51dcac036afae2cc8f6ef569e38b397d21e0,w104h74.jpg" /><br /> na środku jezdni blokując m.in. tory tranwajowe

## Poznań: Wolontariuszki kradną pieniądze ze skarbonki.
 - [https://wykop.pl/link/7513477/poznan-wolontariuszki-kradna-pieniadze-ze-skarbonki](https://wykop.pl/link/7513477/poznan-wolontariuszki-kradna-pieniadze-ze-skarbonki)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T18:19:03+00:00

<img src="https://wykop.pl/cdn/c3397993/b1d59a96654eb85d3738260903ceca2bb68d2ac00c454836b626644455c3d747,w104h74.jpg" /><br /> Wolontariuszki okradają pod mostem Teatralnym skarbonki fundacji Nadzieja na Przyszłość która pomaga ukraińskim dzieciom.

## Panika po ataku Ukrainy. Ewakuacja dziesiątek tysięcy osób
 - [https://wykop.pl/link/7513463/panika-po-ataku-ukrainy-ewakuacja-dziesiatek-tysiecy-osob](https://wykop.pl/link/7513463/panika-po-ataku-ukrainy-ewakuacja-dziesiatek-tysiecy-osob)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T17:30:05+00:00

<img src="https://wykop.pl/cdn/c3397993/dfd663a88338c08bc64515e10c2cf0fb0b875e98829a306ab622856902af80cc,w104h74.jpg" /><br /> Trwa ewakuacja ponad 76 tys. osób w obwodzie kurskim w związku z wtargnięciem ukraińskiej armii

## Niemiecki polityk chce ograniczyć pomoc dla Ukrainy. "Broń nic nie osiągnęła"
 - [https://wykop.pl/link/7513451/niemiecki-polityk-chce-ograniczyc-pomoc-dla-ukrainy-bron-nic-nie-osiagnela](https://wykop.pl/link/7513451/niemiecki-polityk-chce-ograniczyc-pomoc-dla-ukrainy-bron-nic-nie-osiagnela)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T16:57:47+00:00

<img src="https://wykop.pl/cdn/c3397993/f0c52759010b2602d3627c3e529f7354d255b4d5e74565db5a80e78840d74423,w104h74.jpg" /><br /> - Nie możemy dłużej dostarczać Ukrainie funduszy na broń, aby ta broń została zużyta i nic nie osiągnęła. Wszystko musi być proporcjonalne - powiedział premier Saksonii Michael Kretschmer.

## Cztery rakiety Himars zlikwidowały aż 490 Rosjan w ataku pod Rylskiem.
 - [https://wykop.pl/link/7513429/cztery-rakiety-himars-zlikwidowaly-az-490-rosjan-w-ataku-pod-rylskiem](https://wykop.pl/link/7513429/cztery-rakiety-himars-zlikwidowaly-az-490-rosjan-w-ataku-pod-rylskiem)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T16:22:44+00:00

<img src="https://wykop.pl/cdn/c3397993/fdcfd848cdb50e2f93eca813fd7fcca9b564c45cdd286f8db93589bdb5d892c0,w104h74.jpg" /><br /> Do tej pory nie była znana liczba ofiar. W wyniku ukraińskiego uderzenia na rosyjski konwój pod Rylskiem zginęło 490 rosyjskich żołnierzy poinformowała 116. brygada zmechanizowana Sił Zbrojnych Ukrainy. To pierwszy oficjalny komunikat Kijowa w sprawie ataku w obwodzie kurskim.

## Karierę najszybszej kobiety świata zniszczono oskarżeniem, że jest mężczyzną
 - [https://wykop.pl/link/7513413/kariere-najszybszej-kobiety-swiata-zniszczono-oskarzeniem-ze-jest-mezczyzna](https://wykop.pl/link/7513413/kariere-najszybszej-kobiety-swiata-zniszczono-oskarzeniem-ze-jest-mezczyzna)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T15:42:25+00:00

<img src="https://wykop.pl/cdn/c3397993/7ed3570237f52c67c65e9915414d07fa5ea58c9342637460fb51e138b4113c3b,w104h74.jpg" /><br /> Wydawało się, że wielka kariera sportowa stoi przed Ewą Kłobukowską otworem. Kiedy wszystko szło w tym kierunku, pojawił się donos z "zaprzyjaźnionych" sowieckich krajów. Uznano, że jest mężczyzną bo słaba płeć tak szybko nie biega.

## Ukraina. Księgowa firmy pracującej dla MON chciała wywieźć 5 mln EUR w bagażniku
 - [https://wykop.pl/link/7513395/ukraina-ksiegowa-firmy-pracujacej-dla-mon-chciala-wywiezc-5-mln-eur-w-bagazniku](https://wykop.pl/link/7513395/ukraina-ksiegowa-firmy-pracujacej-dla-mon-chciala-wywiezc-5-mln-eur-w-bagazniku)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T14:41:48+00:00

<img src="https://wykop.pl/cdn/c3397993/108866e331ede12fd14573bfa1b7a71111d147662658cdcbaccaee3bb3ae0926,w104h74.jpg" /><br /> Biuro Bezpieczeństwa Gospodarczego Ukrainy ujawniło 4,7 miliona euro w gotówce. Pieniądze zostały znalezione u księgowej pracującej dla firmy dostarczającej produkty dla Ministerstwa Obrony Ukrainy.

## Pożar składowiska odpadów. Kłęby dymu nad miastem
 - [https://wykop.pl/link/7513389/pozar-skladowiska-odpadow-kleby-dymu-nad-miastem](https://wykop.pl/link/7513389/pozar-skladowiska-odpadow-kleby-dymu-nad-miastem)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T14:27:12+00:00

<img src="https://wykop.pl/cdn/c3397993/928c6207f13872d23782e7294b8b1d313851e8e4d13010359e4117cd71f80844,w104h74.jpg" /><br /> W Dąbrowie Górniczej (woj. śląskie) doszło do pożaru odpadów. Ogień najprawdopodobniej rozprzestrzenił się na terenie dzikiego wysypiska. Znowu przenoszenie śmieci do chmury.

## Talahon - tak nazywają siebie młodzi Arabowie w Niemczech
 - [https://wykop.pl/link/7513365/talahon-tak-nazywaja-siebie-mlodzi-arabowie-w-niemczech](https://wykop.pl/link/7513365/talahon-tak-nazywaja-siebie-mlodzi-arabowie-w-niemczech)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T13:38:22+00:00

<img src="https://wykop.pl/cdn/c3397993/852614ad83d4bd4a94cbdc2de1d2a05cf149ea9f5fce0d3e7c4f0f8a87e87de3,w104h74.jpg" /><br /> Piosenka rapera Hasana "Talahon" stała się hymnem nowej subkultury młodzieżowej w Niemczech. Kim są Talahoni i co łączy młodych Arabów żyjących w Europie? Czy ich wartości są zgodne z europejskimi standardami?

## Richard Dawkins zbanowany na Facebooku
 - [https://wykop.pl/link/7513357/richard-dawkins-zbanowany-na-facebooku](https://wykop.pl/link/7513357/richard-dawkins-zbanowany-na-facebooku)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T13:24:05+00:00

<img src="https://wykop.pl/cdn/c3397993/6a08432228144b9457ced647007066b3729af730035c3bc3775ca6e4803e0141.png" /><br /> Ośmielił się napisać, że transseksualni bokserzy nie powinni walczyć z kobietami na olimpiadzie.

## Reakcja propagandy na ukraińską ofensywę w obwodzie kurskim
 - [https://wykop.pl/link/7513349/reakcja-propagandy-na-ukrainska-ofensywe-w-obwodzie-kurskim](https://wykop.pl/link/7513349/reakcja-propagandy-na-ukrainska-ofensywe-w-obwodzie-kurskim)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T13:11:12+00:00

<img src="https://wykop.pl/cdn/c3397993/af49373e44aada25065f2e75d7f511becc71b652b3faa1e170e270a7698507c3,w104h74.jpg" /><br /> Zebrałam reakcje z rosyjskiej telewizji związane z sytuacją w obwodzie kurskim. Pod nieobecność Sołowjowa główne skrzypce gra Siergiej Mardan, w mojej opinii trochę bardziej kompetentny propagandysta. Pojawi się również Michaił Chodarionek, przedstawiciel medialny rosyjskiego Sztabu Generalnego.

## Groźny wypadek w Gdańsku. Pijana kobieta potrąciła 2 osoby
 - [https://wykop.pl/link/7513347/grozny-wypadek-w-gdansku-pijana-kobieta-potracila-2-osoby](https://wykop.pl/link/7513347/grozny-wypadek-w-gdansku-pijana-kobieta-potracila-2-osoby)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T13:09:28+00:00

<img src="https://wykop.pl/cdn/c3397993/f8a4d33a693060920f525d4d2451628a844aad20e140af25af20b7ec553bd9fd,w104h74.jpg" /><br /> Dwie osoby ranne - to bilans wypadku na al. Grunwaldzkiej w Gdańsku. Pijana kobieta potrąciła rowerzystę i pieszego, a potem auto uderzyło w budynek - poinformowała gdańska policja.

## SS-mani nie zdążyli ich zabić. Historia o Polaku, który uratował 4400 więźniów
 - [https://wykop.pl/link/7513335/ss-mani-nie-zdazyli-ich-zabic-historia-o-polaku-ktory-uratowal-4400-wiezniow](https://wykop.pl/link/7513335/ss-mani-nie-zdazyli-ich-zabic-historia-o-polaku-ktory-uratowal-4400-wiezniow)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T12:36:46+00:00

<img src="https://wykop.pl/cdn/c3397993/ad115a6c2936a07de835024186b8c318f2717f2781497be637cc42a38921d828,w104h74.jpg" /><br /> Józef Bellert w lutym 1945 r. zorganizował ochotniczy szpital niosący wsparcie dla ocalałych z obozu Auschwitz-Birkenau. W ten sposób, działając w skrajnie trudnych warunkach, uratował życie 4400 spośród 4800 pozostawionych przez Niemców więźniów

## Polscy siatkarze przegrali z Francją 0-3 w finale Igrzysk Olimpijskich w Paryżu
 - [https://wykop.pl/link/7513327/polscy-siatkarze-przegrali-z-francja-0-3-w-finale-igrzysk-olimpijskich-w-paryzu](https://wykop.pl/link/7513327/polscy-siatkarze-przegrali-z-francja-0-3-w-finale-igrzysk-olimpijskich-w-paryzu)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T12:24:47+00:00

<img src="https://wykop.pl/cdn/c3397993/76bbe1e72bc225ac8662b813d29a7110c294f931c845094bc6546f96fe672c0e,w104h74.jpg" /><br /> Polscy siatkarze przegrali z Francją 0-3 (19-25, 20-25, 23-25) w finale Igrzysk Olimpijskich w Paryżu, zdobywając tym samym srebrny medal.

## Kiedyś to robili reklamy xD
 - [https://wykop.pl/link/7513315/kiedys-to-robili-reklamy-xd](https://wykop.pl/link/7513315/kiedys-to-robili-reklamy-xd)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T12:07:09+00:00

<img src="https://wykop.pl/cdn/c3397993/0c8548e523498549544c530982f1a2e5f2845f299d218219546eb1b4ad28eebe,w104h74.jpg" /><br /> Eee... co ja właśnie obejrzałem?

## Dariusz Szpakowski on X: "Są granice dobrego smaku! Są granice pogoni za...
 - [https://wykop.pl/link/7513311/dariusz-szpakowski-on-x-sa-granice-dobrego-smaku-sa-granice-pogoni-za](https://wykop.pl/link/7513311/dariusz-szpakowski-on-x-sa-granice-dobrego-smaku-sa-granice-pogoni-za)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T12:04:17+00:00

<img src="https://wykop.pl/cdn/c3397993/de512f6a4f26ebd9578dfed15c15f3806ec81cb3af6642e7ea82e03cbe3ac107.png" /><br /> Ciekawe co na to dyrektor TVP Sport Kuba Kwiatkowski...

## Wielka Brytania wycofuje ustawę gwarantującą wolność słowa na uniwersytetach
 - [https://wykop.pl/link/7513309/wielka-brytania-wycofuje-ustawe-gwarantujaca-wolnosc-slowa-na-uniwersytetach](https://wykop.pl/link/7513309/wielka-brytania-wycofuje-ustawe-gwarantujaca-wolnosc-slowa-na-uniwersytetach)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T12:04:15+00:00

<img src="https://wykop.pl/cdn/c3397993/208c86da19b375181ee40c2770c25073e5668f1d35cb1d7933fda779e4215365,w104h74.jpg" /><br /> Ustawa przyjęta przez poprzedni rząd nakazywała wyższym uczelniom pilnowanie standardów wolności wypowiedzi. Miała też utrudniać organizowanie nagonki na nieprawomyślnych wykładowców. Lewicowe władze zablokowały jednak wejście prawa w życie.

## Reporter "Panoramy" odsunięty za wpisy w internecie, w tym o rządzących
 - [https://wykop.pl/link/7513297/reporter-panoramy-odsuniety-za-wpisy-w-internecie-w-tym-o-rzadzacych](https://wykop.pl/link/7513297/reporter-panoramy-odsuniety-za-wpisy-w-internecie-w-tym-o-rzadzacych)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T11:53:01+00:00

<img src="https://wykop.pl/cdn/c3397993/49869a51ca4ea64367f788cad3a0a95b66b022d223214dcd454cc616582159ae,w104h74.jpg" /><br /> Reporter "Panoramy" TVP 2 Bartłomiej Bublewicz został zawieszony w obowiązkach za wpisy w mediach społecznościowych, w których m.in. krytykował rządzących - ustalił "Presserwis". Zdaniem Komisji Etyki TVP dziennikarz naruszył zasady etyki obowiązujące w spółce.

## AIRBNB dlaczego oszuści mogą oszukiwać regularnie, a AirCover to ściema
 - [https://wykop.pl/link/7513291/airbnb-dlaczego-oszusci-moga-oszukiwac-regularnie-a-aircover-to-sciema](https://wykop.pl/link/7513291/airbnb-dlaczego-oszusci-moga-oszukiwac-regularnie-a-aircover-to-sciema)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T11:43:38+00:00

<img src="https://wykop.pl/cdn/c3397993/afc12bd97b96053322e0af401890d81196415dc4dc69bb619911dc6c5873cbb2,w104h74.jpg" /><br /> Wielu z was korzysta z Airbnb -i myśli, że kupując wakacje tam ma pewność, że nie wyląduje na lodzie. Przedstawię wam swoją sytuacje, która pokazuje, że wcale tak nie jest.

## Specjalny wysłannnik ONZ oskarża Izrael o ludobójstwo
 - [https://wykop.pl/link/7513263/specjalny-wyslannnik-onz-oskarza-izrael-o-ludobojstwo](https://wykop.pl/link/7513263/specjalny-wyslannnik-onz-oskarza-izrael-o-ludobojstwo)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T11:04:42+00:00

<img src="https://wykop.pl/cdn/c3397993/5b233b270ca9c62fb6105154e2fe8b8519684e40a1d598b972749faa0e0d213f,w104h74.jpg" /><br /> 18+ "Gaza: W największym i najbardziej haniebnym obozie koncentracyjnym XXI wieku, Izrael dokonuje ludobójstwa na Palestyńczykach: dzielnica za dzielnicą, szpital za szpitalem, szkoła za szkołą.." - Francesca Albanese, Specjalny Wysłannik ONZ na palestyńskie terytoria okupowane.

## Niesprwokowany Afroamerykanin dźga i morduje.
 - [https://wykop.pl/link/7513255/niesprwokowany-afroamerykanin-dzga-i-morduje](https://wykop.pl/link/7513255/niesprwokowany-afroamerykanin-dzga-i-morduje)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T10:57:42+00:00

<img src="https://wykop.pl/cdn/c3397993/a143cb2977b7c7535fb0cfcea968b3c61d41177821f14714401e4a916fd95c60,w104h74.jpg" /><br /> Stan Pana z filmu jest stabilny, natomiast napastnik wyszedł i zamordował innego człowieka.

## Kaczyński nie wytrzymał na miesięcznicy: "Putinowska szmato!"
 - [https://wykop.pl/link/7513227/kaczynski-nie-wytrzymal-na-miesiecznicy-putinowska-szmato](https://wykop.pl/link/7513227/kaczynski-nie-wytrzymal-na-miesiecznicy-putinowska-szmato)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T10:24:49+00:00

<img src="https://wykop.pl/cdn/c3397993/97fcf075a2e55ff50a7454c9b09a2040acf930d05c9f9c5fb714fbde156c8c99,w104h74.jpg" /><br /> Jarosławowi Kaczyńskiemu puszczają nerwy. Dziś jak co miesiąc pojawił się przed Pomnikiem Ofiar Tragedii Smoleńskiej 2010 roku i z jego ust padło: "Ty putinowska szmato". Wulgarność, buta, chamstwo, to wieloletnia praktyka polityków PiS…

## Łukaszenka oskarża Ukrainę o naruszenie przestrzeni powietrznej Białorusi
 - [https://wykop.pl/link/7513223/lukaszenka-oskarza-ukraine-o-naruszenie-przestrzeni-powietrznej-bialorusi](https://wykop.pl/link/7513223/lukaszenka-oskarza-ukraine-o-naruszenie-przestrzeni-powietrznej-bialorusi)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T10:14:50+00:00

<img src="https://wykop.pl/cdn/c3397993/13ab6493744db642fdaaebb18f63baa1e3983dcc6b195d05dd4859b45be6fadc,w104h74.jpg" /><br /> Aleksander Łukaszenka twierdzi, że Ukraina dopuściła się naruszenia przestrzeni powietrznej Białorusi. Prezydent zaznacza, że incydent ten to wynik działań Kijowa. Czy to kolejny etap eskalacji napięć na linii Mińsk-Kijów?

## Ukraińcy i Gruzini wkroczyli do obwodu Biełogrodzkiego!
 - [https://wykop.pl/link/7513203/ukraincy-i-gruzini-wkroczyli-do-obwodu-bielogrodzkiego](https://wykop.pl/link/7513203/ukraincy-i-gruzini-wkroczyli-do-obwodu-bielogrodzkiego)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T09:50:18+00:00

<img src="https://wykop.pl/cdn/c3397993/47ad771aa2a0c406b5a8f008ff45091d3ae60aa70c65ce435540edfc49c0811e,w104h74.jpg" /><br /> Opis musi być

## Rosjanie pilnie skontaktowali się MAEA. Elektrownia Atomowa Kursk zagrożona?
 - [https://wykop.pl/link/7513201/rosjanie-pilnie-skontaktowali-sie-maea-elektrownia-atomowa-kursk-zagrozona](https://wykop.pl/link/7513201/rosjanie-pilnie-skontaktowali-sie-maea-elektrownia-atomowa-kursk-zagrozona)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T09:46:05+00:00

<img src="https://wykop.pl/cdn/c3397993/0bb8b45c09cbc23956da462d4983b6cdddbe7f0393c8ff0cde020fff002c307d,w104h74.jpg" /><br /> Aleksiej Lichaczow szef rosyjskiej agencji energii atomowej ROSATOM twierdzi, że ukraiński atak w obwodzie kurskim zagraża bezpieczeństwu Elektrowni Atomowej Kursk. Lichaczow miał rozmawiać w tej sprawie z Rafaelem Grossim, który szefuje Międzynarodowej Agencji Energii Atomowej (MAEA).

## Tego się nie spodziewałem
 - [https://wykop.pl/link/7513181/tego-sie-nie-spodziewalem](https://wykop.pl/link/7513181/tego-sie-nie-spodziewalem)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T09:25:05+00:00

<img src="https://wykop.pl/cdn/c3397993/335fd8c5319f6fddd45c713c015b14a11663f43a825170500086fdfb25b399e3,w104h74.jpg" /><br /> Myślisz że chodzi o kolejnego murzyna defekujacego w miejscu publicznym? Otóż nic bardziej mylnego!

## Poparcie dla wprowadzenia euro w Polsce coraz mniejsze
 - [https://wykop.pl/link/7513171/poparcie-dla-wprowadzenia-euro-w-polsce-coraz-mniejsze](https://wykop.pl/link/7513171/poparcie-dla-wprowadzenia-euro-w-polsce-coraz-mniejsze)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T09:14:12+00:00

<img src="https://wykop.pl/cdn/c3397993/553b3c7c6cd4c8c66baeefc6022b082c62c22a448e0f87bfb8c87c50543210ab,w104h74.jpg" /><br /> Poparcie dla wprowadzenia "za kilka lat" europejskiej waluty w Polsce wynosi obecnie 30,7 proc., co stanowi spadek z 34,9 proc. rok do roku - wynika z badania zrealizowanego na zlecenie Fundacji Wolności Gospodarczej. Jak zaznaczono, silny spadek poparcia miał miejsce wśród kobiet.

## Kto zatruł Dzierżno Duże?
 - [https://wykop.pl/link/7513159/kto-zatrul-dzierzno-duze](https://wykop.pl/link/7513159/kto-zatrul-dzierzno-duze)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T08:56:18+00:00

D D. To ogromny zbiornik zaporowy z wędkarska strefą "NO KILL". Rekordowe karpie, Leszcze i szczupaki właśnie zdychają. A w mediach cisza... NAGŁAŚNIAMY

## "Testy płci" w sporcie [Naukowy Bełkot nie ma racji]
 - [https://wykop.pl/link/7513137/testy-plci-w-sporcie-naukowy-belkot-nie-ma-racji](https://wykop.pl/link/7513137/testy-plci-w-sporcie-naukowy-belkot-nie-ma-racji)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T08:48:50+00:00

<img src="https://wykop.pl/cdn/c3397993/4a9a660aad78881b0f2220b0a808265e086f815e2b5be6e2085ef4b78cfc5426,w104h74.jpg" /><br /> Kilka dni temu na kanale @naukowy.belkot pojawił się materiał poświęcony testom płci w sporcie. Niestety autor materiału myli się w kilku kluczowych kwestiach. Korzystam z jego zaproszenia do dyskusji i w tym filmie dzielę się szerszym komentarzem dotyczącym dwóch kontrowersyjnych bokserek.

## Nietrzeźwy Ukrainiec uciekał przed Policją, jechał pod prąd na czołówkę
 - [https://wykop.pl/link/7513091/nietrzezwy-ukrainiec-uciekal-przed-policja-jechal-pod-prad-na-czolowke](https://wykop.pl/link/7513091/nietrzezwy-ukrainiec-uciekal-przed-policja-jechal-pod-prad-na-czolowke)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T08:06:13+00:00

<img src="https://wykop.pl/cdn/c3397993/e4453b1da5c52852ec0b3134fac65bdfa46daee454c26e69e17d3fa8e779f2ef.png" /><br /> Swoim samochodem kilkukrotnie uderzał w policyjne auta, gdy te go doganiały. Kierujący oplem mimo to ze znaczną prędkością jechał wprost na nadjeżdżające pojazdy, stwarzając duże zagrożenie dla zdrowia i życia postronnych osób.

## Irak chce zezwolić na śluby z 9-letnimi dziewczynkami
 - [https://wykop.pl/link/7513031/irak-chce-zezwolic-na-sluby-z-9-letnimi-dziewczynkami](https://wykop.pl/link/7513031/irak-chce-zezwolic-na-sluby-z-9-letnimi-dziewczynkami)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T06:55:34+00:00

<img src="https://wykop.pl/cdn/c3397993/2c9ce420ae7deeedf8bffdb2081ea77185b62b228fa7219fc2e19ec3299c7b03,w104h74.jpg" /><br /> W Bagdadzie oraz innych irackich miastach miały miejsce demonstracje przeciwko proponowanej ustawie, która między innymi umożliwia zawieranie małżeństw z dziewięcioletnimi dziewczynkami.

## Atak w Strefie Gazy. Mogło zginąć co najmniej 100 osób
 - [https://wykop.pl/link/7512995/atak-w-strefie-gazy-moglo-zginac-co-najmniej-100-osob](https://wykop.pl/link/7512995/atak-w-strefie-gazy-moglo-zginac-co-najmniej-100-osob)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T06:17:15+00:00

<img src="https://wykop.pl/cdn/c3397993/5ca53331b2bed177ae4dcee7f8fa88a33cadf03093e6a799d4ac808cccc12ced,w104h74.jpg" /><br /> Co najmniej 100 osób zginęło w wyniku izraelskiego ataku na budynek szkoły w Strefie Gazy - informują irańskie media. Znajdował się w nim punkt dowodzenia organizacji terrorystycznej Hamas.

## Susan Wójcicki była CEO YouTube zmarła w wieku 56 lat
 - [https://wykop.pl/link/7512977/susan-wojcicki-byla-ceo-youtube-zmarla-w-wieku-56-lat](https://wykop.pl/link/7512977/susan-wojcicki-byla-ceo-youtube-zmarla-w-wieku-56-lat)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T05:58:33+00:00

<img src="https://wykop.pl/cdn/c3397993/35b8f7ee867b5eaaa72a396cebefdf65f795ccc115c02f0b9ab6f1c70c45eb0f,w104h74.jpg" /><br /> Susan Wójcicki- była CEO YouTube zmarła po 2-letniej walce z rakiem. O zmarłych dobrze albo wcale, więc lepiej jej nie komentować. Tak przy okazji - wiedzieliście, że jej siostra była żona założyciela google? Ciekawe są losy polskich emigrantów.

## Duże modele językowe jak ChatGPT mają lewicowe poglądy
 - [https://wykop.pl/link/7512937/duze-modele-jezykowe-jak-chatgpt-maja-lewicowe-poglady](https://wykop.pl/link/7512937/duze-modele-jezykowe-jak-chatgpt-maja-lewicowe-poglady)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-08-10T03:47:41+00:00

<img src="https://wykop.pl/cdn/c3397993/9ced7befb12922bbbafd46a7647ad5de3abe045e329c2a5dcf0da1093994dc3a,w104h74.jpg" /><br /> Większość dużych modeli językowych (LLM), systemów sztucznej inteligencji takich jak ChatGPT, wykazuje odchylenie w lewą

