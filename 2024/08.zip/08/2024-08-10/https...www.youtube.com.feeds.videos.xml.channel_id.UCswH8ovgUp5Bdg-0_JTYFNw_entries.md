# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Joe Rogan Makes Guest Go Silent With This Kamala Prediction
 - [https://www.youtube.com/watch?v=XgWIEDLIUG0](https://www.youtube.com/watch?v=XgWIEDLIUG0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-08-10T17:07:25+00:00

Wake up everyday and choose freedom, order at https://1775coffee.com/BRAND

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

EXCLUSIVE Content HERE: https://bit.ly/joinlocals

All links: https://linktr.ee/RussellBrand

