# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Tak ogląda się główny program Stanowskiego. Zauważalna zmiana
 - [https://www.wirtualnemedia.pl/artykul/krzysztof-stanowski-kanal-zero-dziennikarskie-zero-program-format-2](https://www.wirtualnemedia.pl/artykul/krzysztof-stanowski-kanal-zero-dziennikarskie-zero-program-format-2)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-08-10T19:55:00+00:00

Krzysztof Stanowski przenosząc do Kanału Zero swój flagowy format „Dziennikarskie Zero” notuje lepsze wyniki niż wcześniej w Kanale Sportowym, choć do najpopularniejszego materiału o Natalii Janoszek jeszcze sporo brakuje.

## Nie żyje była szefowa YouTube’a. Przegrała z nowotworem
 - [https://www.wirtualnemedia.pl/artykul/susan-wojcicki-zmarla-choroba-szefowa-youtube-google](https://www.wirtualnemedia.pl/artykul/susan-wojcicki-zmarla-choroba-szefowa-youtube-google)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-08-10T19:11:00+00:00

W wieku 56 lat zmarła Susan Wojcicki, była dyrektorka generalna serwisu internetowego YouTube – poinformował w sobotę szef firmy Google Sundar Pichai. Wojcicki, którą tygodnik "Time" uznał za "najbardziej wpływową kobietę w internecie", miała polskie obywatelstwo.

