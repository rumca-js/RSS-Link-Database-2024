# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## Wilko parent does not expect to plug collapsed chain’s estimated £70mn pension hole
 - [https://www.ft.com/content/c0d83491-6a26-40f2-81d1-3804ee2bb64b](https://www.ft.com/content/c0d83491-6a26-40f2-81d1-3804ee2bb64b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-08-10T12:00:27+00:00

Ultimate owner of discount brand, whose directors include its former chair, argues it is off the hook for liabilities

## How Paris lit India’s Olympic dream
 - [https://www.ft.com/content/6c4c9a51-7b20-4ea0-90b3-3d636387de60](https://www.ft.com/content/6c4c9a51-7b20-4ea0-90b3-3d636387de60)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-08-10T08:00:26+00:00

Plus, the cash, sneakers and condos for medallists

## Bharti Kher, Yorkshire Sculpture Park — magical transformations of glass into gold
 - [https://www.ft.com/content/967e6224-7e0e-4541-8061-c2be351aeedc](https://www.ft.com/content/967e6224-7e0e-4541-8061-c2be351aeedc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-08-10T04:00:27+00:00

The British-Indian artist draws on politics, religious traditions and her cultural heritage to make works of subtle power

## How are judges dealing with England’s rioters?
 - [https://www.ft.com/content/1b2b42c4-7476-44ef-8355-78dd1f6c7f37](https://www.ft.com/content/1b2b42c4-7476-44ef-8355-78dd1f6c7f37)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-08-10T03:00:26+00:00

Fast-track hearings have led to more than 30 individuals appearing in Crown Court so far as prosecutors bring range of charges

