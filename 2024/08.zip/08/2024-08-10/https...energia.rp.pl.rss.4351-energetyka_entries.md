# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Obawy o produkcję baterii w Polsce i apel o zmiany
 - [https://energia.rp.pl/elektroenergetyka/art40948171-obawy-o-produkcje-baterii-w-polsce-i-apel-o-zmiany](https://energia.rp.pl/elektroenergetyka/art40948171-obawy-o-produkcje-baterii-w-polsce-i-apel-o-zmiany)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-08-10T13:05:27+00:00

Komisja Europejska jest w trakcie prac nad 40 aktami wykonawczymi do przyjętego przez Radę i Parlament Europejski rozporządzenia z 2023 r. w sprawie baterii i zużytych baterii. Nowy sposób liczenia śladu węglowego może uderzyć w takie kraje jak Polska. Producenci baterii już działający w Polsce apelują o odejście od tej niekorzystnej propozycji.

## Działania wojenne coraz bliżej elektrowni atomowej. Szef MAEA apeluje o maksymalną powściągliwość
 - [https://energia.rp.pl/atom/art40948791-dzialania-wojenne-coraz-blizej-elektrowni-atomowej-szef-maea-apeluje-o-maksymalna-powsciagliwosc](https://energia.rp.pl/atom/art40948791-dzialania-wojenne-coraz-blizej-elektrowni-atomowej-szef-maea-apeluje-o-maksymalna-powsciagliwosc)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-08-10T12:32:12+00:00

Szef Międzynarodowej Agencji Energii Atomowej Rafael Grossi wezwał Rosję i Ukrainę do zachowania "maksymalnej powściągliwości" w walkach toczących się w rejonie, w którym zlokalizowana jest Kurska Elektrownia Atomowa.

## Wyniki Orlenu w cieniu mrożeniu cen energii i gazu
 - [https://energia.rp.pl/energetyka-zawodowa/art40948161-wyniki-orlenu-w-cieniu-mrozeniu-cen-energii-i-gazu](https://energia.rp.pl/energetyka-zawodowa/art40948161-wyniki-orlenu-w-cieniu-mrozeniu-cen-energii-i-gazu)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-08-10T11:27:00+00:00

Orlen szacuje, że EBITDA grupy z uwzględnieniem odpisów aktualizujących wartość majątku w II kw. 2024 r. wyniesie ok. 4,54 mld zł. Po eliminacji odpisów aktualizujących wartość majątku wyniesie ok. 5 mld zł. Po odjęciu zaś wpływu opłat na rzecz mrożenia cen energii i gazu w I półroczu, wynik ten wyniesie 11,3 mld zł.

