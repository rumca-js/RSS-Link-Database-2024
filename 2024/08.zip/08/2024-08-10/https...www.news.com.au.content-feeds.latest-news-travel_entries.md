# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## Mysterious island holds dark secrets
 - [https://www.news.com.au/travel/travel-updates/travel-stories/mysterious-island-holds-dark-secrets/news-story/4e0b59323ff6d1cc78bc2c11585ba008?from=rss-basic](https://www.news.com.au/travel/travel-updates/travel-stories/mysterious-island-holds-dark-secrets/news-story/4e0b59323ff6d1cc78bc2c11585ba008?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-08-10T23:07:31.892998+00:00

A mysterious island with a dark history has been deemed too dangerous for anyone to visit for one horrifying reason.

