# Source:Tehran Times, URL:https://www.tehrantimes.com/rss, language:en-US

## Iran taekwondo athlete Salimi wins gold: 2024 Paris
 - [https://www.tehrantimes.com/news/502276/Iran-taekwondo-athlete-Salimi-wins-gold-2024-Paris](https://www.tehrantimes.com/news/502276/Iran-taekwondo-athlete-Salimi-wins-gold-2024-Paris)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T20:15:17+00:00

TEHRAN – Taekwondo athlete Arian Salimi of Iran claimed a gold medal  in the 2024 Olympic Games Saturday night.

## Iran freestyler Zare collects silver in 2024 Olympics
 - [https://www.tehrantimes.com/news/502247/Iran-freestyler-Zare-collects-silver-in-2024-Olympics](https://www.tehrantimes.com/news/502247/Iran-freestyler-Zare-collects-silver-in-2024-Olympics)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T19:01:00+00:00

TEHRAN – Iranian freestyle wrestler Amirhossein Zare lost to Georgian Geno Petriashvili in the men’s 125kg final of the 2024 Olympic Games Saturday night.

## American trick to save Israel from revenge
 - [https://www.tehrantimes.com/news/502264/American-trick-to-save-Israel-from-revenge](https://www.tehrantimes.com/news/502264/American-trick-to-save-Israel-from-revenge)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:53:45+00:00

TEHRAN - In a note, the Iran newspaper addressed the resumption of the ceasefire talks hosted by Cairo and with the mediation of the U.S., Qatar, and Egypt.

## Tehran to deliver strong response to Israeli crimes: official
 - [https://www.tehrantimes.com/news/502266/Tehran-to-deliver-strong-response-to-Israeli-crimes-official](https://www.tehrantimes.com/news/502266/Tehran-to-deliver-strong-response-to-Israeli-crimes-official)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:52:56+00:00

TEHRAN – A former commander of Iran’s Islamic Revolution Guard Corps (IRGC) says Iran is prepared to deliver a powerful response to the malicious actions of the Zionist regime.

## Pezeshkian congratulates Singapore on National Day
 - [https://www.tehrantimes.com/news/502263/Pezeshkian-congratulates-Singapore-on-National-Day](https://www.tehrantimes.com/news/502263/Pezeshkian-congratulates-Singapore-on-National-Day)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:52:38+00:00

TEHRAN – Iranian President Masoud Pezeshkian has congratulated the people and government of Singapore on the country’s National Day.

## Haniyeh’s assassination aimed to sow division among Muslims: commander
 - [https://www.tehrantimes.com/news/502261/Haniyeh-s-assassination-aimed-to-sow-division-among-Muslims](https://www.tehrantimes.com/news/502261/Haniyeh-s-assassination-aimed-to-sow-division-among-Muslims)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:52:11+00:00

TEHRAN- The spokesman and deputy head of the public relations office of the Islamic Revolution Guards Corps (IRGC) stated that the Israeli regime assassinated the Hamas leader to create a rift among Shia and Sunni Muslims.

## Retaliatory action for Haniyeh’s killing independent from Gaza truce talks: Iran UN mission
 - [https://www.tehrantimes.com/news/502258/Retaliatory-action-for-Haniyeh-s-killing-independent-from-Gaza](https://www.tehrantimes.com/news/502258/Retaliatory-action-for-Haniyeh-s-killing-independent-from-Gaza)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:51:38+00:00

TEHRAN – Iran's permanent mission to the United Nations has asserted that a retaliatory response to the Israeli assassination of former Hamas chief Ismail Haniyeh in Tehran is inevitable, regardless of ongoing ceasefire talks in Gaza.

## Iran expresses support for the interim government in Bangladesh
 - [https://www.tehrantimes.com/news/502260/Iran-expresses-support-for-the-interim-government-in-Bangladesh](https://www.tehrantimes.com/news/502260/Iran-expresses-support-for-the-interim-government-in-Bangladesh)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:51:00+00:00

TEHRAN- The spokesman for Iran’s Ministry of Foreign Affairs welcomed the formation of an interim government in Bangladesh headed by Muhammad Yunus.

## Iranian clerics reaffirm support for Resistance Front
 - [https://www.tehrantimes.com/news/502267/Iranian-clerics-reaffirm-support-for-Resistance-Front](https://www.tehrantimes.com/news/502267/Iranian-clerics-reaffirm-support-for-Resistance-Front)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:50:22+00:00

TEHRAN – A senior Iranian cleric has reaffirmed the steadfast support of the Iranian clergy and religious seminaries for Hezbollah and the broader Resistance Front.

## Iranian officials united on retaliation against Israel: source
 - [https://www.tehrantimes.com/news/502265/Iranian-officials-united-on-retaliation-against-Israel-source](https://www.tehrantimes.com/news/502265/Iranian-officials-united-on-retaliation-against-Israel-source)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:49:38+00:00

TEHRAN – An informed source has firmly denied any internal disagreements among Iran's top leadership regarding the response to Israel following the assassination of Ismail Haniyeh, a key Palestinian Resistance movement figure in Hamas, in Tehran.

## Pezeshkian retains Atomic Energy chief, appoints key cabinet members
 - [https://www.tehrantimes.com/news/502259/Pezeshkian-retains-Atomic-Energy-chief-appoints-key-cabinet](https://www.tehrantimes.com/news/502259/Pezeshkian-retains-Atomic-Energy-chief-appoints-key-cabinet)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:48:29+00:00

TEHRAN - Iran's newly inaugurated President Masoud Pezeshkian has retained Mohammad Eslami as the head of the Atomic Energy Organization of Iran (AEOI), a key position in the country's nuclear program Eslami has been holding since he was first appointed by the late President Ebrahim Raisi in 2021.

## Leader’s aide says ‘severe and crushing’ response to Israel ready
 - [https://www.tehrantimes.com/news/502257/Leader-s-aide-says-severe-and-crushing-response-to-Israel-ready](https://www.tehrantimes.com/news/502257/Leader-s-aide-says-severe-and-crushing-response-to-Israel-ready)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:46:12+00:00

TEHRAN– Iran has completed “legal, diplomatic, and media” preparations to carry out “severe and crushing” retaliation against Israel for the assassination of former Hamas chief Ismail Haniyeh, declared Ali Shamkhani, a political advisor to the Leader of the Islamic Revolution and ex-secretary of Iran’s National Security Council.

## Iranian president calls for international action against Israel after Gaza school massacre
 - [https://www.tehrantimes.com/news/502275/Iranian-president-calls-for-international-action-against-Israel](https://www.tehrantimes.com/news/502275/Iranian-president-calls-for-international-action-against-Israel)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:44:14+00:00

TEHRAN - Iranian President Masoud Pezeshkian has condemned the massacre of al-Tabin School in the Gaza Strip, calling for swift action by the international community and the United Nations to prevent such atrocities by the Israeli regime.

## Global outrage erupts after Israel's deadly strike on Gaza school
 - [https://www.tehrantimes.com/news/502256/Global-outrage-erupts-after-Israel-s-deadly-strike-on-Gaza-school](https://www.tehrantimes.com/news/502256/Global-outrage-erupts-after-Israel-s-deadly-strike-on-Gaza-school)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:35:54+00:00

TEHRAN - Israel’s brutal attack on a Gaza City school housing displaced Palestinians has sparked widespread outrage and condemnation across the world.

## 14840
 - [https://www.tehrantimes.com/news/502274/14840](https://www.tehrantimes.com/news/502274/14840)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:34:48+00:00



## Every 70 kg counts as one person
 - [https://www.tehrantimes.com/news/502255/Every-70-kg-counts-as-one-person](https://www.tehrantimes.com/news/502255/Every-70-kg-counts-as-one-person)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:31:22+00:00

TEHRAN - A new Israeli massacre on a school in Gaza sheltering the displaced Palestinians has raised major question marks over Tel Aviv’s lack of desire for any ceasefire in the enclave.

## Veteran actor, Tazieh reciter Fathollah Taheri passes away
 - [https://www.tehrantimes.com/news/502269/Veteran-actor-Tazieh-reciter-Fathollah-Taheri-passes-away](https://www.tehrantimes.com/news/502269/Veteran-actor-Tazieh-reciter-Fathollah-Taheri-passes-away)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:29:00+00:00

TEHRAN-The veteran Iranian actor and Tazieh reciter Fathollah Taheri passed away on Friday, August 9, at the age of 73.

## Iranshahr Theater to host Albert Camus’ “Caligula”
 - [https://www.tehrantimes.com/news/502270/Iranshahr-Theater-to-host-Albert-Camus-Caligula](https://www.tehrantimes.com/news/502270/Iranshahr-Theater-to-host-Albert-Camus-Caligula)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:28:29+00:00

TEHRAN-The play “Caligula” written by Albert Camus will go on stage at Iranshahr Theater Complex in Tehran from August 18.

## Book on strategies for success in age of AI and automation available in Persian
 - [https://www.tehrantimes.com/news/502271/Book-on-strategies-for-success-in-age-of-AI-and-automation-available](https://www.tehrantimes.com/news/502271/Book-on-strategies-for-success-in-age-of-AI-and-automation-available)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:28:07+00:00

TEHRAN-The Persian translation of the book “Dancing With Robots” by Bill Bishop has hit the bookstores across the country.

## It’s time to refer a case against the USA to the ICJ and ICC
 - [https://www.tehrantimes.com/news/502273/It-s-time-to-refer-a-case-against-the-USA-to-the-ICJ-and-ICC](https://www.tehrantimes.com/news/502273/It-s-time-to-refer-a-case-against-the-USA-to-the-ICJ-and-ICC)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:25:59+00:00

On August 7, Türkiye (or Turkey) showed courage and stood up for humanity. It became the seventh country asking to join the case that South Africa brought against Israel for ‘genocide’ on December 29, 2023 at the International Court of Justice (ICJ), the United Nations’ highest court.

## Hezbollah ramps up rocket, drone attacks on Israel
 - [https://www.tehrantimes.com/news/502268/Hezbollah-ramps-up-rocket-drone-attacks-on-Israel](https://www.tehrantimes.com/news/502268/Hezbollah-ramps-up-rocket-drone-attacks-on-Israel)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:04:53+00:00

TEHRAN - Lebanon’s Hezbollah resistance movement carried out fresh strikes against Israeli sites and settlements late on Saturday.

## Iran-Brazil cinematic collaboration spurs carpet export boom, official says
 - [https://www.tehrantimes.com/news/502245/Iran-Brazil-cinematic-collaboration-spurs-carpet-export-boom](https://www.tehrantimes.com/news/502245/Iran-Brazil-cinematic-collaboration-spurs-carpet-export-boom)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T18:02:56+00:00

TEHRAN- The screening of joint cinematic productions from Iran and Brazil has increased the export of Iranian handwoven carpets to Brazil, the Head of the Iran-Brazil Joint Chamber of Commerce has announced.

## Intl. Silk Road rallyists set foot in Tehran
 - [https://www.tehrantimes.com/news/502248/Intl-Silk-Road-rallyists-set-foot-in-Tehran](https://www.tehrantimes.com/news/502248/Intl-Silk-Road-rallyists-set-foot-in-Tehran)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T14:46:00+00:00

TEHRAN – The second international Silk Road rally, currently traversing the route from Türkiye to Mongolia, has reached Tehran, the capital of Iran, after passing through several provinces.

## Kordestan puts sports tourism on agenda
 - [https://www.tehrantimes.com/news/502249/Kordestan-puts-sports-tourism-on-agenda](https://www.tehrantimes.com/news/502249/Kordestan-puts-sports-tourism-on-agenda)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T14:45:52+00:00

TEHRAN - Kordestan has the potential to become a hub for sports tourism through arranging athletic events, according to governor-general.

## Eastern Iranian villages nominated for UNESCO label
 - [https://www.tehrantimes.com/news/502254/Eastern-Iranian-villages-nominated-for-UNESCO-label](https://www.tehrantimes.com/news/502254/Eastern-Iranian-villages-nominated-for-UNESCO-label)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T14:45:43+00:00

TEHRAN – Three villages in Iran’s South Khorasan Province have been selected to vie with other candidates for UNESCO’s “Best Tourism Villages” in 2025.

## Navasard festival celebrates Iran-Armenia cultural ties
 - [https://www.tehrantimes.com/news/502250/Navasard-festival-celebrates-Iran-Armenia-cultural-ties](https://www.tehrantimes.com/news/502250/Navasard-festival-celebrates-Iran-Armenia-cultural-ties)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T14:45:21+00:00

TEHRAN - The third Navasard Festival, a vibrant celebration of the cultural and culinary ties between Iran and Armenia, commenced in Armenia's Sisian region on Saturday, marking a symbol of the longstanding friendship between the two nations.

## Semnan, where desert meets forest on the ancient Silk Road
 - [https://www.tehrantimes.com/news/502253/Semnan-where-desert-meets-forest-on-the-ancient-Silk-Road](https://www.tehrantimes.com/news/502253/Semnan-where-desert-meets-forest-on-the-ancient-Silk-Road)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T14:44:46+00:00

TEHRAN - Semnan province, located in northern Iran, is a region of remarkable geographical diversity, offering a unique blend of natural landscapes, historical landmarks, and cultural elements.

## Documentary “Noqte” on Iranian calligraphy premieres on TV BRICS
 - [https://www.tehrantimes.com/news/502244/Documentary-Noqte-on-Iranian-calligraphy-premieres-on-TV-BRICS](https://www.tehrantimes.com/news/502244/Documentary-Noqte-on-Iranian-calligraphy-premieres-on-TV-BRICS)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T13:52:55+00:00

TEHRAN- The documentary film "Noqte," which explores the art of Iranian calligraphy, is set to have its world premiere in Russia, presented by the TV BRICS International Media Network. This unveiling marks a significant milestone, as the film will reach audiences across the BRICS+ countries.

## Iran men’s sitting volleyball team named for 2024 Paralympics
 - [https://www.tehrantimes.com/news/502231/Iran-men-s-sitting-volleyball-team-named-for-2024-Paralympics](https://www.tehrantimes.com/news/502231/Iran-men-s-sitting-volleyball-team-named-for-2024-Paralympics)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T13:24:03+00:00

TEHRAN – Iran men’s sitting volleyball team head coach Hadi Rezaei announced his 12-player squad for the 2024 Paralympic Games in Paris.

## Police dismantle drug trafficking gang in southeast
 - [https://www.tehrantimes.com/news/502243/Police-dismantle-drug-trafficking-gang-in-southeast](https://www.tehrantimes.com/news/502243/Police-dismantle-drug-trafficking-gang-in-southeast)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-08-10T13:08:12+00:00

TEHRAN – The anti-narcotics police have disbanded a drug trafficking gang in Saravan county, southeastern Sistan-Baluchestan province, Ahmad-Ali Goudarzi, Commander of the Border Police, has stated.

