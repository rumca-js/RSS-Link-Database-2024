# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## New Zealand's Ko completes Olympic medal set with women's golf gold
 - [https://japantoday.com/category/paris-2024-olympics/new-zealand%27s-ko-completes-olympic-medal-set-with-women%27s-golf-gold](https://japantoday.com/category/paris-2024-olympics/new-zealand%27s-ko-completes-olympic-medal-set-with-women%27s-golf-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:08:25+00:00

New Zealander Lydia Ko completed the set of Olympic golf medals on Saturday after battling to a two-shot victory at Le Golf National during a tense final round…

## Portugal win first-ever Olympic track cycling gold
 - [https://japantoday.com/category/paris-2024-olympics/portugal-win-first-ever-olympic-track-cycling-gold](https://japantoday.com/category/paris-2024-olympics/portugal-win-first-ever-olympic-track-cycling-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:07:52+00:00

Portugal won its first-ever Olympic track cycling gold on Saturday after Iuri Leitao and Rui Oliveira surged from nowhere to win a chaotic men's madison littered with crashes.…

## U.S. women's water polo team going home empty-handed after a rough finish to Paris Olympics
 - [https://japantoday.com/category/paris-2024-olympics/us-women%27s-water-polo-team-going-home-empty-handed-after-a-rough-finish-to-paris-olympics](https://japantoday.com/category/paris-2024-olympics/us-women%27s-water-polo-team-going-home-empty-handed-after-a-rough-finish-to-paris-olympics)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:07:19+00:00

In a matter of days, the U.S. women's water polo team went from the pursuit of a historic gold medal to going home empty-handed.
It was quite a…

## Taiwan gender-row boxer Lin eases to Paris Olympics gold
 - [https://japantoday.com/category/paris-2024-olympics/taiwan-gender-row-boxer-lin-eases-to-paris-olympics-gold](https://japantoday.com/category/paris-2024-olympics/taiwan-gender-row-boxer-lin-eases-to-paris-olympics-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:06:01+00:00

Taiwan's Lin Yu-ting won her Paris Olympics women's boxing final on Saturday, ensuring that the two fighters at the centre of a major gender controversy both take home…

## Great haul of China: Cao Yuan wins gold to give his nation an unprecedented diving sweep
 - [https://japantoday.com/category/paris-2024-olympics/china-goes-1-2-in-men%27s-platform-semis-still-on-course-for-unprecedented-olympic-diving-sweep](https://japantoday.com/category/paris-2024-olympics/china-goes-1-2-in-men%27s-platform-semis-still-on-course-for-unprecedented-olympic-diving-sweep)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:05:31+00:00

Call it the Great Haul of China.
Cao Yuan defended his title in the men's 10-meter platform on Saturday and gave his nation an unprecedented sweep of the…

## Canada's B-Boy Phil Wizard wins men's breaking gold
 - [https://japantoday.com/category/paris-2024-olympics/canada%27s-b-boy-phil-wizard-wins-inaugural-olympic-breaking-gold](https://japantoday.com/category/paris-2024-olympics/canada%27s-b-boy-phil-wizard-wins-inaugural-olympic-breaking-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:05:04+00:00

Canada's B-Boy Phil Wizard won the inaugural Olympic men's breaking gold in Paris on Saturday, beating France's B-Boy Dany Dann in the final.
Phil Wizard, whose real name…

## France defends men's volleyball Olympic gold medal, beating No. 1 Poland in front of wild home fans
 - [https://japantoday.com/category/paris-2024-olympics/france-defends-men%27s-volleyball-olympic-gold-medal-beating-no.-1-poland-in-front-of-wild-home-fans](https://japantoday.com/category/paris-2024-olympics/france-defends-men%27s-volleyball-olympic-gold-medal-beating-no.-1-poland-in-front-of-wild-home-fans)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:04:29+00:00

Jean Patry and his jubilant French teammates locked shoulders, formed a circle, then jumped and danced. They kept bouncing on their side of the net for several minutes…

## U.S. beats Brazil 1-0 to win women's soccer gold
 - [https://japantoday.com/category/paris-2024-olympics/swanson-strike-hands-usa-olympic-women%27s-football-gold-against-brazil](https://japantoday.com/category/paris-2024-olympics/swanson-strike-hands-usa-olympic-women%27s-football-gold-against-brazil)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:03:56+00:00

Mallory Swanson scored the winning goal as the United States edged Brazil 1-0 in Saturday's Olympic women's soccer final to claim the gold medal for a record-extending fifth…

## Kipyegon makes history as U.S. underlines track and field dominance
 - [https://japantoday.com/category/paris-2024-olympics/kipyegon-makes-history-as-us-underline-track-and-field-dominance](https://japantoday.com/category/paris-2024-olympics/kipyegon-makes-history-as-us-underline-track-and-field-dominance)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:03:18+00:00

History-making Faith Kipyegon became the first woman to win three consecutive Olympic 1,500m titles in Paris on Saturday as the United States bagged three more golds to confirm…

## China completes table tennis gold clean sweep, beating Japan 3-0 in women's team final
 - [https://japantoday.com/category/paris-2024-olympics/china-completes-olympic-table-tennis-gold-clean-sweep](https://japantoday.com/category/paris-2024-olympics/china-completes-olympic-table-tennis-gold-clean-sweep)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:02:40+00:00

China completed a clean sweep of the Olympic gold medals in table tennis Saturday by winning the women's team title in Paris, the sixth time the Chinese have…

## UK's Starmer scraps holiday to focus on response to riots
 - [https://japantoday.com/category/world/uk%27s-starmer-scraps-holiday-to-focus-on-response-to-riots1](https://japantoday.com/category/world/uk%27s-starmer-scraps-holiday-to-focus-on-response-to-riots1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:01:37+00:00

British Prime Minister Keir Starmer has cancelled a planned holiday to focus on his government's response to a series of racist riots that targeted Muslims and migrants, a…

## Mexican drug lord 'El Mayo' Zambada says he was ambushed and kidnapped before being taken to U.S.
 - [https://japantoday.com/category/world/mexican-drug-lord-%27el-mayo%27-zambada-says-he-was-ambushed-and-kidnapped-before-being-taken-to-the-us](https://japantoday.com/category/world/mexican-drug-lord-%27el-mayo%27-zambada-says-he-was-ambushed-and-kidnapped-before-being-taken-to-the-us)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:01:07+00:00

Mexican drug cartel leader Ismael “El Mayo” Zambada said that he was ambushed and kidnapped when he thought he was going to meet the governor of the northern…

## Turkey reinstates access to Instagram after more than a week
 - [https://japantoday.com/category/world/turkey-suddenly-reinstates-access-to-instagram-after-more-than-a-week](https://japantoday.com/category/world/turkey-suddenly-reinstates-access-to-instagram-after-more-than-a-week)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:00:40+00:00

Turkey reinstated access to Instagram on Saturday night, after more than a week of being blocked nationwide.
The Information and Communication Technologies Authority barred access to Instagram on…

## Venezuela's top court says opposition failed to submit proof in election dispute
 - [https://japantoday.com/category/world/venezuela%27s-top-court-says-opposition-failed-to-submit-proof-in-election-dispute](https://japantoday.com/category/world/venezuela%27s-top-court-says-opposition-failed-to-submit-proof-in-election-dispute)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T22:00:19+00:00

Venezuela's supreme court on Saturday said that it had not received evidence from the opposition coalition in the disputed July 28 presidential elections and warned that its decision…

## Zelenskyy acknowledges military operation in Russia's Kursk region
 - [https://japantoday.com/category/world/zelenskiy-acknowledges-military-operation-in-russia%27s-kursk-region](https://japantoday.com/category/world/zelenskiy-acknowledges-military-operation-in-russia%27s-kursk-region)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:59:50+00:00

President Volodymyr Zelenskyy acknowledged for the first time on Saturday that Ukrainian forces were fighting in Russia's Kursk region and said the operation was part of Kyiv's drive…

## New polls give Harris lead over Trump in three key states
 - [https://japantoday.com/category/world/new-polls-give-harris-a-lead-over-trump-in-three-key-states](https://japantoday.com/category/world/new-polls-give-harris-a-lead-over-trump-in-three-key-states)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:59:14+00:00

Kamala Harris now leads Donald Trump in three crucial battleground states, according to new polls published Saturday, apparently eroding the advantage the former president has enjoyed there over…

## Israeli strike kills nearly 100 in Gaza school refuge, civil defense officials say
 - [https://japantoday.com/category/world/israeli-strike-kills-nearly-100-in-gaza-school-refuge-civil-defence-officials-say3](https://japantoday.com/category/world/israeli-strike-kills-nearly-100-in-gaza-school-refuge-civil-defence-officials-say3)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:58:36+00:00

An Israeli airstrike on a Gaza City school compound housing displaced Palestinian families killed around 100 people, the Gaza Civil Emergency Service said on Saturday, while Israel said…

## Back to reality for Wallabies: South Africa overwhelms Australia 33-7
 - [https://japantoday.com/category/sports/back-to-reality-for-the-wallabies-world-cup-champion-south-africa-overwhelms-australia-33-7](https://japantoday.com/category/sports/back-to-reality-for-the-wallabies-world-cup-champion-south-africa-overwhelms-australia-33-7)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:57:41+00:00

World Cup champion South Africa gave the previously unbeaten Wallabies a harsh reality check on Saturday, leading 14-0 early and beating Australia 33-7 in the opening Rugby Championship…

## Creevy scores late as Argentina stuns All Blacks 38-30 in Rugby Championship
 - [https://japantoday.com/category/sports/creevy-scores-late-as-argentina-stuns-new-zealand-38-30-in-rugby-championship](https://japantoday.com/category/sports/creevy-scores-late-as-argentina-stuns-new-zealand-38-30-in-rugby-championship)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:57:07+00:00

Veteran Agustin Creevy scored a try in the 69th minute as Argentina beat New Zealand 38-30 on Saturday in a thrilling Rugby Championship match which saw five lead…

## Sinner steams into Montreal quarterfinals in ATP catch-up bid
 - [https://japantoday.com/category/sports/sinner-steams-into-montreal-quarter-finals-in-atp-catch-up-bid](https://japantoday.com/category/sports/sinner-steams-into-montreal-quarter-finals-in-atp-catch-up-bid)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:56:40+00:00

Top seed Jannik Sinner took his place in the ATP Montreal Masters quarterfinals on Saturday as organizers raced to get the event back on schedule.
Sinner posted a…

## Man Utd 'hurting' as Man City takes Community Shield on penalties
 - [https://japantoday.com/category/sports/man-city-edge-man-utd-on-penalties-to-win-community-shield](https://japantoday.com/category/sports/man-city-edge-man-utd-on-penalties-to-win-community-shield)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:56:11+00:00

Erik ten Hag said Manchester United must feel the pain of a Community Shield defeat on penalties to Manchester City to fuel them for the beginning of the…

## LA planning 'No Car' Olympics to beat gridlock
 - [https://japantoday.com/category/sports/la-planning-%27no-car%27-olympics-to-beat-gridlock](https://japantoday.com/category/sports/la-planning-%27no-car%27-olympics-to-beat-gridlock)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:55:38+00:00

Los Angeles 2028 organizers said Saturday they will force spectators to take public transportation to Olympic venues and encourage remote working in a bid to sidestep the gridlocked…

## Hotels, Japanese inns hit by cancellations after megaquake alert
 - [https://japantoday.com/category/national/hotels-japanese-inns-hit-by-cancellations-after-megaquake-alert](https://japantoday.com/category/national/hotels-japanese-inns-hit-by-cancellations-after-megaquake-alert)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:50:12+00:00

Hotels and ryokan, Japanese-style inns, in coastal areas in central and western Japan, have been hit by hundreds of cancellations following the weather agency's advisory over a potential…

## U.S. ambassador to Japan planning to leave post in November
 - [https://japantoday.com/category/politics/update1-u.s.-ambassador-to-japan-planning-to-leave-post-in-november](https://japantoday.com/category/politics/update1-u.s.-ambassador-to-japan-planning-to-leave-post-in-november)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:49:08+00:00

U.S. Ambassador to Japan Rahm Emanuel has told people around him of his intention to leave his post in November, government sources said.
Emanuel, known for his tough…

## Motoki wins women's wrestling 62-kg gold; Takatani gets silver
 - [https://japantoday.com/category/paris-2024-olympics/urgent-japan%27s-motoki-wins-women%27s-wrestling-62-kg-gold](https://japantoday.com/category/paris-2024-olympics/urgent-japan%27s-motoki-wins-women%27s-wrestling-62-kg-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:48:23+00:00

Japan's Sakura Motoki won the women's wrestling 62-kilogram gold medal at the Paris Olympics on Saturday.
The 22-year-old Motoki defeated Tokyo Olympic bronze medalist Iryna Koliadenko of Ukraine…

## Kitaguchi wins women's javelin throw gold
 - [https://japantoday.com/category/paris-2024-olympics/update2-olympics-kitaguchi-wins-women%27s-javelin-throw-gold-at-paris-games](https://japantoday.com/category/paris-2024-olympics/update2-olympics-kitaguchi-wins-women%27s-javelin-throw-gold-at-paris-games)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:47:46+00:00

Japan's Haruka Kitaguchi captured the women's javelin throw gold medal at the Paris Olympics on Saturday.
The 26-year-old won with her first throw of the competition at Stade…

## The gold medal goes to ... the chocolate muffin. At the Olympic village, the bakery shines
 - [https://japantoday.com/category/features/food/the-gold-medal-goes-to-...-the-chocolate-muffin.-at-the-olympic-village-the-bakery-shines](https://japantoday.com/category/features/food/the-gold-medal-goes-to-...-the-chocolate-muffin.-at-the-olympic-village-the-bakery-shines)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T21:44:40+00:00

Freshly cooked bread and a selection of French pastries were meant to be the stars of the Olympic village where athletes from across the world have packed the…

## Ethiopian Tamirat Tola wins men's marathon to end Kenya dominance
 - [https://japantoday.com/category/paris-2024-olympics/ethiopian-runner-tamirat-tola-wins-men%27s-marathon-at-paris-olympics-to-end-kenya-dominance](https://japantoday.com/category/paris-2024-olympics/ethiopian-runner-tamirat-tola-wins-men%27s-marathon-at-paris-olympics-to-end-kenya-dominance)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T09:51:27+00:00

Ethiopian runner Tamirat Tola won the men's marathon at the Paris Olympics on Saturday to end Kenya's dominance of the race.
Tola finished in an Olympic record time…

## M6.8 quake jolts northern and northeastern Japan
 - [https://japantoday.com/category/national/m6.8-quake-jolts-northern-and-northeastern-japan](https://japantoday.com/category/national/m6.8-quake-jolts-northern-and-northeastern-japan)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T08:24:19+00:00

An earthquake with a preliminary magnitude of 6.8 struck northern and northeastern Japan on Saturday, but no tsunami warning was issued, the weather agency said.
Despite its relatively…

## North Korea moving thousands of flood victims to capital: KCNA
 - [https://japantoday.com/category/world/north-korea-moving-thousands-of-flood-victims-to-capital-kcna](https://japantoday.com/category/world/north-korea-moving-thousands-of-flood-victims-to-capital-kcna)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-08-10T06:22:44+00:00

North Korea will move more than 15,000 flood victims to the capital, state media said Saturday, as leader Kim Jong Un insisted recovery efforts would be &quot;based on…

