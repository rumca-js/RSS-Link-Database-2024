# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## GNOME Sort Of Brings The System Tray Back
 - [https://www.youtube.com/watch?v=ejqNCbE42cg](https://www.youtube.com/watch?v=ejqNCbE42cg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-08-10T21:00:17+00:00

GNOME has always had a really weird relationship with the system tray but after 7 years they've decided to make at least a little bit of a compromise, albeit one that still sucks.

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
2017 OMG Ubuntu: https://www.omgubuntu.co.uk/2017/09/will-you-miss-gnome-legacy-tray
GNOME 3.26 Release Notes: https://help.gnome.org/misc/release-notes/3.26/
TopIcons: https://extensions.gnome.org/extension/495/topicons/
Top Icons Plus: https://extensions.gnome.org/extension/1031/topicons/
Tray Icons Reloaded: https://extensions.gnome.org/extension/2890/tray-icons-reloaded/
AppIndicator and KStatusNotifierItem Support: https://extensions.gnome.org/extension/615/appindicator-support/
GNOME Extensions Merge: https://gitlab.gnome.org/GNOME/gnome-sh

## 【Testing】COSMIC Desktop First Impressions!!
 - [https://www.youtube.com/watch?v=BG9JSLk4GfE](https://www.youtube.com/watch?v=BG9JSLk4GfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-08-10T05:55:31+00:00

StreamElements Tip: http://brodierobertson.xyz/streamelements
Check out my Twitch: http://brodierobertson.xyz/twitch

Whilst I did have access to an early release ISO, I wanted my first experience with COSMIC to be on stream so lets go

==========Support The Channel==========
► $100 Linode Credit: http://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberachat: https://brodierobertson.xyz/liberachat
► Amazon USA: https://brodierobertson.xyz/amazonusa

=========Video Platforms==========
 Odysee: https://brodierobertson.xyz/odysee
 Podcast: https://techovertea.xyz/youtube
 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
 Discord: https://brodierobertson.xyz/discord
 Matrix Space: https://brodierobertson.xyz/matrix
 Twitter: https://brodierobertson.xyz/twitter
 Mastodon: https://brodierobertson.xyz/mastodon
️ GitHub: https://brodierobertson.xyz/github

==========Credits==========
Chann

