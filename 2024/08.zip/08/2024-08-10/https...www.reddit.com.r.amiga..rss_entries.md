# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## Might have to up the difficulty
 - [https://www.reddit.com/r/amiga/comments/1ep1u76/might_have_to_up_the_difficulty](https://www.reddit.com/r/amiga/comments/1ep1u76/might_have_to_up_the_difficulty)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-08-10T19:55:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ep1u76/might_have_to_up_the_difficulty/"> <img alt="Might have to up the difficulty" src="https://b.thumbs.redditmedia.com/pAbOIReAXqssmJKBanIluljF9akasQp3SRVQg6CwzrU.jpg" title="Might have to up the difficulty" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>They kept it closer in the race in fairness but they weren't going to beat Mansell lol 😆 </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/iamezekiel1_14"> /u/iamezekiel1_14 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep1u76">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ep1u76/might_have_to_up_the_difficulty/">[comments]</a></span> </td></tr></table>

## Crazy Cars 3 - Done (and onto the next thing)
 - [https://www.reddit.com/r/amiga/comments/1ep11yc/crazy_cars_3_done_and_onto_the_next_thing](https://www.reddit.com/r/amiga/comments/1ep11yc/crazy_cars_3_done_and_onto_the_next_thing)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-08-10T19:19:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ep11yc/crazy_cars_3_done_and_onto_the_next_thing/"> <img alt="Crazy Cars 3 - Done (and onto the next thing)" src="https://b.thumbs.redditmedia.com/9eerDPQmnxgXk-Gc-Ro4yWdVODteateCNIYztRverpU.jpg" title="Crazy Cars 3 - Done (and onto the next thing)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Couldn't find a spoiler tag so went for Achievement Unlocked. Relatively straight forward but the last level required a lot of turbos lmao 🤣 </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/iamezekiel1_14"> /u/iamezekiel1_14 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep11yc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ep11yc/crazy_cars_3_done_and_onto_the_next_thing/">[comments]</a></span> </td></tr></table>

## Using SCSIDEV43 with 40Gb HD
 - [https://www.reddit.com/r/amiga/comments/1eowvt4/using_scsidev43_with_40gb_hd](https://www.reddit.com/r/amiga/comments/1eowvt4/using_scsidev43_with_40gb_hd)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-08-10T16:18:43+00:00

<!-- SC_OFF --><div class="md"><p>Hi to all, I have a 4Gb HD on my Idefix interface 1st channel unit 0 and a 40Gb unit 1 on an Amiga 1200 with Blizzard 1230 IV. I use Blizkick to load a 3.1 rom.</p> <p>I'm using only 8Gb of this HD with Professional FileSystem, but I'd like to use all the space...</p> <p>I tried to load the SCSIDEV43 but without success...</p> <p>How can I use a different scsi.device from the one with the 2nd HD?</p> <p>Best regards</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/_Pago_"> /u/_Pago_ </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1eowvt4/using_scsidev43_with_40gb_hd/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1eowvt4/using_scsidev43_with_40gb_hd/">[comments]</a></span>

## What are these green spots on my A1200 main board?
 - [https://www.reddit.com/r/amiga/comments/1eopnl2/what_are_these_green_spots_on_my_a1200_main_board](https://www.reddit.com/r/amiga/comments/1eopnl2/what_are_these_green_spots_on_my_a1200_main_board)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-08-10T10:15:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1eopnl2/what_are_these_green_spots_on_my_a1200_main_board/"> <img alt="What are these green spots on my A1200 main board?" src="https://a.thumbs.redditmedia.com/FjKGBQeZ20g01ovZJApoFjQDiV8RYy0x5JcEmJvtpo4.jpg" title="What are these green spots on my A1200 main board?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Finally got around to recap my A1200 (REV 2B Escom model). It didn't boot so recapping seems the best first thing to try. While inspecting the board I saw these green spots. I tried cleaning with ipa but it didn't help. There are signs of capacitor leakage on other areas. Anyone have an idea what those green spots could be?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CaptainLazy99"> /u/CaptainLazy99 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eopnl2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1eopnl2/what_are_the

