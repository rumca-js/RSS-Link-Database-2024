# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## Lin Yu-ting claims gold in boxing amid gender controversy
 - [https://www.nbcnews.com/news/sports/lin-yu-ting-claims-gold-boxing-gender-controversy-rcna166107](https://www.nbcnews.com/news/sports/lin-yu-ting-claims-gold-boxing-gender-controversy-rcna166107)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-08-10T21:32:48+00:00

PARIS — Lin Yu-ting captured featherweight gold on Saturday, defeating Poland’s Julia Szeremeta and shaking off more than a week of specious allegations that she shouldn’t be fighting in the women’s division.

## Steph Curry leads Team USA to fifth straight gold medal in men's basketball
 - [https://www.nbcnews.com/news/sports/steph-curry-leads-team-usa-fifth-straight-gold-medal-mens-basketball-rcna166110](https://www.nbcnews.com/news/sports/steph-curry-leads-team-usa-fifth-straight-gold-medal-mens-basketball-rcna166110)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-08-10T21:23:47+00:00

PARIS — Steph Curry's late-game heroics and a lightning-fast American transition attack denied France its storybook basketball ending Saturday night.

## U.S. women's 4x400m relay dominates for gold
 - [https://www.nbcnews.com/video/u-s-women-s-4x400m-relay-dominates-for-gold-216904773851](https://www.nbcnews.com/video/u-s-women-s-4x400m-relay-dominates-for-gold-216904773851)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-08-10T20:06:18+00:00

The U.S. women's relay team of Shamier Little, Sydney McLaughlin-Levrone, Gabby Thomas and Alexis Holmes ran a dominant relay in 3:15.27 to take home gold. That time is the second-fastest in history.

## USWNT wins gold medal after hard fought 1-0 win vs. Brazil
 - [https://www.nbcnews.com/video/uswnt-wins-gold-medal-after-1-0-win-vs-brazil-at-2024-paris-olympics-216900677815](https://www.nbcnews.com/video/uswnt-wins-gold-medal-after-1-0-win-vs-brazil-at-2024-paris-olympics-216900677815)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-08-10T17:40:49+00:00

The U.S. women's national team claimed the gold medal after its 1-0 win against Brazil in the final of the women's soccer tournament at the 2024 Paris Olympics.

