# Source:Techlinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA, language:en-US

## New Hack "Downdates" Windows
 - [https://www.youtube.com/watch?v=o59amOZvtnA](https://www.youtube.com/watch?v=o59amOZvtnA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA
 - date published: 2024-08-10T05:52:32+00:00

Embrace your daily life adventure with Vessi! Visit https://vessi.com/TechLinked  for an automatic 15% off your first purchase at checkout!

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► GET A VPN: https://www.piavpn.com/TechLinked
► LISTEN TO THE TECH NEWS: https://lmg.gg/TechLinkedPodcast
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR PODCAST GEAR: https://lmg.gg/podcastgear

NEWS SOURCES: https://lmg.gg/N429n
---------------------------------------------------
Timestamps:
0:00 you should know this
0:09 Windows "Downdate" attacks
1:14 Apple's new EU app linking fees
2:28 Intel microcode patch update
4:33 QUICK BITS
4:40 GPT-4o impersonated testers' voice
5:38 SteamOS beta hints at general install
6:25 0.0.0.0 Day vulnerability patched
7:06 3 BILLION people's data exposed?
7:41 Solving fusion energy with mayonnaise

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: http://t

