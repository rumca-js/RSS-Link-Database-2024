# Source:Newsweek, URL:https://www.newsweek.com/rss, language:en-US

## Former WWE Champion Prefers Vince McMahon to Triple H
 - [https://www.newsweek.com/former-wwe-champion-prefers-vince-mcmahon-triple-h-1937498](https://www.newsweek.com/former-wwe-champion-prefers-vince-mcmahon-triple-h-1937498)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T23:32:13+00:00

A former WWE Champion reveals why he prefers Vince McMahon as the head of creative over Triple H.

## Dodgers Expected To Get Major Reinforcements From Injury List Soon
 - [https://www.newsweek.com/sports/mlb/dodgers-expected-get-major-reinforcements-injury-list-soon-1937482](https://www.newsweek.com/sports/mlb/dodgers-expected-get-major-reinforcements-injury-list-soon-1937482)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T23:02:11+00:00

Los Angeles is expecting to get multiple key players back from injury soon.

## NASCAR: Daniel Suarez Reveals Priorities During Trackhouse Racing Contract Negotiations
 - [https://www.newsweek.com/sports/racing/nascar-daniel-suarez-reveals-priorities-during-trackhouse-racing-contract-negotiations-1937489](https://www.newsweek.com/sports/racing/nascar-daniel-suarez-reveals-priorities-during-trackhouse-racing-contract-negotiations-1937489)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T23:00:01+00:00

Daniel Suarez was more focused on improving his performance on the track rather than contract negotiations.

## Joel Embiid May Not Play For Team USA in 2028 Olympics
 - [https://www.newsweek.com/sports/nba/joel-embiid-may-not-play-team-usa-2028-olympics-1937497](https://www.newsweek.com/sports/nba/joel-embiid-may-not-play-team-usa-2028-olympics-1937497)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:59:05+00:00

Joel Embiid gave some insight into his plans for the 2028 Olympics.

## Future Hall of Famer Named USA Basketball MVP After Winning 2024 Olympic Gold vs France
 - [https://www.newsweek.com/sports/nba/future-hall-famer-named-usa-basketball-mvp-after-winning-2024-olympic-gold-vs-france-1937490](https://www.newsweek.com/sports/nba/future-hall-famer-named-usa-basketball-mvp-after-winning-2024-olympic-gold-vs-france-1937490)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:57:31+00:00

This very decorated NBA champion just added yet another honor to his Hall of Fame-worthy resume.

## NASCAR: David Wilson Shares Heartfelt Message After Retirement Announcement - 'I'm At Peace'
 - [https://www.newsweek.com/sports/racing/nascar-david-wilson-shares-heartfelt-message-after-retirement-announcement-im-peace-1937486](https://www.newsweek.com/sports/racing/nascar-david-wilson-shares-heartfelt-message-after-retirement-announcement-im-peace-1937486)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:30:01+00:00

David Wilson, president of Toyota Racing Development, announced his retirement during an emotional news conference.

## Is Team USA Olympic Basketball's Steve Kerr Replacement Already on 2024 Staff?
 - [https://www.newsweek.com/sports/nba/team-usa-olympic-basketballs-steve-kerr-replacement-already-2024-staff-1937450](https://www.newsweek.com/sports/nba/team-usa-olympic-basketballs-steve-kerr-replacement-already-2024-staff-1937450)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:23:52+00:00

The Golden State Warriors head coach had a much-derided first Olympic run with the Americans in Paris.

## 2024 NASCAR Cup Series Richmond Practice Results - Austin Dillon On Top
 - [https://www.newsweek.com/sports/racing/2024-nascar-cup-series-richmond-practice-results-austin-dillon-top-1937493](https://www.newsweek.com/sports/racing/2024-nascar-cup-series-richmond-practice-results-austin-dillon-top-1937493)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:23:00+00:00

Austin Dillon set the pace with the fastest time on the softer Option tires.

## Steph Curry Wins First Gold Medal at Olympic Games With Team USA Win
 - [https://www.newsweek.com/sports/nba/steph-curry-wins-first-gold-medal-olympic-games-team-usa-win-1937488](https://www.newsweek.com/sports/nba/steph-curry-wins-first-gold-medal-olympic-games-team-usa-win-1937488)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:20:29+00:00

Steph Curry earns his first Olympic gold medal by leading Team USA to their fifth.

## NASCAR Insider Slams Sport For Cup Series Blunder - 'Don't Blame The Drivers When No One's Watching'
 - [https://www.newsweek.com/sports/racing/nascar-insider-slams-sport-cup-series-blunder-dont-blame-drivers-when-no-ones-watching-1937487](https://www.newsweek.com/sports/racing/nascar-insider-slams-sport-cup-series-blunder-dont-blame-drivers-when-no-ones-watching-1937487)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:11:58+00:00

The return of the NASCAR Cup Series was marked by broadcasting issues that left fans struggling to access important sessions.

## Donald Trump's Helicopter Claim Raises Questions From Critics
 - [https://www.newsweek.com/donald-trump-willie-brown-helicopter-claim-raises-questions-1937467](https://www.newsweek.com/donald-trump-willie-brown-helicopter-claim-raises-questions-1937467)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:10:44+00:00

Trump recently claimed he and Willie Brown, a former San Francisco mayor, almost died in a helicopter. However, Brown said it wasn't him.

## Dodgers Starting Pitcher Creates Special Moment Pitching at Home
 - [https://www.newsweek.com/sports/mlb/dodgers-starting-pitcher-creates-special-moment-pitching-home-1937477](https://www.newsweek.com/sports/mlb/dodgers-starting-pitcher-creates-special-moment-pitching-home-1937477)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T22:00:13+00:00

One of the Dodgers starting pitchers had a special moment pitching at home.

## Falcons' Kirk Cousins Provides Massive Injury Update For Week 1 Status
 - [https://www.newsweek.com/sports/nfl/falcons-kirk-cousins-provides-massive-injury-update-week-1-status-1937476](https://www.newsweek.com/sports/nfl/falcons-kirk-cousins-provides-massive-injury-update-week-1-status-1937476)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:58:06+00:00

Falcons quarterback Kirk Cousins provided a big injury update for his Week 1 status.

## Kevin Durant Creates Insane Team USA History With Win Over France
 - [https://www.newsweek.com/sports/nba/kevin-durant-creates-insane-team-usa-history-win-over-france-1937484](https://www.newsweek.com/sports/nba/kevin-durant-creates-insane-team-usa-history-win-over-france-1937484)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:43:49+00:00

Amid the Team USA claiming gold at the Olympics, Kevin Durant created some insane history.

## Brittany Mahomes Calls Out Patrick Mahomes Over Wardrobe Malfunction
 - [https://www.newsweek.com/entertainment/celebrity-news/brittany-mahomes-calls-out-patrick-mahomes-wardrobe-malfunction-1937479](https://www.newsweek.com/entertainment/celebrity-news/brittany-mahomes-calls-out-patrick-mahomes-wardrobe-malfunction-1937479)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:36:55+00:00

The football player's wife had thoughts to share on his recent uniform mishap.

## FanDuel Promo Code: Win $150 Bonus on $5 MLB, NFL Bet
 - [https://www.newsweek.com/fanduel-promo-code-win-150-bonus-5-mlb-nfl-bet-august-10-1937437](https://www.newsweek.com/fanduel-promo-code-win-150-bonus-5-mlb-nfl-bet-august-10-1937437)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:30:01+00:00

Our exclusive FanDuel promo code links allow new customers to bet $5 on MLB or the NFL to win $150 in bonus bets.

## Donald Trump Campaign Hack: What We Know
 - [https://www.newsweek.com/donald-trump-campaign-hack-leaks-iran-politico-microsoft-1937473](https://www.newsweek.com/donald-trump-campaign-hack-leaks-iran-politico-microsoft-1937473)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:26:13+00:00

The incident has raised alarms about potential foreign interference in this year's election and the vulnerability of campaign infrastructure to cyber-attacks.

## Stephen Curry, USA Basketball Survive Team France to Win 5th Straight Olympic Gold Medal
 - [https://www.newsweek.com/sports/nba/stephen-curry-usa-basketball-survive-team-france-win-5th-straight-olympic-gold-medal-1937458](https://www.newsweek.com/sports/nba/stephen-curry-usa-basketball-survive-team-france-win-5th-straight-olympic-gold-medal-1937458)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:21:06+00:00

The Americans won their fifth straight gold medal at the 2024 Paris Olympics, by vanquishing the home nation's team.

## Celine Dion Denounces Donald Trump Rally Playing Her Song
 - [https://www.newsweek.com/celine-dion-denounces-donald-trump-rally-playing-song-1937468](https://www.newsweek.com/celine-dion-denounces-donald-trump-rally-playing-song-1937468)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:11:02+00:00

This is not the first time artists have objected to their songs being played at one of the former president's rallies.

## Kamala Harris Now Leads Donald Trump in Six Different Polling Averages
 - [https://www.newsweek.com/kamala-harris-now-leads-donald-trump-six-national-poll-averages-1937465](https://www.newsweek.com/kamala-harris-now-leads-donald-trump-six-national-poll-averages-1937465)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:06:55+00:00

The aggregate polls reveal a close presidential election where Trump and Harris are inching up or down within the margin of error.

## Why Bubba Wallace Missed Daniel Suarez's Big Brazilian Wedding - Revealed
 - [https://www.newsweek.com/sports/racing/why-bubba-wallace-missed-daniel-suarezs-big-brazilian-wedding-revealed-1937462](https://www.newsweek.com/sports/racing/why-bubba-wallace-missed-daniel-suarezs-big-brazilian-wedding-revealed-1937462)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T21:00:01+00:00

Bubba Wallace didn't attend Daniel Suarez's wedding due to his pregnant wife's travel limitations.

## Justin Bieber Scolds Teens for Following Pregnant Wife Hailey
 - [https://www.newsweek.com/entertainment/celebrity-news/justin-bieber-scolds-teens-following-pregnant-wife-hailey-video-august-2024-1937461](https://www.newsweek.com/entertainment/celebrity-news/justin-bieber-scolds-teens-following-pregnant-wife-hailey-video-august-2024-1937461)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T20:59:00+00:00

The pop singer could be seen yelling at a group of teens in the lobby of the Waldorf Astoria in Beverly Hills.

## Jessica Alba's Daughters Are All Grown Up in Rare Night Out With Actress in Mykonos
 - [https://www.newsweek.com/entertainment/celebrity-news/jessica-albas-daughters-all-grown-rare-night-out-mykonos-august-2024-1937435](https://www.newsweek.com/entertainment/celebrity-news/jessica-albas-daughters-all-grown-rare-night-out-mykonos-august-2024-1937435)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T20:52:30+00:00

The mother-of-three shared a carousel of photos from her family vacation, featuring kids Honor Marie, Haven Garner, and Hayes.

## Despite Draft Controversy, Falcons' Rookie QB Michael Penix Shows Promise in Debut
 - [https://www.newsweek.com/sports/nfl/despite-draft-controversy-falcons-rookie-qb-michael-penix-shows-promise-debut-1937471](https://www.newsweek.com/sports/nfl/despite-draft-controversy-falcons-rookie-qb-michael-penix-shows-promise-debut-1937471)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T20:46:42+00:00

Atlanta Falcons rookie quarterback Michael Penix showed promise in his NFL debut.

## Joe Biden's Supreme Court Reform Plan Backed by Majority of Republicans
 - [https://www.newsweek.com/joe-biden-supreme-court-reform-majority-republicans-poll-1937446](https://www.newsweek.com/joe-biden-supreme-court-reform-majority-republicans-poll-1937446)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-08-10T20:41:50+00:00

According to a new poll, 70 percent of Republicans said they support establishing a binding code of conduct for the Supreme Court.

