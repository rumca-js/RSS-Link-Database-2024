# Source:The New Yorker, URL:https://www.newyorker.com/feed/rss, language:en-US

## The Harris-Walz Reboot
 - [https://www.newyorker.com/podcast/political-scene/the-harris-walz-reboot](https://www.newyorker.com/podcast/political-scene/the-harris-walz-reboot)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-08-10T10:00:00+00:00

“Walz has scrambled the circuits for Trump because he’s not easy to pigeonhole,” Evan Osnos says. “He’s not what Trump imagines, in his comic-book way, of what a progressive looks like.”

## What Tweens Get from Sephora and What They Get from Us
 - [https://www.newyorker.com/culture/the-weekend-essay/what-tweens-get-from-sephora-and-what-they-get-from-us](https://www.newyorker.com/culture/the-weekend-essay/what-tweens-get-from-sephora-and-what-they-get-from-us)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-08-10T10:00:00+00:00

Kids are mimicking the semi-professionals they see on their phones, imbibing ideas about beauty rooted in deep desires and capitulations.

