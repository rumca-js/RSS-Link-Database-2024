# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Plop tiles to make flourishing ecosystems in placement puzzler Preserve
 - [https://www.pcgamer.com/games/puzzle/plop-tiles-to-make-flourishing-ecosystems-in-placement-puzzler-preserve](https://www.pcgamer.com/games/puzzle/plop-tiles-to-make-flourishing-ecosystems-in-placement-puzzler-preserve)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-10T23:03:10+00:00

The chill tile-placement genre gets bigger and bigger.

## Be a cute platypus, solve some Zelda-style puzzles, in Ogu and the Secret Forest
 - [https://www.pcgamer.com/games/be-a-cute-platypus-solve-some-zelda-style-puzzles-in-ogu-and-the-secret-forest](https://www.pcgamer.com/games/be-a-cute-platypus-solve-some-zelda-style-puzzles-in-ogu-and-the-secret-forest)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-10T22:19:50+00:00

Just a little guy.

## Today's Wordle answer for Saturday, August 10
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-august-10-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-august-10-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-08-10T03:00:14+00:00

Wordle today: The solution and a hint for Saturday's puzzle.

