# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## Watch: NY cop pulls pants down of repeat offending thug after he sucker punched female officer
 - [https://www.louderwithcrowder.com/nyc-cop-pants](https://www.louderwithcrowder.com/nyc-cop-pants)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-08-10T11:27:48+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=53146515&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C200%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Progressives in New York City have this foolish idea that not holding people accountable for crimes decreases it, rather than encourages recidivism. Subsequently, the same offenders keep getting arrested and <a href="https://www.foxnews.com/us/migrants-indicted-attack-nypd-cops-checking-unattended-children-nyc-homeless-shelter" target="_blank">released </a>in a continual cycle that creates more victims. </p><p>One NYC cop got fed up after a career criminal punched a female officer in the face and pulled the wannabe thug's pants down as a form of public sha

## UK police warn AMERICANS, Elon Musk: Commit thought crimes and could Be guilty of terrorism charges
 - [https://www.louderwithcrowder.com/police-commissioner-mark-rowley](https://www.louderwithcrowder.com/police-commissioner-mark-rowley)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-08-10T11:04:14+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=53145334&amp;width=1200&amp;height=800&amp;coordinates=26%2C0%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>It’s been over 200 years since the Revolutionary War and UK authorities are still trying to control things over here. So much so that Police Commissioner Mark Rowley is threatening to extradite Americans for thoughts they don’t like and have basically said they won’t rule out putting Elon Musk on their terrorist watch list.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">British police is an international laughing stock.<br /><br />Can't deport foreign criminals but are now talking a big game about having foreigners extradited for twe

