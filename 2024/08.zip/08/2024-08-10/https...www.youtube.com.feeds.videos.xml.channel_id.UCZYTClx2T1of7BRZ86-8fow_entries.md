# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The 6 Deadliest Mushrooms
 - [https://www.youtube.com/watch?v=66skvK7R5i4](https://www.youtube.com/watch?v=66skvK7R5i4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2024-08-10T17:00:04+00:00

Some of your favorite mushroom recipes might use toxic ingredients! These are the top killers worldwide among fungi, from morels to webcaps.

Hosted by: Hank Green (he/him)
----------
Support us for $8/month on Patreon and keep SciShow going!
https://www.patreon.com/scishow
Or support us directly: https://complexly.com/support
Join our SciShow email list to get the latest news and highlights: 
https://mailchi.mp/scishow/email
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Odditeas , Garrett Galloway, Friso, DrakoEsper , Kenny Wilson, J. Copen, Lyndsay Brown, Jeremy Mattern, Jaap Westera, Rizwan Kassim, Harrison Mills, Jeffrey Mckishen, Christoph Schwanke, Matt Curls, Eric Jensen, Chris Mackey, Adam Brainard, Ash, You too can be a nice person, Piya Shedden, charles george, Alex Hackman, Kevin Knupp, Chris Peters, Kevin Bealer, Jason A Saslow
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents P

