# Source:CodeProject Latest Articles, URL:https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1, language:en-us

## Code Generator for SQL Server
 - [https://www.codeproject.com/Tips/5246828/Code-Generator-for-SQL-Server](https://www.codeproject.com/Tips/5246828/Code-Generator-for-SQL-Server)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-08-10T02:28:00+00:00

Tool on T-SQL to code basic generator for SQL Server

## RGFW Under the Hood: OpenGL Context Creation
 - [https://www.codeproject.com/Articles/5386654/RGFW-Under-the-Hood-OpenGL-Context-Creation](https://www.codeproject.com/Articles/5386654/RGFW-Under-the-Hood-OpenGL-Context-Creation)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-08-10T01:05:00+00:00

Tutorial for creating an accelerated opengl context for X11, Windows, and MacOS. Based on my project: RGFW.

