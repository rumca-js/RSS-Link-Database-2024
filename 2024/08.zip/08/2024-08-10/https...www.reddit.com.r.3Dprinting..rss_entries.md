# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Bro... 25 hours, and this in the and.
 - [https://www.reddit.com/r/3Dprinting/comments/1ep5hm4/bro_25_hours_and_this_in_the_and](https://www.reddit.com/r/3Dprinting/comments/1ep5hm4/bro_25_hours_and_this_in_the_and)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T22:44:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ep5hm4/bro_25_hours_and_this_in_the_and/"> <img alt="Bro... 25 hours, and this in the and." src="https://preview.redd.it/wfbzvpce0xhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ac937089ca27bf4373343dba6ddf109b409ab7ad" title="Bro... 25 hours, and this in the and." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Nagibator_mamok3000"> /u/Nagibator_mamok3000 </a> <br /> <span><a href="https://i.redd.it/wfbzvpce0xhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ep5hm4/bro_25_hours_and_this_in_the_and/">[comments]</a></span> </td></tr></table>

## First 1 or 2 mm are rough, but the initial layer looks smooth and prints stick well. (ender 3 max)
 - [https://www.reddit.com/r/3Dprinting/comments/1ep3vn2/first_1_or_2_mm_are_rough_but_the_initial_layer](https://www.reddit.com/r/3Dprinting/comments/1ep3vn2/first_1_or_2_mm_are_rough_but_the_initial_layer)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T21:29:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ep3vn2/first_1_or_2_mm_are_rough_but_the_initial_layer/"> <img alt="First 1 or 2 mm are rough, but the initial layer looks smooth and prints stick well. (ender 3 max)" src="https://a.thumbs.redditmedia.com/FQ9b7ofRe0t_sHISntkG9z6uChnFmIKmF1jDxvP8wH4.jpg" title="First 1 or 2 mm are rough, but the initial layer looks smooth and prints stick well. (ender 3 max)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zambie73"> /u/Zambie73 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep3vn2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ep3vn2/first_1_or_2_mm_are_rough_but_the_initial_layer/">[comments]</a></span> </td></tr></table>

## Let’s see your bench collections
 - [https://www.reddit.com/r/3Dprinting/comments/1ep3dnm/lets_see_your_bench_collections](https://www.reddit.com/r/3Dprinting/comments/1ep3dnm/lets_see_your_bench_collections)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T21:06:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ep3dnm/lets_see_your_bench_collections/"> <img alt="Let’s see your bench collections " src="https://b.thumbs.redditmedia.com/uHBJT4y2mK5T9lhI8tYaHNcMHmejEQEybBdwIt0xpLE.jpg" title="Let’s see your bench collections " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>From left to right:</p> <p>Sparkly titanium blue PLA 4 colour ‘rust’ PLA Glow in the dark PLA 2 tone red and black silk PLA Vapour smoothed ASA 95A TPU Wood effect PLA Metal effect PLA Marble effect PLA</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/I_Get_No_Sleep__"> /u/I_Get_No_Sleep__ </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep3dnm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ep3dnm/lets_see_your_bench_collections/">[comments]</a></span> </td></tr></table>

## Can I put desiccant in my filament drier to help the filament dry?
 - [https://www.reddit.com/r/3Dprinting/comments/1ep2lpg/can_i_put_desiccant_in_my_filament_drier_to_help](https://www.reddit.com/r/3Dprinting/comments/1ep2lpg/can_i_put_desiccant_in_my_filament_drier_to_help)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T20:30:19+00:00

<!-- SC_OFF --><div class="md"><p>So I have heard a version of this for drying desiccant but this is not my goal.</p> <p>My goal is just to keep the filament in my Sunlu S1 dry longer. Past when I have set it.</p> <p>My house stays around 50-70% humidity.</p> <p>Even though I can set the timer for 12 hours some times I forget to refresh it before a print or want to print first thing in the morning and forgot the night before. I feel like it could maybe help keep things dry in there when the drier isnt running. Perhaps for filaments that have absorbed more moisture it could help me not have to wipe the inside of condensation so often.</p> <p>The thing I am worried about is it is not technically airtight. There are two holes in it. one for the filament and one that seems to be there also for the filament. Perhaps this means the desiccant is going to get essentially wasted attempting to absorb moisture from my entire house?</p> <p>I realize I may have to refresh the desiccant more often 

## Very Tiny 3D Printed Structures and Confocal Images
 - [https://www.reddit.com/r/3Dprinting/comments/1ep2esa/very_tiny_3d_printed_structures_and_confocal](https://www.reddit.com/r/3Dprinting/comments/1ep2esa/very_tiny_3d_printed_structures_and_confocal)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T20:21:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ep2esa/very_tiny_3d_printed_structures_and_confocal/"> <img alt="Very Tiny 3D Printed Structures and Confocal Images" src="https://b.thumbs.redditmedia.com/WE9ChfKUKf32nC72_1HM1vnSJrmjSRwkEXwWJIQqerk.jpg" title="Very Tiny 3D Printed Structures and Confocal Images" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Herbologisty"> /u/Herbologisty </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep2esa">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ep2esa/very_tiny_3d_printed_structures_and_confocal/">[comments]</a></span> </td></tr></table>

## Update: I have become brass, destroyer of blob.
 - [https://www.reddit.com/r/3Dprinting/comments/1ep28ld/update_i_have_become_brass_destroyer_of_blob](https://www.reddit.com/r/3Dprinting/comments/1ep28ld/update_i_have_become_brass_destroyer_of_blob)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T20:13:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ep28ld/update_i_have_become_brass_destroyer_of_blob/"> <img alt="Update: I have become brass, destroyer of blob." src="https://b.thumbs.redditmedia.com/n1zOizGoImaCJuJmjhRbIVlsT8SU0_UMbQg7Bl3ivww.jpg" title="Update: I have become brass, destroyer of blob." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>To all the people who offered advice and encouragement, thank you.</p> <p>Lessons learned:</p> <p>Watch the first few layers and check in frequently. Not sure how I'll know that I can have more confidence in it at any point, but maybe I'll just stay paranoid.</p> <p>Clean the plate.</p> <p>Watch the first few layers.</p> <p>Brass wire brushes are your friend, blobs foe, and an energized thermistor wire's &quot;enemy of my enemy.&quot;</p> <p>Heat guns get hot and wear my damn welding gloves. I got them for a reason.</p> <p>Watch the first few layers.</p> <p>Operator action is preferred to automatic system respo

## FV01 - The most advanced 3D printed RC Formula 1 car
 - [https://www.reddit.com/r/3Dprinting/comments/1ep2473/fv01_the_most_advanced_3d_printed_rc_formula_1_car](https://www.reddit.com/r/3Dprinting/comments/1ep2473/fv01_the_most_advanced_3d_printed_rc_formula_1_car)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T20:08:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ep2473/fv01_the_most_advanced_3d_printed_rc_formula_1_car/"> <img alt="FV01 - The most advanced 3D printed RC Formula 1 car" src="https://b.thumbs.redditmedia.com/n0qxNjPZ53dqs4fqEVdIECxbrHniCV3Eii6gIEKe4gw.jpg" title="FV01 - The most advanced 3D printed RC Formula 1 car" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This summer, we finished FV01, our first car project.</p> <p>We have designed the most advanced model of a Formula 1 car for 3D printing (which also drives). Below we upload pictures where you can see the fully independent suspension, designed based on real suspensions. The model also has a differential, which helps with handling. The model measures 73 cm long in approximately 1:7 scale.</p> <p>We also tried to reproduce the whole body and aero parts as much as possible, taking the RB16b car from 2021 as our reference model.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.

## Made something for Dummy 13 to sit
 - [https://www.reddit.com/r/3Dprinting/comments/1eozwfj/made_something_for_dummy_13_to_sit](https://www.reddit.com/r/3Dprinting/comments/1eozwfj/made_something_for_dummy_13_to_sit)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T18:28:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eozwfj/made_something_for_dummy_13_to_sit/"> <img alt="Made something for Dummy 13 to sit" src="https://b.thumbs.redditmedia.com/r-r6HIOqwtoKMmXvpuz5ZIHZb_BMByZKYYLcx9aDXbI.jpg" title="Made something for Dummy 13 to sit" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Wngwie"> /u/Wngwie </a> <br /> <span><a href="https://www.reddit.com/gallery/1eozwfj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eozwfj/made_something_for_dummy_13_to_sit/">[comments]</a></span> </td></tr></table>

## The amount of detail these things can show is stunning.
 - [https://www.reddit.com/r/3Dprinting/comments/1eozfud/the_amount_of_detail_these_things_can_show_is](https://www.reddit.com/r/3Dprinting/comments/1eozfud/the_amount_of_detail_these_things_can_show_is)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T18:08:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eozfud/the_amount_of_detail_these_things_can_show_is/"> <img alt="The amount of detail these things can show is stunning." src="https://preview.redd.it/3ndz00r5nvhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2734d404241f7abffb67d618388313a06d1028ab" title="The amount of detail these things can show is stunning." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I got an elegoo Neptune 3 pro a few weeks ago and decided to make a Deadpool mask/helmet for Halloween. This was the first piece. Plans off thingi with a head silhouette for sizing. Sliced with cura. Took about 12 hours. The lines aren't nearly as noticable in person. You would almost think this was a piece of leather.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rocket3431"> /u/Rocket3431 </a> <br /> <span><a href="https://i.redd.it/3ndz00r5nvhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.re

## How would i go about printing a complex 3D object like this one? Simplify it siginificantly? Print it in multiple parts so i have a even surface for every print? Just use a bunch of support?
 - [https://www.reddit.com/r/3Dprinting/comments/1eoz84s/how_would_i_go_about_printing_a_complex_3d_object](https://www.reddit.com/r/3Dprinting/comments/1eoz84s/how_would_i_go_about_printing_a_complex_3d_object)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T17:59:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoz84s/how_would_i_go_about_printing_a_complex_3d_object/"> <img alt="How would i go about printing a complex 3D object like this one? Simplify it siginificantly? Print it in multiple parts so i have a even surface for every print? Just use a bunch of support? " src="https://preview.redd.it/vrd9xfs8lvhd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=246bdbce3d3c48ce926f5385bebfdba608849e92" title="How would i go about printing a complex 3D object like this one? Simplify it siginificantly? Print it in multiple parts so i have a even surface for every print? Just use a bunch of support? " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Wedupa"> /u/Wedupa </a> <br /> <span><a href="https://i.redd.it/vrd9xfs8lvhd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoz84s/how_would_i_go_about_printing_a_complex_3d_object/">[comments]</a></span> <

## Regular PETG settings vs 100% infill aka gummybear mode
 - [https://www.reddit.com/r/3Dprinting/comments/1eoz1yo/regular_petg_settings_vs_100_infill_aka_gummybear](https://www.reddit.com/r/3Dprinting/comments/1eoz1yo/regular_petg_settings_vs_100_infill_aka_gummybear)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T17:51:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoz1yo/regular_petg_settings_vs_100_infill_aka_gummybear/"> <img alt="Regular PETG settings vs 100% infill aka gummybear mode" src="https://preview.redd.it/unuejh08kvhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d1c1da7855065faaecebdbab322bb449f5280f92" title="Regular PETG settings vs 100% infill aka gummybear mode" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I recently got some transparent PETG and after printing the first cali dragon on the left with standard settings I wanted to see what it would look like with 100% infill. I printed really slow like 10mm/s and bumped temp up to the maximum of the range on the roll. Left dragon has 10 or 15% infill and weighs around 5g and right one 10g. Printing time went from 55min to 3 hours. Ender 3 pro and the filament is atomic filament transparent aqua PETG</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rudd_Threebe

## Hi I'm new and I print Skulls!
 - [https://www.reddit.com/r/3Dprinting/comments/1eoxk1d/hi_im_new_and_i_print_skulls](https://www.reddit.com/r/3Dprinting/comments/1eoxk1d/hi_im_new_and_i_print_skulls)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T16:47:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoxk1d/hi_im_new_and_i_print_skulls/"> <img alt="Hi I'm new and I print Skulls!" src="https://b.thumbs.redditmedia.com/q_JyS0RkgSau9eHvzJgvE500cBPuVaKlz1Tmx3dtEKg.jpg" title="Hi I'm new and I print Skulls!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I've been working on this Allosaurus skull for a little while now and thought you all would enjoy! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TunderMuffins"> /u/TunderMuffins </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoxk1d">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoxk1d/hi_im_new_and_i_print_skulls/">[comments]</a></span> </td></tr></table>

## It’s niche but I like making keychains apparently - Been printing some the last few days and it’s oddly satisfying :)
 - [https://www.reddit.com/r/3Dprinting/comments/1eoxgr7/its_niche_but_i_like_making_keychains_apparently](https://www.reddit.com/r/3Dprinting/comments/1eoxgr7/its_niche_but_i_like_making_keychains_apparently)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T16:43:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoxgr7/its_niche_but_i_like_making_keychains_apparently/"> <img alt="It’s niche but I like making keychains apparently - Been printing some the last few days and it’s oddly satisfying :) " src="https://b.thumbs.redditmedia.com/43lG7YZs-IoOylAaXPVNq1Ob2h7CSL7HTiGM1uP2Tfs.jpg" title="It’s niche but I like making keychains apparently - Been printing some the last few days and it’s oddly satisfying :) " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I will be printing a couple more. This made me realize that I have too many keys.. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Itz_Evolv"> /u/Itz_Evolv </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoxgr7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoxgr7/its_niche_but_i_like_making_keychains_apparently/">[comments]</a></span> </td></tr></table>

## Roman blind clips
 - [https://www.reddit.com/r/3Dprinting/comments/1eoxeub/roman_blind_clips](https://www.reddit.com/r/3Dprinting/comments/1eoxeub/roman_blind_clips)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T16:41:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoxeub/roman_blind_clips/"> <img alt="Roman blind clips" src="https://preview.redd.it/gh94cfwn7vhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aecbf9e7ee03cd85cb86a82240df04f926feac10" title="Roman blind clips" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Does anyone know how to find this on Thingiverse (or anywhere else where I could find a 3D design for this kind of clips)?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Misslyckande"> /u/Misslyckande </a> <br /> <span><a href="https://i.redd.it/gh94cfwn7vhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoxeub/roman_blind_clips/">[comments]</a></span> </td></tr></table>

## I need help ... Please
 - [https://www.reddit.com/r/3Dprinting/comments/1eovu89/i_need_help_please](https://www.reddit.com/r/3Dprinting/comments/1eovu89/i_need_help_please)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T15:33:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eovu89/i_need_help_please/"> <img alt="I need help ... Please" src="https://b.thumbs.redditmedia.com/MzomFCxI5XufpDVEg17LCv41QXPnagfr-Uz67-KBVNk.jpg" title="I need help ... Please" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'm pretty new to 3d printing, and tried to print a silhouette of a car. It came out okay but the finish on the top layer is fucked.</p> <p>I have noticed a similar issue on other prints as well with those big deep gashes on the skin, not just on the top layer.</p> <p>Any tips?</p> <p>I have since learned about top layers (it was set to zero) and ironing which I didn't use. Anything else you think I should try?</p> <p>I'm working with a sovol sv07 plus and cura</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Busy_Efficiency_8478"> /u/Busy_Efficiency_8478 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eovu89">[link]</a></span> &#32; <sp

## Help turn my baby's favorite toy car print into a 3D model
 - [https://www.reddit.com/r/3Dprinting/comments/1eouu79/help_turn_my_babys_favorite_toy_car_print_into_a](https://www.reddit.com/r/3Dprinting/comments/1eouu79/help_turn_my_babys_favorite_toy_car_print_into_a)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T14:50:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eouu79/help_turn_my_babys_favorite_toy_car_print_into_a/"> <img alt="Help turn my baby's favorite toy car print into a 3D model" src="https://b.thumbs.redditmedia.com/pMJPSjrIl0DGvak0DxfAJU_RuKKxxTNZEGvANvwDELU.jpg" title="Help turn my baby's favorite toy car print into a 3D model" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>There's something special about this toy car print on my 4-month-old baby's pillow. Even when he's upset, it catches his attention, and he stops crying just to stare at it with such fascination. Of course, at his age, he can't recognize it as a car—it's likely the bright colors and the playful, cartoonish design that captivate him. </p> <p>It would mean the world to me if this could become a real toy car for him, with the same whimsical appearance. I'm looking for someone to help me bring this to life by creating a 3D model that I could order a print for, and assemble myself. The size 

## Got a new printer at work. (AUDIO WARNING)
 - [https://www.reddit.com/r/3Dprinting/comments/1eoug3j/got_a_new_printer_at_work_audio_warning](https://www.reddit.com/r/3Dprinting/comments/1eoug3j/got_a_new_printer_at_work_audio_warning)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T14:32:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoug3j/got_a_new_printer_at_work_audio_warning/"> <img alt="Got a new printer at work. (AUDIO WARNING)" src="https://external-preview.redd.it/Y2xmbGt5N3BrdWhkMcdzJFd8tuVLX6D7usnBNTeZ1bQcakRAYB5rwAFMc0D7.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c121d87d36720717f6ea62e9ab60b4be4abe1872" title="Got a new printer at work. (AUDIO WARNING)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>CreatBot D600 Pro 2. We also have a D1000 coming in within a few weeks. This printer is 600mm<sup>3</sup> while the D1000 is a full meter cubed! Supposedly we will own the very first D1000 in the U.S.. </p> <p>The benchy actually came out really good considering I sliced it with .4mm nozzle settings instead of the .6mm that was installed on it.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yohobo78"> /u/yohobo78 </a> <br /> <span><a href="https://v.redd.it/d41v0pdpkuhd1">[link]</a></s

## Did a 3D scan of a house and left a little souvenir for the owners
 - [https://www.reddit.com/r/3Dprinting/comments/1eouczw/did_a_3d_scan_of_a_house_and_left_a_little](https://www.reddit.com/r/3Dprinting/comments/1eouczw/did_a_3d_scan_of_a_house_and_left_a_little)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T14:28:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eouczw/did_a_3d_scan_of_a_house_and_left_a_little/"> <img alt="Did a 3D scan of a house and left a little souvenir for the owners" src="https://b.thumbs.redditmedia.com/Lw2BTBc4smQLknpKBvDQt_vW3ESVxye5zPR7rwG7oeo.jpg" title="Did a 3D scan of a house and left a little souvenir for the owners" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zeltkind"> /u/Zeltkind </a> <br /> <span><a href="https://www.reddit.com/gallery/1eouczw">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eouczw/did_a_3d_scan_of_a_house_and_left_a_little/">[comments]</a></span> </td></tr></table>

## Some dinosaur paper clips :D
 - [https://www.reddit.com/r/3Dprinting/comments/1eoqpnx/some_dinosaur_paper_clips_d](https://www.reddit.com/r/3Dprinting/comments/1eoqpnx/some_dinosaur_paper_clips_d)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T11:23:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoqpnx/some_dinosaur_paper_clips_d/"> <img alt="Some dinosaur paper clips :D" src="https://b.thumbs.redditmedia.com/f-gRVW33uKseoIJnqSc_JymklMw7MfuCEh-WpFr9G_o.jpg" title="Some dinosaur paper clips :D" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/viirus42"> /u/viirus42 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoqpnx">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoqpnx/some_dinosaur_paper_clips_d/">[comments]</a></span> </td></tr></table>

## First print multicolor
 - [https://www.reddit.com/r/3Dprinting/comments/1eoqmiw/first_print_multicolor](https://www.reddit.com/r/3Dprinting/comments/1eoqmiw/first_print_multicolor)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T11:18:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoqmiw/first_print_multicolor/"> <img alt="First print multicolor" src="https://preview.redd.it/tpoiw6t0mthd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=95ad9e0b2500cffc6ef8bee885a12e47692cc562" title="First print multicolor" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>yesterday the ams arrived and I mounted it today I did the first test, his name is Jeff</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/paul_room"> /u/paul_room </a> <br /> <span><a href="https://i.redd.it/tpoiw6t0mthd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoqmiw/first_print_multicolor/">[comments]</a></span> </td></tr></table>

## Exhausting fumes through bathroom ceiling vent
 - [https://www.reddit.com/r/3Dprinting/comments/1eoqfl0/exhausting_fumes_through_bathroom_ceiling_vent](https://www.reddit.com/r/3Dprinting/comments/1eoqfl0/exhausting_fumes_through_bathroom_ceiling_vent)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T11:06:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoqfl0/exhausting_fumes_through_bathroom_ceiling_vent/"> <img alt="Exhausting fumes through bathroom ceiling vent" src="https://a.thumbs.redditmedia.com/fIFZixWq8GoSo43AwHcIrovN54ySYHpfXCigPXKF6Y0.jpg" title="Exhausting fumes through bathroom ceiling vent" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hi, i want to buy a bambulab p1s ams combo but i am worried about the fumes. I want to vent them outside but the windows in my apartment don’t open so i want to vent them out of the ceiling fan in a spare toilet that no one uses. </p> <p>The vent does not have a fan.</p> <p>Questions: How can i attach the tube from the enclosure to the ceiling vent?</p> <p>Will a small fan that comes with the enclosure be enough?</p> <p>Is this a good idea?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ranimtor345"> /u/Ranimtor345 </a> <br /> <span><a href="https://www.reddit.com/gallery

## Balrog Lamp
 - [https://www.reddit.com/r/3Dprinting/comments/1eoq3xf/balrog_lamp](https://www.reddit.com/r/3Dprinting/comments/1eoq3xf/balrog_lamp)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T10:46:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoq3xf/balrog_lamp/"> <img alt="Balrog Lamp" src="https://b.thumbs.redditmedia.com/Jo3jV3ZzHvuf5S4Fi51hfDzNlEgD3kjDT7IefkTW9mQ.jpg" title="Balrog Lamp" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>A while ago i made this roughly 1/8 Lamp of the Battle between the Balrog and Gandalf. I just modfied the files for this, to fit the electronics. The On Switch is underneath one of the rocks on Gandalfs Side. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/c4ntstoptherock"> /u/c4ntstoptherock </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoq3xf">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoq3xf/balrog_lamp/">[comments]</a></span> </td></tr></table>

## Hexagons Are The Bestigons!
 - [https://www.reddit.com/r/3Dprinting/comments/1eoikhm/hexagons_are_the_bestigons](https://www.reddit.com/r/3Dprinting/comments/1eoikhm/hexagons_are_the_bestigons)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T02:52:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eoikhm/hexagons_are_the_bestigons/"> <img alt="Hexagons Are The Bestigons!" src="https://b.thumbs.redditmedia.com/TLGzt20YX_Co1HjQALR95L82uQHaIs3dYhHgJMSNpfo.jpg" title="Hexagons Are The Bestigons!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>We had an almighty hailstorm.</p> <p>$500+ for a new shroud for the AC unit on the top of my trailer.</p> <p>...or spark up the Solidoodle ][ and get printing...</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mr_thwibble"> /u/mr_thwibble </a> <br /> <span><a href="https://www.reddit.com/gallery/1eoikhm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eoikhm/hexagons_are_the_bestigons/">[comments]</a></span> </td></tr></table>

## FYI: The "12-Gal. Professional Heavy Duty Waterproof Stackable Plastic Storage Container with Hinged Lid in Red" is only $28 at Home Depot and can perfectly fit 15 1kg rolls.
 - [https://www.reddit.com/r/3Dprinting/comments/1eogsjr/fyi_the_12gal_professional_heavy_duty_waterproof](https://www.reddit.com/r/3Dprinting/comments/1eogsjr/fyi_the_12gal_professional_heavy_duty_waterproof)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-08-10T01:21:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eogsjr/fyi_the_12gal_professional_heavy_duty_waterproof/"> <img alt="FYI: The &quot;12-Gal. Professional Heavy Duty Waterproof Stackable Plastic Storage Container with Hinged Lid in Red&quot; is only $28 at Home Depot and can perfectly fit 15 1kg rolls." src="https://preview.redd.it/cj2835vjnqhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2f5b35f2d76c5c1b149d92df03d8949a60d7fe2f" title="FYI: The &quot;12-Gal. Professional Heavy Duty Waterproof Stackable Plastic Storage Container with Hinged Lid in Red&quot; is only $28 at Home Depot and can perfectly fit 15 1kg rolls." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/shaunsanders"> /u/shaunsanders </a> <br /> <span><a href="https://i.redd.it/cj2835vjnqhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eogsjr/fyi_the_12gal_professional_heavy_duty_waterproof/">[comments]</a></span> </t

