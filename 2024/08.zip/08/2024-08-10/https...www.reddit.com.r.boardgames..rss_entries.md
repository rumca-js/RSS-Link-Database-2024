# Source:boardgames, URL:https://www.reddit.com/r/boardgames/.rss, language:en

## Bananagrams
 - [https://www.reddit.com/r/boardgames/comments/1ep61bj/bananagrams](https://www.reddit.com/r/boardgames/comments/1ep61bj/bananagrams)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T23:09:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/boardgames/comments/1ep61bj/bananagrams/"> <img alt="Bananagrams " src="https://preview.redd.it/6lb2nk4v4xhd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b635131a32446863ae8801dbabe8ba6742c0a524" title="Bananagrams " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Is this allowed? I can’t find anything that gives me a clear answer. (Talking about the left side of the image where the words are “bunched”)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RegionPresent2814"> /u/RegionPresent2814 </a> <br /> <span><a href="https://i.redd.it/6lb2nk4v4xhd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep61bj/bananagrams/">[comments]</a></span> </td></tr></table>

## Deborah Ann Woll Teaches Jon Bernthal Dungeons and Dragons
 - [https://www.reddit.com/r/boardgames/comments/1ep4taa/deborah_ann_woll_teaches_jon_bernthal_dungeons](https://www.reddit.com/r/boardgames/comments/1ep4taa/deborah_ann_woll_teaches_jon_bernthal_dungeons)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T22:11:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/boardgames/comments/1ep4taa/deborah_ann_woll_teaches_jon_bernthal_dungeons/"> <img alt="Deborah Ann Woll Teaches Jon Bernthal Dungeons and Dragons" src="https://external-preview.redd.it/0kqcUUk5eW_8BNsRAO-RdrtART3Y40iKLE2OmHtcX4k.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=a1c3df0f6d65c1a95dfe5aed68338f6995183244" title="Deborah Ann Woll Teaches Jon Bernthal Dungeons and Dragons" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NakedCardboard"> /u/NakedCardboard </a> <br /> <span><a href="https://www.youtube.com/watch?v=JpVJZrabMQE">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep4taa/deborah_ann_woll_teaches_jon_bernthal_dungeons/">[comments]</a></span> </td></tr></table>

## Betrayal deck of lost souls
 - [https://www.reddit.com/r/boardgames/comments/1ep3e4g/betrayal_deck_of_lost_souls](https://www.reddit.com/r/boardgames/comments/1ep3e4g/betrayal_deck_of_lost_souls)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T21:06:46+00:00

<!-- SC_OFF --><div class="md"><p>So I just got this game and watched some videos and read through the rule book but I’m confused on when you play an omen card and you don’t have a item on hand to beat it do I fail to beat it. It’s hard to put into words but when I place an omen only I can defeat that omen correct? But I can trade item cards with players to get the cards I need to beat it. I’m confused on when do you say you failed to beat the omen whenever it comes back around to my turn and I still don’t have the items to beat it? How many turns do I have till I fail to beat it? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Abject-Price-2261"> /u/Abject-Price-2261 </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1ep3e4g/betrayal_deck_of_lost_souls/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep3e4g/betrayal_deck_of_lost_souls/">[comments]</a></span>

## How to value rarer Oink Games entries?
 - [https://www.reddit.com/r/boardgames/comments/1ep2t1r/how_to_value_rarer_oink_games_entries](https://www.reddit.com/r/boardgames/comments/1ep2t1r/how_to_value_rarer_oink_games_entries)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T20:39:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/boardgames/comments/1ep2t1r/how_to_value_rarer_oink_games_entries/"> <img alt="How to value rarer Oink Games entries?" src="https://a.thumbs.redditmedia.com/nTMjKkK489TgQuJaaTBD3mc8Xog54FcBsALyqQ96uu0.jpg" title="How to value rarer Oink Games entries?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Essentially, I have an assortment or rarer Oink Games entries. I’m having a lot of trouble finding anybody selling/anyone who has bought these games and as such have no idea as to their value. Was hoping someone may recognize them and would be able to give a rough evaluation of what they are and what they are worth. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PassivelyMassive"> /u/PassivelyMassive </a> <br /> <span><a href="https://www.reddit.com/gallery/1ep2t1r">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep2t1r/how_to_value_rarer_oink_games_entries/"

## Looking to get into Clank! (Not the usual question)
 - [https://www.reddit.com/r/boardgames/comments/1ep2r43/looking_to_get_into_clank_not_the_usual_question](https://www.reddit.com/r/boardgames/comments/1ep2r43/looking_to_get_into_clank_not_the_usual_question)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T20:37:08+00:00

<!-- SC_OFF --><div class="md"><p>Hi all!</p> <p>As the title suggests, I'm looking to get into Clank! but funds are limited. I've read all the back and forth about OG vs. Catacombs. I'm leaving Legacy out because I don't like legacy games, and leaving in Space out due to my wife preferring fantasy settings. So, it's down between OG and Catacombs for me.</p> <p>That leads me to my actual question:</p> <p>Which version has the lesser setup time? I prefer quicker setups, because nothing can kill the mood quicker than a long setup. So, I'm looking for advice on that aspect od the game.</p> <p>Thanks in advance!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bill_The_Gorilla"> /u/Bill_The_Gorilla </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1ep2r43/looking_to_get_into_clank_not_the_usual_question/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep2r43/looking_to_get_into_clank_not_the_

## Zatu Games
 - [https://www.reddit.com/r/boardgames/comments/1ep2nab/zatu_games](https://www.reddit.com/r/boardgames/comments/1ep2nab/zatu_games)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T20:32:16+00:00

<!-- SC_OFF --><div class="md"><p>Hey guys! Has anyone used Zatu games before for their board game collection? I used them for the first time early this morning and I’m a little worried as it was a big order and although the money has left my account for my order it says “awaiting payment” on my Zatu order. Is this just like a standard thing they do to everyone or is there an issue? I’ve been trying to get hold of them all day but it’s easier to get blood from a stone on a weekend lol thanks guys! (P.S I’m new here, I hope this post is ok). </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DosssingBoss"> /u/DosssingBoss </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1ep2nab/zatu_games/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep2nab/zatu_games/">[comments]</a></span>

## Is there a proper term for a "Help an opponent to help yourself" mechanic?
 - [https://www.reddit.com/r/boardgames/comments/1ep2630/is_there_a_proper_term_for_a_help_an_opponent_to](https://www.reddit.com/r/boardgames/comments/1ep2630/is_there_a_proper_term_for_a_help_an_opponent_to)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T20:10:29+00:00

<!-- SC_OFF --><div class="md"><p>After playing a game of Marvel Villainous recently, I got thinking about a mechanic I've seen in a few board games that goes like this:</p> <ol> <li><p>You do something, whether that be a card play, character ability, or whatever, that forcibly causes an exchange either now or later that is mutually beneficial to both parties.</p></li> <li><p>The exchange doesn't have to necessarily be equal, but it can't be actively negative to the other player (As in, simply stealing resources or cards).</p></li> <li><p>It has to be a tangible benefit toward the game state for both players. No &quot;we're both at peace&quot; or something, but more like &quot;You can now draw an extra card, but every time you do, I get a VP!&quot;</p> <p>Here's the examples I usually think about:</p></li> <li><p>In Marvel Villainous, Loki's gameplay is all about this. He can place &quot;Multiverse&quot; cards onto other players' boards. These cards always provide a benefit to the pla

## Which unpopular board game do you still enjoy playing if given the chance?
 - [https://www.reddit.com/r/boardgames/comments/1ep1jt8/which_unpopular_board_game_do_you_still_enjoy](https://www.reddit.com/r/boardgames/comments/1ep1jt8/which_unpopular_board_game_do_you_still_enjoy)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T19:42:37+00:00

<!-- SC_OFF --><div class="md"><p>Mine would be Munchkin. The sentiment towards it seems to be mostly negative, but if someone wanted to play, I would definitely be down for some goofy take-that action. Even though it can get nasty at the end, the RPG references always get a good laugh.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Just_Anxiety"> /u/Just_Anxiety </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1ep1jt8/which_unpopular_board_game_do_you_still_enjoy/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep1jt8/which_unpopular_board_game_do_you_still_enjoy/">[comments]</a></span>

## Has anyone played the Freeform Murder Mystery games?
 - [https://www.reddit.com/r/boardgames/comments/1ep0h8x/has_anyone_played_the_freeform_murder_mystery](https://www.reddit.com/r/boardgames/comments/1ep0h8x/has_anyone_played_the_freeform_murder_mystery)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T18:54:04+00:00

<!-- SC_OFF --><div class="md"><p>I was also looking into freeform. I'm pretty sure the host cannot play and I'm wonder on the difficulty for anyone that has played one of these. I looked at their free download, which wouldn't work for our numbers, but it looks quite stressful for the host. We do some pretty RP heavy D&amp;D so I think it could be fun, but I'd be soooo afraid of forgetting a clue or something. So I'd be interested in opinions.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Catface_Meowmer"> /u/Catface_Meowmer </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1ep0h8x/has_anyone_played_the_freeform_murder_mystery/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1ep0h8x/has_anyone_played_the_freeform_murder_mystery/">[comments]</a></span>

## Scoring in Forest Shuffle
 - [https://www.reddit.com/r/boardgames/comments/1eozb2w/scoring_in_forest_shuffle](https://www.reddit.com/r/boardgames/comments/1eozb2w/scoring_in_forest_shuffle)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T18:02:18+00:00

<!-- SC_OFF --><div class="md"><p>So me and my gf just played a game of Forest Shuffle with Alpine expansion and tried counting points with this github link we found online: (<a href="https://soldag.github.io/forest-shuffle-scoring/#/forest">https://soldag.github.io/forest-shuffle-scoring/#/forest</a>) First of all the question is if the Snow Hare is allowed to the left of two European Hares. The github form doesn't allow me to.</p> <p>Secondly, my gf placed two Carpenter Bees on a sycamore (left and right). Thinking that this would 'add'two more Sycamores to her forest. The scoring form doesnt count it that way so i am at a loss.</p> <p>Anyone here able to help us?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/VulgairUnicorn"> /u/VulgairUnicorn </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eozb2w/scoring_in_forest_shuffle/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eozb2w/sc

## Designer that suits your taste perfectly?
 - [https://www.reddit.com/r/boardgames/comments/1eoypwy/designer_that_suits_your_taste_perfectly](https://www.reddit.com/r/boardgames/comments/1eoypwy/designer_that_suits_your_taste_perfectly)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T17:37:01+00:00

<!-- SC_OFF --><div class="md"><p>Have you found a game designer who ticks all your boxes for what you like in games? For me it’s Cole Wehrle. All of his games I’ve fallen in love with being mean political games with king making and emergent storytelling + at times a historical focus. What designers/developers make games that feel tailor made for you?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ThatOneRandomGuy101"> /u/ThatOneRandomGuy101 </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eoypwy/designer_that_suits_your_taste_perfectly/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eoypwy/designer_that_suits_your_taste_perfectly/">[comments]</a></span>

## Did any of your create a group you play with or guide and teach?
 - [https://www.reddit.com/r/boardgames/comments/1eowxix/did_any_of_your_create_a_group_you_play_with_or](https://www.reddit.com/r/boardgames/comments/1eowxix/did_any_of_your_create_a_group_you_play_with_or)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T16:20:47+00:00

<!-- SC_OFF --><div class="md"><p>The question in the title can be a bit misleading, so let me explain here.</p> <p>Did any of you, or someone you know, started a group for board games? I mean one built not with the people who were already your friends and/or family, but rather a group made up of strangers that you met, and taught or guided them with board games. Or even just met strangers that already played games.</p> <p>If yes, how did you do that? How did you reach out? How was the reception to your inquiry? How many were you able to get to join? How many stayed? What are the ages of those who stayed? What are the rules for your group? How frequently do you meet? What type of relationship do you have with the members of the group? </p> <p>I know that's a lot of questions, but my wife and I are looking to create a group, and while we know to do our own research, it's is always beneficial to look to those who have already done it and see how they did that.</p> <p>Would love to hear 

## Recommended Backgammon apps to learn the game
 - [https://www.reddit.com/r/boardgames/comments/1eowwji/recommended_backgammon_apps_to_learn_the_game](https://www.reddit.com/r/boardgames/comments/1eowwji/recommended_backgammon_apps_to_learn_the_game)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T16:19:38+00:00

<!-- SC_OFF --><div class="md"><p>Hello, I want to learn how to play backgammon using a backgammon app. There are so many in the App Store. Any recommendations for a good one to learn the game. I’ve never played and want to entertain a friend in the hospital. I need to learn the basic strategy at least. Thank you in advance for your time. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ElusiveBabe"> /u/ElusiveBabe </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eowwji/recommended_backgammon_apps_to_learn_the_game/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eowwji/recommended_backgammon_apps_to_learn_the_game/">[comments]</a></span>

## ‘Anti-war wargame’ Chicago ’68 is an impeccably timed board game
 - [https://www.reddit.com/r/boardgames/comments/1eowo7g/antiwar_wargame_chicago_68_is_an_impeccably_timed](https://www.reddit.com/r/boardgames/comments/1eowo7g/antiwar_wargame_chicago_68_is_an_impeccably_timed)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T16:09:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/boardgames/comments/1eowo7g/antiwar_wargame_chicago_68_is_an_impeccably_timed/"> <img alt="‘Anti-war wargame’ Chicago ’68 is an impeccably timed board game" src="https://external-preview.redd.it/vXd9emjd2t9onJCPIxwhu4WDNzUZYkXfbwhA0J5U3Y0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4ba2eec600198c9aa2fbcbea079b0f41dbcac978" title="‘Anti-war wargame’ Chicago ’68 is an impeccably timed board game" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/chicagojoon"> /u/chicagojoon </a> <br /> <span><a href="https://www.polygon.com/24213917/chicago-68-board-game-kickstarter-preview-interview">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eowo7g/antiwar_wargame_chicago_68_is_an_impeccably_timed/">[comments]</a></span> </td></tr></table>

## what events (other than open play game night) can my uni boardgames club host?
 - [https://www.reddit.com/r/boardgames/comments/1eouttf/what_events_other_than_open_play_game_night_can](https://www.reddit.com/r/boardgames/comments/1eouttf/what_events_other_than_open_play_game_night_can)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T14:49:52+00:00

<!-- SC_OFF --><div class="md"><p>Hi! So I'm part of the organizing committee for the Boardgames and TTRPG club at my university. We hold game nights once a week, but we also want to think of other types of events we could hold for the boardgames side of things (with TTRPG this is easier). </p> <p>If anybody has ideas or suggestions, please comment! It would be a huge help.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/puddinghoax"> /u/puddinghoax </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eouttf/what_events_other_than_open_play_game_night_can/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eouttf/what_events_other_than_open_play_game_night_can/">[comments]</a></span>

## Moonrakers - Titan, worth it?
 - [https://www.reddit.com/r/boardgames/comments/1eopotu/moonrakers_titan_worth_it](https://www.reddit.com/r/boardgames/comments/1eopotu/moonrakers_titan_worth_it)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T10:18:01+00:00

<!-- SC_OFF --><div class="md"><p>Hi, I tried <a href="https://kallax.io/game/BUVWF-Moonrakers">Moonrakers</a> at a friend's house and instantly feel in love with it.</p> <p>Is it worth getting the Titan Big Box? It's a bit expensive but also includes a lot of expansions. Anyone with the game that can tell me if they add a lot of value or can be skipped? My friend only have the base game.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Thor6Throne"> /u/Thor6Throne </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eopotu/moonrakers_titan_worth_it/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eopotu/moonrakers_titan_worth_it/">[comments]</a></span>

## I recently bought 7 wonders, should I buy any expansions, and if so, which ones?
 - [https://www.reddit.com/r/boardgames/comments/1eooas1/i_recently_bought_7_wonders_should_i_buy_any](https://www.reddit.com/r/boardgames/comments/1eooas1/i_recently_bought_7_wonders_should_i_buy_any)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T08:41:25+00:00

<!-- SC_OFF --><div class="md"><p>Body text</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Alphahaukdaboss"> /u/Alphahaukdaboss </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eooas1/i_recently_bought_7_wonders_should_i_buy_any/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eooas1/i_recently_bought_7_wonders_should_i_buy_any/">[comments]</a></span>

## What's your worst board game loss, as in where you've physically lost the box and components?
 - [https://www.reddit.com/r/boardgames/comments/1eonwgs/whats_your_worst_board_game_loss_as_in_where](https://www.reddit.com/r/boardgames/comments/1eonwgs/whats_your_worst_board_game_loss_as_in_where)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T08:13:00+00:00

<!-- SC_OFF --><div class="md"><p>I was wondering what everyone's worst time where they've lost a board game, as in the actual physical box and components? I've just had my suitcase lost by an airline and it was full of all my new solo games as well as some other games I got for my birthday, so now I'm in the dilemma of hoping they find it quickly!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tornroot"> /u/Tornroot </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eonwgs/whats_your_worst_board_game_loss_as_in_where/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eonwgs/whats_your_worst_board_game_loss_as_in_where/">[comments]</a></span>

## Help me find this board game please
 - [https://www.reddit.com/r/boardgames/comments/1eon4j4/help_me_find_this_board_game_please](https://www.reddit.com/r/boardgames/comments/1eon4j4/help_me_find_this_board_game_please)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T07:20:09+00:00

<!-- SC_OFF --><div class="md"><p>Hi, not sure if this is the right sub to post in but I’m looking for a board game. I remember playing it a few years ago but cannot find it online to buy now.</p> <p>It was scrabble but you were able to ‘steal’ words by placing a letter on top, and you’d get the points of the words below.</p> <p>I think it was similar to Upwords but it was official scrabble. </p> <p>I want to buy it for my friend so any help would be greatly appreciated, thanks! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mountain-Dirt-5156"> /u/Mountain-Dirt-5156 </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eon4j4/help_me_find_this_board_game_please/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eon4j4/help_me_find_this_board_game_please/">[comments]</a></span>

## Childhood card/board game?
 - [https://www.reddit.com/r/boardgames/comments/1eon2hm/childhood_cardboard_game](https://www.reddit.com/r/boardgames/comments/1eon2hm/childhood_cardboard_game)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T07:16:19+00:00

<!-- SC_OFF --><div class="md"><p>Hey all,</p> <p>Wondering if anyone can help me. I have vague memories of a card/board game that I used to play as a child (20+ years ago). Trying to see if the game is still around but can’t figure out what it was called. I can’t remember much but think it was a card game. The main detail I remember is that each player got some lives which was a little plastic rectangle with some little men that were standing up. Then when you lost the round, you had to push one of the men over. Very vague I know! But if anyone has any ideas on what this game was called I’d love to know! </p> <p>Thanks!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Kiwi_Adventurer"> /u/Kiwi_Adventurer </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eon2hm/childhood_cardboard_game/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eon2hm/childhood_cardboard_game/">[comments]</a></span

## What is your favorite theme?
 - [https://www.reddit.com/r/boardgames/comments/1eomwqg/what_is_your_favorite_theme](https://www.reddit.com/r/boardgames/comments/1eomwqg/what_is_your_favorite_theme)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T07:05:58+00:00

<!-- SC_OFF --><div class="md"><p>As the title says.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SandCheezy"> /u/SandCheezy </a> <br /> <span><a href="https://www.reddit.com/r/boardgames/comments/1eomwqg/what_is_your_favorite_theme/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/boardgames/comments/1eomwqg/what_is_your_favorite_theme/">[comments]</a></span>

## Daily Game Recommendations Thread (August 10, 2024)
 - [https://www.reddit.com/r/boardgames/comments/1eokwpf/daily_game_recommendations_thread_august_10_2024](https://www.reddit.com/r/boardgames/comments/1eokwpf/daily_game_recommendations_thread_august_10_2024)
 - RSS feed: https://www.reddit.com/r/boardgames/.rss
 - date published: 2024-08-10T05:01:08+00:00

<!-- SC_OFF --><div class="md"><p><strong>Welcome to <a href="/r/boardgames">/r/boardgames</a>'s Daily Game Recommendations</strong></p> <p>This is a place where you can ask any and all questions relating to the board gaming world including but not limited to<a href="https://en.wiktionary.org/wiki/meeple#/media/File:Carcassonne_Miples.jpg">:</a></p> <ul> <li>general or specific game recommendations</li> <li>help identifying a game or game piece</li> <li>advice regarding situation limited to you (e.g, questions about a specific FLGS)</li> <li>rule clarifications</li> <li>and other quick questions that might not warrant their own post</li> </ul> <h2>Asking for Recommendations</h2> <p>You're much more likely to get good and personalized recommendations if you take the time to format a well-written ask. We <strong>highly recommend</strong> using <a href="/r/boardgames/wiki/personalized-game-recommendation-template-no-explainer">this template</a> as a guide. <a href="/r/boardgames/wiki/per

