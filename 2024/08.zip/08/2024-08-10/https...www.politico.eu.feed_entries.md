# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## Puigdemont says he’s back in Belgium, as Catalonia welcomes new president
 - [https://www.politico.eu/article/puigdemont-says-hes-back-in-belgium-as-catalonia-welcomes-new-president/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/puigdemont-says-hes-back-in-belgium-as-catalonia-welcomes-new-president/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-10T15:52:18+00:00

The former Catalan leader accused the Spanish government of not letting him exercise his "right to speak and vote."

## Judge OKs delay in Trump election-subversion case
 - [https://www.politico.com/news/2024/08/09/trump-election-case-special-counsel-delay-00173469?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/08/09/trump-election-case-special-counsel-delay-00173469?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-10T13:15:46+00:00

Jack Smith told Judge Tanya Chutkan that he needs more time to analyze the Supreme Court’s ruling on Trump’s immunity.

## Israeli strike on Gaza school reportedly kills at least 90 civilians
 - [https://www.politico.eu/article/israeli-strike-on-gaza-school-reportedly-kills-at-least-90-civilians/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israeli-strike-on-gaza-school-reportedly-kills-at-least-90-civilians/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-10T11:15:29+00:00

Israel's military said it struck an “active” Hamas command center in the attack, which came during dawn prayers at the school.

## Russia rushes reinforcements to border regions raided by Ukraine
 - [https://www.politico.eu/article/russia-takes-emergency-measures-in-border-regions/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/russia-takes-emergency-measures-in-border-regions/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-10T09:58:06+00:00

Moscow is trying to repulse Kyiv's biggest cross-border ground offensive since Russia's invasion.

## What the US Supreme Court left unsaid about Trump’s criminal immunity
 - [https://www.politico.com/news/2024/08/09/supreme-court-trump-immunity-muddle-00173375?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/08/09/supreme-court-trump-immunity-muddle-00173375?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-10T08:17:07+00:00

The federal election case has returned to the trial court. Now comes the hard part.

## World’s cartoonists on this week’s events
 - [https://www.politico.eu/article/worlds-cartoonists-on-this-weeks-events-130/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/worlds-cartoonists-on-this-weeks-events-130/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-08-10T02:01:00+00:00

Drawing the top stories around the globe.

