# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed, language:en-US

## Judges Back Meta in Vaccine “Misinformation” Battle, Free Speech Advocates Vow to Fight On
 - [https://reclaimthenet.org/judges-back-meta-in-vaccine-misinformation-battle-free-speech-advocates-vow-to-fight-on](https://reclaimthenet.org/judges-back-meta-in-vaccine-misinformation-battle-free-speech-advocates-vow-to-fight-on)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-08-10T16:47:09+00:00

<a href="https://reclaimthenet.org/judges-back-meta-in-vaccine-misinformation-battle-free-speech-advocates-vow-to-fight-on" rel="nofollow" title="Judges Back Meta in Vaccine &#8220;Misinformation&#8221; Battle, Free Speech Advocates Vow to Fight On"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/08/zuck-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Meta wins in court, but dissent raises alarm over government involvement in social media censorship.</p>
<p>The post <a href="https://reclaimthenet.org/judges-back-meta-in-vaccine-misinformation-battle-free-speech-advocates-vow-to-fight-on">Judges Back Meta in Vaccine &#8220;Misinformation&#8221; Battle, Free Speech Advocates Vow to Fight On</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Louisiana’s New Law Sparks First Amendment Showdown
 - [https://reclaimthenet.org/louisianas-new-law-sparks-first-amendment-showdown](https://reclaimthenet.org/louisianas-new-law-sparks-first-amendment-showdown)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-08-10T13:48:31+00:00

<a href="https://reclaimthenet.org/louisianas-new-law-sparks-first-amendment-showdown" rel="nofollow" title="Louisiana’s New Law Sparks First Amendment Showdown"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/08/la-cop-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Media companies sue Louisiana, arguing new law cripples police accountability and infringes on First Amendment rights.</p>
<p>The post <a href="https://reclaimthenet.org/louisianas-new-law-sparks-first-amendment-showdown">Louisiana’s New Law Sparks First Amendment Showdown</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Facebook Takes Sides in Olympic Gender Debate as #XX Hashtag is Blocked
 - [https://reclaimthenet.org/facebook-takes-sides-in-olympic-gender-debate-as-xx-hashtag-is-blocked](https://reclaimthenet.org/facebook-takes-sides-in-olympic-gender-debate-as-xx-hashtag-is-blocked)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-08-10T13:42:27+00:00

<a href="https://reclaimthenet.org/facebook-takes-sides-in-olympic-gender-debate-as-xx-hashtag-is-blocked" rel="nofollow" title="Facebook Takes Sides in Olympic Gender Debate as #XX Hashtag is Blocked"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/08/xx-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Facebook hides posts with viral #XX hashtag amid heated debate over gender eligibility in women's Olympic boxing.</p>
<p>The post <a href="https://reclaimthenet.org/facebook-takes-sides-in-olympic-gender-debate-as-xx-hashtag-is-blocked">Facebook Takes Sides in Olympic Gender Debate as #XX Hashtag is Blocked</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Starmer’s Push to Police “Fake News” Sparks Major Censorship Concerns
 - [https://reclaimthenet.org/starmers-push-to-police-fake-news-sparks-major-censorship-concerns](https://reclaimthenet.org/starmers-push-to-police-fake-news-sparks-major-censorship-concerns)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-08-10T13:25:39+00:00

<a href="https://reclaimthenet.org/starmers-push-to-police-fake-news-sparks-major-censorship-concerns" rel="nofollow" title="Starmer&#8217;s Push to Police &#8220;Fake News&#8221; Sparks Major Censorship Concerns"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/08/starmer-censp-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Proposed crackdown on misinformation raises alarm over creeping censorship and threats to free speech.</p>
<p>The post <a href="https://reclaimthenet.org/starmers-push-to-police-fake-news-sparks-major-censorship-concerns">Starmer&#8217;s Push to Police &#8220;Fake News&#8221; Sparks Major Censorship Concerns</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Free Speech is Under Siege in Starmer’s UK
 - [https://reclaimthenet.org/free-speech-is-under-siege-in-starmers-uk](https://reclaimthenet.org/free-speech-is-under-siege-in-starmers-uk)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-08-10T13:05:08+00:00

<a href="https://reclaimthenet.org/free-speech-is-under-siege-in-starmers-uk" rel="nofollow" title="Free Speech is Under Siege in Starmer&#8217;s UK"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/08/starmer-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>As the UK tightens online speech laws, critics warn of a growing threat to free expression and democratic oversight.</p>
<p>The post <a href="https://reclaimthenet.org/free-speech-is-under-siege-in-starmers-uk">Free Speech is Under Siege in Starmer&#8217;s UK</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

