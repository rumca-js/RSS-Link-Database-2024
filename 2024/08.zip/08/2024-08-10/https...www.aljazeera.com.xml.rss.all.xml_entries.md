# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Olympics: USA rack up relay golds; Barshim bows out with high jump bronze
 - [https://www.aljazeera.com/sports/2024/8/10/olympics-usa-rack-up-relay-golds-barshim-bows-out-with-high-jump-bronze?traffic_source=rss](https://www.aljazeera.com/sports/2024/8/10/olympics-usa-rack-up-relay-golds-barshim-bows-out-with-high-jump-bronze?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T23:21:26+00:00

USA win both 4x400m relay and men&#039;s 100m hurdles finals for their 14 athletics medal at Paris Olympics 2024.

## Canada’s B-Boy Phil Wizard wins first Olympic breaking gold in Paris
 - [https://www.aljazeera.com/sports/2024/8/10/canadas-b-boy-phil-wizard-wins-first-olympic-breaking-gold-in-paris?traffic_source=rss](https://www.aljazeera.com/sports/2024/8/10/canadas-b-boy-phil-wizard-wins-first-olympic-breaking-gold-in-paris?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T22:32:21+00:00

The Canadian beat France&#039;s Dany Dann in front of a partisan crowd to take the first-ever men&#039;s gold medal in breaking.

## Thousands protest in Serbia’s Belgrade against lithium mining project
 - [https://www.aljazeera.com/news/2024/8/10/thousands-protest-in-serbias-belgrade-against-lithium-mining-project?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/thousands-protest-in-serbias-belgrade-against-lithium-mining-project?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T20:17:43+00:00

Protesters say they fear project by mining giant Rio Tinto would pollute water sources and endanger public health.

## Kenya’s Faith Kipyegon wins 1500-metre final for record third Olympic gold
 - [https://www.aljazeera.com/sports/2024/8/10/kenyas-faith-kipyegon-wins-1500-metre-final-for-record-third-olympic-gold?traffic_source=rss](https://www.aljazeera.com/sports/2024/8/10/kenyas-faith-kipyegon-wins-1500-metre-final-for-record-third-olympic-gold?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T19:58:41+00:00

Kipyegon becomes the first athlete ever to win three back-to-back 1500m gold medals and sets new Olympic record time.

## What are the chances for renewed talks to end the Gaza war?
 - [https://www.aljazeera.com/program/inside-story/2024/8/10/what-are-the-chances-for-renewed-talks-to-end-the-gaza-war?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/8/10/what-are-the-chances-for-renewed-talks-to-end-the-gaza-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T19:00:27+00:00

Israel says it will attend as its forces kill more than 100 Palestinians in school attack.

## ‘I was ambushed’: Sinaloa cartel leader ‘El Mayo’ details capture
 - [https://www.aljazeera.com/news/2024/8/10/i-was-ambushed-sinaloa-drug-cartel-leader-el-mayo-details-capture?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/i-was-ambushed-sinaloa-drug-cartel-leader-el-mayo-details-capture?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T18:21:57+00:00

Ismael &#039;El Mayo&#039; Zambada says he was taken against his will to US amid conflicting accounts of arrest last month.

## US election 2024: Harris leads Trump in three key states, new poll shows
 - [https://www.aljazeera.com/news/2024/8/10/us-election-2024-harris-leads-trump-in-three-key-states-new-poll-shows?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/us-election-2024-harris-leads-trump-in-three-key-states-new-poll-shows?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T17:48:50+00:00

Poll shows Democratic candidate Kamala Harris has edge over Republican rival in Michigan, Pennsylvania and Wisconsin.

## Over 100 killed in Israeli attack on Gaza school
 - [https://www.aljazeera.com/program/newsfeed/2024/8/10/over-100-killed-in-israeli-attack-on-gaza-school?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/8/10/over-100-killed-in-israeli-attack-on-gaza-school?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T17:46:40+00:00

Over 100 Palestinians were killed after Israeli strikes attacked a school sheltering forcibly displaced Palestinians.

## Ethiopia’s Tola wins Olympic men’s marathon; Kenya’s Kipchoge drops out
 - [https://www.aljazeera.com/sports/2024/8/10/ethiopias-tola-wins-olympic-mens-marathon-kenyas-kipchoge-drops-out?traffic_source=rss](https://www.aljazeera.com/sports/2024/8/10/ethiopias-tola-wins-olympic-mens-marathon-kenyas-kipchoge-drops-out?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T16:52:02+00:00

Tamirat Tola completes the tough Paris course in an Olympic record time of two hours, six minutes and 26 seconds.

## Israeli attack on Gaza school renews calls for US to end support for Israel
 - [https://www.aljazeera.com/news/2024/8/10/israeli-attack-on-gaza-school-renews-calls-for-us-to-end-support-for-israel?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/israeli-attack-on-gaza-school-renews-calls-for-us-to-end-support-for-israel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T16:10:37+00:00

Advocates urge Washington to stop sending weapons to Israel after attack kills more than 100 Palestinians in Gaza City.

## Brazilian authorities recover bodies, probe cause of deadly plane crash
 - [https://www.aljazeera.com/news/2024/8/10/brazilian-authorities-recover-bodies-probe-cause-of-deadly-plane-crash?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/brazilian-authorities-recover-bodies-probe-cause-of-deadly-plane-crash?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T14:48:58+00:00

Civil defence teams are working to recover bodies of 58 passengers, four crew killed in fiery crash in Sao Paulo state.

## After Hasina: Cautious optimism for Bangladesh’s future
 - [https://www.aljazeera.com/opinions/2024/8/10/after-hasina-cautious-optimism-for-bangladeshs-future?traffic_source=rss](https://www.aljazeera.com/opinions/2024/8/10/after-hasina-cautious-optimism-for-bangladeshs-future?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T11:15:11+00:00

The overthrow of Sheikh Hasina is a remarkable political feat. However, many challenges lie ahead.

## Bangladesh chief justice agrees to resign amid new student protests
 - [https://www.aljazeera.com/news/2024/8/10/bangladesh-chief-justice-agrees-to-resign-amid-new-student-protests?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/bangladesh-chief-justice-agrees-to-resign-amid-new-student-protests?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T10:44:54+00:00

Hundreds protest outside the Supreme Court calling for Obaidul Hassan, seen as loyal to ex-PM Hasina, to step down.

## Migrant workers sent $650bn overseas last year – what it means
 - [https://www.aljazeera.com/features/2024/8/10/migrant-workers-sent-650bn-overseas-last-year-what-it-means?traffic_source=rss](https://www.aljazeera.com/features/2024/8/10/migrant-workers-sent-650bn-overseas-last-year-what-it-means?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T10:04:40+00:00

People living abroad are sending more money to their families at home, but how do money transfers work?

## ‘Bloody massacre’: Reactions to Israeli attack on Gaza school
 - [https://www.aljazeera.com/news/2024/8/10/bloody-massacre-reactions-to-israeli-attack-on-gaza-school?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/bloody-massacre-reactions-to-israeli-attack-on-gaza-school?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T09:23:10+00:00

Hamas condemns &#039;dangerous escalation&#039; while Qatar calls strike &#039;brutal crime against defenceless civilians&#039;.

## Sonic booms – the psychological warfare Israel uses to sow fear in Lebanon
 - [https://www.aljazeera.com/features/2024/8/10/sonic-booms-the-psychological-warfare-israel-uses-to-sow-fear-in-lebanon?traffic_source=rss](https://www.aljazeera.com/features/2024/8/10/sonic-booms-the-psychological-warfare-israel-uses-to-sow-fear-in-lebanon?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T09:10:36+00:00

Since October 7, Israel has been using thunderous noise, triggering memories of Beirut’s devastating port explosion.

## Harris tells pro-Palestine protesters ‘now is time for ceasefire’ in Gaza
 - [https://www.aljazeera.com/news/2024/8/10/harris-tells-pro-palestine-protesters-now-is-time-for-ceasefire-in-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/harris-tells-pro-palestine-protesters-now-is-time-for-ceasefire-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T08:31:19+00:00

People chanted &#039;Free, free Palestine&#039; during Democratic presidential candidate&#039;s speech at Arizona rally.

## Who is Pavel Rubtsov, the journalist released in Russia-West prisoner swap?
 - [https://www.aljazeera.com/features/2024/8/10/who-is-pavel-rubtsov-the-journalist-released-in-russia-west-prisoner-swap?traffic_source=rss](https://www.aljazeera.com/features/2024/8/10/who-is-pavel-rubtsov-the-journalist-released-in-russia-west-prisoner-swap?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T08:10:11+00:00

Dual Russian-Spanish citizen was greeted by President Putin last week after spending years in a Polish jail.

## Ukraine braces for reprisals as Russia sending more troops to Kursk
 - [https://www.aljazeera.com/news/2024/8/10/ukraine-braces-for-reprisals-as-russia-to-send-more-troops-to-kursk?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/ukraine-braces-for-reprisals-as-russia-to-send-more-troops-to-kursk?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T08:03:48+00:00

Tens of thousands evacuate as Russia imposes &#039;anti-terror&#039; measures in Kursk and nearby regions of Bryansk and Belgorod.

## ‘They rape us before we can cross’: Women, girls fleeing violence in Mali
 - [https://www.aljazeera.com/features/2024/8/10/they-rape-us-before-we-can-cross-women-girls-fleeing-violence-in-mali?traffic_source=rss](https://www.aljazeera.com/features/2024/8/10/they-rape-us-before-we-can-cross-women-girls-fleeing-violence-in-mali?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T06:39:12+00:00

Women and girls fleeing armed groups in Mali claim sexual assault by Malian soldiers at border with Niger.

## Russia-Ukraine war: List of key events, day 897
 - [https://www.aljazeera.com/news/2024/8/10/russia-ukraine-war-list-of-key-events-day-897?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/russia-ukraine-war-list-of-key-events-day-897?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T05:57:52+00:00

As the war enters its 897th day, these are the main developments.

## Israeli strike on Gaza school kills more than 100 people
 - [https://www.aljazeera.com/news/2024/8/10/israel-strike-on-gaza-school-kills-more-than-100?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/israel-strike-on-gaza-school-kills-more-than-100?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T04:19:43+00:00

Authorities in Gaza said Israeli bombs hit the school-turned-shelter as people were praying and triggered a fire.

## US says El Chapo son surrendered but El Mayo taken against will from Mexico
 - [https://www.aljazeera.com/news/2024/8/10/us-says-el-chapo-son-surrendered-but-el-mayo-taken-against-will-from-mexico?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/us-says-el-chapo-son-surrendered-but-el-mayo-taken-against-will-from-mexico?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T03:03:43+00:00

US ambassador to Mexico says no US resources were involved in the removal of &#039;El Mayo&#039; from Mexico to arrest in Texas.

## US to provide $3.5bn more in military aid to Israel amid war on Gaza
 - [https://www.aljazeera.com/news/2024/8/10/us-to-send-3-5bn-more-in-military-aid-to-israel-amid-war-on-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/8/10/us-to-send-3-5bn-more-in-military-aid-to-israel-amid-war-on-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-08-10T01:21:49+00:00

Part of the military aid will go to Israeli unit accused of rights abuses of Palestinians in the occupied West Bank.

