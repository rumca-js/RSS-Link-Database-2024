# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Nobody is Seeing Borderlands Movie and CEO is Mad
 - [https://www.youtube.com/watch?v=k-OZ6raN_0k](https://www.youtube.com/watch?v=k-OZ6raN_0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-08-10T16:30:14+00:00

Get a Starforge PC https://starforgepc.com/moist-yt
Get Goof Juice https://gamersupps.gg/?ref=moist
This is the greatest take two ceo moment of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/

