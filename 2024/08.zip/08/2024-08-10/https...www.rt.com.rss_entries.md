# Source:RT - Daily news, URL:https://www.rt.com/rss, language:en

## Kalashnikov unveils new machine gun and grenade launcher (VIDEO)
 - [https://www.rt.com/russia/602427-kalashnikov-machine-gun-grenade-launcher/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602427-kalashnikov-machine-gun-grenade-launcher/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T21:23:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b79de62030273c756bc52a.png" style="margin-right: 10px;" /> Russia’s Kalashnikov Concern has demonstrated its latest light machine gun and a universal under-barrel grenade launcher <br /><a href="https://www.rt.com/russia/602427-kalashnikov-machine-gun-grenade-launcher/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## European state mulls shutting down Ukrainian embassy
 - [https://www.rt.com/russia/602432-european-state-shut-ukrainian-embassy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602432-european-state-shut-ukrainian-embassy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T20:57:29+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b7d35120302749990170d6.jpg" style="margin-right: 10px;" /> Belarus’ Foreign Ministry says it sees little need for a Ukrainian diplomatic mission in Minsk if it is unable to stop Kiev’s provocations <br /><a href="https://www.rt.com/russia/602432-european-state-shut-ukrainian-embassy/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Moscow slams ‘crude forgery’ deepfake video
 - [https://www.rt.com/russia/602431-zakharova-kursk-nuclear-deepfake/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602431-zakharova-kursk-nuclear-deepfake/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T20:38:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b7c8a685f5406f35046e61.jpg" style="margin-right: 10px;" /> Ukrainian agents faked a video claiming that Moscow was ready to surrender a nuclear plant to Kiev, the Russian Foreign Ministry has said <br /><a href="https://www.rt.com/russia/602431-zakharova-kursk-nuclear-deepfake/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Harris leading Trump in key states – poll
 - [https://www.rt.com/news/602430-harris-swing-state-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602430-harris-swing-state-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T20:12:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b7bbe420302749c23760fc.jpg" style="margin-right: 10px;" /> Kamala Harris is leading Donald Trump by four points in Wisconsin, Pennsylvania, and Michigan, according to a New York Times survey <br /><a href="https://www.rt.com/news/602430-harris-swing-state-poll/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU’s chief diplomat ‘horrified’ by Israeli airstrike on school
 - [https://www.rt.com/news/602429-borrell-horrified-israel-school-strike/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602429-borrell-horrified-israel-school-strike/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T17:08:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b798a785f5406cad04fd5b.jpg" style="margin-right: 10px;" /> The EU’s top diplomat, Josep Borrell, has condemned an Israeli airstrike on a school in Gaza that reportedly killed dozens <br /><a href="https://www.rt.com/news/602429-borrell-horrified-israel-school-strike/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China makes new attempt to approve ‘super embassy’ in London – Telegraph
 - [https://www.rt.com/news/602424-uk-china-embassy-london/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602424-uk-china-embassy-london/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T16:55:37+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b77d8820302759633b0b6e.jpg" style="margin-right: 10px;" /> Beijing reportedly wants its new diplomatic mission in the British capital to be ten times larger than its current one <br /><a href="https://www.rt.com/news/602424-uk-china-embassy-london/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian missile destroys Ukrainian command post in Kursk – MOD (VIDEO)
 - [https://www.rt.com/russia/602423-russia-destroy-ukraine-command-post/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602423-russia-destroy-ukraine-command-post/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T15:34:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b7828e20302758bd188f3b.png" style="margin-right: 10px;" /> A Russian Iskander missile has destroyed a Ukrainian command post in Kursk Region, the Defense Ministry has said <br /><a href="https://www.rt.com/russia/602423-russia-destroy-ukraine-command-post/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## No ‘solid’ way to distinguish a man from a woman – IOC chief
 - [https://www.rt.com/news/602417-no-way-distinguish-man-woman-ioc/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602417-no-way-distinguish-man-woman-ioc/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T15:05:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b75b6e20302758bd188f0f.jpg" style="margin-right: 10px;" /> Thomas Bach claims not to know how a person’s gender can be reliably determined <br /><a href="https://www.rt.com/news/602417-no-way-distinguish-man-woman-ioc/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Shielding Israel: Germany is still drawing the wrong lessons from the Holocaust
 - [https://www.rt.com/news/602386-germany-israel-gaza-genocide/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602386-germany-israel-gaza-genocide/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T14:43:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b6336485f54066b461792c.jpg" style="margin-right: 10px;" /> Germany’s own history with genocide suggests it should know better than to shut down any protest against the mass deaths in Gaza <br /><a href="https://www.rt.com/news/602386-germany-israel-gaza-genocide/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian fertilizer exports to BRICS partner hit all-time high – media
 - [https://www.rt.com/russia/602418-russia-brazil-fertilizers-exports-surge/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602418-russia-brazil-fertilizers-exports-surge/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T14:31:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b7633f85f5406f35046e37.jpg" style="margin-right: 10px;" /> Russia’s exports of fertilizers to Brazil exceeded a million of tons in July, a record high, customs data shows <br /><a href="https://www.rt.com/russia/602418-russia-brazil-fertilizers-exports-surge/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘Deeply shaken’: Moscow reacts to Israeli airstrike on Gaza school
 - [https://www.rt.com/russia/602419-zakharova-gaza-school-airstrike-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602419-zakharova-gaza-school-airstrike-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T14:31:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b775ee2030275b5f7c5bb7.jpg" style="margin-right: 10px;" /> The Russian Foreign Ministry has urged Israel to refrain from attacks on civilian infrastructure in Gaza <br /><a href="https://www.rt.com/russia/602419-zakharova-gaza-school-airstrike-israel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## UK police chief threatens Elon Musk
 - [https://www.rt.com/news/602420-elon-musk-hate-speech/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602420-elon-musk-hate-speech/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T14:24:53+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b76d082030275b5f7c5bab.jpg" style="margin-right: 10px;" /> The billionaire is “a keyboard warrior” and could be prosecuted for inciting unrest, Commissioner Sir Mark Rowley has warned <br /><a href="https://www.rt.com/news/602420-elon-musk-hate-speech/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian ally claims Kiev violated its airspace
 - [https://www.rt.com/russia/602422-belarus-ukraine-destroy-drones/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602422-belarus-ukraine-destroy-drones/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T14:01:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b7713185f54059b43271b7.jpg" style="margin-right: 10px;" /> Belarus has shot down several Ukrainian aircraft that illegally entered its airspace, President Alexander Lukashenko has said <br /><a href="https://www.rt.com/russia/602422-belarus-ukraine-destroy-drones/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kiev planned Kursk incursion long in advance – ex-defense minister
 - [https://www.rt.com/about-us/press-releases/kursk-ukraine-incursion-zagorodnyuk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/about-us/press-releases/kursk-ukraine-incursion-zagorodnyuk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T13:55:27+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b74ef985f5403d92497159.jpg" style="margin-right: 10px;" /> The incursion into Kursk Region is an attempt to expose Russia’s “weaknesses,” a former Ukrainian defense minister has told FT <br /><a href="https://www.rt.com/about-us/press-releases/kursk-ukraine-incursion-zagorodnyuk/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India resets ties with Maldives after row over China stance
 - [https://www.rt.com/india/602421-india-restore-relations-maldives/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/602421-india-restore-relations-maldives/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T13:47:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b770bb85f54066b4617990.jpg" style="margin-right: 10px;" /> New Delhi is attempting to restore friendly relations with the strategic islands <br /><a href="https://www.rt.com/india/602421-india-restore-relations-maldives/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Poland warns against kicking Hungary out of Schengen
 - [https://www.rt.com/news/602414-poland-tusk-hungary-schengen/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602414-poland-tusk-hungary-schengen/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T12:13:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b733ea2030275af575c1f4.jpg" style="margin-right: 10px;" /> Hungary’s potential expulsion from the Schengen deal could lead to the country’s exit from the EU, Polish PM Donald Tusk has warned <br /><a href="https://www.rt.com/news/602414-poland-tusk-hungary-schengen/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## West backed Ukrainian attack on Kursk – Politico
 - [https://www.rt.com/russia/602415-west-backed-ukraine-attack-kursk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602415-west-backed-ukraine-attack-kursk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T11:24:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b74c6c203027598741b172.jpg" style="margin-right: 10px;" /> Ukraine’s backers in the West don’t object to Kiev’s incursion into Western Russia, Politico has reported <br /><a href="https://www.rt.com/russia/602415-west-backed-ukraine-attack-kursk/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian tanks take up positions in Kursk Region (VIDEO)
 - [https://www.rt.com/russia/602413-tanks-kursk-incursion-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602413-tanks-kursk-incursion-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T11:11:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b731842030275b5f7c5b93.png" style="margin-right: 10px;" /> Russian tank crews are fully prepared to strike Ukrainian forces in Kursk Region, the Defense Ministry in Moscow has said <br /><a href="https://www.rt.com/russia/602413-tanks-kursk-incursion-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Boxer at center of gender controversy wins Olympic gold
 - [https://www.rt.com/news/602410-gender-controversy-khelif-olympic-gold/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602410-gender-controversy-khelif-olympic-gold/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T11:03:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b73eb385f5406f35046e1c.jpg" style="margin-right: 10px;" /> Algerian welterweight boxer Imane Khelif has won gold after becoming the subject of gender controversy <br /><a href="https://www.rt.com/news/602410-gender-controversy-khelif-olympic-gold/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## German town stops accepting Ukrainian migrants
 - [https://www.rt.com/news/602412-german-town-halt-ukrainian-refugees/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602412-german-town-halt-ukrainian-refugees/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T10:10:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b73b0c20302759633b0b44.jpg" style="margin-right: 10px;" /> The German town of Pirmasens has stopped taking Ukrainian refugees after exceeding the migrant quota by over 80% <br /><a href="https://www.rt.com/news/602412-german-town-halt-ukrainian-refugees/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Dozens killed in Israeli airstrike on school
 - [https://www.rt.com/news/602409-gaza-school-airstrike-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602409-gaza-school-airstrike-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T09:09:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b7180c85f5406f35046dda.jpg" style="margin-right: 10px;" /> Various reports put the death toll from an Israeli attack on a school-turned-shelter in Gaza City at 60-100 people <br /><a href="https://www.rt.com/news/602409-gaza-school-airstrike-israel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukrainian special forces decimated in botched landing operation – Moscow (VIDEO)
 - [https://www.rt.com/russia/602411-ukraine-raid-kinburn-foiled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602411-ukraine-raid-kinburn-foiled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T08:18:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b71cdf203027598741b164.png" style="margin-right: 10px;" /> Ukraine’s forces lost 12 service members and two boats as they tried to raid the Kinburn Spit, Russia’s Defense Ministry has said <br /><a href="https://www.rt.com/russia/602411-ukraine-raid-kinburn-foiled/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Counterterrorism operations launched in western Russia
 - [https://www.rt.com/russia/602404-counterterrorism-kursk-adjacent-regions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/602404-counterterrorism-kursk-adjacent-regions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T07:47:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b6f5c0203027191370756f.jpg" style="margin-right: 10px;" /> Russia’s Antiterrorism Committee has declared counterterrorism operations in three regions amid Ukraine’s incursion into Kursk Region <br /><a href="https://www.rt.com/russia/602404-counterterrorism-kursk-adjacent-regions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Dozens of Indians await release from Russian Army – foreign minister
 - [https://www.rt.com/india/602398-dozens-return-russia-fighting-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/602398-dozens-return-russia-fighting-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T07:27:45+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b66ae920302771f30acae5.jpg" style="margin-right: 10px;" /> Moscow has been assisting New Delhi in the repatriation of citizens lured to the Ukraine conflict by human traffickers <br /><a href="https://www.rt.com/india/602398-dozens-return-russia-fighting-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Drone strikes US airbase in Syria – Reuters
 - [https://www.rt.com/news/602403-drone-strikes-us-airbase-syria/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602403-drone-strikes-us-airbase-syria/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T06:46:01+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b6f1da85f54059b4327177.jpg" style="margin-right: 10px;" /> US troops in northeastern Syria were attacked by a drone on Saturday, according to Reuters <br /><a href="https://www.rt.com/news/602403-drone-strikes-us-airbase-syria/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Trump’s plane makes emergency landing
 - [https://www.rt.com/news/602405-trumps-plane-makes-emergency-landing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602405-trumps-plane-makes-emergency-landing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T04:36:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b6ed5185f5406a097e7bd5.jpg" style="margin-right: 10px;" /> Former President Donald Trump’s plane landed in Billings, Montana after suffering a mechanical issue <br /><a href="https://www.rt.com/news/602405-trumps-plane-makes-emergency-landing/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Serbian president says he received coup warning from Russia
 - [https://www.rt.com/news/602401-serbia-coup-warning-russia-vucic/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602401-serbia-coup-warning-russia-vucic/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T02:33:29+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b693d185f5406f35046daf.jpg" style="margin-right: 10px;" /> Serbian President Aleksandar Vucic says he received an official warning from Moscow about a potential coup attempt ahead of protests <br /><a href="https://www.rt.com/news/602401-serbia-coup-warning-russia-vucic/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Washington slams Israeli minister’s ceasefire criticism
 - [https://www.rt.com/news/602402-washington-israeli-ceasefire-criticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/602402-washington-israeli-ceasefire-criticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-08-10T02:16:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.08/thumbnail/66b6cc2085f54059b4327158.jpg" style="margin-right: 10px;" /> White House national security spokesman John Kirby has slammed Israeli statements against a Gaza peace proposal <br /><a href="https://www.rt.com/news/602402-washington-israeli-ceasefire-criticism/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

