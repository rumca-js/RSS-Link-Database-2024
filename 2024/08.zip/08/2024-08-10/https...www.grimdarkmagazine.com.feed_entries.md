# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: Dragons of Eternity by Margaret Weis and Tracy Hickman
 - [https://www.grimdarkmagazine.com/review-dragons-of-eternity-by-margaret-weis-and-tracy-hickman](https://www.grimdarkmagazine.com/review-dragons-of-eternity-by-margaret-weis-and-tracy-hickman)
 - RSS feed: https://www.grimdarkmagazine.com/feed
 - date published: 2024-08-10T04:34:59+00:00

<p>Dragonlance: Dragons of Eternity is the third and final volume of the Dragonlance Destinies series that may well be the final instalment of the Dragonlance saga as we know it. It is by Margaret Weis and Tracy Hickman, two authors who have been synonomous with the Dragonlance line but also, on a personal note, my childhood. I had mixed feelings about the previous two volumes but a generally positive reception. The Dragonlance Destinies series is not a particularly epic fantasy series but more like a smaller homage to all the past stories told in the setting. Dragons of Eternity is a warm hug to longtime fans and best experienced by those who grew up with the books in their childhood. Dragons of Eternity begins with the premise that the Queen of Darkness has successfully altered time and managed to conquer Krynn. This seems to result in a lot less changed timeline than you might expect with every single person from the original Chronicles trilogy now around as well as the War of the 

