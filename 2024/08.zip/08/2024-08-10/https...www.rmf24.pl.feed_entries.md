# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Zapaśnik Robert Baran przegrał walkę o 3. miejsce
 - [https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-zapasnik-robert-baran-przegral-walke-o-3-miejsce,nId,7755148](https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-zapasnik-robert-baran-przegral-walke-o-3-miejsce,nId,7755148)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T18:31:42+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-zapasnik-robert-baran-przegral-walke-o-3-miejsce,nId,7755148"><img align="left" alt="Zapaśnik Robert Baran przegrał walkę o 3. miejsce" src="https://interia-s.pluscdn.pl/zapasnik-robert-baran-przegral-walke-o-3-miejsce/000JLPNYRI8K7D94-C307.jpg" /></a>Robert Baran, zapaśnik w stylu wolnym, walczył o brązowy medal na igrzyskach w Paryżu. Zmierzył się z reprezentantem Azerbejdżanu Giorgim Meszwildiszwilim. Niestety, pojedynek przegrał.</p><br clear="all" />

## Teren byłego obozu koncentracyjnego w rękach inwestora z branży nieruchomości
 - [https://www.rmf24.pl/fakty/swiat/news-teren-bylego-obozu-koncentracyjnego-w-rekach-inwestora-z-bra,nId,7755164](https://www.rmf24.pl/fakty/swiat/news-teren-bylego-obozu-koncentracyjnego-w-rekach-inwestora-z-bra,nId,7755164)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T18:08:11+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-teren-bylego-obozu-koncentracyjnego-w-rekach-inwestora-z-bra,nId,7755164"><img align="left" alt="Teren byłego obozu koncentracyjnego w rękach inwestora z branży nieruchomości" src="https://interia-s.pluscdn.pl/teren-bylego-obozu-koncentracyjnego-w-rekach-inwestora-z-bra/000JLPL7XS9VMHI8-C307.jpg" /></a>​Teren byłego obozu koncentracyjnego w pobliżu Halberstadt w Saksonii-Anhalt, w którym zginęło ponad 4,3 tys. osób, został sprzedany inwestorowi z branży nieruchomości. Transakcja wywołała konsternację.</p><br clear="all" />

## ​Sypialnia z widokiem na miliony gwiazd. Jak spędzić noc w lesie?
 - [https://www.rmf24.pl/fakty/polska/news-sypialnia-z-widokiem-na-miliony-gwiazd-jak-spedzic-noc-w-les,nId,7754808](https://www.rmf24.pl/fakty/polska/news-sypialnia-z-widokiem-na-miliony-gwiazd-jak-spedzic-noc-w-les,nId,7754808)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T17:12:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-sypialnia-z-widokiem-na-miliony-gwiazd-jak-spedzic-noc-w-les,nId,7754808"><img align="left" alt="​Sypialnia z widokiem na miliony gwiazd. Jak spędzić noc w lesie?" src="https://interia-s.pluscdn.pl/sypialnia-z-widokiem-na-miliony-gwiazd-jak-spedzic-noc-w-les/000JLMJ0YF5JBXR3-C307.jpg" /></a>Bliskość natury, cisza, spokój - to oferuje nam każdy las. Dla miłośników przygód nocleg w takim miejscu nie jest dziś problemem. Lasy Państwowe kolejny rok zachęcają do takiej formy odpoczynku, prowadząc program &quot;Zanocuj w lesie&quot;.</p><br clear="all" />

## Nowy sondaż: Kamala Harris prowadzi w trzech kluczowych stanach
 - [https://www.rmf24.pl/fakty/swiat/news-nowy-sondaz-kamala-harris-prowadzi-w-trzech-kluczowych-stana,nId,7755127](https://www.rmf24.pl/fakty/swiat/news-nowy-sondaz-kamala-harris-prowadzi-w-trzech-kluczowych-stana,nId,7755127)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T16:02:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nowy-sondaz-kamala-harris-prowadzi-w-trzech-kluczowych-stana,nId,7755127"><img align="left" alt="Nowy sondaż: Kamala Harris prowadzi w trzech kluczowych stanach" src="https://interia-s.pluscdn.pl/nowy-sondaz-kamala-harris-prowadzi-w-trzech-kluczowych-stana/000JLPCII3WAON73-C307.jpg" /></a>Kamala Harris wyprzedza Donalda Trumpa o 4 punkty procentowe w trzech kluczowych stanach - Michigan, Wisconsin i Pensylwanii - wynika z opublikowanego w sobotę sondażu ośrodka Siena Polls dla dziennika &quot;The New York Times&quot;. To tzw. swing states - zdobycie przewagi wśród tamtejszych wyborców ma fundamentalne znaczenie dla wyniku całych wyborów prezydenckich.</p><br clear="all" />

## Rosjanie i Białorusini mogą wziąć udział w ceremonii zamknięcia igrzysk
 - [https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-rosjanie-i-bialorusini-moga-wziac-udzial-w-ceremonii-zamknie,nId,7755122](https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-rosjanie-i-bialorusini-moga-wziac-udzial-w-ceremonii-zamknie,nId,7755122)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T15:56:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-rosjanie-i-bialorusini-moga-wziac-udzial-w-ceremonii-zamknie,nId,7755122"><img align="left" alt="Rosjanie i Białorusini mogą wziąć udział w ceremonii zamknięcia igrzysk" src="https://interia-s.pluscdn.pl/rosjanie-i-bialorusini-moga-wziac-udzial-w-ceremonii-zamknie/000JLPCD38UNQQG3-C307.jpg" /></a>Zawodnicy z Rosji i Białorusi, rywalizujący w igrzyskach olimpijskich w Paryżu jako neutralni sportowcy indywidualni, będą mogli wziąć udział w niedzielnej ceremonii zamknięcia imprezy. Taką informację przekazał w sobotę MKOl.</p><br clear="all" />

## Rosyjski samolot zwiadowczy nad Bałtykiem. Luftwaffe poderwało myśliwce
 - [https://www.rmf24.pl/fakty/swiat/news-rosyjski-samolot-zwiadowczy-nad-baltykiem-luftwaffe-poderwal,nId,7755119](https://www.rmf24.pl/fakty/swiat/news-rosyjski-samolot-zwiadowczy-nad-baltykiem-luftwaffe-poderwal,nId,7755119)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T15:31:16+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-rosyjski-samolot-zwiadowczy-nad-baltykiem-luftwaffe-poderwal,nId,7755119"><img align="left" alt="Rosyjski samolot zwiadowczy nad Bałtykiem. Luftwaffe poderwało myśliwce" src="https://interia-s.pluscdn.pl/rosyjski-samolot-zwiadowczy-nad-baltykiem-luftwaffe-poderwal/000JLPBJPM3IA04N-C307.jpg" /></a>&quot;Bez planu lotu lub kontaktu z cywilną kontrolą ruchu lotniczego&quot;, rosyjski zwiadowczy Ił-20M wleciał w międzynarodową przestrzeń powietrzną - przekazały niemieckie siły powietrzne. Z lotniska poderwano myśliwce przechwytujące.</p><br clear="all" />

## Tragedia na drodze w Lubelskiem. Nie żyje kobieta, dziecko w szpitalu
 - [https://www.rmf24.pl/regiony/lublin/news-tragedia-na-drodze-w-lubelskiem-nie-zyje-kobieta-dziecko-w-s,nId,7755110](https://www.rmf24.pl/regiony/lublin/news-tragedia-na-drodze-w-lubelskiem-nie-zyje-kobieta-dziecko-w-s,nId,7755110)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T15:21:00+00:00

<p><a href="https://www.rmf24.pl/regiony/lublin/news-tragedia-na-drodze-w-lubelskiem-nie-zyje-kobieta-dziecko-w-s,nId,7755110"><img align="left" alt="Tragedia na drodze w Lubelskiem. Nie żyje kobieta, dziecko w szpitalu" src="https://interia-s.pluscdn.pl/tragedia-na-drodze-w-lubelskiem-nie-zyje-kobieta-dziecko-w-s/000JLPAG81JNOF5D-C307.jpg" /></a>Tragiczny wypadek na drodze krajowej nr 12 w Lubelskiem. W wyniku zderzenia osobówki z ciężarówką w Tytusinie życie straciła kobieta, a dziecko śmigłowcem LPR zostało przetransportowane do szpitala.</p><br clear="all" />

## Rosjanie twierdzą, że w Serbii planowany jest zamach stanu
 - [https://www.rmf24.pl/fakty/swiat/news-rosjanie-twierdza-ze-w-serbii-planowany-jest-zamach-stanu,nId,7755095](https://www.rmf24.pl/fakty/swiat/news-rosjanie-twierdza-ze-w-serbii-planowany-jest-zamach-stanu,nId,7755095)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T14:51:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-rosjanie-twierdza-ze-w-serbii-planowany-jest-zamach-stanu,nId,7755095"><img align="left" alt="Rosjanie twierdzą, że w Serbii planowany jest zamach stanu" src="https://interia-s.pluscdn.pl/rosjanie-twierdza-ze-w-serbii-planowany-jest-zamach-stanu/000JLP8K3KIY9FCE-C307.jpg" /></a>W Serbii planowany jest zamach stanu? Tak twierdzą Rosjanie, którzy poinformowali o tym Aleksandra Vuczicia. Prezydent Serii zapewnił, że odpowiednie służby badają te doniesienia.</p><br clear="all" />

## Łzy Bartosza Kurka. "To jest medal nas wszystkich"
 - [https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-wzruszenie-bartosza-kurka-nigdy-o-tym-nie-marzylem-nie-bede-,nId,7755094](https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-wzruszenie-bartosza-kurka-nigdy-o-tym-nie-marzylem-nie-bede-,nId,7755094)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T14:49:04+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-wzruszenie-bartosza-kurka-nigdy-o-tym-nie-marzylem-nie-bede-,nId,7755094"><img align="left" alt="Łzy Bartosza Kurka. &quot;To jest medal nas wszystkich&quot;" src="https://interia-s.pluscdn.pl/lzy-bartosza-kurka-to-jest-medal-nas-wszystkich/000JLPA7QV8GNYTB-C307.jpg" /></a>Chociaż polscy siatkarze schodzili dzisiaj z boiska pokonani, smutek dość szybko ustępował wzruszeniu. To pierwszy polski medal w siatkówce od 48 lat! Bartosz Kurek, kapitan srebrnej reprezentacji z Paryża wierzy, że dzisiejszy finał i medal są zwieńczeniem wysiłków wszystkich polskich siatkarzy. Kurek, który sam przebył w biało-czerwonych barwach długą drogę, próbował powstrzymać się od łez. Nie wyszło.</p><br clear="all" />

## Lubiejewski ostro o polskich siatkarzach: Cały turniej grali słabo
 - [https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-lubiejewski-ostro-o-polskich-siatkarzach-caly-turniej-grali-,nId,7755085](https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-lubiejewski-ostro-o-polskich-siatkarzach-caly-turniej-grali-,nId,7755085)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T13:42:20+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-lubiejewski-ostro-o-polskich-siatkarzach-caly-turniej-grali-,nId,7755085"><img align="left" alt="Lubiejewski ostro o polskich siatkarzach: Cały turniej grali słabo" src="https://interia-s.pluscdn.pl/lubiejewski-ostro-o-polskich-siatkarzach-caly-turniej-grali/000JLOHI7KAON9AP-C307.jpg" /></a>&quot;Ja oglądałem wszystkie nasze mecze i moje odczucia (są takie), że cały turniej olimpijski nasza reprezentacja grała słabo&quot; - powiedział w rozmowie z RMF FM Zbigniew Lubiejewski, złoty medalista z Montrealu z 1976 roku. &quot;Ta gra się nie kleiła już od dłuższego czasu&quot; - dodał.</p><br clear="all" />

## Pożar na dzikim składowisku odpadów w Dąbrowie Górniczej
 - [https://www.rmf24.pl/regiony/slaskie/news-pozar-na-dzikim-skladowisku-odpadow-w-dabrowie-gorniczej,nId,7755081](https://www.rmf24.pl/regiony/slaskie/news-pozar-na-dzikim-skladowisku-odpadow-w-dabrowie-gorniczej,nId,7755081)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T13:33:39+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-pozar-na-dzikim-skladowisku-odpadow-w-dabrowie-gorniczej,nId,7755081"><img align="left" alt="Pożar na dzikim składowisku odpadów w Dąbrowie Górniczej" src="https://interia-s.pluscdn.pl/pozar-na-dzikim-skladowisku-odpadow-w-dabrowie-gorniczej/000JLOGSDCKULE8W-C307.jpg" /></a>W sobotę około godz. 14 w Dąbrowie Górniczej (woj. śląskie) wybuchł pożar na dzikim składowisku odpadów. Nie ma poszkodowanych. Informację o pożarze otrzymaliśmy na Gorącą linię RMF FM</p><br clear="all" />

## Francuzi zbyt mocni. Polscy siatkarze wicemistrzami olimpijskimi
 - [https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-francuzi-zbyt-mocni-polscy-siatkarze-wicemistrzami-olimpijsk,nId,7755017](https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-francuzi-zbyt-mocni-polscy-siatkarze-wicemistrzami-olimpijsk,nId,7755017)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T12:24:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-francuzi-zbyt-mocni-polscy-siatkarze-wicemistrzami-olimpijsk,nId,7755017"><img align="left" alt="Francuzi zbyt mocni. Polscy siatkarze wicemistrzami olimpijskimi" src="https://interia-s.pluscdn.pl/francuzi-zbyt-mocni-polscy-siatkarze-wicemistrzami-olimpijsk/000JLOUCTTLL79PP-C307.jpg" /></a>Mimo tylu sukcesów polskiej siatkówki w ostatnich latach, aż od 1976 roku czekamy na olimpijskie złoto. Poczekamy jeszcze trochę. Polacy gładko, bo 0:3 przegrali z Francją w finale igrzysk olimpijskich w Paryżu. Gospodarze turnieju byli zbyt mocni, a my nie graliśmy na swoim poziomie.</p><br clear="all" />

## Rosjanie pilnie skontaktowali się MAEA. Elektrownia Atomowa Kursk zagrożona?
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosjanie-pilnie-skontaktowali-sie-maea-elektrownia-atomowa-k,nId,7754998](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosjanie-pilnie-skontaktowali-sie-maea-elektrownia-atomowa-k,nId,7754998)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T09:34:51+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosjanie-pilnie-skontaktowali-sie-maea-elektrownia-atomowa-k,nId,7754998"><img align="left" alt="Rosjanie pilnie skontaktowali się MAEA. Elektrownia Atomowa Kursk zagrożona?" src="https://interia-s.pluscdn.pl/rosjanie-pilnie-skontaktowali-sie-maea-elektrownia-atomowa-k/000JLNZSBM8AQU1L-C307.jpg" /></a>Aleksiej Lichaczow szef rosyjskiej agencji energii atomowej ROSATOM twierdzi, że ukraiński atak w obwodzie kurskim zagraża bezpieczeństwu Elektrowni Atomowej Kursk. Lichaczow miał rozmawiać w tej sprawie z Rafaelem Grossim, który szefuje Międzynarodowej Agencji Energii Atomowej (MAEA).</p><br clear="all" />

## Łukaszenka: Ukraina naruszyła przestrzeń powietrzną Białorusi
 - [https://www.rmf24.pl/fakty/swiat/news-lukaszenka-twierdzi-ze-ukraina-naruszyla-przestrzen-powietrz,nId,7755002](https://www.rmf24.pl/fakty/swiat/news-lukaszenka-twierdzi-ze-ukraina-naruszyla-przestrzen-powietrz,nId,7755002)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T09:22:38+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-lukaszenka-twierdzi-ze-ukraina-naruszyla-przestrzen-powietrz,nId,7755002"><img align="left" alt="Łukaszenka: Ukraina naruszyła przestrzeń powietrzną Białorusi" src="https://interia-s.pluscdn.pl/lukaszenka-ukraina-naruszyla-przestrzen-powietrzna-bialorusi/000JLO69YRYJRA5U-C307.jpg" /></a>Białoruscy żołnierze zniszczyli &quot;kilka celów&quot;, które &quot;zostały wystrzelone&quot; z terenu Ukrainy - przekazała białoruska agencja informacyjna BelTA. Cytuje ona prezydenta Alaksandra Łukaszenkę.</p><br clear="all" />

## Ukraińcy zajęli obiekt Gazpromu? Rosja wprowadza "reżim operacji antyterrorystycznej"
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-ukraincy-zajeli-obiekt-gazpromu-rosja-wprowadza-rezim-operac,nId,7754931](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-ukraincy-zajeli-obiekt-gazpromu-rosja-wprowadza-rezim-operac,nId,7754931)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-08-10T05:01:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-ukraincy-zajeli-obiekt-gazpromu-rosja-wprowadza-rezim-operac,nId,7754931"><img align="left" alt="Ukraińcy zajęli obiekt Gazpromu? Rosja wprowadza &quot;reżim operacji antyterrorystycznej&quot;" src="https://interia-s.pluscdn.pl/ukraincy-zajeli-obiekt-gazpromu-rosja-wprowadza-rezim-operac/000JLNKREACSYIMK-C307.jpg" /></a>Trwa rajd ukraińskich żołnierzy na rosyjski obwód kurski. Jeden z wojskowych z Ukrainy opublikował nagranie, na którym mówi, że zajęli oni &quot;strategiczny obiekt Gazpromu&quot; w Sudży. W graniczących z Ukrainą obwodach kurskim, biełgorodzkim i briańskim władze rosyjskie wprowadziły &quot;reżim operacji antyterrorystycznej&quot;.</p><br clear="all" />

