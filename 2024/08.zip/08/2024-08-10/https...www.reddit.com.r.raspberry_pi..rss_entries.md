# Source:Raspberry Pi - More than just magic mirrors and kodi!, URL:https://www.reddit.com/r/raspberry_pi/.rss, language:en

## Do these circuit diagrams look viable? Thanks in advance
 - [https://www.reddit.com/r/raspberry_pi/comments/1eosp0y/do_these_circuit_diagrams_look_viable_thanks_in](https://www.reddit.com/r/raspberry_pi/comments/1eosp0y/do_these_circuit_diagrams_look_viable_thanks_in)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-08-10T13:10:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/raspberry_pi/comments/1eosp0y/do_these_circuit_diagrams_look_viable_thanks_in/"> <img alt="Do these circuit diagrams look viable? Thanks in advance" src="https://b.thumbs.redditmedia.com/SLP4GcwwePV3noLBeHM8n0VgPyiTPWFXzYqLTGJ9uvE.jpg" title="Do these circuit diagrams look viable? Thanks in advance" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://preview.redd.it/d7tcnoj36uhd1.png?width=3224&amp;format=png&amp;auto=webp&amp;s=7a2f5b80ee6990b2dac49ab03d48fea62959df49">https://preview.redd.it/d7tcnoj36uhd1.png?width=3224&amp;format=png&amp;auto=webp&amp;s=7a2f5b80ee6990b2dac49ab03d48fea62959df49</a></p> <p><a href="https://preview.redd.it/08s55pj36uhd1.png?width=3400&amp;format=png&amp;auto=webp&amp;s=aeef8a8653e62e390210463ad6f432d30510d990">https://preview.redd.it/08s55pj36uhd1.png?width=3400&amp;format=png&amp;auto=webp&amp;s=aeef8a8653e62e390210463ad6f432d30510d990</a></p> <p>Sorry for the vague question, please 

## Trouble with Bluetooth on Raspberry Pi 5 with USB Dongle
 - [https://www.reddit.com/r/raspberry_pi/comments/1eordvi/trouble_with_bluetooth_on_raspberry_pi_5_with_usb](https://www.reddit.com/r/raspberry_pi/comments/1eordvi/trouble_with_bluetooth_on_raspberry_pi_5_with_usb)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-08-10T12:03:12+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone,</p> <p>I’m having a bit of a problem with Bluetooth on my Raspberry Pi 5. I’ve disabled the internal Bluetooth using the <code>dtoverlay=disable-bt</code> setting in <code>config.txt</code>, since it interfere with the 2.4GHz wifi (I can't use the 5GHz wifi since I've some IoT devices that only works at 2.4) and I’m using an ASUS USB Bluetooth dongle (ID 0b05:190e) that is recognized by <code>lsusb</code>:</p> <pre><code>Bus 001 Device 002: ID 0b05:190e ASUSTek Computer, Inc. ASUS USB-BT500 </code></pre> <p>The problem is that it doesn't detect any bluetooth device.<br /> Indeed, when I run <code>bluetoothctl list</code>, it returns empty.</p> <p>Here’s what I’ve tried so far:</p> <ul> <li>Rebooting the Raspberry Pi</li> <li>Checking if the USB dongle is correctly recognized by <code>lsusb</code></li> <li>Ensuring that Bluetooth services are running</li> </ul> <p>Does anyone have suggestions on how to troubleshoot this? Could it be an iss

## Using Android imager to setup pi headless, how to add userconfig?
 - [https://www.reddit.com/r/raspberry_pi/comments/1eoplqg/using_android_imager_to_setup_pi_headless_how_to](https://www.reddit.com/r/raspberry_pi/comments/1eoplqg/using_android_imager_to_setup_pi_headless_how_to)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-08-10T10:12:13+00:00

<!-- SC_OFF --><div class="md"><p>Hey, i don't have a micro sd adapter for my pc at hand, so im trying to create a os image with a imager called raspi card imager for android. While the general setup itself works and i can acess the the pi through ssh, I'm not able to create a working config.txt file to create a user, most likely becaue i cant access the boot folder, since the file structure with the imager I'm using is different, or because of the password hash i used in the config file. Does someone know how to troubleshoot or how to fix this? Thanks.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Striking_Way_3205"> /u/Striking_Way_3205 </a> <br /> <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1eoplqg/using_android_imager_to_setup_pi_headless_how_to/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1eoplqg/using_android_imager_to_setup_pi_headless_how_to/">[comments]</a></span>

## Raspberry pi camera functions weirdly
 - [https://www.reddit.com/r/raspberry_pi/comments/1eohcbh/raspberry_pi_camera_functions_weirdly](https://www.reddit.com/r/raspberry_pi/comments/1eohcbh/raspberry_pi_camera_functions_weirdly)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-08-10T01:50:03+00:00

<!-- SC_OFF --><div class="md"><p>I’ve got a raspberry pi 3 b+ and when I boot it up the camera doesn’t work, but if when everything is off I unplug the camera and plug it back in then turn it back on, the camera works. But then if I cycle the power again the camera no longer is detected. I hate happening here? How do I fix that? If I unplug the camera while it’s on and plug it back in the camera also doesn’t turn on. 1. Turn pi on 2. Camera doesn’t work 3. Turn pi off 4. Unplug and plug back in camera 5. Turn pi on 6. Camera works 7. Turn pi off 8. Repeat from 1 When I cycle it the red led flashes for a second then shuts off, but when it’s functioning properly it flashes then turns off, then 2-3 seconds later the lights comes on solid. It’s running octoprint on my ender 3, the voltage pin is disconnected so neither feed eachother. And the same thing happens when the cord to the printer is disconnected. I’m using the original pi 3b+ power supply. And the firmware is octoprint off of t

