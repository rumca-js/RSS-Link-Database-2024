# Source:LonTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg, language:en-US

## Vibe is a Free, Open Source, Offline Multi-Platform Transcription App!
 - [https://www.youtube.com/watch?v=eXYiJW8llXc](https://www.youtube.com/watch?v=eXYiJW8llXc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg
 - date published: 2024-08-10T22:45:00+00:00

I was looking for something simple and multi-platform to do audio transcriptions and found Vibe which checks all of those boxes! Give vibe an audio or video file and it will transcribe the text and format it in a number of different ways including SRT closed captioning. See more How Tos: https://www.youtube.com/playlist?list=PLCZHp4d1HnIsX4bR6Q7146Fcit8ediznm , my latest videos: http://lon.tv/latest and subscribe! http://lon.tv/s

Find Vibe on Github: https://thewh1teagle.github.io/vibe/

VIDEO INDEX:
00:00 - Intro
01:12 - Vibe Demo
02:53 - Output Options
04:29 - More Formatting Options
05:30 - Using Other AI Tools with the Output
06:05 - AI Transcription Models
07:24 - Conclusion

Visit my Blog! https://blog.lon.tv

Subscribe to my email lists! 
Weekly Breakdown of Posted Videos:  - https://lon.tv/email
Daily Email From My Blog Posts! https://lon.tv/digest

See my second channel for supplementary content : http://lon.tv/extras

Follow me on Amazon too! http://lon.tv/amazonshop

Join 

