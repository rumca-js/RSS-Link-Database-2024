# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Almost unfixable “Sinkclose” bug affects hundreds of millions of AMD chips
 - [https://arstechnica.com/?p=2042298](https://arstechnica.com/?p=2042298)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-08-10T13:00:03+00:00

Worse-case scenario: "You basically have to throw your computer away."

## More than greenwashing? Sustainable aviation fuels struggle to take off
 - [https://arstechnica.com/?p=2042237](https://arstechnica.com/?p=2042237)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-08-10T10:42:09+00:00

Alternative fuels are intended to reduce the carbon footprint of airlines.

