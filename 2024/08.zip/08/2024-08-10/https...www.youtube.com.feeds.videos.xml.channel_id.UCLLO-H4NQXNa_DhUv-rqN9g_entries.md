# Source:CD-Action - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## Niestety powstał film Borderlands
 - [https://www.youtube.com/watch?v=Ukipb5lw8XY](https://www.youtube.com/watch?v=Ukipb5lw8XY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g
 - date published: 2024-08-10T20:36:12+00:00

Nie jestem pewien, czy to w ogóle powinno być legalne.

Koniecznie zobacz nas w innych miejscach:

Strona :: https://cdaction.pl/
Sklep :: https://sklep.cdaction.pl/
Instagram :: https://instagram.com/cdaction
Facebook :: http://fb.me/CDAction/
Twitter :: https://twitter.com/cdaction
Discord CD-Action :: https://discord.gg/9Aqf3Cjcxx
Kontakt :: youtube@cdaction.pl

Prowadzenie i scenariusz:

Dawid „spikain" Bojarski (http://twitter.com/spikain)

Montaż: Kacper Grela

