# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Mińsk wezwał do MSZ charge d'affaires Ukrainy
 - [https://tvn24.pl/swiat/bialorus-minsk-wezwal-do-msz-charge-daffaires-ukrainy-powodem-rzekome-naruszaniem-bialoruskiej-przestrzeni-powietrznej-przez-kijow-st8038357?source=rss](https://tvn24.pl/swiat/bialorus-minsk-wezwal-do-msz-charge-daffaires-ukrainy-powodem-rzekome-naruszaniem-bialoruskiej-przestrzeni-powietrznej-przez-kijow-st8038357?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T20:06:03+00:00

<img alt="Mińsk wezwał do MSZ charge d'affaires Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie6157ad066255e4bf3c47e7acb9c9eb35-msz-w-minsku-przypomina-ze-kontrola-na-granicy-bialorusko-rosyjskiej-zostala-zniesiona-ponad-20-lat-temu-4287990/alternates/LANDSCAPE_1280" />
    Do MSZ w Mińsku wezwano w sobotę charge d'affaires Ukrainy - podał resort w komunikacie. Miało to związek z rzekomym naruszaniem białoruskiej przestrzeni powietrznej przez Kijów. Jak przekazał resort, ukraiński dyplomata usłyszał, że w przypadku "powtórzenia prowokacji" w przyszłości Białoruś może podjąć "kroki odwetowe". Władze w Kijowie nie skomentowały oficjalnie zarzutów ze strony Mińska, zaś Łukaszenka nie przedstawił żadnych dowodów na to, że ukraińskie drony miałyby faktycznie przekroczyć przestrzeń powietrzną kraju.

## Żółte alarmy w części kraju. Uważajmy
 - [https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-przed-silnym-wiatrem-zolte-alarmy-w-czesci-kraju-uwazajmy-st8038474?source=rss](https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-przed-silnym-wiatrem-zolte-alarmy-w-czesci-kraju-uwazajmy-st8038474?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T19:22:55+00:00

<img alt="Żółte alarmy w części kraju. Uważajmy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-hwww2f-silny-wiatr-5605776/alternates/LANDSCAPE_1280" />
    Instytut Meteorologii i Gospodarki Wodnej ostrzega przed silnym wiatrem. Synoptycy wydali alarmy pierwszego stopnia. Sprawdź, gdzie aura będzie groźna.

## "Jestem głęboko poruszony i mówię Kaczyńskiemu: Dość. I przeproś w końcu za to, co robisz z Polakami"
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-o-putinowskiej-szmacie-i-dofinansowywaniu-instytucji-za-pis-bartosz-arlukowicz-i-michal-kaminski-komentuja-st8038431?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-o-putinowskiej-szmacie-i-dofinansowywaniu-instytucji-za-pis-bartosz-arlukowicz-i-michal-kaminski-komentuja-st8038431?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T18:38:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6470983-kaczynski-na-miesiecznicy-smolenskiej-ph8038458/alternates/LANDSCAPE_1280" />
    Dość przyzwolenia dla Jarosława Kaczyńskiego na wyzywanie, bluzganie, opluwanie ludzi - mówił w "Faktach po Faktach" europoseł Bartosz Arłukowicz z KO, komentując słowa prezesa PiS z sobotniej miesięcznicy smoleńskiej, gdy Kaczyński nazwał inną osobę "putinowską szmatą". Wicemarszałek Senatu Michał Kamiński z PSL-Trzeciej Drogi odniósł się zaś do jego wypowiedzi na temat dofinansowywania instytucji za poprzednich rządów. - Jarosław Kaczyński pokazuje swoją prawdziwą twarz - ocenił.

## Pierwszy taki nabór na unijne dotacje. "To jest przełom"
 - [https://fakty.tvn24.pl/zobacz-fakty/pierwszy-nabor-na-unijne-dotacje-gabinetow-podstawowej-opieki-zdrowotnej-to-jest-przelom-st8038405?source=rss](https://fakty.tvn24.pl/zobacz-fakty/pierwszy-nabor-na-unijne-dotacje-gabinetow-podstawowej-opieki-zdrowotnej-to-jest-przelom-st8038405?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T18:28:02+00:00

<img alt="Pierwszy taki nabór na unijne dotacje. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-8148252-nowicki-ph8038437/alternates/LANDSCAPE_1280" />
    20 sierpnia, godzina 10:00 - wszyscy lekarze podstawowej opieki zdrowotnej (POZ) na pewno mają wpisaną tę datę do kalendarza. Dokładnie wtedy rusza nabór wniosków na unijne dotacje. A do wydania będzie ponad miliard złotych. O czym marzą ci, którzy na co dzień nas leczą i jak oczywistych rzeczy im czasami brakuje?

## Ukraina kontynuuje ofensywę w obwodzie kurskim. "Pozdrowienia z miasta Sudża"
 - [https://fakty.tvn24.pl/zobacz-fakty/ukraina-kontynuuje-ofensywe-w-obwodzie-kurskim-pozdrowienia-z-miasta-sudza-st8038377?source=rss](https://fakty.tvn24.pl/zobacz-fakty/ukraina-kontynuuje-ofensywe-w-obwodzie-kurskim-pozdrowienia-z-miasta-sudza-st8038377?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T18:18:42+00:00

<img alt="Ukraina kontynuuje ofensywę w obwodzie kurskim. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-333645-rosja-przesuwa-sily-do-obwodu-kurskiego-ph8038400/alternates/LANDSCAPE_1280" />
    Najwyraźniej Władimir Putin nie spodziewał się tego, że teraz to on będzie musiał ściągać posiłki z głębi kraju i z Ukrainy, żeby bronić swojej ziemi przed ofensywą tak skutecznie przeprowadzoną przez Kijów. Putin tyle razy opowiadał o potędze Rosji, a teraz jest pierwszym władcą Kremla od 80 lat, którego rodacy w panice uciekają przed uderzeniem nieprzyjaciela.

## Badacze: owoce i warzywa obniżają ciśnienie krwi i chronią nerki
 - [https://tvn24.pl/tvnmeteo/nauka/badacze-owoce-i-warzywa-obnizaja-cisnienie-krwi-i-chronia-nerki-st8038424?source=rss](https://tvn24.pl/tvnmeteo/nauka/badacze-owoce-i-warzywa-obnizaja-cisnienie-krwi-i-chronia-nerki-st8038424?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T18:00:52+00:00

<img alt="Badacze: owoce i warzywa obniżają ciśnienie krwi i chronią nerki     " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2848769-warzywa-i-owoce-ph4850025/alternates/LANDSCAPE_1280" />
    Dieta bogata w dużą ilość owoców i warzyw obniża ciśnienie krwi i poprawia stan nerek i serca u pacjentów z nadciśnieniem tętniczym - donoszą amerykańscy naukowcy. Artykuł  został opublikowany na łamach "The American Journal of Medicine".

## Rosja wysyła czołgi i ewakuuje przygraniczne tereny. Nowe wieści z obwodu kurskiego
 - [https://tvn24.pl/swiat/rosja-obwod-kurski-moskwa-wysyla-czolgi-i-ewakuuje-przygraniczne-tereny-st8038380?source=rss](https://tvn24.pl/swiat/rosja-obwod-kurski-moskwa-wysyla-czolgi-i-ewakuuje-przygraniczne-tereny-st8038380?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T17:02:32+00:00

<img alt="Rosja wysyła czołgi i ewakuuje przygraniczne tereny. Nowe wieści z obwodu kurskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6479890-rosja-przesuwa-sily-do-obwodu-kurskiego-ph8038401/alternates/LANDSCAPE_1280" />
    W graniczącym z Ukrainą obwodzie kurskim w Rosji trwają starcia. Moskwa skierowała tam czołgi i twierdzi, że zlikwidowała ukraiński pojazd opancerzony. Z przygranicznych terenów tego regionu  prowadzona jest również ewakuacja.

## Pogoda na jutro - niedziela, 11.08. Dużo słońca, miejscami silniej powieje
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-niedziela-1108-duzo-slonca-miejscami-silniej-powieje-st8038374?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-niedziela-1108-duzo-slonca-miejscami-silniej-powieje-st8038374?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T16:57:17+00:00

<img alt="Pogoda na jutro - niedziela, 11.08. Dużo słońca, miejscami silniej powieje  " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecief81489ac9b9d68d4fb1dd765dcb78927-pogodny-dzien-5240336/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na niedzielę 11.08. Noc zapowiada się pogodnie. W dzień dopisze słoneczna aura. Tylko miejscami może przelotnie popadać deszcz.

## Rosyjski samolot zwiadowczy nad Bałtykiem. Poderwano myśliwce
 - [https://tvn24.pl/swiat/rosyjski-samolot-zwiadowczy-nad-baltykiem-poderwano-mysliwce-st8038369?source=rss](https://tvn24.pl/swiat/rosyjski-samolot-zwiadowczy-nad-baltykiem-poderwano-mysliwce-st8038369?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T16:02:14+00:00

<img alt="Rosyjski samolot zwiadowczy nad Bałtykiem. Poderwano myśliwce     " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1767658-rosyjski-samolot-zwiadowczy-nad-baltykiem-poderwano-mysliwce-ph8038366/alternates/LANDSCAPE_1280" />

## Sztorm na Bałtyku. Bardzo trudne warunki do żeglowania
 - [https://tvn24.pl/tvnmeteo/pogoda/sztorm-na-baltyku-bardzo-trudne-warunki-do-zeglowania-st8038351?source=rss](https://tvn24.pl/tvnmeteo/pogoda/sztorm-na-baltyku-bardzo-trudne-warunki-do-zeglowania-st8038351?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T16:01:20+00:00

<img alt="Sztorm na Bałtyku. Bardzo trudne warunki do żeglowania" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ugwesv-sztorm-na-baltyku-6110832/alternates/LANDSCAPE_1280" />
    Instytut Meteorologii i Gospodarki Wodnej ostrzega przez sztormem na Bałtyku. Wiatr ma wiać w porywach do 9 stopni w skali Beauforta, czyli przekraczać 80 kilometrów na godzinę. Warunki do żeglowania będą bardzo trudne.

## Kamala Harris prowadzi w trzech kluczowych stanach
 - [https://tvn24.pl/swiat/usa-wybory-prezydenckie-2024-kamala-harris-prowadzi-w-trzech-kluczowych-stanach-swing-states-michigan-wisconsin-i-pensylwanii-st8038333?source=rss](https://tvn24.pl/swiat/usa-wybory-prezydenckie-2024-kamala-harris-prowadzi-w-trzech-kluczowych-stanach-swing-states-michigan-wisconsin-i-pensylwanii-st8038333?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T15:33:14+00:00

<img alt="Kamala Harris prowadzi w trzech kluczowych stanach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9567782-obywatele-wspierajacy-kamale-harris-ph8038337/alternates/LANDSCAPE_1280" />
    Wiceprezydent USA Kamala Harris wyprzedza Donalda Trumpa w przedwyborczym sondażu w trzech kluczowych stanach - wynika z opublikowanego w sobotę badania dla "New York Timesa". W Michigan, Wisconsin i Pensylwanii demokratka zdobyła o 4 punkty procentowe więcej. Są to trzy z siedmiu kluczowych stanów, w których zdobycie przewagi będzie mieć fundamentalne znaczenie dla wyniku jesiennych wyborów prezydenckich w Stanach Zjednoczonych.

## Kobieta nie żyje, dziecko w szpitalu
 - [https://tvn24.pl/lublin/kobieta-nie-zyje-dziecko-w-szpitalu-st8038358?source=rss](https://tvn24.pl/lublin/kobieta-nie-zyje-dziecko-w-szpitalu-st8038358?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T15:28:39+00:00

<img alt="Kobieta nie żyje, dziecko w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2578874-kobieta-zginela-a-dziecko-trafilo-do-szpitala-ph8038354/alternates/LANDSCAPE_1280" />
    Tragiczny wypadek na krajowej "12". Kierująca zjechała na przeciwny pas ruchu i zderzyła się z ciężarowym renault. Zginęła na miejscu, a dziecko zostało śmigłowcem przetransportowane do szpitala.

## Ma orzekać w sprawie Romanowskiego. Giertych zapowiada zawiadomienie w sprawie sędziego
 - [https://tvn24.pl/polska/sprawa-marcina-romanowskiego-roman-giertych-zapowiada-zawiadomienie-w-sprawie-sedziego-przemyslawa-dziwanskiego-st8038343?source=rss](https://tvn24.pl/polska/sprawa-marcina-romanowskiego-roman-giertych-zapowiada-zawiadomienie-w-sprawie-sedziego-przemyslawa-dziwanskiego-st8038343?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-08-10T15:21:08+00:00

<img alt="Ma orzekać w sprawie Romanowskiego. Giertych zapowiada zawiadomienie w sprawie sędziego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4906452-roman-giertych-ph8001287/alternates/LANDSCAPE_1280" />
    Zespół do spraw rozliczenia PiS złoży w przyszłym tygodniu zawiadomienie o możliwości popełnienia deliktu dyscyplinarnego przez sędziego Przemysława Dziwańskiego - zapowiedział poseł Koalicji Obywatelskiej, mecenas Roman Giertych. Delikt ma polegać na przyjęciu do rozpoznania sprawy o zastosowanie aresztu wobec Marcina Romanowskiego "w sytuacji planowania nadzwyczaj długiego urlopu".

