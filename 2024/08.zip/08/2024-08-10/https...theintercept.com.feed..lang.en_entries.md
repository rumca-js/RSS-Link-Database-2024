# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Racism Is Why Trump Is So Popular
 - [https://theintercept.com/2024/08/10/republicans-trump-vance-racism-white-nationalism](https://theintercept.com/2024/08/10/republicans-trump-vance-racism-white-nationalism)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-08-10T10:00:00+00:00

<p>Trump’s popularity with his base isn’t the result of economic anxiety, as many claimed in 2016. It’s about race and demographics.</p>
<p>The post <a href="https://theintercept.com/2024/08/10/republicans-trump-vance-racism-white-nationalism/">Racism Is Why Trump Is So Popular</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

