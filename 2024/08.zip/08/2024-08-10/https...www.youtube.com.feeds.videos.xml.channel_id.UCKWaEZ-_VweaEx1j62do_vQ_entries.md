# Source:IBM Technology, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKWaEZ-_VweaEx1j62do_vQ, language:en

## OpenAI Schema hot take
 - [https://www.youtube.com/watch?v=FmrdaeZcpHE](https://www.youtube.com/watch?v=FmrdaeZcpHE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKWaEZ-_VweaEx1j62do_vQ
 - date published: 2024-08-10T14:00:11+00:00

Listen to the full episode → https://www.youtube.com/watch?

