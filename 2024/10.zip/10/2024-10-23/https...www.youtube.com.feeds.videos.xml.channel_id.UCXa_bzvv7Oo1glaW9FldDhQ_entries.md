# Source:GamingBolt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ, language:en-US

## Call of Duty: Black Ops 6 - 15 Things You NEED TO KNOW Before You Buy
 - [https://www.youtube.com/watch?v=GOp3fttB5Lw](https://www.youtube.com/watch?v=GOp3fttB5Lw)
 - RSS feed: $source
 - date published: 2024-10-23T13:30:13+00:00

You can't have a year of gaming without a new Call of Duty title. While the past few years focused on the extremely awful Modern Warfare series, this year the series returns with Black Ops 6. It's out on October 25th worldwide (October 24th, depending on your region) for consoles and PC.

The story sees Frank Woods and Troy Marshall going rogue to deal with a new threat in Pantheon. The campaign promises more variety and choice in approaching objectives alongside the signature explosive set pieces the franchise is known for. Multiplayer features Omnimovement and new Assist features, and the return of Classic Prestige.

Then there's Zombies, which returns with a round-based format and two maps - Terminus Island and Liberty Falls. While a lot looks promising, there are still several things to worry about.

