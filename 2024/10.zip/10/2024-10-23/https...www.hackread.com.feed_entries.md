# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Attackers Use Encoded JavaScript to Deliver Malware
 - [https://hackread.com/attackers-use-encoded-javascript-to-deliver-malware](https://hackread.com/attackers-use-encoded-javascript-to-deliver-malware)
 - RSS feed: $source
 - date published: 2024-10-23T12:24:22+00:00

Cyber attackers are using encoded JavaScript files to hide malware, abusing Microsoft&#8217;s Script Encoder to disguise harmful scripts&#8230;

## Millions of iOS and Android Users at Risk as Popular Apps Expose Cloud Keys
 - [https://hackread.com/ios-android-users-risk-apps-expose-cloud-keys](https://hackread.com/ios-android-users-risk-apps-expose-cloud-keys)
 - RSS feed: $source
 - date published: 2024-10-23T11:56:03+00:00

Millions of iOS and Android users are at risk after Symantec discovered that popular apps contain hardcoded, unencrypted&#8230;

## Dutch Police Infiltrate Telegram Groups, Arrest 4 for Illegal Data Trading
 - [https://hackread.com/dutch-police-telegram-groups-arrest-data-trading](https://hackread.com/dutch-police-telegram-groups-arrest-data-trading)
 - RSS feed: $source
 - date published: 2024-10-23T09:11:48+00:00

Dutch police arrested four individuals for selling stolen personal data via Telegram groups, seizing devices and firearms in&#8230;

