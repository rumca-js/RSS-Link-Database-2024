# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: The Battle Drum by Saara El-Arifi
 - [https://www.grimdarkmagazine.com/review-the-battle-drum-by-saara-el-arifi](https://www.grimdarkmagazine.com/review-the-battle-drum-by-saara-el-arifi)
 - RSS feed: $source
 - date published: 2024-10-23T04:03:03+00:00

<p>Look, I’ve made it no secret that I adored The Final Strife, but El-Arifi truly takes everything that was so bloody brilliant about the first book and cracks it up to eleven in The Battle Drum. The prophesied ending fire is looming ever closer, and now our favourite crew of flawed yet loveable chaos queers will have to choose between duty and desire to save their world from total destruction; cue the emotional turmoil! The Battle Drum picks up almost immediately where the first book left off, sucking us straight back into the messy lives of our three fierce female leads. I was nervous to see if El-Arifi would be able to keep the story as engaging without the action-packed and high-stakes trial element that made The Final Strife so addictive, but I should never have worried. Although the pacing slows down significantly, the expansion of the world and the development of the characters and their interpersonal relationships quickly prove to be infinitely more captivating than any trial

