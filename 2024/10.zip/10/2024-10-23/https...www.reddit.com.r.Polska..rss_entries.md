# Source:Polski Subreddit, URL:https://www.reddit.com/r/Polska/.rss, language:pl

## Czy ustawa o wieku emerytalnym łamie Konstytucję ?
 - [https://www.reddit.com/r/Polska/comments/1gableb/czy_ustawa_o_wieku_emerytalnym_łamie_konstytucję](https://www.reddit.com/r/Polska/comments/1gableb/czy_ustawa_o_wieku_emerytalnym_łamie_konstytucję)
 - RSS feed: $source
 - date published: 2024-10-23T14:14:38+00:00

<!-- SC_OFF --><div class="md"><p>Cześć, nie jestem prawnikiem, ale skoro zaznaczam w teorii wobec prawa jesteśmy wszyscy równi oraz konstytucja gwarantuje nam równość. Dlaczego więc kobiety żyją dłużej i przechodzą na emeyturę wcześniej ? Zgadzacie się z tym ? Jestem ciekaw co o tym myślą kobiety. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ZookeepergameReal713"> /u/ZookeepergameReal713 </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1gableb/czy_ustawa_o_wieku_emerytalnym_łamie_konstytucję/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1gableb/czy_ustawa_o_wieku_emerytalnym_łamie_konstytucję/">[comments]</a></span>

## Większości dzikiej przyrody już nie ma. Kraje całego świata debatują, jak ocalić resztę
 - [https://www.reddit.com/r/Polska/comments/1gabbu5/większości_dzikiej_przyrody_już_nie_ma_kraje](https://www.reddit.com/r/Polska/comments/1gabbu5/większości_dzikiej_przyrody_już_nie_ma_kraje)
 - RSS feed: $source
 - date published: 2024-10-23T14:02:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1gabbu5/większości_dzikiej_przyrody_już_nie_ma_kraje/"> <img src="https://external-preview.redd.it/GvWLXacmmxOf5QMfEAWGNdasm4weu-oo26pH70jNxLk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9056ee880ada8b0ccb506465bebb07126d570622" alt="Większości dzikiej przyrody już nie ma. Kraje całego świata debatują, jak ocalić resztę" title="Większości dzikiej przyrody już nie ma. Kraje całego świata debatują, jak ocalić resztę" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/grot_13"> /u/grot_13 </a> <br/> <span><a href="https://next.gazeta.pl/next/7,172392,31404912,wiekszosci-dzikiej-przyrody-juz-nie-ma-kraje-calego-swiata.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1gabbu5/większości_dzikiej_przyrody_już_nie_ma_kraje/">[comments]</a></span> </td></tr></table>

## Rant na plagę wadliwego mięsa w sklepach
 - [https://www.reddit.com/r/Polska/comments/1ga9nc8/rant_na_plagę_wadliwego_mięsa_w_sklepach](https://www.reddit.com/r/Polska/comments/1ga9nc8/rant_na_plagę_wadliwego_mięsa_w_sklepach)
 - RSS feed: $source
 - date published: 2024-10-23T12:44:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ga9nc8/rant_na_plagę_wadliwego_mięsa_w_sklepach/"> <img src="https://b.thumbs.redditmedia.com/gkBGhjw6x4-jGzLq-OQeES0J2B-56BLUihwBtZ0u5lM.jpg" alt="Rant na plagę wadliwego mięsa w sklepach" title="Rant na plagę wadliwego mięsa w sklepach" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Mój mąż to ten typ człowieka z serii &quot;białko do obiadu musi być&quot; a ze względu na wzrost cen żywności coraz częściej sięgamy po kurczaka. Kiedyś byłam bardzo kurczakowa i niby nie powinno mi to nastręczać dramatów życiowych chociaż jestem team ryby i wołowina. Ale zauważyłam, że ostatnio to mięso z kurczaka smakuje po prostu okropnie niezależnie od tego co z nim zrobimy i gdzie je kupimy. Jest pozbawione smaku, twarde, włókniste i suche i nawet po zasypaniu go toną przypraw sprawia, że mi się cofa. Szczerze mówiąc nie pamiętam żeby kiedyś był z tym taki problem. Kurczak zawsze mi się kojarzył z łatwymi a w miarę smacznymi p

## Pretensjonalne nazwy dań i składników w restauracjach
 - [https://www.reddit.com/r/Polska/comments/1ga8rqi/pretensjonalne_nazwy_dań_i_składników_w](https://www.reddit.com/r/Polska/comments/1ga8rqi/pretensjonalne_nazwy_dań_i_składników_w)
 - RSS feed: $source
 - date published: 2024-10-23T12:00:10+00:00

<!-- SC_OFF --><div class="md"><p>Macie jakieś przykłady? Mnie aż zęby bolą jak widzę, że składnikiem dania jest „pangrattato” co brzmi bardzo światowo, ale w rzeczywistości to zwykła bułka tarta 🥴</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PatatinaBrava"> /u/PatatinaBrava </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1ga8rqi/pretensjonalne_nazwy_dań_i_składników_w/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga8rqi/pretensjonalne_nazwy_dań_i_składników_w/">[comments]</a></span>

## Gówno Logana Paula już w Żabce
 - [https://www.reddit.com/r/Polska/comments/1ga8jup/gówno_logana_paula_już_w_żabce](https://www.reddit.com/r/Polska/comments/1ga8jup/gówno_logana_paula_już_w_żabce)
 - RSS feed: $source
 - date published: 2024-10-23T11:48:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ga8jup/gówno_logana_paula_już_w_żabce/"> <img src="https://preview.redd.it/wgvu0pxuuhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a2b6f8edaa7291f6eaf3ce4ac376bd974e514efe" alt="Gówno Logana Paula już w Żabce" title="Gówno Logana Paula już w Żabce" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/El_Antonio_2137"> /u/El_Antonio_2137 </a> <br/> <span><a href="https://i.redd.it/wgvu0pxuuhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga8jup/gówno_logana_paula_już_w_żabce/">[comments]</a></span> </td></tr></table>

## Sondaż: Trzaskowski z większymi szansami niż Sikorski w wyb. prezydenckich
 - [https://www.reddit.com/r/Polska/comments/1ga8guo/sondaż_trzaskowski_z_większymi_szansami_niż](https://www.reddit.com/r/Polska/comments/1ga8guo/sondaż_trzaskowski_z_większymi_szansami_niż)
 - RSS feed: $source
 - date published: 2024-10-23T11:44:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ga8guo/sondaż_trzaskowski_z_większymi_szansami_niż/"> <img src="https://preview.redd.it/dpzqpsk6uhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4421d13f9245f2eb3f399d941996fe1204d023a7" alt="Sondaż: Trzaskowski z większymi szansami niż Sikorski w wyb. prezydenckich " title="Sondaż: Trzaskowski z większymi szansami niż Sikorski w wyb. prezydenckich " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://wiadomosci.wp.pl/dwa-sondaze-prezydenckie-fatalne-wiesci-dla-sikorskiego-7084126078106176a">https://wiadomosci.wp.pl/dwa-sondaze-prezydenckie-fatalne-wiesci-dla-sikorskiego-7084126078106176a</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Eryk0201"> /u/Eryk0201 </a> <br/> <span><a href="https://i.redd.it/dpzqpsk6uhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga8guo/sondaż_trzaskowski_z_większymi_szansami_niż/"

## Chmura pyłu nad Śląskiem. Pożar w najwyższej pokopalnianej hałdzie w Europie. Trwają poszukiwania nowej metody ugaszenia ognia w jej wnętrzu
 - [https://www.reddit.com/r/Polska/comments/1ga7up0/chmura_pyłu_nad_śląskiem_pożar_w_najwyższej](https://www.reddit.com/r/Polska/comments/1ga7up0/chmura_pyłu_nad_śląskiem_pożar_w_najwyższej)
 - RSS feed: $source
 - date published: 2024-10-23T11:08:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ga7up0/chmura_pyłu_nad_śląskiem_pożar_w_najwyższej/"> <img src="https://external-preview.redd.it/Z6PwduyGK6BieiAKs3l-pL2NJ2WnOzOxe5XhojR2MbU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=971bd40e810140e668e361418d040937187a482c" alt="Chmura pyłu nad Śląskiem. Pożar w najwyższej pokopalnianej hałdzie w Europie. Trwają poszukiwania nowej metody ugaszenia ognia w jej wnętrzu" title="Chmura pyłu nad Śląskiem. Pożar w najwyższej pokopalnianej hałdzie w Europie. Trwają poszukiwania nowej metody ugaszenia ognia w jej wnętrzu" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/grot_13"> /u/grot_13 </a> <br/> <span><a href="https://dziennikzachodni.pl/chmura-pylu-nad-slaskiem-pozar-w-najwyzszej-pokopalnianej-haldzie-w-europie-trwaja-poszukiwania-nowej-metody-ugaszenia-ognia-w/ar/c1-18890467">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga7up0/chmura_pyłu_nad_ś

## Jak sądzicie, kim ostatecznie będzie kandydat koalicji na prezydenta? Jest szansa że będzie to ktoś inny niż Trzaskowski?
 - [https://www.reddit.com/r/Polska/comments/1ga75c9/jak_sądzicie_kim_ostatecznie_będzie_kandydat](https://www.reddit.com/r/Polska/comments/1ga75c9/jak_sądzicie_kim_ostatecznie_będzie_kandydat)
 - RSS feed: $source
 - date published: 2024-10-23T10:23:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ga75c9/jak_sądzicie_kim_ostatecznie_będzie_kandydat/"> <img src="https://preview.redd.it/9rf6b1xifhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=44ddf79430cf7cf643c57b110218fbac3173faf2" alt="Jak sądzicie, kim ostatecznie będzie kandydat koalicji na prezydenta? Jest szansa że będzie to ktoś inny niż Trzaskowski? " title="Jak sądzicie, kim ostatecznie będzie kandydat koalicji na prezydenta? Jest szansa że będzie to ktoś inny niż Trzaskowski? " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Optimal_Area_7152"> /u/Optimal_Area_7152 </a> <br/> <span><a href="https://i.redd.it/9rf6b1xifhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga75c9/jak_sądzicie_kim_ostatecznie_będzie_kandydat/">[comments]</a></span> </td></tr></table>

## Nowy spot Tramwajów Warszawskich o Silent Disco
 - [https://www.reddit.com/r/Polska/comments/1ga6whw/nowy_spot_tramwajów_warszawskich_o_silent_disco](https://www.reddit.com/r/Polska/comments/1ga6whw/nowy_spot_tramwajów_warszawskich_o_silent_disco)
 - RSS feed: $source
 - date published: 2024-10-23T10:07:11+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Mackelowsky"> /u/Mackelowsky </a> <br/> <span><a href="https://v.redd.it/xto7lpttbhwd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga6whw/nowy_spot_tramwajów_warszawskich_o_silent_disco/">[comments]</a></span>

## Hałaśliwi sąsiedzi z góry.
 - [https://www.reddit.com/r/Polska/comments/1ga6ucg/hałaśliwi_sąsiedzi_z_góry](https://www.reddit.com/r/Polska/comments/1ga6ucg/hałaśliwi_sąsiedzi_z_góry)
 - RSS feed: $source
 - date published: 2024-10-23T10:03:11+00:00

<!-- SC_OFF --><div class="md"><p>Cześć Panie i Panowie, mam dosyć uciążliwy problem, który nie daje mi normalnie pracować, funkcjonować po pracy.</p> <p>Jakieś pół roku temu zmuszony byłem przez powrót właścicieli z UK wyprowadzić się z zajebistego mieszkania, gdzie sąsiedzi byli naprawdę spoko. </p> <p>Przeprowadziłem się do mieszkania w wielkiej płycie, oprócz romów urządzających niedzielne bitki pod moim balkonem, i pijaczkami na całym osiedlu (serio, pozdrawiam z nowej huty) pojawił się problem większy i bardziej uciążliwy. </p> <p>Nade mną mieszka rodzinka z dwoma małymi dzieciakami ~7 lat, oprócz pisków i wrzasków codziennie napierdalaja w piłkę w mieszkaniu, skaczą po podłodze - aż tak że w mieszkaniu dosłownie telepią się szklanki. Jak schodzą na parter po schodach dźwięk chodu przypomina czterech sumo nizeli dwóch drobnych dzieciaczków. I tak od 13 do 22 godziny.</p> <p>Jakieś porady? Po widoku rodziców którzy nie potrafili mi odpowiedzieć dzień dobry na klatce nie spodziewa

## Nagranie przedstawiające kierowcę autobusu szkolnego z miejscowości Góra
 - [https://www.reddit.com/r/Polska/comments/1ga6r52/nagranie_przedstawiające_kierowcę_autobusu](https://www.reddit.com/r/Polska/comments/1ga6r52/nagranie_przedstawiające_kierowcę_autobusu)
 - RSS feed: $source
 - date published: 2024-10-23T09:57:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ga6r52/nagranie_przedstawiające_kierowcę_autobusu/"> <img src="https://external-preview.redd.it/NDFmcnpnYzJiaHdkMZwzQQeXateFK1W1ErqtqsB6ouP-NcO2eyF9_sJqjcxW.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=30f634a97f4b90b7d57780d51f715afc969273f2" alt="Nagranie przedstawiające kierowcę autobusu szkolnego z miejscowości Góra " title="Nagranie przedstawiające kierowcę autobusu szkolnego z miejscowości Góra " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://www.pap.pl/aktualnosci/zrobil-celowo-szokujace-ustalenia-sledczych-w-sprawie-kierowcy-ktory-autobusem-z">https://www.pap.pl/aktualnosci/zrobil-celowo-szokujace-ustalenia-sledczych-w-sprawie-kierowcy-ktory-autobusem-z</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/blind095"> /u/blind095 </a> <br/> <span><a href="https://v.redd.it/87w0dke2bhwd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/

## Jaki catering możecie polecić?
 - [https://www.reddit.com/r/Polska/comments/1ga6r2w/jaki_catering_możecie_polecić](https://www.reddit.com/r/Polska/comments/1ga6r2w/jaki_catering_możecie_polecić)
 - RSS feed: $source
 - date published: 2024-10-23T09:57:10+00:00

<!-- SC_OFF --><div class="md"><p>Cześć, jak w temacie. Miałem dłuższą przerwę i po powrocie do cateringów które miałem przetestowane jestem przerażony jak spadła jakość a ile się pozamykało.</p> <p>Prośba o polecajki.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/voonart"> /u/voonart </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1ga6r2w/jaki_catering_możecie_polecić/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga6r2w/jaki_catering_możecie_polecić/">[comments]</a></span>

## ChatGPT Advanced voice już w polsce. Ktoś z obecnych tutaj ma subskrypcję Plus i podzieli się wrażeniami? Myślę o tym głównie pod kątem nauki języka angielskiego. Codziennie 15 min konwersacji powinno dać efekt
 - [https://www.reddit.com/r/Polska/comments/1ga6kql/chatgpt_advanced_voice_już_w_polsce_ktoś_z](https://www.reddit.com/r/Polska/comments/1ga6kql/chatgpt_advanced_voice_już_w_polsce_ktoś_z)
 - RSS feed: $source
 - date published: 2024-10-23T09:44:30+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/gordriver_berserker"> /u/gordriver_berserker </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1ga6kql/chatgpt_advanced_voice_już_w_polsce_ktoś_z/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga6kql/chatgpt_advanced_voice_już_w_polsce_ktoś_z/">[comments]</a></span>

## Polska alternatywna historia
 - [https://www.reddit.com/r/Polska/comments/1ga60yl/polska_alternatywna_historia](https://www.reddit.com/r/Polska/comments/1ga60yl/polska_alternatywna_historia)
 - RSS feed: $source
 - date published: 2024-10-23T09:03:14+00:00

<!-- SC_OFF --><div class="md"><p>Jakie wydarzenia nazwalibyście potencjalnymi wydarzeniami, które jakby się wydarzyły mogłyby zmienić bieg naszej historii? Moje kilka propozycji 1. Wybór kanadyjskiego biznesmena Stanisława Tymińskiego na prezydenta w 1990. 2. Co gdyby elektrownie atomowe Warta i Żarnowiec powstały w latach 80 3. Co gdyby przewrót majowy się nie wydarzył, a Piłsudski został odsunięty od polityki </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/baegarcon"> /u/baegarcon </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1ga60yl/polska_alternatywna_historia/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga60yl/polska_alternatywna_historia/">[comments]</a></span>

## Dietetyka czy fizjoterapia?
 - [https://www.reddit.com/r/Polska/comments/1ga5bb5/dietetyka_czy_fizjoterapia](https://www.reddit.com/r/Polska/comments/1ga5bb5/dietetyka_czy_fizjoterapia)
 - RSS feed: $source
 - date published: 2024-10-23T08:08:52+00:00

<!-- SC_OFF --><div class="md"><p>Hej, zamierzam w wieku 30+ lat pójść na studia i zastanawiam się głównie nad dwoma kierunkami: fizjoterapią i dietetyką. Chętnie poczytałabym opinie osób pracujących w tych zawodach, bo jak widzę w jakimś rankingu, że mediana zarobków fizjo w Polsce to 3745 netto, odechciewa mi się jakichkolwiek studiów. Jest aż tak źle?</p> <p>A jeśli ktoś studiuje któreś z powyższych na WUM-ie lub UJ-ocie, to też chętnie dowiedziałabym się, jakie macie wrażenia</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PsychoticBasil"> /u/PsychoticBasil </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1ga5bb5/dietetyka_czy_fizjoterapia/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga5bb5/dietetyka_czy_fizjoterapia/">[comments]</a></span>

## Wiedźmińska dziecięca książeczka
 - [https://www.reddit.com/r/Polska/comments/1ga5ad5/wiedźmińska_dziecięca_książeczka](https://www.reddit.com/r/Polska/comments/1ga5ad5/wiedźmińska_dziecięca_książeczka)
 - RSS feed: $source
 - date published: 2024-10-23T08:06:55+00:00

<!-- SC_OFF --><div class="md"><p>Ostatnio natrafiłem na Amazonie na przedsprzedaż czegoś takiego: <a href="https://www.amazon.com/Little-Witcher-CD-Projekt-Red/dp/0593235452">https://www.amazon.com/Little-Witcher-CD-Projekt-Red/dp/0593235452</a>. Dziecinna książeczka o Ciri i Geralcie w Kaer Morhen. Co o tym myślicie? Czy to w ogóle ma sens? Czy to trafi do dzieci, czy będzie raczej ciekawostką dla dorosłych?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Upset_Dog272"> /u/Upset_Dog272 </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1ga5ad5/wiedźmińska_dziecięca_książeczka/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga5ad5/wiedźmińska_dziecięca_książeczka/">[comments]</a></span>

## Jak się oszukuje w internecie
 - [https://www.reddit.com/r/Polska/comments/1ga4fxe/jak_się_oszukuje_w_internecie](https://www.reddit.com/r/Polska/comments/1ga4fxe/jak_się_oszukuje_w_internecie)
 - RSS feed: $source
 - date published: 2024-10-23T07:07:41+00:00

<!-- SC_OFF --><div class="md"><p>Wbrew wszelkim pozorom nie będzie to historia o tym, jak zamówiłem telefon z aliexpress a zamiast niego dostałem kartę pamięci. Coś takiego nie ma prawa się wydarzyć, bo jest zbyt absurdalne. Nie mniej jednak pomyłki w zamówieniach się zdarzają i wcale nie trzeba robić zakupów przez internet na drugim końcu świata, żeby dostać nie to co trzeba. Czasem wystarczy zamówić pizzę w sobotni wieczór i zamiast upragnionego włoskiego placka z podwójnym serem trzeba zadowolić się hawajską z ananasem.I to już jest historia z życia wzięta, ale nie o tym dzisiaj.</p> <p>Ostatnio sporo czytałem w komentarzach, że już po kilku pierwszych zdaniach, a niektórzy nawet po samym tytule, wiedzą już, kto pisze. Tak, to kolejna część sagi z serwisu rowerowego, a dzisiaj chciałbym wam opowiedzieć o, tu niespodzianka, źle wykonanych zamówieniach. I jeśli ktoś sobie teraz pomyślał “Boże Jedyny, nudniejszego tematu już się dało wybrać” to chyba nie zna mnie za długo. Bo moje ży

## Apka Zappka kaput
 - [https://www.reddit.com/r/Polska/comments/1ga2qzq/apka_zappka_kaput](https://www.reddit.com/r/Polska/comments/1ga2qzq/apka_zappka_kaput)
 - RSS feed: $source
 - date published: 2024-10-23T05:11:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ga2qzq/apka_zappka_kaput/"> <img src="https://preview.redd.it/bx94pn52wfwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5dc3ef485edd349f1caa00a23813aad4e6d2c8aa" alt="Apka Zappka kaput" title="Apka Zappka kaput" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Dzień dobry. Ktoś wie o co chodzi z apką żabkową? Nie pomogły oczywiste metody. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/atomicautism"> /u/atomicautism </a> <br/> <span><a href="https://i.redd.it/bx94pn52wfwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ga2qzq/apka_zappka_kaput/">[comments]</a></span> </td></tr></table>

## Bardzo ciekawe. "How ‘Gilded Age’ Star Christine Baranski Is Helping Harris Sway Polish American Voters"
 - [https://www.reddit.com/r/Polska/comments/1g9zj4a/bardzo_ciekawe_how_gilded_age_star_christine](https://www.reddit.com/r/Polska/comments/1g9zj4a/bardzo_ciekawe_how_gilded_age_star_christine)
 - RSS feed: $source
 - date published: 2024-10-23T02:08:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1g9zj4a/bardzo_ciekawe_how_gilded_age_star_christine/"> <img src="https://external-preview.redd.it/eKqIhydPoqrHmDnP8D3i0_2kuCBzECRsjUsKhs8Zcqc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d519fad1267e7293006764a399c7d20fea763edd" alt="Bardzo ciekawe. &quot;How ‘Gilded Age’ Star Christine Baranski Is Helping Harris Sway Polish American Voters&quot;" title="Bardzo ciekawe. &quot;How ‘Gilded Age’ Star Christine Baranski Is Helping Harris Sway Polish American Voters&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Fragrant_Respond1818"> /u/Fragrant_Respond1818 </a> <br/> <span><a href="https://www.nytimes.com/2024/10/22/us/politics/christine-baranski-harris-polish-american-voters.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1g9zj4a/bardzo_ciekawe_how_gilded_age_star_christine/">[comments]</a></span> </td></tr></table>

## Uwaga na dotacje ze strony epedagog
 - [https://www.reddit.com/r/Polska/comments/1g9xpmj/uwaga_na_dotacje_ze_strony_epedagog](https://www.reddit.com/r/Polska/comments/1g9xpmj/uwaga_na_dotacje_ze_strony_epedagog)
 - RSS feed: $source
 - date published: 2024-10-23T00:37:39+00:00

<!-- SC_OFF --><div class="md"><p>Tldr: chciałem się tylko zorientować, czy mogę skorzystać z dotacji, a oznaczało to zapisanie się na podyplomowke.</p> <p>Prowadzę firmę i chciałem zapisać się na podyplomowke na stronie epedagog. Wybralem zakładkę dotacje i chciałem się zorientować, czy mogę dostać dotację. Zostawiłem dane swojej firmy i dane kontaktowe. Przyznaję, że popełniłem błąd i wykazałem się naiwnością, bo nie widziałem, że przycisk &quot;załóż konto/wyślij wniosek&quot; oznacza też akceptację regulaminu, myślałem że po kliknięciu i zostawieniu swoich danych ktoś ze strony epedagog się po prostu ze mną skontaktuje i powie mi, jakie mam możliwości w sprawę dotacji. Ale niestety przyszedł mi SMS z dostępem do serwisu i regulamin według którego nie mogę odstąpić już od umowy. Link do regulaminu: <a href="https://epedagog.edu.pl/regulamin">https://epedagog.edu.pl/regulamin</a></p> <p>Co sądzicie? Może ktoś ma doświadczenia z tą stroną? Wiem, że wykazałem się naiwnością, jak napis

