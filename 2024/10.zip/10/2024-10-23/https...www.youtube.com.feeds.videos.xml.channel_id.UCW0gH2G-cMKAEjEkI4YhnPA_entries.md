# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## War of the Rohirrim at NYCC RECAP
 - [https://www.youtube.com/watch?v=uJ2wynb_AHY](https://www.youtube.com/watch?v=uJ2wynb_AHY)
 - RSS feed: $source
 - date published: 2024-10-23T02:28:24+00:00

We are going to chat all things Tolkien from New York Comic Con!  I'm joined by my friends Kellie from @HappyHobbit and Anna María from @makersofmiddleearth to chat about the War of the Rohirrim panel, the @TheOneRingNet party, and more!

#waroftherohirrim #nycc #lordoftherings

