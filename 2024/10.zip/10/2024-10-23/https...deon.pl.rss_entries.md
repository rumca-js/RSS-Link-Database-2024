# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Nie żyje polsko-amerykański noblista Andrew V. Schally. Zmarł w USA.
 - [https://deon.pl/swiat/nie-zyje-polsko-amerykanski-noblista-andrew-v-schally-zmarl-w-usa,2954051](https://deon.pl/swiat/nie-zyje-polsko-amerykanski-noblista-andrew-v-schally-zmarl-w-usa,2954051)
 - RSS feed: $source
 - date published: 2024-10-23T13:32:54.439040+00:00

Śp. Andrew Schally - fot. US gov, Public domain, via Wikimedia Commons / Depositphotos.com (66532011)

## Żaden inny kardynał nie nosi takiego krzyża. Jego pochodzenie zaskakuje
 - [https://deon.pl/kosciol/zaden-inny-kardynal-nie-nosi-takiego-krzyza-jego-pochodzenie-zaskakuje,2954075](https://deon.pl/kosciol/zaden-inny-kardynal-nie-nosi-takiego-krzyza-jego-pochodzenie-zaskakuje,2954075)
 - RSS feed: $source
 - date published: 2024-10-23T13:32:54.052008+00:00

Fot. depositphotos.com / X.com

## Kolejne zmiany w szkołach. Nauczyciele stracili możliwość urlopu zdrowotnego
 - [https://deon.pl/swiat/kolejne-zmiany-w-szkolach-nauczyciele-stracili-mozliwosc-urlopu-zdrowotnego,2954126](https://deon.pl/swiat/kolejne-zmiany-w-szkolach-nauczyciele-stracili-mozliwosc-urlopu-zdrowotnego,2954126)
 - RSS feed: $source
 - date published: 2024-10-23T13:32:53.783957+00:00

Zdjęcie ilustracyjne. Fot. Depositphotos

## "Szczęśliwa, która słucha". Diecezjalny Dzień Kobiet w Nadarzynie
 - [https://deon.pl/kosciol/szczesliwa-ktora-slucha-diecezjalny-dzien-kobiet-w-nadarzynie,2954174](https://deon.pl/kosciol/szczesliwa-ktora-slucha-diecezjalny-dzien-kobiet-w-nadarzynie,2954174)
 - RSS feed: $source
 - date published: 2024-10-23T13:32:53.502318+00:00

Fot: Nikodem Idzi

## Lekarze proponowali przerwanie ciąży. Mimo zespołu Takayasu, szczęśliwie urodziła
 - [https://deon.pl/swiat/lekarze-proponowali-przerwanie-ciazy-mimo-zespolu-takayasu-szczesliwie-urodzila,2953931](https://deon.pl/swiat/lekarze-proponowali-przerwanie-ciazy-mimo-zespolu-takayasu-szczesliwie-urodzila,2953931)
 - RSS feed: $source
 - date published: 2024-10-23T12:27:25.889679+00:00

Fot. Depositphotos

## Mężczyzna obudził się podczas pobierania organów. Myśleli, że nie żyje
 - [https://deon.pl/swiat/mezczyzna-obudzil-sie-podczas-pobierania-organow-mysleli-ze-nie-zyje,2953937](https://deon.pl/swiat/mezczyzna-obudzil-sie-podczas-pobierania-organow-mysleli-ze-nie-zyje,2953937)
 - RSS feed: $source
 - date published: 2024-10-23T12:27:25.630968+00:00

Fot. depositphotos.com

## Dominik Dubiel SJ o największym kłamstwie, jakie wdarło się do katechezy i głoszenia
 - [https://deon.pl/wiara/dominik-dubiel-sj-o-najwiekszym-klamstwie-jakie-wdarlo-sie-do-katechezy-i-gloszenia,2953838](https://deon.pl/wiara/dominik-dubiel-sj-o-najwiekszym-klamstwie-jakie-wdarlo-sie-do-katechezy-i-gloszenia,2953838)
 - RSS feed: $source
 - date published: 2024-10-23T12:27:25.364925+00:00

Dominik Dubiel SJ (fot. jezuici.pl)

## Małopolskie/ Okradali cmentarze na Sądecczyźnie; staną przed sądem
 - [https://deon.pl/swiat/wiadomosci-z-polski/malopolskie-okradali-cmentarze-na-sadecczyznie-stana-przed-sadem,2954033](https://deon.pl/swiat/wiadomosci-z-polski/malopolskie-okradali-cmentarze-na-sadecczyznie-stana-przed-sadem,2954033)
 - RSS feed: $source
 - date published: 2024-10-23T12:27:25.097604+00:00

Depositphotos.com (621251020)

## Abp Jędraszewski złożył rezygnację. Nowe doniesienia o następcy
 - [https://deon.pl/kosciol/abp-jedraszewski-zlozyl-rezygnacje-nowe-doniesienia-o-nastepcy,2953904](https://deon.pl/kosciol/abp-jedraszewski-zlozyl-rezygnacje-nowe-doniesienia-o-nastepcy,2953904)
 - RSS feed: $source
 - date published: 2024-10-23T12:24:49+00:00

fot. Joanna Adamik | Archidiecezja Krakowska

## Ostatnia droga o. Zygmunta Perza SJ
 - [https://deon.pl/kosciol/ostatnia-droga-o-zygmunta-perza-sj,2953805](https://deon.pl/kosciol/ostatnia-droga-o-zygmunta-perza-sj,2953805)
 - RSS feed: $source
 - date published: 2024-10-23T11:22:14.911871+00:00

Śp. o. Zygmunt Perz SJ - fot. jezuici.pl/Depositphotos.com (645364042)

## Wracać do domu, by słuchać przed mówieniem
 - [https://deon.pl/kosciol/komentarze/wracac-do-domu-by-sluchac-przed-mowieniem,2953871](https://deon.pl/kosciol/komentarze/wracac-do-domu-by-sluchac-przed-mowieniem,2953871)
 - RSS feed: $source
 - date published: 2024-10-23T11:22:14.434363+00:00

Depositphotos.com (159360898)

## Zwrot w sprawie ks. Michała Olszewskiego – jest zmiana zarzutów
 - [https://deon.pl/kosciol/zwrot-w-sprawie-ks-michala-olszewskiego--jest-zmiana-zarzutow,2953826](https://deon.pl/kosciol/zwrot-w-sprawie-ks-michala-olszewskiego--jest-zmiana-zarzutow,2953826)
 - RSS feed: $source
 - date published: 2024-10-23T11:22:13.988134+00:00

Fot. Dobre Media Nowej Ewangelizacji / YouTube

## Po pięćdziesiątce rób to codziennie rano. Będziesz mieć więcej energii
 - [https://deon.pl/inteligentne-zycie/zdrowie/po-piecdziesiatce-rob-to-codziennie-rano-bedziesz-miec-wiecej-energii,2953829](https://deon.pl/inteligentne-zycie/zdrowie/po-piecdziesiatce-rob-to-codziennie-rano-bedziesz-miec-wiecej-energii,2953829)
 - RSS feed: $source
 - date published: 2024-10-23T11:22:13.654631+00:00

None

## Jak się ubrać na Wszystkich Świętych? To nie jest pokaz mody
 - [https://deon.pl/po-godzinach/jak-sie-ubrac-na-wszystkich-swietych-to-nie-jest-pokaz-mody,2953652](https://deon.pl/po-godzinach/jak-sie-ubrac-na-wszystkich-swietych-to-nie-jest-pokaz-mody,2953652)
 - RSS feed: $source
 - date published: 2024-10-23T10:17:01.039318+00:00

Zdjęcie ilustracyjne. Fot. Depositphotos

## Franciszek do Polaków: Jan Paweł II był papieżem rodziny
 - [https://deon.pl/kosciol/serwis-papieski/franciszek-do-polakow-jan-pawel-ii-byl-papiezem-rodziny,2953622](https://deon.pl/kosciol/serwis-papieski/franciszek-do-polakow-jan-pawel-ii-byl-papiezem-rodziny,2953622)
 - RSS feed: $source
 - date published: 2024-10-23T09:11:21.135293+00:00

Fot. Vatican Media

## Ukraina się wyludnia. ONZ: liczba ludności zmniejszyła się o ponad 10 mln
 - [https://deon.pl/swiat/ukraina-sie-wyludnia-onz-liczba-ludnosci-zmniejszyla-sie-o-ponad-10-mln-,2953643](https://deon.pl/swiat/ukraina-sie-wyludnia-onz-liczba-ludnosci-zmniejszyla-sie-o-ponad-10-mln-,2953643)
 - RSS feed: $source
 - date published: 2024-10-23T09:11:21.006413+00:00

Ukraina, Kijów październik 2024 (Fot. PAP/EPA/SERGEY DOLZHENKO)

## Ośmiomiesięczna dziewczynka została uznana za zmarłą. Obudziła się w trumnie
 - [https://deon.pl/swiat/osmiomiesieczna-dziewczynka-zostala-uznana-za-zmarla-obudzila-sie-w-trumnie,2953433](https://deon.pl/swiat/osmiomiesieczna-dziewczynka-zostala-uznana-za-zmarla-obudzila-sie-w-trumnie,2953433)
 - RSS feed: $source
 - date published: 2024-10-23T08:06:26.963835+00:00

Zdjęcie ilustracyjne. Fot. Depositphotos

## 60-latka z Polski urodziła bliźniaki. To nic w porównaniu z najstarszą matką świata
 - [https://deon.pl/po-godzinach/60-latka-z-polski-urodzila-blizniaki-to-nic-w-porownaniu-z-najstarsza-matka-swiata,2953484](https://deon.pl/po-godzinach/60-latka-z-polski-urodzila-blizniaki-to-nic-w-porownaniu-z-najstarsza-matka-swiata,2953484)
 - RSS feed: $source
 - date published: 2024-10-23T08:06:26.879366+00:00

Barbara Sienkiewicz w wieku 60 lat urodziła bliźniaki (fot. Super Express News / YouTube.com)

## „Quo vadis” w animowanej odsłonie dla całej rodziny. Michał Koterski jako Neron
 - [https://deon.pl/swiat/quo-vadis-w-animowanej-odslonie-dla-calej-rodziny-michal-koterski-jako-neron,2953406](https://deon.pl/swiat/quo-vadis-w-animowanej-odslonie-dla-calej-rodziny-michal-koterski-jako-neron,2953406)
 - RSS feed: $source
 - date published: 2024-10-23T08:06:26.794605+00:00

Michał Koterski a animacji wcielił się w postać Nerona  (Fot. „Quo vadis”)

## Franciszek: małżeństwo potrzebuje wsparcia Ducha Świętego
 - [https://deon.pl/kosciol/serwis-papieski/franciszek-malzenstwo-potrzebuje-wsparcia-ducha-swietego,2953571](https://deon.pl/kosciol/serwis-papieski/franciszek-malzenstwo-potrzebuje-wsparcia-ducha-swietego,2953571)
 - RSS feed: $source
 - date published: 2024-10-23T08:06:26.706583+00:00

Papież Franciszek - fot. Grzegorz Gałązka

## Strażaczka wspomina akcję w kamieniołomie: noc, na dole krzaki, mało co było widać
 - [https://deon.pl/po-godzinach/strazaczka-wspomina-akcje-w-kamieniolomie-noc-na-dole-krzaki-malo-co-bylo-widac,2953199](https://deon.pl/po-godzinach/strazaczka-wspomina-akcje-w-kamieniolomie-noc-na-dole-krzaki-malo-co-bylo-widac,2953199)
 - RSS feed: $source
 - date published: 2024-10-23T08:06:26.611062+00:00

fot. depositphotos.com

## Kiedy przemoc psychiczna staje się niewidzialnym mordercą duszy
 - [https://deon.pl/inteligentne-zycie/kiedy-przemoc-psychiczna-staje-sie-niewidzialnym-morderca-duszy,2950016](https://deon.pl/inteligentne-zycie/kiedy-przemoc-psychiczna-staje-sie-niewidzialnym-morderca-duszy,2950016)
 - RSS feed: $source
 - date published: 2024-10-23T07:03:07.614049+00:00

Zdjęcie ilustracyjne. Fot. Depositphotos

## Kamala Harris do studentów głoszących "Jezus jest Panem!": Jesteście na złym wiecu
 - [https://deon.pl/kosciol/kamala-harris-do-studentow-gloszacych-jezus-jest-panem-jestescie-na-zlym-wiecu,2953418](https://deon.pl/kosciol/kamala-harris-do-studentow-gloszacych-jezus-jest-panem-jestescie-na-zlym-wiecu,2953418)
 - RSS feed: $source
 - date published: 2024-10-23T07:03:07.521285+00:00

Kamala Harris (fot. PAP/EPA/JIM LO SCALZO)

## Dr Ewa Dąbrowska o poście w chorobach metaboliczne: niedoczynność tarczycy ustępuje
 - [https://deon.pl/po-godzinach/przepisy/dr-ewa-dabrowska-o-poscie-w-chorobach-metaboliczne-niedoczynnosc-tarczycy-ustepuje-,2933276](https://deon.pl/po-godzinach/przepisy/dr-ewa-dabrowska-o-poscie-w-chorobach-metaboliczne-niedoczynnosc-tarczycy-ustepuje-,2933276)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:00+00:00

Zdjęcie ilustracyjne (Fot. depositphotos.com/pl/HayDmitriy)

