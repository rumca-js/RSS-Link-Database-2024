# Source:Lost in Time, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCac6m8K3OGHUT4itHwpCAmw, language:en

## 1960 Presidential Debate between John F. Kennedy and Richard Nixon!🇺🇸 Colorized and upscaled!
 - [https://www.youtube.com/watch?v=nXbfZfY2_kM](https://www.youtube.com/watch?v=nXbfZfY2_kM)
 - RSS feed: $source
 - date published: 2024-10-23T14:00:46+00:00

None

