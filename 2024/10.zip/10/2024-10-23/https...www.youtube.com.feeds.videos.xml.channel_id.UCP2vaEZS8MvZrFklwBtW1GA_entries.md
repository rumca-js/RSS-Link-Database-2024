# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## How to Mix Mortar Without Dust - #shorts #homerepairtutor
 - [https://www.youtube.com/watch?v=FwOdhnClOP8](https://www.youtube.com/watch?v=FwOdhnClOP8)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:19+00:00

I use the Collomix Dust EX and my shop vac. This keeps most of the powder from going into the air. That said, I still use a silica dust respirator. This system works tremendously well for its compact size 👍🏽🔥#mortar #safety #homerenovation

