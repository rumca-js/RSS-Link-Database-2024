# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Podcast „Szkoła na nowo”: Wolna szkoła – czy to w ogóle możliwe?
 - [https://edukacja.rp.pl/oswiata/art41337071-podcast-szkola-na-nowo-wolna-szkola-czy-to-w-ogole-mozliwe](https://edukacja.rp.pl/oswiata/art41337071-podcast-szkola-na-nowo-wolna-szkola-czy-to-w-ogole-mozliwe)
 - RSS feed: $source
 - date published: 2024-10-23T06:55:39.016985+00:00

Wraz z odejściem poprzedniej ekipy rządzącej, w szkole miało być więcej wolności. Więcej poszanowania praw ucznia. Więcej autonomii dla nauczycieli. Na razie niewiele z tego wyszło.

