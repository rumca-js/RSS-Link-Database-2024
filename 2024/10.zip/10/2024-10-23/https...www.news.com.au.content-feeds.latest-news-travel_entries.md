# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## Change on board plane to impact thousands
 - [https://www.news.com.au/travel/travel-advice/flights/qantas-trial-of-new-australia-digital-travel-declaration-kicks-off/news-story/aa1066feba96043abb83fc32bc528925?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/qantas-trial-of-new-australia-digital-travel-declaration-kicks-off/news-story/aa1066feba96043abb83fc32bc528925?from=rss-basic)
 - RSS feed: $source
 - date published: 2024-10-23T02:02:34.078160+00:00

It’s perhaps one of the most annoying things on board a flight into Australia. But now, resident or not, this requirement will be gone.

