# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## The Baylor Project: Tiny Desk Concert
 - [https://www.youtube.com/watch?v=PbM82phaaeg](https://www.youtube.com/watch?v=PbM82phaaeg)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:21+00:00

Mitra I. Arthur | October 23, 2024
When Marcus and Jean Baylor of The Baylor Project enter a space, their love for each other and playfulness is on display. Those traits carry over to the music they’ve been creating since becoming musical partners, in addition to life partners. Their journey to the Desk includes similar musical upbringings as children of pastors (evident in Marcus’ repeated call and response of “Let the church say what? Amen!”) and stints in music groups prior to forming The Baylor Project: Marcus as a drummer in jazz quartet Yellowjackets, and Jean in R&B duo Zhané. These threads are woven through their joint musical output that has garnered them seven Grammy nominations.

When reflecting on their visit to the Tiny Desk, the Baylors remarked that this is a “one-of-a-kind performance” that perfectly reflected their ethos “of love, family, faith, culture and community!” The kinetic energy of “We Swing (The Cypher)” allows Jean to display her skillful scatting as she tr

