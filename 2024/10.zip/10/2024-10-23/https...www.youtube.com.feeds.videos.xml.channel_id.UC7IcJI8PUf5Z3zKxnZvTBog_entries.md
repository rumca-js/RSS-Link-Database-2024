# Source:The School of Life, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog, language:en-US

## Why It Can Take Us So Long to Understand How Unwell We Are
 - [https://www.youtube.com/watch?v=lRDwAafSFgI](https://www.youtube.com/watch?v=lRDwAafSFgI)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:55+00:00

Enjoying our Youtube videos? Get full access to all our audio content, videos, and thousands of thought-provoking articles, conversation cards and more with The School of Life Subscription: https://www.theschooloflife.com/the-school-of-life-youtube/?utm_source=youtube&utm_medium=description&utm_campaign=Why%20it%20can%20take%20us%20so%20long%20to%20understand%20how%20unwell%20we%20are


Learn, heal and grow. Get the best of The School of Life delivered straight to your inbox: https://www.theschooloflife.com/signup/?utm_source=youtube&utm_medium=description&utm_campaign=Why%20it%20can%20take%20us%20so%20long%20to%20understand%20how%20unwell%20we%20are

FURTHER READING

You can read more on this and other subjects in our articles, here: https://www.theschooloflife.com/article/why-it-can-take-us-so-long-to-understand-how-unwell-we-are/

“A lot about our behaviour doesn’t make sense until we can take on board a basic idea about the way we humans are built: that our biology privileges surv

