# Source:r/gaming, URL:https://www.reddit.com/r/gaming/.rss, language:

## Gets me every time but I can't look away
 - [https://www.reddit.com/r/gaming/comments/1ga8b6c/gets_me_every_time_but_i_cant_look_away](https://www.reddit.com/r/gaming/comments/1ga8b6c/gets_me_every_time_but_i_cant_look_away)
 - RSS feed: $source
 - date published: 2024-10-23T11:35:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1ga8b6c/gets_me_every_time_but_i_cant_look_away/"> <img src="https://preview.redd.it/mt2ze70nshwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5d790bb078ba3547551a22511c4a76641ddfd545" alt="Gets me every time but I can't look away " title="Gets me every time but I can't look away " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AzazaMaster"> /u/AzazaMaster </a> <br/> <span><a href="https://i.redd.it/mt2ze70nshwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1ga8b6c/gets_me_every_time_but_i_cant_look_away/">[comments]</a></span> </td></tr></table>

## Family and gaming are the only things that keep me going
 - [https://www.reddit.com/r/gaming/comments/1ga665m/family_and_gaming_are_the_only_things_that_keep](https://www.reddit.com/r/gaming/comments/1ga665m/family_and_gaming_are_the_only_things_that_keep)
 - RSS feed: $source
 - date published: 2024-10-23T09:14:34+00:00

<!-- SC_OFF --><div class="md"><p>Hey everyone, I recently got some really tough news about my health, and it’s been hard to process. I’m feeling a lot of fear, sadness, and uncertainty about what’s next, and honestly, I’m not sure how to deal with it all. Life can change so quickly, and right now it feels like everything is up in the air.</p> <p>The one thing that’s been helping me stay distracted and somewhat grounded has been gaming. It’s always been my go-to escape, but now it feels more important than ever. It’s tough to enjoy things the same way I used to, but right now, gaming is the only thing keeping me going.</p> <p>I’m reaching out here because I know I’m not the only one who’s been through dark times. If anyone has advice, support, or just wants to share their story, it would mean a lot. Even if you haven’t been in the same situation, I’d love to hear how you’ve dealt with tough times.</p> <p>Thanks for taking the time to read this. </p> <p>Edit: a few days ago I created a

## To kills monsters, you must become a monster.
 - [https://www.reddit.com/r/gaming/comments/1ga51kt/to_kills_monsters_you_must_become_a_monster](https://www.reddit.com/r/gaming/comments/1ga51kt/to_kills_monsters_you_must_become_a_monster)
 - RSS feed: $source
 - date published: 2024-10-23T07:53:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1ga51kt/to_kills_monsters_you_must_become_a_monster/"> <img src="https://preview.redd.it/wzsu89txogwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=91dfccb5f413787f2339d8a0b83ff4765bf021f8" alt="To kills monsters, you must become a monster." title="To kills monsters, you must become a monster." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NeonJumpsuit"> /u/NeonJumpsuit </a> <br/> <span><a href="https://i.redd.it/wzsu89txogwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1ga51kt/to_kills_monsters_you_must_become_a_monster/">[comments]</a></span> </td></tr></table>

## UPDATE: My 70 years old Japanese mother in law is now at level 13473 in Candy Crush
 - [https://www.reddit.com/r/gaming/comments/1ga47o0/update_my_70_years_old_japanese_mother_in_law_is](https://www.reddit.com/r/gaming/comments/1ga47o0/update_my_70_years_old_japanese_mother_in_law_is)
 - RSS feed: $source
 - date published: 2024-10-23T06:50:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1ga47o0/update_my_70_years_old_japanese_mother_in_law_is/"> <img src="https://preview.redd.it/nd73770sdgwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f7133bddd4c76ec3f5eb534ae364271743d1f6e0" alt="UPDATE: My 70 years old Japanese mother in law is now at level 13473 in Candy Crush" title="UPDATE: My 70 years old Japanese mother in law is now at level 13473 in Candy Crush" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>And she didn’t spend a single penny on it.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plutonium-239"> /u/plutonium-239 </a> <br/> <span><a href="https://i.redd.it/nd73770sdgwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1ga47o0/update_my_70_years_old_japanese_mother_in_law_is/">[comments]</a></span> </td></tr></table>

## Super Mario Party Jamboree is pretty fun.
 - [https://www.reddit.com/r/gaming/comments/1ga42rm/super_mario_party_jamboree_is_pretty_fun](https://www.reddit.com/r/gaming/comments/1ga42rm/super_mario_party_jamboree_is_pretty_fun)
 - RSS feed: $source
 - date published: 2024-10-23T06:40:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1ga42rm/super_mario_party_jamboree_is_pretty_fun/"> <img src="https://preview.redd.it/aaa13j30cgwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bf99c0880003f8c026ec3cb766c1656a1170247f" alt="Super Mario Party Jamboree is pretty fun." title="Super Mario Party Jamboree is pretty fun." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>There&#39;s something about the poses though...</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ithinktheysellpaint"> /u/ithinktheysellpaint </a> <br/> <span><a href="https://i.redd.it/aaa13j30cgwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1ga42rm/super_mario_party_jamboree_is_pretty_fun/">[comments]</a></span> </td></tr></table>

## What are you playing Wednesday!
 - [https://www.reddit.com/r/gaming/comments/1ga3i87/what_are_you_playing_wednesday](https://www.reddit.com/r/gaming/comments/1ga3i87/what_are_you_playing_wednesday)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:10+00:00

<!-- SC_OFF --><div class="md"><p>What game&#39;s got your attention this week? What&#39;s great about it? What sucks? Tell us all about it! </p> <p>&#x200B;</p> <p>This thread is posted weekly on Wednesdays (adjustments made as needed).</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AutoModerator"> /u/AutoModerator </a> <br/> <span><a href="https://www.reddit.com/r/gaming/comments/1ga3i87/what_are_you_playing_wednesday/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1ga3i87/what_are_you_playing_wednesday/">[comments]</a></span>

## This is me after a long day of work and no energy to do anything fun. Starting a new game of Skyrim and seeing Lydia just sit and drink mead, I thought "me too Lydia, me too".
 - [https://www.reddit.com/r/gaming/comments/1ga0ed8/this_is_me_after_a_long_day_of_work_and_no_energy](https://www.reddit.com/r/gaming/comments/1ga0ed8/this_is_me_after_a_long_day_of_work_and_no_energy)
 - RSS feed: $source
 - date published: 2024-10-23T02:54:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1ga0ed8/this_is_me_after_a_long_day_of_work_and_no_energy/"> <img src="https://preview.redd.it/kk0q3u0e7fwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=918b8f8f21adfa94defd32909ee301d1e8b819d2" alt="This is me after a long day of work and no energy to do anything fun. Starting a new game of Skyrim and seeing Lydia just sit and drink mead, I thought &quot;me too Lydia, me too&quot;." title="This is me after a long day of work and no energy to do anything fun. Starting a new game of Skyrim and seeing Lydia just sit and drink mead, I thought &quot;me too Lydia, me too&quot;." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Danvideotech2385"> /u/Danvideotech2385 </a> <br/> <span><a href="https://i.redd.it/kk0q3u0e7fwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1ga0ed8/this_is_me_after_a_long_day_of_work_and_no_energy/">[comments]</a></span> 

## Bought these about a year ago on sale and forgot about them until now. I’m going in blind, but I’ve only ever heard them talked about positively, so I’m excited to play them. Jumping in now.
 - [https://www.reddit.com/r/gaming/comments/1g9zpql/bought_these_about_a_year_ago_on_sale_and_forgot](https://www.reddit.com/r/gaming/comments/1g9zpql/bought_these_about_a_year_ago_on_sale_and_forgot)
 - RSS feed: $source
 - date published: 2024-10-23T02:17:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1g9zpql/bought_these_about_a_year_ago_on_sale_and_forgot/"> <img src="https://preview.redd.it/qvu5nrnxyewd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e042cc3a0a82c5aae9dcf44b45bcaa7660497054" alt="Bought these about a year ago on sale and forgot about them until now. I’m going in blind, but I’ve only ever heard them talked about positively, so I’m excited to play them. Jumping in now. " title="Bought these about a year ago on sale and forgot about them until now. I’m going in blind, but I’ve only ever heard them talked about positively, so I’m excited to play them. Jumping in now. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dr_Mantis_Teabaggin"> /u/Dr_Mantis_Teabaggin </a> <br/> <span><a href="https://i.redd.it/qvu5nrnxyewd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1g9zpql/bought_these_about_a_year_ago_on_sale_and_forgot/">[comme

## Today - EA broke Battlefield 1 for Steam Deck and Linux by choice - 8 years after it was released
 - [https://www.reddit.com/r/gaming/comments/1g9zmd9/today_ea_broke_battlefield_1_for_steam_deck_and](https://www.reddit.com/r/gaming/comments/1g9zmd9/today_ea_broke_battlefield_1_for_steam_deck_and)
 - RSS feed: $source
 - date published: 2024-10-23T02:13:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1g9zmd9/today_ea_broke_battlefield_1_for_steam_deck_and/"> <img src="https://external-preview.redd.it/QjB8RplAOUjoGrCSxqkJDK0OsNXKi5cAoEthJvdqbeU.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=1666ebcf761c6bdbb4d5fe8c1073d2cad05de254" alt="Today - EA broke Battlefield 1 for Steam Deck and Linux by choice - 8 years after it was released" title="Today - EA broke Battlefield 1 for Steam Deck and Linux by choice - 8 years after it was released" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BloodyIron"> /u/BloodyIron </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1g9i85d/kernel_level_anticheat_was_just_released_in_bf1/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1g9zmd9/today_ea_broke_battlefield_1_for_steam_deck_and/">[comments]</a></span> </td></tr></table>

## Amazing goodwill score, 3 still completely sealed!!!
 - [https://www.reddit.com/r/gaming/comments/1g9z84o/amazing_goodwill_score_3_still_completely_sealed](https://www.reddit.com/r/gaming/comments/1g9z84o/amazing_goodwill_score_3_still_completely_sealed)
 - RSS feed: $source
 - date published: 2024-10-23T01:53:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1g9z84o/amazing_goodwill_score_3_still_completely_sealed/"> <img src="https://preview.redd.it/tafm33kpwewd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0eb2b2b9a4d28a5622fa6d72c41348c368410933" alt="Amazing goodwill score, 3 still completely sealed!!!" title="Amazing goodwill score, 3 still completely sealed!!!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bad_rug"> /u/bad_rug </a> <br/> <span><a href="https://i.redd.it/tafm33kpwewd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1g9z84o/amazing_goodwill_score_3_still_completely_sealed/">[comments]</a></span> </td></tr></table>

## Sony's Guerrilla Sounds Completely Done with the Killzone Series
 - [https://www.reddit.com/r/gaming/comments/1g9xark/sonys_guerrilla_sounds_completely_done_with_the](https://www.reddit.com/r/gaming/comments/1g9xark/sonys_guerrilla_sounds_completely_done_with_the)
 - RSS feed: $source
 - date published: 2024-10-23T00:17:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1g9xark/sonys_guerrilla_sounds_completely_done_with_the/"> <img src="https://external-preview.redd.it/Vm3dFO14gcoEpp_OhmPF9mhGQHojRaCt45ztRtiZZRY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ea062f0e9745f3c214917a2d20ed90f47508df72" alt="Sony's Guerrilla Sounds Completely Done with the Killzone Series" title="Sony's Guerrilla Sounds Completely Done with the Killzone Series" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ThereBeGold"> /u/ThereBeGold </a> <br/> <span><a href="https://www.pushsquare.com/news/2024/10/sonys-guerrilla-sounds-completely-done-with-the-killzone-series">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1g9xark/sonys_guerrilla_sounds_completely_done_with_the/">[comments]</a></span> </td></tr></table>

## Its time to stop playing live service games and hit the dreaded BACKLOG!!!!
 - [https://www.reddit.com/r/gaming/comments/1g9x0by/its_time_to_stop_playing_live_service_games_and](https://www.reddit.com/r/gaming/comments/1g9x0by/its_time_to_stop_playing_live_service_games_and)
 - RSS feed: $source
 - date published: 2024-10-23T00:03:30+00:00

<!-- SC_OFF --><div class="md"><p>Bro I GUARANTEE that you have a backlog. And maybe you dont want to hear this but playing the same game that you lowkey dont even like anymore maybe its time to give the backlog a chance.<br/> Backloggery, grouvee, backloggd are good sites to track progress btw...</p> <p>figure out the games you have always wanted to play but just always told yourself &quot;i dont have the time...&quot;<br/> Max Payne?? Alan Wake?? Red Dead Redemption?? Alien Isolation?? Dead Space?? Resident Evil?? F.E.A.R.?? Hollow Knight?? Metroid Prime/Dread?? Castlevania?? Metal Gear Solid?? God of War?? Bioshock?? Ninja Gaiden?? Nioh?? Bloodbourne/demon/darksouls?? Saints Row?? Gravity Rush?? Signalis?? Tekken?? Portal?? Half Life??</p> <p>Chances are theres a game you&#39;ve been thinking of for literally YEARS but you&#39;re just to comfortable in COD, Apex, Fortnite, Overwatch, Rocket League because its &quot;familiar&quot; and maybe i&#39;m projecting a bit but i know that a

## What game sound or music theme sends you into a panic when you hear it?
 - [https://www.reddit.com/r/gaming/comments/1g9wxu3/what_game_sound_or_music_theme_sends_you_into_a](https://www.reddit.com/r/gaming/comments/1g9wxu3/what_game_sound_or_music_theme_sends_you_into_a)
 - RSS feed: $source
 - date published: 2024-10-23T00:00:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/gaming/comments/1g9wxu3/what_game_sound_or_music_theme_sends_you_into_a/"> <img src="https://preview.redd.it/cyqa9tuecewd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=705184db8e39911262ed84af88f3338246b1f956" alt="What game sound or music theme sends you into a panic when you hear it?" title="What game sound or music theme sends you into a panic when you hear it?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/2Scarhand"> /u/2Scarhand </a> <br/> <span><a href="https://i.redd.it/cyqa9tuecewd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/gaming/comments/1g9wxu3/what_game_sound_or_music_theme_sends_you_into_a/">[comments]</a></span> </td></tr></table>

