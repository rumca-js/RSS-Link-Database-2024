# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Had fun translating “You’re So Vain” into French. There are many ways to call someone vain in French
 - [https://www.youtube.com/watch?v=dMhj3QdIpuI](https://www.youtube.com/watch?v=dMhj3QdIpuI)
 - RSS feed: $source
 - date published: 2024-10-23T16:14:37+00:00

None

