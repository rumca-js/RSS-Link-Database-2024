# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## Seeking Emulator
 - [https://www.reddit.com/r/amiga/comments/1gabgus/seeking_emulator](https://www.reddit.com/r/amiga/comments/1gabgus/seeking_emulator)
 - RSS feed: $source
 - date published: 2024-10-23T14:09:08+00:00

<!-- SC_OFF --><div class="md"><p>Looking for an emulator for the A500/600, specifically one that mimics the OS/filesystem for software, not games. Either for Windows or Linux.</p> <p>Thanks.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Soekkon"> /u/Soekkon </a> <br/> <span><a href="https://www.reddit.com/r/amiga/comments/1gabgus/seeking_emulator/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1gabgus/seeking_emulator/">[comments]</a></span>

## Mental Hangover (Scoopex, 1990, Amiga OCS) HQ
 - [https://www.reddit.com/r/amiga/comments/1ga9a7l/mental_hangover_scoopex_1990_amiga_ocs_hq](https://www.reddit.com/r/amiga/comments/1ga9a7l/mental_hangover_scoopex_1990_amiga_ocs_hq)
 - RSS feed: $source
 - date published: 2024-10-23T12:26:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ga9a7l/mental_hangover_scoopex_1990_amiga_ocs_hq/"> <img src="https://external-preview.redd.it/gQhvYcM-H-o8SCByNOQbdMLBRtat_fMBBlRtMeN8Uqo.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=97bb5ec885b2c3de8977b9108a640f124812be55" alt="Mental Hangover (Scoopex, 1990, Amiga OCS) HQ" title="Mental Hangover (Scoopex, 1990, Amiga OCS) HQ" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HydratedCarrot"> /u/HydratedCarrot </a> <br/> <span><a href="https://youtu.be/cZETBFv6zWs?si=GI57N5aMyxjPBBXC">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ga9a7l/mental_hangover_scoopex_1990_amiga_ocs_hq/">[comments]</a></span> </td></tr></table>

## RGB SCART to HDMI for the Amiga 600
 - [https://www.reddit.com/r/amiga/comments/1ga8orw/rgb_scart_to_hdmi_for_the_amiga_600](https://www.reddit.com/r/amiga/comments/1ga8orw/rgb_scart_to_hdmi_for_the_amiga_600)
 - RSS feed: $source
 - date published: 2024-10-23T11:55:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ga8orw/rgb_scart_to_hdmi_for_the_amiga_600/"> <img src="https://preview.redd.it/bg0ub0r6whwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0adda344932426222efe0e2351a5d33cfdb403c6" alt="RGB SCART to HDMI for the Amiga 600" title="RGB SCART to HDMI for the Amiga 600" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I got a nice Amiga 600 with an RGB cable that works perfectly on my crt tv. I tried several SCART to HDMI adapters to make it work via HDMI but with no luck (black screen or very super dim, really faint impression). In this case, would it be the cable or the adapter? Would it be solved if I bought a OSSC? Thanks!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Retroaffaire"> /u/Retroaffaire </a> <br/> <span><a href="https://i.redd.it/bg0ub0r6whwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ga8orw/rgb_scart_to_hdmi_for_th

## [[ Loading Music ]] Last Ninja 2 – Original Soundtrack (1990) (Amiga)
 - [https://www.reddit.com/r/amiga/comments/1ga6px4/loading_music_last_ninja_2_original_soundtrack](https://www.reddit.com/r/amiga/comments/1ga6px4/loading_music_last_ninja_2_original_soundtrack)
 - RSS feed: $source
 - date published: 2024-10-23T09:54:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ga6px4/loading_music_last_ninja_2_original_soundtrack/"> <img src="https://external-preview.redd.it/ONsTQWR5-QPNYzK9fLBI0mY_huhbOws0fLJPsZospwM.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=5ff97756a88bf5e1b68efab395f605f8f209947f" alt="[[ Loading Music ]] Last Ninja 2 – Original Soundtrack (1990) (Amiga)" title="[[ Loading Music ]] Last Ninja 2 – Original Soundtrack (1990) (Amiga)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JGOR004"> /u/JGOR004 </a> <br/> <span><a href="https://www.youtube.com/watch?v=BK5fAHzZnJE">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ga6px4/loading_music_last_ninja_2_original_soundtrack/">[comments]</a></span> </td></tr></table>

## Amiga 500 game "Blood Money" wont run properly
 - [https://www.reddit.com/r/amiga/comments/1ga3xgd/amiga_500_game_blood_money_wont_run_properly](https://www.reddit.com/r/amiga/comments/1ga3xgd/amiga_500_game_blood_money_wont_run_properly)
 - RSS feed: $source
 - date published: 2024-10-23T06:29:36+00:00

<!-- SC_OFF --><div class="md"><p>I am trying to run the game Blood Money for the amiga 500 and there are multiple versions of the rom out there and i cannot get any of them to work. Some roms red screen, some crash saying &quot;guru meditation #00000003 , 00c01570&quot;, and one rom called &quot;Blood Money (1989)(Psygnosis)[cr Majestic][t Majestic]&quot; I am able to actually get into a game with but theres so many graphical flashes and glitches it makes it un-playable/un-able to see.</p> <p>Im using puae_libretro and ive tried combining disks when given 2 disks using note pad and listing eaching file name then saving as Blood Money(MD).m3u or INSERT GAME NAME HERE(MD).m3u (this method works for combinging my other disk amiga games).</p> <p>My question is has anyone been able to get Blood Money to run in an emulator if so lmk which rom you used (theres a couple different versions of the rom ie. majestic, cr orb, cr defjam,cr defjam t+2,cr defjam t+2 [a] ) and which emulator!</p> </d

## Roguecraft
 - [https://www.reddit.com/r/amiga/comments/1ga1vij/roguecraft](https://www.reddit.com/r/amiga/comments/1ga1vij/roguecraft)
 - RSS feed: $source
 - date published: 2024-10-23T04:17:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ga1vij/roguecraft/"> <img src="https://b.thumbs.redditmedia.com/zRu1VePT0Ca5lXYrtb1Ovsd4LsaVpNHG9EwGffuSRrY.jpg" alt="Roguecraft" title="Roguecraft" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Arrived today!! Roguecraft for Amiga! What perfect timing! This amazing game is just what I needed to get me in the #Halloween spirit. It&#39;s the ideal time to explore mysterious, creepy dungeons and face off against slimy monsters.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Maleficent_Rough_527"> /u/Maleficent_Rough_527 </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga1vij">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ga1vij/roguecraft/">[comments]</a></span> </td></tr></table>

## A Tribute Amiga Game
 - [https://www.reddit.com/r/amiga/comments/1g9xha1/a_tribute_amiga_game](https://www.reddit.com/r/amiga/comments/1g9xha1/a_tribute_amiga_game)
 - RSS feed: $source
 - date published: 2024-10-23T00:26:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1g9xha1/a_tribute_amiga_game/"> <img src="https://external-preview.redd.it/jJ5rlDvlVFZ0DayzrdKyM6cYPwioYsysxEg79Ysuby0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5d66f2be8ad836b53330bbf32a15983ebd43c36c" alt="A Tribute Amiga Game" title="A Tribute Amiga Game" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>&quot;Skinny Marley&quot; is a heartfelt tribute to my beloved Marley, who left too soon. In this Amiga game, you help Marley find peace by gathering his owner’s belongings. Created with love and over 100 hours of dedication, it&#39;s a journey about love, loss, and longing.</p> <p>Available here: <a href="https://tooizzi.itch.io/skinny-marley">https://tooizzi.itch.io/skinny-marley</a> </p> <p><a href="https://preview.redd.it/1pytyym6hewd1.png?width=692&amp;format=png&amp;auto=webp&amp;s=1cef189d9160731310f2740b9b5fdbff159b84d1">https://preview.redd.it/1pytyym6hewd1.png?width=692&amp;format=png&amp;auto=webp

