# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Podcast: How the U.S. Government Tracks Your Phone
 - [https://www.404media.co/podcast-how-the-u-s-government-tracks-your-phone](https://www.404media.co/podcast-how-the-u-s-government-tracks-your-phone)
 - RSS feed: $source
 - date published: 2024-10-23T12:48:49+00:00

A massive story on how a U.S. government-bought tool can track phones at abortion clinics; a very special guest drops by to talk about The Abstract; and how we found where a Musk-funded PAC is targeting Snapchat ads.

## Inside the U.S. Government-Bought Tool That Can Track Phones at Abortion Clinics
 - [https://www.404media.co/inside-the-u-s-government-bought-tool-that-can-track-phones-at-abortion-clinics](https://www.404media.co/inside-the-u-s-government-bought-tool-that-can-track-phones-at-abortion-clinics)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:40+00:00

Privacy advocates gained access to a powerful tool bought by U.S. law enforcement agencies that can track smartphone locations around the world. Abortion clinics, places of worship, and individual people can all be monitored without a warrant.

