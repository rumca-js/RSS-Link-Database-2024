# Source:The New Yorker, URL:https://www.newyorker.com/feed/rss, language:en-US

## Charts for Talking to People
 - [https://www.newyorker.com/humor/shouts-murmurs/charts-for-talking-to-people](https://www.newyorker.com/humor/shouts-murmurs/charts-for-talking-to-people)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

Surefire Conversational Fodder by Group, Topic Correlations, and more.

## Door-Knocking in Door County
 - [https://www.newyorker.com/news/the-lede/door-knocking-in-door-county-wisconsin-2024-election](https://www.newyorker.com/news/the-lede/door-knocking-in-door-county-wisconsin-2024-election)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

A bellwether county in Wisconsin appears evenly divided in the final stretch.

## The Crossword: Wednesday, October 23, 2024
 - [https://www.newyorker.com/puzzles-and-games-dept/crossword/2024/10/23](https://www.newyorker.com/puzzles-and-games-dept/crossword/2024/10/23)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

Handel oratorio that contains the “Hallelujah” Chorus: seven letters.

## The Crypto Betting Platform Predicting a Trump Win
 - [https://www.newyorker.com/culture/infinite-scroll/the-crypto-betting-platform-predicting-a-trump-win](https://www.newyorker.com/culture/infinite-scroll/the-crypto-betting-platform-predicting-a-trump-win)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

Polymarket has seen a recent surge in pro-Trump election bets. Is it the movement of a rational market or a concerted campaign?

## The Frightening Familiarity of Late-Nineties Office Photos
 - [https://www.newyorker.com/culture/photo-booth/the-frightening-familiarity-of-late-nineties-office-photos](https://www.newyorker.com/culture/photo-booth/the-frightening-familiarity-of-late-nineties-office-photos)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

Lars Tunbjörk documented the rise of alienating online work. His images should remind us that it didn’t have to be this way.

## The Megachurch That Tried to Confront Racism
 - [https://www.newyorker.com/books/under-review/the-megachurch-that-tried-to-confront-racism](https://www.newyorker.com/books/under-review/the-megachurch-that-tried-to-confront-racism)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

A political scientist spent years at Crossroads Church, talking to members of a bespoke racial-justice course. What did she find?

## “Anora” Is More for Show Than for Substance
 - [https://www.newyorker.com/culture/the-front-row/anora-is-more-for-show-than-for-substance](https://www.newyorker.com/culture/the-front-row/anora-is-more-for-show-than-for-substance)
 - RSS feed: $source
 - date published: 2024-10-23T01:05:19+00:00

Sean Baker’s hectic drama, about the mismatch of a sex worker and an oligarch’s son, masks its synthetic storytelling with authentic locations.

