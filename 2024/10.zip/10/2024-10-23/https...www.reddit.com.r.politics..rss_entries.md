# Source:Reddit - Politics, URL:https://www.reddit.com/r/politics/.rss, language:en-US

## Trump, 78, says Obama, 63, is ‘exhausted’ and ‘looks old’
 - [https://www.reddit.com/r/politics/comments/1gaa7pe/trump_78_says_obama_63_is_exhausted_and_looks_old](https://www.reddit.com/r/politics/comments/1gaa7pe/trump_78_says_obama_63_is_exhausted_and_looks_old)
 - RSS feed: $source
 - date published: 2024-10-23T13:11:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1gaa7pe/trump_78_says_obama_63_is_exhausted_and_looks_old/"> <img src="https://external-preview.redd.it/rD2X8NwEfu6oURHpd4IxDPEsPumizpeTdVuwiOJS0ZI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6bfaad25575c4951ab933ec0b3e55dadd0673cfb" alt="Trump, 78, says Obama, 63, is ‘exhausted’ and ‘looks old’" title="Trump, 78, says Obama, 63, is ‘exhausted’ and ‘looks old’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Happy_Traveller_2023"> /u/Happy_Traveller_2023 </a> <br/> <span><a href="https://www.independent.co.uk/news/world/americas/us-politics/donald-trump-obama-age-old-exhausted-eminem-b2634033.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1gaa7pe/trump_78_says_obama_63_is_exhausted_and_looks_old/">[comments]</a></span> </td></tr></table>

## Harris lead among young voters grows to 20 points in new poll
 - [https://www.reddit.com/r/politics/comments/1ga9fxh/harris_lead_among_young_voters_grows_to_20_points](https://www.reddit.com/r/politics/comments/1ga9fxh/harris_lead_among_young_voters_grows_to_20_points)
 - RSS feed: $source
 - date published: 2024-10-23T12:34:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga9fxh/harris_lead_among_young_voters_grows_to_20_points/"> <img src="https://external-preview.redd.it/VqERN9Jk1wwUHrFHkCG-nW1MLXIGdH2L2jE542NFnUU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=da44c978d103b736a7f253ba7c126b8e02e66bb8" alt="Harris lead among young voters grows to 20 points in new poll" title="Harris lead among young voters grows to 20 points in new poll" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/etfvfva"> /u/etfvfva </a> <br/> <span><a href="https://thehill.com/homenews/campaign/4946514-harris-trump-younger-voters-poll/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga9fxh/harris_lead_among_young_voters_grows_to_20_points/">[comments]</a></span> </td></tr></table>

## Aileen Cannon Being Considered as Donald Trump's AG Sparks Fury: 'Insane'
 - [https://www.reddit.com/r/politics/comments/1ga8tbj/aileen_cannon_being_considered_as_donald_trumps](https://www.reddit.com/r/politics/comments/1ga8tbj/aileen_cannon_being_considered_as_donald_trumps)
 - RSS feed: $source
 - date published: 2024-10-23T12:02:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga8tbj/aileen_cannon_being_considered_as_donald_trumps/"> <img src="https://external-preview.redd.it/QibFNthSScnav1i1zA4aRetfInASJUFtneO0eFScH_w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b3af7c5e1e5482a534150f2f66b8d6a397d9044e" alt="Aileen Cannon Being Considered as Donald Trump's AG Sparks Fury: 'Insane'" title="Aileen Cannon Being Considered as Donald Trump's AG Sparks Fury: 'Insane'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/P_a_s_g_i_t_24"> /u/P_a_s_g_i_t_24 </a> <br/> <span><a href="https://www.newsweek.com/donald-trump-aileen-cannon-attorney-general-mar-lago-florida-classified-documents-1973456?10232024">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga8tbj/aileen_cannon_being_considered_as_donald_trumps/">[comments]</a></span> </td></tr></table>

## /r/Politics' 2024 US Elections Live Thread, Part 49
 - [https://www.reddit.com/r/politics/comments/1ga8mdo/rpolitics_2024_us_elections_live_thread_part_49](https://www.reddit.com/r/politics/comments/1ga8mdo/rpolitics_2024_us_elections_live_thread_part_49)
 - RSS feed: $source
 - date published: 2024-10-23T11:51:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga8mdo/rpolitics_2024_us_elections_live_thread_part_49/"> <img src="https://b.thumbs.redditmedia.com/6VVMgGipe7XrGi7CSABeYGc5q-SEcQseXpVVbyKZs6U.jpg" alt="/r/Politics' 2024 US Elections Live Thread, Part 49" title="/r/Politics' 2024 US Elections Live Thread, Part 49" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PoliticsModeratorBot"> /u/PoliticsModeratorBot </a> <br/> <span><a href="https://www.reddit.com/live/1db9knzhqzdfp/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga8mdo/rpolitics_2024_us_elections_live_thread_part_49/">[comments]</a></span> </td></tr></table>

## Cruz, Allred in virtual dead heat in Texas Senate race: Poll
 - [https://www.reddit.com/r/politics/comments/1ga861c/cruz_allred_in_virtual_dead_heat_in_texas_senate](https://www.reddit.com/r/politics/comments/1ga861c/cruz_allred_in_virtual_dead_heat_in_texas_senate)
 - RSS feed: $source
 - date published: 2024-10-23T11:27:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga861c/cruz_allred_in_virtual_dead_heat_in_texas_senate/"> <img src="https://external-preview.redd.it/g6sTrKcdYghScKP3XjQ3PyYeO4LkSFBg9f4UAK_RtZI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a7aced086e4d38af64cc5c3b2c7f5f1de608b0a1" alt="Cruz, Allred in virtual dead heat in Texas Senate race: Poll" title="Cruz, Allred in virtual dead heat in Texas Senate race: Poll" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Chips1709"> /u/Chips1709 </a> <br/> <span><a href="https://thehill.com/homenews/campaign/4947749-cruz-allred-texas-senate-race-poll/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga861c/cruz_allred_in_virtual_dead_heat_in_texas_senate/">[comments]</a></span> </td></tr></table>

## “Red Wave” Redux: Are GOP Polls Rigging the Averages in Trump’s Favor?
 - [https://www.reddit.com/r/politics/comments/1ga7y8o/red_wave_redux_are_gop_polls_rigging_the_averages](https://www.reddit.com/r/politics/comments/1ga7y8o/red_wave_redux_are_gop_polls_rigging_the_averages)
 - RSS feed: $source
 - date published: 2024-10-23T11:14:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga7y8o/red_wave_redux_are_gop_polls_rigging_the_averages/"> <img src="https://external-preview.redd.it/KrB45HI21h06O0sEHIP-OSbc8XYckzI_cg_ODuSFSAA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9637c7c78964f7cffc84dd26f10c355752950bd3" alt="“Red Wave” Redux: Are GOP Polls Rigging the Averages in Trump’s Favor?" title="“Red Wave” Redux: Are GOP Polls Rigging the Averages in Trump’s Favor?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://newrepublic.com/article/187425/gop-polls-rigging-averages-trump">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga7y8o/red_wave_redux_are_gop_polls_rigging_the_averages/">[comments]</a></span> </td></tr></table>

## US public schools burned up nearly $3.2bn fending off rightwing culture attacks – report
 - [https://www.reddit.com/r/politics/comments/1ga7lwx/us_public_schools_burned_up_nearly_32bn_fending](https://www.reddit.com/r/politics/comments/1ga7lwx/us_public_schools_burned_up_nearly_32bn_fending)
 - RSS feed: $source
 - date published: 2024-10-23T10:53:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga7lwx/us_public_schools_burned_up_nearly_32bn_fending/"> <img src="https://external-preview.redd.it/UHtYrf8qyH95-s55zZCJeC9-Yf_TlHssgHkt4aoX7Bc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=dce3aa59a643122c7c88de2264e2aff7b841ab0e" alt="US public schools burned up nearly $3.2bn fending off rightwing culture attacks – report" title="US public schools burned up nearly $3.2bn fending off rightwing culture attacks – report" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br/> <span><a href="https://www.theguardian.com/us-news/ng-interactive/2024/oct/23/public-schools-culture-war-cost">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga7lwx/us_public_schools_burned_up_nearly_32bn_fending/">[comments]</a></span> </td></tr></table>

## Any other CEO would have been fired for what Elon Musk just said
 - [https://www.reddit.com/r/politics/comments/1ga6y4v/any_other_ceo_would_have_been_fired_for_what_elon](https://www.reddit.com/r/politics/comments/1ga6y4v/any_other_ceo_would_have_been_fired_for_what_elon)
 - RSS feed: $source
 - date published: 2024-10-23T10:10:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga6y4v/any_other_ceo_would_have_been_fired_for_what_elon/"> <img src="https://external-preview.redd.it/j3g5dER2KvC_IqTkE7C4gS5Pf_T4_DnDUXIHxUsbIx8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=06a16fff958a8bd76eb0945a67492e1d854cf2f9" alt="Any other CEO would have been fired for what Elon Musk just said " title="Any other CEO would have been fired for what Elon Musk just said " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turuial"> /u/Turuial </a> <br/> <span><a href="https://amp.cnn.com/cnn/2024/10/23/business/elon-musk-nazi-jokes">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga6y4v/any_other_ceo_would_have_been_fired_for_what_elon/">[comments]</a></span> </td></tr></table>

## Donald Trump campaign manager shared posts in 2021 saying Trump’s lies caused the violence on January 6
 - [https://www.reddit.com/r/politics/comments/1ga6gdu/donald_trump_campaign_manager_shared_posts_in](https://www.reddit.com/r/politics/comments/1ga6gdu/donald_trump_campaign_manager_shared_posts_in)
 - RSS feed: $source
 - date published: 2024-10-23T09:35:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga6gdu/donald_trump_campaign_manager_shared_posts_in/"> <img src="https://external-preview.redd.it/V2vque7eZF-1u0bi1L-MXiLq0-X5poyDlvT5uug5ZIk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=726e585a9d3f616f2d0baf7aa12ca8a5fc5265a2" alt="Donald Trump campaign manager shared posts in 2021 saying Trump’s lies caused the violence on January 6" title="Donald Trump campaign manager shared posts in 2021 saying Trump’s lies caused the violence on January 6" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PrintOk8045"> /u/PrintOk8045 </a> <br/> <span><a href="https://www.cnn.com/2024/10/23/politics/trump-campaign-manager-january-6/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga6gdu/donald_trump_campaign_manager_shared_posts_in/">[comments]</a></span> </td></tr></table>

## Trump Is a Hitler-Loving Literal Fascist, Says Ex-Chief of Staff
 - [https://www.reddit.com/r/politics/comments/1ga2xej/trump_is_a_hitlerloving_literal_fascist_says](https://www.reddit.com/r/politics/comments/1ga2xej/trump_is_a_hitlerloving_literal_fascist_says)
 - RSS feed: $source
 - date published: 2024-10-23T05:23:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga2xej/trump_is_a_hitlerloving_literal_fascist_says/"> <img src="https://external-preview.redd.it/o6a9wogYDib1nyp16cvLhz7dlCP8SlbwCfLCvRSRc7c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aabb70f2177afdb2b59731af5fe0515c13ef5c8f" alt="Trump Is a Hitler-Loving Literal Fascist, Says Ex-Chief of Staff" title="Trump Is a Hitler-Loving Literal Fascist, Says Ex-Chief of Staff" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Iknowwecanmakeit"> /u/Iknowwecanmakeit </a> <br/> <span><a href="https://www.thedailybeast.com/trump-is-a-hitler-loving-literal-fascist-says-ex-chief-of-staff/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga2xej/trump_is_a_hitlerloving_literal_fascist_says/">[comments]</a></span> </td></tr></table>

## Former White House chief of staff John Kelly says Trump meets the definition of a 'fascist'
 - [https://www.reddit.com/r/politics/comments/1ga1b8m/former_white_house_chief_of_staff_john_kelly_says](https://www.reddit.com/r/politics/comments/1ga1b8m/former_white_house_chief_of_staff_john_kelly_says)
 - RSS feed: $source
 - date published: 2024-10-23T03:45:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga1b8m/former_white_house_chief_of_staff_john_kelly_says/"> <img src="https://external-preview.redd.it/bYTShJaRxuM1QZ5Mu8YUeCVcYJHwDaXGk_lgsXCV6nc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9630e6f3f89ba3df1e522a92886615498a212b6b" alt="Former White House chief of staff John Kelly says Trump meets the definition of a 'fascist'" title="Former White House chief of staff John Kelly says Trump meets the definition of a 'fascist'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silent-Resort-3076"> /u/Silent-Resort-3076 </a> <br/> <span><a href="https://www.nbcnews.com/politics/2024-election/john-kelly-says-donald-trump-meets-definition-fascist-rcna176706">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga1b8m/former_white_house_chief_of_staff_john_kelly_says/">[comments]</a></span> </td></tr></table>

## Bob and Kristina Lange, Republican farmers who starred in a Kamala Harris campaign ad, say their Republican friends ‘are thanking us for what we’re doing’
 - [https://www.reddit.com/r/politics/comments/1ga05cv/bob_and_kristina_lange_republican_farmers_who](https://www.reddit.com/r/politics/comments/1ga05cv/bob_and_kristina_lange_republican_farmers_who)
 - RSS feed: $source
 - date published: 2024-10-23T02:41:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ga05cv/bob_and_kristina_lange_republican_farmers_who/"> <img src="https://external-preview.redd.it/rz4r53zEMXSFSwW6IFQ8ePYPKF-Fy9H5gE0vgs9CfyE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4318b861eddc77df7264ecf0902b2675be609c9e" alt="Bob and Kristina Lange, Republican farmers who starred in a Kamala Harris campaign ad, say their Republican friends ‘are thanking us for what we’re doing’" title="Bob and Kristina Lange, Republican farmers who starred in a Kamala Harris campaign ad, say their Republican friends ‘are thanking us for what we’re doing’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dizzy-Inspection-492"> /u/Dizzy-Inspection-492 </a> <br/> <span><a href="https://www.foxnews.com/video/6363558985112">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ga05cv/bob_and_kristina_lange_republican_farmers_who/">[comments]</a></span> </td></tr></t

## Obama jokes his "palms are sweaty" after Eminem introduction at Detroit rally
 - [https://www.reddit.com/r/politics/comments/1g9yq62/obama_jokes_his_palms_are_sweaty_after_eminem](https://www.reddit.com/r/politics/comments/1g9yq62/obama_jokes_his_palms_are_sweaty_after_eminem)
 - RSS feed: $source
 - date published: 2024-10-23T01:27:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g9yq62/obama_jokes_his_palms_are_sweaty_after_eminem/"> <img src="https://external-preview.redd.it/k2_dMFkichcTwGZnz8f5rJT1I04mINgoX-_Nwr0RAXk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=15ffd2194e4eb98a9233796a92f82a913fc3d5bc" alt="Obama jokes his &quot;palms are sweaty&quot; after Eminem introduction at Detroit rally" title="Obama jokes his &quot;palms are sweaty&quot; after Eminem introduction at Detroit rally" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MoralClimber"> /u/MoralClimber </a> <br/> <span><a href="https://www.nbcnews.com/video/obama-and-eminem-campaign-for-harris-in-detroit-222433861838">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g9yq62/obama_jokes_his_palms_are_sweaty_after_eminem/">[comments]</a></span> </td></tr></table>

## Kamala Harris vows to double federal minimum wage to $15
 - [https://www.reddit.com/r/politics/comments/1g9y20e/kamala_harris_vows_to_double_federal_minimum_wage](https://www.reddit.com/r/politics/comments/1g9y20e/kamala_harris_vows_to_double_federal_minimum_wage)
 - RSS feed: $source
 - date published: 2024-10-23T00:54:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g9y20e/kamala_harris_vows_to_double_federal_minimum_wage/"> <img src="https://external-preview.redd.it/_FUF8T2rbwDAYiv7uEqe9lFIpAoRcjFiBc4GPjsgjLY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=95e66b8c3523cfc92f98b871d7b51e05401e95fd" alt="Kamala Harris vows to double federal minimum wage to $15" title="Kamala Harris vows to double federal minimum wage to $15" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheTelegraph"> /u/TheTelegraph </a> <br/> <span><a href="https://www.telegraph.co.uk/us/politics/2024/10/22/election-2024-kamala-harris-to-be-interviewed-on-nbc/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g9y20e/kamala_harris_vows_to_double_federal_minimum_wage/">[comments]</a></span> </td></tr></table>

