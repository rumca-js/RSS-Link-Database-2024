# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Peter Todd in hiding after being “unmasked” as Bitcoin creator
 - [https://arstechnica.com/tech-policy/2024/10/peter-todd-in-hiding-after-being-unmasked-as-bitcoin-creator](https://arstechnica.com/tech-policy/2024/10/peter-todd-in-hiding-after-being-unmasked-as-bitcoin-creator)
 - RSS feed: $source
 - date published: 2024-10-23T12:47:38+00:00


            An HBO documentary says he is the real Satoshi Nakamoto.
          

## After nozzle failure, Space Force is “assessing” impacts to Vulcan schedule
 - [https://arstechnica.com/space/2024/10/space-force-official-expects-to-certify-vulcan-rocket-despite-nozzle-failure](https://arstechnica.com/space/2024/10/space-force-official-expects-to-certify-vulcan-rocket-despite-nozzle-failure)
 - RSS feed: $source
 - date published: 2024-10-23T01:29:04+00:00


            "It was a successful Cert flight, and now we’re knee deep in finalizing certification."
          

