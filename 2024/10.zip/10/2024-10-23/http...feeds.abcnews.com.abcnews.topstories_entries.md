# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

##  Turkey reports casualties in 'terrorist attack' on aerospace facility
 - [https://abcnews.go.com/International/turkey-reports-casualties-terrorist-attack-aerospace-facility/story?id=115063342](https://abcnews.go.com/International/turkey-reports-casualties-terrorist-attack-aerospace-facility/story?id=115063342)
 - RSS feed: $source
 - date published: 2024-10-23T10:25:01+00:00

Turkey's interior minister reported deaths and injuries after a "terrorist attack" at Turkish Aerospace Industries facilities in the capital Ankara on Wednesday.

##  John Kelly comes out swinging against Trump
 - [https://abcnews.go.com/Politics/john-kelly-swinging-trump/story?id=115061457](https://abcnews.go.com/Politics/john-kelly-swinging-trump/story?id=115061457)
 - RSS feed: $source
 - date published: 2024-10-23T10:24:03+00:00

John Kelly, a former chief of staff to former President Donald Trump, hammered his former boss in a stunningly public fashion Tuesday just two weeks before Election Day.

##  DOD ordered to turn over records from Trump's Arlington National Cemetery incident
 - [https://abcnews.go.com/Politics/judge-orders-dod-turn-records-trumps-arlington-national/story?id=115060948](https://abcnews.go.com/Politics/judge-orders-dod-turn-records-trumps-arlington-national/story?id=115060948)
 - RSS feed: $source
 - date published: 2024-10-23T09:39:40+00:00

The Trump campaign denies any altercation with a cemetery employee. 

## WATCH:  Dramatic footage shows Beirut building demolished in Israeli airstrike
 - [https://abcnews.go.com/International/video/dramatic-footage-shows-beirut-building-demolished-israeli-airstrike-115062986](https://abcnews.go.com/International/video/dramatic-footage-shows-beirut-building-demolished-israeli-airstrike-115062986)
 - RSS feed: $source
 - date published: 2024-10-23T09:33:52+00:00

The IDF said the building was a Hezbollah facility.

## WATCH:  Trump blasted by former chief of staff
 - [https://abcnews.go.com/GMA/News/video/trump-blasted-former-chief-staff-115057593](https://abcnews.go.com/GMA/News/video/trump-blasted-former-chief-staff-115057593)
 - RSS feed: $source
 - date published: 2024-10-23T09:12:48+00:00

Donald Trump’s former chief of staff and retired General John Kelly called the former president a “fascist” with no concept for the rule of law or constitution.

## WATCH:  Harris tries to woo unhappy Republican voters as Trump doubles down on his base
 - [https://abcnews.go.com/GMA/News/video/harris-woo-unhappy-republican-voters-trump-doubles-base-115057589](https://abcnews.go.com/GMA/News/video/harris-woo-unhappy-republican-voters-trump-doubles-base-115057589)
 - RSS feed: $source
 - date published: 2024-10-23T09:12:46+00:00

The most dire warnings against a second Trump administration have come from people who served him in the most sensitive and important positions.

## WATCH:  Eminem introduces Obama at campaign rally in Detroit
 - [https://abcnews.go.com/Politics/video/eminem-introduces-obama-campaign-rally-detroit-115048964](https://abcnews.go.com/Politics/video/eminem-introduces-obama-campaign-rally-detroit-115048964)
 - RSS feed: $source
 - date published: 2024-10-23T07:40:31+00:00

Rapper Eminem took the stage in his home state of Michigan to introduce former President Barack Obama at a campaign event for Vice President Kamala Harris.

##  North Korean troops are already in Russia, Lloyd Austin confirms
 - [https://abcnews.go.com/International/north-korean-troops-russia-lloyd-austin-confirms/story?id=115057351](https://abcnews.go.com/International/north-korean-troops-russia-lloyd-austin-confirms/story?id=115057351)
 - RSS feed: $source
 - date published: 2024-10-23T07:09:38+00:00

Defense Secretary Lloyd Austin confirmed Wednesday the U.S. has evidence that North Korean troops are in Russia.

## WATCH:  Terrifying moment dog walker narrowly avoids landslide
 - [https://abcnews.go.com/International/video/terrifying-moment-dog-walker-narrowly-avoids-landslide-115056768](https://abcnews.go.com/International/video/terrifying-moment-dog-walker-narrowly-avoids-landslide-115056768)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:59+00:00

Bystander footage captured the terrifying moment part of a cliff collapsed and fell onto beach huts, with the landslide nearly wiping out a dog walker in Bournemouth, England.

##  A man accused of threatening to kill Dem election officials will likely plead guilty
 - [https://abcnews.go.com/Politics/wireStory/man-accused-threatening-kill-democratic-election-officials-plead-115053430](https://abcnews.go.com/Politics/wireStory/man-accused-threatening-kill-democratic-election-officials-plead-115053430)
 - RSS feed: $source
 - date published: 2024-10-23T03:18:15+00:00

A man accused of making repeated threats to kill the top election officials in Colorado and Arizona as well as judges and federal law enforcement agents is expected to plead guilty in federal court on Wednesday

##  Fernando Valenzuela, Mexican-born pitcher whose feats for Dodgers fueled 'Fernandomania,' dies at 63
 - [https://abcnews.go.com/Sports/wireStory/fernando-valenzuela-mexican-born-pitcher-feats-dodgers-fueled-115052332](https://abcnews.go.com/Sports/wireStory/fernando-valenzuela-mexican-born-pitcher-feats-dodgers-fueled-115052332)
 - RSS feed: $source
 - date published: 2024-10-23T00:22:16+00:00

Fernando Valenzuela, the Los Angeles Dodgers pitching ace who inspired &ldquo;Fernandomania&rdquo; in the early 1980s, has died

