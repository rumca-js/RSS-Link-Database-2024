# Source:Guerrilla Miniature Games, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug, language:en

## KILL TEAM (2024) - Airborn Operations: Part 2
 - [https://www.youtube.com/watch?v=Rz5WbGsZ2V0](https://www.youtube.com/watch?v=Rz5WbGsZ2V0)
 - RSS feed: $source
 - date published: 2024-10-23T12:00:38+00:00

The Tempestus Aquilons are taking to the Hives of Volkus to dig out the Vespids of the Tau Empire in the first of the three-part Narrative Campaign from HIVESTORM! Having landed in and secured the Anti-Air guns, the Aquilons must now attack the Strongholds of the Vespids!

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/guerrilla-miniature-games/

GMG T-Shirts and Hoodies HERE: https://shop.spreadshirt.ca/guerrillaminiaturegames/

Intro and Outro music used via Creative Commons "Benji" by Dyalla

