# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Ten rajd już był. Osiemdziesiąt metrów i gol
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/vinicius-junior-i-spektakularny-rajd-w-meczu-real-madryt-borussia-dortmund.-porownania-do-garetha-balea-i-pelego_sto20047711/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/vinicius-junior-i-spektakularny-rajd-w-meczu-real-madryt-borussia-dortmund.-porownania-do-garetha-balea-i-pelego_sto20047711/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:21:59+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-614842-imagetitle/alternates/LANDSCAPE_1280" alt="Ten rajd już był. Osiemdziesiąt metrów i gol" />
    Vinicius Junior skopiował wyczyn Garetha Bale'a. 
    
    

## Legia składa kondolencje po karambolu
 - [https://eurosport.tvn24.pl/pilka-nozna/legia-warszawa-sklada-kondolencje-bliskim-ofiar-karambolu-pod-gdanskiem_sto20047715/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/legia-warszawa-sklada-kondolencje-bliskim-ofiar-karambolu-pod-gdanskiem_sto20047715/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:58:04+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1509404-imagetitle/alternates/LANDSCAPE_1280" alt="Legia składa kondolencje po karambolu" />
    Doszło do niego w piątek pod Gdańskiem. Dzieci, które zginęły, wracały z meczu Lechia - Legia. 
    
    

## Alarm w Realu przed El Clasico
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2024-2025/thibaut-courtois-kontuzjowany-przed-meczem-realu-z-barcelona-w-el-clasico_sto20047712/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2024-2025/thibaut-courtois-kontuzjowany-przed-meczem-realu-z-barcelona-w-el-clasico_sto20047712/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:38:30+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9618496-imagetitle/alternates/LANDSCAPE_1280" alt="Alarm w Realu przed El Clasico" />
    Thibaut Courtois kontuzjowany. 
    
    

## Wyjątkowe wsparcie dla Glika
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2024-2025/kamil-glik-z-wyrazami-wsparcia-od-mlodych-pilkarzy-gks-u-jastrzebie_sto20047698/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2024-2025/kamil-glik-z-wyrazami-wsparcia-od-mlodych-pilkarzy-gks-u-jastrzebie_sto20047698/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:33:44+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9953517-imagetitle/alternates/LANDSCAPE_1280" alt="Wyjątkowe wsparcie dla Glika" />
    Byłego reprezentanta czeka walka o powrót na boisko. 
    
    

## "Niesłychane". Bez porażki i straconego gola, ale tylko drugie miejsce
 - [https://eurosport.tvn24.pl/pilka-nozna/pilkarki-angelholm-ff-nie-przegraly-meczu-i-nie-stracily-gola-ligi-nie-wygraly-bezwzgledne-punktowe-szalenstwo_sto20047657/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pilkarki-angelholm-ff-nie-przegraly-meczu-i-nie-stracily-gola-ligi-nie-wygraly-bezwzgledne-punktowe-szalenstwo_sto20047657/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:13:42+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-730268-imagetitle/alternates/LANDSCAPE_1280" alt=""Niesłychane". Bez porażki i straconego gola, ale tylko drugie miejsce" />
    Zagadka w szwedzkiej piłce. 
    
    

## 23-0. Liczby, którymi Lewandowski miażdży
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/robert-lewandowski-vs.-harry-kane-przed-meczem-barcelona-bayern.-porownanie-osiagniec-i-rekordow_sto20047686/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/robert-lewandowski-vs.-harry-kane-przed-meczem-barcelona-bayern.-porownanie-osiagniec-i-rekordow_sto20047686/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:33:46+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6141137-imagetitle/alternates/LANDSCAPE_1280" alt="23-0. Liczby, którymi Lewandowski miażdży" />
    Robert Lewandowski czy Harry Kane? Porównanie snajperów przed hitem.  
    
    

## Jak fundusze unijne mogą wesprzeć zieloną transformację firm?
 - [https://tvn24.pl/fundusze-europejskie-dla-biznesu/jak-fundusze-unijne-moga-wesprzec-zielona-transformacje-firm-st8147118?source=rss](https://tvn24.pl/fundusze-europejskie-dla-biznesu/jak-fundusze-unijne-moga-wesprzec-zielona-transformacje-firm-st8147118?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:35:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1219050-jak-fundusze-unijne-moga-wesprzec-zielona-transformacje-firm-ph8147742/alternates/LANDSCAPE_1280" alt="Jak fundusze unijne mogą wesprzeć zieloną transformację firm?" />
    Współczesny świat stawia przed firmami wiele wyzwań. Jednym z największych są zmiany klimatyczne, do których musimy się dostosować i sprawić, by nasze przedsiębiorstwo było bardziej przyjazne środowisku. 
    
    

## Smutek w Niemczech. "Horror Borussii" 
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/niemieckie-media-po-meczu-real-madryt-borussia-dortmund_sto20047644/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/niemieckie-media-po-meczu-real-madryt-borussia-dortmund_sto20047644/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:22:54+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9493210-imagetitle/alternates/LANDSCAPE_1280" alt="Smutek w Niemczech. "Horror Borussii" " />
    Po dotkliwej porażce z Realem.
    
    

## "Konie zwykle nie przeżywają takich rzeczy"
 - [https://eurosport.tvn24.pl/wyscigi-konne/jason-collett-uratowal-zycie-swojego-konia-po-tym-jak-doznal-krwotoku-z-pluc-w-trakcie-wyscigu_sto20047649/story.shtml?source=rss](https://eurosport.tvn24.pl/wyscigi-konne/jason-collett-uratowal-zycie-swojego-konia-po-tym-jak-doznal-krwotoku-z-pluc-w-trakcie-wyscigu_sto20047649/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:50:11+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2505746-imagetitle/alternates/LANDSCAPE_1280" alt=""Konie zwykle nie przeżywają takich rzeczy"" />
    Dramatyczne sceny podczas wyścigu.
    
    

## Jaki ojciec, taki syn. Pierwszy taki duet w historii
 - [https://eurosport.tvn24.pl/koszykowka/nba/2024-2025/lebron-i-bronny-james-zagrali-wspolnie-dla-los-angeles-lakers.-pierwszy-taki-przypadek-w-historii-nba_sto20047639/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2024-2025/lebron-i-bronny-james-zagrali-wspolnie-dla-los-angeles-lakers.-pierwszy-taki-przypadek-w-historii-nba_sto20047639/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:39:24+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6231100-imagetitle/alternates/LANDSCAPE_1280" alt="Jaki ojciec, taki syn. Pierwszy taki duet w historii" />
    Ruszyła NBA. 
    
    

## Hiszpania wstrząśnięta. "Bardzo surowa kara" od Realu
 - [https://eurosport.tvn24.pl/pilka-nozna/hiszpanskie-media-zachwycone-po-meczu-real-madryt-borussia-dortmund-w-lidze-mistrzow.-bardzo-surowa-kara_sto20047637/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/hiszpanskie-media-zachwycone-po-meczu-real-madryt-borussia-dortmund-w-lidze-mistrzow.-bardzo-surowa-kara_sto20047637/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:22:42+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2555570-imagetitle/alternates/LANDSCAPE_1280" alt="Hiszpania wstrząśnięta. "Bardzo surowa kara" od Realu" />
    Po zwycięstwie 5:2 z Borussią Dortmund. 
    
    

## Tenisiści protestują. "Dlaczego chcecie zmienić piękno tej gry?"
 - [https://eurosport.tvn24.pl/tenis/zmiany-w-tenisie.-nie-wszyscy-zawodnicy-sa-zadowoleni_sto20047593/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/zmiany-w-tenisie.-nie-wszyscy-zawodnicy-sa-zadowoleni_sto20047593/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T04:42:32+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1033404-imagetitle/alternates/LANDSCAPE_1280" alt="Tenisiści protestują. "Dlaczego chcecie zmienić piękno tej gry?"" />
    Tenisowe władze zdecydowały o historycznej zmianie. 
    
    

## Ta decyzja pogrążyła Borussię? "Jego plan obrócił się przeciw niemu"
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/real-madryt-borussia-dortmund.-o-porazce-bvb-zadecydowala-decyzja-trenera-nuriego-sahina_sto20047624/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/real-madryt-borussia-dortmund.-o-porazce-bvb-zadecydowala-decyzja-trenera-nuriego-sahina_sto20047624/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T04:28:46+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8801856-imagetitle/alternates/LANDSCAPE_1280" alt="Ta decyzja pogrążyła Borussię? "Jego plan obrócił się przeciw niemu"" />
    Piłkarze Borussii Dortmund grali jak z nut i wydawało się, że we wtorkowy wieczór uciszą publiczność zgromadzoną na Santiago Bernabeu.
    
    

## Euforia bohatera Realu. Po meczu złożył deklarację
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/deklaracja-vinicusa-junior-po-meczu-real-madryt-borussia-dortmund_sto20047627/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2024-2025/deklaracja-vinicusa-junior-po-meczu-real-madryt-borussia-dortmund_sto20047627/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T04:20:42+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8804706-imagetitle/alternates/LANDSCAPE_1280" alt="Euforia bohatera Realu. Po meczu złożył deklarację" />
    Vinicius Junior popisał się hat-trickiem i zapewnił Realowi okazałe zwycięstwo z Borussią Dortmund.
    
    

