# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Lambrini Girls - Filthy Rich Nepo Baby (Live on KEXP)
 - [https://www.youtube.com/watch?v=p9_1p5HaBB0](https://www.youtube.com/watch?v=p9_1p5HaBB0)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:58+00:00

http://KEXP.ORG presents Lambrini Girls performing “Filthy Rich Nepo Baby” live in the KEXP studio. Recorded August 8, 2024.

Phoebe Lunny - Guitar, Vocal
Lilly Macieira-Bosgelmez - Bass, Additional Vocal
Sid Nichols - Drums

Host: Brian Foss
Audio Engineer: Kevin Suggs
Audio Mixer: Seth Manchester
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann, Carlos Cruz & Luke Knecht
Editor: Scott Holpainen

https://bio.to/LambriniGirls!kexp
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Lambrini Girls - Love (Live on KEXP)
 - [https://www.youtube.com/watch?v=WHecA_Wgzvw](https://www.youtube.com/watch?v=WHecA_Wgzvw)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:30+00:00

http://KEXP.ORG presents Lambrini Girls performing “Love” live in the KEXP studio. Recorded August 8, 2024.

Phoebe Lunny - Guitar, Vocal
Lilly Macieira-Bosgelmez - Bass, Additional Vocal
Sid Nichols - Drums

Host: Brian Foss
Audio Engineer: Kevin Suggs
Audio Mixer: Seth Manchester
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann, Carlos Cruz & Luke Knecht
Editor: Scott Holpainen

https://bio.to/LambriniGirls!kexp
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Lambrini Girls - Company Culture (Live on KEXP)
 - [https://www.youtube.com/watch?v=M9nTKWA90tc](https://www.youtube.com/watch?v=M9nTKWA90tc)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:20+00:00

http://KEXP.ORG presents Lambrini Girls performing “Company Culture” live in the KEXP studio. Recorded August 8, 2024.

Phoebe Lunny - Guitar, Vocal
Lilly Macieira-Bosgelmez - Bass, Additional Vocal
Sid Nichols - Drums

Host: Brian Foss
Audio Engineer: Kevin Suggs
Audio Mixer: Seth Manchester
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann, Carlos Cruz & Luke Knecht
Editor: Scott Holpainen

https://bio.to/LambriniGirls!kexp
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Lambrini Girls - God's Country (Live on KEXP)
 - [https://www.youtube.com/watch?v=8ht55uOwqV8](https://www.youtube.com/watch?v=8ht55uOwqV8)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:14+00:00

http://KEXP.ORG presents Lambrini Girls performing “God's Country” live in the KEXP studio. Recorded August 8, 2024.

Phoebe Lunny - Guitar, Vocal
Lilly Macieira-Bosgelmez - Bass, Additional Vocal
Sid Nichols - Drums

Host: Brian Foss
Audio Engineer: Kevin Suggs
Audio Mixer: Seth Manchester
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann, Carlos Cruz & Luke Knecht
Editor: Scott Holpainen

https://bio.to/LambriniGirls!kexp
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Lambrini Girls - Big Dick Energy (Live on KEXP)
 - [https://www.youtube.com/watch?v=5Z6Z8u8SLyY](https://www.youtube.com/watch?v=5Z6Z8u8SLyY)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:08+00:00

http://KEXP.ORG presents Lambrini Girls performing “Big Dick Energy” live in the KEXP studio. Recorded August 8, 2024.

Phoebe Lunny - Guitar, Vocal
Lilly Macieira-Bosgelmez - Bass, Additional Vocal
Sid Nichols - Drums

Host: Brian Foss
Audio Engineer: Kevin Suggs
Audio Mixer: Seth Manchester
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann, Carlos Cruz & Luke Knecht
Editor: Scott Holpainen

https://bio.to/LambriniGirls!kexp
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

