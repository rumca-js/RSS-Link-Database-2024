# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Nicole Shanahan’s astonishing journey from tech royalty to rising MAGA star 
 - [https://www.washingtonpost.com/technology/2024/10/23/nicole-shanahan-maga-make-america-healthy-trump-rfk-jr](https://www.washingtonpost.com/technology/2024/10/23/nicole-shanahan-maga-make-america-healthy-trump-rfk-jr)
 - RSS feed: $source
 - date published: 2024-10-23T11:10:05+00:00

With a massive divorce settlement from Google’s Sergey Brin, the former Democrat is remaking herself as a pro-Trump ‘Make America Healthy Again’ wellness guru.

## Elon Musk sued by ‘Blade Runner 2049’ producers over look-alike image
 - [https://www.washingtonpost.com/nation/2024/10/22/elon-musk-tesla-blade-runner-lawsuit](https://www.washingtonpost.com/nation/2024/10/22/elon-musk-tesla-blade-runner-lawsuit)
 - RSS feed: $source
 - date published: 2024-10-23T02:02:22+00:00

Alcon Entertainment alleges that Musk and Tesla made an AI image for their robotaxi unveiling that’s based on “Blade Runner 2049.”

