# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Eksplozja w Turcji. Media: Słychać strzały, trwa ewakuacja
 - [https://wydarzenia.interia.pl/zagranica/news-eksplozja-w-turcji-media-slychac-strzaly-trwa-ewakuacja,nId,7841951](https://wydarzenia.interia.pl/zagranica/news-eksplozja-w-turcji-media-slychac-strzaly-trwa-ewakuacja,nId,7841951)
 - RSS feed: $source
 - date published: 2024-10-23T14:11:11.985136+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-eksplozja-w-turcji-media-slychac-strzaly-trwa-ewakuacja,nId,7841951"><img src="https://i.iplsc.com/eksplozja-w-turcji-media-slychac-strzaly-trwa-ewakuacja/000JZ8V172LUJ7BX-C321.jpg" alt="Eksplozja w Turcji. Media: Słychać strzały, trwa ewakuacja" align="left" /></a>Na terenie tureckiej firmy z branży lotniczej i obronnej TUSAS w Ankarze doszło do eksplozji - informują tureckie media. Jak podano, po eksplozji nastąpiły strzały. Obecnie trwa akcja służb. Szef MSW przekazał, że są ofiary śmiertelne i ranni zdarzenia. </p><br clear="all" />

## Trzy kompanie rozbite. Ukraińcy obwieścili sukces na froncie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-trzy-kompanie-rozbite-ukraincy-obwiescili-sukces-na-froncie,nId,7841912](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-trzy-kompanie-rozbite-ukraincy-obwiescili-sukces-na-froncie,nId,7841912)
 - RSS feed: $source
 - date published: 2024-10-23T14:11:11.716886+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-trzy-kompanie-rozbite-ukraincy-obwiescili-sukces-na-froncie,nId,7841912"><img src="https://i.iplsc.com/trzy-kompanie-rozbite-ukraincy-obwiescili-sukces-na-froncie/000JZ7BHRMS7J3W9-C321.jpg" alt="Trzy kompanie rozbite. Ukraińcy obwieścili sukces na froncie " align="left" /></a>Rosjanie starają się kontynuować natarcie w kierunku donbaskich miast takich jak Pokrowsk, Solidowe i Kurachiwka. Tylko w ciągu jednego dnia i na jednym kierunku działań ukraińska Gwardia Narodowa odparła 13 ataków. Szturmy okazały się nieskuteczne i zakończyły bardzo poważnymi stratami wśród Rosjan.</p><br clear="all" />

## Nowy etap walk w obwodzie kurskim. "Rosjanie chcą nas wciągnąć w pułapkę"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-etap-walk-w-obwodzie-kurskim-rosjanie-chca-nas-wciagnac,nId,7841946](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-etap-walk-w-obwodzie-kurskim-rosjanie-chca-nas-wciagnac,nId,7841946)
 - RSS feed: $source
 - date published: 2024-10-23T14:11:11.335320+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-etap-walk-w-obwodzie-kurskim-rosjanie-chca-nas-wciagnac,nId,7841946"><img src="https://i.iplsc.com/nowy-etap-walk-w-obwodzie-kurskim-rosjanie-chca-nas-wciagnac/000JZ8254W68J2O9-C321.jpg" alt="Nowy etap walk w obwodzie kurskim. &quot;Rosjanie chcą nas wciągnąć w pułapkę&quot;" align="left" /></a>- Teraz Rosjanie próbują nas wciągnąć w pułapkę, żebyśmy wrzucili więcej swoich rezerw do obwodu kurskiego. Chcą zrobić coś podobnego, co udało nam się zrobić na północy obwodu charkowskiego - twierdzi Wasyl Pechnio. Zdaniem eksperta w ostatnich tygodniach rosyjskie dowództwo zdecydowało o rozpoczęciu nowego etapu walk na terenach zajętych przez Siły Zbrojne Ukrainy.</p><br clear="all" />

## Zmiany w jednym z najbardziej zatłoczonych miast. Władze pokazały plan
 - [https://wydarzenia.interia.pl/ciekawostki/news-zmiany-w-jednym-z-najbardziej-zatloczonych-miast-wladze-poka,nId,7841884](https://wydarzenia.interia.pl/ciekawostki/news-zmiany-w-jednym-z-najbardziej-zatloczonych-miast-wladze-poka,nId,7841884)
 - RSS feed: $source
 - date published: 2024-10-23T13:05:38.818424+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-zmiany-w-jednym-z-najbardziej-zatloczonych-miast-wladze-poka,nId,7841884"><img src="https://i.iplsc.com/zmiany-w-jednym-z-najbardziej-zatloczonych-miast-wladze-poka/000JZ6YOHLL9EBBN-C321.jpg" alt="Zmiany w jednym z najbardziej zatłoczonych miast. Władze pokazały plan" align="left" /></a>Seul ujawnia plany przeniesienia swoich linii kolejowych pod ziemię. Dotychczasowa infrastruktura ma zostać przekształcona w tereny zielone, centra handlowe czy biurowce. To część procesu zakopywania kolei w stolicy Korei Południowej. </p><br clear="all" />

## Rosja i Białoruś zacieśniają współpracę. Ćwiczenia wojskowe na wielką skalę
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-i-bialorus-zaciesniaja-wspolprace-cwiczenia-wojskowe-n,nId,7841837](https://wydarzenia.interia.pl/zagranica/news-rosja-i-bialorus-zaciesniaja-wspolprace-cwiczenia-wojskowe-n,nId,7841837)
 - RSS feed: $source
 - date published: 2024-10-23T13:05:38.665569+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-i-bialorus-zaciesniaja-wspolprace-cwiczenia-wojskowe-n,nId,7841837"><img src="https://i.iplsc.com/rosja-i-bialorus-zaciesniaja-wspolprace-cwiczenia-wojskowe-n/000JZ6TWW7C180DV-C321.jpg" alt="Rosja i Białoruś zacieśniają współpracę. Ćwiczenia wojskowe na wielką skalę" align="left" /></a>Podczas spotkania białoruskiego i rosyjskiego ministra obrony, zatwierdzono decyzję o organizacji wspólnych ćwiczeń wojskowych Zachód-2025. Szef rosyjskiego resortu zadeklarował też, że jego kraj rozważy możliwość użycia broni jądrowej, jeśli Białoruś zostanie zaatakowana.</p><br clear="all" />

## Wołodymyr Zełenski szykuje kolejny plan. Tym razem nie dla Zachodu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wolodymyr-zelenski-szykuje-kolejny-plan-tym-razem-nie-dla-za,nId,7841742](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wolodymyr-zelenski-szykuje-kolejny-plan-tym-razem-nie-dla-za,nId,7841742)
 - RSS feed: $source
 - date published: 2024-10-23T12:01:54.287842+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wolodymyr-zelenski-szykuje-kolejny-plan-tym-razem-nie-dla-za,nId,7841742"><img src="https://i.iplsc.com/wolodymyr-zelenski-szykuje-kolejny-plan-tym-razem-nie-dla-za/000JZ5Q06USDG7NN-C321.jpg" alt="Wołodymyr Zełenski szykuje kolejny plan. Tym razem nie dla Zachodu" align="left" /></a>Wołodymyr Zełenski wraz ze swoimi współpracownikami przygotowuje kolejny plan działań wojennych. Według informacji mediów, tym razem dokument dotyczyć będzie wewnętrznych spraw kraju i zaprezentowany zostanie obywatelom do końca roku.</p><br clear="all" />

## Orban nie zostawił suchej nitki na UE. Brukselę porównał do Moskwy
 - [https://wydarzenia.interia.pl/zagranica/news-orban-nie-zostawil-suchej-nitki-na-ue-bruksele-porownal-do-m,nId,7841751](https://wydarzenia.interia.pl/zagranica/news-orban-nie-zostawil-suchej-nitki-na-ue-bruksele-porownal-do-m,nId,7841751)
 - RSS feed: $source
 - date published: 2024-10-23T12:01:54.011393+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-orban-nie-zostawil-suchej-nitki-na-ue-bruksele-porownal-do-m,nId,7841751"><img src="https://i.iplsc.com/orban-nie-zostawil-suchej-nitki-na-ue-bruksele-porownal-do-m/000JZ5MRXR2YOKQ1-C321.jpg" alt="Orban nie zostawił suchej nitki na UE. Brukselę porównał do Moskwy " align="left" /></a>- Znowu pojawia się stare pytanie: czy ugniemy się przed wolą obcego mocarstwa, tym razem z Brukseli, czy też się jej przeciwstawimy? - mówił w rocznicę antyradzieckiego powstania z 1956 roku Viktor Orban. Premier Węgier, ku uciesze swoich zwolenników, porównał Unię Europejską do sowieckiej Rosji. Lider Fideszu nakłaniał zgromadzonych w Budapeszcie do opowiedzenia się przeciwko unijnym elitom.</p><br clear="all" />

## Potężny żywioł zbliża się do wielkiego kraju. Gigantyczna ewakuacja
 - [https://wydarzenia.interia.pl/zagranica/news-potezny-zywiol-zbliza-sie-do-wielkiego-kraju-gigantyczna-ewa,nId,7841828](https://wydarzenia.interia.pl/zagranica/news-potezny-zywiol-zbliza-sie-do-wielkiego-kraju-gigantyczna-ewa,nId,7841828)
 - RSS feed: $source
 - date published: 2024-10-23T12:01:53.625022+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezny-zywiol-zbliza-sie-do-wielkiego-kraju-gigantyczna-ewa,nId,7841828"><img src="https://i.iplsc.com/potezny-zywiol-zbliza-sie-do-wielkiego-kraju-gigantyczna-ewa/000JZ6FMQTUTLKY9-C321.jpg" alt="Potężny żywioł zbliża się do wielkiego kraju. Gigantyczna ewakuacja" align="left" /></a>Do brzegów Indii zbliża się od wschodu potężny cyklon Dana. Możliwe, że dotrze do gęsto zaludnionych terenów w czwartek wieczorem. W zagrożonych stanach mieszka łącznie około 150 mln osób. Lokalne władze rozpoczęły wielką ewakuację ponad 100 tys. ludzi z wybrzeża. Odwołano setki połączeń kolejowych i zamknięto wszystkie szkoły. Rybakom odradzono wypływanie w morze.</p><br clear="all" />

## Potężne wsparcie na ostatniej prostej. Harris z gigantycznym zastrzykiem gotówki
 - [https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-potezne-wsparcie-na-ostatniej-prostej-harris-z-gigantycznym-,nId,7841602](https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-potezne-wsparcie-na-ostatniej-prostej-harris-z-gigantycznym-,nId,7841602)
 - RSS feed: $source
 - date published: 2024-10-23T10:55:08.837842+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-potezne-wsparcie-na-ostatniej-prostej-harris-z-gigantycznym-,nId,7841602"><img src="https://i.iplsc.com/potezne-wsparcie-na-ostatniej-prostej-harris-z-gigantycznym/000JZ3UXLCWK3PDR-C321.jpg" alt="Potężne wsparcie na ostatniej prostej. Harris z gigantycznym zastrzykiem gotówki" align="left" /></a>Bill Gates przekazał na kampanię Kamali Harris 50 mln dolarów - donoszą amerykańskie media. Założyciel Microsoftu unikał dotychczas politycznych deklaracji, lecz uznał, że &quot;te wybory są inne&quot;. Miliarder dołączył do grona VIP-ów wspierających kandydatkę demokratów. Należy do nich m.in. Eminem oraz Bruce Springsteen.</p><br clear="all" />

## Polański miał stanąć przed sądem. Zwrot ws. 91-letniego reżysera
 - [https://wydarzenia.interia.pl/zagranica/news-polanski-mial-stanac-przed-sadem-zwrot-ws-91-letniego-rezyse,nId,7841657](https://wydarzenia.interia.pl/zagranica/news-polanski-mial-stanac-przed-sadem-zwrot-ws-91-letniego-rezyse,nId,7841657)
 - RSS feed: $source
 - date published: 2024-10-23T09:50:06.340096+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polanski-mial-stanac-przed-sadem-zwrot-ws-91-letniego-rezyse,nId,7841657"><img src="https://i.iplsc.com/polanski-mial-stanac-przed-sadem-zwrot-ws-91-letniego-rezyse/000JZ40JR0QO97BX-C321.jpg" alt="Polański miał stanąć przed sądem. Zwrot ws. 91-letniego reżysera" align="left" /></a>Roman Polański nie stanie przed sądem w związku z domniemanym wykorzystaniem seksualnym, którego miał dopuścić się w 1973 roku na nieletniej. Strony zawarły &quot;satysfakcjonującą ugodę&quot; - przekazał prawnik reżysera. Polański konsekwentnie nie przyznawał się do winy. </p><br clear="all" />

## Nowe zdobycze na koncie Rosjan. Udało im się przesunąć linię frontu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowe-zdobycze-na-koncie-rosjan-udalo-im-sie-przesunac-linie-,nId,7841574](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowe-zdobycze-na-koncie-rosjan-udalo-im-sie-przesunac-linie-,nId,7841574)
 - RSS feed: $source
 - date published: 2024-10-23T08:45:10.634023+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowe-zdobycze-na-koncie-rosjan-udalo-im-sie-przesunac-linie-,nId,7841574"><img src="https://i.iplsc.com/nowe-zdobycze-na-koncie-rosjan-udalo-im-sie-przesunac-linie/000JZ2KAIMKY865B-C321.jpg" alt="Nowe zdobycze na koncie Rosjan. Udało im się przesunąć linię frontu" align="left" /></a>Rosyjskie wojska kontynuują działania ofensywne w Donbasie i zdobywają kolejne miejscowości. Według najnowszych informacji frontowych pod rosyjską kontrolą znajduje się miejscowość Nowosadowe położona na granicy obwodu ługańskiego i donieckiego. Złe informacje dla Ukraińców napływają także m.in. z Torećka.</p><br clear="all" />

## Andrew V. Schally nie żyje. Polsko-amerykański noblista miał 97 lat
 - [https://wydarzenia.interia.pl/zagranica/news-andrew-v-schally-nie-zyje-polsko-amerykanski-noblista-mial-9,nId,7841518](https://wydarzenia.interia.pl/zagranica/news-andrew-v-schally-nie-zyje-polsko-amerykanski-noblista-mial-9,nId,7841518)
 - RSS feed: $source
 - date published: 2024-10-23T07:40:13.674075+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-andrew-v-schally-nie-zyje-polsko-amerykanski-noblista-mial-9,nId,7841518"><img src="https://i.iplsc.com/andrew-v-schally-nie-zyje-polsko-amerykanski-noblista-mial-9/000JZ1P4VQ1XNF8U-C321.jpg" alt="Andrew V. Schally nie żyje. Polsko-amerykański noblista miał 97 lat" align="left" /></a>Nie żyje Andrew V. Schally, polsko-amerykański noblista. Znany endokrynolog miał 97 lat. Urodził się w przedwojennej Polsce, jako Andrzej Wiktor Schally.</p><br clear="all" />

## Gniewny odwet Hezbollahu. Zaatakowano przedmieścia Tel Awiwu
 - [https://wydarzenia.interia.pl/raport-bliski-wschod/news-gniewny-odwet-hezbollahu-zaatakowano-przedmiescia-tel-awiwu,nId,7841537](https://wydarzenia.interia.pl/raport-bliski-wschod/news-gniewny-odwet-hezbollahu-zaatakowano-przedmiescia-tel-awiwu,nId,7841537)
 - RSS feed: $source
 - date published: 2024-10-23T07:40:13.569411+00:00

<p><a href="https://wydarzenia.interia.pl/raport-bliski-wschod/news-gniewny-odwet-hezbollahu-zaatakowano-przedmiescia-tel-awiwu,nId,7841537"><img src="https://i.iplsc.com/gniewny-odwet-hezbollahu-zaatakowano-przedmiescia-tel-awiwu/000JZ26ZVLE91DQP-C321.jpg" alt="Gniewny odwet Hezbollahu. Zaatakowano przedmieścia Tel Awiwu" align="left" /></a>Hezbollah zareagował na działania Izraela i ostrzelał przedmieścia Tel Awiwu. To &quot;odpowiedź na masakry&quot; dokonywane przez wroga - tłumaczyła uderzenie libańska grupa zbrojna. Celem stała się jednostka wywiadu wojskowego w Glilot.</p><br clear="all" />

## Bałkański kocioł wrze. Przyjaciel Putina chce secesji
 - [https://wydarzenia.interia.pl/zagranica/news-balkanski-kociol-wrze-przyjaciel-putina-chce-secesji,nId,7841463](https://wydarzenia.interia.pl/zagranica/news-balkanski-kociol-wrze-przyjaciel-putina-chce-secesji,nId,7841463)
 - RSS feed: $source
 - date published: 2024-10-23T04:24:55.942255+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-balkanski-kociol-wrze-przyjaciel-putina-chce-secesji,nId,7841463"><img src="https://i.iplsc.com/balkanski-kociol-wrze-przyjaciel-putina-chce-secesji/000JZ0X1A4SO0129-C321.jpg" alt="Bałkański kocioł wrze. Przyjaciel Putina chce secesji" align="left" /></a>- My, nie-Serbowie, jesteśmy w tej części kraju obywatelami piątej kategorii i dlatego potrzebujemy pomocy - zauważył jeden z obywateli Bośni i Hercegowiny. Kraj jest na krawędzi rozpadu z powodu działań autonomicznej Republiki Serbskiej. Dziennik &quot;Osłobedzenie&quot; nagłośnił sprawę odbierania ziem repatriantom. Władze centralne pozostają głuche na kolejne działania reżimu Milorada Dodika. Ten nie ukrywa, że jego celem jest przyłączenie się do niepodległej Serbii.</p><br clear="all" />

