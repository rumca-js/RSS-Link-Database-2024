# Source:Publisher weekly, URL:https://www.publishersweekly.com/pw/feeds/recent/index.xml, language:en-US

## Andrews McMeel to Publish Inspirational Books Under Amber Lotus Imprint
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/96295-andrews-mcmeel-to-publish-inspirational-books-under-amber-lotus-imprint.html](http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/96295-andrews-mcmeel-to-publish-inspirational-books-under-amber-lotus-imprint.html)
 - RSS feed: $source
 - date published: 2024-10-23T00:00:00+00:00

None

## Publishers Sign Petition Condemning ‘Theft’ by AI Companies
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/96294-publishers-sign-petition-condemning-theft-by-ai-companies.html](http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/96294-publishers-sign-petition-condemning-theft-by-ai-companies.html)
 - RSS feed: $source
 - date published: 2024-10-23T00:00:00+00:00

None

