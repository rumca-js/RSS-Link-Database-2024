# Source:Book Browse, URL:https://www.bookbrowse.com/rss/book_news.rss, language:en

##  Publishers sign petition condemning 'theft' by AI companies
 - [http://www.bookbrowse.com/news/detail/index.cfm?news_item_number=3311](http://www.bookbrowse.com/news/detail/index.cfm?news_item_number=3311)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:00+00:00

 An online petition and statement condemning the unauthorized use of creative works to train generative AI has reached 13,500 signatories, including novelist Kazuo Ishiguro, Saturday Night Live actor (and upcoming National Book Awards host) Kate McKinnon, musician Thom Yorke, and a host of industry organizations that includes the Association of American Publishers.

