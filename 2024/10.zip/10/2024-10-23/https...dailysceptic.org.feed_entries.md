# Source:Daily sceptic, URL:https://dailysceptic.org/feed, language:en-US

## Rachel Reeves to Spare Public Sector Gold-Plated Pensions From £15bn Tax Raid
 - [https://dailysceptic.org/2024/10/23/rachel-reeves-to-spare-public-sector-gold-plated-pensions-from-15bn-tax-raid](https://dailysceptic.org/2024/10/23/rachel-reeves-to-spare-public-sector-gold-plated-pensions-from-15bn-tax-raid)
 - RSS feed: $source
 - date published: 2024-10-23T14:21:16+00:00

<p>Public sector gold-plated pensions will be shielded from Rachel Reeves's plans to mount a £15bn tax raid on employers' pension contributions, while those in the private sector face lower wages and less money in retirement.</p>
<p>The post <a href="https://dailysceptic.org/2024/10/23/rachel-reeves-to-spare-public-sector-gold-plated-pensions-from-15bn-tax-raid/">Rachel Reeves to Spare Public Sector Gold-Plated Pensions From £15bn Tax Raid</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>


## How a 1,500th Anniversary Shows the Deep Roots of Western Civilisation
 - [https://dailysceptic.org/2024/10/23/how-a-1500th-anniversary-shows-the-deep-roots-of-western-civilisation](https://dailysceptic.org/2024/10/23/how-a-1500th-anniversary-shows-the-deep-roots-of-western-civilisation)
 - RSS feed: $source
 - date published: 2024-10-23T12:00:00+00:00

<p>Today is the 1,500th anniversary of the death of the Roman writer Boethius, whose great work The Consolation of Philosophy illustrates what we mean when we say we are part of one Western civilisation, says Nicholas Tate.</p>
<p>The post <a href="https://dailysceptic.org/2024/10/23/how-a-1500th-anniversary-shows-the-deep-roots-of-western-civilisation/">How a 1,500th Anniversary Shows the Deep Roots of Western Civilisation</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>


## Does the Kaba Case Reflect “Deeply Rooted Patterns of Racial Disproportionality”?
 - [https://dailysceptic.org/2024/10/23/does-the-kaba-case-reflect-deeply-rooted-patterns-of-racial-disproportionality](https://dailysceptic.org/2024/10/23/does-the-kaba-case-reflect-deeply-rooted-patterns-of-racial-disproportionality)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

<p>The verdict in the trial of officer Blake suggests that Kaba was killed in lawful self-defence. And there’s no evidence that police are disproportionately killing black people due to racism.</p>
<p>The post <a href="https://dailysceptic.org/2024/10/23/does-the-kaba-case-reflect-deeply-rooted-patterns-of-racial-disproportionality/">Does the Kaba Case Reflect “Deeply Rooted Patterns of Racial Disproportionality”?</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>


## British Censorship Group Linked to Starmer and Kamala Harris Plots to “Kill Musk’s Twitter”, Leaked Documents Show
 - [https://dailysceptic.org/2024/10/23/british-censorship-group-linked-to-starmer-and-kamala-harris-plots-to-kill-musks-twitter-leaked-documents-show](https://dailysceptic.org/2024/10/23/british-censorship-group-linked-to-starmer-and-kamala-harris-plots-to-kill-musks-twitter-leaked-documents-show)
 - RSS feed: $source
 - date published: 2024-10-23T08:00:00+00:00

<p>A British censorship group linked to Keir Starmer and Kamala Harris is plotting to "kill Musk's Twitter", leaked documents show. Musk has accused the Centre for Countering Digital Hate of illegal election interference.</p>
<p>The post <a href="https://dailysceptic.org/2024/10/23/british-censorship-group-linked-to-starmer-and-kamala-harris-plots-to-kill-musks-twitter-leaked-documents-show/">British Censorship Group Linked to Starmer and Kamala Harris Plots to &#8220;Kill Musk&#8217;s Twitter&#8221;, Leaked Documents Show</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>


## 2023’s ‘Record Temperatures’ Were Not Driven by CO2 Emissions, New Science Paper Finds
 - [https://dailysceptic.org/2024/10/23/2023s-record-temperatures-were-not-driven-by-co2-emissions-new-science-paper-finds](https://dailysceptic.org/2024/10/23/2023s-record-temperatures-were-not-driven-by-co2-emissions-new-science-paper-finds)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:00+00:00

<p>2023's record temperatures were not driven by human CO2 emissions, a new scientific paper published in Atmospheric Chemistry and Physics has found. They were rather a natural spike from a strong El Niño.</p>
<p>The post <a href="https://dailysceptic.org/2024/10/23/2023s-record-temperatures-were-not-driven-by-co2-emissions-new-science-paper-finds/">2023&#8217;s &#8216;Record Temperatures&#8217; Were Not Driven by CO2 Emissions, New Science Paper Finds</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>


## News Round-Up
 - [https://dailysceptic.org/2024/10/23/news-round-up-1320](https://dailysceptic.org/2024/10/23/news-round-up-1320)
 - RSS feed: $source
 - date published: 2024-10-23T00:06:57+00:00

<p>A summary of the most interesting stories in the past 24 hours that challenge the prevailing orthodoxy about the ‘climate emergency’, public health ‘crises’ and the supposed moral defects of Western civilisation.</p>
<p>The post <a href="https://dailysceptic.org/2024/10/23/news-round-up-1320/">News Round-Up</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>


