# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## Lotto: Numbers revealed for giant $30 million Powerball jackpot
 - [https://www.nzherald.co.nz/nz/lotto-numbers-revealed-for-giant-30-million-powerball-jackpot/J5IDVSX7JRCJNPE5W4BA4QA4JI](https://www.nzherald.co.nz/nz/lotto-numbers-revealed-for-giant-30-million-powerball-jackpot/J5IDVSX7JRCJNPE5W4BA4QA4JI)
 - RSS feed: $source
 - date published: 2024-10-23T07:22:58+00:00

The jackpot has reached an incredible $30m.

## Michael Murray denied early release from prison for killing Connor Morris in West Auckland street fight
 - [https://www.nzherald.co.nz/nz/michael-murray-denied-early-release-from-prison-for-killing-connor-morris-in-west-auckland-street-fight/XFZ3RYT3BFGK5MFANQMRGHX6ZU](https://www.nzherald.co.nz/nz/michael-murray-denied-early-release-from-prison-for-killing-connor-morris-in-west-auckland-street-fight/XFZ3RYT3BFGK5MFANQMRGHX6ZU)
 - RSS feed: $source
 - date published: 2024-10-23T05:25:30+00:00

Michael Murray killed Morris with a sickle during a West Auckland street fight.

## Baby Ru homicide: Person of interest Rosie Morunga speaks out about toddler’s death on Instagram
 - [https://www.nzherald.co.nz/nz/baby-ru-homicide-person-of-interest-rosie-morunga-speaks-out-about-toddlers-death-on-instagram/VG7BHYMFGRDABIHHUM3WCBOQUY](https://www.nzherald.co.nz/nz/baby-ru-homicide-person-of-interest-rosie-morunga-speaks-out-about-toddlers-death-on-instagram/VG7BHYMFGRDABIHHUM3WCBOQUY)
 - RSS feed: $source
 - date published: 2024-10-23T04:33:32+00:00

Three people were in the house when the 1-year-old suffered a skull fracture.

## Travis Scott reschedules Auckland show, slashes ticket prices one week out from concert
 - [https://www.nzherald.co.nz/entertainment/travis-scott-reschedules-auckland-show-slashes-ticket-prices-one-week-out-from-concert/N7JBPZZXXZEANARDKWYAR6TZA4](https://www.nzherald.co.nz/entertainment/travis-scott-reschedules-auckland-show-slashes-ticket-prices-one-week-out-from-concert/N7JBPZZXXZEANARDKWYAR6TZA4)
 - RSS feed: $source
 - date published: 2024-10-23T04:27:17+00:00

Several concertgoers have had to pay hundreds of dollars just to change their flights.

## Ōpōtiki: Rawiri Waititi says police gang operation ‘terrorism’, Mark Mitchell calls claims ‘ridiculous’
 - [https://www.nzherald.co.nz/nz/politics/opotiki-rawiri-waititi-says-police-gang-operation-terrorism-mark-mitchell-calls-claims-ridiculous/MKPGAN5IBNFLFDNMKJZ6PN2ACM](https://www.nzherald.co.nz/nz/politics/opotiki-rawiri-waititi-says-police-gang-operation-terrorism-mark-mitchell-calls-claims-ridiculous/MKPGAN5IBNFLFDNMKJZ6PN2ACM)
 - RSS feed: $source
 - date published: 2024-10-23T03:25:20+00:00

Mitchell said the police were 'extremely sensitive and careful'.

## Who will be Wellington City Council’s Crown observer?
 - [https://www.nzherald.co.nz/nz/who-will-be-wellington-city-councils-crown-observer/5F7FSGTMO5HFXBGZGAOJHFKPUI](https://www.nzherald.co.nz/nz/who-will-be-wellington-city-councils-crown-observer/5F7FSGTMO5HFXBGZGAOJHFKPUI)
 - RSS feed: $source
 - date published: 2024-10-23T03:06:23+00:00

Several names have been floated as potential candidates to sort out the 'shambles'.

## Person rushed to hospital with critical injuries after assault on a bus in Onehunga
 - [https://www.nzherald.co.nz/nz/person-rushed-to-hospital-with-serious-injuries-after-assault-on-a-bus-in-onehunga/TQ3QZOH2FFCZNPN5TMDCYSFP3U](https://www.nzherald.co.nz/nz/person-rushed-to-hospital-with-serious-injuries-after-assault-on-a-bus-in-onehunga/TQ3QZOH2FFCZNPN5TMDCYSFP3U)
 - RSS feed: $source
 - date published: 2024-10-23T02:24:57+00:00

The Police Eagle helicopter was seen circling the area.

## Kiri Allan, Anika Moa’s RNZ podcast released under Official Information Act
 - [https://www.nzherald.co.nz/nz/kiri-allan-anika-moas-rnz-podcast-released-under-official-information-act/5FUIOO5CPFHFHDSD4BCY7O3KL4](https://www.nzherald.co.nz/nz/kiri-allan-anika-moas-rnz-podcast-released-under-official-information-act/5FUIOO5CPFHFHDSD4BCY7O3KL4)
 - RSS feed: $source
 - date published: 2024-10-23T02:21:15+00:00

The podcast was released to the Herald under the Official Information Act.

## Kaitāia College in Northland out of lockdown after fighting and trespass with parents coming on site
 - [https://www.nzherald.co.nz/northern-advocate/news/kaitaia-college-in-lockdown-due-to-fighting-trespassing-and-parents-on-site/MA24PGJ3NJBX5FVJP6UHUXAREI](https://www.nzherald.co.nz/northern-advocate/news/kaitaia-college-in-lockdown-due-to-fighting-trespassing-and-parents-on-site/MA24PGJ3NJBX5FVJP6UHUXAREI)
 - RSS feed: $source
 - date published: 2024-10-23T01:59:03+00:00

The notice was put on the school's Facebook page around 1.50pm.

## Auditor-General finds Ministry of Education lacks information on student achievement before NCEA
 - [https://www.nzherald.co.nz/nz/education/auditor-general-finds-ministry-of-education-lacks-information-on-student-achievement-before-ncea/NKMU7YDDPNF47BMINLJOFHYW6U](https://www.nzherald.co.nz/nz/education/auditor-general-finds-ministry-of-education-lacks-information-on-student-achievement-before-ncea/NKMU7YDDPNF47BMINLJOFHYW6U)
 - RSS feed: $source
 - date published: 2024-10-23T01:04:51+00:00

The audit says better information is needed to improve student achievement.

## America’s Cup: Why Valencia makes sense as host of 38th America’s Cup - Paul Lewis
 - [https://www.nzherald.co.nz/sport/sailing/americas-cup/americas-cup-why-valencia-makes-sense-as-host-of-38th-americas-cup-paul-lewis/X2KOGE46BBGU5GRTJFHIIRX3CQ](https://www.nzherald.co.nz/sport/sailing/americas-cup/americas-cup-why-valencia-makes-sense-as-host-of-38th-americas-cup-paul-lewis/X2KOGE46BBGU5GRTJFHIIRX3CQ)
 - RSS feed: $source
 - date published: 2024-10-23T01:00:00+00:00

Logic says Auckland has about as much chance as a tissue paper mainsail.

## Jetstar and Air New Zealand both put domestic flights on sale 
 - [https://www.nzherald.co.nz/travel/travel-news/jetstar-and-air-new-zealand-both-put-domestic-flights-on-sale/LXTKCYFDDNAV3IWXNO5NI2YDUI](https://www.nzherald.co.nz/travel/travel-news/jetstar-and-air-new-zealand-both-put-domestic-flights-on-sale/LXTKCYFDDNAV3IWXNO5NI2YDUI)
 - RSS feed: $source
 - date published: 2024-10-23T00:02:39+00:00

Think $59 one-way fares are a steal? How about $35?

