# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## GNOME 47.1 Released to Improve Quick Settings Accessibility and Display Scaling
 - [https://9to5linux.com/gnome-47-1-released-to-improve-quick-settings-accessibility-and-display-scaling](https://9to5linux.com/gnome-47-1-released-to-improve-quick-settings-accessibility-and-display-scaling)
 - RSS feed: $source
 - date published: 2024-10-23T01:21:30+00:00

<p>GNOME 47.1 is now available as the first point release to the latest GNOME 47 desktop environment series adding improvements and fixing bugs. Here's what's changed!</p>
<p>The post <a href="https://9to5linux.com/gnome-47-1-released-to-improve-quick-settings-accessibility-and-display-scaling">GNOME 47.1 Released to Improve Quick Settings Accessibility and Display Scaling</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>


## Tor Browser 14.0 Anonymous Web Browser Is Out Based on Firefox 128 ESR
 - [https://9to5linux.com/tor-browser-14-0-anonymous-web-browser-is-out-based-on-firefox-128-esr](https://9to5linux.com/tor-browser-14-0-anonymous-web-browser-is-out-based-on-firefox-128-esr)
 - RSS feed: $source
 - date published: 2024-10-23T00:15:46+00:00

<p>Tor Browser 14.0 open-source anonymous web browser is now available for download based on the Mozilla Firefox ESR 128 series. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/tor-browser-14-0-anonymous-web-browser-is-out-based-on-firefox-128-esr">Tor Browser 14.0 Anonymous Web Browser Is Out Based on Firefox 128 ESR</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>


