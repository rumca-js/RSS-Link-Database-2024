# Source:Kanał Zero, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClhEl4bMD8_escGCCTmRAYg, language:pl

## EKSPERYMENT ZIMBARDO. DLACZEGO ZOSTAŁ PRZERWANY? | ZERO ŚCIEMY #30
 - [https://www.youtube.com/watch?v=VZCgi0jUnrk](https://www.youtube.com/watch?v=VZCgi0jUnrk)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:38+00:00

“Audycja przeznaczona dla osób powyżej 16. roku życia.
W 30 odcinku  "Zero Ściemy", Łukasz Kaca odkrył jedno z największych eksperymentów w historii psychologii – eksperymentowi więziennego Zimbardo. Eksperyment ten od lat budzi wiele reakcji, a jego wyniki nadal są przedmiotem debaty. Tym razem materiał występuje na przerwaniu przebiegu badań i wyciągnięciu na temat natury ludzkiej.
Łukasz przybliżone szczegóły eksperymentu, podczas którego zwykli ludzie, podzieleni na „strażników” i „więźniów”, w ciągu kilku dni zmieniali się nie do poznania. Czy rzeczywiście każdy z nas może być oprawą w określonych warunkach? Co tak naprawdę pokazał eksperyment i jakie kontrowersje z nim przetrwały do dzisiaj?
Niestety, 14 października 2024 roku świat obiegła wiadomość o śmierci Zimbardo, ale jego eksperyment żyje w debatach naukowych.”

Wesprzyj Zbiórkę: https://www.siepomaga.pl/kanalzero

🔥 Zatrudniaj kierowców, kurierów, w ochronie zdrowia i gastro na rocketjobs.pl. Teraz za free z kodem ZERO: 

## NIE ROSJANIE, A POLACY. KULISY ZAMACHU NA WSPÓŁPRACOWNIKA NAWALNEGO. WYSZLI Z ARESZTU
 - [https://www.youtube.com/watch?v=KFFlIBmDSFs](https://www.youtube.com/watch?v=KFFlIBmDSFs)
 - RSS feed: $source
 - date published: 2024-10-23T11:22:05+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
W tym odcinku Gabriela Jatkowska opowiada o brutalnym pobiciu rosyjskiego opozycjonisty Leonida Wołkowa, bliskiego współpracownika Aleksieja Nawalnego. Atak miał miejsce w marcu tego roku, a sprawcy, Maksymilian K., pseudonim „Kruszynka,” oraz Igor C., związani z pseudokibicowskim środowiskiem Legii Warszawa, zostali tymczasowo aresztowani. Zadziwiające jest, że to właśnie polscy kibice stali się wykonawcami zlecenia, które wielu łączy z rosyjskimi służbami.

Wesprzyj Zbiórkę: https://www.siepomaga.pl/kanalzero

✅ Załóż profil na rockejobs.pl i otrzymuj dopasowane oferty pracy: https://oferty.rocketjobs.pl/wAsiLcW

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQgeK3frVnhfoEM9xP3oWfqD

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 TikTok: https://www.tiktok.

## TEDE OFICJALNIE NIE JEST LEWAKIEM
 - [https://www.youtube.com/watch?v=eAo9nCwXxaI](https://www.youtube.com/watch?v=eAo9nCwXxaI)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:44+00:00

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #tede #wuwunio #lewica #dowód #polityka

## NOC FUTBOLU #2 - KOWAL, RUDZKI, TWAROWSKI, KAPICA
 - [https://www.youtube.com/watch?v=PviLNomExDQ](https://www.youtube.com/watch?v=PviLNomExDQ)
 - RSS feed: $source
 - date published: 2024-10-23T09:40:25+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Przemysław Rudzki i jego goście: Wojciech Kowalczyk, Andrzej Twarowski i Filip Kapica zapraszają na noc futbolu. W programie będzie o występach polskich klubów w europejskich pucharach oraz podsumowanie ostatnich meczy ligi mistrzów.

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #piłkanożna #rudzki #kowal #twarowski #kapica #ligamistrzówc#sport #europa

## NIEMCY KOJARZĄ NAM SIĘ Z WOJNĄ
 - [https://www.youtube.com/watch?v=OKiCKbchbtc](https://www.youtube.com/watch?v=OKiCKbchbtc)
 - RSS feed: $source
 - date published: 2024-10-23T09:22:00+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #polska #niemcy #przeszłość #2wojnaświatowa #polityka

## JAK W POLSCE ŻYJĄ NIEWIDOMI? MARCIN RYSZKA OPOWIADA, JAK DZIAŁA SYSTEM I ZERO ZNIECZULENIA #32
 - [https://www.youtube.com/watch?v=psgA5g28sTI](https://www.youtube.com/watch?v=psgA5g28sTI)
 - RSS feed: $source
 - date published: 2024-10-23T08:55:41+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
W 32 odcinku "Zero Znieczulenia" wracamy do tematu niepełnosprawnych. Tym razem poświęcony osobom niewidomym. W 2018 roku w Polsce według GUS szacuje się, że osób niewidomych lub mających inną niepełnosprawność ze wzrokiem wynosi 1,8 miliona. Życie z tą dysfunkcją wzroku nie zawsze należy do najprostszych. Jakub Kosikowski zaprosił do programu Marcina Ryszkę - autora książki "Nie widzę przeszkód" oraz paraolimpijczyka, który jest niewidomy. Jak wygląda jego życie? Jak radzi sobie z brakiem wzorku? Czy Polska jako państwo wystarczająco wspiera osoby niewidome? O tym w dzisiejszym odcinku.

Wesprzyj Zbiórkę: https://www.siepomaga.pl/kanalzero

✅ Załóż profil na rockejobs.pl i otrzymuj dopasowane oferty pracy: https://oferty.rocketjobs.pl/wAsiLcW

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQjPYrw04gydifS7ck5iA79D 

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 

## TERAZ MOŻNA SIĘ ROZWIEŚĆ W 1 DZIEŃ
 - [https://www.youtube.com/watch?v=1DlbPLwtgwg](https://www.youtube.com/watch?v=1DlbPLwtgwg)
 - RSS feed: $source
 - date published: 2024-10-23T08:51:28+00:00

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #wuwunio #tede #rozwód #mediacje #małżeństwo #prawo

## GODZINA ZERO #54 KRZYSZTOF STANOWSKI I MARCIN IWUĆ - EKONOMISTA
 - [https://www.youtube.com/watch?v=yVBpKvx8RZE](https://www.youtube.com/watch?v=yVBpKvx8RZE)
 - RSS feed: $source
 - date published: 2024-10-23T08:00:08+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Krzysztof Stanowski zaprasza o 20:00 na "Godzinę Zero", której gościem jest Marcin Iwuć - autor bloga Finanse Bardzo Osobiste i ekonomista, autor książki "Finansowa Forteca".

Wesprzyj Zbiórkę: https://www.siepomaga.pl/kanalzero

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQh--ebjWrA8Chb1yBXXI1Mx

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #stanowski #iwuć #finanse #ekonomia #pieniądze

## 7:00 MARCIN MELLER & TOMASZ KAMMEL - POBUDKA!
 - [https://www.youtube.com/watch?v=YjGbNOgECzk](https://www.youtube.com/watch?v=YjGbNOgECzk)
 - RSS feed: $source
 - date published: 2024-10-23T07:23:26+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Marcin Meller i Tomasz Kammel zapraszają na czwartkowy poranek! 😊

Goście:
👤 Krzysztof Iwaneczko - wokalista i kompozytor,
👤Marzena i Łukasz Hartabus - psy Corgi
👤prof. Łukasz Paluch - flebolog

Wesprzyj Zbiórkę: https://www.siepomaga.pl/kanalzero

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQib0kFamBx6c5j8fOfYMuXh

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #kammel #meller #poranek #corgi #muzyka #flebologia #żyły

