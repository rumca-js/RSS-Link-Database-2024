# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Piwo, cydr i perry bez banderoli przez kolejne dwa lata. Jest projekt
 - [https://www.bankier.pl/wiadomosc/Piwo-cydr-i-perry-bez-banderoli-przez-kolejne-dwa-lata-Jest-projekt-8833511.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Piwo-cydr-i-perry-bez-banderoli-przez-kolejne-dwa-lata-Jest-projekt-8833511.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T13:51:12.580526+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/2/d/c43a6a184d5b53-948-568-8-239-3528-2116.jpg" alt="" align="left" />Przedłużenie do 31 grudnia 2026 r. zwolnienia z obowiązku oznaczania znakami akcyzy m.in. piwa, a także cydru i perry o mocy alkoholu nieprzekraczającej 5 proc. objętości - przewiduje projekt rozporządzenia przygotowany przez Ministerstwo Finansów.</p>

## Dyrektor finansowy: Sprzedaż LPP w III kw. mogła wzrosnąć o ponad 20 proc. 
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-LPP-w-III-kw-mogla-wzrosnac-o-ponad-20-proc-dyrektor-finansowy-8833532.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-LPP-w-III-kw-mogla-wzrosnac-o-ponad-20-proc-dyrektor-finansowy-8833532.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T13:51:12.050662+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/0/1/c68d1ff7adfcfa-948-568-37-149-2462-1477.jpg" alt="" align="left" />LPP nie widzi słabości konsumenta, w trzecim kwartale roku obrotowego sprzedaż grupy mogła wzrosnąć o ponad 20 proc. - poinformował Marcin Bójko, dyrektor finansowy LPP.</p>

## Marsz Niepodległości przejdzie ulicami Warszawy. Jest zgoda prezydenta stolicy
 - [https://www.bankier.pl/wiadomosc/Marsz-Niepodleglosci-przejdzie-ulicami-Warszawy-Jest-zgoda-prezydenta-stolicy-8833463.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Marsz-Niepodleglosci-przejdzie-ulicami-Warszawy-Jest-zgoda-prezydenta-stolicy-8833463.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T12:45:56.420254+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/2/a/da927bae1c9a61-945-560-0-90-1732-1039.jpg" alt="" align="left" />Prezydent Warszawy zgodził się, aby Marsz Niepodległości przeszedł ulicami Warszawy. Tym samym marsz odbędzie się jako zgromadzenie legalne.</p>

## Zawieszenie azylu, ośrodki powrotowe. Europosłowie debatują w Strasburgu o pakcie migracyjnym
 - [https://www.bankier.pl/wiadomosc/Zawieszenie-azylu-osrodki-powrotowe-Europoslowie-debatuja-w-Strasburgu-o-pakcie-migracyjnym-8833434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zawieszenie-azylu-osrodki-powrotowe-Europoslowie-debatuja-w-Strasburgu-o-pakcie-migracyjnym-8833434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T12:45:56.222460+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/f/a/35c981dcb838b6-948-568-0-0-4000-2399.jpg" alt="" align="left" />Grupy prawicowe w Parlamencie Europejskim opowiedziały się w środę za zaostrzeniem unijnej polityki migracyjnej, w tym polityki powrotowej. Socjaliści i demokraci, lewica i liberałowie chcą wdrożenia paktu migracyjnego, ale są przeciwni zaostrzeniom.</p>

## Alior z nowym prezesem. Rada nadzorcza wskazała Piotra Żabskiego
 - [https://www.bankier.pl/wiadomosc/RN-Alior-Banku-powierzyla-Piotrowi-Zabskiemu-kierowanie-pracami-zarzadu-od-1-listopada-2024-r-8833483.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/RN-Alior-Banku-powierzyla-Piotrowi-Zabskiemu-kierowanie-pracami-zarzadu-od-1-listopada-2024-r-8833483.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T12:45:55.667216+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/a/d/f0da00b87edda7-948-568-0-270-4000-2399.jpg" alt="" align="left" />Rada nadzorcza Alior Banku powierzyła ze skutkiem od 1 listopada 2024 r. Piotrowi Żabskiemu kierowanie pracami zarządu banku do czasu uzyskania zgody Komisji Nadzoru Finansowego na powołanie go na stanowisko prezesa zarządu - poinformował bank w komunikacie. Zgodnie z pierwotnym brzmieniem uchwały RN, powołanie Piotra Żabskiego miało nastąpić od 1 stycznia 2025 r.</p>

## Rosyjskie MSZ sparaliżowane przez cyberatak
 - [https://www.bankier.pl/wiadomosc/Rosyjskie-MSZ-sparalizowane-przez-cyberatak-8833371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjskie-MSZ-sparalizowane-przez-cyberatak-8833371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T11:41:07.805377+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/3/a/ad6754f21c9358-948-567-0-65-1000-599.jpg" alt="" align="left" />Ministerstwo spraw zagranicznych Rosji zostało sparaliżowane przez cyberatak - poinformowała w środę agencja Reutera za mediami w tym kraju. Rzeczniczka resortu Maria Zacharowa przekazała, że z powodu ataku musiała przełożyć swój cotygodniowy briefing prasowy.</p>

## Mińsk wyznaczył datę "wyborów prezydenckich". Cichanouska: To data reelekcji Łukaszenki
 - [https://www.bankier.pl/wiadomosc/Minsk-wyznaczyl-date-wyborow-prezydenckich-Cichanouska-To-data-reelekcji-Lukaszenki-8833430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minsk-wyznaczyl-date-wyborow-prezydenckich-Cichanouska-To-data-reelekcji-Lukaszenki-8833430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T11:41:07.346116+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/9/c/d1dad550cf6c6d-948-568-0-54-1823-1093.jpg" alt="" align="left" />"Wybory prezydenckie" na Białorusi odbędą się 26 stycznia; datę (formalnie, ponieważ jest to decyzja Alaksandra Łukaszenki) zatwierdził parlament – poinformowały w środę białoruskie media. Łukaszenka ogłosił datę swojej reelekcji – oceniła liderka opozycji Swiatłana Cichanouska.</p>

## Szef Pentagonu: Są dowody na obecność żołnierzy z Korei Płn. w Rosji
 - [https://www.bankier.pl/wiadomosc/Szef-Pentagonu-Sa-dowody-na-obecnosc-zolnierzy-z-Korei-Pln-w-Rosji-8833420.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-Pentagonu-Sa-dowody-na-obecnosc-zolnierzy-z-Korei-Pln-w-Rosji-8833420.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T11:41:06.967063+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/e/3/91042596b81ac7-948-568-0-86-1721-1032.jpg" alt="" align="left" />Są dowody na to, że żołnierze z Korei Płn. znajdują się w Rosji; nie wiadomo, do czego mają zostać wykorzystani – powiadomił w środę na konferencji prasowej w Rzymie szef Pentagonu Lloyd Austin.</p>

## Brytyjczycy przeszkolili już 200 ukraińskich pilotów, którzy będą latać na F-16
 - [https://www.bankier.pl/wiadomosc/Ukraincy-beda-latac-na-F-16-Brytyjczycy-przeszkolili-juz-200-pilotow-8833384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraincy-beda-latac-na-F-16-Brytyjczycy-przeszkolili-juz-200-pilotow-8833384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T11:41:06.560938+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/3/6/e26a61e751f930-948-568-0-266-3945-2366.jpg" alt="" align="left" />Wielka Brytania przeszkoliła już 200 ukraińskich pilotów, którzy będą latać na przekazywanych Kijowowi samolotach wielozadaniowych F-16 - poinformował w nocy z wtorku na środę brytyjski wiceminister obrony Luke Pollard.</p>

## Pepco liderem. Dla 86 proc. Polaków to główny sklep odzieżowy
 - [https://www.bankier.pl/wiadomosc/Pepco-liderem-na-polskim-rynku-odziezowym-dla-86-proc-Polakow-to-glowny-sklep-odziezowy-PMR-8833418.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pepco-liderem-na-polskim-rynku-odziezowym-dla-86-proc-Polakow-to-glowny-sklep-odziezowy-PMR-8833418.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T11:41:06.126192+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/9/d/58aba3e98c78b9-930-557-35-0-930-557.jpg" alt="" align="left" />Pepco jest liderem na polskim rynku odzieżowym, wybieranym przez 86 proc. Polaków jako główny sklep odzieżowy - wynika z badania firmy badawczej PMR Market Experts.</p>

## Presja przyniosła efekty. "Oceania" dostała finansowanie na kolejne trzy lata
 - [https://www.bankier.pl/wiadomosc/Presja-przyniosla-efekty-Oceania-dostala-finansowanie-na-kolejne-trzy-lata-8833449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Presja-przyniosla-efekty-Oceania-dostala-finansowanie-na-kolejne-trzy-lata-8833449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T11:41:05.701395+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/6/7/de2befa0d7c937-892-535-45-4-892-535.jpg" alt="" align="left" />Minister nauki Dariusz Wieczorek zdecydował o przyznaniu środków dla Instytutu Oceanologii Polskiej Akademii Nauk na utrzymanie statku naukowo-badawczego „Oceania” – poinformował w środę resort nauki. Finansowanie przyznano na trzy lata.</p>

## Żabka w mWIG40 już za tydzień? Kurs szuka dna, a straty niektórych to już ponad 20%
 - [https://www.bankier.pl/wiadomosc/Zabka-w-mWIG40-juz-za-tydzien-Kurs-szuka-dna-a-straty-niektorych-to-juz-ponad-20-8833412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zabka-w-mWIG40-juz-za-tydzien-Kurs-szuka-dna-a-straty-niektorych-to-juz-ponad-20-8833412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T11:41:05.116140+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/c/3/8a37cc714d27ac-948-568-0-190-4000-2399.jpg" alt="" align="left" />Mija giełdowy tydzień, czyli pięć sesji z Żabką notowaną na GPW. W tym czasie ani jednak sesja nie skończyła się wzrostem. Co więcej, jeśli ktoś kupił akcje w debiucie na górce i nie sprzedał, to w środę widział na rachunku stratę przekraczającą 20 procent. Według wyliczeń maklerów akcje spółki w następną środę będą już notowane w mWIG40. </p>

## Ubywa zarejestrowanych bezrobotnych, ale czy nadciągają zwolnienia? Najnowszy raport PIE
 - [https://www.bankier.pl/wiadomosc/Ubywa-zarejestrowanych-bezrobotnych-ale-czy-nadciagaja-zwolnienia-Najnowszy-raport-PIE-8833318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ubywa-zarejestrowanych-bezrobotnych-ale-czy-nadciagaja-zwolnienia-Najnowszy-raport-PIE-8833318.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:51.927255+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/9/3/7360cbf73817a0-948-568-345-630-2415-1449.jpg" alt="" align="left" />Istotny wzrost stopy bezrobocia czy liczby zwolnień w kolejnych miesiącach jest mało prawdopodobny - uważają analitycy PIE. W komentarzu do danych GUS zwrócili uwagę, że liczba bezrobotnych jest umiarkowana; przybywa jednodniowych zwolnień L4, dotyczących zwłaszcza piątków.</p>

## PO ogłosi swojego kandydata na prezydenta. Tusk: Nie będę to ja
 - [https://www.bankier.pl/wiadomosc/PO-oglosi-swojego-kandydata-na-prezydenta-Tusk-Nie-bede-to-ja-8833325.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PO-oglosi-swojego-kandydata-na-prezydenta-Tusk-Nie-bede-to-ja-8833325.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:51.698950+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/d/1/e8761336993443-948-568-577-427-2422-1453.jpg" alt="" align="left" />Premier Donald Tusk zapowiedział w środę, że kandydat KO na prezydenta zostanie ogłoszony 7 grudnia, na Śląsku. Będzie to ktoś, kto nadaje się najlepiej na ten urząd, kto ma największe szanse na wygranie; nie będę to ja - zaznaczył Tusk.</p>

## Zakopane bez sylwestrowej imprezy? TVP wybrało inne miasto
 - [https://www.bankier.pl/wiadomosc/Zakopane-bez-sylwestrowej-imprezy-TVP-wybralo-inne-miasto-8833370.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zakopane-bez-sylwestrowej-imprezy-TVP-wybralo-inne-miasto-8833370.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:51.520181+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/4/d/976590881d200d-948-568-0-303-4500-2699.jpg" alt="" align="left" />Największa impreza sylwestrowa w woj. śląskim odbędzie się ponownie na należącym do samorządu tego regionu Stadionie Śląskim, jednak tym razem zorganizuje go Telewizja Polska - przekazał w środę marszałek województwa śląskiego Wojciech Saługa.</p>

## Rosyjski wywiad planował zamach terrorystyczny w Kijowie. Zwerbowano mieszkankę Zaporoża
 - [https://www.bankier.pl/wiadomosc/Rosyjski-wywiad-planowal-zamach-terrorystyczny-w-Kijowie-Zwerbowano-mieszkanke-Zaporoza-8833361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjski-wywiad-planowal-zamach-terrorystyczny-w-Kijowie-Zwerbowano-mieszkanke-Zaporoza-8833361.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:51.336840+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/1/a/1ce2b247e5dace-948-568-0-270-4000-2399.jpg" alt="" align="left" />Służba Bezpieczeństwa Ukrainy (SBU) i Policja Narodowa zapobiegły atakowi terrorystycznemu w Kijowie, który został zaplanowany przez rosyjski wywiad wojskowy - poinformowała SBU w środę. Zamach miał spowodować śmierć jak największej liczby ludzi, aby wywołać panikę wśród obywateli.</p>

## Nie tylko monitoring transakcji. UOKiK ma gotowe zalecenia dla dostawców usług płatniczych
 - [https://www.bankier.pl/wiadomosc/Nie-tylko-monitoring-transakcji-UOKiK-ma-gotowe-zalecenia-dla-dostawcow-uslug-platniczych-8833320.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-tylko-monitoring-transakcji-UOKiK-ma-gotowe-zalecenia-dla-dostawcow-uslug-platniczych-8833320.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:51.074813+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/5/a/7513d239686cca-948-568-0-340-4000-2399.jpg" alt="" align="left" />Monitorowanie nietypowych transakcji, stosowanie limitów transakcyjnych oraz wykorzystanie kanałów autoryzacji - znalazły się w zaleceniach dla dostawców usług płatniczych, sformułowanych przez zespół powołany przez Prezesa UOKiK. Rozwiązania mają ograniczyć ryzyko oszustw.</p>

## Kolejna spółka zniknie z GPW. Złożono wniosek w KNF
 - [https://www.bankier.pl/wiadomosc/Ferrum-zlozyl-w-KNF-wniosek-o-wycofanie-akcji-z-obrotu-na-GPW-8833372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ferrum-zlozyl-w-KNF-wniosek-o-wycofanie-akcji-z-obrotu-na-GPW-8833372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:50.719374+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/4/c/ab4817a9275b1c-948-568-630-270-2370-1421.jpg" alt="" align="left" />Zarząd Ferrum złożył w KNF wniosek o udzielenie zezwolenia na wycofanie akcji spółki z obrotu na Giełdzie Papierów Wartościowych w Warszawie - poinformowała spółka w komunikacie.</p>

## RPO: Płacisz mandat w ratach, jesteś dyskryminowany. Jest wniosek o zmianę przepisów
 - [https://www.bankier.pl/wiadomosc/RPO-Kierowcy-placacy-mandaty-w-ratach-dyskryminowani-Jest-wniosek-o-zmiane-przepisow-8833346.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/RPO-Kierowcy-placacy-mandaty-w-ratach-dyskryminowani-Jest-wniosek-o-zmiane-przepisow-8833346.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:50.442570+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/4/a/0f3e4aeb130ee6-948-568-0-0-1997-1198.jpg" alt="" align="left" />Kasowanie punktów karnych rok po opłaceniu ostatniej raty mandatu jest niezgodne z konstytucją i dyskryminuje kierowców korzystających z takiego rozwiązania – uważa Rzecznik Praw Obywatelskich, który zaapelował o zmiany w przepisach.</p>

## Jest nas coraz mniej. W rok ubyło 147 tys. mieszkańców Polski
 - [https://www.bankier.pl/wiadomosc/Liczba-ludnosci-Polski-spadla-W-rok-ubylo-147-tys-osob-8833292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Liczba-ludnosci-Polski-spadla-W-rok-ubylo-147-tys-osob-8833292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:50.251402+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/5/6/4a0379f64f4540-948-567-0-37-1000-599.jpg" alt="" align="left" />GUS podał najnowsze szacunki dotyczące liczby ludności Polski. W końcu września 2024 roku była ona, co nie jest zaskoczeniem, mniejsza niż przed rokiem.</p>

## Polski konsument widzi przyszłość w czarnych barwach. Ożywienia nie będzie?
 - [https://www.bankier.pl/wiadomosc/Polski-konsument-widzi-przyszlosc-w-czarnych-barwach-Ozywienia-nie-bedzie-8833335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-konsument-widzi-przyszlosc-w-czarnych-barwach-Ozywienia-nie-bedzie-8833335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:49.976880+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/a/1/2a1a022d73d522-948-568-0-266-3952-2371.jpg" alt="" align="left" />Październik przyniósł pogorszenie nastrojów konsumentów. Taki wynik
koresponduje z fatalnym odczytem sprzedaży detalicznej za wrzesień i zapowiada
brak tak oczekiwanego ożywienia.</p>

## Podkomisja Macierewicza ma nie lada problem. Będzie kilkanaście wniosków do prokuratury
 - [https://www.bankier.pl/wiadomosc/Podkomisja-Macierewicza-ma-nie-lada-problem-Bedzie-kilkanascie-wnioskow-do-prokuratury-8833264.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podkomisja-Macierewicza-ma-nie-lada-problem-Bedzie-kilkanascie-wnioskow-do-prokuratury-8833264.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:25.072614+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/c/6/3bcbb31eb05390-945-560-0-2-1152-691.jpg" alt="" align="left" />Wiceszef MON Paweł Zalewski zapowiedział w środę, że w związku z planowaną prezentacją raportu dot. działania tzw. podkomisji smoleńskiej skierowanych zostanie kilkanaście wniosków do prokuratury. Dodał, że w czwartek będą konkretne informacje.</p>

## Chiny połkną europejski sektor motoryzacyjny. "To słodko-gorzki smak"
 - [https://www.bankier.pl/wiadomosc/Chiny-polkna-europejski-sektor-motoryzacyjny-To-slodko-gorzki-smak-8833265.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-polkna-europejski-sektor-motoryzacyjny-To-slodko-gorzki-smak-8833265.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:24.838644+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/6/4/b7f70c996d9303-948-568-0-135-2000-1199.jpg" alt="" align="left" />W 2035 r. liderem sprzedaży aut elektrycznych na rynku europejskim będzie chiński producent - uważa większość przedstawicieli sektora motoryzacyjnego w Europie. Autorzy raportu MotoBarometr wskazali, że nowe fabryki chińskich producentów w krajach Europy mogą mieć "słodko-gorzki smak".</p>

## Złoty nie był tak słaby od wiosny. Drogie euro i dolar, funt najdroższy od przeszło roku
 - [https://www.bankier.pl/wiadomosc/Zloty-nie-byl-tak-slaby-od-wiosny-Drogie-euro-i-dolar-funt-najdrozszy-od-przeszlo-roku-8833279.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-nie-byl-tak-slaby-od-wiosny-Drogie-euro-i-dolar-funt-najdrozszy-od-przeszlo-roku-8833279.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:24.387654+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/1/8/caf8db3b0a2288-948-568-0-475-2500-1499.jpg" alt="" align="left" />Jesień wyraźnie nie sprzyja polskiej walucie, która obrywa ze wszystkich stron. Drożejący dolar, wzrost awersji do ryzyka, odpływ kapitału z polskiej giełdy i na dodatek słabe dane gospodarcze, które mogą wywierać presję na RPP w sprawie szybszego cięcia stóp - to wszystko przekłada się na fatalne notowania polskiego złotego do głównych walut. </p>

## Cinkciarz z mankiem na 150 mln zł? Co stanie się z pieniędzmi klientów, jeśli kantor upadnie?
 - [https://www.bankier.pl/wiadomosc/Cinkciarz-z-mankiem-na-150-mln-zl-Co-stanie-sie-z-pieniedzmi-klientow-jesli-kantor-upadnie-8833246.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cinkciarz-z-mankiem-na-150-mln-zl-Co-stanie-sie-z-pieniedzmi-klientow-jesli-kantor-upadnie-8833246.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T09:14:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/8/6/92e2632f3b2061-948-568-240-0-3600-2159.jpg" alt="" align="left" />128 tys. dolarów, 225 tys. złotych, 30 tys. euro - redakcja Bankier.pl otrzymuje codziennie nowe zgłoszenia od klientów kantoru Cinkciarz.pl, którzy czekają na swoje środki. Wśród wiadomości, które otrzymujemy, powtarza się pytanie: co stanie się z ich pieniędzmi, jeżeli spółka upadnie. Zwróciliśmy się z nim do prawnika.</p>

## Lubnauer: Jedna godzina religii jest dobrym kompromisem
 - [https://www.bankier.pl/wiadomosc/Lubnauer-Jedna-godzina-religii-jest-dobrym-kompromisem-8833244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lubnauer-Jedna-godzina-religii-jest-dobrym-kompromisem-8833244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T08:25:42.227143+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/e/1/ba278a525b687c-945-560-0-22-4415-2648.jpg" alt="" align="left" />Jedna godzina religii jest dobrym kompromisem między Polakami - powiedziała we wtorek w programie "Tłit" wiceministra edukacji narodowej Katarzyna Lubnauer. W jej ocenie, forsując szerszą obecność lekcji religii w szkołach Kościół "rozminął się ze społeczeństwem".</p>

## Kim Dzong Un chce zwiększyć gotowości użycia broni atomowej
 - [https://www.bankier.pl/wiadomosc/Kim-Dzong-Un-chce-zwiekszyc-gotowosci-uzycia-broni-atomowej-8833248.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kim-Dzong-Un-chce-zwiekszyc-gotowosci-uzycia-broni-atomowej-8833248.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T08:25:41.855320+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/6/8/178030c08dfae0-945-567-0-83-1755-1053.jpg" alt="" align="left" />Przywódca Korei Północnej Kim Dzong Un przeprowadził inspekcję strategicznych baz rakietowych, wzywając do wzmocnienia zdolności odstraszania, w tym gotowości użycia broni atomowej, wobec zagrożenia ze strony USA - podały w środę rządowe media.</p>

## Niezgodne z prawem, ale i tak pytają. Problematyczne rodziny podczas rekrutacji
 - [https://www.bankier.pl/wiadomosc/Niezgodne-z-prawem-ale-i-tak-zadawane-Problematyczne-rodziny-podczas-rekrutacji-8833259.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niezgodne-z-prawem-ale-i-tak-zadawane-Problematyczne-rodziny-podczas-rekrutacji-8833259.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T08:25:41.423159+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/a/7/6bb24b56464a17-945-560-0-90-1732-1039.jpg" alt="" align="left" />Pytanie o plany rodzinne usłyszała w trakcie rekrutacji co czwarta osoba; odsetek wśród kobiet wyniósł 32 proc., a mężczyzn - 19 proc. - wynika z opublikowanego w środę badania. Z niesprawiedliwym traktowaniem ze względu na wiek spotkało się 24 proc. badanych.</p>

## Kotecki: Polska gospodarka rozwija się poniżej potencjału. Co z inflacją i PKB w 2025 roku?
 - [https://www.bankier.pl/wiadomosc/Koteki-Polska-gospodarka-rozwija-sie-ponizej-potencjalu-Co-z-inflacja-i-PKB-w-2025-roku-8833262.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koteki-Polska-gospodarka-rozwija-sie-ponizej-potencjalu-Co-z-inflacja-i-PKB-w-2025-roku-8833262.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T08:25:40.800442+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/8/4/edbff0d85a2bb8-948-568-0-0-2048-1228.jpg" alt="" align="left" />Średnioroczna inflacji konsumencka i wzrost PKB mogą być niższe niż w założeniach do budżetu państwa na 2025 r., ocenia w rozmowie z ISBnews członek Rady Polityki Pieniężnej (RPP) Ludwik Kotecki. Podkreślił, że wzrost gospodarczy nie przekroczy 3% r/r w br., a dodatkowo konsument staje się ostrożny w wydawaniu pieniędzy.</p>

## Loteria Buddy "7 aut 2!" miała pozwolenie skarbówki. Dlaczego prokuratura bada sprawę?
 - [https://www.bankier.pl/wiadomosc/Budda-podejrzany-o-nielegalny-hazard-Ale-loteria-7-aut-2-miala-pozwolenie-8833216.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Budda-podejrzany-o-nielegalny-hazard-Ale-loteria-7-aut-2-miala-pozwolenie-8833216.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T08:25:40.165446+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/4/5/28f2870aede0b2-948-568-0-569-2681-1608.jpg" alt="" align="left" />W połowie października znany youtuber Budda został zatrzymany i usłyszał zarzuty organizowania nielegalnych gier hazardowych i prania pieniędzy. Na loterię, w której pula nagród była warta 7,5 mln złotych zgodę, wydała Izba Administracji Skarbowej w Krakowie. W czym więc tkwi problem?</p>

## Off Radio Kraków zwolniło dziennikarzy. Zastąpiła ich sztuczna inteligencja
 - [https://www.bankier.pl/wiadomosc/Off-Radio-Krakow-zwolnilo-dziennikarzy-Zastapila-ich-sztuczna-inteligencja-8833207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Off-Radio-Krakow-zwolnilo-dziennikarzy-Zastapila-ich-sztuczna-inteligencja-8833207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T07:19:40.533441+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/1/9/8f9b0cfb895364-948-568-0-7-2787-1672.jpg" alt="" align="left" />Szansa czy zagrożenie - wokół sztucznej inteligencji jest wiele niewiadomych. Choć powinna wspierać człowieka w pracy, to często mu ją zabiera. Zwolnienia dziennikarzy w Off Radio Kraków wywołały burzę - zastąpi ich bowiem AI. Byli i obecni współpracownicy rozgłośni przygotowali petycję skierowaną m.in. do RPO i KRRiT. Głos w sprawie zabrał nawet wicepremier Krzysztof Gawkowski.</p>

## Bałtycka zapaść. Związek Rybaków Polskich: Ograniczenie połowów spóźnione
 - [https://www.bankier.pl/wiadomosc/Baltycka-zapasc-Zwiazek-Rybakow-Polskich-Ograniczenie-polowow-spoznione-8833198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Baltycka-zapasc-Zwiazek-Rybakow-Polskich-Ograniczenie-polowow-spoznione-8833198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T06:14:44.001157+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/c/7/88c0eea29767a5-945-560-0-240-3704-2222.jpg" alt="" align="left" />Prezes Związku Rybaków Polskich Grzegorz Hałubek powiedział w rozmowie z PAP, że decyzja Unii Europejskiej w sprawie ograniczenia połowów na Bałtyku powinna zapaść dwanaście lat wcześniej. Ocenił, że zbyt późne decyzje w tej sprawie pogłębiły zapaść w ekosystemie Bałtyku.</p>

## Polski przemysł motoryzacyjny się stacza. Prognozy są złe
 - [https://www.bankier.pl/wiadomosc/Polski-przemysl-motoryzacyjny-sie-stacza-Prognozy-sa-zle-8833189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-przemysl-motoryzacyjny-sie-stacza-Prognozy-sa-zle-8833189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T06:14:43.127210+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/3/ee5bc0b66e4445-948-568-109-79-1873-1124.jpg" alt="" align="left" />Perspektywy polskiego przemysłu motoryzacyjnego szybko się pogarszają. W ciągu ostatnich 12 miesięcy odsetek szefów firm tego sektora przewidujących spadki produkcji wzrósł pięciokrotnie - informuje w środowym wydaniu "Rzeczpospolita".</p>

## Płatnościom odroczonym InPost Pay przyjrzy się nadzór finansowy
 - [https://www.bankier.pl/wiadomosc/Platnosciom-odroczonym-InPost-Pay-przyjrzy-sie-nadzor-finansowy-8833206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Platnosciom-odroczonym-InPost-Pay-przyjrzy-sie-nadzor-finansowy-8833206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T06:14:42.456096+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/a/c/edb5f9b6d2a25c-948-568-5-105-1074-644.png" alt="" align="left" />Przed kilkoma dniami InPost rozpoczął pilotażowe wdrożenie płatności odroczonych. Usługa dostępna jest na razie dla kilku e-sklepów. Sposób wnioskowania o odłożenie uregulowania rachunku zainteresował Komisję Nadzoru Finansowego.</p>

## Drożyzna w marketach. Inflacja niby 5 proc. a ceny w sklepach wzrosły o 50 proc. rdr.
 - [https://www.bankier.pl/wiadomosc/Drozyzna-w-marketach-Jest-ponad-polowe-drozej-niz-rok-temu-8833166.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drozyzna-w-marketach-Jest-ponad-polowe-drozej-niz-rok-temu-8833166.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T06:02:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/3/895b97188f25f3-945-560-0-25-1000-599.jpg" alt="" align="left" />Auchan liderem najniższych cen we wrześniu, wyprzedził Selgros i Makro Cash &amp; Carry - podała agencja badawcza ASM SFA.</p>

## USA już nie takie atrakcyjne? Najmniej nielegalnych prób przekroczenia granicy od czterech lat
 - [https://www.bankier.pl/wiadomosc/USA-juz-nie-takie-atrakcyjne-Najmniej-nielegalnych-prob-przekroczenia-granicy-od-czterech-lat-8833168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-juz-nie-takie-atrakcyjne-Najmniej-nielegalnych-prob-przekroczenia-granicy-od-czterech-lat-8833168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:39.505487+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/a/a/c09c0118298a24-945-560-0-63-1500-899.jpg" alt="" align="left" />Amerykańskie służby ds. ceł i ochrony granic  poczynając od 5 czerwca odnotowały 55 proc. spadek liczby nielegalnych przekroczeń południowo-zachodniej granicy. Przypisuje się to rozporządzeniu wykonawczemu prezydenta Joe Bidena poważnie ograniczającemu przyznawanie azylu.</p>

## Gen. Kelly: Trump spełnia definicję faszysty. Mówił, że Hitler robił dobre rzeczy
 - [https://www.bankier.pl/wiadomosc/Gen-Kelly-Trump-spelnia-definicje-faszysty-Mowil-ze-Hitler-robil-dobre-rzeczy-8833159.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gen-Kelly-Trump-spelnia-definicje-faszysty-Mowil-ze-Hitler-robil-dobre-rzeczy-8833159.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:39.318065+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/f/2/a0b3ee022e1978-948-568-0-289-4458-2674.jpg" alt="" align="left" />Donald Trump spełnia definicję faszysty i chciałby rządzić jak dyktator - powiedział były szef personelu Białego Domu gen. John Kelly w wywiadach dla "New York Timesa" i magazynu "The Atlantic". Kelly opowiadał też, że Trump niejednokrotnie twierdził, że Hitler robił też dobre rzeczy.</p>

## Koniec z dwukadencyjnością. Samorządowcy chcą zmiany prawa znowelizowanego przez PiS
 - [https://www.bankier.pl/wiadomosc/Koniec-z-dwukadencyjnoscia-Samorzadowcy-chca-zmiany-prawa-znowelizowanego-przez-PiS-8833182.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-dwukadencyjnoscia-Samorzadowcy-chca-zmiany-prawa-znowelizowanego-przez-PiS-8833182.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:39.127830+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/b/a/c72951105ae8fc-948-568-0-187-3000-1799.jpg" alt="" align="left" />Zniesienie dwukadencyjności, znaczne poszerzenie kompetencji samorządu m.in. w sprawach ochrony środowiska,  to niektóre z postulatów samorządowców, które wkrótce będą omawiane z rządem - informuje w środowym wydaniu "Rzeczpospolita".</p>

## Stalowe nerwy Kanady. Wytoczyła działa przeciwko chińskiej "taniości"
 - [https://www.bankier.pl/wiadomosc/Stalowe-nerwy-Kanady-Wytoczyla-dziala-przeciwko-chinskiej-taniosci-8833169.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stalowe-nerwy-Kanady-Wytoczyla-dziala-przeciwko-chinskiej-taniosci-8833169.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:38.942558+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/4/1/6f62a6283a85c3-948-568-0-62-1773-1063.jpg" alt="" align="left" />Kanada będzie chronić rynek przed tanim chińskim importem stali i aluminium, a także przed zbyt tanią zagraniczną siłą roboczą – poinformował rząd we wtorek. Jednocześnie budżet federalny wesprze małe i średnie firmy w wykorzystaniu rozwiązań AI.</p>

## Zmęczony, bez motywacji, odlicza czas do 17. Obraz Polaka w pracy
 - [https://www.bankier.pl/wiadomosc/Zmeczony-bez-motywacji-odlicza-czas-do-17-Obraz-Polaka-w-pracy-8833181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmeczony-bez-motywacji-odlicza-czas-do-17-Obraz-Polaka-w-pracy-8833181.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:38.554397+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/6/d/8fd9b18d2d9b35-948-568-270-164-2527-1516.jpg" alt="" align="left" />Po ponad 40 godzinach pracy w tygodniu Polacy są zmęczeni i nie mają motywacji - informuje środowa "Gazeta Wyborcza”.</p>

## Tak zetki wybierają ubezpieczenia. "To wynik większego sceptycyzmu"
 - [https://www.bankier.pl/wiadomosc/Tak-zetki-wybieraja-ubezpieczenia-To-wynik-wiekszego-sceptycyzmu-8833178.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-zetki-wybieraja-ubezpieczenia-To-wynik-wiekszego-sceptycyzmu-8833178.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:38.317698+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/c/ce32f447ff0fd4-948-568-19-19-3976-2385.jpg" alt="" align="left" />Młodzi Polacy przy wyborze ubezpieczenia najczęściej kierują się opinią rodziny - 42 proc. i przyjaciół - 26 proc. - wynika z raportu Deloitte przekazanego PAP.  30 proc. pokolenia "Z" bierze też pod uwagę rady agentów ubezpieczeniowych, a z porównywarek internetowych korzysta niespełna 20 proc.</p>

## Migracja szyta na miarę. Koniec nieuczciwych praktyk agencji pracy?
 - [https://www.bankier.pl/wiadomosc/Migracja-szyta-na-miare-Kto-bedzie-mogl-przyjechac-do-pracy-w-Polsce-8832869.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Migracja-szyta-na-miare-Kto-bedzie-mogl-przyjechac-do-pracy-w-Polsce-8832869.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:37.690885+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/b/6/5b4d70cbfe9aad-948-568-42-76-1657-994.jpg" alt="" align="left" />Znany jest już
projekt rządowej strategii migracyjnej na lata 2025-2030. Rada Ministrów
chce większej kontroli nad przyjazdami cudzoziemców, w tym także wzrostu
poziomu selektywności w polityce wizowej. Jak wpłynie to na polski rynek
pracy?</p>

## Za mało małych mieszkań. Ceny wyższe niż rok temu
 - [https://www.bankier.pl/wiadomosc/Za-malo-malych-mieszkan-Ceny-wyzsze-niz-rok-temu-8832696.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Za-malo-malych-mieszkan-Ceny-wyzsze-niz-rok-temu-8832696.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:37.468700+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/a/81d490547dc509-948-568-0-59-1982-1189.jpg" alt="" align="left" />Zgodnie z ostatnim raportem NBP, podsumowującym sytuację na rynku nieruchomości w II kw. 2024 r., aktywność na rynku nieruchomości mieszkaniowych pozostawała wysoka. Obserwowano wzrost średnich cen transakcyjnych mkw. mieszkań, zarówno na rynku pierwotnym jak i wtórnym.</p>

## PKO BP z 11 mln klientów w 2023 roku, a teraz? Te banki obsługują najwięcej klientów
 - [https://www.bankier.pl/wiadomosc/PKO-BP-z-11-mln-klientow-w-2023-roku-a-teraz-Te-banki-obsluguja-najwiecej-klientow-8832791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-BP-z-11-mln-klientow-w-2023-roku-a-teraz-Te-banki-obsluguja-najwiecej-klientow-8832791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:37.129520+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/b/9/cdcf6023890070-948-568-0-270-4000-2399.jpg" alt="" align="left" />Najwięcej klientów w Polsce obsługują PKO Bank Polski, Bank Pekao, Santander Bank Polska i ING Bank Śląski – wynika z danych zebranych przez Bankier.pl. Na koniec półrocza ankietowane przez nas banki obsługiwały łącznie 55 mln klientów, z czego 51 mln w segmencie detalicznym.</p>

## Europejska konkurencja dla Visy i Mastercarda nabiera rozpędu
 - [https://www.bankier.pl/wiadomosc/Wero-europejska-konkurencja-dla-Visy-i-Mastercarda-startuje-we-Francji-8832875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wero-europejska-konkurencja-dla-Visy-i-Mastercarda-startuje-we-Francji-8832875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T05:09:36.737552+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/0/3/7489bfe2b81cea-728-436-187-8-728-436.jpg" alt="" align="left" />Wygląda na to, że kolejne w ostatnich 10 latach podejście do stworzenia europejskiego systemu płatności ma szansę na powodzenie. Portfel Wero, po debiucie w Niemczech i Belgii, startuje właśnie na francuskim rynku. Czy Visa i Mastercard mają się czego bać?</p>

## Polacy oblegają ukraińskie uczelnie medyczne. Studia to banał, a nostryfikacja łatwizna?
 - [https://www.bankier.pl/wiadomosc/Polacy-oblegaja-ukrainskie-uczelnie-medyczne-Studia-to-banal-a-nostryfikacja-latwizna-8833149.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-oblegaja-ukrainskie-uczelnie-medyczne-Studia-to-banal-a-nostryfikacja-latwizna-8833149.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T04:41:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/6/9/bf606a024a565d-945-560-7-45-992-595.jpg" alt="" align="left" />Na stomatologię można się dostać bez egzaminu i studiować bez wychodzenia z domu. Polscy absolwenci ukraińskich uczelni coraz częściej nostryfikują dyplomy w naszym kraju albo w... Czechach - czytamy w środowym wydaniu "Dziennika Gazety Prawnej".</p>

## 1000 dolarów za ewakuację z Libanu. Wenezuela zarabia na swoich obywatelach
 - [https://www.bankier.pl/wiadomosc/1000-dolarow-za-ewakuacje-z-Libanu-Wenezuela-zarabia-na-swoich-obywatelach-8833145.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/1000-dolarow-za-ewakuacje-z-Libanu-Wenezuela-zarabia-na-swoich-obywatelach-8833145.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T04:10:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/d/7/7aa3265f705626-948-568-0-90-4000-2399.jpg" alt="" align="left" />Wenezuelczycy chcący uciec z Libanu w związku z izraelską operacją wojskową przeciw Hezbollahowi skarżą się na brak pomocy ze strony ambasady swojego kraju – podał we wtorek portal Infobae. Według jego rozmówców placówka żądała prawie 1000 dolarów za miejsce w locie ewakuacyjnym.</p>

## Rosja wzmaga ataki na statki przewożące ukraińskie zboże
 - [https://www.bankier.pl/wiadomosc/Rosja-wzmaga-ataki-na-statki-przewozace-ukrainskie-zboze-8833141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-wzmaga-ataki-na-statki-przewozace-ukrainskie-zboze-8833141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-23T02:31:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/0/1/b15aa995b4c450-948-568-0-258-4500-2699.jpg" alt="" align="left" />Rosja wzmogła ataki na ukraińską infrastrukturę portową na Morzu Czarnym, co opóźnia dostawy niezbędnej pomocy dla Palestyńczyków i uniemożliwia dostarczenie kluczowych dostaw zboża na globalne południe - ostrzegł we wtorek wieczorem brytyjski premier Keir Starmer.</p>

