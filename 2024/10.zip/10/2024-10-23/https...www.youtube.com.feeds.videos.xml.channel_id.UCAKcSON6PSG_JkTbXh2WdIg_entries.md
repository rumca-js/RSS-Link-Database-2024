# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Sierra Ferrell sings "American Dreaming" live at The Current #music #shorts
 - [https://www.youtube.com/watch?v=NRSJR8WKyW4](https://www.youtube.com/watch?v=NRSJR8WKyW4)
 - RSS feed: $source
 - date published: 2024-10-23T13:15:02+00:00

Sierra Ferrell performs "American Dreaming" live in studio
Support The Current: https://support.mpr.org/youtube

During a tour stop in the Twin Cities to play a show at First Avenue in Minneapolis, Sierra Ferrell and her band visited The Current for a studio session hosted by Jessica Paxton. Watch and listen to a performance of "American Dreaming" above.

Musicians
Sierra Ferrell – vocals, fiddle, guitar
Joshua Rilko – mandolin, guitar, backing vocals
Geoffrey Saunders – bass, backing vocals
Oliver Bates Craven – guitars, fiddle, backing vocals
Matty Meyer – drums

Credits
Guest – @SierraFerrell 
Host – Jessica Paxton
Producer – Derrick Stevens
Video Director – Derek Ramirez
Audio Engineer – Evan Clark
Camera Operators – Derek Ramirez, Megan Lundberg, Erik Stromstad
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.

## Brigitte Calls Me Baby perform "We Were Never Alive" in studio #music #shorts
 - [https://www.youtube.com/watch?v=MJk0FTBDsNU](https://www.youtube.com/watch?v=MJk0FTBDsNU)
 - RSS feed: $source
 - date published: 2024-10-23T12:30:16+00:00

Brigitte Calls Me Baby performing "We Were Never Alive" at The Current
Support The Current: https://support.mpr.org/youtube 

"We Were Never Alive" is from Brigitte Calls Me Baby’s 2024 album, The Future Is Our Way Out, available on @atorecords .

Musicians
Wes Leavins – lead vocals
Jack Fluegel – lead guitar
Devin Wessels – bass
Jeremy Benshish – drums
Dave Rosendahl – rhythm guitar

Credits
Guests – @brigittecallsmebaby 
Host – Jill Riley
Producers – Derrick Stevens, Nilufer Arsala
Audio – Eric Xu Romani
Video – Megan Lundberg
Graphics – Natalia Toledo
Digital Producer – Luke Taylor 

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.com/thecurrent/
https://www.threads.net/@thecurrent
https://www.tiktok.com/@thecurrent.org

#music #studio #performance

## Brigitte Calls Me Baby – three-song set in The Current studio
 - [https://www.youtube.com/watch?v=mZfPdR-FbFk](https://www.youtube.com/watch?v=mZfPdR-FbFk)
 - RSS feed: $source
 - date published: 2024-10-23T12:01:08+00:00

Brigitte Calls Me Baby perform three songs at The Current
Support The Current: https://support.mpr.org/youtube 

Chicago band Brigitte Calls Me Baby first grabbed everyone’s attention at SXSW in 2023. Not long after, they were signed to ATO Records, and have been on a steady track of touring and recording. 

On a visit to the Twin Cities to perform a show at the Fine Line in Minneapolis, Brigitte Calls Me Baby visited The Current studio to play three songs from their 2024 album, "The Future Is Our Way Out." Watch the performances above.

Songs Performed
00:00:00 Too Easy
00:03:28 We Were Never Alive
00:07:44 Impressively Average
All songs are from Brigitte Calls Me Baby’s 2024 album, The Future Is Our Way Out, available on @atorecords .

Musicians
Wes Leavins – lead vocals
Jack Fluegel – lead guitar
Devin Wessels – bass
Jeremy Benshish – drums
Dave Rosendahl – rhythm guitar

Credits
Guests – @brigittecallsmebaby 
Host – Jill Riley
Producers – Derrick Stevens, Nilufer Arsala
Audio – Er

