# Source:The Rubin Report, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng, language:en

## BBC Host Goes Quiet as Her Question for Conservative Backfires
 - [https://www.youtube.com/watch?v=BwS1oJXrwl0](https://www.youtube.com/watch?v=BwS1oJXrwl0)
 - RSS feed: $source
 - date published: 2024-10-23T02:15:00+00:00

Dave Rubin of “The Rubin Report” reacts to a DM clip of Kemi Badenoch proudly laying out why Western civilization is a superior civilization to BBC’s Laura Kuenssberg.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=tiQVXb2JoGs&list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&index=1&t=1706s&pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#DaveRubinReacts #RubinReport #BBC #KemiBadenoch #thewest #westerncivilization #LauraKuenssberg  #immigration #culture #multiculturalism #DaveRubin #Shorts

The Direct Message directly addresses political news, cultural news and current events of the day. It’s only by having rational conversations about these topics that we can help end political polarization. To hear what Dave has to say on these and a variety of other topics watch this playlist: https://www.youtube.com/playlist?list=PLEbhOtC9klbDG22n--rC

## This Was Shocking Even for Trump
 - [https://www.youtube.com/watch?v=zbUMRANcP8U](https://www.youtube.com/watch?v=zbUMRANcP8U)
 - RSS feed: $source
 - date published: 2024-10-23T00:15:02+00:00

Dave Rubin of “The Rubin Report” reacts to Donald Trump's "adult" comments about golf legend Arnold Palmer.

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

-----------------------------------

#DaveRubinReacts #ArnoldPalmer #Golf #legend #doessizematter #Trump #shorts

The Direct Message directly addresses political news, cultural news and current events of the day. It’s only by having rational conversations about these topics that we can help end political polarization. To hear what Dave has to say on these and a variety of other topics watch this playlist: https://www.youtube.com/playlist?list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL 

To make sure you never miss a single Rubin Report video, click here to subscribe:
https://www.youtube.com/channel/UCJdKr0Bgd_5saZYqLCa9mng?sub_confirmation=1

Looking for smart and honest conversations about current events, political news and the culture war? Want to increase your critical thinking by listening to different perspective

