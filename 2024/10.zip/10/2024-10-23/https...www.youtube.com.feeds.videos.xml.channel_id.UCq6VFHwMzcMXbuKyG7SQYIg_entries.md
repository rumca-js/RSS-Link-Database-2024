# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Is Sonic x Shadow Generations Good
 - [https://www.youtube.com/watch?v=JuZPHMI_NbQ](https://www.youtube.com/watch?v=JuZPHMI_NbQ)
 - RSS feed: $source
 - date published: 2024-10-23T05:37:30+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

## He's Met Bigfoot
 - [https://www.youtube.com/watch?v=lYfAN-hdSks](https://www.youtube.com/watch?v=lYfAN-hdSks)
 - RSS feed: $source
 - date published: 2024-10-23T01:15:03+00:00

Get Goof Juice https://gamersupps.gg/?ref=moist
This is the greatest bigfoot experience of All Time
Get a Starforge PC https://starforgepc.com/moist-yt
Merch https://moistglobal.com/
Comics https://badegg.co/

