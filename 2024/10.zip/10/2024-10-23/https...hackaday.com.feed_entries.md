# Source:Hackaday, URL:https://hackaday.com/feed, language:en-US

## Will .IO Domain Names Survive A Geopolitical Rearrangement?
 - [https://hackaday.com/2024/10/23/will-io-domain-names-survive-a-geopolitical-rearrangement](https://hackaday.com/2024/10/23/will-io-domain-names-survive-a-geopolitical-rearrangement)
 - RSS feed: $source
 - date published: 2024-10-23T14:00:34+00:00

<div><img width="800" height="484" src="https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg 3000w, https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg?resize=250,151 250w, https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg?resize=400,242 400w, https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg?resize=800,484 800w, https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg?resize=1536,929 1536w, https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg?resize=2048,1239 2048w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="729687" data-permalink="https://hackaday.com/2024/10/23/will-io-domain-names-survive-a-geopolitical-rearrangement/ioend/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/IOend.jpg" data-orig-size="3000,181

## Tridora: A Full-Custom CPU Designed For Pascal
 - [https://hackaday.com/2024/10/23/tridora-a-full-custom-cpu-designed-for-pascal](https://hackaday.com/2024/10/23/tridora-a-full-custom-cpu-designed-for-pascal)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:07+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/2631641728336669380-featured.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/2631641728336669380-featured.png 2499w, https://hackaday.com/wp-content/uploads/2024/10/2631641728336669380-featured.png?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/2631641728336669380-featured.png?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/10/2631641728336669380-featured.png?resize=800,450 800w, https://hackaday.com/wp-content/uploads/2024/10/2631641728336669380-featured.png?resize=1536,864 1536w, https://hackaday.com/wp-content/uploads/2024/10/2631641728336669380-featured.png?resize=2048,1152 2048w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="729610" data-permalink="https://hackaday.com/2024/10/23/trid

## 75-In-One Music
 - [https://hackaday.com/2024/10/23/75-in-one-music](https://hackaday.com/2024/10/23/75-in-one-music)
 - RSS feed: $source
 - date published: 2024-10-23T08:00:00+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/75-1-featured.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/75-1-featured.jpg 800w, https://hackaday.com/wp-content/uploads/2024/10/75-1-featured.jpg?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/75-1-featured.jpg?resize=400,225 400w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="729605" data-permalink="https://hackaday.com/2024/10/23/75-in-one-music/75-1-featured/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/75-1-featured.jpg" data-orig-size="800,450" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&q

## Heathkit Signal Generator Gets an Update
 - [https://hackaday.com/2024/10/22/heathkit-signal-generator-gets-an-update](https://hackaday.com/2024/10/22/heathkit-signal-generator-gets-an-update)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:02+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/heath.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/heath.png 800w, https://hackaday.com/wp-content/uploads/2024/10/heath.png?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/heath.png?resize=400,225 400w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="729331" data-permalink="https://hackaday.com/2024/10/22/heathkit-signal-generator-gets-an-update/heath-3/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/heath.png" data-orig-size="800,450" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&qu

## A Modern PC With a Retro OS
 - [https://hackaday.com/2024/10/22/a-modern-pc-with-a-retro-os](https://hackaday.com/2024/10/22/a-modern-pc-with-a-retro-os)
 - RSS feed: $source
 - date published: 2024-10-23T02:00:23+00:00

<div><img width="800" height="432" src="https://hackaday.com/wp-content/uploads/2024/10/dos-main.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/dos-main.jpg 1930w, https://hackaday.com/wp-content/uploads/2024/10/dos-main.jpg?resize=250,135 250w, https://hackaday.com/wp-content/uploads/2024/10/dos-main.jpg?resize=400,216 400w, https://hackaday.com/wp-content/uploads/2024/10/dos-main.jpg?resize=800,432 800w, https://hackaday.com/wp-content/uploads/2024/10/dos-main.jpg?resize=1536,828 1536w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="729589" data-permalink="https://hackaday.com/2024/10/22/a-modern-pc-with-a-retro-os/dos-main/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/dos-main.jpg" data-orig-size="1930,1041" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;1.88&quot;,&quo

