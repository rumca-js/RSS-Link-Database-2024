# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Atalanta vs Celtic: Line-ups and latest updates from Champions League
 - [https://www.telegraph.co.uk/football/2024/10/23/atalanta-vs-celtic-live-score-latest-champions-league](https://www.telegraph.co.uk/football/2024/10/23/atalanta-vs-celtic-live-score-latest-champions-league)
 - RSS feed: $source
 - date published: 2024-10-23T15:20:18+00:00

None

## Obama raps Eminem’s ‘Lose Yourself’ after rapper backs Kamala Harris - Video
 - [https://www.telegraph.co.uk/us/politics/2024/10/23/barack-obama-eminem-kamala-harris-detroit-rally-singer-rap](https://www.telegraph.co.uk/us/politics/2024/10/23/barack-obama-eminem-kamala-harris-detroit-rally-singer-rap)
 - RSS feed: $source
 - date published: 2024-10-23T14:12:41+00:00

<![CDATA[Eminem introduced Barack Obama at a Harris rally in Detroit, Michigan]]>

## The 10 best sofa beds of 2024, tried and tested for style and comfort
 - [https://www.telegraph.co.uk/recommended/home/best-sofa-beds-sitting-sleeping](https://www.telegraph.co.uk/recommended/home/best-sofa-beds-sitting-sleeping)
 - RSS feed: $source
 - date published: 2024-10-23T09:08:59+00:00

<![CDATA[We tested this year's best click-clack and pull-out sofa beds for making the most of your living space]]>

## Women’s America’s Cup was a step forward – but is not endgame for female sailors
 - [https://www.telegraph.co.uk/womens-sport/2024/10/23/womens-americas-cup-not-endgame-female-sailors](https://www.telegraph.co.uk/womens-sport/2024/10/23/womens-americas-cup-not-endgame-female-sailors)
 - RSS feed: $source
 - date published: 2024-10-23T09:01:00+00:00

<![CDATA[After first standalone women&rsquo;s race in Cup&rsquo;s 173-year history, Telegraph Sport debates whether it was a success and looks at what is next]]>

## McDonald’s shares plunge after fatal e.coli outbreak
 - [https://www.telegraph.co.uk/business/2024/10/23/ftse-100-markets-latest-news-budget-reeves-rates-mcdonalds](https://www.telegraph.co.uk/business/2024/10/23/ftse-100-markets-latest-news-budget-reeves-rates-mcdonalds)
 - RSS feed: $source
 - date published: 2024-10-23T06:30:11+00:00

<![CDATA[<p>McDonald’s shares plunged in after-hours trading after its Quarter Pounder hamburgers were linked to a <a class="ck-custom-link" href="https://www.telegraph.co.uk/us/news/2024/10/23/mcdonalds-e-coli-outbreak-quarter-pounders/">fatal outbreak of e.coli</a>.</p>]]>

