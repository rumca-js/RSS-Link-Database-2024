# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Boeing-made satellite breaks up in space
 - [https://www.bbc.com/news/articles/ce8d886l028o](https://www.bbc.com/news/articles/ce8d886l028o)
 - RSS feed: $source
 - date published: 2024-10-23T03:50:35+00:00

The "total loss" of the communications satellite has affected Intelsat customers around the world.

