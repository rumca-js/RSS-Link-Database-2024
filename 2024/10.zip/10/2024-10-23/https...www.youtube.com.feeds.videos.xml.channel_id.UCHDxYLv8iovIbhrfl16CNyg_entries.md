# Source:GameLinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg, language:en

## New Nintendo Leak Dropped
 - [https://www.youtube.com/watch?v=S3Wq9e6KfOc](https://www.youtube.com/watch?v=S3Wq9e6KfOc)
 - RSS feed: $source
 - date published: 2024-10-23T01:49:39+00:00

Get an exclusive deal on Private Internet Access VPN today at https://www.piavpn.com/GameLinked

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► LISTEN TO THE GAMING NEWS: https://lmg.gg/GameLinkedPodcast
► GET A VPN: https://lmg.gg/piagamelinked
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► WHERE WE BUY GAMES: https://lmg.gg/shopgames

NEWS SOURCES: https://lmg.gg/jsl6g
-------------------------------------------------------------------
Timestamps:
0:00 I mustache for your sympathies
0:14 Nintendo Playtest leaks
1:22 Squadron 42 has release window
3:49 QUICK BITS INTRO
3:57 Guerilla "done" with Killzone
4:32 Sonic x Shadow Generations goes hard
5:20 Bloober Team's new game details
6:00 Ubisoft Lost Crown team, AC early access gone
6:35 Sega gets their own patent lawsuit

