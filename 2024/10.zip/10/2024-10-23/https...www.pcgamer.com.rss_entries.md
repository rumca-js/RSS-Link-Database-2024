# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

##  Telltale heaves a long, dog-tired sigh at 'unsubstantiated Reddit threads', reassures fans that The Wolf Among Us 2 is still being made, honest 
 - [https://www.pcgamer.com/games/adventure/telltale-heaves-a-long-dog-tired-sigh-at-unsubstantiated-reddit-threads-reassures-fans-that-the-wolf-among-us-2-is-still-being-made-honest](https://www.pcgamer.com/games/adventure/telltale-heaves-a-long-dog-tired-sigh-at-unsubstantiated-reddit-threads-reassures-fans-that-the-wolf-among-us-2-is-still-being-made-honest)
 - RSS feed: $source
 - date published: 2024-10-23T13:44:04+00:00


                             The (tell)tales of my death are greatly over-exaggerated.  
                                                                                                            

##  AMD might not give up on AM4 just yet as it looks like more refreshed 5000-series chips are on the way 
 - [https://www.pcgamer.com/hardware/processors/amd-might-not-give-up-on-am4-just-yet-as-it-looks-like-more-refreshed-5000-series-chips-are-on-the-way](https://www.pcgamer.com/hardware/processors/amd-might-not-give-up-on-am4-just-yet-as-it-looks-like-more-refreshed-5000-series-chips-are-on-the-way)
 - RSS feed: $source
 - date published: 2024-10-23T12:01:28+00:00


                             Two generations old but still kicking. 
                                                                                                            

##  Asus TUF A14 review 
 - [https://www.pcgamer.com/hardware/gaming-laptops/asus-tuf-a14-review](https://www.pcgamer.com/hardware/gaming-laptops/asus-tuf-a14-review)
 - RSS feed: $source
 - date published: 2024-10-23T11:59:14+00:00


                             AMD Ryzen AI 9 HX 370 | Nvidia RTX 4060 (100 W) | 16 GB LPDDR5x-7500 | 1 TB SSD | $1499 | £1479 
                                                                                                            

##  Arm is reportedly cancelling Qualcomm's chip licence but it probably won't stop Snapdragon X 'AI' PCs from being made 
 - [https://www.pcgamer.com/hardware/processors/arm-is-reportedly-cancelling-qualcomms-chip-licence-but-it-probably-wont-stop-snapdragon-x-ai-pcs-from-being-made](https://www.pcgamer.com/hardware/processors/arm-is-reportedly-cancelling-qualcomms-chip-licence-but-it-probably-wont-stop-snapdragon-x-ai-pcs-from-being-made)
 - RSS feed: $source
 - date published: 2024-10-23T11:59:05+00:00


                             This legal tussle will almost certainly run and run. 
                                                                                                            

##  Radio station uses AI to interview the ghost of a dead Nobel-winner with 3 quirky zoomers who don't exist, seems baffled people don't like it 
 - [https://www.pcgamer.com/software/ai/radio-station-uses-ai-to-interview-the-ghost-of-a-dead-nobel-winner-with-3-quirky-zoomers-who-dont-exist-seems-baffled-people-dont-like-it](https://www.pcgamer.com/software/ai/radio-station-uses-ai-to-interview-the-ghost-of-a-dead-nobel-winner-with-3-quirky-zoomers-who-dont-exist-seems-baffled-people-dont-like-it)
 - RSS feed: $source
 - date published: 2024-10-23T11:56:59+00:00


                             Just saying I think I could have seen that coming. 
                                                                                                            

##  Gorgeous deck-building shop sim Potionomics just got a patch that fixes all my problems with it—plus voice acting, and an option to smooch everyone in a single playthrough 
 - [https://www.pcgamer.com/games/card-games/gorgeous-deck-building-shop-sim-potionomics-just-got-a-patch-that-fixes-all-my-problems-with-it-plus-voice-acting-and-an-option-to-smooch-everyone-in-a-single-playthrough](https://www.pcgamer.com/games/card-games/gorgeous-deck-building-shop-sim-potionomics-just-got-a-patch-that-fixes-all-my-problems-with-it-plus-voice-acting-and-an-option-to-smooch-everyone-in-a-single-playthrough)
 - RSS feed: $source
 - date published: 2024-10-23T11:27:40+00:00


                             Endless hubble and bubble. 
                                                                                                            

##  Romancing SaGa 2 is a remake of a weird, obtuse game that seemingly shouldn't exist, yet it defies the odds by sticking to what made it so unique in the first place 
 - [https://www.pcgamer.com/games/rpg/romancing-saga-2-is-a-remake-of-a-weird-obtuse-game-that-seemingly-shouldnt-exist-yet-it-defies-the-odds-by-sticking-to-what-made-it-so-unique-in-the-first-place](https://www.pcgamer.com/games/rpg/romancing-saga-2-is-a-remake-of-a-weird-obtuse-game-that-seemingly-shouldnt-exist-yet-it-defies-the-odds-by-sticking-to-what-made-it-so-unique-in-the-first-place)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:00+00:00


                             Over three decades of defying RPG standards. 
                                                                                                            

##  I'm #62935 on the waitlist for Daze, an expressive messenger app that's already got over 150,000 signups 
 - [https://www.pcgamer.com/hardware/Daze-chat-156000-signups](https://www.pcgamer.com/hardware/Daze-chat-156000-signups)
 - RSS feed: $source
 - date published: 2024-10-23T10:52:01+00:00


                             Does Daze have its head in the clouds, or do I? 
                                                                                                            

##  Today's Wordle answer for Wednesday, October 23 
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-october-23-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-october-23-2024)
 - RSS feed: $source
 - date published: 2024-10-23T03:00:59+00:00


                             Today's Wordle: Help with the daily puzzle. 
                                                                                                            

