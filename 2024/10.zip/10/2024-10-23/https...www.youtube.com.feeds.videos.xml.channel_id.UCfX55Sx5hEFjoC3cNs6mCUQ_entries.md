# Source:The Linux Foundation, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCfX55Sx5hEFjoC3cNs6mCUQ, language:en

## A celebration of community! #KubeCon #CloudNativeCon
 - [https://www.youtube.com/watch?v=3UfJePN2J9Q](https://www.youtube.com/watch?v=3UfJePN2J9Q)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:08+00:00

KubeCon + CloudNativeCon is more than just a tech event—it’s a community! From inspiring talks to building lifelong connections, this event is where learning and collaboration truly thrive. Join us this November in Salt Lake City and be part of the cloud native community.

Register Today: https://events.linuxfoundation.org/kubecon-cloudnativecon-north-america/

#KubeCon #CloudNativeCon

