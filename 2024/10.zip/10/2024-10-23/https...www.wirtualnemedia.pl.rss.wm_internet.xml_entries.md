# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Koniec Goldenline. Jak Agora tłumaczy to użytkownikom?
 - [https://www.wirtualnemedia.pl/artykul/goldenline-koniec-serwis-znika-agora](https://www.wirtualnemedia.pl/artykul/goldenline-koniec-serwis-znika-agora)
 - RSS feed: $source
 - date published: 2024-10-23T08:25:22.977867+00:00

Należący do Agory serwis rekrutacyjno-społecznościowy Goldenline z końcem listopada zniknie z internetu. Zarządzająca nim spółka wiosną br. została postawiona w stan likwidacji. Dekadę temu Agora zapłaciła za Goldenline ok. 20 mln zł.

## Legimi dalej traci po podwyżce i sporze z wydawcami. Ekspert: potrzeba szybkich działań
 - [https://www.wirtualnemedia.pl/artykul/legimi-musi-podjac-natychmiastowe-dzialania-by-ograniczyc-straty-finansowe-i-wizerunkowe](https://www.wirtualnemedia.pl/artykul/legimi-musi-podjac-natychmiastowe-dzialania-by-ograniczyc-straty-finansowe-i-wizerunkowe)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:14.627014+00:00

Platforma z ebookami i audiobookami Legimi po ogłoszeniu dodatkowej opłaty znalazła się w centrum debaty na temat transparentności i uczciwości w cyfrowej dystrybucji książek. Jej akcje przez kilka dni staniały o ponad połowę. - Jeśli firma nie podejmie szybkich działań, konsekwencje wizerunkowe mogą się nasilić, a reputacja platformy może zostać nadszarpnięta - komentuje dla Wirtualnemedia.pl dr inż Jacek Kotarbiński. 

## Czy finał „Stranger Things” czekają te same błędy co „Grę o tron”?
 - [https://www.wirtualnemedia.pl/artykul/stranger-things-sezon-final-kiedy-premiera-co-sie-wydarzy](https://www.wirtualnemedia.pl/artykul/stranger-things-sezon-final-kiedy-premiera-co-sie-wydarzy)
 - RSS feed: $source
 - date published: 2024-10-23T05:05:23.105934+00:00

Showrunnerzy hitu Netfliksa są świadomi błędów jakie popełnili twórcy „Gro o tron” i deklarują, że starannie dbają o to, aby uniknąć finału w stylu głośnej produkcji HBO. Do końca roku potrwają zdjęcia na planie zdjęciowym popularnego serialu giganta streamingu.

## Menedżer od treści AI po 9 latach odchodzi z Wirtualnej Polski
 - [https://www.wirtualnemedia.pl/artykul/marcin-watemborski-wirtualna-polska-menedzer](https://www.wirtualnemedia.pl/artykul/marcin-watemborski-wirtualna-polska-menedzer)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:16.063295+00:00

Marcin Watemborski po dziewięciu latach żegna się z Wirtualną Polską. Ostatnio pracował na stanowisku head of AI Content Department.  

## Meta testuje nowe rozwiązania w walce z oszustwami
 - [https://www.wirtualnemedia.pl/artykul/meta-testuje-nowe-rozwiazania-w-walce-z-oszustwami](https://www.wirtualnemedia.pl/artykul/meta-testuje-nowe-rozwiazania-w-walce-z-oszustwami)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:15.932383+00:00

Koncern Meta Platforms chce wykorzystywać technologię rozpoznawania twarzy do walki z fałszywymi reklamami w swoich serwisach społecznościowych. Będzie dotyczyć zwłaszcza znanych osób. To nie będzie jedyne zastosowanie tej techniki. 

