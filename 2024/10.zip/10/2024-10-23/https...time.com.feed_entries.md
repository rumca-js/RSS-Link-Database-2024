# Source:TIME, URL:https://time.com/feed, language:en-UK

## Prohibition Exposes the Dangers of Trump’s Immigration Rhetoric
 - [https://time.com/7088140/prohibition-immigration-rhetoric-trump](https://time.com/7088140/prohibition-immigration-rhetoric-trump)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:00+00:00

The history of the temperance movement shows that claims about protecting Americans from immigrants cloak a desire to impose a moral vision.

## Indigenous Australian Who Confronted King Charles III Criticizes British Monarchy Again
 - [https://time.com/7096395/indigenous-australian-confronted-king-charles-criticizes-british-monarchy](https://time.com/7096395/indigenous-australian-confronted-king-charles-criticizes-british-monarchy)
 - RSS feed: $source
 - date published: 2024-10-23T12:52:54+00:00

An Indigenous senator has intensified her criticism of King Charles III, again accusing the British monarch of complicity in “genocide."

## Bridget Everett on Bringing Her Full Self to Three Seasons of Somebody Somewhere
 - [https://time.com/7096025/bridget-everett-interview-somebody-somewhere-final-season](https://time.com/7096025/bridget-everett-interview-somebody-somewhere-final-season)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:00+00:00

The comedian, actor, and singer talks about ending her beloved HBO series, being honored by her hometown, and what's next.

## Blinken Urges Israel to Seek Deal After Tactical Gains as Truce Efforts Remain Stalled
 - [https://time.com/7096386/blinken-urges-israel-to-seek-deal-after-tactical-gains](https://time.com/7096386/blinken-urges-israel-to-seek-deal-after-tactical-gains)
 - RSS feed: $source
 - date published: 2024-10-23T10:48:31+00:00

Secretary of State Antony Blinken said on Wednesday that Israel needs to pursue an “enduring strategic success."

## A Brief History of Tulsi Gabbard’s Evolution—From Democratic ‘Star’ to MAGA Republican
 - [https://time.com/7096376/tulsi-gabbard-democrat-republican-political-evolution-history-trump](https://time.com/7096376/tulsi-gabbard-democrat-republican-political-evolution-history-trump)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:00+00:00

Former ‘rising star’ Democrat Tulsi Gabbard’s announcement that she’s joining the GOP has been years in the making.

## Amid Ownership Dispute, Ohtani’s 50-50 Baseball Sells at Auction for Record $4M
 - [https://time.com/7096369/shohei-ohtani-50-50-ball-auction](https://time.com/7096369/shohei-ohtani-50-50-ball-auction)
 - RSS feed: $source
 - date published: 2024-10-23T08:30:00+00:00

It’s a record high price not just for a baseball but for any ball in any sport, the auctioneer said, though the auction has been overshadowed by disputes over the ball’s ownership.

## People Who Knew the Zodiac Killer Suspect as Children Say He Confessed to Them in a New Netflix Doc
 - [https://time.com/7096188/this-is-the-zodiac-speaking-netflix](https://time.com/7096188/this-is-the-zodiac-speaking-netflix)
 - RSS feed: $source
 - date published: 2024-10-23T07:01:00+00:00

People who knew Arthur Leigh Allen as children say he confessed, drugged them, and brought them to the sites of Zodiac killer murders.

## Fernando Valenzuela, ‘One of the Most Influential Dodgers Ever,’ Dies at 63
 - [https://time.com/7096335/fernando-valenzuela-dodgers-pitcher-commentator-obituary](https://time.com/7096335/fernando-valenzuela-dodgers-pitcher-commentator-obituary)
 - RSS feed: $source
 - date published: 2024-10-23T05:15:00+00:00

“He is one of the most influential Dodgers ever,” said team president and CEO Stan Kasten, in a statement about the passing of the former pitcher-turned-commentator.

## The Biggest Moments From the TIME100 Health Leadership Forum
 - [https://time.com/7094016/health-leadership-forum-biggest-moments](https://time.com/7094016/health-leadership-forum-biggest-moments)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:00+00:00

TIME convened the first-ever TIME100 Health Leadership Forum to bring together individuals driving innovation and creating equitable initiatives within the health sector.

## Health Industry Experts Talk Increasing Trust and Lowering Costs
 - [https://time.com/7094014/health-leadership-forum-trust-costs](https://time.com/7094014/health-leadership-forum-trust-costs)
 - RSS feed: $source
 - date published: 2024-10-23T04:30:00+00:00

Dr. Raj Panjabi, Lori M. Reilly, Dr. Ziyad Al-Aly spoke on a panel at the TIME100 Health Leadership Forum.

## At Detroit Rally for Kamala Harris, Eminem Endorses and Obama Raps
 - [https://time.com/7096316/eminem-barack-obama-kamala-harris-campaign-detroit-michigan](https://time.com/7096316/eminem-barack-obama-kamala-harris-campaign-detroit-michigan)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:00+00:00

Voter turnout in Detroit, a longtime Democratic stronghold, will be crucial in determining who wins Michigan, a crucial swing state, in November.

## How Emerging Technologies Can Transform Health Care
 - [https://time.com/7094012/health-leadership-forum-emerging-technologies](https://time.com/7094012/health-leadership-forum-emerging-technologies)
 - RSS feed: $source
 - date published: 2024-10-23T03:30:00+00:00

Shyamal Patel and Dr. David Agus spoke about wearable health tech at the TIME100 Health Leadership Forum.

## How Emerging Technologies Can Transform Health Care
 - [https://time.com/7094012/health-leadership-forum-shell-3](https://time.com/7094012/health-leadership-forum-shell-3)
 - RSS feed: $source
 - date published: 2024-10-23T03:30:00+00:00

Shyamal Patel and Dr. David Agus spoke about wearable health tech at the TIME100 Health Leadership Forum.

## How Health Care Can Be Made More Equitable
 - [https://time.com/7094008/health-leadership-forum-equitable-care](https://time.com/7094008/health-leadership-forum-equitable-care)
 - RSS feed: $source
 - date published: 2024-10-23T03:30:00+00:00

Dr. Uché Blackstock, Adrelia Allen, and Ai-jen Poo spoke on a panel at the TIME100 Health Leadership Forum.

## How Women’s Health Is Global Health
 - [https://time.com/7094010/health-leadership-forum-shell-2](https://time.com/7094010/health-leadership-forum-shell-2)
 - RSS feed: $source
 - date published: 2024-10-23T03:30:00+00:00

Dr. Natalia Kanem, Dr. Tlaleng Mofokeng, and Dr. Asif Dhar spoke on a panel at the TIME100 Health Leadership Forum.

## How Women’s Health Is Global Health
 - [https://time.com/7094010/health-leadership-forum-women-global](https://time.com/7094010/health-leadership-forum-women-global)
 - RSS feed: $source
 - date published: 2024-10-23T03:30:00+00:00

Dr. Natalia Kanem, Dr. Tlaleng Mofokeng, and Dr. Asif Dhar spoke on a panel at the TIME100 Health Leadership Forum.

## A New Special Finds Hasan Minhaj Relaxed, Confident, and Ready to Move Past the Backlash
 - [https://time.com/7096089/hasan-minhaj-off-with-his-head-netflix](https://time.com/7096089/hasan-minhaj-off-with-his-head-netflix)
 - RSS feed: $source
 - date published: 2024-10-23T02:16:38+00:00

Hasan Minhaj's new special finds the comedian relaxed, confident, and ready to move forward

## McDonald’s Quarter Pounder Linked to Severe E. Coli Outbreak in U.S.
 - [https://time.com/7096222/mcdonalds-quarter-pounder-e-coli](https://time.com/7096222/mcdonalds-quarter-pounder-e-coli)
 - RSS feed: $source
 - date published: 2024-10-23T02:00:00+00:00

McDonald’s said it was taking “swift and decisive action” to control the outbreak that has sickened dozens of people, mainly in Colorado and Nebraska.

