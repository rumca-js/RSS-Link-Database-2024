# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 🪟 sudo w Windowsach nadchodzi
 - [https://www.youtube.com/watch?v=NM3mPJsggpQ](https://www.youtube.com/watch?v=NM3mPJsggpQ)
 - RSS feed: $source
 - date published: 2024-10-23T04:30:13+00:00

Windowsy w końcu dadzą możliwość tymczasowego podnoszenia uprawnień do poziomu administratora.
 
Źródła:
https://tinyurl.com/mr4mrmyv
https://tinyurl.com/y8jzdv5r
 
#Windows #Linux #sudo #bezpieczeństwo

