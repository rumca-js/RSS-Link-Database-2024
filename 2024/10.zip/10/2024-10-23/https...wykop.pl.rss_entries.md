# Source:Wykop, URL:https://wykop.pl/rss, language:pl-PL

## Kopali i okładali pięściami 72-latka w metrze. Szuka ich policja
 - [https://wykop.pl/link/7571911/kopali-i-okladali-piesciami-72-latka-w-metrze-szuka-ich-policja](https://wykop.pl/link/7571911/kopali-i-okladali-piesciami-72-latka-w-metrze-szuka-ich-policja)
 - RSS feed: $source
 - date published: 2024-10-23T13:18:54+00:00

 <img src="https://wykop.pl/cdn/c3397993/9e9f754b4eef896cf8a3bea811f34aeb8e777c64befe8362b8a9869bd018c58e,w104h74.jpg"/><br/> Stołeczna policja poszukuje sprawców pobicia w metrze. Na stacji Nowy Świat-Uniwersytet dwóch mężczyzn w wieku ok. 20 lat kopało i okładało pięściami 72-latka, który trafił potem do szpitala. 

## Matka z córką w stanie ciężkim. Potrącił je kierowca po amfetaminie i alkoholu
 - [https://wykop.pl/link/7571887/matka-z-corka-w-stanie-ciezkim-potracil-je-kierowca-po-amfetaminie-i-alkoholu](https://wykop.pl/link/7571887/matka-z-corka-w-stanie-ciezkim-potracil-je-kierowca-po-amfetaminie-i-alkoholu)
 - RSS feed: $source
 - date published: 2024-10-23T12:22:47.284627+00:00

 <img src="https://wykop.pl/cdn/c3397993/b5b5c2bbb5d3deb6c30be4297995a0480d3b52fcc34a78d1f59b77fc3743961c,w104h74.jpg"/><br/> Pod wpływem alkoholu i a--------y był 32-latek, który w Krakowie przy ul. Działowskiego potrącił 42-letnią kobietę idącą ze swoją 7-letnią córką - poinformowała w środę małopolska policja. Na miejscu lądował śmigłowiec Lotniczego Pogotowia Ratunkowego. Zarówno kobieta, jak i 7-latka, doznały obrażeń 

## Anglik opowiada jak prze*ane stało się życie w UK ale nejlepsze są komentarze
 - [https://wykop.pl/link/7571833/anglik-opowiada-jak-prze-ane-stalo-sie-zycie-w-uk-ale-nejlepsze-sa-komentarze](https://wykop.pl/link/7571833/anglik-opowiada-jak-prze-ane-stalo-sie-zycie-w-uk-ale-nejlepsze-sa-komentarze)
 - RSS feed: $source
 - date published: 2024-10-23T12:02:26+00:00

 <img src="https://wykop.pl/cdn/c3397993/ff7fd4b0161e319dd837b882125a623d4832d91f3b136219b93511ddaf5db340,w104h74.jpg"/><br/> 10k komentarzy, większość już wyjechała albo szykuje wyjazd, wybierają Polskę, Czechy, Hiszpanie, Bałkany, Japonię. Najlepszy wpis: "Good to see poles going back to Poland, as a Brit I am considering joining them. Funny how in 20 years its like a role reversal" 

## Śledził samoloty celebrytów. Meta skasowała mu konta na Facebooku, Instagramie i
 - [https://wykop.pl/link/7571823/sledzil-samoloty-celebrytow-meta-skasowala-mu-konta-na-facebooku-instagramie-i](https://wykop.pl/link/7571823/sledzil-samoloty-celebrytow-meta-skasowala-mu-konta-na-facebooku-instagramie-i)
 - RSS feed: $source
 - date published: 2024-10-23T11:58:40+00:00

 <img src="https://wykop.pl/cdn/c3397993/d6b87898e2c0fc5ee997da52735a759bde8f5125356c0514d5d60f36b56b681d,w104h74.jpg"/><br/> Na ogonie Jacka Sweeneya, studenta, który za pomocą publicznie dostępnych danych śledzi pozycje samolotów celebrytów, siedzą nie tylko sami celebryci, ale i platformy społecznościowe. Meta właśnie zbanowała mu wszystkie konta, powołując się na zakaz publikacji adresów. 

## Wytknął prokuraturze nieprawidłowości, wsadzili go do psychiatryka
 - [https://wykop.pl/link/7571791/wytknal-prokuraturze-nieprawidlowosci-wsadzili-go-do-psychiatryka](https://wykop.pl/link/7571791/wytknal-prokuraturze-nieprawidlowosci-wsadzili-go-do-psychiatryka)
 - RSS feed: $source
 - date published: 2024-10-23T11:17:15.641322+00:00

 <img src="https://wykop.pl/cdn/c3397993/3caf51c89a337be9a70e98954f23b5c430d587f4394b944255b68b9320c5f62d,w104h74.jpg"/><br/> Sytuacja jak w Procesie Kafki, gdzie wobec działań instytucji człowiek jest całkowicie bezradny. Spotkało to przedsiębiorcę Andrzeja Andrzejewskiego, który wytknął prokuraturze nieprawidłowości, w tym sfałszowany podpis policjanta. 

## Rząd kupuje Diesle i benzyny. Nie chcą jeździć elektrykami, choć wybór jest
 - [https://wykop.pl/link/7571747/rzad-kupuje-diesle-i-benzyny-nie-chca-jezdzic-elektrykami-choc-wybor-jest](https://wykop.pl/link/7571747/rzad-kupuje-diesle-i-benzyny-nie-chca-jezdzic-elektrykami-choc-wybor-jest)
 - RSS feed: $source
 - date published: 2024-10-23T10:57:21+00:00

 <img src="https://wykop.pl/cdn/c3397993/20af9737b1e181ff354b1ae0739e0bcdae81039c059733b13961d6851cbdb406,w104h74.jpg"/><br/> Spalinówki są dla zarządu. 

## Ministra Równości: nie ma woli politycznej do zrównania wieku emerytalnego
 - [https://wykop.pl/link/7571699/ministra-rownosci-nie-ma-woli-politycznej-do-zrownania-wieku-emerytalnego](https://wykop.pl/link/7571699/ministra-rownosci-nie-ma-woli-politycznej-do-zrownania-wieku-emerytalnego)
 - RSS feed: $source
 - date published: 2024-10-23T10:12:10.653639+00:00

 <img src="https://wykop.pl/cdn/c3397993/28522fcc8e5b3d7b971e7d0e9db57200e4140f9bc1f834f24e87c08c568199fc,w104h74.jpg"/><br/> Ale Pani Ministra rozumie potrzebę dyskusji - powinniśmy rozmawiać. Dodaje też, że kobiety pracują na drugi etat bo bardziej zajmują się domem niż mężczyźni. Co w tym czasie robią mężczyzni - tego nie powiedziała. Wypowiedź z 23.10.2024 

## Wielkie bezprawie i demontaż Państwa czyli bezkarność polskich sądów
 - [https://wykop.pl/link/7571653/wielkie-bezprawie-i-demontaz-panstwa-czyli-bezkarnosc-polskich-sadow](https://wykop.pl/link/7571653/wielkie-bezprawie-i-demontaz-panstwa-czyli-bezkarnosc-polskich-sadow)
 - RSS feed: $source
 - date published: 2024-10-23T10:01:07+00:00

 <img src="https://wykop.pl/cdn/c3397993/bf788dfdf80eb924348ff2edc26892379209631aef5b739861a1182a1acf58fb.png"/><br/> Polskie sądownictwo jest tylko dla tych, którzy mają wielkie pieniądze. Sądy służą nie wiadomo komu, a ich bezkarność i przewlekłość postępowań prowadzą do erozji zaufania do instytucji państwowych i poczucia niesprawiedliwości w społeczeństwie. Aby przywrócić zaufanie do systemu prawnego, koniec... 

## Rząd tnie wydatki na energetykę jądrową
 - [https://wykop.pl/link/7571607/rzad-tnie-wydatki-na-energetyke-jadrowa](https://wykop.pl/link/7571607/rzad-tnie-wydatki-na-energetyke-jadrowa)
 - RSS feed: $source
 - date published: 2024-10-23T09:26:35+00:00

 <img src="https://wykop.pl/cdn/c3397993/4dede357071b0b2893079ad7ad40fb1f39413cd5eb886926993dde03202df334,w104h74.jpg"/><br/> Najwyraźniej mamy zapomnieć o prawdziwie polskim atomie i reaktorach HTGR. Ale 1,5 mld rezerwy dla deweloperów jest trzymane 

## Zapłacił za większy metraż niż wpisany w księdze wiecz. "To nie nasza decyzja"
 - [https://wykop.pl/link/7571553/zaplacil-za-wiekszy-metraz-niz-wpisany-w-ksiedze-wiecz-to-nie-nasza-decyzja](https://wykop.pl/link/7571553/zaplacil-za-wiekszy-metraz-niz-wpisany-w-ksiedze-wiecz-to-nie-nasza-decyzja)
 - RSS feed: $source
 - date published: 2024-10-23T08:22:43+00:00

 <img src="https://wykop.pl/cdn/c3397993/8d4355b41a5f6747335f2630b962ed59a0d81cb19b903338e1b807f1ec6d2599,w104h74.jpg"/><br/> Adam podpisał umowę na zakup 39-metrowego mieszkania. Po powstaniu budynku deweloper kazał mu dopłacić do 40 mkw., ale do aktu notarialnego wpisał powierzchnię... 38 m kw. To sprytny nowy sprytny sposób deweloperów na dodatkowy zarobek. 

## Spadek sprzedaży detalicznej. Hennig-Kloska: "To nawet dobrze"
 - [https://wykop.pl/link/7571533/spadek-sprzedazy-detalicznej-hennig-kloska-to-nawet-dobrze](https://wykop.pl/link/7571533/spadek-sprzedazy-detalicznej-hennig-kloska-to-nawet-dobrze)
 - RSS feed: $source
 - date published: 2024-10-23T08:00:46+00:00

 <img src="https://wykop.pl/cdn/c3397993/362e1d364aeca0575c64f894289c46995e59d321e728dab07da040f40a7fabe4,w104h74.jpg"/><br/> Paulina Hennig-Kloska została zapytana przez Polsat News o problem spadku sprzedaży detalicznej, który został odnotowany w ujęciu miesięcznym na poziomie 7 proc. Ministra klimatu i środowiska w zaskakującej odpowiedzi stwierdziła, że jeśli Polacy będą kupować mniej tekstyliów, to lepiej dla środowis 

## Krzyczał i wyzywał ekspedientki w sklepie. 33-latek aresztowany
 - [https://wykop.pl/link/7571527/krzyczal-i-wyzywal-ekspedientki-w-sklepie-33-latek-aresztowany](https://wykop.pl/link/7571527/krzyczal-i-wyzywal-ekspedientki-w-sklepie-33-latek-aresztowany)
 - RSS feed: $source
 - date published: 2024-10-23T07:47:13+00:00

 <img src="https://wykop.pl/cdn/c3397993/b20ef8c0aef5a8fb63ee8cc1a99c3aa724acc03d8ca63c83f8c35ce9de61d3c5.png"/><br/> Policjanci z Woli zatrzymali 33-latka, który groził ekspedientkom, że je zabije, a jedną z nich znieważył z powodu przynależności narodowościowej. Mężczyzna został tymczasowo aresztowany na 3 miesiące. 

## Nieoficjalnie: Podejrzany o podwójne zabójstwo uciekł, gdy... mundurowi spali
 - [https://wykop.pl/link/7571511/nieoficjalnie-podejrzany-o-podwojne-zabojstwo-uciekl-gdy-mundurowi-spali](https://wykop.pl/link/7571511/nieoficjalnie-podejrzany-o-podwojne-zabojstwo-uciekl-gdy-mundurowi-spali)
 - RSS feed: $source
 - date published: 2024-10-23T07:16:20+00:00

 <img src="https://wykop.pl/cdn/c3397993/371fa1849933bff7b48d66450368f302819943282fbfa03d8080f8525b5b151b,w104h74.jpg"/><br/> Funkcjonariusze Służby Więziennej, którzy mieli pilnować podejrzanego o podwójne zabójstwo, spali na służbie. Taki błąd miała stwierdzić prokuratura badająca sprawę ucieczki mężczyzny ze szpitala psychiatrycznego w Radecznicy w Lubelskiem. 

## Norweski fundsuz zarobił po 55 tys. PLN na obywatela w 3 miesiące
 - [https://wykop.pl/link/7571509/norweski-fundsuz-zarobil-po-55-tys-pln-na-obywatela-w-3-miesiace](https://wykop.pl/link/7571509/norweski-fundsuz-zarobil-po-55-tys-pln-na-obywatela-w-3-miesiace)
 - RSS feed: $source
 - date published: 2024-10-23T07:12:19+00:00

 <img src="https://wykop.pl/cdn/c3397993/9ab273f8f62af7b7f41faae3895fcaebe572d4da8612f66099691ffd72c3f9e5,w104h74.jpg"/><br/> Norweski Państwowy Fundusz Emerytalny w samym trzecim kwartale 2024 roku zarobił ponad 305,6 mld PLN. W przeliczeniu na jednego obywatela daje to kwotę blisko 55 tys. PLN. 

## Pizza z... kokainą. Sprzedawano ją w niemieckiej restauracji
 - [https://wykop.pl/link/7571489/pizza-z-kokaina-sprzedawano-ja-w-niemieckiej-restauracji](https://wykop.pl/link/7571489/pizza-z-kokaina-sprzedawano-ja-w-niemieckiej-restauracji)
 - RSS feed: $source
 - date published: 2024-10-23T06:39:45+00:00

 <img src="https://wykop.pl/cdn/c3397993/391bc96655b915e4db5571133ec74cc94586d2d0b820f82d8e52e507ba989c18,w104h74.jpg"/><br/> Duża sieć dilerów narkotyków rozbita przez policję w Duesseldorfie, na zachodzie Niemiec. Podczas rutynowej kontroli w jednej z pizzerii na starym mieście okazało się, że w lokalu sprzedawano n-------i przy użyciu nietypowej metody: do zamówionej pizzy nr 40 dołączano małą paczkę k-----y 

