# Source:Newsweek, URL:https://www.newsweek.com/rss, language:en-US

## Global Conflict 'Approaching Very Rapidly,' NATO Ally Warns
 - [https://www.newsweek.com/north-korea-troops-russia-ukraine-south-korea-boris-pistorius-germany-john-healey-1973540](https://www.newsweek.com/north-korea-troops-russia-ukraine-south-korea-boris-pistorius-germany-john-healey-1973540)
 - RSS feed: $source
 - date published: 2024-10-23T10:32:16+00:00

It remains "to be seen" what North Korean troops will do in Russia, U.S. Defense Secretary Lloyd Austin said on Wednesday.

## James Carville 'Certain' Kamala Harris Wins Election
 - [https://www.newsweek.com/james-carville-kamala-harris-election-1973599](https://www.newsweek.com/james-carville-kamala-harris-election-1973599)
 - RSS feed: $source
 - date published: 2024-10-23T10:28:32+00:00

The famous political consultant identified three reasons he believes the VP will triumph.

## Woody Harrelson Speaks Out on Motorcycle Accident—'Very Lucky'
 - [https://www.newsweek.com/woody-harrelson-speaks-out-motorcycle-accident-very-lucky-1973582](https://www.newsweek.com/woody-harrelson-speaks-out-motorcycle-accident-very-lucky-1973582)
 - RSS feed: $source
 - date published: 2024-10-23T10:24:16+00:00

Woody Harrelson opened up about his June motorbike accident during an episode of the "Where Everybody Knows Your Name" podcast.

## Russians Fume as Whole Platoon Accused of War Crimes Wiped Out in Kursk
 - [https://www.newsweek.com/russians-fume-platoon-accused-war-crimes-wiped-out-kursk-1973549](https://www.newsweek.com/russians-fume-platoon-accused-war-crimes-wiped-out-kursk-1973549)
 - RSS feed: $source
 - date published: 2024-10-23T10:16:03+00:00

"They all gave their lives for you and me, my husband, who is in the lower left corner, among others," a woman wrote next to a social-media image.

## Democrat Ahead in Alabama District Dominated by GOP Since 1965
 - [https://www.newsweek.com/democrat-ahead-alabama-district-dominated-gop-since-1965-1973557](https://www.newsweek.com/democrat-ahead-alabama-district-dominated-gop-since-1965-1973557)
 - RSS feed: $source
 - date published: 2024-10-23T10:13:20+00:00

Alabama's 2nd congressional district was redrawn last year to increase its Black population by order of the Supreme Court.

## Facts Show Menendez Brothers Are 'Stone Cold Killers': Ex-LA Times Reporter
 - [https://www.newsweek.com/menendez-brothers-erik-lyle-alan-abrahamson-la-times-reporter-1973154](https://www.newsweek.com/menendez-brothers-erik-lyle-alan-abrahamson-la-times-reporter-1973154)
 - RSS feed: $source
 - date published: 2024-10-23T10:11:44+00:00

Former LA Times reporter Alan Abrahamson, who covered the Menendez brothers' trials, calls them "stone cold killers," urging focus on facts.

## NBA Player Props: 3 NBA Player Props for Wednesday (October 23)
 - [https://www.newsweek.com/nba-player-prop-picks-today-wednesday-october-23-1973511](https://www.newsweek.com/nba-player-prop-picks-today-wednesday-october-23-1973511)
 - RSS feed: $source
 - date published: 2024-10-23T10:03:40+00:00

Newsweek's NBA betting expert provides the best NBA player prop picks & predictions for Wednesday, October 23.

## Soup Recalled Over Potential Larvae Infestation
 - [https://www.newsweek.com/soup-recalled-over-potential-larvae-infestation-1973539](https://www.newsweek.com/soup-recalled-over-potential-larvae-infestation-1973539)
 - RSS feed: $source
 - date published: 2024-10-23T10:03:20+00:00

Tubs of Hungarian mushroom soup are being recalled by Puget Consumers Co-op due to concerns they make contain larvae.

## Dogsitter Hears Strange Noise, Finds Labrador Performing 'Masterpiece'
 - [https://www.newsweek.com/dogsitter-hears-strange-noise-finds-labrador-performing-masterpiece-1973563](https://www.newsweek.com/dogsitter-hears-strange-noise-finds-labrador-performing-masterpiece-1973563)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:58+00:00

Kirsty told Newsweek: "His father used to do the same, so as a pup he was brought up around the piano and his dad howling to the music."

## Prince Harry Above Major Heartthrobs in 'Hottest' List
 - [https://www.newsweek.com/prince-harry-above-ryan-gosling-david-beckham-hottest-list-1973508](https://www.newsweek.com/prince-harry-above-ryan-gosling-david-beckham-hottest-list-1973508)
 - RSS feed: $source
 - date published: 2024-10-23T09:58:36+00:00

Prince Harry was ranked the 25th hottest man of all time by a magazine, beating Ryan Gosling, Channing Tatum and other sex symbols.

## OnlyFans Creators Provide Hurricane Relief for North Carolina Community
 - [https://www.newsweek.com/alana-cho-onlyfans-creators-provide-hurricane-helene-relief-north-carolina-asheville-1972751](https://www.newsweek.com/alana-cho-onlyfans-creators-provide-hurricane-helene-relief-north-carolina-asheville-1972751)
 - RSS feed: $source
 - date published: 2024-10-23T09:56:31+00:00

Three women used "OnlyFans money" to provide food, generators and laptops for people in Ashville, North Carolina, still recovering from Hurricane Helene.

## Golden Retriever Sees Reflection While on Walk, His Reaction Melts Hearts
 - [https://www.newsweek.com/golden-retriever-mirror-reflection-walk-reaction-1973469](https://www.newsweek.com/golden-retriever-mirror-reflection-walk-reaction-1973469)
 - RSS feed: $source
 - date published: 2024-10-23T09:53:34+00:00

The hilarious TikTok video has racked up over 930,000 views in less than 24 hours.

## Tears at Moment Shelter Workers Save 'Lost and Broken' Dog Fighting Victim
 - [https://www.newsweek.com/tears-shelter-workers-save-dog-fighting-victim-1973391](https://www.newsweek.com/tears-shelter-workers-save-dog-fighting-victim-1973391)
 - RSS feed: $source
 - date published: 2024-10-23T09:52:29+00:00

Trooper was found with fresh wounds and older ones which had healed, suggesting he was used as a bait dog for quite a while.

## Donald Trump Is NOT Adolf Hitler | Opinion
 - [https://www.newsweek.com/donald-trump-not-adolph-hitler-opinion-1973600](https://www.newsweek.com/donald-trump-not-adolph-hitler-opinion-1973600)
 - RSS feed: $source
 - date published: 2024-10-23T09:51:08+00:00

As we close in on Nov. 5 and Judgment Day for American democracy, the specter of Benito Mussolini's seizure of power in Italy a century ago has been keeping me up at night.

## Woman Saves Begging Stray Dog, Vows To Give Her Only 'Love and Happiness'
 - [https://www.newsweek.com/woman-saves-begging-stray-gives-love-happiness-1973516](https://www.newsweek.com/woman-saves-begging-stray-gives-love-happiness-1973516)
 - RSS feed: $source
 - date published: 2024-10-23T09:46:05+00:00

A German shepherd stray was scrounging for food in a car park, but Joanna Quin said she "couldn't leave her there" and took the dog home.

## 'BRICS Still Don't Matter' Says 'Godfather' of Putin-Led Alliance
 - [https://www.newsweek.com/brics-godfather-says-alliance-doesnt-matter-1973425](https://www.newsweek.com/brics-godfather-says-alliance-doesnt-matter-1973425)
 - RSS feed: $source
 - date published: 2024-10-23T09:43:56+00:00

The man who coined "BRICS" says the group serves little purpose beyond symbolism, and that Putin's summit will mainly be used for "photo ops."

## Moment Cat Clings Onto Shed Roof 'The Lion King'-Style Caught on Camera
 - [https://www.newsweek.com/moment-cat-clings-shed-roof-lion-king-style-caught-camera-1971801](https://www.newsweek.com/moment-cat-clings-shed-roof-lion-king-style-caught-camera-1971801)
 - RSS feed: $source
 - date published: 2024-10-23T09:43:49+00:00

Paul, who filmed the incident, said he "felt a bit sorry" for the cat: "It looked a bit embarrassed, especially when it looked at the camera."

## AMBER Alert Update: Missing Arkansas Teens Found
 - [https://www.newsweek.com/amber-alert-arkansas-trixie-studer-sam-smith-1973577](https://www.newsweek.com/amber-alert-arkansas-trixie-studer-sam-smith-1973577)
 - RSS feed: $source
 - date published: 2024-10-23T09:41:16+00:00

An AMBER Alert was canceled after two teenagers who went missing in Arkansas were found safe.

## China Sails Aircraft Carrier Through Contested West Pacific Waters
 - [https://www.newsweek.com/china-news-sails-aircraft-carrier-through-contested-west-pacific-waters-taiwan-strait-1973394](https://www.newsweek.com/china-news-sails-aircraft-carrier-through-contested-west-pacific-waters-taiwan-strait-1973394)
 - RSS feed: $source
 - date published: 2024-10-23T09:38:03+00:00

CNS Liaoning, China's first operational aircraft carrier, transited the Taiwan Strait.

## AMBER Alert Issued: Missing New Mexico 5-Year-Old 'Is In Danger'
 - [https://www.newsweek.com/amber-alert-kaelani-gonzales-new-mexico-albuquerque-1973587](https://www.newsweek.com/amber-alert-kaelani-gonzales-new-mexico-albuquerque-1973587)
 - RSS feed: $source
 - date published: 2024-10-23T09:35:59+00:00

Kaelani Gonzales, 5, was last seen Monday leaving Kirtland Elementary School in New Mexico with her grandmother Marianne Garnand, 53.

## Gen Z Server Training Teen New Hire Leaves Internet in Stitches
 - [https://www.newsweek.com/gen-z-server-training-teen-new-hire-1973506](https://www.newsweek.com/gen-z-server-training-teen-new-hire-1973506)
 - RSS feed: $source
 - date published: 2024-10-23T09:25:50+00:00

"The blind leading the blind," posted one commenter on the clip that has more than 1.2 million views.

## Boeing Faces $6 Billion Loss as Striking Workers' Vote Looms
 - [https://www.newsweek.com/boeing-strike-vote-losses-ceo-earnings-report-1973498](https://www.newsweek.com/boeing-strike-vote-losses-ceo-earnings-report-1973498)
 - RSS feed: $source
 - date published: 2024-10-23T09:19:07+00:00

Boeing announced a potential $6 billion loss and plans to lay off 17,000 workers while grappling with an ongoing strike that has halted important production.

## Woman Adopts Dog She Met in Bali and Flies Her Across the World to Reunite
 - [https://www.newsweek.com/woman-adopts-dog-met-bali-flies-across-world-1972729](https://www.newsweek.com/woman-adopts-dog-met-bali-flies-across-world-1972729)
 - RSS feed: $source
 - date published: 2024-10-23T09:17:22+00:00

Karin Poravne feared Bella would end up on the streets, so she spent months having the pup flown to her forever home in Europe.

## Woman Singing at Best Friend's Wedding Goes Viral: 'Disney Princess'
 - [https://www.newsweek.com/woman-singing-best-friend-wedding-viral-1972962](https://www.newsweek.com/woman-singing-best-friend-wedding-viral-1972962)
 - RSS feed: $source
 - date published: 2024-10-23T09:07:16+00:00

Parisalexa's take on Etta James' classic has been viewed millions of times, introducing her sound to new listeners.

## Cocker Spaniel Puppy Learning To Make Friends at Day Care Melts Hearts
 - [https://www.newsweek.com/cocker-spaniel-puppy-learning-friends-day-care-1973533](https://www.newsweek.com/cocker-spaniel-puppy-learning-friends-day-care-1973533)
 - RSS feed: $source
 - date published: 2024-10-23T09:03:36+00:00

"Cocker spaniel pups really are the cutest," one viewer said. Another added: "I'm literally about to cry."

## Husky Who Has Decided To Be 'Kitten's Mom' Melts Hearts
 - [https://www.newsweek.com/husky-decided-kitten-mom-melts-hearts-1973553](https://www.newsweek.com/husky-decided-kitten-mom-melts-hearts-1973553)
 - RSS feed: $source
 - date published: 2024-10-23T09:02:16+00:00

Social-media users adored the husky's behavior in the viral clip, with one saying, "we love a protective mom."

## Donald Trump's Anger at UK's PM: What We Know
 - [https://www.newsweek.com/donald-trumps-anger-uks-pm-what-we-know-1973417](https://www.newsweek.com/donald-trumps-anger-uks-pm-what-we-know-1973417)
 - RSS feed: $source
 - date published: 2024-10-23T08:57:43+00:00

Donald Trump is angry at the UK PM for a Linkin post reported to have been made by a Labour Party official to assist volunteers to join Harris' campaign.

## Who is Hailey Davidson? Female Golfers Demand Transgender Player Be Removed
 - [https://www.newsweek.com/hailey-davidson-transgender-golf-star-faces-calls-removed-1973410](https://www.newsweek.com/hailey-davidson-transgender-golf-star-faces-calls-removed-1973410)
 - RSS feed: $source
 - date published: 2024-10-23T08:53:51+00:00

Hailey Davidson is one of the first openly transgender women to compete in high-level women's golf tournaments in the U.S.

## UCLA Sued Over Gaza Protest Arrests
 - [https://www.newsweek.com/ucla-sued-gaza-protest-arrest-1973546](https://www.newsweek.com/ucla-sued-gaza-protest-arrest-1973546)
 - RSS feed: $source
 - date published: 2024-10-23T08:50:50+00:00

The Universityhas been sued by two professors and two graduate students who took part in protests relating to the war in Gaza.

## Woman in Labor Asks Husband To Perform Interpretive Dance, He Delivers
 - [https://www.newsweek.com/woman-labor-asks-husband-perform-interpretive-dance-1973499](https://www.newsweek.com/woman-labor-asks-husband-perform-interpretive-dance-1973499)
 - RSS feed: $source
 - date published: 2024-10-23T08:50:49+00:00

Grayson Bearden appeared to be the perfect candidate and was applauded online.

## How Early Voting Breaks Down After First 20 Million Votes
 - [https://www.newsweek.com/early-voting-2024-election-polls-1973504](https://www.newsweek.com/early-voting-2024-election-polls-1973504)
 - RSS feed: $source
 - date published: 2024-10-23T08:45:09+00:00

Last week, officials said the record for early voting turnout was being broken in swing states such as Georgia and North Carolina.

## Dog Medicine Recall Update As FDA Sets Risk Class
 - [https://www.newsweek.com/dog-ear-medication-recalled-fda-class-ii-recall-1973464](https://www.newsweek.com/dog-ear-medication-recalled-fda-class-ii-recall-1973464)
 - RSS feed: $source
 - date published: 2024-10-23T08:29:43+00:00

A class II risk level is given to products that "may cause temporary or medically reversible adverse health consequences."

## Do Women Pilots Crash More Than Men? What the Data Shows
 - [https://www.newsweek.com/do-women-pilots-crash-more-men-1973481](https://www.newsweek.com/do-women-pilots-crash-more-men-1973481)
 - RSS feed: $source
 - date published: 2024-10-23T08:23:55+00:00

The relationship between pilot gender and aircraft safety is shaped by various factors and is more nuanced than it may seem.

## Owner Checks on Dog on Petcam—Can't Believe What She's Guarding
 - [https://www.newsweek.com/owner-checks-dog-petcam-cant-believe-what-guarding-1973471](https://www.newsweek.com/owner-checks-dog-petcam-cant-believe-what-guarding-1973471)
 - RSS feed: $source
 - date published: 2024-10-23T08:22:16+00:00

"I think she's safe from any intruders," the poster wrote, adding that it might be "the scariest thing she has taken so far …"

## CNN Anchor Apologizes For Reading Alleged Trump Quote On Air
 - [https://www.newsweek.com/cnn-erin-burnett-apologize-expletive-trump-1973385](https://www.newsweek.com/cnn-erin-burnett-apologize-expletive-trump-1973385)
 - RSS feed: $source
 - date published: 2024-10-23T08:06:44+00:00

CNN's Erin Burnett used an expletive live on air when covering reports of comments Donald Trump made in 2020 about a dead soldier's funeral.

## UK Rejects Trump's Campaign 'Interference' Claim: Happens Every Election
 - [https://www.newsweek.com/uk-rejects-trump-campaing-interference-claims-2024-election-1973461](https://www.newsweek.com/uk-rejects-trump-campaing-interference-claims-2024-election-1973461)
 - RSS feed: $source
 - date published: 2024-10-23T08:02:05+00:00

Trump's campaign cited America's revolution, misspelled "Britian," in a complaint claiming election "interference," against the UK's Labour party.

## Man Accused of Threatening Election Officials Expected to Plead Guilty
 - [https://www.newsweek.com/colorado-man-accused-threatening-election-officials-expected-plead-guilty-1973445](https://www.newsweek.com/colorado-man-accused-threatening-election-officials-expected-plead-guilty-1973445)
 - RSS feed: $source
 - date published: 2024-10-23T07:57:27+00:00

Teak Ty Brockbank, 45, of Cortez, Colorado, has been in jail since his arrest on Aug. 23 and is now expected to plead guilty.

## Catastrophic Floods Leave People Trapped on Rooftops
 - [https://www.newsweek.com/philippines-tropical-storm-trami-flooding-rescue-asia-1973453](https://www.newsweek.com/philippines-tropical-storm-trami-flooding-rescue-asia-1973453)
 - RSS feed: $source
 - date published: 2024-10-23T07:53:23+00:00

Widespread floods across the Philippines inundate cities and towns as Tropical Storm Trami strikes.

## Juice Drinks Recall Update as FDA Sets Risk Level
 - [https://www.newsweek.com/fda-recall-juice-products-youngstown-grape-distributors-1973485](https://www.newsweek.com/fda-recall-juice-products-youngstown-grape-distributors-1973485)
 - RSS feed: $source
 - date published: 2024-10-23T07:52:17+00:00

Several juice products "did not complete the High Pressure Processing treatment."

## North Korea Mobilizes Soldiers Near Border As Tensions Flare
 - [https://www.newsweek.com/north-korea-mobilizes-soldiers-near-border-1973366](https://www.newsweek.com/north-korea-mobilizes-soldiers-near-border-1973366)
 - RSS feed: $source
 - date published: 2024-10-23T07:44:23+00:00

The new defenses, including mines, follow last week's detonation of road and rail links with the South.

## Aileen Cannon Being Considered as Donald Trump's AG Sparks Fury: 'Insane'
 - [https://www.newsweek.com/donald-trump-aileen-cannon-attorney-general-mar-lago-florida-classified-documents-1973456](https://www.newsweek.com/donald-trump-aileen-cannon-attorney-general-mar-lago-florida-classified-documents-1973456)
 - RSS feed: $source
 - date published: 2024-10-23T07:42:47+00:00

Judge Aileen Cannon dismissed all charges against former President Donald Trump in his federal classified documents case.

## Rudy Giuliani Apartment Transfer Is 'Very Strange'—Legal Analyst
 - [https://www.newsweek.com/rudy-giuliani-donald-trump-2020-election-georgia-election-workers-apartment-manhattan-1973502](https://www.newsweek.com/rudy-giuliani-donald-trump-2020-election-georgia-election-workers-apartment-manhattan-1973502)
 - RSS feed: $source
 - date published: 2024-10-23T07:40:48+00:00

Giuliani has one week to transfer his $6 million Manhattan home to two election workers whom he defamed.

## Construction Underway at $500 Million Missouri Theme Park
 - [https://www.newsweek.com/construction-underway-500-million-missouri-theme-park-silver-dollar-city-1973483](https://www.newsweek.com/construction-underway-500-million-missouri-theme-park-silver-dollar-city-1973483)
 - RSS feed: $source
 - date published: 2024-10-23T07:36:04+00:00

Part of a decade-long plan representing half a billion dollars, the resort is billed as the first theme park resort in America's Heartland.

## Russia Deploying Strategic Nuclear Forces as Regular Infantry in Ukraine
 - [https://www.newsweek.com/russia-deploying-strategic-nuclear-forces-ukraine-1973398](https://www.newsweek.com/russia-deploying-strategic-nuclear-forces-ukraine-1973398)
 - RSS feed: $source
 - date published: 2024-10-23T07:22:55+00:00

Soldiers in a unit specializing in the operation of nuclear weaponry were deployed to Ukraine as Moscow faces dwindling troops.

## Kim Jong Un Issues Nuclear Warning To US as North Korea Grows Arsenal
 - [https://www.newsweek.com/kim-jong-un-nuclear-threat-north-korea-us-1973411](https://www.newsweek.com/kim-jong-un-nuclear-threat-north-korea-us-1973411)
 - RSS feed: $source
 - date published: 2024-10-23T07:09:59+00:00

North Korean leader has called America's nuclear weapons an "ever-increasing threat."

## Israel Evacuation Order to Lebanese City of Tyre: 'Immediately Move'
 - [https://www.newsweek.com/israel-issues-evacuation-order-lebanese-city-tyre-1973414](https://www.newsweek.com/israel-issues-evacuation-order-lebanese-city-tyre-1973414)
 - RSS feed: $source
 - date published: 2024-10-23T07:00:43+00:00

"Hezbollah's activity forces the IDF to act in the area you are in. The IDF does not want to harm you," the Israel Defense Forces (IDF) wrote on X.

## Did Donald Trump Praise Hitler? What We Know
 - [https://www.newsweek.com/did-donald-trump-praise-hitler-what-we-know-1973401](https://www.newsweek.com/did-donald-trump-praise-hitler-what-we-know-1973401)
 - RSS feed: $source
 - date published: 2024-10-23T06:55:35+00:00

Former White House chief of staff John Kelly said Trump expressed admiration for the loyalty shown by Adolf Hitler's generals.

## Famous Falcon Flies Again After Broken Wing Surgery
 - [https://www.newsweek.com/famous-falcon-flies-again-after-broken-wing-surgery-1972877](https://www.newsweek.com/famous-falcon-flies-again-after-broken-wing-surgery-1972877)
 - RSS feed: $source
 - date published: 2024-10-23T06:52:35+00:00

Equinox's injury would have led to him being euthanized in the past but technology made it possible to treat the "tiny little bones."

## Plane Passenger Orders In-Flight Meal, Can't Cope With What She's Served
 - [https://www.newsweek.com/passenger-orders-flight-meal-cant-cope-served-1972085](https://www.newsweek.com/passenger-orders-flight-meal-cant-cope-served-1972085)
 - RSS feed: $source
 - date published: 2024-10-23T06:44:37+00:00

A passenger decided to try the food available on her five-hour flight and quickly regretted it after it arrived.

## How to Watch Kamala Harris' Pennsylvania CNN Town Hall Tonight
 - [https://www.newsweek.com/how-watch-kamala-harris-cnn-town-hall-2024-election-1973408](https://www.newsweek.com/how-watch-kamala-harris-cnn-town-hall-2024-election-1973408)
 - RSS feed: $source
 - date published: 2024-10-23T06:36:05+00:00

With the election less than two weeks away, Harris is scheduled to participate in a CNN town hall hosted in the key swing state.

## US Confirms North Korean Troops Are in Russia: 'Very Serious'
 - [https://www.newsweek.com/north-korean-troops-are-russia-us-defense-secretary-confirms-1973468](https://www.newsweek.com/north-korean-troops-are-russia-us-defense-secretary-confirms-1973468)
 - RSS feed: $source
 - date published: 2024-10-23T06:25:02+00:00

Lloyd Austin has confirmed that North Korean troops have been moved to Russia.

## Gisèle Pelicot Takes Stand at French Mass Rape Trial, Addresses Ex-Husband
 - [https://www.newsweek.com/gisele-pelicot-takes-stand-french-mass-rape-trial-addresses-ex-husband-1973466](https://www.newsweek.com/gisele-pelicot-takes-stand-french-mass-rape-trial-addresses-ex-husband-1973466)
 - RSS feed: $source
 - date published: 2024-10-23T06:24:35+00:00

Grandmother Gisele Pelicot takes the stand in mass rape trial of her ex-husband in France with a message to other rape survivors.

## Zelensky Reveals First Step to Ending Russia-Ukraine War
 - [https://www.newsweek.com/ukraine-energy-targets-zelensky-russia-war-end-1973404](https://www.newsweek.com/ukraine-energy-targets-zelensky-russia-war-end-1973404)
 - RSS feed: $source
 - date published: 2024-10-23T06:23:26+00:00

The Ukrainian president told journalists that Russian attacks on energy targets in his country must stop.

## Trump's Chances of Winning New Jersey as He Says 'We Are Making a Move'
 - [https://www.newsweek.com/trump-chances-winning-new-jersey-he-making-move-1973407](https://www.newsweek.com/trump-chances-winning-new-jersey-he-making-move-1973407)
 - RSS feed: $source
 - date published: 2024-10-23T06:19:50+00:00

The Republican presidential candidate makes bold declaration of intent as he targets the deep-blue Garden State.

## 'Introvert' Cat Is Taken Out of His Home for One Hour—His Response Delights
 - [https://www.newsweek.com/cat-taken-out-home-one-hour-tiktok-1973427](https://www.newsweek.com/cat-taken-out-home-one-hour-tiktok-1973427)
 - RSS feed: $source
 - date published: 2024-10-23T06:11:07+00:00

"This is me when my social battery is gone," related one TikTok user.

## South Korean Intel Reveals Date Kim's Soldiers Will Join Putin's War
 - [https://www.newsweek.com/south-korean-intel-reveals-date-kim-soldiers-join-putin-war-1973377](https://www.newsweek.com/south-korean-intel-reveals-date-kim-soldiers-join-putin-war-1973377)
 - RSS feed: $source
 - date published: 2024-10-23T06:02:47+00:00

South Korean intel published by the country's news agency Yonyap reveals when Kim's soldiers will join Putin's war.

## Volvo Relying on 'Relentless' Data and Engineering to Make Cars Safe
 - [https://www.newsweek.com/volvo-relying-relentless-data-engineering-make-cars-safe-1969945](https://www.newsweek.com/volvo-relying-relentless-data-engineering-make-cars-safe-1969945)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:01+00:00

Volvo's new technology suite combines 90 years of safety into one modular on-board, self-learning computer.

## Digital Economy: Insights from the Real World
 - [https://www.newsweek.com/digital-economy-insights-real-world-1973437](https://www.newsweek.com/digital-economy-insights-real-world-1973437)
 - RSS feed: $source
 - date published: 2024-10-23T05:47:25+00:00

Digital Economy: Insights from the Real World

## McDonald's Shares Plunge Amid E.coli Outbreak
 - [https://www.newsweek.com/mcdonalds-shares-plunge-e-coli-outbreak-1973393](https://www.newsweek.com/mcdonalds-shares-plunge-e-coli-outbreak-1973393)
 - RSS feed: $source
 - date published: 2024-10-23T05:39:36+00:00

Numerous illnesses have been reported in several states, the CDC has said.

## Tim Walz Has a New Nickname for Elon Musk
 - [https://www.newsweek.com/tim-walz-elon-musk-new-nickname-1973382](https://www.newsweek.com/tim-walz-elon-musk-new-nickname-1973382)
 - RSS feed: $source
 - date published: 2024-10-23T05:36:31+00:00

Speaking at a rally in Madison, Wisconsin, the Democratic vice presidential nominee called SpaceX CEO Elon Musk a "dips**t."

## Donald Trump Overtakes Kamala Harris in Four National Polls
 - [https://www.newsweek.com/kamala-harris-donald-trump-national-polls-1973373](https://www.newsweek.com/kamala-harris-donald-trump-national-polls-1973373)
 - RSS feed: $source
 - date published: 2024-10-23T05:36:13+00:00

Polling aggregators have shifted in favor of Trump in recent days, showing that he now has a greater chance than Harris of winning the election.

## Mom Tries to Say Nightly Prayers, Toddler Takes It 'Off the Rails'
 - [https://www.newsweek.com/mom-tries-say-nightly-prayers-toddler-takes-it-off-rails-1973073](https://www.newsweek.com/mom-tries-say-nightly-prayers-toddler-takes-it-off-rails-1973073)
 - RSS feed: $source
 - date published: 2024-10-23T05:35:49+00:00

Jalen Rose told Newsweek she tried to get her 23-month-old daughter back on track, but she was somewhat distracted.

## Fuel Truck Overturns and Explodes, Leaving 11 Dead
 - [https://www.newsweek.com/fuel-truck-explosion-kills-11-uganda-1973374](https://www.newsweek.com/fuel-truck-explosion-kills-11-uganda-1973374)
 - RSS feed: $source
 - date published: 2024-10-23T05:29:08+00:00

The truck overturned after an accident and later exploded in a town just outside of the Ugandan capital, Kampala.

## A Fight Among China Hawks Could Imperil U.S. AI Dominance | Opinion
 - [https://www.newsweek.com/fight-among-china-hawks-could-imperil-us-ai-dominance-opinion-1973287](https://www.newsweek.com/fight-among-china-hawks-could-imperil-us-ai-dominance-opinion-1973287)
 - RSS feed: $source
 - date published: 2024-10-23T05:27:01+00:00

Potential restrictions reflect a deep ambivalence within the Biden administration on export of AI technology and the $1.5 billion G42 deal specifically.

## Nobody Wants to Vote in Favor of Climate Change—Right? | Opinion
 - [https://www.newsweek.com/nobody-wants-vote-favor-climate-changeright-opinion-1973156](https://www.newsweek.com/nobody-wants-vote-favor-climate-changeright-opinion-1973156)
 - RSS feed: $source
 - date published: 2024-10-23T05:27:01+00:00

The climate crisis isn't coming. It is here now. Look all around us. Devastating back-to-back hurricanes in Florida and the Southeast. Massive wildfires out West.

## Melania Trump's Mom's Papers Released in Prince Harry Case
 - [https://www.newsweek.com/melania-trump-mom-amalija-knavs-papers-released-prince-harry-visa-1973400](https://www.newsweek.com/melania-trump-mom-amalija-knavs-papers-released-prince-harry-visa-1973400)
 - RSS feed: $source
 - date published: 2024-10-23T05:08:41+00:00

Records for Donald Trump's mother-in-law were released by a conservative think tank via a lawsuit over Prince Harry's visa.

## Russian Submarine, Warships Converge on Indian Ocean
 - [https://www.newsweek.com/russia-submarine-warships-converge-indian-ocean-1973357](https://www.newsweek.com/russia-submarine-warships-converge-indian-ocean-1973357)
 - RSS feed: $source
 - date published: 2024-10-23T05:08:23+00:00

The Russian submarine can fire Kalibr cruise missiles, which have seen extensive use in strikes against Ukraine.

## Country Star Jordan Davis Clarifies 'Bachelorette' Hannah Brown Controversy
 - [https://www.newsweek.com/jordan-davis-bachelorette-hannah-brown-instagram-1973361](https://www.newsweek.com/jordan-davis-bachelorette-hannah-brown-instagram-1973361)
 - RSS feed: $source
 - date published: 2024-10-23T05:01:59+00:00

The father-of-three told podcaster Kaitlyn Bristowe that his naivety caught up to him on social media as he was only trying to promote the pair's collaboration.

## Ukraine Gets $3B From Putin's Funds Held by NATO Ally
 - [https://www.newsweek.com/ukraine-loan-uk-putin-russian-assets-sanctions-1972827](https://www.newsweek.com/ukraine-loan-uk-putin-russian-assets-sanctions-1972827)
 - RSS feed: $source
 - date published: 2024-10-23T05:01:48+00:00

The $3 billion U.K. loan for military resources will be paid for by the profits generated from frozen Russian assets.

## America's Shifting Opinions on 2024 Election Issues
 - [https://www.newsweek.com/2024/11/01/americas-shifting-opinions-2024-election-issues-1972784.html](https://www.newsweek.com/2024/11/01/americas-shifting-opinions-2024-election-issues-1972784.html)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:02+00:00

Exclusive polling for Newsweek on key issues highlights where presidential candidates Donald Trump and Kamala Harris need to win votes to succeed to the White House

## Nutritionist Reveals Vegetables That May Give Your Skin a Golden Glow
 - [https://www.newsweek.com/nutritionist-reveals-vegetables-may-give-skin-golden-glow-1973046](https://www.newsweek.com/nutritionist-reveals-vegetables-may-give-skin-golden-glow-1973046)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:02+00:00

Videos have been circulating on social media describing the benefits of these foods for healthy, glowing, tanned skin.

## Tony Blair: US Should Make Sure Iran Never Gets Nuclear Weapons
 - [https://www.newsweek.com/tony-blair-middle-east-israel-iran-leadership-1972118](https://www.newsweek.com/tony-blair-middle-east-israel-iran-leadership-1972118)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:01+00:00

Former British Prime Minister Sir Tony Blair talks exclusively to Newsweek about resolution in the Middle East.

## 'Yellowstone' Star Luke Grimes: 'The Show Rolled With the Punches'
 - [https://www.newsweek.com/2024/11/01/yellowstone-star-luke-grimes-show-rolled-punches-1972740.html](https://www.newsweek.com/2024/11/01/yellowstone-star-luke-grimes-show-rolled-punches-1972740.html)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:01+00:00

The actor told Newsweek about the show concluding without main man Kevin Costner and life after playing Kayce Dutton for seven years.

## Prince Harry's Visa Drugs Headache Isn't Over Yet
 - [https://www.newsweek.com/prince-harry-visa-drugs-lawsuit-heritage-foundation-homeland-security-1973363](https://www.newsweek.com/prince-harry-visa-drugs-lawsuit-heritage-foundation-homeland-security-1973363)
 - RSS feed: $source
 - date published: 2024-10-23T04:38:40+00:00

Prince Harry's visa is back in the spotlight as the Heritage Foundation fights to overturn a ruling that it should be kept secret.

## Russian Pilots Leave Ominous Warning to Putin on Bomb Bound for Kursk
 - [https://www.newsweek.com/russia-putin-bomb-kursk-1973368](https://www.newsweek.com/russia-putin-bomb-kursk-1973368)
 - RSS feed: $source
 - date published: 2024-10-23T04:33:51+00:00

The personnel complained about not being paid what they were owed in a message on a glide bomb, an image on social media showed.

## Hysterics at Dog's Bizarre 'Upside Down' Method of Begging for Food
 - [https://www.newsweek.com/dog-upside-down-begging-1972710](https://www.newsweek.com/dog-upside-down-begging-1972710)
 - RSS feed: $source
 - date published: 2024-10-23T04:33:49+00:00

"Nobody trained him to do this (intentionally)," his owner told Newsweek.

## Vanessa Guillén's Sister Says She Voted for Trump, Dismisses Allegations
 - [https://www.newsweek.com/vanessa-guillen-sister-voted-trump-dismisses-allegations-1973386](https://www.newsweek.com/vanessa-guillen-sister-voted-trump-dismisses-allegations-1973386)
 - RSS feed: $source
 - date published: 2024-10-23T04:25:25+00:00

Mayra Guillén addressed a report that said Donald Trump complained while in office about the cost of the slain soldier's funeral.

## Ukraine Launches Major Black Sea Naval Drone Attack Toward Crimea
 - [https://www.newsweek.com/ukraine-black-sea-fleet-naval-drones-usv-crimea-1973371](https://www.newsweek.com/ukraine-black-sea-fleet-naval-drones-usv-crimea-1973371)
 - RSS feed: $source
 - date published: 2024-10-23T04:11:11+00:00

Kyiv has consistently targeted Russian assets around Crimea, including facilities belonging to Moscow's Black Sea Fleet.

## George Lopez Never Set Out to Be an Example, But He Became One
 - [https://www.newsweek.com/2024/11/01/george-lopez-never-set-out-example-he-became-one-1973092.html](https://www.newsweek.com/2024/11/01/george-lopez-never-set-out-example-he-became-one-1973092.html)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:03+00:00

"The one thing that has never left me is my sense of humor, or my ability to find humor in the most tragic or the most serious things," George Lopez tells Newsweek.

## US Submarine Earns Highest Military Honor for Spying on America's Enemies
 - [https://www.newsweek.com/us-submarine-earns-highest-military-honor-spying-america-enemies-1972838](https://www.newsweek.com/us-submarine-earns-highest-military-honor-spying-america-enemies-1972838)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:03+00:00

The USS Washington completed three demanding national security missions by obtaining sensitive and unique intelligence.

## What Millennials Secretly Get Up to While Working From Home
 - [https://www.newsweek.com/millennials-secretly-get-working-home-1972137](https://www.newsweek.com/millennials-secretly-get-working-home-1972137)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:02+00:00

Employees born between 1981 and 1996 are the most likely to admit doing something non-work related while clocked in according to a new survey.

## Michelle Obama Could Be Kamala Harris' Ultimate Weapon
 - [https://www.newsweek.com/michelle-obama-kamala-harris-weapon-1972089](https://www.newsweek.com/michelle-obama-kamala-harris-weapon-1972089)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:01+00:00

Obama, one of the Democratic Party's most popular figures, will hit the campaign trail for Harris for the first time.

## The US Election Will Likely Decide Ukraine's Fate. Here's What Voters Think
 - [https://www.newsweek.com/us-support-ukraine-voters-opinions-trump-1966902](https://www.newsweek.com/us-support-ukraine-voters-opinions-trump-1966902)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:01+00:00

Polling by Redfield and Wilton Strategies found that around one-third of U.S. voters backed continued support for Ukraine.

## Half of Retirees Considering Return To Work After COLA Update
 - [https://www.newsweek.com/retirees-consider-return-work-cola-update-social-security-1972890](https://www.newsweek.com/retirees-consider-return-work-cola-update-social-security-1972890)
 - RSS feed: $source
 - date published: 2024-10-23T03:52:16+00:00

Seniors feel like the 2.5 percent increase does not go far enough.

## Mark Cuban vs Elon Musk: Battle of the Billionaires on the Campaign Trail
 - [https://www.newsweek.com/mark-cuban-vs-elon-musk-battle-billionaires-campaign-trail-trump-harris-1972738](https://www.newsweek.com/mark-cuban-vs-elon-musk-battle-billionaires-campaign-trail-trump-harris-1972738)
 - RSS feed: $source
 - date published: 2024-10-23T03:00:01+00:00

While SpaceX CEO Musk is throwing millions into campaigning for former President Donald Trump, Dallas Mavericks owner Mark Cuban is backing VP Kamala Harris.

## Putin's North Korea Move Might Backfire—Here's Why
 - [https://www.newsweek.com/vladimir-putin-north-korea-south-troops-ukraine-1972939](https://www.newsweek.com/vladimir-putin-north-korea-south-troops-ukraine-1972939)
 - RSS feed: $source
 - date published: 2024-10-23T03:00:01+00:00

Seoul "will not stand by but respond firmly in collaboration with the international community," South Korea said.

## Putin Lacks Support As Only 14 Percent of Russians Back His Foreign Policy
 - [https://www.newsweek.com/russia-putin-ukraine-war-1972857](https://www.newsweek.com/russia-putin-ukraine-war-1972857)
 - RSS feed: $source
 - date published: 2024-10-23T02:30:01+00:00

Survey by independent pollster Chronicles found that 61 percent of Russians surveyed wanted negotiations to end war in Ukraine.

## Invisible Joe Biden Disappears From Kamala Harris' Campaign
 - [https://www.newsweek.com/invisible-joe-biden-disappears-kamala-harris-campaign-1973043](https://www.newsweek.com/invisible-joe-biden-disappears-kamala-harris-campaign-1973043)
 - RSS feed: $source
 - date published: 2024-10-23T02:00:01+00:00

The VP is distandicng herself from Joe Biden in the final weeks of the 2024 race, presenting herself as the change candidate.

## MLB News: Baseball World Reacts to News of Legendary Pitcher's Death
 - [https://www.newsweek.com/sports/mlb/mlb-news-baseball-world-reacts-news-legendary-pitchers-death-1973360](https://www.newsweek.com/sports/mlb/mlb-news-baseball-world-reacts-news-legendary-pitchers-death-1973360)
 - RSS feed: $source
 - date published: 2024-10-23T01:53:16+00:00

Tributes poured in from around the baseball community Tuesday in response to news of Fernando Valenzuela's death at age 63.

## Shohei Ohtani News: 50th Home Run Ball Sells For Record Price
 - [https://www.newsweek.com/sports/mlb/shohei-ohtani-news-50th-home-run-ball-sells-record-price-1973359](https://www.newsweek.com/sports/mlb/shohei-ohtani-news-50th-home-run-ball-sells-record-price-1973359)
 - RSS feed: $source
 - date published: 2024-10-23T01:06:31+00:00

The ball Shohei Ohtani hit for his 50th home run of 2024 has sold at auction for $4.392 million, which the auctioneer says is a record for a ball.

## Lakers Outlast Timberwolves in Historic NBA Season Opener
 - [https://www.newsweek.com/sports/nba/lakers-outlast-timberwolves-historic-nba-season-opener-1973341](https://www.newsweek.com/sports/nba/lakers-outlast-timberwolves-historic-nba-season-opener-1973341)
 - RSS feed: $source
 - date published: 2024-10-23T00:55:26+00:00

Los Angeles made a special kind of league history during their home clash with the mighty Minnesota Timberwolves.

## NYT 'Connections' October 23: Clues and Answers for Game #500
 - [https://www.newsweek.com/connections-new-york-times-october-23-answers-clues-hints-game-500-1972798](https://www.newsweek.com/connections-new-york-times-october-23-answers-clues-hints-game-500-1972798)
 - RSS feed: $source
 - date published: 2024-10-23T00:01:01+00:00

Wednesday's "Connections" categories share a particular theme for its 500-game milestone.

## Today's 'Wordle' #1,222 Clues, Hints and Answer for Wednesday, October 23
 - [https://www.newsweek.com/wordle-1222-clues-hints-answer-wednesday-october-23-1972811](https://www.newsweek.com/wordle-1222-clues-hints-answer-wednesday-october-23-1972811)
 - RSS feed: $source
 - date published: 2024-10-23T00:01:01+00:00

If you are finding Wednesday's "Wordle" difficult, Newsweek has provided some handy tips and clues that might help.

