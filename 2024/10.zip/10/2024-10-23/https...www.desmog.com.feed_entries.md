# Source:DeSmog, URL:https://www.desmog.com/feed, language:en-US

## ‘Terrifying’: Leak Shows Industry Plot to Worsen Methane Emissions — If Trump Wins
 - [https://www.desmog.com/2024/10/23/axpc-terrifying-leak-shows-industry-plot-to-worsen-methane-emissions-if-trump-wins](https://www.desmog.com/2024/10/23/axpc-terrifying-leak-shows-industry-plot-to-worsen-methane-emissions-if-trump-wins)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

<p>This article by Common Dreams is published here as part of the global journalism collaboration Covering Climate Now. A key oil and gas industry group has devised a plan to dismantle Biden-era climate regulations, including on methane emissions, according to an investigation published Friday in The Washington Post. The American Exploration and Production Council, a trade group of&#160;30&#160;oil and [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2024/10/23/axpc-terrifying-leak-shows-industry-plot-to-worsen-methane-emissions-if-trump-wins/" data-wpel-link="internal">&#8216;Terrifying&#8217;: Leak Shows Industry Plot to Worsen Methane Emissions — If Trump Wins</a> appeared first on <a href="https://www.desmog.com" data-wpel-link="internal">DeSmog</a>.</p>


## Big Ag Is Using  ‘Regenerative Agriculture’ to Mask Business-as-Usual
 - [https://www.desmog.com/2024/10/22/big-ag-is-using-regenerative-agriculture-to-mask-business-as-usual](https://www.desmog.com/2024/10/22/big-ag-is-using-regenerative-agriculture-to-mask-business-as-usual)
 - RSS feed: $source
 - date published: 2024-10-23T05:01:00+00:00

<p>During September’s Climate Week in New York City, the world&#8217;s major food companies lined up to share their pro-nature credentials, claiming that they are embracing “regenerative agriculture” practices that will reduce their massive carbon footprint.&#160; However, a new report finds that multinational food and ag companies – such as Cargill, Bayer and Unilever – which [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2024/10/22/big-ag-is-using-regenerative-agriculture-to-mask-business-as-usual/" data-wpel-link="internal">Big Ag Is Using  ‘Regenerative Agriculture’ to Mask Business-as-Usual</a> appeared first on <a href="https://www.desmog.com" data-wpel-link="internal">DeSmog</a>.</p>


