# Source:EonsOfBattle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDNHPNeWScAC8h8IxtEBtkQ, language:en

## Painting a Friend's Army in 8 Hours!
 - [https://www.youtube.com/watch?v=_QdrIPXx4LU](https://www.youtube.com/watch?v=_QdrIPXx4LU)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:41+00:00

https://eonsofbattle.com/
Check out our new website for our Merch, Terrain STLs and Memberships!  

Sean needs to get his army ready for an upcoming tournament and Jay and Nick are coming to the rescue! We have new videos every Monday, Wednesday and Friday!

Join as a Member to Get Terrain and Help Support the Show!
https://eonsofbattle.com/
T-Shirts, Dice and More Available!

Another place to buy our 3D Models and Terrain:
https://www.myminifactory.com/users/eonsofbattle

Discord Server:
https://discord.gg/ymhENeyFTP

EonsOfBattle Instagram:
https://www.instagram.com/eonsofbattle/

EonsOfBattle Facebook Page:
https://www.facebook.com/eobfans

EonsOfBattle Reddit:
http://www.reddit.com/r/eonsofbattle

Twitter:
https://twitter.com/EonsOfBattle

Assistant Editor:
Amanda B.

Intro Animation By: Liqerise
https://www.instagram.com/liqerise/  

#warhammer40k #miniatures #gamesworkshop

