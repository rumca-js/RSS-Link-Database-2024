# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Did THIS Man Just STEAL Military Power From Xi Jinping
 - [https://www.youtube.com/watch?v=QN9NGWU6sBg](https://www.youtube.com/watch?v=QN9NGWU6sBg)
 - RSS feed: $source
 - date published: 2024-10-23T01:00:36+00:00

It seems that Xi Jinping’s power is waning and he may have already lost control if the military. This man may have been the one who took it away from him.



Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

