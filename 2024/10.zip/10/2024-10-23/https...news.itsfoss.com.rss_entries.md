# Source:It's FOSS News, URL:https://news.itsfoss.com/rss, language:en-US

## Syncthing's Android App is Going Away, Google Play Store Policies is One of the Reasons to Blame
 - [https://news.itsfoss.com/syncthing-android-app-no-more](https://news.itsfoss.com/syncthing-android-app-no-more)
 - RSS feed: $source
 - date published: 2024-10-23T12:11:07+00:00

Syncthing Android app is retiring. While you do have alternatives, it is indeed sad news.

