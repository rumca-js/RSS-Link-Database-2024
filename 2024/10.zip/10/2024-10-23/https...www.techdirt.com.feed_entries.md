# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## No Longer Consumer Friendly: T-Mobile Fights FCC Phone Unlocking Effort
 - [https://www.techdirt.com/2024/10/23/no-longer-consumer-friendly-t-mobile-fights-fcc-phone-unlocking-effort](https://www.techdirt.com/2024/10/23/no-longer-consumer-friendly-t-mobile-fights-fcc-phone-unlocking-effort)
 - RSS feed: $source
 - date published: 2024-10-23T12:32:15+00:00

Back in July, the Biden FCC voted to make unlocking your phone easier. As a result, the agency is now crafting new rules that would require that wireless carriers unlock customers’ mobile phones within 60days of activation, even if you&#8217;re still under contract. Wireless giant T-Mobile, which used to have a consumer-friendly reputation until its [&#8230;]

## Federal Court Says Sheriff Violated Citizen Journalist’s Rights So Hard There’s No Need To Bring In A Jury
 - [https://www.techdirt.com/2024/10/22/federal-court-says-sheriff-violated-citizen-journalists-rights-so-hard-theres-no-need-to-bring-in-a-jury](https://www.techdirt.com/2024/10/22/federal-court-says-sheriff-violated-citizen-journalists-rights-so-hard-theres-no-need-to-bring-in-a-jury)
 - RSS feed: $source
 - date published: 2024-10-23T04:19:52+00:00

As they say, the wheels of justice grind slowly. The presumed upside is that they grind finely, which means every periodic iteration should produce better outcomes. And maybe that&#8217;s true in some cases. (Cases handled in the Fifth Circuit, not so much.) This one&#8217;s in the Fifth Circuit but at least hasn&#8217;t suffered the possible [&#8230;]

## FTC Investigating John Deere Over ‘Right To Repair’ Violations
 - [https://www.techdirt.com/2024/10/22/ftc-investigating-john-deere-over-right-to-repair-violations](https://www.techdirt.com/2024/10/22/ftc-investigating-john-deere-over-right-to-repair-violations)
 - RSS feed: $source
 - date published: 2024-10-23T00:12:52+00:00

A few years ago agricultural equipment giant John Deere found itself&#160;on the receiving end of an antitrust lawsuit&#160;for its efforts to monopolize tractor repair. The lawsuits noted that the company consistently purchased competing repair centers in order to consolidate the sector and force customers into using the company’s own repair facilities, driving up costs and [&#8230;]

