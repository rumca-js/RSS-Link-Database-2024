# Source:Science News, URL:https://www.sciencenews.org/feed, language:en-US

## Tech companies want small nuclear reactors. Here’s how they’d work 
 - [https://www.sciencenews.org/article/small-modular-nuclear-reactors-amazon](https://www.sciencenews.org/article/small-modular-nuclear-reactors-amazon)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:00+00:00

To fuel AI’s insatiable energy appetite, tech companies are going big on small nuclear reactors.

