# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Morning Nonsense: Terrible but Funny!
 - [https://www.youtube.com/watch?v=X7kgoi8HB_M](https://www.youtube.com/watch?v=X7kgoi8HB_M)
 - RSS feed: $source
 - date published: 2024-10-23T04:19:39+00:00

MAIN RULE: Please do NOT attack or insult other members of the chat with superchats.
Get the Embrace 2 here: https://www.indiegogo.com/projects/the-embrace-2/x/22169562#/

Get Dr. Alpha: 2nd Chance Campaign: https://www.indiegogo.com/projects/dr-alpha-miracle-child-2nd-chance/x/22169562#/

Dr. Alpha: Miracle Child on Amazon: https://www.amazon.com/dp/B0B7F95YF3

Rumble: https://rumble.com/c/c-2621304

MUSIC:
There You Are (POGO): https://www.youtube.com/watch?v=5tOAZkrkuVA
Surrender (First to Eleven): https://www.youtube.com/watch?v=nUk6ARY7dSg
Walk Like An Egyptian (Bangles): https://www.youtube.com/watch?v=tMnGmoLS6zo
Saturday Night's Alright for Fighting (Elton John): https://www.youtube.com/watch?v=26wEWSUUsUc
Smells Like Teen Spirit Major Key (Nirvana/Sleep Good): https://www.youtube.com/watch?v=dVehv_LDWaE
Surface Pressure JoJo Remix (Thai McGrath): https://www.youtube.com/watch?v=MVOrUkLOEOI
Segata Sanshiro: https://www.youtube.com/watch?v=POkU70cjYI8
Out to Lu

