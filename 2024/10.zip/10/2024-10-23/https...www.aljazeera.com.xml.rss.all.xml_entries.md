# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## How Republican-linked ads stir Israel tensions to undermine Kamala Harris
 - [https://www.aljazeera.com/news/2024/10/23/how-republican-linked-ads-stir-israel-tensions-to-undermine-kamala-harris?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/how-republican-linked-ads-stir-israel-tensions-to-undermine-kamala-harris?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:13:40+00:00

Ad campaign focused on Gaza in key swing states invokes &#039;anti-Semitic and anti-Arab&#039; bigotry, advocate says.

## Why has Trump accused the UK’s Labour Party of election interference?
 - [https://www.aljazeera.com/news/2024/10/23/why-has-trump-accused-the-uks-labour-party-of-election-interference?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/why-has-trump-accused-the-uks-labour-party-of-election-interference?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:12:08+00:00

The US Republican presidential candidate has filed a legal complaint against UK&#039;s governing party for meddling. 

## Why is Hungary’s Orban sending soldiers to Chad?
 - [https://www.aljazeera.com/news/2024/10/23/why-is-hungarys-orban-sending-soldiers-to-chad?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/why-is-hungarys-orban-sending-soldiers-to-chad?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:49:07+00:00

An unlikely friendship is budding between Budapest and N&#039;Djamena with the goal of stemming migration to Europe.

## ‘Dead and wounded’ in attack near Turkey’s Ankara, minister says
 - [https://www.aljazeera.com/news/2024/10/23/dead-and-wounded-in-attack-near-ankara-turkish-minister-says?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/dead-and-wounded-in-attack-near-ankara-turkish-minister-says?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:42:50+00:00

This is a breaking news story, more details to follow.

## US says ‘evidence’ North Korea has sent troops to Russia
 - [https://www.aljazeera.com/news/2024/10/23/us-says-evidence-north-korea-has-sent-troops-to-russia?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/us-says-evidence-north-korea-has-sent-troops-to-russia?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:07:04+00:00

Seoul&#039;s intelligence agency says double the number of soldiers previously stated sent to fight against Ukraine.

## Pro-Palestinian protesters in US rename historic university hall
 - [https://www.aljazeera.com/program/newsfeed/2024/10/23/pro-palestinian-protesters-in-us-rename-historic-university-hall?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/10/23/pro-palestinian-protesters-in-us-rename-historic-university-hall?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T12:56:26+00:00

Pro-Palestine protesters at the University of Minnesota were arrested after staging a sit-in inside a university hall.

## Video shows blindfolded Palestinians taken for interrogation
 - [https://www.aljazeera.com/program/newsfeed/2024/10/23/video-shows-blindfolded-palestinians-taken-for-interrogation?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/10/23/video-shows-blindfolded-palestinians-taken-for-interrogation?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T12:27:25+00:00

Dozens of blindfolded Palestinian men can be seen being taken away in Israeli military trucks.

## UK PM says ties with Trump ‘good’ after US election ‘interference’ claims
 - [https://www.aljazeera.com/news/2024/10/23/uk-pm-says-can-have-good-ties-with-trump-after-us-interference-claims?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/uk-pm-says-can-have-good-ties-with-trump-after-us-interference-claims?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T12:15:02+00:00

Keir Starmer bats away accusations that Labour volunteers backing Kamala Harris made ‘illegal&#039; foreign contributions.

## Risking my life to feed people displaced by Israel’s war on Lebanon
 - [https://www.aljazeera.com/program/al-jazeera-close-up/2024/10/23/risking-my-life-to-feed-people-displaced-by-israels-war-on-lebanon?traffic_source=rss](https://www.aljazeera.com/program/al-jazeera-close-up/2024/10/23/risking-my-life-to-feed-people-displaced-by-israels-war-on-lebanon?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:59:37+00:00

As Israel intensifies its bombardment of Lebanon, volunteers risk their lives to feed those displaced across the country

## Why are victims of a Brazil dam disaster suing miner BHP in a London court?
 - [https://www.aljazeera.com/news/2024/10/23/why-are-victims-of-a-brazil-dam-disaster-suing-miner-bhp-in-a-london-court?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/why-are-victims-of-a-brazil-dam-disaster-suing-miner-bhp-in-a-london-court?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:48:51+00:00

The mining giant faces a potential $47bn lawsuit filed by at least 600,000 people over the 2015 mining disaster.

## Why questions are being raised over the Greater Israel ideology?
 - [https://www.aljazeera.com/program/the-stream/2024/10/23/why-questions-are-being-raised-over-the-greater-israel-ideology?traffic_source=rss](https://www.aljazeera.com/program/the-stream/2024/10/23/why-questions-are-being-raised-over-the-greater-israel-ideology?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:09:32+00:00

We explore the rising influence of the &#039;Greater Israel&#039; ideology amid military tensions in Gaza and Lebanon.

## War and instability bring African governance progress to a halt: Report
 - [https://www.aljazeera.com/news/2024/10/23/progress-on-african-governance-halts-amidst-war-and-coups-report?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/progress-on-african-governance-halts-amidst-war-and-coups-report?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:09:28+00:00

Democratic backsliding in Africa reflects global trend towards ‘strongman politics’ emboldening autocrats.

## Gaza parents’ heartbreak as children’s clothes, shoes fall to pieces
 - [https://www.aljazeera.com/features/2024/10/23/gaza-parents-heartbreak-as-childrens-clothes-shoes-fall-to-pieces?traffic_source=rss](https://www.aljazeera.com/features/2024/10/23/gaza-parents-heartbreak-as-childrens-clothes-shoes-fall-to-pieces?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:55:49+00:00

Children are underdressed and exposed to the elements a year into Israel&#039;s war on Gaza.

## Will Biden administration prosecute Elon Musk for his $1m lottery?
 - [https://www.aljazeera.com/news/2024/10/23/will-biden-administration-prosecute-elon-musk-for-his-1m-lottery?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/will-biden-administration-prosecute-elon-musk-for-his-1m-lottery?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:55:27+00:00

Experts doubt that Musk will be prosecuted — even though he might be violating election laws.

## Trump, the EU and the appeal of Orbanocracy
 - [https://www.aljazeera.com/opinions/2024/10/23/trump-the-eu-and-the-appeal-of-orbanocracy?traffic_source=rss](https://www.aljazeera.com/opinions/2024/10/23/trump-the-eu-and-the-appeal-of-orbanocracy?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:54:42+00:00

What drives the popularity of Hungary&#039;s Viktor Orban is not his geopolitical game but his governance model.

## Trump vs Harris: Who’s leading in the US election polls as the vote looms?
 - [https://www.aljazeera.com/news/2024/10/23/trump-vs-harris-whos-leading-in-the-us-election-polls-as-the-vote-looms?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/trump-vs-harris-whos-leading-in-the-us-election-polls-as-the-vote-looms?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:48:23+00:00

We track the latest polls with less than two weeks to go before US voters choose a new president on November 5.

## Belarus president Lukashenko to seek seventh term in January vote
 - [https://www.aljazeera.com/news/2024/10/23/belarus-president-lukashenko-to-seek-seventh-term-in-january-vote?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/belarus-president-lukashenko-to-seek-seventh-term-in-january-vote?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:43:45+00:00

Opposition calls for non-recognition of vote set to extend Lukashenko’s 30-year rule.

## Video: Israeli forces attack Tyre in Lebanon and tell people to leave
 - [https://www.aljazeera.com/program/newsfeed/2024/10/23/video-israeli-forces-attack-tyre-in-lebanon-and-tell-people-to-leave?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/10/23/video-israeli-forces-attack-tyre-in-lebanon-and-tell-people-to-leave?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:17:57+00:00

Video shows smoke rising after a series of Israeli air attacks on the city of Tyre in Lebanon.

## Taxes and tractors in the US election
 - [https://www.aljazeera.com/program/money-works/2024/10/23/taxes-and-tractors-in-the-us-election?traffic_source=rss](https://www.aljazeera.com/program/money-works/2024/10/23/taxes-and-tractors-in-the-us-election?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:38:09+00:00

We look at how the two main candidates in the US election plan to change the US economic landscape.

## Vinicius is going to win the Ballon d’Or, says Real Madrid coach Ancelotti
 - [https://www.aljazeera.com/sports/2024/10/23/vinicius-is-going-to-win-the-ballon-dor-says-real-madrid-coach-ancelotti?traffic_source=rss](https://www.aljazeera.com/sports/2024/10/23/vinicius-is-going-to-win-the-ballon-dor-says-real-madrid-coach-ancelotti?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:26:10+00:00

The Brazilian forward scored a hat-trick in Real Madrid&#039;s 5-2 win over Borussia Dortmund in the Champions League.

## Sinaloa shootout: Mexico troops kill 19 suspected cartel members
 - [https://www.aljazeera.com/news/2024/10/23/sinaloa-shootout-mexico-troops-kill-19-suspected-cartel-members?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/sinaloa-shootout-mexico-troops-kill-19-suspected-cartel-members?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:23:16+00:00

Violence has surged in Sinaloa since the arrest in July of the cartel&#039;s co-founder Ismael Zambada, now on trial in US.

## Palestinians flee North Gaza amid Israeli bombardment
 - [https://www.aljazeera.com/gallery/2024/10/23/palestinians-flee-north-gaza-amid-israeli-bombardment?traffic_source=rss](https://www.aljazeera.com/gallery/2024/10/23/palestinians-flee-north-gaza-amid-israeli-bombardment?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:18:06+00:00

Israel has carried out numerous deadly attacks since laying siege to the north of the enclave more than two weeks ago.

## Video: Obama raps Eminem’s ‘Lose Yourself’ at Harris rally
 - [https://www.aljazeera.com/program/newsfeed/2024/10/23/video-obama-raps-eminems-lose-yourself-at-harris-rally?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/10/23/video-obama-raps-eminems-lose-yourself-at-harris-rally?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:14:21+00:00

Former US President Barack Obama rapped lyrics from Eminem’s ‘Lose Yourself’ at a Harris rally.

## Ukraine’s army readies for high-stakes fight against Russia as winter nears
 - [https://www.aljazeera.com/news/2024/10/23/winter-and-the-bumpy-road-ahead-for-ukraine?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/winter-and-the-bumpy-road-ahead-for-ukraine?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:03:54+00:00

Al Jazeera&#039;s defence editor analyses the powers and vulnerabilities of Kyiv&#039;s military as its support system slows down.

## Images capture exact moment Israeli missile hit building in Beirut
 - [https://www.aljazeera.com/gallery/2024/10/23/images-capture-exact-moment-israeli-missile-hit-building-in-beirut?traffic_source=rss](https://www.aljazeera.com/gallery/2024/10/23/images-capture-exact-moment-israeli-missile-hit-building-in-beirut?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:21:11+00:00

Photographs taken second by second show projectile frozen in mid-flight before obliterating the structure.

## Global warming worsening deadly flooding in Africa, warn scientists
 - [https://www.aljazeera.com/news/2024/10/23/global-warming-worsened-floods-across-africa-scientists?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/global-warming-worsened-floods-across-africa-scientists?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:00:31+00:00

Africa is bearing the brunt of climate change despite producing tiny percentage of global emissions.

## US election: 13 days left — What polls say, what Harris and Trump are up to
 - [https://www.aljazeera.com/news/2024/10/23/us-election-13-days-left-what-polls-say-what-harris-and-trump-are-up?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/us-election-13-days-left-what-polls-say-what-harris-and-trump-are-up?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:33:15+00:00

Kamala Harris and Donald Trump both targeted Latino voters with their campaign activities on Tuesday.

## LeBron and Bronny James share court, make NBA history as Lakers beat Wolves
 - [https://www.aljazeera.com/sports/2024/10/23/lebron-and-bronny-james-share-court-make-nba-history-as-lakers-beat-wolves?traffic_source=rss](https://www.aljazeera.com/sports/2024/10/23/lebron-and-bronny-james-share-court-make-nba-history-as-lakers-beat-wolves?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:24:40+00:00

LeBron James shared the court with his 20-year-old son Bronny and later called the moment &#039;one of the greatest gifts&#039;.

## Taiwan says blockade would be act of war as China holds more drills
 - [https://www.aljazeera.com/news/2024/10/23/taiwan-says-blockade-would-be-act-of-war-as-china-holds-more-drills?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/taiwan-says-blockade-would-be-act-of-war-as-china-holds-more-drills?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:41:04+00:00

Taiwanese defence chief says a blockade would have far-reaching consequences for international trade.

## Russia-Ukraine war: List of key events, day 971
 - [https://www.aljazeera.com/news/2024/10/23/russia-ukraine-war-list-of-key-events-day-971?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/russia-ukraine-war-list-of-key-events-day-971?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T03:17:07+00:00

As the war enters its 971st day, these are the main developments.

## Tokyo Metro shares soar in Japan’s biggest IPO in 6 years
 - [https://www.aljazeera.com/economy/2024/10/23/tokyo-metro-shares-soar-in-japans-biggest-ipo-in-6-years?traffic_source=rss](https://www.aljazeera.com/economy/2024/10/23/tokyo-metro-shares-soar-in-japans-biggest-ipo-in-6-years?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T03:02:04+00:00

Japanese subway operator&#039;s shares soar as much as 47 percent in biggest listing since 2018.

## Giuliani ordered to hand over New York apartment to defamed election staff
 - [https://www.aljazeera.com/news/2024/10/23/giuliani-ordered-to-hand-over-new-york-apartment-to-defamed-election-staff?traffic_source=rss](https://www.aljazeera.com/news/2024/10/23/giuliani-ordered-to-hand-over-new-york-apartment-to-defamed-election-staff?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T02:31:31+00:00

Former New York mayor was one of many associates of Donald Trump who made false claims over 2020 election.

