# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Here's what I really thought about these guys in "Am I Racist?"
 - [https://www.youtube.com/watch?v=kP-HoWelvF8](https://www.youtube.com/watch?v=kP-HoWelvF8)
 - RSS feed: $source
 - date published: 2024-10-23T18:30:36+00:00

None

## Pretend Action Hero Mocks Trump’s Manhood
 - [https://www.youtube.com/watch?v=6rkR0IdBblI](https://www.youtube.com/watch?v=6rkR0IdBblI)
 - RSS feed: $source
 - date published: 2024-10-23T00:00:04+00:00

First Liberty Institute - Go to https://supremecoup.com/walsh to learn how you can help stop the radical Left’s takeover of the Supreme Court.

The actor Dave Bautista is flinging insults at Trump in a skit for Jimmy Kimmel Live. It seems pretty hypocritical from a guy who made a career by playing pretend. 

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep. 1469 - https://bit.ly/48ekZXD

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

