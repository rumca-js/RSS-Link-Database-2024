# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Meet the World’s Least Popular President
 - [https://theintercept.com/2024/10/23/peru-president-dina-boluarte-rolexgate](https://theintercept.com/2024/10/23/peru-president-dina-boluarte-rolexgate)
 - RSS feed: $source
 - date published: 2024-10-23T14:10:46+00:00

<p>With a 92 percent disapproval rating, Peru’s Dina Boluarte is testing the very limits of disdain.</p>
<p>The post <a href="https://theintercept.com/2024/10/23/peru-president-dina-boluarte-rolexgate/">Meet the World’s Least Popular President</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>


