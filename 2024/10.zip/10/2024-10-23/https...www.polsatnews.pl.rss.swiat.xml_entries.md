# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Eksplozja w stolicy Turcji. Padły też strzały, są ofiary
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/wybuch-w-siedzibie-firmy-tureckiej-lotniczej-trwa-ewakuacja](https://www.polsatnews.pl/wiadomosc/2024-10-23/wybuch-w-siedzibie-firmy-tureckiej-lotniczej-trwa-ewakuacja)
 - RSS feed: $source
 - date published: 2024-10-23T14:16:06.986921+00:00

W siedzibie tureckiej firmy lotniczej TUSAS w Ankarze doszło do eksplozji. W mediach pojawiła się informacja, że mogło tam dojść do zamachu bombowego. Są ofiary śmiertelne i ranni.

## Marija Zacharowa oburzona wyborem Mołdawian. Zarzuca fałszerstwo
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/marija-zacharowa-oburzona-wyborem-moldawian-zarzuca-falszerstwo](https://www.polsatnews.pl/wiadomosc/2024-10-23/marija-zacharowa-oburzona-wyborem-moldawian-zarzuca-falszerstwo)
 - RSS feed: $source
 - date published: 2024-10-23T14:16:06.658659+00:00

Według rzeczniczki MSZ Rosji Marii Zacharowej wyniki wyborów i referendum w Mołdawii zostały sfałszowane, a w przebieg głosowania mieszały się USA oraz Unia Europejska. Krytyczna reakcja Kremla najpewniej związana jest z faktem, iż o mały włos w referendum przeważyły głosy zwolenników integracji z UE, a na czele prezydenckiego wyścigu znalazła się obecna, proeuropejska liderka.

## Szefa ONZ w ogniu krytyki. Przyleciał na szczyt do Putina
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/szczyt-brics-sekretarz-generalny-onz-powitany-chlebem-i-czak-czakiem](https://www.polsatnews.pl/wiadomosc/2024-10-23/szczyt-brics-sekretarz-generalny-onz-powitany-chlebem-i-czak-czakiem)
 - RSS feed: $source
 - date published: 2024-10-23T12:06:21.873071+00:00

Sekretarz generalny ONZ Antonio Guterres pojawił się na rosyjskim szczycie państw BRICS. W sieci pojawiło się nagranie, na którym widać, że polityk został przywitany chlebem i tradycyjnym tatarskim deserem. Nie spodobało się to stronie ukraińskiej, która wypomniała sekretarzowi nieobecność na poprzednim szczycie współorganizowanym przez Kijów. To zły wybór - komentuje resort.

## Viktor Orban straszy rodaków Unią Europejską. "Czy kłaniamy się obcej sile?"
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/viktor-orban-straszy-rodakow-unia-europejska-czy-klaniamy-sie-obcej-sile](https://www.polsatnews.pl/wiadomosc/2024-10-23/viktor-orban-straszy-rodakow-unia-europejska-czy-klaniamy-sie-obcej-sile)
 - RSS feed: $source
 - date published: 2024-10-23T12:06:21.765702+00:00

- Pojawia się stare pytanie: czy kłaniamy się woli obcej siły, tym razem z Brukseli, czy też jej się opieramy? (...) Proponuję, aby nasza odpowiedź była równie jasna i jednoznaczna, jak w 1956 r. - mówił Viktor Orban przy okazji rocznicy narodowego powstania. W ten sposób węgierski premier Węgier przekonywał rodaków, że Unia Europejska chce umieścić w kraju marionetkowy rząd.

## Zełenski przygotowuje kolejny plan. "Wydał już rozkaz"
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/zelenski-przygotowuje-kolejny-plan-wydal-juz-rozkaz](https://www.polsatnews.pl/wiadomosc/2024-10-23/zelenski-przygotowuje-kolejny-plan-wydal-juz-rozkaz)
 - RSS feed: $source
 - date published: 2024-10-23T12:06:21.654181+00:00

Wołodymyr Zełenski przygotowuje kolejny plan. Media donoszą, że prezydent Ukrainy zlecił urzędnikom opracowanie propozycji koncepcji wewnętrznych działań, które miałyby pomóc Ukrainie przetrwać w warunkach wojny. Inicjatywa ta nie stanowi alternatywy dla planu zwycięstwa prezentowanego na arenie międzynarodowej.

## Barack Obama zaskoczył. Były prezydent zaczął rapować
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/barack-obama-zaskoczyl-byly-prezydent-zaczal-rapowac-na-wiecu](https://www.polsatnews.pl/wiadomosc/2024-10-23/barack-obama-zaskoczyl-byly-prezydent-zaczal-rapowac-na-wiecu)
 - RSS feed: $source
 - date published: 2024-10-23T08:50:14.797332+00:00

Barack Obama, który na finiszu kampanii prezydenckiej w Stanach Zjednoczonych aktywnie wspiera Kamalę Harris, zaskoczył podczas wiecu wyborczego w Detroit. Były prezydent USA zaśpiewał fragment słynnej piosenki jednego z najbardziej znanych raperów na świecie - Eminema. Jego występ został nagrodzony owacją publiczności.

## Białoruś zorganizuje wybory prezydenckie. Podano datę
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/bialorus-zorganizuje-wybory-prezydenckie-podano-date](https://www.polsatnews.pl/wiadomosc/2024-10-23/bialorus-zorganizuje-wybory-prezydenckie-podano-date)
 - RSS feed: $source
 - date published: 2024-10-23T08:50:14.466346+00:00

26 stycznia 2025 r. na Białorusi zorganizowane zostaną wybory prezydenckie - podała agencja AFP. Kraj od 1994 r. niezmiennie rządzony jest przez Aleksandra Łukaszenkę, który ograniczył wszelką działalność opozycyjną. Agencja przypomina także, że w 2022 r. Łukaszenka zgodził się na atak Rosji z terenu Białorusi na Ukrainę.

## Rosja nasiliła ataki na ukraińskie statki. Putin podjął ryzyko
 - [https://www.polsatnews.pl/wiadomosc/2024-10-23/rosja-nasilila-ataki-na-ukrainskie-statki-to-stwarza-globalne-zagrozenie](https://www.polsatnews.pl/wiadomosc/2024-10-23/rosja-nasilila-ataki-na-ukrainskie-statki-to-stwarza-globalne-zagrozenie)
 - RSS feed: $source
 - date published: 2024-10-23T05:35:19.127027+00:00

Brytyjski wywiad ustalił, że Rosja nasiliła swoje ataki na ukraińskie statki na Morzu Czarnym. Powoduje to nie tylko starty dla Kijowa, ale także w znacznym stopniu opóźnia dostawy na Bliski Wschód i do Afryki. Wielka Brytania wraz z Norwegią zapowiedziały, że wyposażą ukraińską marynarkę wojenną w lepszy sprzęt taki jak m.in. morskie drony.

