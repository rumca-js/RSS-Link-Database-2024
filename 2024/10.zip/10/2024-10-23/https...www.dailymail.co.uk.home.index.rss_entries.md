# Source:Daily Mail - Home, URL:https://www.dailymail.co.uk/home/index.rss, language:en-gb

## Widow and widower who fell in love while queuing to pay their respect to the Queen get married aged 89 and 85
 - [https://www.dailymail.co.uk/femail/article-13992339/Widow-widower-fell-love-queuing-pay-respect-Queen-married-aged-89-85.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13992339/Widow-widower-fell-love-queuing-pay-respect-Queen-married-aged-89-85.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T14:17:02+00:00

Joyce Lambert, 89, and Norman Giller, 85, exchanged vows at an intimate wedding in Southend-on-Sea on October 18 after a whirlwind romance of the last five years.

## British Boomer couples with degrees retire with SEVEN times more money than people who didn't go to university, study finds
 - [https://www.dailymail.co.uk/sciencetech/article-13992597/British-Boomers-retire-SEVEN-times-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13992597/British-Boomers-retire-SEVEN-times-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T14:14:12+00:00

Researchers from the University of Bath have discovered a huge discrepancy between the amount of money people who did, and did not go to university, retire with.

## Daisy May Cooper breaks down in tears recounting death of her friend on Loose Women - and reveals supernatural experience that changed her life forever
 - [https://www.dailymail.co.uk/tv/article-13992283/Daisy-Cooper-tears-death-friend-Loose-Women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tv/article-13992283/Daisy-Cooper-tears-death-friend-Loose-Women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T14:12:27+00:00

The actress, 38, joined the ITV show on Wednesday to discuss her new book Hexy B***h and what inspired her love of the supernatural.

## Buy a house for £10! Open plan home with its own garden near historic village and handy transport links is up for auction - but there is a catch
 - [https://www.dailymail.co.uk/property/article-13992089/Buy-house-10-Open-plan-home-garden-near-historic-village-handy-transport-links-auction-catch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/property/article-13992089/Buy-house-10-Open-plan-home-garden-near-historic-village-handy-transport-links-auction-catch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T14:10:46+00:00

Struggling to get onto the property ladder? Well, now is your chance as a terraced house in the picturesque environs of the Welsh Valleys hits the market for just a tenner - but there is a catch.

## Liam Payne raises £200,000 for Choose Love charity as sales for his specially designed T-shirt spike following his death
 - [https://www.dailymail.co.uk/tvshowbiz/article-13991653/Liam-Payne-raises-Choose-Love-charity-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13991653/Liam-Payne-raises-Choose-Love-charity-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T14:07:55+00:00

The singer, who passed away last Wednesday at the age of 31 , previously worked with the Choose Love campaign, and designed a T-shirt which has so far raised £186,500.

## Clarkson's Farm star Kaleb Cooper reveals he accidentally snubbed David Beckham as he shares hilarious story
 - [https://www.dailymail.co.uk/tvshowbiz/article-13991949/Clarksons-Farm-Kaleb-Cooper-snubbed-David-Beckham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13991949/Clarksons-Farm-Kaleb-Cooper-snubbed-David-Beckham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T13:55:06+00:00

During an appearance on Capital Breakfast with Jordan North , Chris Stark and Sian Welby, he said: 'I didn't really watch much TV, or, you know, go on Instagram too much..'

## Devastating moment Grand Designs couple face £5,000 blow in 'biblical task' of converting an old water tower into their dream home
 - [https://www.dailymail.co.uk/femail/article-13991341/Grand-Designs-blow-converting-old-water-tower.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991341/Grand-Designs-blow-converting-old-water-tower.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T13:45:06+00:00

In tonight's episode of Channel 4 's home design series, Adam and Tassy set about the seemingly impossible task of converting an old water tower in Northamptonshire into a home.

## Drug overdose deaths hit a record high with middle-aged Gen X driving disturbing trend - while Gen Z fatalities fall
 - [https://www.dailymail.co.uk/health/article-13991411/Drug-overdose-deaths-hit-record-high-middle-aged-Gen-X-driving-disturbing-trend-Gen-Z-fatalities-fall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13991411/Drug-overdose-deaths-hit-record-high-middle-aged-Gen-X-driving-disturbing-trend-Gen-Z-fatalities-fall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T13:11:48+00:00

A record-breaking 5,448 drug poisoning deaths were recorded in 2023 - a rate of 93 deaths per million people. This is the eleventh consecutive annual rise.

## Heston Blumenthal hikes price of a Christmas dinner at the Fat Duck to an eye-watering £450-per-head (and it's not even available on December 25!)
 - [https://www.dailymail.co.uk/femail/article-13991451/Heston-Blumenthal-hikes-price-Christmas-dinner-Fat-Duck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991451/Heston-Blumenthal-hikes-price-Christmas-dinner-Fat-Duck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T13:09:49+00:00

The Berkshire restaurant  promises indulgent dishes with some 'nice surprises'- including classic Christmas-inspired food as well as Blumenthal's famous wacky creations.

## Trinny and Susannah's meanest What Not to Wear moments revealed - as their own daughters admit 'they'd be cancelled now' 
 - [https://www.dailymail.co.uk/femail/article-13991097/Trinny-Susannahs-meanest-Not-Wear-moments-revealed-daughters-admit-theyd-cancelled-now.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991097/Trinny-Susannahs-meanest-Not-Wear-moments-revealed-daughters-admit-theyd-cancelled-now.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T13:07:03+00:00

The What Not to Wear duo's own daughters this week admitted their mums would face the axe if they dared to say make some of the catty comments they did in the early noughties.

## British film icon Dick Pope dies aged 77 as Tom Hardy pays tribute to 'lovely friend and all round legend'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13992007/British-film-icon-Dick-Pope-dies-aged-77-Tom-Hardy-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13992007/British-film-icon-Dick-Pope-dies-aged-77-Tom-Hardy-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T12:46:09+00:00

Cinematographer Dick Pope, has died, aged 77.

## Covid cut half a year from UK men's life expectancy - and three months from women, new official data reveals
 - [https://www.dailymail.co.uk/health/article-13991483/Covid-slashed-life-expectancy-new-data-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13991483/Covid-slashed-life-expectancy-new-data-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T12:33:11+00:00

In 2021 to 2023, life expectancy at birth in England and Wales was 79.0 years for men and 83.0 years for women, Office for National Statistics ( ONS ) today revealed.

## Balenciaga is selling a plain black tie for £250 (despite Asda selling an identical one for £5!)
 - [https://www.dailymail.co.uk/femail/article-13991845/Balenciaga-flogs-tie-250-despite-Asda.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991845/Balenciaga-flogs-tie-250-despite-Asda.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T12:25:10+00:00

The Spanish luxury fashion house has become known for its wacky and unconventional designs - but seemed to disappoint with the mediocrity of one recent item.

## Man claims he was infected with drug-resistant e.coli in his PENIS from a bidet - doctors say there could be a more embarrassing explanation
 - [https://www.dailymail.co.uk/health/article-13991227/Man-claims-contracted-superbug-UTI-using-bidet-doctors-sceptical.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13991227/Man-claims-contracted-superbug-UTI-using-bidet-doctors-sceptical.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T12:04:23+00:00

Molson Hart shared his experience of what he initially thought was a cold but which later turned out to be an infection that left him urinating blood for four days.

## The woman behind TV's raciest scenes: Intimacy co-ordinator for Bridgerton and raunchy movie that left Nicole Kidman with 'orgasm burnout' reveals her secrets
 - [https://www.dailymail.co.uk/femail/article-13991251/The-woman-TVs-raciest-scenes-Intimacy-ordinator-Bridgerton-raunchy-movie-left-Nicole-Kidman-orgasm-burnout-reveals-secrets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991251/The-woman-TVs-raciest-scenes-Intimacy-ordinator-Bridgerton-raunchy-movie-left-Nicole-Kidman-orgasm-burnout-reveals-secrets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T12:01:46+00:00

Lizzy Talbot, who splits her time between the US and the UK, has revealed her secrets to creating the perfect sex scene to titillate audiences as Nicole Kidman sets pulses racing in Babygirl.

## Inside the glamorous life of the Australian model who had a VERY cheeky sign for King Charles in Sydney
 - [https://www.dailymail.co.uk/femail/article-13991121/glamorous-Australian-King-Charles-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991121/glamorous-Australian-King-Charles-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T12:00:32+00:00

King Charles , 75,  and his wife Queen Camilla, 77, were on the fifth day of official engagements in Australian yesterday when one very scantily clad woman was spotted.

## Mike Tindall to go head to head with Prince Harry as paperback version of Spare is released tomorrow - the same day as rugby ace's new book
 - [https://www.dailymail.co.uk/femail/article-13991165/Mike-Tindall-head-head-Prince-Harry-book-sale-spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991165/Mike-Tindall-head-head-Prince-Harry-book-sale-spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:53:35+00:00

The former English rugby union player, who resides in Gloucestershire, is set to release 'The Good, The Bad & The Rugby -Unleashed' tomorrow - the same day as Harry's Spare paperback.

## DAN HODGES: Vicious Chris Kaba preyed on his own community. His attempted martyrdom by liberal politicians and black leaders is utterly insane
 - [https://www.dailymail.co.uk/debate/article-13991761/DAN-HODGES-Chris-Kaba-liberal-politicians-black-leaders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13991761/DAN-HODGES-Chris-Kaba-liberal-politicians-black-leaders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:53:04+00:00

Finally, we get to see Chris Kaba. Not the myth, or the martyr. But the real man. In fact, Kaba was a vicious criminal who had been issued with a 28-day domestic violence order.

## Strictly's Wynne Evans and Katya Jones are all smiles while out shopping on London's Oxford Street after controversy surrounding 'wandering hand' incident
 - [https://www.dailymail.co.uk/tvshowbiz/article-13991797/Strictlys-Wynne-Evans-Katya-Jones-smiles-shopping-Londons-Oxford-Street-controversy-surrounding-wandering-hand-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13991797/Strictlys-Wynne-Evans-Katya-Jones-smiles-shopping-Londons-Oxford-Street-controversy-surrounding-wandering-hand-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:47:43+00:00

The Strictly Come Dancing pair have been embroiled in controversy since Wynne's 'wandering hand' incident during an episode of the BBC show.

## I have been branded 'lazy' because I believe homework is optional - people say my 'woke' parenting makes my children the boss of the house
 - [https://www.dailymail.co.uk/femail/article-13991151/I-branded-lazy-believe-homework-optional-people-say-woke-parenting-makes-children-boss-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991151/I-branded-lazy-believe-homework-optional-people-say-woke-parenting-makes-children-boss-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:40:06+00:00

Danielle Gallacher, from Glasgow , Scotland, has been branded 'lazy' after boasting that homework is 'optional' - as people claim her ' woke ' parenting makes her children boss of the house.

## How to beat arthritis: The definitive doctors' guide to the treatments that work, what to do if it's early days, the truth about supplements and steps to avoid surgery
 - [https://www.dailymail.co.uk/health/article-13991441/How-beat-arthritis-definitive-doctors-guide-treatments-work-early-days-truth-supplements-steps-avoid-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13991441/How-beat-arthritis-definitive-doctors-guide-treatments-work-early-days-truth-supplements-steps-avoid-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:26:35+00:00

In the UK, an estimated 9million people have osteoarthritis, which most commonly hits joints that take most strain - more than two million over-45s have it in their hips, and five million in their knee

## Make money from your old mobile: Experts reveal the best types and ways to sell, how to wipe your data and the best month to do it so you can earn hundreds more
 - [https://www.dailymail.co.uk/money/mailplus/article-13991213/Make-money-old-mobile-Experts-reveal-best-types-ways-sell-wipe-data-best-month-earn-hundreds-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mailplus/article-13991213/Make-money-old-mobile-Experts-reveal-best-types-ways-sell-wipe-data-best-month-earn-hundreds-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:25:25+00:00

Do you have the means to making hundreds of pounds just gathering dust in a drawer? When upgrading our smartphones, most of us will keep our old device as a back-up.

## Weight loss surgery could make you RICHER - new figures show drastic op leads to higher earnings
 - [https://www.dailymail.co.uk/health/article-13991485/Surgery-lose-weight-boost-wages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13991485/Surgery-lose-weight-boost-wages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:25:10+00:00

Analysis found Brits in who underwent bariatric surgery, such as gastric bypasses, on the NHS saw the significant boost to their pay checks five years after the operation.

## Clarkson's Farm star Kaleb Cooper shares health update on Jeremy Clarkson after the presenter revealed he underwent an urgent heart operation
 - [https://www.dailymail.co.uk/tvshowbiz/article-13991343/Clarksons-Farm-Kaleb-Cooper-Jeremy-Clarkson-health-update.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13991343/Clarksons-Farm-Kaleb-Cooper-Jeremy-Clarkson-health-update.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:15:28+00:00

It was revealed earlier this week that the 64-year-old former Top Gear host had to have the procedure after a 'sudden deterioration' in his health, that left him 'maybe days away from death'.

## DEAR JANE: My husband is upset after I revealed my body count... but I don't even think my number is that high!
 - [https://www.dailymail.co.uk/femail/article-13983473/husband-body-count-high-DEAR-JANE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13983473/husband-body-count-high-DEAR-JANE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T11:06:42+00:00

I'd never had a serious relationship before, and I used to travel around for work - so I'll admit that I'd slept with a fair few people before we met.

## Emergency services respond to 'major incident' at Dorset care home as staff are 'seen hugging and crying' outside
 - [https://www.dailymail.co.uk/news/article-13991767/Emergency-services-respond-major-incident-Dorset-care-home-staff-seen-hugging-crying-outside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13991767/Emergency-services-respond-major-incident-Dorset-care-home-staff-seen-hugging-crying-outside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:58:53+00:00

A 'major incident' has been declared at Gainsborough Care Home in Ullwell Road, Swanage, Dorset this morning.

## Holly Hagan shows off her incredible 47lbs weight loss and admits cruel trolls led her to 'stop showing up and creating content' as she reflects on her fitness journey
 - [https://www.dailymail.co.uk/tvshowbiz/article-13991153/Holly-Hagan-weight-loss-candid-post-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13991153/Holly-Hagan-weight-loss-candid-post-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:58:17+00:00

The Geordie Shore alum, 32, admitted she 'stopped showing up and creating content' after being criticised by cruel online trolls on her post-partum body - as she got candid in her latest post.

## The ultra-processed foods you don't realise are damaging your health. A top nutritionist reveals the surprising staples that can be packed with chemicals
 - [https://www.dailymail.co.uk/health/article-13982827/ultra-processed-foods-dont-realise-damaging-health-nutritionist-reveals-surprising-staples-packed-chemicals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13982827/ultra-processed-foods-dont-realise-damaging-health-nutritionist-reveals-surprising-staples-packed-chemicals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:57:03+00:00

We asked Kayla Daniels, registered nutritionist and founder of Kayla's Nutrition, for nine of the ultra-processed foods most damaging to your health.

## Prince Harry named 25th hottest man of all time by Harper's Bazaar - beating Bradley Cooper and David Beckham
 - [https://www.dailymail.co.uk/femail/article-13991049/Prince-Harry-25th-hottest-man-Harpers-Bazaar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991049/Prince-Harry-25th-hottest-man-Harpers-Bazaar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:55:49+00:00

Montecito-based Prince Harry, 40, beat of stiff competition from the world's most famous faces in Harper Bazaar's rankings.

## Richard Madeley pays emotional tribute to 'inspiring' John Stapleton on in first TV interview since Parkinson's diagnosis on Good Morning Britain
 - [https://www.dailymail.co.uk/tv/article-13991429/richard-madeley-tribute-john-stapleton-tv-interview-parkinsons-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tv/article-13991429/richard-madeley-tribute-john-stapleton-tv-interview-parkinsons-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:54:52+00:00

The broadcaster, 78, made the revelation in a video for BBC One's Morning Live where he discussed his life has changed.

## The Chase fans concerned for contestant as he sports bruised face and split lip on ITV quiz show - before Paul Sinha takes a brutal swipe
 - [https://www.dailymail.co.uk/tv/article-13991597/The-Chase-fans-concerned-contestant-ITV-Paul-Sinha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tv/article-13991597/The-Chase-fans-concerned-contestant-ITV-Paul-Sinha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:50:30+00:00

The rugby player from Henley-on-Thames, was joined by Claire, Ed and Hannah as they battled it out against The Simmerman.

## Revealed: Liverpool's 'new £60m-a-year adidas deal' is STILL dwarfed by Man United's £900m partnership - but how does it compare to Europe's powerhouses?
 - [https://www.dailymail.co.uk/sport/football/article-13991691/Liverpool-60m-adidas-Man-United-900m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13991691/Liverpool-60m-adidas-Man-United-900m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:45:48+00:00

In recent years, adidas' willingness to utilise the iconic designs of yesteryear to modernise the top teams' kits has seen them become hugely successful, resulting in numerous cult classics.

## Princess Eugenie gives a cheery wave as she joins her husband Jack Brooksbank for date night in Mayfair
 - [https://www.dailymail.co.uk/femail/article-13991491/Princess-Eugenie-cheery-wave-jack-brooksbank-date-night-mayfair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13991491/Princess-Eugenie-cheery-wave-jack-brooksbank-date-night-mayfair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:33:10+00:00

The younger daughter of Prince Andrew and Sarah Ferguson, 34, appeared in very bright spirits as she left swanky members' club Oswald's in London.

## Popular acne treatment gave 24-year-old woman second degree burns all over her face - she could be scarred for life
 - [https://www.dailymail.co.uk/health/article-13987947/Warning-acne-treatment-woman-degree-burns-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13987947/Warning-acne-treatment-woman-degree-burns-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:31:17+00:00

Melia Nielsen from Grimsby, Lincolnshire, 24, was left with a swollen and red cheek after a microneedleing procedure went wrong. The ordeal has permanently put her off cosmetic procedures.

## Teenage chess grandmaster arrested after allegedly committing a shocking crime against a woman when he had a meltdown after a loss
 - [https://www.dailymail.co.uk/sport/othersports/article-13991349/Teenage-chess-grandmaster-arrested-allegedly-committing-shocking-crime-against-woman-meltdown-loss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/othersports/article-13991349/Teenage-chess-grandmaster-arrested-allegedly-committing-shocking-crime-against-woman-meltdown-loss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:25:45+00:00

Christopher Yoo had been beaten by defending champion GM Fabiano Caruana but appeared to react angrily to the defeat and was seen scrunching up his scoresheet.

## Emma King, the actress wife of Rivals star Alex Hassell, met him at drama school - and has already warned him to stop getting his kit off
 - [https://www.dailymail.co.uk/femail/article-13988015/Disney-Rivals-Alex-Hassell-wife-14-years-actress-Emma-King.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13988015/Disney-Rivals-Alex-Hassell-wife-14-years-actress-Emma-King.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:22:52+00:00

Any viewers hoping to steal British heartthrob Alex Hassell's heart following his saucy scenes in the adaptation of Jilly Cooper's 1988 'bonkbuster' are going to be left disappointed.

## Former England boss Gareth Southgate 'in contention to replace Premier League manager if poor start to the season continues'
 - [https://www.dailymail.co.uk/sport/football/article-13991397/Former-England-boss-Gareth-Southgate-contention-replace-Premier-League-manager-poor-start-season-continues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13991397/Former-England-boss-Gareth-Southgate-contention-replace-Premier-League-manager-poor-start-season-continues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:21:50+00:00

Southgate resigned as England manager after the Three Lions' crushing 2-1 defeat by Spain in July's European Championship final and has continued to be linked with jobs since.

## Dutch royal's foundation 'comes to a halt' after Princess is accused of creating a 'culture of fear and intimidation'
 - [https://www.dailymail.co.uk/femail/article-13987291/Dutch-King-sister-law-Princess-Laurentien-foundation-comes-halt-accused-creating-culture-fear-intimidation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13987291/Dutch-King-sister-law-Princess-Laurentien-foundation-comes-halt-accused-creating-culture-fear-intimidation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:20:22+00:00

Princess Laurentien of the Netherlands' foundation has come to a halt, according to Dutch news outlet NRC.

## Floods hit... the SAHARA! Shocking before and after satellite images show a huge lake emerging after the desert was struck by its biggest deluge for decades
 - [https://www.dailymail.co.uk/sciencetech/article-13991321/Floods-hit-SAHARA-Shocking-satellite-images.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13991321/Floods-hit-SAHARA-Shocking-satellite-images.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:10:08+00:00

It's known as one of the driest places on our planet. But shocking before and after images show what happened when the Sahara Desert was struck by its biggest deluge for decades.

## Strictly 'love hexagon' involving Pete Wicks, Maura Higgins and Jowita Przystał proves show is 'a never-ending conveyor belt' of hook ups
 - [https://www.dailymail.co.uk/tvshowbiz/article-13987051/Strictly-love-hexagon-Pete-Wicks-Maura-Higgins-Jowita-Przysta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13987051/Strictly-love-hexagon-Pete-Wicks-Maura-Higgins-Jowita-Przysta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T10:07:38+00:00

At Monday night's Pride Of Britain awards at London's Grosvenor Hotel, pro dancer Kai Widdrington was spotted cosying up to Maura Higgins who was also seen kissing contestant Pete Wicks.

## Liam Payne's 'fairy godmother' Dame Denise Lewis pens heartbreaking tribute to the 1D star after his tragic death aged 31
 - [https://www.dailymail.co.uk/tvshowbiz/article-13991261/denise-lewis-tribute-liam-payne-tragic-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13991261/denise-lewis-tribute-liam-payne-tragic-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:51:16+00:00

The heptathlete, 52, is married to Steve Finan - who was Liam's manager for several years - and she has been regarded by some as the former One Direction star's 'fairy godmother'.

## The Hairy Bikers' Si King pays tear-jerking tribute to late co-star Dave Myers in first TV interview since his death
 - [https://www.dailymail.co.uk/tv/article-13991135/The-Hairy-Bikers-Si-King-tribute-Dave-Myers-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tv/article-13991135/The-Hairy-Bikers-Si-King-tribute-Dave-Myers-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:51:04+00:00

During an appearance on The One Show, the TV presenter, 58, emotionally explained how the spirit of their friendship will live on as he learns to cope with his loss. 

## Marcus Rashford's £2.5m Cheshire mansion is STILL not finished four years after he bought the eco-friendly site... and there's an irritating issue with his dream home
 - [https://www.dailymail.co.uk/tvshowbiz/article-13991105/Marcus-Rashford-Cheshire-mansion-not-finished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13991105/Marcus-Rashford-Cheshire-mansion-not-finished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:50:18+00:00

Marcus Rashford's dream home in the Cheshire countryside is still under construction, four years after the footballer bought the site.

## The Traitors finale is postponed indefinitely after contestant's real-life murder
 - [https://www.dailymail.co.uk/femail/article-13986785/Traitors-Finland-postpones-final-contestant-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13986785/Traitors-Finland-postpones-final-contestant-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:47:48+00:00

Janne was a contestant on the pre-recorded second series of Finland 's The Traitors, and had reached the final alongside Green MP Fatim Diarra, according to YLE .

## Anger as NHS patients told they WON'T get 'new hope' Alzheimer's drug donanemab
 - [https://www.dailymail.co.uk/health/article-13991125/patients-drug-donanemab-Alzheimers-treatment-NHS-watchdog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13991125/patients-drug-donanemab-Alzheimers-treatment-NHS-watchdog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:43:44+00:00

In a blow to tens of thousands of Brits, draft guidance by the NHS spending watchdog ruled the benefits of the drug are far too small to justify the roll-out cost.

## Women's football team claim they are victims of 'transphobic violence' after rival team's local councillor claimed they fielded 'two bearded guys who consider themselves women'
 - [https://www.dailymail.co.uk/sport/football/article-13991211/Womens-football-team-transphobic-violence-bearded-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13991211/Womens-football-team-transphobic-violence-bearded-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:35:42+00:00

The situation is rather distinctive - these are two women attempting to transition to manhood who are still playing in a female league.

## The Gulf Stream is on the verge of COLLAPSING, leading climate scientists warn - 'impacting the entire world for centuries to come'
 - [https://www.dailymail.co.uk/sciencetech/article-13991003/Gulf-Stream-COLLAPSE-soon-scientists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13991003/Gulf-Stream-COLLAPSE-soon-scientists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:33:34+00:00

In the 'The Day After Tomorrow', the world is plunged into an ice age after climate change leads to the collapse of the Gulf Stream. Now, scientists say the film's terrifying plot could be coming true.

## Interactive Investor launches its own social media platform
 - [https://www.dailymail.co.uk/money/investing/article-13990839/Interactive-Investor-launches-social-media-platform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/investing/article-13990839/Interactive-Investor-launches-social-media-platform.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:46+00:00

Interactive Investor is hoping to connect with the growing influence of social media on DIY investors via the launch of its own platform.

## Lloyds profits beat expectations thanks to interest rate boost
 - [https://www.dailymail.co.uk/money/markets/article-13990889/Lloyds-profits-beat-expectations-thanks-rate-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/markets/article-13990889/Lloyds-profits-beat-expectations-thanks-rate-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T08:42:29+00:00

The banking giant revealed its pre-tax profits totalled £1.8billion for the three months ending September, 2 per cent down on the same period last year.

## Dame Arlene Phillips, 81, hints at Strictly return after she was axed from judging panel 15 years ago
 - [https://www.dailymail.co.uk/tvshowbiz/article-13990979/Arlene-Phillips-hints-Strictly-return-axed-judge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13990979/Arlene-Phillips-hints-Strictly-return-axed-judge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T08:35:40+00:00

Dame Arlene Phillips has hinted at a exciting return to Strictly Come Dancing, over a decade after she was axed from the judging panel.

## TRACEY COX reveals the six REAL reasons why women cheat
 - [https://www.dailymail.co.uk/femail/article-13990989/TRACEY-COX-reveals-six-REAL-reasons-women-cheat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13990989/TRACEY-COX-reveals-six-REAL-reasons-women-cheat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T07:39:10+00:00

In this week's column, UK sex expert Tracey Cox debunks common myths about woman and infidelity.

## Rape-accused UK rapper Yung Filly blows kiss to fans outside court
 - [https://www.dailymail.co.uk/tvshowbiz/article-13990765/Yung-Filly-blows-kiss-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13990765/Yung-Filly-blows-kiss-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T07:21:04+00:00

British YouTuber and musician Yung Filly, who is accused of raping and choking a woman in a Perth hotel room, has briefly faced court to change his temporary address.

## Temu slammed by shopper over croissant-shaped lamp - after she realised what it is actually made from
 - [https://www.dailymail.co.uk/femail/article-13986507/Temu-croissant-shaped-lamp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13986507/Temu-croissant-shaped-lamp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:55:17+00:00

Neta Murphy ordered a croissant lamp as a gift for her sister from the affordable Chinese shopping site Temu but was left stumped by what she discovered.

## Popular 90s TV show is returning to screens after 34 years - and it is 'sure to warm hearts worldwide'
 - [https://www.dailymail.co.uk/femail/article-13988073/90s-tv-returning-screens.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13988073/90s-tv-returning-screens.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:43:45+00:00

The creators of the Wallace and Gromit and Chicken Run franchises, Aardman Animations, will team up with American Barbie company Mattel to revive the beloved '90s animated series.

## Clock changes fuel a rise in cancer, traffic accidents and sleep issues, experts warn - as they call for daylight saving time to be DITCHED entirely
 - [https://www.dailymail.co.uk/sciencetech/article-13987901/Clock-change-cancer-traffic-accidents-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13987901/Clock-change-cancer-traffic-accidents-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:38:22+00:00

In a UK first, experts from the British Sleep Society have published a position statement advocating for the abolition of the twice-yearly clock change.

## Nurse who poisoned young boy with 'industrial amounts' of laxatives leaving him emaciated, permanently disfigured and with a growth stunt has jail sentence cut
 - [https://www.dailymail.co.uk/news/article-13990845/Nurse-poisoned-young-boy-industrial-amounts-laxatives-leaving-emaciated-permanently-disfigured-growth-stunt-jail-sentence-cut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13990845/Nurse-poisoned-young-boy-industrial-amounts-laxatives-leaving-emaciated-permanently-disfigured-growth-stunt-jail-sentence-cut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:36:13+00:00

Tracy Menhinick was found guilty of wilfully harming the youngster earlier this year after a 19-day trial at the High Court in Aberdeen.

## Newborn baby fighting for its life after heavily pregnant woman, in her 30s, plunges to her death from 17-storey tower block
 - [https://www.dailymail.co.uk/news/article-13990861/newborn-baby-fighting-life-woman-plunge-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13990861/newborn-baby-fighting-life-woman-plunge-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:35:54+00:00

The little baby is today receiving 'critical care' after a woman, aged in her 30s, fell to her death from Shakespeare Towers in Burmantofts, Leeds, yesterday morning.

## Public sector workers' golden pension pots 'will be spared' Chancellor's £15BILLION national insurance raid in Budget - leaving private sector firms and staff to bear the whole burden
 - [https://www.dailymail.co.uk/news/article-13990859/Public-sector-workers-golden-pension-pots-Chancellor-national-insurance-Budget-Labour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13990859/Public-sector-workers-golden-pension-pots-Chancellor-national-insurance-Budget-Labour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:34:51+00:00

Chancellor Rachel Reeves is planning a huge move to impose NICs on employers' contributions to retirement funds in the crucial package next Wednesday.

## My friends have ditched my 40th celebrations at the last minute and it's made me feel unimportant
 - [https://www.dailymail.co.uk/femail/article-13962419/My-friends-ditched-40th-celebrations-feel-unimportant-unreliable-pals-flaky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13962419/My-friends-ditched-40th-celebrations-feel-unimportant-unreliable-pals-flaky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:33:37+00:00

The woman took to British parenting platform Mumsnet to explain that she booked a venue for 28 friends but now eight have dropped out last minute and she is stuck with the bill.

## Victoria, the comeback queen of fashion: Royals from around world pay homage to Britain's brand Beckham
 - [https://www.dailymail.co.uk/news/royals/article-13906527/victoria-beckham-comeback-queen-fashion-British-brand-kate-meghan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/royals/article-13906527/victoria-beckham-comeback-queen-fashion-British-brand-kate-meghan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:22:32+00:00

Victoria Beckham is experiencing a resurgence after several years of big financial losses.

## How the country that welcomed the Queen with 'Viva! Viva!' in 1957 could now be Harry and Meghan's new European home in 'the Hamptons of Portugal'
 - [https://www.dailymail.co.uk/news/royals/article-13971785/country-welcomed-Queen-Viva-Viva-1957-Harry-Meghan-new-European-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/royals/article-13971785/country-welcomed-Queen-Viva-Viva-1957-Harry-Meghan-new-European-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:21:29+00:00

Portugal has played an important part in British royal lives for centuries, and it looks as though it could continue.

## The 30 best places to visit in 2025 named by Lonely Planet: Cameroon, Toulouse, Pittsburgh and East Anglia are among the places you MUST explore next year
 - [https://www.dailymail.co.uk/travel/article-13984699/Lonely-Planet-best-places-2025-east-anglia-pittsburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13984699/Lonely-Planet-best-places-2025-east-anglia-pittsburgh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:20:57+00:00

The destinations are honoured in Lonely Planet's newly released Best In Travel 2025 book, which crowns the top ten countries, regions and cities to visit next year.

## PLAY TEAMSHEET: Can YOU name the Chelsea team that collapsed against Arsenal via a hat-trick from a Gunners star?
 - [https://www.dailymail.co.uk/sport/teamsheet/article-13913657/PLAY-TEAMSHEET-Chelsea-collapsed-Arsenal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/teamsheet/article-13913657/PLAY-TEAMSHEET-Chelsea-collapsed-Arsenal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T06:06:11+00:00

Every day we'll challenge you to name a different starting XI from the Premier League era. We'll give you a team's rough formation, and the number of letters in each player's name. Then it's up to you!

## Bizarre meaning behind North West's $20,000 'Skibidi Toilet' birthday gift for Kim Kardashian revealed
 - [https://www.dailymail.co.uk/tvshowbiz/article-13990143/North-West-bizarre-Skibidi-Toilet-gift-Kim-Kardashian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13990143/North-West-bizarre-Skibidi-Toilet-gift-Kim-Kardashian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T05:42:39+00:00

North West gifted her mom Kim Kardashian a birthday surprise that's a treasure, with the estimated value of her unique diamond tennis necklace revealed just a day after Kim's 44th birthday.

## Truth about lethal 'pink cocaine': Narcos warn new designer drug cocktail is cooked up by the sons of El Chapo is flooding US and UK after being linked to Liam Payne's death
 - [https://www.dailymail.co.uk/health/article-13986457/Sinister-truth-lethal-pink-cocaine-warn-new-designer-drug-cocktail-Mexican-cartel-El-Chapo-flooding-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13986457/Sinister-truth-lethal-pink-cocaine-warn-new-designer-drug-cocktail-Mexican-cartel-El-Chapo-flooding-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T05:26:51+00:00

Despite being invented in the 70s and having a minor presence in the party scene since the 90s, the designer drug has only recently enjoyed a burst in popularity driven, in part, by its alluring pink hue.

## Rural Midlands sees biggest house price rises in past year - while coastal areas suffered
 - [https://www.dailymail.co.uk/money/mortgageshome/article-13984263/House-price-winners-losers-year-revealed-double-digit-growth-8-falls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mortgageshome/article-13984263/House-price-winners-losers-year-revealed-double-digit-growth-8-falls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:52+00:00

Average house prices went up just 2.8% in the past year, official data shows - but which areas of the UK did better and worse?

## Our £450k second home is inheritance for our two young sons - how is it best to gift it to them over the next decade?
 - [https://www.dailymail.co.uk/money/financial-planning/article-13987763/Our-450k-second-home-inheritance-two-young-sons-best-gift-decade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/financial-planning/article-13987763/Our-450k-second-home-inheritance-two-young-sons-best-gift-decade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:49+00:00

My wife and I are in our mid 50s and currently have two houses. Can we gift our sons £3,000 worth of equity in the house each year until it is theirs?

## Lady Gaga reveals her next career move after disastrous performance of box office flop Joker: Folie à Deux
 - [https://www.dailymail.co.uk/tvshowbiz/article-13989907/lady-gaga-new-single-disease-joker-deux-flop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13989907/lady-gaga-new-single-disease-joker-deux-flop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T02:00:15+00:00

Diesase, the first of songs from her forthcoming seventh album, was teased Tuesday on the Grammy-winning artist's Instagram account.

## Rihanna parties with A$AP Rocky in her native Barbados after his shooting trial was postponed
 - [https://www.dailymail.co.uk/tvshowbiz/article-13989943/Rihanna-ASAP-Rocky-party-Barbados-shooting-trial-postponed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13989943/Rihanna-ASAP-Rocky-party-Barbados-shooting-trial-postponed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T01:31:29+00:00

Rihanna was pictured enjoying a night out with boyfriend A$AP Rocky in her native Barbados on Monday.

## Ruby signed up to earn £150 a day reviewing films... but it was a scam that shook her marriage and cost her £80k. And more and more are falling victim to this cruel and ingenious new fraud
 - [https://www.dailymail.co.uk/money/mailplus/article-13987967/Ruby-signed-earn-150-day-reviewing-films-scam-shook-marriage-cost-80k-falling-victim-cruel-ingenious-new-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mailplus/article-13987967/Ruby-signed-earn-150-day-reviewing-films-scam-shook-marriage-cost-80k-falling-victim-cruel-ingenious-new-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T01:11:21+00:00

Mother-of-two Ruby Robinson always looks forward to putting her feet up in front of a film at the end of a long day in her job as a credit analyst.

## Trinny and Susannah 2.0! What Not To Wear stars' daughters Lyla Elichaoff and Esme Bertelsen say their mums 'would be cancelled now' as they grace Tatler's December cover
 - [https://www.dailymail.co.uk/tvshowbiz/article-13986709/Trinny-Susannah-2-0-Not-Wear-stars-daughters-Lyla-Elichaoff-Esme-Bertelsen-say-mums-cancelled-grace-Tatlers-December-cover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13986709/Trinny-Susannah-2-0-Not-Wear-stars-daughters-Lyla-Elichaoff-Esme-Bertelsen-say-mums-cancelled-grace-Tatlers-December-cover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T01:10:40+00:00

Susannah's daughter Esme Bertelsen, 23, and Trinny's daughter Lyla Elichaoff, 21, are set to be Tatler's December issue cover stars.

## This is Xavi the manager: Strong in defence and developing young stars but with one big flaw in his style of play, writes Spanish football expert PETE JENSON
 - [https://www.dailymail.co.uk/sport/football/article-13989123/This-Xavi-manager-Strong-defence-developing-young-stars-one-big-flaw-style-play-writes-Spanish-football-expert-PETE-JENSON.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13989123/This-Xavi-manager-Strong-defence-developing-young-stars-one-big-flaw-style-play-writes-Spanish-football-expert-PETE-JENSON.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T01:00:52+00:00

PETE JENSON: Xavi at Old Trafford would certainly be box-office. Thriller or horror film for Manchester United fans? That's harder to say.

## Daily guide to what the stars have in store for YOU - October 23, 2024
 - [https://www.dailymail.co.uk/femail/horoscopes/article-13988463/Daily-guide-stars-store-October-23-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/horoscopes/article-13988463/Daily-guide-stars-store-October-23-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T01:00:49+00:00

OSCAR CAINER: Fresh from its alignment with Pluto, the Sun is exploring Scorpio. But perhaps 'fresh' is the wrong word. Emerging bruised, yet stronger, might be more appropriate!

## Pep Lijnders reveals the truth about Jurgen Klopp's Liverpool exit, the 'bronzed' pictures his old boss sends him and his son's jibes about Salzburg switch
 - [https://www.dailymail.co.uk/sport/football/article-13987665/Pep-Lijnders-reveals-truth-Jurgen-Klopps-Liverpool-exit-bronzed-pictures-old-boss-sends-sons-jibes-Salzburg-switch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13987665/Pep-Lijnders-reveals-truth-Jurgen-Klopps-Liverpool-exit-bronzed-pictures-old-boss-sends-sons-jibes-Salzburg-switch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T01:00:46+00:00

EXCLUSIVE INTERVIEW BY LEWIS STEELE: Described by some as the brains of the Jurgen Klopp operation, the German's former right-hand man Pepijn Lijnders is a good talker.

## Lynda Obst dead at 74: Sleepless in Seattle and Flashdance producer succumbs to COPD
 - [https://www.dailymail.co.uk/tvshowbiz/article-13989361/lynda-obst-dead-sleepless-seattle-producer-copd.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13989361/lynda-obst-dead-sleepless-seattle-producer-copd.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:58:40+00:00

Obst - who was an executive producer on the hit 1993 rom-com starring Tom Hanks and Meg Ryan - passed away Tuesday at her home in Los Angeles , her son Oly Obst said.

## Inside story of Strictly love triangle: Truth behind photo of Maura Higgins and 'fame hungry' Kai and why Pete Wicks is 'playing with fire' by dealing a 'fresh blow' to Jowita, insiders tell GRANT TUCKER
 - [https://www.dailymail.co.uk/tvshowbiz/article-13988893/Inside-story-Strictly-love-triangle-Truth-photo-Maura-Higgins-fame-hungry-Kai-Pete-Wicks-playing-fire-dealing-fresh-blow-Jowita-insiders-tell-GRANT-TUCKER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13988893/Inside-story-Strictly-love-triangle-Truth-photo-Maura-Higgins-fame-hungry-Kai-Pete-Wicks-playing-fire-dealing-fresh-blow-Jowita-insiders-tell-GRANT-TUCKER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:56:38+00:00

As Maura Higgins stepped on to the red carpet at Monday night's Pride of Britain Awards, all eyes were on her.

## Inside story of how Ozempic decimated the diet industry: Women are bragging about how fantastic they feel, lying about weight to 'score' the jab... and say they'll NEVER return to the misery of soups and shakes
 - [https://www.dailymail.co.uk/femail/article-13988759/Inside-story-Ozempic-decimated-diet-industry-Women-bragging-fantastic-feel-lying-weight-score-jab-say-theyll-NEVER-return-misery-soups-shakes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13988759/Inside-story-Ozempic-decimated-diet-industry-Women-bragging-fantastic-feel-lying-weight-score-jab-say-theyll-NEVER-return-misery-soups-shakes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:55:36+00:00

Earlier this month, WeightWatchers made the extraordinary announcement that it would be offering its own version of the 'fat jab' Ozempic.

## STEPHEN GLOVER: Kemi is fresh and formidable - and you wouldn't want to mess with her. That's why she's the right person to take on this sly, mendacious government
 - [https://www.dailymail.co.uk/debate/article-13988475/STEPHEN-GLOVER-Kemi-fresh-formidable-wouldnt-want-mess-Thats-shes-right-person-sly-mendacious-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13988475/STEPHEN-GLOVER-Kemi-fresh-formidable-wouldnt-want-mess-Thats-shes-right-person-sly-mendacious-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:55:11+00:00

The Tory leadership contest is approaching its final lap, and it can't honestly be said that it has so far caught the imagination of the British people.

## Only Connect viewers 'forced to mute' show after just seconds as they brand host Victoria Coren Mitchell's 'awful' intro the 'worst 30 seconds of their week'
 - [https://www.dailymail.co.uk/tv/article-13990075/Only-Connect-viewers-forced-mute-just-seconds-brand-host-Victoria-Coren-Mitchells-awful-intro-worst-30-seconds-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tv/article-13990075/Only-Connect-viewers-forced-mute-just-seconds-brand-host-Victoria-Coren-Mitchells-awful-intro-worst-30-seconds-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:53:04+00:00

Only Connect viewers complained that they were 'forced to mute' the show after just seconds on Tuesday.

## New York medics report epidemic of 'scromiting' - a reaction to cannabis that causes such severe symptoms it puts people in hospital
 - [https://www.dailymail.co.uk/health/article-13987209/New-York-medics-epidemic-scromiting-cannabis-symptoms-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13987209/New-York-medics-epidemic-scromiting-cannabis-symptoms-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:45:54+00:00

'Scromiting', which gets its name from sufferers' both 'screaming and vomiting' as they seek medical help is becoming an all-too-familiar site at emergency rooms, doctors say.

## Storyville: Dogs Of War review: Take him with a pinch of salt, but this old mercenary is highly entertaining, writes CHRISTOPHER STEVENS
 - [https://www.dailymail.co.uk/news/article-13990089/Storyville-Dogs-War-review-pinch-salt-old-mercenary-highly-entertaining-writes-CHRISTOPHER-STEVENS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13990089/Storyville-Dogs-War-review-pinch-salt-old-mercenary-highly-entertaining-writes-CHRISTOPHER-STEVENS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:39:08+00:00

This 90-minute film, featuring reconstructions as well as interviews and Dave's own archive video footage, centred on a plan to assassinate Colombian cocaine mogul Pablo Escobar in 1991

## Gardens could soon 'speak' to humans using AI to ask for water and say how they are feeling
 - [https://www.dailymail.co.uk/news/article-13989917/Gardens-speak-humans-AI-water-feeling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13989917/Gardens-speak-humans-AI-water-feeling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:29+00:00

They say talking to plants helps them grow - with King Charles a keen believer in the theory. And soon plants will 'talk' back thanks to AI that will allow gardeners to converse with their plot.

## Trinny Woodall reveals the VERY shocking x-rated comment chat show king Michael Parkinson made to her about a star after disastrous interview
 - [https://www.dailymail.co.uk/tvshowbiz/article-13987825/Trinny-Woodall-Michael-Parkinson-called-Meg-Ryan-c-word.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13987825/Trinny-Woodall-Michael-Parkinson-called-Meg-Ryan-c-word.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:29:06+00:00

Trinny Woodall has revealed that Michael Parkinson whispered to her that Meg Ryan was 'a c***' after their infamously icy interview in 2003.

## Sam Smith puts on a leggy display in black shorts teamed with a pink shirt as they head for a leisurely lunch with pals in New York
 - [https://www.dailymail.co.uk/tvshowbiz/article-13989967/Sam-Smith-leggy-display-shorts-lunch-New-York.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13989967/Sam-Smith-leggy-display-shorts-lunch-New-York.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:19:45+00:00

Sam Smith put on a leggy display on Tuesday as they headed for a leisurely lunch with pals in West Village, Manhattan.

## Viral college football fan Grant Walther breaks his silence and asks Matthew McConaughey to shave the hair that made him famous
 - [https://www.dailymail.co.uk/sport/college-football/article-13989919/Viral-college-football-fan-Grant-Walther-breaks-silence-asks-Matthew-McConaughey-shave-hair-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/college-football/article-13989919/Viral-college-football-fan-Grant-Walther-breaks-silence-asks-Matthew-McConaughey-shave-hair-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:09:01+00:00

The 20-year-old, who is studying government in Austin, opened up on his remarkable rise to internet fame which has seen him compared to to Butthead and country legend Conway Twitty.

## DAILY MAIL COMMENT: The Martyn Blake case raises troubling questions
 - [https://www.dailymail.co.uk/debate/article-13989925/DAILY-MAIL-COMMENT-Martyn-Blake-case-raises-troubling-questions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13989925/DAILY-MAIL-COMMENT-Martyn-Blake-case-raises-troubling-questions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:08:32+00:00

DAILY MAIL COMMENT: The first test any criminal case must pass before being sent to trial is that there is enough evidence to provide 'a realistic prospect of conviction'.

## Great British Bake Off viewers hail Nelly as 'the biggest icon the tent has ever seen' and a 'queen of style' as she dons a beret for pastry week
 - [https://www.dailymail.co.uk/tv/article-13989873/Great-British-Bake-viewers-hail-Nelly-biggest-icon-tent-seen-queen-style-dons-beret-pastry-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tv/article-13989873/Great-British-Bake-viewers-hail-Nelly-biggest-icon-tent-seen-queen-style-dons-beret-pastry-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:04:57+00:00

Great British Bake Off viewers hailed Nelly as 'the biggest icon the tent has ever seen' as the latest episode aired on Tuesday night.

## Weight loss, braces, teeth whitening and a whole lot of needles: Inside Sam Burgess and Lucy Graham's wedding glow up
 - [https://www.dailymail.co.uk/tvshowbiz/article-13989149/Sam-Burgess-Lucy-Graham-wedding-transformation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13989149/Sam-Burgess-Lucy-Graham-wedding-transformation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:04:53+00:00

Sam Burgess and his wife Lucy Graham were literally glowing when they got married in Rome, Italy on Sunday.

## MAFS UK star Holly begs producers to 'get her out of here' as she goes home following explosive argument with husband Alex
 - [https://www.dailymail.co.uk/tv/article-13989787/MAFS-UK-star-Holly-begs-producers-goes-home-following-explosive-argument-husband-Alex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tv/article-13989787/MAFS-UK-star-Holly-begs-producers-goes-home-following-explosive-argument-husband-Alex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:03:58+00:00

The couple have had a rocky journey throughout the process, but seemed to be back on track until Alex erupted during the last commitment ceremony and lashed out at several of the woman.

## Cats go against babies in a word association game devised by scientists - but WHO came out on top?
 - [https://www.dailymail.co.uk/news/article-13989941/Cats-against-babies-word-association-game-devised-scientists-came-top.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13989941/Cats-against-babies-word-association-game-devised-scientists-came-top.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-10-23T00:02:35+00:00

A small team of animal scientists at Azabu University in Japan have found that common house cats are capable of linking human words with images without prompting.

