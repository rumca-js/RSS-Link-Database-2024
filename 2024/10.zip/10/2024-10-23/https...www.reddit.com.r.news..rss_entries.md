# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## North Korean troops are in Russia, US defense secretary says
 - [https://www.reddit.com/r/news/comments/1ga9sjs/north_korean_troops_are_in_russia_us_defense](https://www.reddit.com/r/news/comments/1ga9sjs/north_korean_troops_are_in_russia_us_defense)
 - RSS feed: $source
 - date published: 2024-10-23T12:51:48+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/00genericname00"> /u/00genericname00 </a> <br/> <span><a href="https://www.reuters.com/world/north-korean-troops-russia-us-defense-secretary-says-2024-10-23/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ga9sjs/north_korean_troops_are_in_russia_us_defense/">[comments]</a></span>

## City: Police had no constitutional duty to protect murder victim
 - [https://www.reddit.com/r/news/comments/1ga7z9o/city_police_had_no_constitutional_duty_to_protect](https://www.reddit.com/r/news/comments/1ga7z9o/city_police_had_no_constitutional_duty_to_protect)
 - RSS feed: $source
 - date published: 2024-10-23T11:16:20+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/addled_and_old"> /u/addled_and_old </a> <br/> <span><a href="https://iowacapitaldispatch.com/2024/10/17/city-police-had-no-constitutional-duty-to-protect-murder-victim/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ga7z9o/city_police_had_no_constitutional_duty_to_protect/">[comments]</a></span>

## Six men jailed for role in 'gruesome' castration and 'human butchery' ring can appeal their sentences, court rules
 - [https://www.reddit.com/r/news/comments/1ga6olo/six_men_jailed_for_role_in_gruesome_castration](https://www.reddit.com/r/news/comments/1ga6olo/six_men_jailed_for_role_in_gruesome_castration)
 - RSS feed: $source
 - date published: 2024-10-23T09:52:17+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/One_Psychology_"> /u/One_Psychology_ </a> <br/> <span><a href="https://www.lbc.co.uk/news/six-men-jailed-for-role-in-gruesome-castration-and-human-butchery-ring-appeal/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ga6olo/six_men_jailed_for_role_in_gruesome_castration/">[comments]</a></span>

## Boeing-made communications satellite breaks up in space
 - [https://www.reddit.com/r/news/comments/1ga3rqq/boeingmade_communications_satellite_breaks_up_in](https://www.reddit.com/r/news/comments/1ga3rqq/boeingmade_communications_satellite_breaks_up_in)
 - RSS feed: $source
 - date published: 2024-10-23T06:18:19+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Superbuddhapunk"> /u/Superbuddhapunk </a> <br/> <span><a href="https://www.bbc.co.uk/news/articles/ce8d886l028o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ga3rqq/boeingmade_communications_satellite_breaks_up_in/">[comments]</a></span>

## Dodgers Legendary Pitcher Fernando Valenzuela Dies 63
 - [https://www.reddit.com/r/news/comments/1ga1cdn/dodgers_legendary_pitcher_fernando_valenzuela](https://www.reddit.com/r/news/comments/1ga1cdn/dodgers_legendary_pitcher_fernando_valenzuela)
 - RSS feed: $source
 - date published: 2024-10-23T03:46:53+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/francethefifth"> /u/francethefifth </a> <br/> <span><a href="https://www.espn.com/mlb/story/_/id/41952316/dodgers-legendary-pitcher-fernando-valenzuela-dies-63">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ga1cdn/dodgers_legendary_pitcher_fernando_valenzuela/">[comments]</a></span>

## Target cutting prices on more than 2,000 items heading into the holiday season
 - [https://www.reddit.com/r/news/comments/1ga0t4y/target_cutting_prices_on_more_than_2000_items](https://www.reddit.com/r/news/comments/1ga0t4y/target_cutting_prices_on_more_than_2000_items)
 - RSS feed: $source
 - date published: 2024-10-23T03:16:50+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/jackiehauer24"> /u/jackiehauer24 </a> <br/> <span><a href="https://www.nbcnews.com/business/consumer/target-cutting-prices-2000-items-heading-holiday-season-rcna176542">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ga0t4y/target_cutting_prices_on_more_than_2000_items/">[comments]</a></span>

## Frontier, Spirit Airlines revive merger talks, WSJ reports
 - [https://www.reddit.com/r/news/comments/1g9ylq7/frontier_spirit_airlines_revive_merger_talks_wsj](https://www.reddit.com/r/news/comments/1g9ylq7/frontier_spirit_airlines_revive_merger_talks_wsj)
 - RSS feed: $source
 - date published: 2024-10-23T01:21:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Panaka"> /u/Panaka </a> <br/> <span><a href="https://www.reuters.com/markets/deals/frontier-spirit-airlines-revive-merger-talks-wsj-reports-2024-10-23/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g9ylq7/frontier_spirit_airlines_revive_merger_talks_wsj/">[comments]</a></span>

## Seoul demands North Korean troops leave Russia immediately
 - [https://www.reddit.com/r/news/comments/1g9xf4y/seoul_demands_north_korean_troops_leave_russia](https://www.reddit.com/r/news/comments/1g9xf4y/seoul_demands_north_korean_troops_leave_russia)
 - RSS feed: $source
 - date published: 2024-10-23T00:23:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/PlayShelf"> /u/PlayShelf </a> <br/> <span><a href="https://www.bbc.co.uk/news/articles/c625p2wy3q7o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g9xf4y/seoul_demands_north_korean_troops_leave_russia/">[comments]</a></span>

