# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Full circle with myopia
 - [https://seths.blog/2024/10/full-circle-with-myopia](https://seths.blog/2024/10/full-circle-with-myopia)
 - RSS feed: $source
 - date published: 2024-10-23T09:03:00+00:00

In 1983, an old article from the Harvard Business Review changed my life. In 1960, Ted Levitt, a professor at HBS, wrote the most popular article in the Review&#8217;s history. Called Marketing Myopia, it described a different way of thinking about change and marketing. I was a (very) young MBA student at Stanford and somehow [&#8230;]

