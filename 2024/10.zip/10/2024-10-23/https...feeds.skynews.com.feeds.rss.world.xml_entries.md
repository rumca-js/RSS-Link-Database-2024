# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## North Korea sending thousands of troops to help Russia, says South Korea
 - [https://news.sky.com/story/north-korea-sending-thousands-of-troops-to-help-russia-in-war-with-ukraine-says-south-korea-13239504](https://news.sky.com/story/north-korea-sending-thousands-of-troops-to-help-russia-in-war-with-ukraine-says-south-korea-13239504)
 - RSS feed: $source
 - date published: 2024-10-23T11:32:00+00:00

North Korea has sent 3,000 troops to help Russia in its war against Ukraine and is planning to send thousands more, South Korea has said.

## Three dead after migrant boat with dozens on board sinks in Channel
 - [https://news.sky.com/story/three-dead-after-migrant-boat-with-50-on-board-sinks-in-channel-13239439](https://news.sky.com/story/three-dead-after-migrant-boat-with-50-on-board-sinks-in-channel-13239439)
 - RSS feed: $source
 - date published: 2024-10-23T09:29:00+00:00

Three people have died after an inflatable boat carrying migrants sank in the Channel, French maritime authorities said.

## Two dead after migrant boat with dozens on board sinks in Channel
 - [https://news.sky.com/story/two-dead-after-migrant-boat-with-50-on-board-sinks-in-channel-13239439](https://news.sky.com/story/two-dead-after-migrant-boat-with-50-on-board-sinks-in-channel-13239439)
 - RSS feed: $source
 - date published: 2024-10-23T09:29:00+00:00

Two people have died after a migrant boat sank in the Channel, French maritime authorities said.

## Husband 'destroyed' and betrayed me, says woman at centre of France mass rape trial
 - [https://news.sky.com/story/gisele-pelicot-husband-destroyed-my-life-and-betrayed-me-says-woman-at-centre-of-mass-rape-trial-which-has-shocked-france-13239438](https://news.sky.com/story/gisele-pelicot-husband-destroyed-my-life-and-betrayed-me-says-woman-at-centre-of-mass-rape-trial-which-has-shocked-france-13239438)
 - RSS feed: $source
 - date published: 2024-10-23T09:27:00+00:00

The woman at the centre of a rape trial that has shocked France has spoken in court for the first time, saying she can't comprehend how the "perfect man" has destroyed her life.

## Woman at centre of France rape trial set to address court
 - [https://news.sky.com/story/gisele-pelicot-woman-at-centre-of-france-rape-trial-expected-to-address-court-13239438](https://news.sky.com/story/gisele-pelicot-woman-at-centre-of-france-rape-trial-expected-to-address-court-13239438)
 - RSS feed: $source
 - date published: 2024-10-23T09:27:00+00:00

The woman at the centre of a rape trial that has shocked France is expected to address the court today.

## Scurvy 'is re-emerging' due to modern diets and cost of living crisis
 - [https://news.sky.com/story/scurvy-is-re-emerging-due-to-modern-diets-and-cost-of-living-pressures-doctors-in-australia-reveal-13239399](https://news.sky.com/story/scurvy-is-re-emerging-due-to-modern-diets-and-cost-of-living-pressures-doctors-in-australia-reveal-13239399)
 - RSS feed: $source
 - date published: 2024-10-23T07:41:00+00:00

Scurvy, a disease common between the 16th and 18th centuries which results from vitamin C deficiency, is re-emerging, according to doctors in Australia.&#160; 

## Harris prepared to challenge Trump if he prematurely declares victory, as he calls her 'lazy' - with two weeks to go
 - [https://news.sky.com/story/harris-prepared-to-challenge-trump-if-he-prematurely-declares-victory-as-he-calls-her-lazy-with-two-weeks-to-go-13239343](https://news.sky.com/story/harris-prepared-to-challenge-trump-if-he-prematurely-declares-victory-as-he-calls-her-lazy-with-two-weeks-to-go-13239343)
 - RSS feed: $source
 - date published: 2024-10-23T02:36:00+00:00

With just two weeks remaining before the US 2024 presidential election, the main players were out campaigning in key battleground states to sway the vote in their party's favour.

