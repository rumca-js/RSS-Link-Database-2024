# Source:Simon Willison's Weblog, URL:https://simonwillison.net/atom/everything, language:en-us

## Running prompts against images and PDFs with Google Gemini
 - [https://simonwillison.net/2024/Oct/23/prompt-gemini/#atom-everything](https://simonwillison.net/2024/Oct/23/prompt-gemini/#atom-everything)
 - RSS feed: $source
 - date published: 2024-10-23T18:25:07+00:00

None

## Using Rust in non-Rust servers to improve performance
 - [https://simonwillison.net/2024/Oct/23/using-rust-in-non-rust-servers/#atom-everything](https://simonwillison.net/2024/Oct/23/using-rust-in-non-rust-servers/#atom-everything)
 - RSS feed: $source
 - date published: 2024-10-23T15:45:42+00:00

None

## Quoting Model Card Addendum: Claude 3.5 Haiku and Upgraded Sonnet
 - [https://simonwillison.net/2024/Oct/23/model-card/#atom-everything](https://simonwillison.net/2024/Oct/23/model-card/#atom-everything)
 - RSS feed: $source
 - date published: 2024-10-23T04:23:57+00:00

None

## Claude Artifact Runner
 - [https://simonwillison.net/2024/Oct/23/claude-artifact-runner/#atom-everything](https://simonwillison.net/2024/Oct/23/claude-artifact-runner/#atom-everything)
 - RSS feed: $source
 - date published: 2024-10-23T02:34:24+00:00

None

## Quoting Deirdre Bosa
 - [https://simonwillison.net/2024/Oct/23/cnbc/#atom-everything](https://simonwillison.net/2024/Oct/23/cnbc/#atom-everything)
 - RSS feed: $source
 - date published: 2024-10-23T01:26:34+00:00

None

## Quoting Mike Isaac and Erin Griffith
 - [https://simonwillison.net/2024/Oct/23/mike-isaac-and-erin-griffith/#atom-everything](https://simonwillison.net/2024/Oct/23/mike-isaac-and-erin-griffith/#atom-everything)
 - RSS feed: $source
 - date published: 2024-10-23T01:20:31+00:00

None

