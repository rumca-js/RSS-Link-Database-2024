# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## 25 zatrzymanych i dziesiątki interwencji dzięki monitoringowi w 2 tygodnie. Były taniec na fontannie i załatwianie się do niej
 - [https://epoznan.pl/news-news-156147-25_zatrzymanych_i_dziesiatki_interwencji_dzieki_monitoringowi_w_2_tygodnie_byly_taniec_na_fontannie_i_zalatwianie_sie_do_niej?rss=1](https://epoznan.pl/news-news-156147-25_zatrzymanych_i_dziesiatki_interwencji_dzieki_monitoringowi_w_2_tygodnie_byly_taniec_na_fontannie_i_zalatwianie_sie_do_niej?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T13:50:01.767253+00:00

W Poznaniu strażnicy miejscy i policjanci zdecydowanie mają co robić.

## Kolejni zatrzymani w związku z korupcją w lokalnym samorządzie
 - [https://epoznan.pl/news-news-156149-kolejni_zatrzymani_w_zwiazku_z_korupcja_w_lokalnym_samorzadzie?rss=1](https://epoznan.pl/news-news-156149-kolejni_zatrzymani_w_zwiazku_z_korupcja_w_lokalnym_samorzadzie?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T13:50:01.605327+00:00

Chodzi o sprawę z Opalenicy.

## Pobicie w poznańskim pasażu handlowym. Poznajesz go?
 - [https://epoznan.pl/news-news-156145-pobicie_w_poznanskim_pasazu_handlowym_poznajesz_go?rss=1](https://epoznan.pl/news-news-156145-pobicie_w_poznanskim_pasazu_handlowym_poznajesz_go?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T13:50:01.408558+00:00

Do zdarzenia doszło w lipcu.

## Jedna z poznańskich ulic przejdzie dużą metamorfozę. Prace mają tu trwać do połowy grudnia
 - [https://epoznan.pl/news-news-156151-jedna_z_poznanskich_ulic_przejdzie_duza_metamorfoze_prace_maja_tu_trwac_do_polowy_grudnia?rss=1](https://epoznan.pl/news-news-156151-jedna_z_poznanskich_ulic_przejdzie_duza_metamorfoze_prace_maja_tu_trwac_do_polowy_grudnia?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T13:50:01.278158+00:00

Przebudowa ulicy planowana jest na osiedlu Warszawskim.

## Pod Poznaniem zlikwidowano linię produkcyjną mefedronu. Zatrzymano 2 osoby
 - [https://epoznan.pl/news-news-156143-pod_poznaniem_zlikwidowano_linie_produkcyjna_mefedronu_zatrzymano_2_osoby?rss=1](https://epoznan.pl/news-news-156143-pod_poznaniem_zlikwidowano_linie_produkcyjna_mefedronu_zatrzymano_2_osoby?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T12:44:58.126057+00:00

Policjanci od miesięcy zajmowali się tą sprawą.

## Magda Gessler z rewolucjami w regionie. Są szczegóły
 - [https://epoznan.pl/news-news-156146-magda_gessler_z_rewolucjami_w_regionie_sa_szczegoly?rss=1](https://epoznan.pl/news-news-156146-magda_gessler_z_rewolucjami_w_regionie_sa_szczegoly?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T12:44:58.010351+00:00

Okazuje się, że wcale nie realizuje kolejnego odcinka swojego programu w Kaliszu.

## Jest ostrzeżenie meteo dla całej Wielkopolski!
 - [https://epoznan.pl/news-news-156142-jest_ostrzezenie_meteo_dla_calej_wielkopolski?rss=1](https://epoznan.pl/news-news-156142-jest_ostrzezenie_meteo_dla_calej_wielkopolski?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T12:44:57.849212+00:00

Może być niebezpiecznie.

## Nowy mural w mieście
 - [https://epoznan.pl/news-news-156148-nowy_mural_w_miescie?rss=1](https://epoznan.pl/news-news-156148-nowy_mural_w_miescie?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T12:44:57.599524+00:00

Gdzie powstał?

## Driftował nocą autem na rynku, nie dawał ludziom spać. Gruzin trafił w ręce Straży Granicznej, niezwłocznie opuści Polskę
 - [https://epoznan.pl/news-news-156144-driftowal_noca_autem_na_rynku_nie_dawal_ludziom_spac_gruzin_trafil_w_rece_strazy_granicznej_niezwlocznie_opusci_polske?rss=1](https://epoznan.pl/news-news-156144-driftowal_noca_autem_na_rynku_nie_dawal_ludziom_spac_gruzin_trafil_w_rece_strazy_granicznej_niezwlocznie_opusci_polske?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T12:44:57.337649+00:00

O tej sprawie pisaliśmy już na epoznan.pl.

## Kolejny &quot;Trzeźwy poranek&quot;. Sprawdzono 32 tysiące kierowców, blisko 100 jechało na podwójnym gazie. Sporo w Poznaniu i okolicy
 - [https://epoznan.pl/news-news-156131-kolejny_trzezwy_poranek_sprawdzono_32_tysiace_kierowcow_blisko_100_jechalo_na_podwojnym_gazie_sporo_w_poznaniu_i_okolicy?rss=1](https://epoznan.pl/news-news-156131-kolejny_trzezwy_poranek_sprawdzono_32_tysiace_kierowcow_blisko_100_jechalo_na_podwojnym_gazie_sporo_w_poznaniu_i_okolicy?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T11:40:05.165157+00:00

Tak jak wcześniej zapowiadali policjanci, akcje &quot;Trzeźwość&quot; odbywają się cyklicznie.

## Mamy nowy ranking najbardziej smogowych miejscowości w kraju. W top 12 aż 2 miasta z Wielkopolski
 - [https://epoznan.pl/news-news-156140-mamy_nowy_ranking_najbardziej_smogowych_miejscowosci_w_kraju_w_top_12_az_2_miasta_z_wielkopolski?rss=1](https://epoznan.pl/news-news-156140-mamy_nowy_ranking_najbardziej_smogowych_miejscowosci_w_kraju_w_top_12_az_2_miasta_z_wielkopolski?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T11:40:04.697727+00:00

Nie jest to Poznań.

## Dziecko o włos od potrącenia na pasach przez motocyklistę. Mężczyznę ustalono, dostał 30 punktów karnych
 - [https://epoznan.pl/news-news-156134-dziecko_o_wlos_od_potracenia_na_pasach_przez_motocykliste_mezczyzne_ustalono_dostal_30_punktow_karnych?rss=1](https://epoznan.pl/news-news-156134-dziecko_o_wlos_od_potracenia_na_pasach_przez_motocykliste_mezczyzne_ustalono_dostal_30_punktow_karnych?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T10:34:50.221870+00:00

A to nie wszystko.

## Justyna Socha skazana w sprawie postu o &quot;cichej eutanazji&quot;. Ma wykonywać prace społeczne
 - [https://epoznan.pl/news-news-156141-justyna_socha_skazana_w_sprawie_postu_o_cichej_eutanazji_ma_wykonywac_prace_spoleczne?rss=1](https://epoznan.pl/news-news-156141-justyna_socha_skazana_w_sprawie_postu_o_cichej_eutanazji_ma_wykonywac_prace_spoleczne?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T10:34:50.096786+00:00

Chodzi o liderkę stowarzyszenia &quot;STOP NOP&quot;.

## W Poznaniu otwierają nowy sklep. Będzie promocja na iPhone&#039;y i iPady
 - [https://epoznan.pl/news-news-156135-w_poznaniu_otwieraja_nowy_sklep_bedzie_promocja_na_iphoney_i_ipady?rss=1](https://epoznan.pl/news-news-156135-w_poznaniu_otwieraja_nowy_sklep_bedzie_promocja_na_iphoney_i_ipady?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T10:34:49.984488+00:00

W Starym Browarze otwiera się iSpot.

## Rekordowe wyniki Term Maltańskich. Zarobiły na czysto 16 milionów złotych
 - [https://epoznan.pl/news-news-156136-rekordowe_wyniki_term_maltanskich_zarobily_na_czysto_16_milionow_zlotych?rss=1](https://epoznan.pl/news-news-156136-rekordowe_wyniki_term_maltanskich_zarobily_na_czysto_16_milionow_zlotych?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T09:29:35.072650+00:00

W Krajowym Rejestrze Sądowym złożono sprawozdanie finansowe Term Maltańskich za 2023 rok.

## Zatrzymanie ratownika wodnego na pływalni pod Poznaniem. &quot;Sprawa o charakterze kryminalnym&quot;
 - [https://epoznan.pl/news-news-156137-zatrzymanie_ratownika_wodnego_na_plywalni_pod_poznaniem_sprawa_o_charakterze_kryminalnym?rss=1](https://epoznan.pl/news-news-156137-zatrzymanie_ratownika_wodnego_na_plywalni_pod_poznaniem_sprawa_o_charakterze_kryminalnym?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T09:29:34.982214+00:00

W Koziegłowach.

## Policja &quot;cały dzień i noc&quot; na sygnałach na poznańskim przystanku. Przez... granat
 - [https://epoznan.pl/news-news-156138-policja_caly_dzien_i_noc_na_sygnalach_na_poznanskim_przystanku_przez_granat?rss=1](https://epoznan.pl/news-news-156138-policja_caly_dzien_i_noc_na_sygnalach_na_poznanskim_przystanku_przez_granat?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T09:29:34.893752+00:00

Widokiem funkcjonariuszy na ulicy Wojska Polskiego zainteresował się nasz Czytelnik.

## Nowy market ma się pojawić w poznańskim centrum handlowym. Będzie przebudowa
 - [https://epoznan.pl/news-news-156133-nowy_market_ma_sie_pojawic_w_poznanskim_centrum_handlowym_bedzie_przebudowa?rss=1](https://epoznan.pl/news-news-156133-nowy_market_ma_sie_pojawic_w_poznanskim_centrum_handlowym_bedzie_przebudowa?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T09:29:34.804205+00:00

Chodzi o Górczyńskie Centrum Handlowe przy Głogowskiej / Winklera.

## W Poznaniu uczczono 68. rocznicę wybuchu Powstania Węgierskiego
 - [https://epoznan.pl/news-news-156139-w_poznaniu_uczczono_68_rocznice_wybuchu_powstania_wegierskiego?rss=1](https://epoznan.pl/news-news-156139-w_poznaniu_uczczono_68_rocznice_wybuchu_powstania_wegierskiego?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T09:29:34.703247+00:00

Kwiaty złożono pod tablicami upamiętniającymi Petera Mansfelda i Romka Strzałkowskiego.

## Chiński gigant miał postawić showroom na kampusie UAM. Samorząd studentów zaprotestował, wydarzenie się nie odbędzie
 - [https://epoznan.pl/news-news-156130-chinski_gigant_mial_postawic_showroom_na_kampusie_uam_samorzad_studentow_zaprotestowal_wydarzenie_sie_nie_odbedzie?rss=1](https://epoznan.pl/news-news-156130-chinski_gigant_mial_postawic_showroom_na_kampusie_uam_samorzad_studentow_zaprotestowal_wydarzenie_sie_nie_odbedzie?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T08:24:38.654614+00:00

Chodzi o SHEIN.

## Znany influencer miał wypadek w Poznaniu. Szuka kobiety, która mu pomogła
 - [https://epoznan.pl/news-news-156127-znany_influencer_mial_wypadek_w_poznaniu_szuka_kobiety_ktora_mu_pomogla?rss=1](https://epoznan.pl/news-news-156127-znany_influencer_mial_wypadek_w_poznaniu_szuka_kobiety_ktora_mu_pomogla?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T08:24:38.235337+00:00

Chodzi o Marka Hoffmanna.

## Znany wokalista zginął tragicznie. Chcą go pożegnać w Poznaniu
 - [https://epoznan.pl/news-news-156125-znany_wokalista_zginal_tragicznie_chca_go_pozegnac_w_poznaniu?rss=1](https://epoznan.pl/news-news-156125-znany_wokalista_zginal_tragicznie_chca_go_pozegnac_w_poznaniu?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T07:15:02.081811+00:00

Mowa o zaledwie 31-letnim byłym wokaliście zespołu One Direction.

## Korek na trasie S5 pod Poznaniem. Blokada po wypadku!
 - [https://epoznan.pl/news-news-156128-korek_na_trasie_s5_pod_poznaniem_blokada_po_wypadku?rss=1](https://epoznan.pl/news-news-156128-korek_na_trasie_s5_pod_poznaniem_blokada_po_wypadku?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T07:15:01.989823+00:00

Do zdarzenia doszło między węzłami Stęszew i Konarzewo.

## Zwężenie na trasie S11 pod Poznaniem. Korki!
 - [https://epoznan.pl/news-news-156129-zwezenie_na_trasie_s11_pod_poznaniem_korki?rss=1](https://epoznan.pl/news-news-156129-zwezenie_na_trasie_s11_pod_poznaniem_korki?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T07:15:01.883587+00:00

Chodzi o trasę Kórnik - Poznań.

## Piękny efekt halo nad miastem. Kolejny raz w ostatnich dniach
 - [https://epoznan.pl/news-news-156123-piekny_efekt_halo_nad_miastem_kolejny_raz_w_ostatnich_dniach?rss=1](https://epoznan.pl/news-news-156123-piekny_efekt_halo_nad_miastem_kolejny_raz_w_ostatnich_dniach?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T06:09:45.302576+00:00

Na zjawisko zwrócili uwagę nasi Czytelnicy.

## Nietypowa konstrukcja nad sygnalizatorami. Wiemy co to takiego
 - [https://epoznan.pl/news-news-156124-nietypowa_konstrukcja_nad_sygnalizatorami_wiemy_co_to_takiego?rss=1](https://epoznan.pl/news-news-156124-nietypowa_konstrukcja_nad_sygnalizatorami_wiemy_co_to_takiego?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T06:09:45.214527+00:00

Pojawiła się przy tunelu na granicy Poznania i gminy Komorniki.

## Potrącenie rowerzystki na Strzeszynie. &quot;Brak przejazdu&quot;
 - [https://epoznan.pl/news-news-156126-potracenie_rowerzystki_na_strzeszynie_brak_przejazdu?rss=1](https://epoznan.pl/news-news-156126-potracenie_rowerzystki_na_strzeszynie_brak_przejazdu?rss=1)
 - RSS feed: $source
 - date published: 2024-10-23T06:09:45.111924+00:00

O sprawie poinformował nas Czytelnik.

