# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## SAS Rogue Regiment Review
 - [https://www.boardgamequest.com/sas-rogue-regiment-review](https://www.boardgamequest.com/sas-rogue-regiment-review)
 - RSS feed: $source
 - date published: 2024-10-23T11:43:48+00:00

<img width="640" height="640" src="https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment-1024x1024.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="SAS Rogue Regiment" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" link_thumbnail="" decoding="async" fetchpriority="high" srcset="https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment-1024x1024.jpg 1024w, https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment-300x300.jpg 300w, https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment-150x150.jpg 150w, https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment-768x768.jpg 768w, https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment-640x640.jpg 640w, https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment-1280x1280.jpg 1280w, https://www.boardgamequest.com/wp-content/uploads/2024/10/SAS-Rogue-Regiment.jpg 1500w" si

