# Source:Eurogamer.net Latest Articles Feed, URL:https://www.eurogamer.net/feed, language:en-gb

## The Sims 4 ghostly update puts WooHoo-ing the Grim Reaper back on the table
 - [https://www.eurogamer.net/the-sims-4-ghostly-update-puts-woohoo-ing-the-grim-reaper-back-on-the-table](https://www.eurogamer.net/the-sims-4-ghostly-update-puts-woohoo-ing-the-grim-reaper-back-on-the-table)
 - RSS feed: $source
 - date published: 2024-10-23T13:33:43+00:00

<img src="https://assetsio.gnwcdn.com/The-Sims-4-Grim-Reaper-surrounded-by-love-hearts.jpg?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p><a data-keyword="true" href="https://www.eurogamer.net/games/the-sims-4">The Sims 4</a> team has released an appropriately-timed spooky update for its life-simulation game, which focuses on the afterlife, and allows us to once again get down and dirty with the Grim Reaper.</p> <p><a href="https://www.eurogamer.net/the-sims-4-ghostly-update-puts-woohoo-ing-the-grim-reaper-back-on-the-table">Read more</a></p>

## No Man's Sky's The Cursed is a spooky expedition for Halloween set in a collapsing reality
 - [https://www.eurogamer.net/no-mans-skys-the-cursed-is-a-spooky-expedition-for-halloween-set-in-a-collapsing-reality](https://www.eurogamer.net/no-mans-skys-the-cursed-is-a-spooky-expedition-for-halloween-set-in-a-collapsing-reality)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:00+00:00

<img src="https://assetsio.gnwcdn.com/nms-cursed2.jpg?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p>
We've only just said farewell to <a data-keyword="true" href="https://www.eurogamer.net/games/no-mans-sky">No Man's Sky</a>'s <a href="https://www.eurogamer.net/no-mans-sky-gets-reel-in-new-aquarius-fishing-update">fishing-themed Aquarius expedition</a>, but already there's another here to take its place - and this time it's a special, spooky themed event straddling the boundary between one reality and the next.
</p> <p><a href="https://www.eurogamer.net/no-mans-skys-the-cursed-is-a-spooky-expedition-for-halloween-set-in-a-collapsing-reality">Read more</a></p>

## Nature-rekindling sandbox Towers of Aghasba gets early access release date
 - [https://www.eurogamer.net/nature-rekindling-sandbox-towers-of-aghasba-gets-early-access-release-date](https://www.eurogamer.net/nature-rekindling-sandbox-towers-of-aghasba-gets-early-access-release-date)
 - RSS feed: $source
 - date published: 2024-10-23T12:06:31+00:00

<img src="https://assetsio.gnwcdn.com/Towers-of-Aghasba_-Gameplay-Showcase-%2B-Release-Date-Announcement!-7-18-screenshot.png?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p>
Cast your mind back a month, and you may remember a promising-looking open-world sandbox popping up in <a href="https://www.eurogamer.net/everything-announced-sonys-playstation-state-of-play">Sony's September PlayStation State of Play</a>. That game was Towers of Aghasba, and it now has an early access release date for PC and PS5: 
</p> <p><a href="https://www.eurogamer.net/nature-rekindling-sandbox-towers-of-aghasba-gets-early-access-release-date">Read more</a></p>

## NCSoft suffers layoffs and cancels projects, including ultra-realistic thriller Project M
 - [https://www.eurogamer.net/ncsoft-suffers-layoffs-and-cancels-projects-including-ultra-realistic-thriller-project-m](https://www.eurogamer.net/ncsoft-suffers-layoffs-and-cancels-projects-including-ultra-realistic-thriller-project-m)
 - RSS feed: $source
 - date published: 2024-10-23T11:34:22+00:00

<img src="https://assetsio.gnwcdn.com/Screenshot-from-Project-M-trailer-showing-a-young-female-woman-with-dark-hair.jpg?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p>NCSoft has announced a reorganisation of its projects and staff, resulting in layoffs and the end of several games - including the promising and ultra-realistic-looking thriller Project M.</p> <p><a href="https://www.eurogamer.net/ncsoft-suffers-layoffs-and-cancels-projects-including-ultra-realistic-thriller-project-m">Read more</a></p>

## Amazon's God of War TV series lands new showrunner in former Battlestar Galactica executive producer
 - [https://www.eurogamer.net/amazons-god-of-war-tv-series-lands-new-showrunner-in-former-battlestar-galactica-executive-producer](https://www.eurogamer.net/amazons-god-of-war-tv-series-lands-new-showrunner-in-former-battlestar-galactica-executive-producer)
 - RSS feed: $source
 - date published: 2024-10-23T10:11:01+00:00

<img src="https://assetsio.gnwcdn.com/Kratos-and-Freya-in-God-of-War-Ragnarok.jpg?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p>Former Battlestar Galactica executive producer Ronald D. Moore has joined Amazon's God of War TV adaptation as the series' writer, executive producer and showrunner.</p> <p><a href="https://www.eurogamer.net/amazons-god-of-war-tv-series-lands-new-showrunner-in-former-battlestar-galactica-executive-producer">Read more</a></p>

## Four years after PS5's launch, Minecraft finally gets a native version
 - [https://www.eurogamer.net/four-years-after-ps5s-launch-minecraft-finally-gets-a-native-version](https://www.eurogamer.net/four-years-after-ps5s-launch-minecraft-finally-gets-a-native-version)
 - RSS feed: $source
 - date published: 2024-10-23T09:56:33+00:00

<img src="https://assetsio.gnwcdn.com/Bundles-of-Bravery-0-7-screenshot.png?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p>
PlayStation 5 will celebrate its fourth birthday in just a few days, and finally there's a native version of Minecraft available for it.
</p> <p><a href="https://www.eurogamer.net/four-years-after-ps5s-launch-minecraft-finally-gets-a-native-version">Read more</a></p>

## Ubisoft responds to report Prince of Persia: The Lost Crown development team disbanded
 - [https://www.eurogamer.net/ubisoft-responds-to-report-prince-of-persia-the-lost-crown-development-team-disbanded](https://www.eurogamer.net/ubisoft-responds-to-report-prince-of-persia-the-lost-crown-development-team-disbanded)
 - RSS feed: $source
 - date published: 2024-10-23T09:34:22+00:00

<img src="https://assetsio.gnwcdn.com/PrinceOfPersia_HERO.jpg?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p>
Ubisoft has responded to a report published yesterday that claimed <a data-keyword="true" href="https://www.eurogamer.net/games/prince-of-persia-the-lost-crown">Prince of Persia: The Lost Crown</a>'s team had been disbanded.
</p> <p><a href="https://www.eurogamer.net/ubisoft-responds-to-report-prince-of-persia-the-lost-crown-development-team-disbanded">Read more</a></p>

