# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Tech, Media & Telecom Roundup: Market Talk
 - [https://www.wsj.com/articles/tech-media-telecom-roundup-market-talk-7bd012aa?mod=rss_Technology](https://www.wsj.com/articles/tech-media-telecom-roundup-market-talk-7bd012aa?mod=rss_Technology)
 - RSS feed: $source
 - date published: 2024-10-23T04:35:00+00:00

Find insight on iQiyi, Zomato, ZTE and more in the latest Market Talks covering Technology, Media and Telecom.

## Meet Hollywood's AI Doomsayer: Joseph Gordon-Levitt
 - [https://www.wsj.com/articles/meet-hollywoods-ai-doomsayer-joseph-gordon-levitt-27b82d69?mod=rss_Technology](https://www.wsj.com/articles/meet-hollywoods-ai-doomsayer-joseph-gordon-levitt-27b82d69?mod=rss_Technology)
 - RSS feed: $source
 - date published: 2024-10-23T00:47:00+00:00

The actor says AI companies use movies and TV to make money without fairly compensating actors and the industry should ‘get ahead of that flood.’

