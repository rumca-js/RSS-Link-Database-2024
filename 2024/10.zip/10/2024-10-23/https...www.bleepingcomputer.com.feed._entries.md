# Source:BleepingComputer, URL:https://www.bleepingcomputer.com/feed/, language:en-US

## Hackers exploit 52 zero-days on the first day of Pwn2Own Ireland
 - [https://www.bleepingcomputer.com/news/security/hackers-exploit-52-zero-days-on-the-first-day-of-pwn2own-ireland](https://www.bleepingcomputer.com/news/security/hackers-exploit-52-zero-days-on-the-first-day-of-pwn2own-ireland)
 - RSS feed: $source
 - date published: 2024-10-23T10:01:34+00:00

On the first day of Pwn2Own Ireland, participants demonstrated 52 zero-day vulnerabilities across a range of devices, earning a total of $486,250 in cash prizes. [...]

