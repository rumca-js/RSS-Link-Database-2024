# Source:Pakistan Observer, URL:https://pakobserver.net/feed, language:en-US

## Another Indian woman travels to Pakistan to marry love of her life
 - [https://pakobserver.net/another-indian-woman-travels-to-pakistan-to-marry-love-of-her-life](https://pakobserver.net/another-indian-woman-travels-to-pakistan-to-marry-love-of-her-life)
 - RSS feed: $source
 - date published: 2024-10-23T12:27:30+00:00

LAHORE – In another story that shows the power of love transcending borders, an Indian woman traveled alone to Lahore…

## Big Discount Offer on MG4 and MG ZS in Pakistan; Check full payment options here
 - [https://pakobserver.net/big-discount-offer-on-mg4-and-mg-zs-in-pakistan-check-full-payment-options-here](https://pakobserver.net/big-discount-offer-on-mg4-and-mg-zs-in-pakistan-check-full-payment-options-here)
 - RSS feed: $source
 - date published: 2024-10-23T11:43:08+00:00

MG4 was launched in Pakistan a year back, as the Chinese auto giant expanded its lineup. The compact electric vehicle…

## Gold prices in Pakistan climb to fresh high – Check latest rates on Oct 23
 - [https://pakobserver.net/gold-prices-in-pakistan-climb-to-fresh-high-check-latest-rates-on-oct-23](https://pakobserver.net/gold-prices-in-pakistan-climb-to-fresh-high-check-latest-rates-on-oct-23)
 - RSS feed: $source
 - date published: 2024-10-23T10:19:42+00:00

KARACHI – Gold prices in Pakistan continued to break all previous records amid rising global prices on Wednesday. According to…

## Nominated CJP Yahya meets outgoing CJP Isa, Justice Mansoor
 - [https://pakobserver.net/nominated-cjp-yahya-meets-outgoing-cjp-isa-justice-mansoor](https://pakobserver.net/nominated-cjp-yahya-meets-outgoing-cjp-isa-justice-mansoor)
 - RSS feed: $source
 - date published: 2024-10-23T10:17:37+00:00

ISLAMABAD &#8211; Chief Justice of Pakistan Qazi Faez Isa met with the nominated Chief Justice Yahya Afridi. The sources said…

## Pakistan announces playing XI for third Test against England
 - [https://pakobserver.net/pakistan-announces-playing-xi-for-third-test-against-england](https://pakobserver.net/pakistan-announces-playing-xi-for-third-test-against-england)
 - RSS feed: $source
 - date published: 2024-10-23T09:32:46+00:00

RAWALPINDI &#8211;  Pakistan on Wednesday announced its playing eleven for the third and final Test match against England. The third…

## New school timings in Punjab from Oct 28 to Jan 31 announced
 - [https://pakobserver.net/new-school-timings-in-punjab-from-oct-28-to-jan-31-announced](https://pakobserver.net/new-school-timings-in-punjab-from-oct-28-to-jan-31-announced)
 - RSS feed: $source
 - date published: 2024-10-23T09:21:46+00:00

LAHORE – The Punjab government has notified new timings for schools across the province amid worsening smog situation. Punjab Environmental…

## Mir Hamza ruled out of Rawalpindi Test against England
 - [https://pakobserver.net/mir-hamza-ruled-out-of-rawalpindi-test-against-england](https://pakobserver.net/mir-hamza-ruled-out-of-rawalpindi-test-against-england)
 - RSS feed: $source
 - date published: 2024-10-23T08:45:54+00:00

LAHORE &#8211; Pakistan&#8217;s fast bowler Mir Hamza has been ruled out of the Rawalpindi Test against England due to injury…

## Nadra NICOP fee update for Canada – October 2024
 - [https://pakobserver.net/nadra-nicop-fee-update-for-canada-october-2024](https://pakobserver.net/nadra-nicop-fee-update-for-canada-october-2024)
 - RSS feed: $source
 - date published: 2024-10-23T08:39:50+00:00

LAHORE – National Database Registration Authority (NADRA) issues National Identity Card for Overseas Pakistanis (NICOP) to Pakistani nationals who are…

## CM Maryam visits PIC, inquires after patients
 - [https://pakobserver.net/cm-maryam-visits-pic-inquires-after-patients](https://pakobserver.net/cm-maryam-visits-pic-inquires-after-patients)
 - RSS feed: $source
 - date published: 2024-10-23T08:35:14+00:00

LAHORE &#8211; Punjab Chief Minister Maryam Nawaz Sharif on Wednesday visited the Punjab Institute of Cardiology (PIC) and inquired after…

## MQM-P lawmaker Rana Ansar’s son dies in Karachi accident
 - [https://pakobserver.net/mqm-p-lawmaker-rana-ansars-son-dies-in-karachi-accident](https://pakobserver.net/mqm-p-lawmaker-rana-ansars-son-dies-in-karachi-accident)
 - RSS feed: $source
 - date published: 2024-10-23T08:28:30+00:00

KARACHI – Muttahida Qaumi Movement-Pakistan (MQM-P) MNA Rana Ansar’s son died in a road accident in Karachi on Wednesday. The…

## PAF holds multinational air exercise Indus Shield 2024
 - [https://pakobserver.net/paf-holds-multinational-air-exercise-indus-shield-2024](https://pakobserver.net/paf-holds-multinational-air-exercise-indus-shield-2024)
 - RSS feed: $source
 - date published: 2024-10-23T08:16:01+00:00

KARACHI – Pakistan Air Force holds multinational air exercise Indus Shield 2024 involving Turkish, Saudi and Egyptian Air Forces among…

## Electricity prices may go down for November 2024
 - [https://pakobserver.net/electricity-prices-may-go-down-for-november-2024](https://pakobserver.net/electricity-prices-may-go-down-for-november-2024)
 - RSS feed: $source
 - date published: 2024-10-23T08:01:43+00:00

ISLAMABAD &#8211;  In a major development, the electricity prices may go down by Rs0.70 per unit as National Electric Power…

## IHC approves bail of Bushra Bibi in Toshakhana case two
 - [https://pakobserver.net/ihc-approves-bail-of-bushra-bibi-in-toshakhana-case-two](https://pakobserver.net/ihc-approves-bail-of-bushra-bibi-in-toshakhana-case-two)
 - RSS feed: $source
 - date published: 2024-10-23T07:37:33+00:00

ISLAMABAD &#8211; The Islamabad High Court (IHC) on Wednesday approved the bail of former Prime Minister Imran Khan&#8217;s wife Bushra…

## Nadra Family Registration Certificate fee in Dirhams from Oct 2024 [FRC Fee in UAE]
 - [https://pakobserver.net/nadra-family-registration-certificate-fee-in-dirhams-from-oct-2024-frc-fee-in-uae](https://pakobserver.net/nadra-family-registration-certificate-fee-in-dirhams-from-oct-2024-frc-fee-in-uae)
 - RSS feed: $source
 - date published: 2024-10-23T06:57:14+00:00

ISLAMABAD &#8211; The National Database Registration Authority (Nadra) issues the Family Registration Certificate , a document that carries details about…

## Dunkin Donuts, Lahore Broast, Servaid Pharmacy, Dubai Islamic Bank among 200 sealed in Lahore
 - [https://pakobserver.net/dunkin-donuts-lahore-broast-servaid-pharmacy-dubai-islamic-bank-among-200-sealed-in-lahore](https://pakobserver.net/dunkin-donuts-lahore-broast-servaid-pharmacy-dubai-islamic-bank-among-200-sealed-in-lahore)
 - RSS feed: $source
 - date published: 2024-10-23T06:53:02+00:00

LAHORE—The Lahore Development Authority (LDA) sealed 200 illegal commercial buildings and commercialization fee defaulter premises yesterday. LDA Town Planning Wing…

## Are you eligible for Dubai 30-day visa on arrival facility – Check online
 - [https://pakobserver.net/are-you-eligible-for-dubai-30-day-visa-on-arrival-facility-check-online](https://pakobserver.net/are-you-eligible-for-dubai-30-day-visa-on-arrival-facility-check-online)
 - RSS feed: $source
 - date published: 2024-10-23T06:48:29+00:00

DUBAI – Dubai, the economic and tourism hub of the United Arab Emirates (UAE), offers visa on-arrival to citizens of…

## Former President of Peru sentenced to 20 years, six months in jail over corruption
 - [https://pakobserver.net/former-president-of-peru-sentenced-to-20-years-six-months-in-jail-over-corruption](https://pakobserver.net/former-president-of-peru-sentenced-to-20-years-six-months-in-jail-over-corruption)
 - RSS feed: $source
 - date published: 2024-10-23T06:27:09+00:00

Former Peruvian President Alejandro Toledo has been sentenced to 20 years and 6 months in prison on charges of accepting…

## Aurangzeb urges to resolve issues of developing countries
 - [https://pakobserver.net/aurangzeb-urges-to-resolve-issues-of-developing-countries](https://pakobserver.net/aurangzeb-urges-to-resolve-issues-of-developing-countries)
 - RSS feed: $source
 - date published: 2024-10-23T06:19:05+00:00

WASHINGTON &#8211;  Minister for Finance Muhammad Aurangzeb has urged all development partners to work together to resolve the pressing issues…

## Vehicle fitness certificate fee update in Punjab – October 2024
 - [https://pakobserver.net/vehicle-fitness-certificate-fee-update-in-punjab-october-2024](https://pakobserver.net/vehicle-fitness-certificate-fee-update-in-punjab-october-2024)
 - RSS feed: $source
 - date published: 2024-10-23T06:17:26+00:00

LAHORE &#8211; The Punjab government has made it mandatory to obtain vehicle fitness certificate before driving the vehicles on roads…

## PU announces latest semester examination fee for Fall 2024 [Read Details]
 - [https://pakobserver.net/pu-announces-latest-semester-examination-fee-for-fall-2024-read-details](https://pakobserver.net/pu-announces-latest-semester-examination-fee-for-fall-2024-read-details)
 - RSS feed: $source
 - date published: 2024-10-23T05:58:42+00:00

LAHORE – The Punjab University has announced online semester enrollment and examinations fee schedule of affiliated colleges for Semesters Examination…

## President Zardari appoints Justice Yahya Afridi as new CJP
 - [https://pakobserver.net/president-zardari-appoints-justice-yahya-afridi-as-new-cjp](https://pakobserver.net/president-zardari-appoints-justice-yahya-afridi-as-new-cjp)
 - RSS feed: $source
 - date published: 2024-10-23T05:30:46+00:00

ISLAMABAD – President Asif Ali Zardari has approved the appointment of Justice Yahya Afridi as the new Chief Justice of…

## Gold rates in Saudi Arabia today – 23 October 2024
 - [https://pakobserver.net/gold-rates-in-saudi-arabia-today-23-october-2024](https://pakobserver.net/gold-rates-in-saudi-arabia-today-23-october-2024)
 - RSS feed: $source
 - date published: 2024-10-23T05:26:26+00:00

LAHORE – The price of per tola price 24-karat gold in Saudi Arabia on Wednesday (October 23) stands unchanged at…

## Omani Rial to PKR latest rate today – 23 October 2024
 - [https://pakobserver.net/omani-rial-to-pkr-latest-rate-today-23-october-2024](https://pakobserver.net/omani-rial-to-pkr-latest-rate-today-23-october-2024)
 - RSS feed: $source
 - date published: 2024-10-23T05:24:22+00:00

KARACHI – The buying rate for Omani Rial in Pakistan stands at Rs715.71 while the selling rate stands at Rs724.21…

## UK Pound to PKR rate today – 23 October 2024
 - [https://pakobserver.net/uk-pound-to-pkr-rate-today-23-october-2024](https://pakobserver.net/uk-pound-to-pkr-rate-today-23-october-2024)
 - RSS feed: $source
 - date published: 2024-10-23T05:21:57+00:00

KARACHI &#8211; UK Pound GBP sterling&#8217;s buying rate in Pakistan stands at Rs358.1 while the selling rate is Rs361.6 in…

## Dirham to PKR exchange rate today – 23 October 2024
 - [https://pakobserver.net/dirham-to-pkr-exchange-rate-today-23-october-2024](https://pakobserver.net/dirham-to-pkr-exchange-rate-today-23-october-2024)
 - RSS feed: $source
 - date published: 2024-10-23T05:19:19+00:00

AED to PKR today &#8211; UAE Dirham&#8217;s buying rate in open market of Pakistan stands at Rs75.25 after shedding five…

## Saudi Riyal to PKR exchange rate today – 23 October 2024
 - [https://pakobserver.net/saudi-riyal-to-pkr-exchange-rate-today-23-october-2024](https://pakobserver.net/saudi-riyal-to-pkr-exchange-rate-today-23-october-2024)
 - RSS feed: $source
 - date published: 2024-10-23T05:15:32+00:00

SAR to PKR today – The Saudi Riyal is being bought for Rs73.55 while the selling rate stands at Rs74.1…

## CM Maryam visits house being built by loan under ‘Apni Chhat…Apna Ghar’ programme
 - [https://pakobserver.net/cm-maryam-visits-house-being-built-by-loan-under-apni-chhatapna-ghar-programme](https://pakobserver.net/cm-maryam-visits-house-being-built-by-loan-under-apni-chhatapna-ghar-programme)
 - RSS feed: $source
 - date published: 2024-10-23T00:46:20+00:00

“Alhamdulillah, the work of putting lanterns on the first house under ‘Apni Chhat. Apna Ghar’ Programme has started,” said Chief…

## PM for immediate relief aid to Palestine, Lebanon through land, aerial routes
 - [https://pakobserver.net/pm-for-immediate-relief-aid-to-palestine-lebanon-through-land-aerial-routes](https://pakobserver.net/pm-for-immediate-relief-aid-to-palestine-lebanon-through-land-aerial-routes)
 - RSS feed: $source
 - date published: 2024-10-23T00:46:17+00:00

Prime Minister Shehbaz Sharif on Tuesday directed the authorities concerned to immediately dispatch two planeloads of relief goods to Gaza…

## Gandapur warns of consequences if senior most judge not appointed CJP
 - [https://pakobserver.net/gandapur-warns-of-consequences-if-senior-most-judge-not-appointed-cjp](https://pakobserver.net/gandapur-warns-of-consequences-if-senior-most-judge-not-appointed-cjp)
 - RSS feed: $source
 - date published: 2024-10-23T00:46:12+00:00

Tariq Saeed Peshawar Amid Pakistan Tehreek-e-Insaaf reiteration of boycotting the parliamentary committee meeting, Khyber Pakhtunkhwa (KP) Chief Minister (CM) Ali…

## PSX Stays Bullish, Gains 409 More Points
 - [https://pakobserver.net/psx-stays-bullish-gains-409-more-points](https://pakobserver.net/psx-stays-bullish-gains-409-more-points)
 - RSS feed: $source
 - date published: 2024-10-23T00:46:06+00:00

&#160; The 100-Index of the Pakistan stock exchange (PSX) continued with bullish trend on Tuesday, gaining 409.06 points, a positive…

## PTI decides against attending parliamentary committee meeting
 - [https://pakobserver.net/pti-decides-against-attending-parliamentary-committee-meeting](https://pakobserver.net/pti-decides-against-attending-parliamentary-committee-meeting)
 - RSS feed: $source
 - date published: 2024-10-23T00:46:06+00:00

Ijaz Kakakhel Islamabad The Pakistan Tehreek-e-Insaf (PTI) has announced that it will not participate on Tuesday’s meeting of the Special…

## Constitutional Amendment challenged in Supreme Court, SHC
 - [https://pakobserver.net/constitutional-amendment-challenged-in-supreme-court-shc](https://pakobserver.net/constitutional-amendment-challenged-in-supreme-court-shc)
 - RSS feed: $source
 - date published: 2024-10-23T00:46:05+00:00

Two days after the passage of much-hyped 26th Constitutional Amendment which entailed a two month-long political wrangling and compromises, the…

## Islamabad announces to keep Kartaepur Corridor open for five years
 - [https://pakobserver.net/islamabad-announces-to-keep-kartaepur-corridor-open-for-five-years](https://pakobserver.net/islamabad-announces-to-keep-kartaepur-corridor-open-for-five-years)
 - RSS feed: $source
 - date published: 2024-10-23T00:42:21+00:00

Abdul Hadi Mayar Islamabad Pakistan has announced the renewal of a Agreement with India for the facilitation of pilgrims to…

## Naqvi praises modern equipments showcased at SAHA expo
 - [https://pakobserver.net/naqvi-praises-modern-equipments-showcased-at-saha-expo](https://pakobserver.net/naqvi-praises-modern-equipments-showcased-at-saha-expo)
 - RSS feed: $source
 - date published: 2024-10-23T00:35:26+00:00

&#160; Federal Minister for Interior and Narcotics Control MohsinNaqvi participated in the SAHA Expo in Istanbul today. Interior Minister along…

## Pak delegation meets reps of Alvarez & Marsal Sovereign Advisory Services
 - [https://pakobserver.net/pak-delegation-meets-reps-of-alvarez-marsal-sovereign-advisory-services](https://pakobserver.net/pak-delegation-meets-reps-of-alvarez-marsal-sovereign-advisory-services)
 - RSS feed: $source
 - date published: 2024-10-23T00:35:26+00:00

The Pakistan delegation held a meeting with the representatives of Alvarez &#38; Marsal Sovereign Advisory Services, comprising Dr. Reza Baqir,…

## Rana to attend multilateral industrial policy forum in KSA
 - [https://pakobserver.net/rana-to-attend-multilateral-industrial-policy-forum-in-ksa](https://pakobserver.net/rana-to-attend-multilateral-industrial-policy-forum-in-ksa)
 - RSS feed: $source
 - date published: 2024-10-23T00:35:25+00:00

&#160; Federal Minister for Industries and Production Rana Tanveer Hussain Tuesday departed for Saudi Arabia to attend the two-day United…

## Technical training vital for telecom operators’ capacity building: Shaza
 - [https://pakobserver.net/technical-training-vital-for-telecom-operators-capacity-building-shaza](https://pakobserver.net/technical-training-vital-for-telecom-operators-capacity-building-shaza)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:35+00:00

&#160; Minister of State for Information Technology and Telecommunication Shaza Fatima Khawaja said Tuesday that technical training is vital for…

## Senator Rubina Khalid meets ADB country director Emma Fan
 - [https://pakobserver.net/senator-rubina-khalid-meets-adb-country-director-emma-fan](https://pakobserver.net/senator-rubina-khalid-meets-adb-country-director-emma-fan)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:30+00:00

Discusse skill development of beneficiaries and their families &#160; Chairperson of the Benazir Income Support Program (BISP), Senator Rubina Khalid,…

## NADRA, PBS sign MoU to use data domestically, internationally
 - [https://pakobserver.net/nadra-pbs-sign-mou-to-use-data-domestically-internationally](https://pakobserver.net/nadra-pbs-sign-mou-to-use-data-domestically-internationally)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:25+00:00

The National Database and Registration Authority (NADRA) and the Pakistan Bureau of Statistics (PBS) signed Memorandum of Understanding (MoU) to…

## LCCI holds awareness session on filing of income tax returns
 - [https://pakobserver.net/lcci-holds-awareness-session-on-filing-of-income-tax-returns](https://pakobserver.net/lcci-holds-awareness-session-on-filing-of-income-tax-returns)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:22+00:00

&#160; The Lahore Chamber of Commerce &#38; Industry has organized an awareness session on the filing of income tax returns…

## SECP alerts public to fraudulent investment/ deposit taking platform
 - [https://pakobserver.net/secp-alerts-public-to-fraudulent-investment-deposit-taking-platform](https://pakobserver.net/secp-alerts-public-to-fraudulent-investment-deposit-taking-platform)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:21+00:00

&#160; The Securities and Exchange Commission of Pakistan (SECP) has identified an illegal investment/ deposit taking platform operating under the…

## NIMA-ISSI hold joint seminar on ‘Challenges to Maritime Trade’
 - [https://pakobserver.net/nima-issi-hold-joint-seminar-on-challenges-to-maritime-trade](https://pakobserver.net/nima-issi-hold-joint-seminar-on-challenges-to-maritime-trade)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:20+00:00

&#160; The National Institute of Maritime Affairs (NIMA) Islamabad, in collaboration with the Institute of Strategic Studies Islamabad (ISSI), organized…

## Pakistan’s rice exports surge, earning over $720m in first quarter
 - [https://pakobserver.net/pakistans-rice-exports-surge-earning-over-720m-in-first-quarter](https://pakobserver.net/pakistans-rice-exports-surge-earning-over-720m-in-first-quarter)
 - RSS feed: $source
 - date published: 2024-10-23T00:32:19+00:00

&#160; Pakistan has witnessed a significant rise in the demand for its rice in international markets, earning over $721.8 million…

## IIUI holds condolence reference in honour  of late Dr N.B. Jumani
 - [https://pakobserver.net/iiui-holds-condolence-reference-in-honour-of-late-dr-n-b-jumani](https://pakobserver.net/iiui-holds-condolence-reference-in-honour-of-late-dr-n-b-jumani)
 - RSS feed: $source
 - date published: 2024-10-23T00:29:50+00:00

&#160; A heartfelt condolence reference was held in honor of the late Dr. NabiBuxJumani, former Vice President of the International…

## Call for strengthening Pak-UK partnerships
 - [https://pakobserver.net/call-for-strengthening-pak-uk-partnerships](https://pakobserver.net/call-for-strengthening-pak-uk-partnerships)
 - RSS feed: $source
 - date published: 2024-10-23T00:29:46+00:00

&#160; National Assembly Speaker Sardar Ayaz Sadiq and British MP Mohammad Yasin on Tuesday vowed for strengthening Pakistan-UK partnerships, especially…

## Experts call for early diagnosis for better treatment
 - [https://pakobserver.net/experts-call-for-early-diagnosis-for-better-treatment](https://pakobserver.net/experts-call-for-early-diagnosis-for-better-treatment)
 - RSS feed: $source
 - date published: 2024-10-23T00:27:50+00:00

PAEC breast cancer awareness drive NORI wins international recognition for sharing expertise with other cancer hospitals of region Nuclear Medicine,…

