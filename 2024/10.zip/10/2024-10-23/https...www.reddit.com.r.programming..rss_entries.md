# Source:programming, URL:https://www.reddit.com/r/programming/.rss, language:

## Stable Diffusion 3.5 HuggingFace Quickstart
 - [https://www.reddit.com/r/programming/comments/1gab0hu/stable_diffusion_35_huggingface_quickstart](https://www.reddit.com/r/programming/comments/1gab0hu/stable_diffusion_35_huggingface_quickstart)
 - RSS feed: $source
 - date published: 2024-10-23T13:49:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Other_Actuator_1925"> /u/Other_Actuator_1925 </a> <br/> <span><a href="https://github.com/jpe90/Stable-Diffusion-3.5-Diffusers">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1gab0hu/stable_diffusion_35_huggingface_quickstart/">[comments]</a></span>

## Need help creating something like this but simpler
 - [https://www.reddit.com/r/programming/comments/1gaat1e/need_help_creating_something_like_this_but_simpler](https://www.reddit.com/r/programming/comments/1gaat1e/need_help_creating_something_like_this_but_simpler)
 - RSS feed: $source
 - date published: 2024-10-23T13:39:29+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Impossible_Gear_7606"> /u/Impossible_Gear_7606 </a> <br/> <span><a href="https://www.abas.com.py/loteamientos?&amp;distrito=153">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1gaat1e/need_help_creating_something_like_this_but_simpler/">[comments]</a></span>

## Convert your Figma design into Python code
 - [https://www.reddit.com/r/programming/comments/1gaaqpa/convert_your_figma_design_into_python_code](https://www.reddit.com/r/programming/comments/1gaaqpa/convert_your_figma_design_into_python_code)
 - RSS feed: $source
 - date published: 2024-10-23T13:36:30+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/axorax"> /u/axorax </a> <br/> <span><a href="https://github.com/axorax/tkforge">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1gaaqpa/convert_your_figma_design_into_python_code/">[comments]</a></span>

## Keep your backend apps alive 24/7 by automating pulse signals, ensuring uninterrupted uptime on free hosting services.
 - [https://www.reddit.com/r/programming/comments/1gaaodv/keep_your_backend_apps_alive_247_by_automating](https://www.reddit.com/r/programming/comments/1gaaodv/keep_your_backend_apps_alive_247_by_automating)
 - RSS feed: $source
 - date published: 2024-10-23T13:33:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DarkGlance_"> /u/DarkGlance_ </a> <br/> <span><a href="https://github.com/Ashif4354/CyclicTasks">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1gaaodv/keep_your_backend_apps_alive_247_by_automating/">[comments]</a></span>

## How Shadcn Cut Through the Noise and Became React’s Default Component Library
 - [https://www.reddit.com/r/programming/comments/1ga9nmh/how_shadcn_cut_through_the_noise_and_became](https://www.reddit.com/r/programming/comments/1ga9nmh/how_shadcn_cut_through_the_noise_and_became)
 - RSS feed: $source
 - date published: 2024-10-23T12:45:06+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/memo_mar"> /u/memo_mar </a> <br/> <span><a href="https://blog.api-fiddle.com/posts/shadcn-for-react">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga9nmh/how_shadcn_cut_through_the_noise_and_became/">[comments]</a></span>

## Postiz: open-source social media scheduling, 11 platforms (Threads, Pinterest, Facebook, TikTok, Reddit, LinkedIn, Dribbble, YouTube, Instagram, Bluesky, Mastodon, Slack, Discord, and X). AI Copilots, AI auto-complete, Canva-like editor, team support
 - [https://www.reddit.com/r/programming/comments/1ga9g7u/postiz_opensource_social_media_scheduling_11](https://www.reddit.com/r/programming/comments/1ga9g7u/postiz_opensource_social_media_scheduling_11)
 - RSS feed: $source
 - date published: 2024-10-23T12:35:02+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sleepysiding22"> /u/sleepysiding22 </a> <br/> <span><a href="https://github.com/gitroomhq/postiz-app/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga9g7u/postiz_opensource_social_media_scheduling_11/">[comments]</a></span>

## Windows NT vs. Unix: A design comparison
 - [https://www.reddit.com/r/programming/comments/1ga8rf8/windows_nt_vs_unix_a_design_comparison](https://www.reddit.com/r/programming/comments/1ga8rf8/windows_nt_vs_unix_a_design_comparison)
 - RSS feed: $source
 - date published: 2024-10-23T11:59:45+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/pmz"> /u/pmz </a> <br/> <span><a href="https://blogsystem5.substack.com/p/windows-nt-vs-unix-design">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga8rf8/windows_nt_vs_unix_a_design_comparison/">[comments]</a></span>

## From ORM to OQM 2: Property-Related Duplication in Dynamic Queries and its Refactor Approach
 - [https://www.reddit.com/r/programming/comments/1ga8q6e/from_orm_to_oqm_2_propertyrelated_duplication_in](https://www.reddit.com/r/programming/comments/1ga8q6e/from_orm_to_oqm_2_propertyrelated_duplication_in)
 - RSS feed: $source
 - date published: 2024-10-23T11:57:50+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/saidBy4b"> /u/saidBy4b </a> <br/> <span><a href="https://blog.doyto.win/post/from-orm-to-oqm-2-en/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga8q6e/from_orm_to_oqm_2_propertyrelated_duplication_in/">[comments]</a></span>

## No EC2 or Kubernetes Allowed: Insights from Building Serverless-Only Architecture at PostNL
 - [https://www.reddit.com/r/programming/comments/1ga7cfj/no_ec2_or_kubernetes_allowed_insights_from](https://www.reddit.com/r/programming/comments/1ga7cfj/no_ec2_or_kubernetes_allowed_insights_from)
 - RSS feed: $source
 - date published: 2024-10-23T10:36:18+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/rgancarz"> /u/rgancarz </a> <br/> <span><a href="https://www.infoq.com/news/2024/10/postnl-serverless-enterprise/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga7cfj/no_ec2_or_kubernetes_allowed_insights_from/">[comments]</a></span>

## Dynamic Teams: Reteaming Patterns & Practices • Heidi Helfand & Charles Humble - GOTO - The Brightest Minds in Tech
 - [https://www.reddit.com/r/programming/comments/1ga6x17/dynamic_teams_reteaming_patterns_practices_heidi](https://www.reddit.com/r/programming/comments/1ga6x17/dynamic_teams_reteaming_patterns_practices_heidi)
 - RSS feed: $source
 - date published: 2024-10-23T10:08:13+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/goto-con"> /u/goto-con </a> <br/> <span><a href="https://www.buzzsprout.com/1714721/15821223">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga6x17/dynamic_teams_reteaming_patterns_practices_heidi/">[comments]</a></span>

## A love letter to Golang
 - [https://www.reddit.com/r/programming/comments/1ga6nnc/a_love_letter_to_golang](https://www.reddit.com/r/programming/comments/1ga6nnc/a_love_letter_to_golang)
 - RSS feed: $source
 - date published: 2024-10-23T09:50:23+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Mbv-Dev"> /u/Mbv-Dev </a> <br/> <span><a href="https://mortenvistisen.com/posts/a-love-letter-to-golang">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga6nnc/a_love_letter_to_golang/">[comments]</a></span>

## Jailer: relational data navigation tool
 - [https://www.reddit.com/r/programming/comments/1ga6awl/jailer_relational_data_navigation_tool](https://www.reddit.com/r/programming/comments/1ga6awl/jailer_relational_data_navigation_tool)
 - RSS feed: $source
 - date published: 2024-10-23T09:24:30+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Plane-Discussion"> /u/Plane-Discussion </a> <br/> <span><a href="https://github.com/Wisser/Jailer">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga6awl/jailer_relational_data_navigation_tool/">[comments]</a></span>

## My Journey as a Freelance Developer: How I Grew to Earning $14K a Month
 - [https://www.reddit.com/r/programming/comments/1ga5wvp/my_journey_as_a_freelance_developer_how_i_grew_to](https://www.reddit.com/r/programming/comments/1ga5wvp/my_journey_as_a_freelance_developer_how_i_grew_to)
 - RSS feed: $source
 - date published: 2024-10-23T08:55:06+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/No-Access2366"> /u/No-Access2366 </a> <br/> <span><a href="https://www.reddit.com/r/careeradvice/comments/1ga5wn6/my_journey_as_a_freelance_developer_how_i_grew_to/?utm_source=share&amp;utm_medium=web3x&amp;utm_name=web3xcss&amp;utm_term=1&amp;utm_content=share_button">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga5wvp/my_journey_as_a_freelance_developer_how_i_grew_to/">[comments]</a></span>

## A quick guide on how to speak at Tech Conferences
 - [https://www.reddit.com/r/programming/comments/1ga5u5e/a_quick_guide_on_how_to_speak_at_tech_conferences](https://www.reddit.com/r/programming/comments/1ga5u5e/a_quick_guide_on_how_to_speak_at_tech_conferences)
 - RSS feed: $source
 - date published: 2024-10-23T08:49:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/creasta29"> /u/creasta29 </a> <br/> <span><a href="https://neciudan.dev/speaking-at-tech-confrences">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga5u5e/a_quick_guide_on_how_to_speak_at_tech_conferences/">[comments]</a></span>

## New Typing Features in Python 3.13
 - [https://www.reddit.com/r/programming/comments/1ga5hes/new_typing_features_in_python_313](https://www.reddit.com/r/programming/comments/1ga5hes/new_typing_features_in_python_313)
 - RSS feed: $source
 - date published: 2024-10-23T08:21:47+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/wyhjsbyb"> /u/wyhjsbyb </a> <br/> <span><a href="https://medium.com/techtofreedom/7-new-typing-features-in-python-3-13-58caae5f2f10?sk=6ee66766ba372ea1f62b44a0ef08012d">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga5hes/new_typing_features_in_python_313/">[comments]</a></span>

## Mastering Design Patterns in JavaScript: Part 3 - The Observer Pattern
 - [https://www.reddit.com/r/programming/comments/1ga5gue/mastering_design_patterns_in_javascript_part_3](https://www.reddit.com/r/programming/comments/1ga5gue/mastering_design_patterns_in_javascript_part_3)
 - RSS feed: $source
 - date published: 2024-10-23T08:20:34+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/HolidayCartoonist323"> /u/HolidayCartoonist323 </a> <br/> <span><a href="https://codexstoney.medium.com/mastering-design-patterns-in-javascript-part-3-the-observer-pattern-06f1a08ade93?sk=7f8254f33f8ce2d387f697c2ccea2564">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga5gue/mastering_design_patterns_in_javascript_part_3/">[comments]</a></span>

## Step-by-Step Guide: Fine-Tuning and Training Stable Diffusion for Images & Videos
 - [https://www.reddit.com/r/programming/comments/1ga4lgb/stepbystep_guide_finetuning_and_training_stable](https://www.reddit.com/r/programming/comments/1ga4lgb/stepbystep_guide_finetuning_and_training_stable)
 - RSS feed: $source
 - date published: 2024-10-23T07:18:56+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Unlikely-Lettuce-472"> /u/Unlikely-Lettuce-472 </a> <br/> <span><a href="https://devtoys.io/2024/10/21/step-by-step-guide-fine-tuning-and-training-stable-diffusion-for-images-videos/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga4lgb/stepbystep_guide_finetuning_and_training_stable/">[comments]</a></span>

## Announcing the PlanetScale vectors public beta
 - [https://www.reddit.com/r/programming/comments/1ga4i03/announcing_the_planetscale_vectors_public_beta](https://www.reddit.com/r/programming/comments/1ga4i03/announcing_the_planetscale_vectors_public_beta)
 - RSS feed: $source
 - date published: 2024-10-23T07:11:51+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/_srbhr_"> /u/_srbhr_ </a> <br/> <span><a href="https://planetscale.com/blog/announcing-planetscale-vectors-public-beta">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga4i03/announcing_the_planetscale_vectors_public_beta/">[comments]</a></span>

## OpenAI's 'Canvas' for ChatGPT: Game-Changer or Meh?
 - [https://www.reddit.com/r/programming/comments/1ga4gjj/openais_canvas_for_chatgpt_gamechanger_or_meh](https://www.reddit.com/r/programming/comments/1ga4gjj/openais_canvas_for_chatgpt_gamechanger_or_meh)
 - RSS feed: $source
 - date published: 2024-10-23T07:08:56+00:00

<!-- SC_OFF --><div class="md"><p>OpenAI dropped this new &#39;Canvas&#39; interface for ChatGPT that’s supposed to be great for writing and coding. Has anyone given it a go? Does it actually help streamline work, or is it still a bit clunky? Share your insights</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Opening-Music-7266"> /u/Opening-Music-7266 </a> <br/> <span><a href="https://openai.com/index/introducing-canvas/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga4gjj/openais_canvas_for_chatgpt_gamechanger_or_meh/">[comments]</a></span>

## LZAV 4.2: Increased decompression speed by 7-20%. Fast In-Memory Data Compression Algorithm (inline C/C++) 460+MB/s compress, 2700+MB/s decompress, ratio% better than LZ4, Snappy, and Zstd@-1
 - [https://www.reddit.com/r/programming/comments/1ga495u/lzav_42_increased_decompression_speed_by_720_fast](https://www.reddit.com/r/programming/comments/1ga495u/lzav_42_increased_decompression_speed_by_720_fast)
 - RSS feed: $source
 - date published: 2024-10-23T06:53:49+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/avaneev"> /u/avaneev </a> <br/> <span><a href="https://github.com/avaneev/lzav">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga495u/lzav_42_increased_decompression_speed_by_720_fast/">[comments]</a></span>

## Introducing computer use, a new Claude 3.5 Sonnet, and Claude 3.5 Haiku
 - [https://www.reddit.com/r/programming/comments/1ga3wd0/introducing_computer_use_a_new_claude_35_sonnet](https://www.reddit.com/r/programming/comments/1ga3wd0/introducing_computer_use_a_new_claude_35_sonnet)
 - RSS feed: $source
 - date published: 2024-10-23T06:27:26+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/donutloop"> /u/donutloop </a> <br/> <span><a href="https://www.anthropic.com/news/3-5-models-and-computer-use">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga3wd0/introducing_computer_use_a_new_claude_35_sonnet/">[comments]</a></span>

## Learn CRUD operations on SQLite Database using C#
 - [https://www.reddit.com/r/programming/comments/1ga3to6/learn_crud_operations_on_sqlite_database_using_c](https://www.reddit.com/r/programming/comments/1ga3to6/learn_crud_operations_on_sqlite_database_using_c)
 - RSS feed: $source
 - date published: 2024-10-23T06:22:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/xanthium_in"> /u/xanthium_in </a> <br/> <span><a href="https://www.youtube.com/watch?v=HqywH0bZJlA">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga3to6/learn_crud_operations_on_sqlite_database_using_c/">[comments]</a></span>

## Comparing Auth from Supabase, Firebase, Auth.js, Ory, Clerk and others
 - [https://www.reddit.com/r/programming/comments/1ga1fmp/comparing_auth_from_supabase_firebase_authjs_ory](https://www.reddit.com/r/programming/comments/1ga1fmp/comparing_auth_from_supabase_firebase_authjs_ory)
 - RSS feed: $source
 - date published: 2024-10-23T03:52:03+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Suspicious_Market561"> /u/Suspicious_Market561 </a> <br/> <span><a href="https://blog.hyperknot.com/p/comparing-auth-providers">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga1fmp/comparing_auth_from_supabase_firebase_authjs_ory/">[comments]</a></span>

## Tipos Unión en Python
 - [https://www.reddit.com/r/programming/comments/1ga0yq0/tipos_unión_en_python](https://www.reddit.com/r/programming/comments/1ga0yq0/tipos_unión_en_python)
 - RSS feed: $source
 - date published: 2024-10-23T03:25:19+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/emanuelpeg"> /u/emanuelpeg </a> <br/> <span><a href="https://emanuelpeg.blogspot.com/2024/10/tipos-union-en-python.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga0yq0/tipos_unión_en_python/">[comments]</a></span>

## Build a manual assembly QA system
 - [https://www.reddit.com/r/programming/comments/1ga0ume/build_a_manual_assembly_qa_system](https://www.reddit.com/r/programming/comments/1ga0ume/build_a_manual_assembly_qa_system)
 - RSS feed: $source
 - date published: 2024-10-23T03:19:03+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/zerojames_"> /u/zerojames_ </a> <br/> <span><a href="https://blog.roboflow.com/manual-assembly-qa-computer-vision/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1ga0ume/build_a_manual_assembly_qa_system/">[comments]</a></span>

## 15 Essential Tailwind CSS Plugins to Supercharge Your Web Design
 - [https://www.reddit.com/r/programming/comments/1g9zfss/15_essential_tailwind_css_plugins_to_supercharge](https://www.reddit.com/r/programming/comments/1g9zfss/15_essential_tailwind_css_plugins_to_supercharge)
 - RSS feed: $source
 - date published: 2024-10-23T02:03:46+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/jsdevspace"> /u/jsdevspace </a> <br/> <span><a href="https://medium.com/@jsdevspace/15-essential-tailwind-css-plugins-to-supercharge-your-web-design-35e352797bab">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g9zfss/15_essential_tailwind_css_plugins_to_supercharge/">[comments]</a></span>

## Computer Use by Anthropic: A 5-Minute Setup Guide and Demo
 - [https://www.reddit.com/r/programming/comments/1g9yz20/computer_use_by_anthropic_a_5minute_setup_guide](https://www.reddit.com/r/programming/comments/1g9yz20/computer_use_by_anthropic_a_5minute_setup_guide)
 - RSS feed: $source
 - date published: 2024-10-23T01:40:18+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/punkpeye"> /u/punkpeye </a> <br/> <span><a href="https://glama.ai/blog/2024-10-22-automate-computer-using-claude">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g9yz20/computer_use_by_anthropic_a_5minute_setup_guide/">[comments]</a></span>

## Borgo, lenguaje de programación que compila a Go.
 - [https://www.reddit.com/r/programming/comments/1g9y705/borgo_lenguaje_de_programación_que_compila_a_go](https://www.reddit.com/r/programming/comments/1g9y705/borgo_lenguaje_de_programación_que_compila_a_go)
 - RSS feed: $source
 - date published: 2024-10-23T01:01:14+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/emanuelpeg"> /u/emanuelpeg </a> <br/> <span><a href="https://emanuelpeg.blogspot.com/2024/10/borgo-lenguaje-de-programacion-que.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g9y705/borgo_lenguaje_de_programación_que_compila_a_go/">[comments]</a></span>

