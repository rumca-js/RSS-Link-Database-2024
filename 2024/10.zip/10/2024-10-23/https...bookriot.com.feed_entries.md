# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## What Next?: Recent Post-Apocalyptic Fiction
 - [https://bookriot.com/recent-post-apocalyptic-fiction](https://bookriot.com/recent-post-apocalyptic-fiction)
 - RSS feed: $source
 - date published: 2024-10-23T13:30:00+00:00

Reading these recent post-apocalyptic fiction books will make you look at our past, present, and future in a new light.

## Book Riot’s Deals of the Day for October 23, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-october-23-2024](https://bookriot.com/book-riots-deals-of-the-day-for-october-23-2024)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:00+00:00

Black girls who battle monsters and survive, a foreboding Gothic mansion, an enigmatic librarian, and more of today's best book deals

## New YA Books Out This Week, October 23, 2024
 - [https://bookriot.com/new-ya-books-out-this-week-october-23-2024](https://bookriot.com/new-ya-books-out-this-week-october-23-2024)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:00+00:00

Here are this week's new YA releases in hardcover and paperback, including one called BRIDGERTON meets THE BACHELOR. 

## The Cutest Comic for ADHD Awareness Month
 - [https://bookriot.com/the-cutest-comic-for-adhd-awareness-month](https://bookriot.com/the-cutest-comic-for-adhd-awareness-month)
 - RSS feed: $source
 - date published: 2024-10-23T12:30:00+00:00

October is ADHD Awareness Month, and this comic is fun with characters who show what it's like to be neurodivergent

## The Guilt of Reading Deep Backlist
 - [https://bookriot.com/the-guilt-of-reading-deep-backlist](https://bookriot.com/the-guilt-of-reading-deep-backlist)
 - RSS feed: $source
 - date published: 2024-10-23T11:30:00+00:00

Do you have things having to do with reading that make you feel guilty?

## 8 Historical Fiction Novels Set in Scotland
 - [https://bookriot.com/historical-fiction-novels-set-in-scotland](https://bookriot.com/historical-fiction-novels-set-in-scotland)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:00+00:00

What's your favorite Scotland-set story?

## This Queer Epic Takes Place in ’70s China and Modern-Day US
 - [https://bookriot.com/cinema-love-by-jiaming-tang](https://bookriot.com/cinema-love-by-jiaming-tang)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:00+00:00

"This is not an easy read, but it's not a bleak read, either. Tang writes with such compassion and tenderness, such open curiosity about the stories behind the stories"

## Cozy Reading Season Essentials
 - [https://bookriot.com/cozy-reading-essentials](https://bookriot.com/cozy-reading-essentials)
 - RSS feed: $source
 - date published: 2024-10-23T10:45:00+00:00

On your marks, get set, get comfy! It's time for pillow forts, book stacks, and cozy reading essentials for reading sprints. 

## I WANT TO DIE BUT I WANT TO EAT TTEOKBOKKI
 - [https://bookriot.com/i-want-to-die-but-i-want-to-eat-tteokbokki](https://bookriot.com/i-want-to-die-but-i-want-to-eat-tteokbokki)
 - RSS feed: $source
 - date published: 2024-10-23T10:30:00+00:00

What are your favorite memoirs that focus on mental health?

