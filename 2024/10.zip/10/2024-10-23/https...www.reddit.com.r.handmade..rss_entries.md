# Source:Handmade - Arts & Crafts Made by Hand, URL:https://www.reddit.com/r/handmade/.rss, language:

## Succulent Sunset, 8x10 inches
 - [https://www.reddit.com/r/handmade/comments/1gaagva/succulent_sunset_8x10_inches](https://www.reddit.com/r/handmade/comments/1gaagva/succulent_sunset_8x10_inches)
 - RSS feed: $source
 - date published: 2024-10-23T13:23:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1gaagva/succulent_sunset_8x10_inches/"> <img src="https://b.thumbs.redditmedia.com/ZX4jK1digx1dttOa7eyKGLQ1H6qztGOwJrbVrwKJYJQ.jpg" alt="Succulent Sunset, 8x10 inches" title="Succulent Sunset, 8x10 inches" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/queenartistseller"> /u/queenartistseller </a> <br/> <span><a href="https://www.reddit.com/gallery/1gaagva">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1gaagva/succulent_sunset_8x10_inches/">[comments]</a></span> </td></tr></table>

## Turn iPhone 6 into handheld gaming console
 - [https://www.reddit.com/r/handmade/comments/1ga8wi2/turn_iphone_6_into_handheld_gaming_console](https://www.reddit.com/r/handmade/comments/1ga8wi2/turn_iphone_6_into_handheld_gaming_console)
 - RSS feed: $source
 - date published: 2024-10-23T12:06:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1ga8wi2/turn_iphone_6_into_handheld_gaming_console/"> <img src="https://external-preview.redd.it/igEOaf2R4kELsdKIYFnCLOmFzyz6fWGXQrMNqOR3jeY.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=3a4ffe1fe66460568b364be7152d8e9006faed65" alt="Turn iPhone 6 into handheld gaming console" title="Turn iPhone 6 into handheld gaming console" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/diyotaku"> /u/diyotaku </a> <br/> <span><a href="https://www.youtube.com/watch?v=Q1JyjTBjtx4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1ga8wi2/turn_iphone_6_into_handheld_gaming_console/">[comments]</a></span> </td></tr></table>

## A commission I drew of a sweet dog that recently crossed the rainbow bridge. I used Charcoal pencils for this portrait.
 - [https://www.reddit.com/r/handmade/comments/1ga8ieg/a_commission_i_drew_of_a_sweet_dog_that_recently](https://www.reddit.com/r/handmade/comments/1ga8ieg/a_commission_i_drew_of_a_sweet_dog_that_recently)
 - RSS feed: $source
 - date published: 2024-10-23T11:46:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1ga8ieg/a_commission_i_drew_of_a_sweet_dog_that_recently/"> <img src="https://preview.redd.it/tagqh60juhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b309a51a6089e3b82b6d02bf01a95a5b753258ed" alt="A commission I drew of a sweet dog that recently crossed the rainbow bridge. I used Charcoal pencils for this portrait." title="A commission I drew of a sweet dog that recently crossed the rainbow bridge. I used Charcoal pencils for this portrait." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cary_21"> /u/Cary_21 </a> <br/> <span><a href="https://i.redd.it/tagqh60juhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1ga8ieg/a_commission_i_drew_of_a_sweet_dog_that_recently/">[comments]</a></span> </td></tr></table>

## Upcycled vinyl records & Handcrafted reclaimed wood art.
 - [https://www.reddit.com/r/handmade/comments/1ga83w4/upcycled_vinyl_records_handcrafted_reclaimed_wood](https://www.reddit.com/r/handmade/comments/1ga83w4/upcycled_vinyl_records_handcrafted_reclaimed_wood)
 - RSS feed: $source
 - date published: 2024-10-23T11:24:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1ga83w4/upcycled_vinyl_records_handcrafted_reclaimed_wood/"> <img src="https://preview.redd.it/s2tbwgqjqhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b58d2bf8ff249f8ee7342c3580fe367ca54edd35" alt="Upcycled vinyl records &amp; Handcrafted reclaimed wood art. " title="Upcycled vinyl records &amp; Handcrafted reclaimed wood art. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wildrare"> /u/wildrare </a> <br/> <span><a href="https://i.redd.it/s2tbwgqjqhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1ga83w4/upcycled_vinyl_records_handcrafted_reclaimed_wood/">[comments]</a></span> </td></tr></table>

## Did you do handmade yet today? I’m doing lanyard.
 - [https://www.reddit.com/r/handmade/comments/1ga7jyb/did_you_do_handmade_yet_today_im_doing_lanyard](https://www.reddit.com/r/handmade/comments/1ga7jyb/did_you_do_handmade_yet_today_im_doing_lanyard)
 - RSS feed: $source
 - date published: 2024-10-23T10:49:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1ga7jyb/did_you_do_handmade_yet_today_im_doing_lanyard/"> <img src="https://preview.redd.it/2eorsn1gkhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6764e10f9f496cbba587d7a4c3666fb832f0ce18" alt="Did you do handmade yet today? I’m doing lanyard." title="Did you do handmade yet today? I’m doing lanyard." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/thingsforlucky"> /u/thingsforlucky </a> <br/> <span><a href="https://i.redd.it/2eorsn1gkhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1ga7jyb/did_you_do_handmade_yet_today_im_doing_lanyard/">[comments]</a></span> </td></tr></table>

## Anthurium Green Queen, made out of air-dry clay.
 - [https://www.reddit.com/r/handmade/comments/1ga79s5/anthurium_green_queen_made_out_of_airdry_clay](https://www.reddit.com/r/handmade/comments/1ga79s5/anthurium_green_queen_made_out_of_airdry_clay)
 - RSS feed: $source
 - date published: 2024-10-23T10:31:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1ga79s5/anthurium_green_queen_made_out_of_airdry_clay/"> <img src="https://b.thumbs.redditmedia.com/KFZxMsDrAlaPtygO8hax-yAI4vfn3kn1ehvysnImKBw.jpg" alt="Anthurium Green Queen, made out of air-dry clay." title="Anthurium Green Queen, made out of air-dry clay." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CynicOwl1"> /u/CynicOwl1 </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga79s5">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1ga79s5/anthurium_green_queen_made_out_of_airdry_clay/">[comments]</a></span> </td></tr></table>

## An ouroboros sweater that I hand-carved and printed
 - [https://www.reddit.com/r/handmade/comments/1ga3chj/an_ouroboros_sweater_that_i_handcarved_and_printed](https://www.reddit.com/r/handmade/comments/1ga3chj/an_ouroboros_sweater_that_i_handcarved_and_printed)
 - RSS feed: $source
 - date published: 2024-10-23T05:49:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1ga3chj/an_ouroboros_sweater_that_i_handcarved_and_printed/"> <img src="https://b.thumbs.redditmedia.com/QDwV66UEDFoOnx4XhxuOJXE0gREi8tNkgu90OABhblM.jpg" alt="An ouroboros sweater that I hand-carved and printed" title="An ouroboros sweater that I hand-carved and printed" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Bonus pic of my muse Casanova</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Artbyannaem"> /u/Artbyannaem </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga3chj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1ga3chj/an_ouroboros_sweater_that_i_handcarved_and_printed/">[comments]</a></span> </td></tr></table>

## I made a Watchtower with Toothpicks.
 - [https://www.reddit.com/r/handmade/comments/1g9y3cu/i_made_a_watchtower_with_toothpicks](https://www.reddit.com/r/handmade/comments/1g9y3cu/i_made_a_watchtower_with_toothpicks)
 - RSS feed: $source
 - date published: 2024-10-23T00:56:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1g9y3cu/i_made_a_watchtower_with_toothpicks/"> <img src="https://external-preview.redd.it/ueM1mQxthUNl8z_gMCNflVj9Z_EU3skjdBuAPFeolWk.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=11b7c12c080855adec80690064c37b59a5d706e3" alt="I made a Watchtower with Toothpicks." title="I made a Watchtower with Toothpicks." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Specialist_Guava_188"> /u/Specialist_Guava_188 </a> <br/> <span><a href="https://youtu.be/mxQ6jZpmAOI">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1g9y3cu/i_made_a_watchtower_with_toothpicks/">[comments]</a></span> </td></tr></table>

## Amigurumi Teddy Swims🧡🤍
 - [https://www.reddit.com/r/handmade/comments/1g9xws8/amigurumi_teddy_swims](https://www.reddit.com/r/handmade/comments/1g9xws8/amigurumi_teddy_swims)
 - RSS feed: $source
 - date published: 2024-10-23T00:47:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1g9xws8/amigurumi_teddy_swims/"> <img src="https://a.thumbs.redditmedia.com/9giQjHs0U4iYawc7S0J1xF0wHsyquwhn90xCKQRSuV4.jpg" alt="Amigurumi Teddy Swims🧡🤍" title="Amigurumi Teddy Swims🧡🤍" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hanakomai"> /u/Hanakomai </a> <br/> <span><a href="https://www.reddit.com/gallery/1g9xws8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1g9xws8/amigurumi_teddy_swims/">[comments]</a></span> </td></tr></table>

