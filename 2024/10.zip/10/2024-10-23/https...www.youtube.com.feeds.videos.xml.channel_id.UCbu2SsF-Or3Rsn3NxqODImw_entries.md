# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## GUILTY GEAR STRIVE - Official Queen Dizzy Character Gameplay Reveal Trailer
 - [https://www.youtube.com/watch?v=JWmn4Ju--bo](https://www.youtube.com/watch?v=JWmn4Ju--bo)
 - RSS feed: $source
 - date published: 2024-10-23T14:25:37+00:00

The story of Guilty Gear, spanning over 25 years, will finally come to a conclusion in “GUILTY GEAR -STRIVE-." The trials and tribulations of the series’ heroes and villains will finally be resolved. Discover the astonishing truth awaiting at the end of all things.

Check out the play style of the first character in Season Pass 4, Queen Dizzy, in this trailer.

## Monster Hunter Wilds: 5th Trailer | The Black Flame
 - [https://www.youtube.com/watch?v=GecO6NuZI3Y](https://www.youtube.com/watch?v=GecO6NuZI3Y)
 - RSS feed: $source
 - date published: 2024-10-23T14:23:53+00:00

Welcome, hunters, to the third locale in the Forbidden Lands; the Oilwell Basin. Meet the people of Azuz, the Everforge, and come face-to-face with three of the area's new monstrous denizens, including the ominous Black Flame. 
 
Monster Hunter Wilds launches on February 28, 2025. Pre-order now to receive the Guild Knight Set Layered Armor and the Hope Charm Talisman!

Monster Hunter Wilds is the next generation of the acclaimed Monster Hunter series.

You are a monster hunter, protecting the balance of the ecosystem and hunting monsters in a world with dynamic, ever-changing environments. Use the resources you gain from hunts to craft ever more powerful weapons and armor in your quest to unravel the mysteries of the new lands.

Experience the most evolved action and improved immersion in the series when Monster Hunter Wilds arrives on PS5, Xbox Series X|S, and PC/Steam on February 28, 2025. 

#MonsterHunter #MHWilds

