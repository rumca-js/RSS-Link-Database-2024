# Source:/r/Warhammer40k - Unofficial Home of 40k on Reddit, URL:https://www.reddit.com/r/Warhammer40k/.rss, language:en

## Thanks for your thoughts, he love it!!!
 - [https://www.reddit.com/r/Warhammer40k/comments/1gaa5i2/thanks_for_your_thoughts_he_love_it](https://www.reddit.com/r/Warhammer40k/comments/1gaa5i2/thanks_for_your_thoughts_he_love_it)
 - RSS feed: $source
 - date published: 2024-10-23T13:08:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1gaa5i2/thanks_for_your_thoughts_he_love_it/"> <img src="https://preview.redd.it/uo960sv89iwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f831b395ae47a077ba970c0e3cb6c9d8837d2f41" alt="Thanks for your thoughts, he love it!!! " title="Thanks for your thoughts, he love it!!! " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LenaCrystallize"> /u/LenaCrystallize </a> <br/> <span><a href="https://i.redd.it/uo960sv89iwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1gaa5i2/thanks_for_your_thoughts_he_love_it/">[comments]</a></span> </td></tr></table>

## First ever dreadnought done!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga9j1p/first_ever_dreadnought_done](https://www.reddit.com/r/Warhammer40k/comments/1ga9j1p/first_ever_dreadnought_done)
 - RSS feed: $source
 - date published: 2024-10-23T12:39:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga9j1p/first_ever_dreadnought_done/"> <img src="https://b.thumbs.redditmedia.com/dc-VCIj1EfNiO71gkSwXvFU0lxrpkfPfp91KmVrckdQ.jpg" alt="First ever dreadnought done!" title="First ever dreadnought done!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheHookedTip"> /u/TheHookedTip </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga9j1p">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga9j1p/first_ever_dreadnought_done/">[comments]</a></span> </td></tr></table>

## She’s a keeper
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga9d0b/shes_a_keeper](https://www.reddit.com/r/Warhammer40k/comments/1ga9d0b/shes_a_keeper)
 - RSS feed: $source
 - date published: 2024-10-23T12:30:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga9d0b/shes_a_keeper/"> <img src="https://preview.redd.it/a2fmjdoe2iwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e9c14272739e2080ee0be762f03c340dd0af6b81" alt="She’s a keeper" title="She’s a keeper" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>My fiancée asked if I wanted anything from the hobby store, as she was in the area. I asked if she could get a pot of Warplock Bronze. She came home with all this, swearing that our 5 month-old kept grabbing the box of Termagants 😅 and obviously an Ork for Orktober</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Moist-Chocolate1612"> /u/Moist-Chocolate1612 </a> <br/> <span><a href="https://i.redd.it/a2fmjdoe2iwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga9d0b/shes_a_keeper/">[comments]</a></span> </td></tr></table>

## Size matters!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga9agt/size_matters](https://www.reddit.com/r/Warhammer40k/comments/1ga9agt/size_matters)
 - RSS feed: $source
 - date published: 2024-10-23T12:27:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga9agt/size_matters/"> <img src="https://b.thumbs.redditmedia.com/XOGabpRLckBFd-J98nSp3MMJJrQpyi5Xx4ffR04O6Js.jpg" alt="Size matters!" title="Size matters!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/emperorhimself"> /u/emperorhimself </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga9agt">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga9agt/size_matters/">[comments]</a></span> </td></tr></table>

## GW plastic bags phased out to 'reduce plastic use' is unintentionally hilarious.
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga8byj/gw_plastic_bags_phased_out_to_reduce_plastic_use](https://www.reddit.com/r/Warhammer40k/comments/1ga8byj/gw_plastic_bags_phased_out_to_reduce_plastic_use)
 - RSS feed: $source
 - date published: 2024-10-23T11:37:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga8byj/gw_plastic_bags_phased_out_to_reduce_plastic_use/"> <img src="https://preview.redd.it/b5qzdkysshwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=dbf1c3e0f557160ae54fe8af8f1dd02de9ed02bf" alt="GW plastic bags phased out to 'reduce plastic use' is unintentionally hilarious." title="GW plastic bags phased out to 'reduce plastic use' is unintentionally hilarious." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I had to buy a canvas GW bag that as the plastic ones have been removed to save on plastic waste. </p> <p>I know it&#39;s referring to single use stuff and I&#39;m broadly in favour of phasing then out, but it struck me as unintentionally hilarious in a business selling plastic kits. Especially one where a large percentage of every kit is sprue waste 😅</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Daedricbob"> /u/Daedricbob </a> <br/> <span><a href="htt

## Was not happy with my Mortarion so tired to go back and make improvements. Cc welcome.
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga8b3h/was_not_happy_with_my_mortarion_so_tired_to_go](https://www.reddit.com/r/Warhammer40k/comments/1ga8b3h/was_not_happy_with_my_mortarion_so_tired_to_go)
 - RSS feed: $source
 - date published: 2024-10-23T11:35:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga8b3h/was_not_happy_with_my_mortarion_so_tired_to_go/"> <img src="https://preview.redd.it/8p1uoh2mshwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e0c7de4052b8478eda12e04b9307075353a6a880" alt="Was not happy with my Mortarion so tired to go back and make improvements. Cc welcome. " title="Was not happy with my Mortarion so tired to go back and make improvements. Cc welcome. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/fishtacopainting"> /u/fishtacopainting </a> <br/> <span><a href="https://i.redd.it/8p1uoh2mshwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga8b3h/was_not_happy_with_my_mortarion_so_tired_to_go/">[comments]</a></span> </td></tr></table>

## Trust the process!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga7q5a/trust_the_process](https://www.reddit.com/r/Warhammer40k/comments/1ga7q5a/trust_the_process)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga7q5a/trust_the_process/"> <img src="https://preview.redd.it/txv611edmhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ffaa1237f25072829f635fd11a3cf76d852e909c" alt="Trust the process!" title="Trust the process!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Active_Young"> /u/Active_Young </a> <br/> <span><a href="https://i.redd.it/txv611edmhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga7q5a/trust_the_process/">[comments]</a></span> </td></tr></table>

## Plague marine
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga7d06/plague_marine](https://www.reddit.com/r/Warhammer40k/comments/1ga7d06/plague_marine)
 - RSS feed: $source
 - date published: 2024-10-23T10:37:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga7d06/plague_marine/"> <img src="https://preview.redd.it/2eb8l1f7ihwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5bbda90df22eb0e7833171ab39b87054bbf6d50c" alt="Plague marine" title="Plague marine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/whitelinefever05"> /u/whitelinefever05 </a> <br/> <span><a href="https://i.redd.it/2eb8l1f7ihwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga7d06/plague_marine/">[comments]</a></span> </td></tr></table>

## Space marine captain from the blind box
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga7cex/space_marine_captain_from_the_blind_box](https://www.reddit.com/r/Warhammer40k/comments/1ga7cex/space_marine_captain_from_the_blind_box)
 - RSS feed: $source
 - date published: 2024-10-23T10:36:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga7cex/space_marine_captain_from_the_blind_box/"> <img src="https://preview.redd.it/hb2jruo0ihwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=dff39a04d01e7550b452afcba4d48c6dff126f18" alt="Space marine captain from the blind box" title="Space marine captain from the blind box" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/whitelinefever05"> /u/whitelinefever05 </a> <br/> <span><a href="https://i.redd.it/hb2jruo0ihwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga7cex/space_marine_captain_from_the_blind_box/">[comments]</a></span> </td></tr></table>

## All the tyranid warrior weapons, painted AND magnetized!!! Commission work
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga6k03/all_the_tyranid_warrior_weapons_painted_and](https://www.reddit.com/r/Warhammer40k/comments/1ga6k03/all_the_tyranid_warrior_weapons_painted_and)
 - RSS feed: $source
 - date published: 2024-10-23T09:43:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga6k03/all_the_tyranid_warrior_weapons_painted_and/"> <img src="https://preview.redd.it/eo1btxai8hwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=549e448b13b6809756be0e5af8151c08892d8eea" alt="All the tyranid warrior weapons, painted AND magnetized!!! Commission work" title="All the tyranid warrior weapons, painted AND magnetized!!! Commission work" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Altruistic_Salt_4456"> /u/Altruistic_Salt_4456 </a> <br/> <span><a href="https://i.redd.it/eo1btxai8hwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga6k03/all_the_tyranid_warrior_weapons_painted_and/">[comments]</a></span> </td></tr></table>

## Slow progress is still progress!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga570m/slow_progress_is_still_progress](https://www.reddit.com/r/Warhammer40k/comments/1ga570m/slow_progress_is_still_progress)
 - RSS feed: $source
 - date published: 2024-10-23T08:02:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga570m/slow_progress_is_still_progress/"> <img src="https://preview.redd.it/affd8dckqgwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4802e5d12e90802bd02afa28cfaa8b303e43ee44" alt="Slow progress is still progress!" title="Slow progress is still progress!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Been a bit slow recently working on this inner circle companion. But work is still work! No matter how much you get done you still picked up the brush! Good job!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Jbladez"> /u/Jbladez </a> <br/> <span><a href="https://i.redd.it/affd8dckqgwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga570m/slow_progress_is_still_progress/">[comments]</a></span> </td></tr></table>

## Why don't we get numbers sequentially on the sprues? 1,2,3,4 etc
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga4afj/why_dont_we_get_numbers_sequentially_on_the](https://www.reddit.com/r/Warhammer40k/comments/1ga4afj/why_dont_we_get_numbers_sequentially_on_the)
 - RSS feed: $source
 - date published: 2024-10-23T06:56:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga4afj/why_dont_we_get_numbers_sequentially_on_the/"> <img src="https://preview.redd.it/q1z4ab7tegwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=33526b27770bab3b0a1c5260071282bd1747c3b7" alt="Why don't we get numbers sequentially on the sprues? 1,2,3,4 etc" title="Why don't we get numbers sequentially on the sprues? 1,2,3,4 etc" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I&#39;m struggling to understand the logic, on the spure 1-100 and in the instructions which ever number aligns to the piece. Built 40 models last night and 70% of that time is tracking down numbers spread across 3 separate sprues.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/hutber"> /u/hutber </a> <br/> <span><a href="https://i.redd.it/q1z4ab7tegwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga4afj/why_dont_we_get_numbers_sequentially_on

## More converted outriders for the Khan!
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga2rr2/more_converted_outriders_for_the_khan](https://www.reddit.com/r/Warhammer40k/comments/1ga2rr2/more_converted_outriders_for_the_khan)
 - RSS feed: $source
 - date published: 2024-10-23T05:12:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga2rr2/more_converted_outriders_for_the_khan/"> <img src="https://b.thumbs.redditmedia.com/KAfOllhPsPqYlgNI2f3GKFqpwik1iogTwsF4Jbocd6s.jpg" alt="More converted outriders for the Khan!" title="More converted outriders for the Khan!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nomzor"> /u/nomzor </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga2rr2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga2rr2/more_converted_outriders_for_the_khan/">[comments]</a></span> </td></tr></table>

## First paint job after almost 20 years away from 40k. How did I do?
 - [https://www.reddit.com/r/Warhammer40k/comments/1ga0qr0/first_paint_job_after_almost_20_years_away_from](https://www.reddit.com/r/Warhammer40k/comments/1ga0qr0/first_paint_job_after_almost_20_years_away_from)
 - RSS feed: $source
 - date published: 2024-10-23T03:13:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1ga0qr0/first_paint_job_after_almost_20_years_away_from/"> <img src="https://b.thumbs.redditmedia.com/ce53CAKXp-JCUsIcl8BT3YT5cgcpOdfO3E1IXoZ55lg.jpg" alt="First paint job after almost 20 years away from 40k. How did I do?" title="First paint job after almost 20 years away from 40k. How did I do?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CaptainTrips24"> /u/CaptainTrips24 </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga0qr0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1ga0qr0/first_paint_job_after_almost_20_years_away_from/">[comments]</a></span> </td></tr></table>

## Pose test before any conversion. Yay or nay?
 - [https://www.reddit.com/r/Warhammer40k/comments/1g9yke8/pose_test_before_any_conversion_yay_or_nay](https://www.reddit.com/r/Warhammer40k/comments/1g9yke8/pose_test_before_any_conversion_yay_or_nay)
 - RSS feed: $source
 - date published: 2024-10-23T01:19:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1g9yke8/pose_test_before_any_conversion_yay_or_nay/"> <img src="https://b.thumbs.redditmedia.com/e8BajYcZQDERHOnaRLe4nw4qLo6zTLPvau4XaQhrEeE.jpg" alt="Pose test before any conversion. Yay or nay?" title="Pose test before any conversion. Yay or nay?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>The Contemptor is gonna get a lot of skulls to be a World Eater&#39;s dread, and the Ballistus will get a ton of DA bitz. Gonna have fun doing lighting effects on the lascannon beams.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ZedekiahCromwell"> /u/ZedekiahCromwell </a> <br/> <span><a href="https://www.reddit.com/gallery/1g9yke8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1g9yke8/pose_test_before_any_conversion_yay_or_nay/">[comments]</a></span> </td></tr></table>

## Nearly 200 pages in so far and I'm enjoying it. This is my 1st ever venture into the Black Library.
 - [https://www.reddit.com/r/Warhammer40k/comments/1g9y88h/nearly_200_pages_in_so_far_and_im_enjoying_it](https://www.reddit.com/r/Warhammer40k/comments/1g9y88h/nearly_200_pages_in_so_far_and_im_enjoying_it)
 - RSS feed: $source
 - date published: 2024-10-23T01:02:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1g9y88h/nearly_200_pages_in_so_far_and_im_enjoying_it/"> <img src="https://preview.redd.it/vpvq5nppnewd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=21297af62bca8d2507fbf458187219ceeb34e10a" alt="Nearly 200 pages in so far and I'm enjoying it. This is my 1st ever venture into the Black Library." title="Nearly 200 pages in so far and I'm enjoying it. This is my 1st ever venture into the Black Library." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MutantApocalypse"> /u/MutantApocalypse </a> <br/> <span><a href="https://i.redd.it/vpvq5nppnewd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1g9y88h/nearly_200_pages_in_so_far_and_im_enjoying_it/">[comments]</a></span> </td></tr></table>

## I melted the face of the hellbrute with a little glue before working on it, What do you think ?
 - [https://www.reddit.com/r/Warhammer40k/comments/1g9xdd2/i_melted_the_face_of_the_hellbrute_with_a_little](https://www.reddit.com/r/Warhammer40k/comments/1g9xdd2/i_melted_the_face_of_the_hellbrute_with_a_little)
 - RSS feed: $source
 - date published: 2024-10-23T00:21:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Warhammer40k/comments/1g9xdd2/i_melted_the_face_of_the_hellbrute_with_a_little/"> <img src="https://preview.redd.it/p7rqdnn8gewd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=59204725683b9c2cd7b9b9e63bfd8c4d6537ae6f" alt="I melted the face of the hellbrute with a little glue before working on it, What do you think ?" title="I melted the face of the hellbrute with a little glue before working on it, What do you think ?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/alexdrummond"> /u/alexdrummond </a> <br/> <span><a href="https://i.redd.it/p7rqdnn8gewd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Warhammer40k/comments/1g9xdd2/i_melted_the_face_of_the_hellbrute_with_a_little/">[comments]</a></span> </td></tr></table>

