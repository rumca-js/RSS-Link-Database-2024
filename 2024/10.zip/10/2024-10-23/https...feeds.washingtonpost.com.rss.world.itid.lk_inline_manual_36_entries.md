# Source:The Washington Post - World, URL:https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36, language:en-US

## U.K’s Labour denies election interference allegations from Trump campaign
 - [https://www.washingtonpost.com/world/2024/10/23/trump-election-complaint-uk-labour-party](https://www.washingtonpost.com/world/2024/10/23/trump-election-complaint-uk-labour-party)
 - RSS feed: $source
 - date published: 2024-10-23T12:54:24+00:00

British Prime Minister Keir Starmer dismissed the allegations that Labour was financially supporting its members who volunteered for the Harris campaign.

## 36-year-old surfer dies after being impaled by sharp-billed fish
 - [https://www.washingtonpost.com/world/2024/10/23/giulia-manfrini-surfer-impaled-fish-indonesia](https://www.washingtonpost.com/world/2024/10/23/giulia-manfrini-surfer-impaled-fish-indonesia)
 - RSS feed: $source
 - date published: 2024-10-23T12:10:23+00:00

Italian surfer Giulia Manfrini was surfing in the Mentawai Islands when she was impaled by a swordfish, Indonesian authorities said. The resort said it was a needlefish. 

## U.S. defense chief says North Korean troops in Russia, but purpose unclear
 - [https://www.washingtonpost.com/world/2024/10/23/austin-north-korea-troops-russia](https://www.washingtonpost.com/world/2024/10/23/austin-north-korea-troops-russia)
 - RSS feed: $source
 - date published: 2024-10-23T11:07:57+00:00

Ukraine and South Korea have repeatedly accused North Korea of sending troops to Russia to aid in its war.

## Putin is hosting the BRICS summit in Russia. What to know. 
 - [https://www.washingtonpost.com/world/2024/10/23/brics-summit-2024-countries-russia-putin](https://www.washingtonpost.com/world/2024/10/23/brics-summit-2024-countries-russia-putin)
 - RSS feed: $source
 - date published: 2024-10-23T10:51:22+00:00

Russian President Vladimir Putin is hosting leaders from China, India and other countries for the bloc’s first meeting since its expansion.

## The internet fell for a dog filmed atop an Egyptian pyramid. Meet Apollo. 
 - [https://www.washingtonpost.com/climate-environment/2024/10/23/dog-on-pyramid-egypt-giza](https://www.washingtonpost.com/climate-environment/2024/10/23/dog-on-pyramid-egypt-giza)
 - RSS feed: $source
 - date published: 2024-10-23T07:51:06+00:00

A leader of a rescue group immediately recognized Apollo, one of millions of stray dogs in Egypt, barking at birds atop the Pyramid of Khafre.

## Live Briefing: Northern Gaza conditions ‘beyond catastrophic,’ U.N. official says
 - [https://www.washingtonpost.com/world/2024/10/23/israel-iran-war-news-hamas-lebanon-hezbollah](https://www.washingtonpost.com/world/2024/10/23/israel-iran-war-news-hamas-lebanon-hezbollah)
 - RSS feed: $source
 - date published: 2024-10-23T06:47:43+00:00

The head of the United Nations’ Gaza humanitarian affairs office described a desperate situation brought on by Israel’s ramped-up military operations in the area.

## Vatican debate over women as deacons hits a big obstacle: Pope Francis
 - [https://www.washingtonpost.com/world/2024/10/23/women-deacons-vatican-synod-pope-francis](https://www.washingtonpost.com/world/2024/10/23/women-deacons-vatican-synod-pope-francis)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:00+00:00

In the final days of the most significant Catholic gathering since the 1960s, the prospect of women being ordained appears off the table for during Francis’s papacy.

## 19-year-old Walmart employee found dead inside walk-in oven
 - [https://www.washingtonpost.com/world/2024/10/23/walmart-employee-oven-death](https://www.washingtonpost.com/world/2024/10/23/walmart-employee-oven-death)
 - RSS feed: $source
 - date published: 2024-10-23T04:31:50+00:00

Police in eastern Canada said the woman was discovered inside the store’s bakery department oven. The cause and manner of death are under investigation.

## The growing tension within the BRICS
 - [https://www.washingtonpost.com/world/2024/10/23/brics-summit-russia-china](https://www.washingtonpost.com/world/2024/10/23/brics-summit-russia-china)
 - RSS feed: $source
 - date published: 2024-10-23T04:00:49+00:00

Russia and China see the burgeoning bloc as a vehicle for confrontation with the West. Other influential member states are not so keen.

