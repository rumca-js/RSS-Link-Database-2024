# Source:Popular Science, URL:https://www.popsci.com/feed, language:en-US

## Jeff VanderMeer talks about his new novel and ‘deranged court jester’ Elon Musk
 - [https://www.popsci.com/science/jeff-vandermeer-absolution-interview](https://www.popsci.com/science/jeff-vandermeer-absolution-interview)
 - RSS feed: $source
 - date published: 2024-10-23T10:01:11+00:00

<p>'Absolution' takes us back to Area X.</p>
<p>The post <a href="https://www.popsci.com/science/jeff-vandermeer-absolution-interview/">Jeff VanderMeer talks about his new novel and ‘deranged court jester’ Elon Musk</a> appeared first on <a href="https://www.popsci.com">Popular Science</a>.</p>


## The ‘Mad Gasser of Mattoon’ is one of history’s most bizarre unsolved mysteries
 - [https://www.popsci.com/science/mad-gasser-of-mattoon-weirdest-thing](https://www.popsci.com/science/mad-gasser-of-mattoon-weirdest-thing)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:00+00:00

<p>Plus other weird things we learned this week.</p>
<p>The post <a href="https://www.popsci.com/science/mad-gasser-of-mattoon-weirdest-thing/">The ‘Mad Gasser of Mattoon’ is one of history’s most bizarre unsolved mysteries</a> appeared first on <a href="https://www.popsci.com">Popular Science</a>.</p>


