# Source:GamingOnLinux Latest Articles, URL:https://www.gamingonlinux.com/article_rss.php, language:en-us

## EA Anti-Cheat arrives for Battlefield 1 breaking it on Steam Deck / Linux
 - [https://www.gamingonlinux.com/2024/10/ea-anti-cheat-arrives-for-battlefield-1-breaking-it-on-steam-deck-linux](https://www.gamingonlinux.com/2024/10/ea-anti-cheat-arrives-for-battlefield-1-breaking-it-on-steam-deck-linux)
 - RSS feed: $source
 - date published: 2024-10-23T12:30:14+00:00

It's here. EA Anti-Cheat has now been rolled out into Battlefield 1, breaking another multiplayer game on Steam Deck and Desktop Linux.<p><img src="https://www.gamingonlinux.com/uploads/articles/tagline_images/373026361id25502gol.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/10/ea-anti-cheat-arrives-for-battlefield-1-breaking-it-on-steam-deck-linux/">GamingOnLinux</a>.</p>

## Creepy retro horror game Fear the Spotlight is out now
 - [https://www.gamingonlinux.com/2024/10/creepy-retro-horror-game-fear-the-spotlight-is-out-now](https://www.gamingonlinux.com/2024/10/creepy-retro-horror-game-fear-the-spotlight-is-out-now)
 - RSS feed: $source
 - date published: 2024-10-23T12:10:17+00:00

Fear the Spotlight from Cozy Game Pals and Blumhouse Games is a retro-styled horror game that looks like it would fit right in on the original PlayStation. It's just be re-released on Steam with Linux support.<p><img src="https://www.gamingonlinux.com/uploads/articles/tagline_images/1339187685id25501gol.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/10/creepy-retro-horror-game-fear-the-spotlight-is-out-now/">GamingOnLinux</a>.</p>

## Unified launcher for Windows games on Linux (UMU) v1.1.3 out now
 - [https://www.gamingonlinux.com/2024/10/unified-launcher-for-windows-games-on-linux-umu-v113-out-now](https://www.gamingonlinux.com/2024/10/unified-launcher-for-windows-games-on-linux-umu-v113-out-now)
 - RSS feed: $source
 - date published: 2024-10-23T11:10:20+00:00

Continuing to improve compatibility with Windows games on Linux outside of Steam, the Unified launcher for Windows games on Linux (UMU) has another release out now.<p><img src="https://www.gamingonlinux.com/uploads/articles/tagline_images/280357901id25500gol.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/10/unified-launcher-for-windows-games-on-linux-umu-v113-out-now/">GamingOnLinux</a>.</p>

## Escape Simulator gets a free Talos Principle DLC out now, plus a paid DLC in December
 - [https://www.gamingonlinux.com/2024/10/escape-simulator-gets-a-free-talos-principle-dlc-out-now-plus-a-paid-dlc-in-december](https://www.gamingonlinux.com/2024/10/escape-simulator-gets-a-free-talos-principle-dlc-out-now-plus-a-paid-dlc-in-december)
 - RSS feed: $source
 - date published: 2024-10-23T10:57:20+00:00

Escape Simulator from Pine Studio continues doing some really cool additions, with The Talos Principle getting a little free crossover DLC out now.<p><img src="https://www.gamingonlinux.com/uploads/articles/tagline_images/108720668id25499gol.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/10/escape-simulator-gets-a-free-talos-principle-dlc-out-now-plus-a-paid-dlc-in-december/">GamingOnLinux</a>.</p>

