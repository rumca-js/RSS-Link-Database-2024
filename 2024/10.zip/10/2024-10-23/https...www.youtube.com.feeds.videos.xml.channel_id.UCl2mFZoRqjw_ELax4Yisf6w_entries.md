# Source:Louis Rossmann, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## taking a quick break from writing the manual to say hi to a koi fish :)
 - [https://www.youtube.com/watch?v=c6zXVGXjtQA](https://www.youtube.com/watch?v=c6zXVGXjtQA)
 - RSS feed: $source
 - date published: 2024-10-23T07:26:24+00:00

None

