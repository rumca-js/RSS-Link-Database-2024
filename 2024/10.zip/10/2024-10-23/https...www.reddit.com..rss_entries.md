# Source:Reddit - Front Page, URL:https://www.reddit.com/.rss, language:en-US

## What happened here and ig we getting more censorship now
 - [https://www.reddit.com/r/CharacterAI/comments/1ga9jwv/what_happened_here_and_ig_we_getting_more](https://www.reddit.com/r/CharacterAI/comments/1ga9jwv/what_happened_here_and_ig_we_getting_more)
 - RSS feed: $source
 - date published: 2024-10-23T12:40:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/CharacterAI/comments/1ga9jwv/what_happened_here_and_ig_we_getting_more/"> <img src="https://preview.redd.it/5037vcu44iwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8b70b4450450188060968d54a6de48ace72bd8b1" alt="What happened here and ig we getting more censorship now " title="What happened here and ig we getting more censorship now " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PipeDependent7890"> /u/PipeDependent7890 </a> &#32; to &#32; <a href="https://www.reddit.com/r/CharacterAI/"> r/CharacterAI </a> <br/> <span><a href="https://i.redd.it/5037vcu44iwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/CharacterAI/comments/1ga9jwv/what_happened_here_and_ig_we_getting_more/">[comments]</a></span> </td></tr></table>

## Now that anyone can get the Tutorial LC from the Herta shop, tell me you are playing this game from first patches, without telling me you are playing from first patches. I'll go first.
 - [https://www.reddit.com/r/HonkaiStarRail/comments/1ga9769/now_that_anyone_can_get_the_tutorial_lc_from_the](https://www.reddit.com/r/HonkaiStarRail/comments/1ga9769/now_that_anyone_can_get_the_tutorial_lc_from_the)
 - RSS feed: $source
 - date published: 2024-10-23T12:22:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga9769/now_that_anyone_can_get_the_tutorial_lc_from_the/"> <img src="https://preview.redd.it/ixxhpgh60iwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=87f7b86c4f6c1c1e8a79eab3c8be73c2674e81a7" alt="Now that anyone can get the Tutorial LC from the Herta shop, tell me you are playing this game from first patches, without telling me you are playing from first patches. I'll go first." title="Now that anyone can get the Tutorial LC from the Herta shop, tell me you are playing this game from first patches, without telling me you are playing from first patches. I'll go first." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/never_agree"> /u/never_agree </a> &#32; to &#32; <a href="https://www.reddit.com/r/HonkaiStarRail/"> r/HonkaiStarRail </a> <br/> <span><a href="https://i.redd.it/ixxhpgh60iwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HonkaiStarRail/c

## Liar's Bar banned words
 - [https://www.reddit.com/r/forsen/comments/1ga8wo4/liars_bar_banned_words](https://www.reddit.com/r/forsen/comments/1ga8wo4/liars_bar_banned_words)
 - RSS feed: $source
 - date published: 2024-10-23T12:06:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/forsen/comments/1ga8wo4/liars_bar_banned_words/"> <img src="https://preview.redd.it/vbf0m1n6yhwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0bf37bcb3a60546c2f8a937f523c27f6867f6420" alt="Liar's Bar banned words" title="Liar's Bar banned words" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NarutoUA1337"> /u/NarutoUA1337 </a> &#32; to &#32; <a href="https://www.reddit.com/r/forsen/"> r/forsen </a> <br/> <span><a href="https://i.redd.it/vbf0m1n6yhwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/forsen/comments/1ga8wo4/liars_bar_banned_words/">[comments]</a></span> </td></tr></table>

## 🐺🐺🐺
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1ga8gck/_](https://www.reddit.com/r/okkolegauposledzony/comments/1ga8gck/_)
 - RSS feed: $source
 - date published: 2024-10-23T11:43:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ga8gck/_/"> <img src="https://preview.redd.it/dy62b6n2uhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=87c2a85686e4530e32e3415691865bc26cc49268" alt="🐺🐺🐺" title="🐺🐺🐺" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/i_like_southpark"> /u/i_like_southpark </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br/> <span><a href="https://i.redd.it/dy62b6n2uhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ga8gck/_/">[comments]</a></span> </td></tr></table>

## Class did “too” good on the midterm, so now the Prof is puttin' a cap on all our Final grades.
 - [https://www.reddit.com/r/mildlyinfuriating/comments/1ga8fff/class_did_too_good_on_the_midterm_so_now_the_prof](https://www.reddit.com/r/mildlyinfuriating/comments/1ga8fff/class_did_too_good_on_the_midterm_so_now_the_prof)
 - RSS feed: $source
 - date published: 2024-10-23T11:42:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinfuriating/comments/1ga8fff/class_did_too_good_on_the_midterm_so_now_the_prof/"> <img src="https://preview.redd.it/3rwp7ihqthwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e3b1306d9367fcbb8ba308105d0d8d8bff3c901c" alt="Class did “too” good on the midterm, so now the Prof is puttin' a cap on all our Final grades." title="Class did “too” good on the midterm, so now the Prof is puttin' a cap on all our Final grades." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ybaemarb"> /u/ybaemarb </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinfuriating/"> r/mildlyinfuriating </a> <br/> <span><a href="https://i.redd.it/3rwp7ihqthwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/mildlyinfuriating/comments/1ga8fff/class_did_too_good_on_the_midterm_so_now_the_prof/">[comments]</a></span> </td></tr></table>

## This shit came to at three in the morning
 - [https://www.reddit.com/r/Grimdank/comments/1ga8cog/this_shit_came_to_at_three_in_the_morning](https://www.reddit.com/r/Grimdank/comments/1ga8cog/this_shit_came_to_at_three_in_the_morning)
 - RSS feed: $source
 - date published: 2024-10-23T11:38:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Grimdank/comments/1ga8cog/this_shit_came_to_at_three_in_the_morning/"> <img src="https://preview.redd.it/b8how5c3thwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=305ad375e7092b7c4f140f5acf64e56cb26b27c7" alt="This shit came to at three in the morning " title="This shit came to at three in the morning " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/StuckInthebasement2"> /u/StuckInthebasement2 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Grimdank/"> r/Grimdank </a> <br/> <span><a href="https://i.redd.it/b8how5c3thwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Grimdank/comments/1ga8cog/this_shit_came_to_at_three_in_the_morning/">[comments]</a></span> </td></tr></table>

## A map of Poland, but every voivodeship gets the land closest to its capital
 - [https://www.reddit.com/r/poland/comments/1ga8aco/a_map_of_poland_but_every_voivodeship_gets_the](https://www.reddit.com/r/poland/comments/1ga8aco/a_map_of_poland_but_every_voivodeship_gets_the)
 - RSS feed: $source
 - date published: 2024-10-23T11:34:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/poland/comments/1ga8aco/a_map_of_poland_but_every_voivodeship_gets_the/"> <img src="https://preview.redd.it/5buwwfvdshwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=cc8706004b5fe506f5abffdbad7c843afac9b8d2" alt="A map of Poland, but every voivodeship gets the land closest to its capital" title="A map of Poland, but every voivodeship gets the land closest to its capital" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LopacixGaming"> /u/LopacixGaming </a> &#32; to &#32; <a href="https://www.reddit.com/r/poland/"> r/poland </a> <br/> <span><a href="https://i.redd.it/5buwwfvdshwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/poland/comments/1ga8aco/a_map_of_poland_but_every_voivodeship_gets_the/">[comments]</a></span> </td></tr></table>

## Najlepszy kefir
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1ga80w3/najlepszy_kefir](https://www.reddit.com/r/okkolegauposledzony/comments/1ga80w3/najlepszy_kefir)
 - RSS feed: $source
 - date published: 2024-10-23T11:19:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ga80w3/najlepszy_kefir/"> <img src="https://preview.redd.it/q78ahgjnphwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=eb604a995e56fec4c8937db74f2d5245c2109f64" alt="Najlepszy kefir " title="Najlepszy kefir " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>To jest mój ulubiony kefir. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PeaceNo406"> /u/PeaceNo406 </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br/> <span><a href="https://i.redd.it/q78ahgjnphwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ga80w3/najlepszy_kefir/">[comments]</a></span> </td></tr></table>

## How Finns would vote in the US presidential election
 - [https://www.reddit.com/r/europe/comments/1ga80hr/how_finns_would_vote_in_the_us_presidential](https://www.reddit.com/r/europe/comments/1ga80hr/how_finns_would_vote_in_the_us_presidential)
 - RSS feed: $source
 - date published: 2024-10-23T11:18:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1ga80hr/how_finns_would_vote_in_the_us_presidential/"> <img src="https://b.thumbs.redditmedia.com/dCLc_pgRfL46tgMhVabxYttabNYiCaBTYZOGGPH-Lis.jpg" alt="How Finns would vote in the US presidential election" title="How Finns would vote in the US presidential election" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MysteriousPenguins"> /u/MysteriousPenguins </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga80hr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1ga80hr/how_finns_would_vote_in_the_us_presidential/">[comments]</a></span> </td></tr></table>

## Why can't inserters fill my fish pond?
 - [https://www.reddit.com/r/factorio/comments/1ga7kdt/why_cant_inserters_fill_my_fish_pond](https://www.reddit.com/r/factorio/comments/1ga7kdt/why_cant_inserters_fill_my_fish_pond)
 - RSS feed: $source
 - date published: 2024-10-23T10:50:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/factorio/comments/1ga7kdt/why_cant_inserters_fill_my_fish_pond/"> <img src="https://preview.redd.it/3erlnfuikhwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=7ee6a0a0e07a53beeccfd794278b236b858f9d52" alt="Why can't inserters fill my fish pond?" title="Why can't inserters fill my fish pond?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Evan_Underscore"> /u/Evan_Underscore </a> &#32; to &#32; <a href="https://www.reddit.com/r/factorio/"> r/factorio </a> <br/> <span><a href="https://i.redd.it/3erlnfuikhwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/factorio/comments/1ga7kdt/why_cant_inserters_fill_my_fish_pond/">[comments]</a></span> </td></tr></table>

## Men with big bellies are considered very attractive in Ethiopia’s Bodi tribe. Tribesmen try to gain belly fat by drinking cow’s blood and milk for 6 months. After that, the man with the biggest belly is declared winner and considered to be the most handsome.
 - [https://www.reddit.com/r/Damnthatsinteresting/comments/1ga7jov/men_with_big_bellies_are_considered_very](https://www.reddit.com/r/Damnthatsinteresting/comments/1ga7jov/men_with_big_bellies_are_considered_very)
 - RSS feed: $source
 - date published: 2024-10-23T10:49:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Dev-98"> /u/Dev-98 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Damnthatsinteresting/"> r/Damnthatsinteresting </a> <br/> <span><a href="https://i.redd.it/0s7a8v7dkhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1ga7jov/men_with_big_bellies_are_considered_very/">[comments]</a></span>

## The most sane explanation
 - [https://www.reddit.com/r/polandball/comments/1ga78ku/the_most_sane_explanation](https://www.reddit.com/r/polandball/comments/1ga78ku/the_most_sane_explanation)
 - RSS feed: $source
 - date published: 2024-10-23T10:29:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/polandball/comments/1ga78ku/the_most_sane_explanation/"> <img src="https://preview.redd.it/e4ho2z2oghwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=ec53e2c220c683bd4107cb40f8f0c2351ddd299f" alt="The most sane explanation" title="The most sane explanation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dolmande"> /u/Dolmande </a> &#32; to &#32; <a href="https://www.reddit.com/r/polandball/"> r/polandball </a> <br/> <span><a href="https://i.redd.it/e4ho2z2oghwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/polandball/comments/1ga78ku/the_most_sane_explanation/">[comments]</a></span> </td></tr></table>

## Petersburg Griffin, I need your help!
 - [https://www.reddit.com/r/PeterExplainsTheJoke/comments/1ga6vn2/petersburg_griffin_i_need_your_help](https://www.reddit.com/r/PeterExplainsTheJoke/comments/1ga6vn2/petersburg_griffin_i_need_your_help)
 - RSS feed: $source
 - date published: 2024-10-23T10:05:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/PeterExplainsTheJoke/comments/1ga6vn2/petersburg_griffin_i_need_your_help/"> <img src="https://preview.redd.it/godbka4kchwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=6d8c394bcfa63c2ec4cabf24530882ac0a3db8d9" alt="Petersburg Griffin, I need your help! " title="Petersburg Griffin, I need your help! " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ThetrueMarkaka"> /u/ThetrueMarkaka </a> &#32; to &#32; <a href="https://www.reddit.com/r/PeterExplainsTheJoke/"> r/PeterExplainsTheJoke </a> <br/> <span><a href="https://i.redd.it/godbka4kchwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/PeterExplainsTheJoke/comments/1ga6vn2/petersburg_griffin_i_need_your_help/">[comments]</a></span> </td></tr></table>

## No butter knife needed
 - [https://www.reddit.com/r/madlads/comments/1ga6tpm/no_butter_knife_needed](https://www.reddit.com/r/madlads/comments/1ga6tpm/no_butter_knife_needed)
 - RSS feed: $source
 - date published: 2024-10-23T10:01:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/madlads/comments/1ga6tpm/no_butter_knife_needed/"> <img src="https://preview.redd.it/agznv88wbhwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7c8e112722c81e3bce45f794f7de2a2539ca03ee" alt="No butter knife needed " title="No butter knife needed " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheCoolBlondeGirl"> /u/TheCoolBlondeGirl </a> &#32; to &#32; <a href="https://www.reddit.com/r/madlads/"> r/madlads </a> <br/> <span><a href="https://i.redd.it/agznv88wbhwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/madlads/comments/1ga6tpm/no_butter_knife_needed/">[comments]</a></span> </td></tr></table>

## One of the Curiosity Rover's wheels after traversing Mars for 11yrs
 - [https://www.reddit.com/r/interestingasfuck/comments/1ga5vkw/one_of_the_curiosity_rovers_wheels_after](https://www.reddit.com/r/interestingasfuck/comments/1ga5vkw/one_of_the_curiosity_rovers_wheels_after)
 - RSS feed: $source
 - date published: 2024-10-23T08:52:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/interestingasfuck/comments/1ga5vkw/one_of_the_curiosity_rovers_wheels_after/"> <img src="https://preview.redd.it/wwazfbpgzgwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f5fb005226e7af24ba4bf4c9f969970f79c59fd7" alt="One of the Curiosity Rover's wheels after traversing Mars for 11yrs " title="One of the Curiosity Rover's wheels after traversing Mars for 11yrs " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/QuickResidentjoe"> /u/QuickResidentjoe </a> &#32; to &#32; <a href="https://www.reddit.com/r/interestingasfuck/"> r/interestingasfuck </a> <br/> <span><a href="https://i.redd.it/wwazfbpgzgwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/interestingasfuck/comments/1ga5vkw/one_of_the_curiosity_rovers_wheels_after/">[comments]</a></span> </td></tr></table>

## In light of recent events specifically in the Acheron sub
 - [https://www.reddit.com/r/HonkaiStarRail/comments/1ga5oot/in_light_of_recent_events_specifically_in_the](https://www.reddit.com/r/HonkaiStarRail/comments/1ga5oot/in_light_of_recent_events_specifically_in_the)
 - RSS feed: $source
 - date published: 2024-10-23T08:37:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga5oot/in_light_of_recent_events_specifically_in_the/"> <img src="https://preview.redd.it/7cj7eucuwgwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=69dd656feb02997f2c2dfe912a654ac606f3b9a7" alt="In light of recent events specifically in the Acheron sub" title="In light of recent events specifically in the Acheron sub" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ambulance-kun"> /u/ambulance-kun </a> &#32; to &#32; <a href="https://www.reddit.com/r/HonkaiStarRail/"> r/HonkaiStarRail </a> <br/> <span><a href="https://i.redd.it/7cj7eucuwgwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga5oot/in_light_of_recent_events_specifically_in_the/">[comments]</a></span> </td></tr></table>

## I can't with this guy
 - [https://www.reddit.com/r/dankmemes/comments/1ga5gl0/i_cant_with_this_guy](https://www.reddit.com/r/dankmemes/comments/1ga5gl0/i_cant_with_this_guy)
 - RSS feed: $source
 - date published: 2024-10-23T08:20:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/dankmemes/comments/1ga5gl0/i_cant_with_this_guy/"> <img src="https://b.thumbs.redditmedia.com/OAfJ_tFkyvz6wAl7k0jfymUqYMLegChfzFUFrt7Fu4E.jpg" alt="I can't with this guy" title="I can't with this guy" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This meme is based off of real events </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DramaticRock_"> /u/DramaticRock_ </a> &#32; to &#32; <a href="https://www.reddit.com/r/dankmemes/"> r/dankmemes </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga5gl0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/dankmemes/comments/1ga5gl0/i_cant_with_this_guy/">[comments]</a></span> </td></tr></table>

## pronouns
 - [https://www.reddit.com/r/comedyheaven/comments/1ga5fv1/pronouns](https://www.reddit.com/r/comedyheaven/comments/1ga5fv1/pronouns)
 - RSS feed: $source
 - date published: 2024-10-23T08:18:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comedyheaven/comments/1ga5fv1/pronouns/"> <img src="https://preview.redd.it/5ld5rfqetgwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=efdac5b2ba63fb6402ef766abe2d63c3f39926ea" alt="pronouns" title="pronouns" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/princelyjester"> /u/princelyjester </a> &#32; to &#32; <a href="https://www.reddit.com/r/comedyheaven/"> r/comedyheaven </a> <br/> <span><a href="https://i.redd.it/5ld5rfqetgwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comedyheaven/comments/1ga5fv1/pronouns/">[comments]</a></span> </td></tr></table>

## Williams receives $195 million injection
 - [https://www.reddit.com/r/formula1/comments/1ga5c67/williams_receives_195_million_injection](https://www.reddit.com/r/formula1/comments/1ga5c67/williams_receives_195_million_injection)
 - RSS feed: $source
 - date published: 2024-10-23T08:10:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/formula1/comments/1ga5c67/williams_receives_195_million_injection/"> <img src="https://external-preview.redd.it/qzyiIvXI5Me-JGVhAxd0GfQiunexzWOF8tQOIcD7oNQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9663ed9aba8714a2220f9e94c7801b14ad51d19b" alt="Williams receives $195 million injection" title="Williams receives $195 million injection" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Takagero"> /u/Takagero </a> &#32; to &#32; <a href="https://www.reddit.com/r/formula1/"> r/formula1 </a> <br/> <span><a href="https://speedcafe.com/williams-receives-195-million-injection/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/formula1/comments/1ga5c67/williams_receives_195_million_injection/">[comments]</a></span> </td></tr></table>

## Alarming rise in poverty in Poland
 - [https://www.reddit.com/r/poland/comments/1ga5aqq/alarming_rise_in_poverty_in_poland](https://www.reddit.com/r/poland/comments/1ga5aqq/alarming_rise_in_poverty_in_poland)
 - RSS feed: $source
 - date published: 2024-10-23T08:07:42+00:00

<!-- SC_OFF --><div class="md"><p>Poland on the brink of social crisis. It means: - A dramatic increase in extreme poverty to 6.6% of the population, affecting 2.5 millions Poles - The expansion of social exclusion to 46%, impacting 17.3 million Poles</p> <p>Polish population is around 37 million people. It means 50% of population faces various forms of poverty problem.</p> <p>Source: <a href="https://next.gazeta.pl/next/7,151003,31391611,ogromne-ubostwo-w-polsce-fatalne-dane-najgorsze-od-niemal.html">https://next.gazeta.pl/next/7,151003,31391611,ogromne-ubostwo-w-polsce-fatalne-dane-najgorsze-od-niemal.html</a> <a href="https://www.eapn.eu/wp-content/uploads/2024/10/eapn-PL-Poverty-Watch-Poland-2024-ENG-6027.pdf">https://www.eapn.eu/wp-content/uploads/2024/10/eapn-PL-Poverty-Watch-Poland-2024-ENG-6027.pdf</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Pm0001_"> /u/Pm0001_ </a> &#32; to &#32; <a href="https://www.reddit.com/r/poland/"> r/pol

## Today marks the anniversary of the 1956 Hungarian Revolution against Soviet domination.
 - [https://www.reddit.com/r/europe/comments/1ga4una/today_marks_the_anniversary_of_the_1956_hungarian](https://www.reddit.com/r/europe/comments/1ga4una/today_marks_the_anniversary_of_the_1956_hungarian)
 - RSS feed: $source
 - date published: 2024-10-23T07:38:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1ga4una/today_marks_the_anniversary_of_the_1956_hungarian/"> <img src="https://preview.redd.it/2bh7s4a2mgwd1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=8378c6356c38a8177d8ef08305e9399bfb15fbd3" alt="Today marks the anniversary of the 1956 Hungarian Revolution against Soviet domination." title="Today marks the anniversary of the 1956 Hungarian Revolution against Soviet domination." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/the_battle_bunny"> /u/the_battle_bunny </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br/> <span><a href="https://i.redd.it/2bh7s4a2mgwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1ga4una/today_marks_the_anniversary_of_the_1956_hungarian/">[comments]</a></span> </td></tr></table>

## The newest Hungarian poll shows that the TISZA party is ahead of Fidesz
 - [https://www.reddit.com/r/europe/comments/1ga4dic/the_newest_hungarian_poll_shows_that_the_tisza](https://www.reddit.com/r/europe/comments/1ga4dic/the_newest_hungarian_poll_shows_that_the_tisza)
 - RSS feed: $source
 - date published: 2024-10-23T07:02:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1ga4dic/the_newest_hungarian_poll_shows_that_the_tisza/"> <img src="https://b.thumbs.redditmedia.com/i1DwtU5DgIcn115kZOoUlM9DPg_KwNgaAzoCl7hJVyg.jpg" alt="The newest Hungarian poll shows that the TISZA party is ahead of Fidesz" title="The newest Hungarian poll shows that the TISZA party is ahead of Fidesz" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dead97531"> /u/dead97531 </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br/> <span><a href="https://www.reddit.com/gallery/1ga4dic">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1ga4dic/the_newest_hungarian_poll_shows_that_the_tisza/">[comments]</a></span> </td></tr></table>

## Cursed_Riley
 - [https://www.reddit.com/r/cursedcomments/comments/1ga3tqu/cursed_riley](https://www.reddit.com/r/cursedcomments/comments/1ga3tqu/cursed_riley)
 - RSS feed: $source
 - date published: 2024-10-23T06:22:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/cursedcomments/comments/1ga3tqu/cursed_riley/"> <img src="https://preview.redd.it/h1s43xzo8gwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2482066cc8091fbe4f57200a9752f7e2b4d3f74f" alt="Cursed_Riley" title="Cursed_Riley" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheIncredibleAspie"> /u/TheIncredibleAspie </a> &#32; to &#32; <a href="https://www.reddit.com/r/cursedcomments/"> r/cursedcomments </a> <br/> <span><a href="https://i.redd.it/h1s43xzo8gwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/cursedcomments/comments/1ga3tqu/cursed_riley/">[comments]</a></span> </td></tr></table>

## A very literal interpretation
 - [https://www.reddit.com/r/technicallythetruth/comments/1ga3kn1/a_very_literal_interpretation](https://www.reddit.com/r/technicallythetruth/comments/1ga3kn1/a_very_literal_interpretation)
 - RSS feed: $source
 - date published: 2024-10-23T06:04:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technicallythetruth/comments/1ga3kn1/a_very_literal_interpretation/"> <img src="https://preview.redd.it/jxzmy3mj5gwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=62f18837d456dddedeefe6151d63a3a501144c9a" alt="A very literal interpretation" title="A very literal interpretation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/elgooGmirror"> /u/elgooGmirror </a> &#32; to &#32; <a href="https://www.reddit.com/r/technicallythetruth/"> r/technicallythetruth </a> <br/> <span><a href="https://i.redd.it/jxzmy3mj5gwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technicallythetruth/comments/1ga3kn1/a_very_literal_interpretation/">[comments]</a></span> </td></tr></table>

## Complain all you want the ship has sailed!
 - [https://www.reddit.com/r/Grimdank/comments/1ga3dss/complain_all_you_want_the_ship_has_sailed](https://www.reddit.com/r/Grimdank/comments/1ga3dss/complain_all_you_want_the_ship_has_sailed)
 - RSS feed: $source
 - date published: 2024-10-23T05:51:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Grimdank/comments/1ga3dss/complain_all_you_want_the_ship_has_sailed/"> <img src="https://preview.redd.it/gymdgcu83gwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=90a00997b0b7fb155f6858b44b5c0ec0868ccc39" alt="Complain all you want the ship has sailed! " title="Complain all you want the ship has sailed! " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TaigaTigerVT"> /u/TaigaTigerVT </a> &#32; to &#32; <a href="https://www.reddit.com/r/Grimdank/"> r/Grimdank </a> <br/> <span><a href="https://i.redd.it/gymdgcu83gwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Grimdank/comments/1ga3dss/complain_all_you_want_the_ship_has_sailed/">[comments]</a></span> </td></tr></table>

## Prydwen cons for Rappa. ☕️
 - [https://www.reddit.com/r/HonkaiStarRail/comments/1ga2v7x/prydwen_cons_for_rappa](https://www.reddit.com/r/HonkaiStarRail/comments/1ga2v7x/prydwen_cons_for_rappa)
 - RSS feed: $source
 - date published: 2024-10-23T05:19:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga2v7x/prydwen_cons_for_rappa/"> <img src="https://preview.redd.it/4a560cyfxfwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7a16ae84e50f32717964b2ae5f5ad0f647f9c138" alt="Prydwen cons for Rappa. ☕️ " title="Prydwen cons for Rappa. ☕️ " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Makeup-less_Clown"> /u/Makeup-less_Clown </a> &#32; to &#32; <a href="https://www.reddit.com/r/HonkaiStarRail/"> r/HonkaiStarRail </a> <br/> <span><a href="https://i.redd.it/4a560cyfxfwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga2v7x/prydwen_cons_for_rappa/">[comments]</a></span> </td></tr></table>

## Finally, inner peace
 - [https://www.reddit.com/r/whenthe/comments/1ga1und/finally_inner_peace](https://www.reddit.com/r/whenthe/comments/1ga1und/finally_inner_peace)
 - RSS feed: $source
 - date published: 2024-10-23T04:15:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ga1und/finally_inner_peace/"> <img src="https://preview.redd.it/9x5ovhr4mfwd1.gif?width=640&amp;crop=smart&amp;s=20f8f98127089b046b9cb20be469d5fa3199e964" alt="Finally, inner peace " title="Finally, inner peace " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheRedditScarecrow"> /u/TheRedditScarecrow </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br/> <span><a href="https://i.redd.it/9x5ovhr4mfwd1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ga1und/finally_inner_peace/">[comments]</a></span> </td></tr></table>

## She worked very hard on it
 - [https://www.reddit.com/r/memes/comments/1ga19nt/she_worked_very_hard_on_it](https://www.reddit.com/r/memes/comments/1ga19nt/she_worked_very_hard_on_it)
 - RSS feed: $source
 - date published: 2024-10-23T03:42:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/memes/comments/1ga19nt/she_worked_very_hard_on_it/"> <img src="https://preview.redd.it/cxjyn5s7gfwd1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=6fec6a18557741e3348c5b6f40316841c3c60d6e" alt="She worked very hard on it" title="She worked very hard on it" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mementodory"> /u/mementodory </a> &#32; to &#32; <a href="https://www.reddit.com/r/memes/"> r/memes </a> <br/> <span><a href="https://i.redd.it/cxjyn5s7gfwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/memes/comments/1ga19nt/she_worked_very_hard_on_it/">[comments]</a></span> </td></tr></table>

## Garbage men saving kittens from the trash
 - [https://www.reddit.com/r/nextfuckinglevel/comments/1ga17h8/garbage_men_saving_kittens_from_the_trash](https://www.reddit.com/r/nextfuckinglevel/comments/1ga17h8/garbage_men_saving_kittens_from_the_trash)
 - RSS feed: $source
 - date published: 2024-10-23T03:39:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/nextfuckinglevel/comments/1ga17h8/garbage_men_saving_kittens_from_the_trash/"> <img src="https://external-preview.redd.it/Z3Q1ZTgzaGxmZndkMSverUs0yjXcLrLlDH9gRdZo8dsrothbG2CtXPCQHrr6.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=813a35dd566f39180a7de41ae777ffd782c63e92" alt="Garbage men saving kittens from the trash" title="Garbage men saving kittens from the trash" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CuriousWanderer567"> /u/CuriousWanderer567 </a> &#32; to &#32; <a href="https://www.reddit.com/r/nextfuckinglevel/"> r/nextfuckinglevel </a> <br/> <span><a href="https://v.redd.it/euv5gfjlffwd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/nextfuckinglevel/comments/1ga17h8/garbage_men_saving_kittens_from_the_trash/">[comments]</a></span> </td></tr></table>

## Chiropractor almost suffocates man
 - [https://www.reddit.com/r/Unexpected/comments/1ga16bq/chiropractor_almost_suffocates_man](https://www.reddit.com/r/Unexpected/comments/1ga16bq/chiropractor_almost_suffocates_man)
 - RSS feed: $source
 - date published: 2024-10-23T03:37:24+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/LaserGuy626"> /u/LaserGuy626 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Unexpected/"> r/Unexpected </a> <br/> <span><a href="https://v.redd.it/xavt8bfaffwd1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Unexpected/comments/1ga16bq/chiropractor_almost_suffocates_man/">[comments]</a></span>

## Prydwen 2.6 MoC Tier List (with Rappa)
 - [https://www.reddit.com/r/HonkaiStarRail/comments/1ga14w2/prydwen_26_moc_tier_list_with_rappa](https://www.reddit.com/r/HonkaiStarRail/comments/1ga14w2/prydwen_26_moc_tier_list_with_rappa)
 - RSS feed: $source
 - date published: 2024-10-23T03:35:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga14w2/prydwen_26_moc_tier_list_with_rappa/"> <img src="https://preview.redd.it/fff656ovefwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=adf4b99f9884f04b35fc9ccc61ccc9f2d5df82b4" alt="Prydwen 2.6 MoC Tier List (with Rappa)" title="Prydwen 2.6 MoC Tier List (with Rappa)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/meow3272"> /u/meow3272 </a> &#32; to &#32; <a href="https://www.reddit.com/r/HonkaiStarRail/"> r/HonkaiStarRail </a> <br/> <span><a href="https://i.redd.it/fff656ovefwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga14w2/prydwen_26_moc_tier_list_with_rappa/">[comments]</a></span> </td></tr></table>

## be real, has anyone ever bust to the tf2 calendar girl?
 - [https://www.reddit.com/r/tf2/comments/1ga14uu/be_real_has_anyone_ever_bust_to_the_tf2_calendar](https://www.reddit.com/r/tf2/comments/1ga14uu/be_real_has_anyone_ever_bust_to_the_tf2_calendar)
 - RSS feed: $source
 - date published: 2024-10-23T03:35:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/tf2/comments/1ga14uu/be_real_has_anyone_ever_bust_to_the_tf2_calendar/"> <img src="https://preview.redd.it/rk5byxbuefwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6cb2cdb401a01e7522607304a118591663278b53" alt="be real, has anyone ever bust to the tf2 calendar girl?" title="be real, has anyone ever bust to the tf2 calendar girl?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CorneliusDale"> /u/CorneliusDale </a> &#32; to &#32; <a href="https://www.reddit.com/r/tf2/"> r/tf2 </a> <br/> <span><a href="https://i.redd.it/rk5byxbuefwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/tf2/comments/1ga14uu/be_real_has_anyone_ever_bust_to_the_tf2_calendar/">[comments]</a></span> </td></tr></table>

## He tried
 - [https://www.reddit.com/r/meme/comments/1ga12c1/he_tried](https://www.reddit.com/r/meme/comments/1ga12c1/he_tried)
 - RSS feed: $source
 - date published: 2024-10-23T03:31:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/meme/comments/1ga12c1/he_tried/"> <img src="https://preview.redd.it/umsdr7dydfwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2a2dd0c720730b9371fe37e8263013e3594590be" alt="He tried" title="He tried" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/charmingfoxyxxxpie"> /u/charmingfoxyxxxpie </a> &#32; to &#32; <a href="https://www.reddit.com/r/meme/"> r/meme </a> <br/> <span><a href="https://i.redd.it/umsdr7dydfwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/meme/comments/1ga12c1/he_tried/">[comments]</a></span> </td></tr></table>

## Prydwen has updated their 2.6 tier list with Rappa (T1, T0, T0.5)
 - [https://www.reddit.com/r/HonkaiStarRail/comments/1ga0s4s/prydwen_has_updated_their_26_tier_list_with_rappa](https://www.reddit.com/r/HonkaiStarRail/comments/1ga0s4s/prydwen_has_updated_their_26_tier_list_with_rappa)
 - RSS feed: $source
 - date published: 2024-10-23T03:15:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga0s4s/prydwen_has_updated_their_26_tier_list_with_rappa/"> <img src="https://preview.redd.it/jsfckc7cbfwd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=825296a6eebabcffdbcf75120ae3c151b95d224e" alt="Prydwen has updated their 2.6 tier list with Rappa (T1, T0, T0.5)" title="Prydwen has updated their 2.6 tier list with Rappa (T1, T0, T0.5)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/XYXYZXY"> /u/XYXYZXY </a> &#32; to &#32; <a href="https://www.reddit.com/r/HonkaiStarRail/"> r/HonkaiStarRail </a> <br/> <span><a href="https://i.redd.it/jsfckc7cbfwd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HonkaiStarRail/comments/1ga0s4s/prydwen_has_updated_their_26_tier_list_with_rappa/">[comments]</a></span> </td></tr></table>

## Futanari [OC]
 - [https://www.reddit.com/r/comics/comments/1g9zzvo/futanari_oc](https://www.reddit.com/r/comics/comments/1g9zzvo/futanari_oc)
 - RSS feed: $source
 - date published: 2024-10-23T02:32:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1g9zzvo/futanari_oc/"> <img src="https://b.thumbs.redditmedia.com/a5AczZufNxfOmvEAJ5iX283T2_tR-ewMfNsVaEWSIIc.jpg" alt="Futanari [OC]" title="Futanari [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LeFauxCreux"> /u/LeFauxCreux </a> &#32; to &#32; <a href="https://www.reddit.com/r/comics/"> r/comics </a> <br/> <span><a href="https://www.reddit.com/gallery/1g9zzvo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1g9zzvo/futanari_oc/">[comments]</a></span> </td></tr></table>

## All the countries mentioned in the Bible
 - [https://www.reddit.com/r/MapPorn/comments/1g9zof0/all_the_countries_mentioned_in_the_bible](https://www.reddit.com/r/MapPorn/comments/1g9zof0/all_the_countries_mentioned_in_the_bible)
 - RSS feed: $source
 - date published: 2024-10-23T02:16:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/MapPorn/comments/1g9zof0/all_the_countries_mentioned_in_the_bible/"> <img src="https://preview.redd.it/nevbjm0t0fwd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0a35073980f3dd61a9fd64f8e32798b396689b44" alt="All the countries mentioned in the Bible " title="All the countries mentioned in the Bible " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Source was a another map I saw and then verified finding out it wasn’t correct so then I spent time checking all of them and making it accurate.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Persistent_Bug_0101"> /u/Persistent_Bug_0101 </a> &#32; to &#32; <a href="https://www.reddit.com/r/MapPorn/"> r/MapPorn </a> <br/> <span><a href="https://i.redd.it/nevbjm0t0fwd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/MapPorn/comments/1g9zof0/all_the_countries_mentioned_in_the_bible/">[comments]</a></span> </td></tr></table>

## Missed out on being the coolest MF in the gym
 - [https://www.reddit.com/r/shitposting/comments/1g9ymdq/missed_out_on_being_the_coolest_mf_in_the_gym](https://www.reddit.com/r/shitposting/comments/1g9ymdq/missed_out_on_being_the_coolest_mf_in_the_gym)
 - RSS feed: $source
 - date published: 2024-10-23T01:22:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shitposting/comments/1g9ymdq/missed_out_on_being_the_coolest_mf_in_the_gym/"> <img src="https://preview.redd.it/t7eacxf5rewd1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=774d3caec37448284c6b0c0513de0973a83a896b" alt="Missed out on being the coolest MF in the gym" title="Missed out on being the coolest MF in the gym" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/YouLostTheGamesorry"> /u/YouLostTheGamesorry </a> &#32; to &#32; <a href="https://www.reddit.com/r/shitposting/"> r/shitposting </a> <br/> <span><a href="https://i.redd.it/t7eacxf5rewd1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/shitposting/comments/1g9ymdq/missed_out_on_being_the_coolest_mf_in_the_gym/">[comments]</a></span> </td></tr></table>

## Petah???
 - [https://www.reddit.com/r/PeterExplainsTheJoke/comments/1g9yeaz/petah](https://www.reddit.com/r/PeterExplainsTheJoke/comments/1g9yeaz/petah)
 - RSS feed: $source
 - date published: 2024-10-23T01:11:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/PeterExplainsTheJoke/comments/1g9yeaz/petah/"> <img src="https://preview.redd.it/lzftux07pewd1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f96365d68cd56ae35e1578557b108d9121c06ff2" alt="Petah???" title="Petah???" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hot-Prior2874"> /u/Hot-Prior2874 </a> &#32; to &#32; <a href="https://www.reddit.com/r/PeterExplainsTheJoke/"> r/PeterExplainsTheJoke </a> <br/> <span><a href="https://i.redd.it/lzftux07pewd1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/PeterExplainsTheJoke/comments/1g9yeaz/petah/">[comments]</a></span> </td></tr></table>

