# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Kłopoty z wypłatami, spotkanie z szefem NBP. Pat w sprawie Cinkciarza
 - [https://tvn24.pl/biznes/prawo/klopoty-z-wyplatami-spotkanie-z-szefem-nbp-pat-w-sprawie-cinkciarza-st8147868?source=rss](https://tvn24.pl/biznes/prawo/klopoty-z-wyplatami-spotkanie-z-szefem-nbp-pat-w-sprawie-cinkciarza-st8147868?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:32:21+00:00


    
    <img src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-lsu7xq-portfel-konkret-5795734/alternates/LANDSCAPE_1280" alt="Kłopoty z wypłatami, spotkanie z szefem NBP. Pat w sprawie Cinkciarza" />
    Cinkciarz.pl kolejny dzień informuje, że "z przyczyn technicznych realizacja transakcji wymiany walut może trwać dłużej niż zwykle". Podobny komunikat zamieszczany jest regularnie od lipca. W mediach pojawiły się informacje, że na rachunkach firmy brakuje 150 milionów złotych, czemu spółka temu zdecydowanie zaprzecza. Przyznaje natomiast, że niedawno doszło do spotkania szefa holdingu z prezesem Narodowego Banku Polskiego Adamem Glapińskim w sprawie pożyczki, a także wsparcia w kwestii uzyskania licencji bankowej.
    
    

## Ciało 51-latka znalazł sąsiad. Zatrzymano pięć osób
 - [https://tvn24.pl/kielce/cialo-51-latka-znalazl-sasiad-zatrzymano-piec-osob-st8148493?source=rss](https://tvn24.pl/kielce/cialo-51-latka-znalazl-sasiad-zatrzymano-piec-osob-st8148493?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:08:22+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2592684-policja-zatrzymala-czterech-mezczyzn-zdjecie-ilustracyjne-ph8123320/alternates/LANDSCAPE_1280" alt="Ciało 51-latka znalazł sąsiad. Zatrzymano pięć osób" />
    Policja zatrzymała pięć osób, które mogą mieć związek z zabójstwem 51-latka z gminy Busko-Zdrój. Ciało mężczyzny zostało znalezione w jego mieszkaniu przez sąsiada. 
    
    

## Wojska Kim Dzong Una a front w Ukrainie. Radosław Sikorski zabiera głos
 - [https://tvn24.pl/swiat/wojska-kim-dzong-una-a-front-w-ukrainie-radoslaw-sikorski-zabiera-glos-st8148475?source=rss](https://tvn24.pl/swiat/wojska-kim-dzong-una-a-front-w-ukrainie-radoslaw-sikorski-zabiera-glos-st8148475?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:06:55+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3394924-espen-barth-eide-i-radoslaw-sikorski-ph8148473/alternates/LANDSCAPE_1280" alt="Wojska Kim Dzong Una a front w Ukrainie. Radosław Sikorski zabiera głos" />
    Minister spraw zagranicznych Radosław Sikorski skomentował w środę kwestię ewentualnego udziału wojsk Korei Północnej w wojnie w Ukrainie. Według jego informacji żołnierze Kim Dzong Una nie dotarli jeszcze na front i są na Dalekim Wschodzie. - Jeżeli Rosja potrzebuje wzywać na pomoc żołnierzy Korei Północnej, to to dużo mówi o jej stanie - ocenił szef norweskiego MSZ Espen Barth Eide. 
    
    

## Rusztowania zasłoniły mury zamku. Trwa renowacja
 - [https://tvn24.pl/kielce/checiny-rusztowania-zaslonily-mury-zamku-trwa-renowacja-st8148444?source=rss](https://tvn24.pl/kielce/checiny-rusztowania-zaslonily-mury-zamku-trwa-renowacja-st8148444?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:04:11+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6478803-renowacja-zamku-w-checinach-ph8148445/alternates/LANDSCAPE_1280" alt="Rusztowania zasłoniły mury zamku. Trwa renowacja" />
    Na zamku królewskim w Chęcinach zaczęły się prace renowacyjne. Odnowione zostaną między innymi mury i elementy baszt. Zamek ma status "trwałej ruiny", co oznacza, że jest szczególnie narażony na działanie czynników atmosferycznych. 
    
    

## W weekend nawet 20 stopni, potem duża zmiana pogody
 - [https://tvn24.pl/tvnmeteo/prognoza/w-weekend-nawet-20-stopni-potem-duza-zmiana-pogody-st8148454?source=rss](https://tvn24.pl/tvnmeteo/prognoza/w-weekend-nawet-20-stopni-potem-duza-zmiana-pogody-st8148454?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:03:26+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7027592-adobestock-117444363-ph8148518/alternates/LANDSCAPE_1280" alt="W weekend nawet 20 stopni, potem duża zmiana pogody" />
    W nadchodzących dniach pogodę w Polsce będzie kształtował wyż. Napłynie cieplejsze powietrze, które sprawi, że miejscami temperatura wzrośnie do 20 stopni Celsjusza. Nowy tydzień przyniesie nam jednak załamanie pogody. 
    
    

## Ktoś ostrzelał koparkę na budowie tramwaju do Wilanowa
 - [https://tvn24.pl/tvnwarszawa/mokotow/warszawa-ostrzelana-koparka-na-budowie-tramwaju-do-wilanowa-st8148514?source=rss](https://tvn24.pl/tvnwarszawa/mokotow/warszawa-ostrzelana-koparka-na-budowie-tramwaju-do-wilanowa-st8148514?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T14:01:49+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8021437-tramwaj-pomiarowy-dojechal-do-wilanowa-ph8134665/alternates/LANDSCAPE_1280" alt="Ktoś ostrzelał koparkę na budowie tramwaju do Wilanowa" />
    W nocy z wtorku na środę nieznani sprawcy ostrzelali koparkę na budowie tramwaju do Wilanowa. Do zdarzenia doszło w rejonie pętli na Bonifacego.
    
    

## "Dzieci zaczęły skarżyć się na świąd skóry". Ewakuacja na pływalni
 - [https://tvn24.pl/poznan/wrzesnia-ewakuacja-na-plywalni-dzieci-zaczely-skarzyc-sie-na-swiad-skory-i-drapanie-w-gardle-st8148459?source=rss](https://tvn24.pl/poznan/wrzesnia-ewakuacja-na-plywalni-dzieci-zaczely-skarzyc-sie-na-swiad-skory-i-drapanie-w-gardle-st8148459?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:54:59+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9803203-shutterstock-2452915829-ph8148464/alternates/LANDSCAPE_1280" alt=""Dzieci zaczęły skarżyć się na świąd skóry". Ewakuacja na pływalni" />
    Podczas zajęć na pływalni we Wrześni pięcioro dzieci zaczęło się uskarżać na świąd skóry oraz drapanie w gardle. Straż pożarna zdecydowała o ewakuacji. Budynek sprawdza specjalistyczna grupa chemiczna z Konina. 
    
    

## Zamach w siedzibie firmy lotniczej. Są ofiary śmiertelne i ranni 
 - [https://tvn24.pl/swiat/turcja-atak-terrorystyczny-w-siedzibie-tusas-w-ankarze-st8148470?source=rss](https://tvn24.pl/swiat/turcja-atak-terrorystyczny-w-siedzibie-tusas-w-ankarze-st8148470?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:45:35+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5891660-ankara-ph8148605/alternates/LANDSCAPE_1280" alt="Zamach w siedzibie firmy lotniczej. Są ofiary śmiertelne i ranni " />
    Na terenie tureckiej firmy z branży lotniczej i obronnej TUSAS w Ankarze doszło w środę do ataku terrorystycznego. Są ofiary śmiertelne i ranni. Lokalne media podają, że w czasie wymiany ognia z napastnikami zginęło dwóch ochroniarzy. Doszło również do wybuchu.
    
    

## Kierowca ciężarówki potrącił 19-latkę, kobieta nie żyje 
 - [https://tvn24.pl/rzeszow/wola-mielecka-ciezarowka-potracila-19-latke-kobieta-nie-zyje-st8148419?source=rss](https://tvn24.pl/rzeszow/wola-mielecka-ciezarowka-potracila-19-latke-kobieta-nie-zyje-st8148419?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:25:27+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5669063-w-wypadku-zginela-19-latka-ph8148421/alternates/LANDSCAPE_1280" alt="Kierowca ciężarówki potrącił 19-latkę, kobieta nie żyje " />
    Nie udało się uratować życia 19-latki, która w Woli Mieleckiej (Podkarpacie) została potrącona przez ciężarówkę. Na miejscu trwają czynności z udziałem prokuratora. 
    
    

## Wycieńczone psy i koty na posesji w Józefowie. Wokół "mnóstwo martwych zwierząt"
 - [https://tvn24.pl/tvnwarszawa/okolice/jozefow-ponad-20-wycienczonych-psow-i-kotow-na-posesji-wokol-cale-mnostwo-zwlok-st8148140?source=rss](https://tvn24.pl/tvnwarszawa/okolice/jozefow-ponad-20-wycienczonych-psow-i-kotow-na-posesji-wokol-cale-mnostwo-zwlok-st8148140?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:25:06+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-889161-skrajnie-zaniedbane-zwierzeta-znajdowaly-sie-na-posesji-w-jozefowie-ph8148270/alternates/LANDSCAPE_1280" alt="Wycieńczone psy i koty na posesji w Józefowie. Wokół "mnóstwo martwych zwierząt"" />
    Na posesji w podwarszawskim Józefowie znajdowało się ponad 20 skrajnie wygłodzonych i zaniedbanych psów oraz kotów. Żyły pośród odchodów i martwych zwierząt. Policja zatrzymała właścicielkę posesji. Kobieta usłyszała zarzut znęcania się ze szczególnym okrucieństwem. Została objęta dozorem policyjnym. 
    
    

## Zamknięty konsulat w Poznaniu. "Nie jest wykluczone, że niszczarki pracują"
 - [https://tvn24.pl/polska/zamkniety-konsulat-w-poznaniu-nie-jest-wykluczone-ze-niszczarki-pracuja-st8148345?source=rss](https://tvn24.pl/polska/zamkniety-konsulat-w-poznaniu-nie-jest-wykluczone-ze-niszczarki-pracuja-st8148345?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:21:33+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-161840-konsulat-generalny-federacji-rosyjskiej-w-poznaniu-ph8148415/alternates/LANDSCAPE_1280" alt="Zamknięty konsulat w Poznaniu. "Nie jest wykluczone, że niszczarki pracują"" />
    Nie jest wykluczone, że w rosyjskim konsulacie w Poznaniu w tym momencie pracują niszczarki, pakowane są jakieś dokumenty, zamykane są sprawy - stwierdził w TVN24 były ambasador Polski w Kijowie Jan Piekło. Zaznaczył, że ambasador Rosji w Polsce "już dawno sobie zasłużył na to, żeby być bardziej brutalnie potraktowany, ponieważ cały czas próbuje prowokować i zachowuje się w sposób niezgodny ze standardami dyplomatycznymi".
    
    

## "Przyjął zaproszenie zbrodniarza wojennego". Kijów oburzony
 - [https://tvn24.pl/swiat/sekretarz-generalny-onz-na-szczycie-putina-ukraina-oburzona-przyjal-zaproszenie-od-zbrodniarza-wojennego-st8148377?source=rss](https://tvn24.pl/swiat/sekretarz-generalny-onz-na-szczycie-putina-ukraina-oburzona-przyjal-zaproszenie-od-zbrodniarza-wojennego-st8148377?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:09+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4225665-antonio-guterres-witany-na-szczycie-brics-kazan-ph8148412/alternates/LANDSCAPE_1280" alt=""Przyjął zaproszenie zbrodniarza wojennego". Kijów oburzony" />
    Unia Europejska w środę wezwała kraje uczestniczące w szczycie BRICS, w rosyjskim Kazaniu, by zwróciły się do prezydenta Władimira Putina o natychmiastowe zakończenie wojny w Ukrainie. W wydarzeniu uczestniczy António Guterres, sekretarz generalny ONZ, co spotkało się z ostrą krytyką ze strony Kijowa. "Odrzucił zaproszenie Ukrainy na pierwszy Globalny Szczyt Pokojowy w Szwajcarii. Przyjął jednak zaproszenie od zbrodniarza wojennego" - oświadczył minister spraw zagranicznych Ukrainy. 
    
    

## Czarny dym widoczny nad miastem z kilku kilometrów. Spłonęło 10 samochodów
 - [https://tvn24.pl/lodz/lodz-czarny-dym-widoczny-nad-miastem-z-kilku-kilometrow-splonelo-10-samochodow-st8148407?source=rss](https://tvn24.pl/lodz/lodz-czarny-dym-widoczny-nad-miastem-z-kilku-kilometrow-splonelo-10-samochodow-st8148407?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T12:53:51+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2833392-pozar-garazu-splonelo-10-samochodow-ph8148396/alternates/LANDSCAPE_1280" alt="Czarny dym widoczny nad miastem z kilku kilometrów. Spłonęło 10 samochodów" />
    10 samochodów spłonęło, kolejne dwa i traktor zostały nadpalone w pożarze garażu przy ulicy Klinowej w dzielnicy Teofilów w Łodzi. Czarny dym było widać nad miastem z kilku kilometrów. Na miejscu pracowało 14 zastępów straży pożarnej, ogień udało się ugasić.
    
    

## "Potrzeba czegoś więcej" niż pakt migracyjny. Czego? Debata w europarlamencie
 - [https://tvn24.pl/swiat/pakt-migracyjny-debata-w-europarlamencie-potrzeba-czegos-wiecej-st8148224?source=rss](https://tvn24.pl/swiat/pakt-migracyjny-debata-w-europarlamencie-potrzeba-czegos-wiecej-st8148224?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T12:44:09+00:00


    
    <img src="https://tvn24.pl/polska/cdn-zdjecie-1364682-glosowanie-w-parlamencie-europejskim-ph8148240/alternates/LANDSCAPE_1280" alt=""Potrzeba czegoś więcej" niż pakt migracyjny. Czego? Debata w europarlamencie" />
    W Parlamencie Europejskim odbyła się w środę debata w sprawie zaostrzenia unijnej polityki migracyjnej. Grupy centroprawicowe i prawicowe opowiedziały się za zaostrzeniem unijnej polityki migracyjnej, w tym polityki powrotowej. Socjaliści i demokraci, lewica i liberałowie chcą wdrożenia paktu migracyjnego, ale są przeciwni zaostrzeniom.
    
    

## Nowa Ruda prowadzi w rankingu "dni smogowych"
 - [https://tvn24.pl/krakow/nowa-ruda-prowadzi-w-rankingu-dni-smogowych-st8148254?source=rss](https://tvn24.pl/krakow/nowa-ruda-prowadzi-w-rankingu-dni-smogowych-st8148254?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T12:03:53+00:00


    
    <img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-x4zjlm-smog-7775876/alternates/LANDSCAPE_1280" alt="Nowa Ruda prowadzi w rankingu "dni smogowych"" />
    Gdzie jest najgorsze powietrze w Polsce? Według rankingu opublikowanego przez Polski Alarm Smogowy, w Nowej Rudzie na Dolnym Śląsku. Na niechlubnym podium znalazły się też dwie małopolskie miejscowości: Sucha Beskidzka i Nowy Targ. Jest również jedna gmina, która w spektakularny sposób poprawiła jakość swojego powietrza. 
    
    

## Poszukiwany rozpoznany na ulicy przez policjanta po służbie
 - [https://tvn24.pl/szczecin/szczecin-byl-poszukiwany-za-przestepstwa-narkotykowe-rozpoznano-go-na-ulicy-st8148279?source=rss](https://tvn24.pl/szczecin/szczecin-byl-poszukiwany-za-przestepstwa-narkotykowe-rozpoznano-go-na-ulicy-st8148279?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T12:00:13+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-l3vjb0-kajdanki-7274052/alternates/LANDSCAPE_1280" alt="Poszukiwany rozpoznany na ulicy przez policjanta po służbie" />
    Szczeciński policjant w czasie wolnym od służby, zauważył na ulicy mężczyznę, który od dłuższego czasu był poszukiwany. Mężczyzna miał do odbycia karę trzech miesięcy więzienia za przestępstwa narkotykowe.
    
    

## Marsz Niepodległości przejdzie ulicami Warszawy
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-marsz-niepodleglosci-przejdzie-ulicami-warszawy-st8148302?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-marsz-niepodleglosci-przejdzie-ulicami-warszawy-st8148302?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:58:27+00:00


    
    <img src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-8224970-przez-warszawe-przeszedl-marsz-niepodleglosci-ph7433112/alternates/LANDSCAPE_1280" alt="Marsz Niepodległości przejdzie ulicami Warszawy" />
    Marsz Niepodległości przejdzie ulicami Warszawy. Odbędzie się jako zgromadzenie legalne i na dotychczasowej trasie. Informację potwierdziła rzeczniczka stołeczna ratusza Monika Beuth.
    
    

## Pod prąd rowerem na ekspresówce. Bo tak poprowadziła nawigacja 
 - [https://tvn24.pl/bialystok/zambrow-pod-prad-rowerem-na-trasie-s8-bo-tak-poprowadzila-nawigacja-st8148222?source=rss](https://tvn24.pl/bialystok/zambrow-pod-prad-rowerem-na-trasie-s8-bo-tak-poprowadzila-nawigacja-st8148222?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:49:14+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8850399-37-latek-jechal-rowerem-pod-prad-na-drodze-ekspresowej-ph8148221/alternates/LANDSCAPE_1280" alt="Pod prąd rowerem na ekspresówce. Bo tak poprowadziła nawigacja " />
    37-latek jechał rowerem drogą ekspresową S8 na Podlasiu bo - jak tłumaczył policjantom - tak go prowadziła nawigacja. "Wybierając tę trasę kierujący rowerem ryzykował własnym życiem" - skwitowali mundurowi. 
    
    

## W pożarze zginęło dwóch mężczyzn, a dwie osoby, w tym strażak, zostały ranne
 - [https://tvn24.pl/tvnwarszawa/okolice/strupczewo-duze-pozar-budynku-socjalnego-zginelo-dwoch-mezczyzn-st8148239?source=rss](https://tvn24.pl/tvnwarszawa/okolice/strupczewo-duze-pozar-budynku-socjalnego-zginelo-dwoch-mezczyzn-st8148239?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:46:44+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-582104-pozar-budynku-socjalnego-w-miejscowosci-strupczewo-duze-ph8148249/alternates/LANDSCAPE_1280" alt="W pożarze zginęło dwóch mężczyzn, a dwie osoby, w tym strażak, zostały ranne" />
    Dwie osoby nie żyją, a kolejne dwie, w tym strażak, są ranne - to tragiczny bilans nocnego pożaru w miejscowości Strupczewo Duże pod Płockiem. Z budynku ewakuowano około 30 osób. 
    
    

## Bobry podgryzły wierzbę. "Zagrożenie niekontrolowanego upadku" 
 - [https://tvn24.pl/krakow/bobry-podgryzly-wierzbe-zagrozenie-niekontrolowanego-upadku-st8148083?source=rss](https://tvn24.pl/krakow/bobry-podgryzly-wierzbe-zagrozenie-niekontrolowanego-upadku-st8148083?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:13:43+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4521000-drzewo-ph8148107/alternates/LANDSCAPE_1280" alt="Bobry podgryzły wierzbę. "Zagrożenie niekontrolowanego upadku" " />
    Strażacy z Żegiestowa (woj. małopolskie) musieli interweniować przy tamtejszej drodze wojewódzkiej. Powodem było uszkodzone drzewo. Pień 28-metrowej wierzby podgryzły bobry. Działania strażaków trwały sześć godzin.
    
    

## Ukrywał się, często zmieniał kryjówki. "Łowcy głów" zatrzymali szpiega 
 - [https://tvn24.pl/lublin/lublin-policja-zatrzymala-poszukiwanego-listem-gonczym-i-skazanego-za-szpiegostwo-st8147941?source=rss](https://tvn24.pl/lublin/lublin-policja-zatrzymala-poszukiwanego-listem-gonczym-i-skazanego-za-szpiegostwo-st8147941?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:07:11+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-769338-mezczyzna-byl-poszukiwany-za-szpiegostwo-ph8147993/alternates/LANDSCAPE_1280" alt="Ukrywał się, często zmieniał kryjówki. "Łowcy głów" zatrzymali szpiega " />
    Lubelscy "łowcy głów" zatrzymali poszukiwanego listem gończym 45-letniego obywatela Ukrainy Yaroslava B. Mężczyzna został skazany za szpiegostwo. Ukrywał się w Łodzi. Trafił już do zakładu karnego, gdzie odbędzie zasądzoną karę.
    
    

## Nagrał, jak kierowca jedzie "na czołówkę". Film wysłał policji
 - [https://tvn24.pl/olsztyn/olsztyn-droga-krajowa-nr-53-nagral-jak-kierowca-jedzie-na-czolowke-film-wyslal-policji-st8147870?source=rss](https://tvn24.pl/olsztyn/olsztyn-droga-krajowa-nr-53-nagral-jak-kierowca-jedzie-na-czolowke-film-wyslal-policji-st8147870?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:04:03+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3776730-niebezpieczne-wyprzedzanie-w-oku-kamery-ph8147942/alternates/LANDSCAPE_1280" alt="Nagrał, jak kierowca jedzie "na czołówkę". Film wysłał policji" />
    Na podwójnej ciągłej, wprost na inny samochód. Niebezpieczne wyprzedzanie zarejestrowała kamera w drugim aucie. Kierowca film przesłał policji. Właściciel został już ukarany. 
    
    

## Lichocka: "właściciel polskiej marki ogłosił zwolnienia". Czego posłanka nie napisała?
 - [https://konkret24.tvn24.pl/polityka/joanna-lichocka-wlasciciel-polskiej-marki-sokolow-oglosil-zwolnienia-czego-poslanka-nie-napisala-st8146942?source=rss](https://konkret24.tvn24.pl/polityka/joanna-lichocka-wlasciciel-polskiej-marki-sokolow-oglosil-zwolnienia-czego-poslanka-nie-napisala-st8146942?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T11:01:25+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3088224-lichocka-wlasciciel-polskiej-marki-sokolow-oglosil-zwolnienia-500-pracownikow-poslanka-pis-wprowadza-w-blad-ph8146832/alternates/LANDSCAPE_1280" alt="Lichocka: "właściciel polskiej marki ogłosił zwolnienia". Czego posłanka nie napisała?" />
    Posłanka PiS Joanna Lichocka poinformowała na Facebooku, że "właściciel polskiej marki Sokołów ogłosił zwolnienia 500 pracowników". Wpis wywołał falę krytyki - wielu komentujących uznało, że redukcje dotyczą Polaków i obwiniło za tę sytuację polski rząd. Tylko że posłanka PiS swoim enigmatycznym postem wprowadza opinię publiczną w błąd.
    
    

## W tym roku zabiła 13 osób. Po przejściu huraganów przybyło zakażeń mięsożerną bakterią
 - [https://tvn24.pl/tvnmeteo/swiat/w-tym-roku-zabila-13-osob-po-przejsciu-huraganow-przybylo-zakazen-miesozerna-bakteria-st8147724?source=rss](https://tvn24.pl/tvnmeteo/swiat/w-tym-roku-zabila-13-osob-po-przejsciu-huraganow-przybylo-zakazen-miesozerna-bakteria-st8147724?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:53:42+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5223060-bakteria-vibrio-vulnificus-ph8147781/alternates/LANDSCAPE_1280" alt="W tym roku zabiła 13 osób. Po przejściu huraganów przybyło zakażeń mięsożerną bakterią" />
    Po przejściu dwóch huraganów w krótkim odstępie czasu na Florydzie odnotowano duży wzrost liczby zakażeń bakterią Vibrio vulnificus, nazywaną mięsożerną. W tym roku w całym stanie za jej sprawą zmarło 13 osób - poinformował tamtejszy departament zdrowia.
    
    

## 60-letni kolejarz musi wytrzymać zimę. Renowacja pomnika dopiero wiosną
 - [https://tvn24.pl/szczecin/szczecin-60-letni-pomnik-kolejarza-odzyska-dawny-blask-st8147597?source=rss](https://tvn24.pl/szczecin/szczecin-60-letni-pomnik-kolejarza-odzyska-dawny-blask-st8147597?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:52:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4568622-pomnik-kolejarza-w-szczecinie-ph8147630/alternates/LANDSCAPE_1280" alt="60-letni kolejarz musi wytrzymać zimę. Renowacja pomnika dopiero wiosną" />
    60-letnia rzeźba kolejarza, stojąca przed budynkiem Dworca Głównego w Szczecinie, doczeka się renowacji. Łukasz Kadłubowski, zastępca prezydenta miasta, zapewnił, że planowane jest zabezpieczenie środków na ten cel w przyszłorocznym budżecie. Koszt napraw ma wynieść od 80 do 100 tysięcy złotych. 
    
    

## Kilkadziesiąt osób z objawami zatrucia. Wszyscy mówią o zapiekance
 - [https://tvn24.pl/szczecin/mierzyn-trzydziesci-osob-z-objawami-zatrucia-pokarmowego-osiem-w-szpitalu-st8147918?source=rss](https://tvn24.pl/szczecin/mierzyn-trzydziesci-osob-z-objawami-zatrucia-pokarmowego-osiem-w-szpitalu-st8147918?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:48:01+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1168456-karetka-pogotowia-zdjecie-ilustracyjne-ph8028302/alternates/LANDSCAPE_1280" alt="Kilkadziesiąt osób z objawami zatrucia. Wszyscy mówią o zapiekance" />
    W jednej z firm działających pod Szczecinem doszło do zatrucia pokarmowego kilkudziesięciu pracowników. Wszystkie osoby z podobnymi objawami przekazały, że jadły zapiekankę makaronową z kurczakiem. Sprawą zajmuje się Powiatowa Stacja Sanitarno-Epidemiologiczna w Policach.
    
    

## Z masztu na rondzie "Radosława" zniknęła flaga
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-z-masztu-na-rondzie-radoslawa-zniknela-flaga-st8148094?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-z-masztu-na-rondzie-radoslawa-zniknela-flaga-st8148094?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:41:42+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6586649-zmiany-na-rondzie-radoslawa-ph7294975/alternates/LANDSCAPE_1280" alt="Z masztu na rondzie "Radosława" zniknęła flaga" />
    Największa w kraju biało-czerwona flaga zniknęła z 60-metrowego Masztu Wolności na rondzie "Radosława". Zarząd Terenów Publicznych poinformował o remoncie masztu.
    
    

## Prezydent w Korei Południowej. Rozmowy z "najbliższym sojusznikiem" o zbrojeniówce
 - [https://tvn24.pl/swiat/prezydent-andrzej-duda-w-korei-poludniowej-rozmowy-z-najblizszym-sojusznikiem-o-zbrojeniowce-st8147988?source=rss](https://tvn24.pl/swiat/prezydent-andrzej-duda-w-korei-poludniowej-rozmowy-z-najblizszym-sojusznikiem-o-zbrojeniowce-st8147988?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:39:43+00:00


    
    <img src="https://tvn24.pl/polska/cdn-zdjecie-3731516-andrzej-duda-w-korei-poludniowej-ph8147983/alternates/LANDSCAPE_1280" alt="Prezydent w Korei Południowej. Rozmowy z "najbliższym sojusznikiem" o zbrojeniówce" />
    - To bardzo ważna wizyta w bardzo ważnych czasach. Korea Południowa to nasz najbliższy sojusznik w tej części świata - powiedział prezydent Andrzej Duda, który przebywa z wizytą w Seulu. Spotkał się z przewodniczącym parlamentu, zaplanowano też rozmowy z prezydentem i premierem.
    
    

## Zaginął 84-letni mężczyzna. Gdy do niego dotarli, leżał na skraju bagna
 - [https://tvn24.pl/tvnwarszawa/bialoleka/warszawa-senior-zgubil-sie-na-bagnach-w-jego-odnalezieniu-pomogl-zegarek-z-gps-st8147905?source=rss](https://tvn24.pl/tvnwarszawa/bialoleka/warszawa-senior-zgubil-sie-na-bagnach-w-jego-odnalezieniu-pomogl-zegarek-z-gps-st8147905?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:02+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1523147-policjanci-ktorzy-odnalezli-seniora-ml-asp-radoslaw-trybus-i-st-post-arkadiusz-zaleski-ph8147987/alternates/LANDSCAPE_1280" alt="Zaginął 84-letni mężczyzna. Gdy do niego dotarli, leżał na skraju bagna" />
    Policjanci z Białołęki szukali starszego mężczyzny, cierpiącego na zaburzenia pamięci. W jego odnalezieniu pomógł zegarek z nadajnikiem GPS. 84-latek znajdował się na zalesionym i błotnistym terenie. Był wychłodzony.
    
    

## Motocyklista omal nie potrącił dziecka, po czym uciekł. Straci prawo jazdy 
 - [https://tvn24.pl/poznan/poznan-motocyklista-omal-nie-potracil-dziecka-po-czym-uciekl-jaka-poniesie-kare-st8147919?source=rss](https://tvn24.pl/poznan/poznan-motocyklista-omal-nie-potracil-dziecka-po-czym-uciekl-jaka-poniesie-kare-st8147919?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T10:02:24+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2601813-motocyklista-omal-nie-wjechal-w-chlopca-ph8099061/alternates/LANDSCAPE_1280" alt="Motocyklista omal nie potrącił dziecka, po czym uciekł. Straci prawo jazdy " />
    Uciekł, ale nie uniknie konsekwencji. Poznańscy policjanci ustalili dane motocyklisty, który wyprzedzając inne pojazdy na przejściu dla pieszych omal nie wjechał w chłopca na hulajnodze. Podczas tego manewru mężczyzna zahaczył również o wyprzedzane auto. Motocyklistę ukarano mandatem i punktami karnymi. Uzbierał ich tak dużo, że straci prawo jazdy. 
    
    

## W ogromnej hali namiotowej 160 rowerów elektrycznych wartych 3 miliony. Zatrzymany 23-latek
 - [https://tvn24.pl/wroclaw/wroclaw-w-ogromnej-hali-namiotowej-160-rowerow-elektrycznych-wartych-3-miliony-zatrzymany-23-latek-st8147915?source=rss](https://tvn24.pl/wroclaw/wroclaw-w-ogromnej-hali-namiotowej-160-rowerow-elektrycznych-wartych-3-miliony-zatrzymany-23-latek-st8147915?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:57:06+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6242026-rowery-elektryczne-warte-trzy-miliony-zlotych-byly-przechowywane-w-hali-namiotowej-ph8147873/alternates/LANDSCAPE_1280" alt="W ogromnej hali namiotowej 160 rowerów elektrycznych wartych 3 miliony. Zatrzymany 23-latek" />
    Policjanci z Wrocławia odzyskali 160 skradzionych rowerów elektrycznych o łącznej wartości trzech milionów złotych. Jednoślady różnych typów były przechowywane w hali namiotowej. W sprawie zatrzymany został 23-latek, członek grupy przestępczej, która trudniła się kradzieżą rowerów elektrycznych z terenu Unii Europejskiej. 
    
    

## Tych przyborów kuchennych lepiej nie używać. Jest ostrzeżenie
 - [https://tvn24.pl/biznes/z-kraju/gis-ostrzezenie-w-sprawie-serii-przyborow-kuchennych-st8147874?source=rss](https://tvn24.pl/biznes/z-kraju/gis-ostrzezenie-w-sprawie-serii-przyborow-kuchennych-st8147874?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:51:45+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6324487-shutterstock-2466329717-ph8147912/alternates/LANDSCAPE_1280" alt="Tych przyborów kuchennych lepiej nie używać. Jest ostrzeżenie" />
    Główny Inspektorat Sanitarny wydał ostrzeżenie dotyczące kompletu przyborów kuchennych Ofenbach - nie należy używać ich do kontaktu z żywnością. W badaniach stwierdzono migrację do żywności pierwszorzędowych amin aromatycznych z tych akcesoriów.
    
    

## Zwierzę jak z baśni na nagraniu Reportera24
 - [https://tvn24.pl/tvnmeteo/ciekawostki/zwierze-jak-z-basni-na-nagraniu-reportera24-st8147846?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/zwierze-jak-z-basni-na-nagraniu-reportera24-st8147846?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:49:15+00:00


    
    <img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-1163997-a7f50f7b-a535-42ad-ad9f-41c5a64700f6-bialyjelen-daniel-0001-ph8147916/alternates/LANDSCAPE_1280" alt="Zwierzę jak z baśni na nagraniu Reportera24" />
    W czasie spaceru przez las pan Grzegorz ze Skaryszew (województwo pomorskie) zauważył białego daniela. Rzadkie zwierzę, hasające między drzewami, widać na nagraniu, które mężczyzna przesłał na Kontakt24. 
    
    

## Z nagrobków znikały uchwyty. Trzy osoby zatrzymane
 - [https://tvn24.pl/krakow/z-nagrobkow-znikaly-uchwyty-trzy-osoby-zatrzymane-st8147695?source=rss](https://tvn24.pl/krakow/z-nagrobkow-znikaly-uchwyty-trzy-osoby-zatrzymane-st8147695?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:39:38+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3331126-z-nagrobkow-skradziono-mosiezne-uchwyty-ph8147693/alternates/LANDSCAPE_1280" alt="Z nagrobków znikały uchwyty. Trzy osoby zatrzymane" />
    Trójka mieszkańców Sądecczyzny odpowie za ograbienie miejsc pochówku na lokalnych cmentarzach. Z nagrobków mieli zabierać uchwyty i inne mosiężne elementy. Grozi im długa odsiadka. 
    
    

## "W żartach poprosił, by go zastrzeliła". 58-letni mężczyzna nie żyje 
 - [https://tvn24.pl/swiat/usa-w-zartach-poprosil-by-go-zastrzelila-58-letni-mezczyzna-nie-zyje-st8147817?source=rss](https://tvn24.pl/swiat/usa-w-zartach-poprosil-by-go-zastrzelila-58-letni-mezczyzna-nie-zyje-st8147817?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:39:25+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4fz9e0-usa-policja-swiatla-policyjne-7870481/alternates/LANDSCAPE_1280" alt=""W żartach poprosił, by go zastrzeliła". 58-letni mężczyzna nie żyje " />
    Kathleen Geiger, 77-letnia mieszkanka Cincinnati w stanie Ohio, została oskarżona o nieumyślne spowodowanie śmierci. Podczas rozmowy ze znajomym kobieta miała zostać żartobliwie poproszona o zastrzelenie swojego rozmówcy. Sądząc, że jej broń nie jest naładowana, Amerykanka wymierzyła pistolet w stronę przyjaciela i pociągnęła za spust. Mężczyzna zmarł w wyniku odniesionych obrażeń.  
    
    

## Szczątki dwóch osób przy budowanej trasie S7
 - [https://tvn24.pl/tvnwarszawa/okolice/niepiekla-kolo-plonska-szczatki-dwoch-osob-przy-budowanej-trasie-s7-st8147702?source=rss](https://tvn24.pl/tvnwarszawa/okolice/niepiekla-kolo-plonska-szczatki-dwoch-osob-przy-budowanej-trasie-s7-st8147702?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:36:22+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5635584-szczatki-ludzkie-znalezione-przy-trasie-s7-ph8147611/alternates/LANDSCAPE_1280" alt="Szczątki dwóch osób przy budowanej trasie S7" />
    W wykopie przy trasie S7 w okolicach Niepiekła, niedaleko Płońska (Mazowieckie) znaleziono ludzkie szczątki. Na miejscu pracowali policjanci pod nadzorem prokuratury. 
    
    

## "Są trzy opcje". Co żołnierze Kima mogą robić na ukraińskim froncie 
 - [https://tvn24.pl/swiat/korea-polnocna-wysyla-zolnierzy-na-ukraine-gdzie-beda-walczyli-jakie-beda-mieli-zadania-ekspert-o-scenariuszach-st8147770?source=rss](https://tvn24.pl/swiat/korea-polnocna-wysyla-zolnierzy-na-ukraine-gdzie-beda-walczyli-jakie-beda-mieli-zadania-ekspert-o-scenariuszach-st8147770?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:35:04+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9184765-polnocnokoreanscy-zolnierze-podczas-cwiczen-ph8140336/alternates/LANDSCAPE_1280" alt=""Są trzy opcje". Co żołnierze Kima mogą robić na ukraińskim froncie " />
    Przydatność żołnierzy z Korei Północnej dla Rosji zależy w dużej mierze od tego, do jakich zadań zostaliby oddelegowani - tłumaczy dr Oskar Pietrewicz z Polskiego Instytutu Spraw Międzynarodowych. Żołnierze północnokoreańscy nie brali udziału w działaniach zbrojnych od 1953 roku, a więc aktywnej fazy wojny koreańskiej. Ich wysłanie na front w Ukrainie mogłoby posłużyć za poligon doświadczalny - dodaje. Wywiad Korei Południowej wskazuje, że wśród żołnierzy wysłanych do Europy mogą się znaleźć najlepiej wyszkolone siły specjalne.
    
    

## "Nie możemy się pogodzić z tak nagłym odejściem tych wspaniałych dzieci". Eliza i Tomek zginęli na S7
 - [https://tvn24.pl/trojmiasto/nowa-wies-malborska-uczniowie-i-pracownicy-szkoly-zegnaja-elize-i-tomka-ktorzy-zgineli-na-s7-st8147671?source=rss](https://tvn24.pl/trojmiasto/nowa-wies-malborska-uczniowie-i-pracownicy-szkoly-zegnaja-elize-i-tomka-ktorzy-zgineli-na-s7-st8147671?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:32:31+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1643440-szkola-zegna-rodzenstwo-ktore-zginelo-na-s7-ph8147694/alternates/LANDSCAPE_1280" alt=""Nie możemy się pogodzić z tak nagłym odejściem tych wspaniałych dzieci". Eliza i Tomek zginęli na S7" />
    Uczniowie i pracownicy Szkoły Podstawowej w Nowej Wsi Malborskiej żegnają rodzeństwo, które zginęło w karambolu na S7 koło Gdańska. - "Z ogromnym smutkiem przyjęliśmy wiadomość o tragicznej śmierci Elizy i Tomka. Wciąż nie możemy się pogodzić z tak nagłym odejściem tych wspaniałych dzieci" - napisali. W wypadku zginęli też 7-letni Nikodem i 10-letni Mikołaj.
    
    

## Prawie 15 kilogramów narkotyków i pięcioro podejrzanych o ich rozprowadzanie
 - [https://tvn24.pl/krakow/prawie-15-kilogramow-narkotykow-i-piecioro-podejrzanych-o-ich-rozprowadzanie-st8147811?source=rss](https://tvn24.pl/krakow/prawie-15-kilogramow-narkotykow-i-piecioro-podejrzanych-o-ich-rozprowadzanie-st8147811?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:28:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8981782-policja-rozbila-narkotykowy-gang-ph8147815/alternates/LANDSCAPE_1280" alt="Prawie 15 kilogramów narkotyków i pięcioro podejrzanych o ich rozprowadzanie" />
    Krakowscy policjanci rozbili grupę przestępczą zajmującą się handlem narkotykami w ilościach hurtowych. Do pierwszych zatrzymań w tej sprawie doszło na początku października, teraz do cel trafiły kolejne osoby. Podejrzani mieli też zajmować się oszustwami na seniorach.
    
    

## Niechlubni rekordziści. Jeżdżą za szybko, bez pasów, po alkoholu i bez uprawnień 
 - [https://tvn24.pl/rzeszow/glojsce-trzykrotnie-przekroczyl-dozwolona-predkosc-st8147716?source=rss](https://tvn24.pl/rzeszow/glojsce-trzykrotnie-przekroczyl-dozwolona-predkosc-st8147716?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:26:54+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1358211-19-letni-pirat-drogowy-gnal-156-km-h-w-terenie-zabudowanym-ph8147706/alternates/LANDSCAPE_1280" alt="Niechlubni rekordziści. Jeżdżą za szybko, bez pasów, po alkoholu i bez uprawnień " />
    19-latek pędził w obszarze zabudowanym z prędkością 156 kilometrów na godzinę, czyli o 106 km/h za szybko. Okazało się, że to recydywista. Młody kierowca dostał pięć tysięcy mandatu i 15 punktów karnych. Mimo apeli policji kierowcy wciąż jeżdżą za szybko, wsiadają za kółko bez uprawnień lub po alkoholu. 
    
    

## "Niet" dla wódki, odcięty internet, dzieci w domach. Kazań w rękach Putina i jego gości
 - [https://tvn24.pl/swiat/rosja-kazan-szczyt-panstw-brics-media-o-zamknietym-miescie-st8147661?source=rss](https://tvn24.pl/swiat/rosja-kazan-szczyt-panstw-brics-media-o-zamknietym-miescie-st8147661?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:04:23+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2212855-kazan-szczyt-ph8147697/alternates/LANDSCAPE_1280" alt=""Niet" dla wódki, odcięty internet, dzieci w domach. Kazań w rękach Putina i jego gości" />
    W czasie szczytu państw grupy BRICS w centrum Kazania odwołano kursowanie minibusów, uczniów wysłano do domu, a w sklepach obowiązywał zakaz sprzedaży alkoholu - opisuje sytuację w mieście, gdzie prezydent Władimir Putin zwołał spotkanie potencjalnych sojuszników, rosyjska sekcja Radia Swoboda. 
    
    

## Na stacji metra zaatakowali starszego mężczyznę. Szuka ich policja
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/na-stacji-metra-zaatakowali-starszego-mezczyzne-szuka-ich-policja-st8147806?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/na-stacji-metra-zaatakowali-starszego-mezczyzne-szuka-ich-policja-st8147806?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:01:17+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5950031-w-sprawie-pobicia-starszego-mezczyzny-ph8147776/alternates/LANDSCAPE_1280" alt="Na stacji metra zaatakowali starszego mężczyznę. Szuka ich policja" />
    Dwóch młodych mężczyzn w wieku około 20 lat na stacji metra zaatakowało 72-latka. Doznał on poważnych obrażeń głowy, napastników szukają policjanci.
    
    

## Tyle wyniosła stopa bezrobocia we wrześniu
 - [https://tvn24.pl/biznes/z-kraju/bezrobocie-w-polsce-dane-gus-za-wrzesien-2024-st8147707?source=rss](https://tvn24.pl/biznes/z-kraju/bezrobocie-w-polsce-dane-gus-za-wrzesien-2024-st8147707?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:07+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8410702-pracownik-robotnik-praca-zmeczenie-zmeczony-shutterstock1887454645-ph8054353/alternates/LANDSCAPE_1280" alt="Tyle wyniosła stopa bezrobocia we wrześniu" />
    Stopa bezrobocia we wrześniu 2024 roku wyniosła 5,0 procent, tak jak miesiąc wcześniej - podał Główny Urząd Statystyczny.
    
    

## Pozew przeciwko Romanowi Polańskiemu "formalnie oddalony". Ugoda ku "obopólnemu zadowoleniu"
 - [https://tvn24.pl/swiat/roman-polanski-ugoda-w-procesie-obopolne-zadowolenie-stron-st8147682?source=rss](https://tvn24.pl/swiat/roman-polanski-ugoda-w-procesie-obopolne-zadowolenie-stron-st8147682?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:57:02+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-o7sy12-roman-polanski-czeka-na-premiere-swojego-najnowszego-filmu-6919343/alternates/LANDSCAPE_1280" alt="Pozew przeciwko Romanowi Polańskiemu "formalnie oddalony". Ugoda ku "obopólnemu zadowoleniu"" />
    Pozew przeciwko Romanowi Polańskiemu w sprawie rzekomej napaści seksualnej na 16-latkę w 1973 roku został oddalony. Pierwotnie powódka, której nazwiska nie podano do publicznej wiadomości, domagała się od reżysera odszkodowania w niesprecyzowanej kwocie. Finalnie w sprawie zawarto ugodę. Takie rozstrzygnięcie miało spotkać się z "zadowoleniem" obu stron.  
    
    

## To stworzenie ma zadziwiającą tolerancję na alkohol
 - [https://tvn24.pl/tvnmeteo/nauka/to-stworzenie-ma-zadziwiajaca-tolerancje-na-alkohol-st8147512?source=rss](https://tvn24.pl/tvnmeteo/nauka/to-stworzenie-ma-zadziwiajaca-tolerancje-na-alkohol-st8147512?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:39:55+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2423010-szerszen-wschodni-ph8147535/alternates/LANDSCAPE_1280" alt="To stworzenie ma zadziwiającą tolerancję na alkohol" />
    Szerszeń wschodni jest owadem z taką tolerancją na alkohol, jakiej jeszcze nie widziano - wynika z najnowszych badań. Duże ilości etanolu nie powodują u niego chorób ani śmierci. 
    
    

## Bliźnięta w szpitalu po zatruciu oparami środka do zwalczania gryzoni. Stan dzieci jest ciężki 
 - [https://tvn24.pl/tvnwarszawa/okolice/plonsk-bliznieta-w-ciezkim-stanie-po-zatruciu-oparami-srodka-do-zwalczania-gryzoni-st8147692?source=rss](https://tvn24.pl/tvnwarszawa/okolice/plonsk-bliznieta-w-ciezkim-stanie-po-zatruciu-oparami-srodka-do-zwalczania-gryzoni-st8147692?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:39:36+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-wnuxoa-pacjentka-zle-sie-poczula-i-wezwala-pomoc-zdjecie-ilustracyjne-7863456/alternates/LANDSCAPE_1280" alt="Bliźnięta w szpitalu po zatruciu oparami środka do zwalczania gryzoni. Stan dzieci jest ciężki " />
    Dwoje dzieci z jednego z gospodarstw pod Płońskiem (Mazowieckie) z objawami silnego zatrucia, prawdopodobnie silnie toksycznym środkiem do zwalczania gryzoni, przebywa w szpitalu w Warszawie. Po przyjęciu wymagały reanimacji i i podłączenia do aparatury podtrzymującej życie. Ich stan jest ciężki. Prokuratura Rejonowa w Płońsku wszczęła dochodzenie. 
    
    

## Dolar przekroczył psychologiczną granicę, funt najdroższy od roku
 - [https://tvn24.pl/biznes/rynki/kursy-walut-ile-kosztuje-dolar-euro-frank-funt-st8147626?source=rss](https://tvn24.pl/biznes/rynki/kursy-walut-ile-kosztuje-dolar-euro-frank-funt-st8147626?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:34:28+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-jaeqm7-dolar-zloty-shutterstock_346360979-6208364/alternates/LANDSCAPE_1280" alt="Dolar przekroczył psychologiczną granicę, funt najdroższy od roku" />
    Złoty pozostaje pod presją umacniającego się amerykańskiego dolara - wskazują w porannych raportach ekonomiści. - Scenariusz rynkowych zmian wciąż zakłada stopniowe umacnianie się dolara związane z możliwymi konsekwencjami zwycięstwa Donalda Trumpa w wyborach prezydenckich w USA - ocenił Mateusz Sutowicz z Banku Millennium. Złoty osłabia się wobec wszystkich głównych walut.
    
    

## Dziewięciu lokalnych liderów tak zwanego Państwa Islamskiego zabitych
 - [https://tvn24.pl/swiat/irak-poinformowal-o-zabiciu-lokalnego-przywodcy-tak-zwanego-panstwa-islamskiego-i-osmiu-innych-lokalnych-liderow-organizacji-st8147411?source=rss](https://tvn24.pl/swiat/irak-poinformowal-o-zabiciu-lokalnego-przywodcy-tak-zwanego-panstwa-islamskiego-i-osmiu-innych-lokalnych-liderow-organizacji-st8147411?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:33:22+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1114483-irak-bagdad-ph7287052/alternates/LANDSCAPE_1280" alt="Dziewięciu lokalnych liderów tak zwanego Państwa Islamskiego zabitych" />
    Irackie siły bezpieczeństwa poinformowały, że podczas operacji przeprowadzonej w północnej części kraju, zabiły dziewięciu liderów tak zwanego Państwa Islamskiego (IS) w Iraku, w tym lokalnego przywódcy tej terrorystycznej organizacji.
    
    

## "Pingwin" z rekordową oglądalnością. Tylu widzów obejrzało najnowszy odcinek
 - [https://tvn24.pl/kultura-i-styl/pingwin-na-platformie-max-rekordowa-ogladalnosc-piatego-odcinka-st8147537?source=rss](https://tvn24.pl/kultura-i-styl/pingwin-na-platformie-max-rekordowa-ogladalnosc-piatego-odcinka-st8147537?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:33:21+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7320882-colin-farrell-w-serialu-pingwin-ph8099059/alternates/LANDSCAPE_1280" alt=""Pingwin" z rekordową oglądalnością. Tylu widzów obejrzało najnowszy odcinek" />
    Serial "Pingwin" odnotował rekordowy wynik oglądalności w ciągu jednego dnia od premiery. Piąty odcinek produkcji obejrzało 1,8 miliona widzów w USA. Z kolei pierwszy odcinek został obejrzany już ponad 14 milionów razy. 
    
    

## Jakimowicz pojechał na Białoruś. Były propagandysta TVP "pożytecznym idiotą" Łukaszenki
 - [https://tvn24.pl/polska/jaroslaw-jakimowicz-pojechal-na-bialorus-st8147556?source=rss](https://tvn24.pl/polska/jaroslaw-jakimowicz-pojechal-na-bialorus-st8147556?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:29:38+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-721557-jakimowicz-sklej-ph8147655/alternates/LANDSCAPE_1280" alt="Jakimowicz pojechał na Białoruś. Były propagandysta TVP "pożytecznym idiotą" Łukaszenki" />
    Jarosław Jakimowicz, były pracownik propagandowej TVP w czasach rządów PiS, wyjechał na Białoruś. W mediach społecznościowych publikuje nagrania i zdjęcia, zachwala życie w białoruskich miastach, architekturę i infrastrukturę. - Trudno uwierzyć, że niektórzy w działania wrogich służb wpisują się dobrowolnie - skomentował rzecznik ministra-koordynatora służb specjalnych Jacek Dobrzyński.
    
    

## Ciężarówka miażdży samochód osobowy. Nagranie z drogi S5
 - [https://tvn24.pl/poznan/bylin-droga-ekspresowa-s5-ciezarowka-miazdzy-samochod-osobowy-nagranie-st8147680?source=rss](https://tvn24.pl/poznan/bylin-droga-ekspresowa-s5-ciezarowka-miazdzy-samochod-osobowy-nagranie-st8147680?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T08:24:35+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2292468-nagranie-z-momentu-wypadku-na-drodze-ekspresowej-s5-ph8147670/alternates/LANDSCAPE_1280" alt="Ciężarówka miażdży samochód osobowy. Nagranie z drogi S5" />
    22-latek zginął w tragicznym wypadku na drodze ekspresowej S5 pod Poznaniem. Jego samochód dosłownie zmiażdżyła ciężarówka. Portal epoznań.pl opublikował nagranie z kamerki samochodowej jednego z kierowców, na którym widać moment tego tragicznego w skutkach zdarzenia.
    
    

## Sztab Trump oskarżył rządzących Wielką Brytanią o ingerencję w wybory. Starmer odpowiedział
 - [https://tvn24.pl/wybory-prezydenckie-2024-w-usa/wybory-prezydenckie-usa-2024-sztab-donalda-trump-oskarzyl-brytyjska-partie-pracy-o-ingerencje-w-wybory-st8147620?source=rss](https://tvn24.pl/wybory-prezydenckie-2024-w-usa/wybory-prezydenckie-usa-2024-sztab-donalda-trump-oskarzyl-brytyjska-partie-pracy-o-ingerencje-w-wybory-st8147620?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:58:16+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8539596-wiec-wyborczy-donalda-trumpa-w-greensboro-w-karolinie-polnocnej-ph8147618/alternates/LANDSCAPE_1280" alt="Sztab Trump oskarżył rządzących Wielką Brytanią o ingerencję w wybory. Starmer odpowiedział" />
    Sztab Donalda Trumpa zarzucił brytyjskiej Partii Pracy "rażącą ingerencję" w wybory prezydenckie w USA po tym, jak jej wolontariusze udali się do Stanów Zjednoczonych, aby wesprzeć kampanię Kamali Harris. Do sprawy odniósł się premier Wielkiej Brytanii. 
    
    

## Zmiany w sondażu zaufania do polityków. Powrót Radosława Sikorskiego
 - [https://tvn24.pl/polska/ranking-zaufania-do-politykow-pazdziernik-2024-komu-ufaja-polacy-powrot-radoslawa-sikorskiego-sondaz-st8147550?source=rss](https://tvn24.pl/polska/ranking-zaufania-do-politykow-pazdziernik-2024-komu-ufaja-polacy-powrot-radoslawa-sikorskiego-sondaz-st8147550?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:54:29+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8942151-tusk-duda-sikorski-trzaskowski-ph8147563/alternates/LANDSCAPE_1280" alt="Zmiany w sondażu zaufania do polityków. Powrót Radosława Sikorskiego" />
    Premier Donald Tusk nadal jest liderem zaufania wśród Polaków, ale jego przewaga nad drugim w rankingu Rafałem Trzaskowskim topnieje - wynika z sondażu IBRiS dla Onetu. W przypadku prezydenta Warszawy znacznie wzrosła jednak liczba osób, które mu nie ufają. Do zestawienia wrócił Radosław Sikorski, zajmując wysokie miejsce. 
    
    

## Podejrzany o dwa zabójstwa uciekł ze szpitala, bo pilnujący go funkcjonariusze spali 
 - [https://tvn24.pl/lublin/radecznica-podejrzany-o-dwa-zabojstwa-uciekl-bo-pilnujacy-go-funkcjonariusze-spali-st8147628?source=rss](https://tvn24.pl/lublin/radecznica-podejrzany-o-dwa-zabojstwa-uciekl-bo-pilnujacy-go-funkcjonariusze-spali-st8147628?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:51:32+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6982055-bartlomiej-b-ph8129124/alternates/LANDSCAPE_1280" alt="Podejrzany o dwa zabójstwa uciekł ze szpitala, bo pilnujący go funkcjonariusze spali " />
    Bartłomiej B., który przyznał się do zabicia ojca i brata, uciekł ze szpitala w Radecznicy (Lubelskie), bo pilnujący go funkcjonariusze Służby Więziennej spali - wynika z ustaleń śledczych. Dowodem jest szpitalny monitoring. Groźny przestępca przez kilka dni po ucieczce przebywał na wolności.
    
    

## Na Spartańską wracają samochody i autobusy
 - [https://tvn24.pl/tvnwarszawa/mokotow/mokotow-na-spartanska-wracaja-samochody-i-autobusy-st8147664?source=rss](https://tvn24.pl/tvnwarszawa/mokotow/mokotow-na-spartanska-wracaja-samochody-i-autobusy-st8147664?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:48:53+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1110438-na-spartanska-wracaja-samochody-i-autobusy-ph8147658/alternates/LANDSCAPE_1280" alt="Na Spartańską wracają samochody i autobusy" />
    Ulica Spartańska została przebudowana. Dla kierowców samochodów otwarta będzie od czwartku, 24 października, a dla autobusów od soboty, 26 października. Mieszkańcy zyskali między innymi zieleń, ścieżkę rowerową i nowe miejsca parkingowe.
    
    

## Dariusz Kmiecik zginął razem z żoną i synkiem. Mija 10 lat od ich śmierci 
 - [https://tvn24.pl/katowice/dariusz-kmiecik-brygida-frosztega-kmiecik-i-remigiusz-kmiecik-dziesiata-rocznica-smieci-dziennikarzy-i-ich-synka-st8147607?source=rss](https://tvn24.pl/katowice/dariusz-kmiecik-brygida-frosztega-kmiecik-i-remigiusz-kmiecik-dziesiata-rocznica-smieci-dziennikarzy-i-ich-synka-st8147607?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:39:53+00:00


    
    <img src="https://fakty.tvn24.pl/ludzie-faktow/cdn-zdjecie-njz27i-dariusz-kmiecik-6599964/alternates/LANDSCAPE_1280" alt="Dariusz Kmiecik zginął razem z żoną i synkiem. Mija 10 lat od ich śmierci " />
    Reporter "Faktów" TVN Dariusz Kmiecik, jego żona Brygida Frosztęga-Kmiecik i syn Remigiusz zginęli 10 lat temu - 23 października 2014 roku. Tamtego dnia przed godziną piątą nad ranem w katowickiej kamienicy, w której mieszkali, wybuchł gaz.
    
    

## "Na złość" partnerce trafił do więzienia, po wyjściu zdemolował auta, by "odreagować rozstanie"
 - [https://tvn24.pl/tvnwarszawa/okolice/ciechanow-na-zlosc-partnerce-trafil-do-wiezienia-po-wyjsciu-zdemolowal-auta-by-odreagowac-rozstanie-st8147617?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ciechanow-na-zlosc-partnerce-trafil-do-wiezienia-po-wyjsciu-zdemolowal-auta-by-odreagowac-rozstanie-st8147617?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:35:14+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7101541-mezczyzna-zostal-tymczasowo-aresztowany-ph8126637/alternates/LANDSCAPE_1280" alt=""Na złość" partnerce trafił do więzienia, po wyjściu zdemolował auta, by "odreagować rozstanie"" />
    Uszkodził pięć zaparkowanych samochodów, bo - jak powiedział policjantom - chciał odreagować złość po rozstaniu z dziewczyną. 22-latek niedawno wyszedł z więzienia, gdzie trafił na kilka dni, by zrobić "na złość" swojej partnerce. 
    
    

## Po ulewach zawalił się budynek. Uratowali 15 osób, szukają kolejnych
 - [https://tvn24.pl/tvnmeteo/swiat/po-ulewach-zawalil-sie-budynek-uratowali-15-osob-szukaja-kolejnych-st8147574?source=rss](https://tvn24.pl/tvnmeteo/swiat/po-ulewach-zawalil-sie-budynek-uratowali-15-osob-szukaja-kolejnych-st8147574?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:34:31+00:00


    
    <img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2630415-indie-ph8147596/alternates/LANDSCAPE_1280" alt="Po ulewach zawalił się budynek. Uratowali 15 osób, szukają kolejnych" />
    Na skutek intensywnych opadów deszczu doszło do zawalenia się budynku na placu budowy w indyjskim mieście Bengaluru na południu kraju. Ratownicy wyciągnęli spod gruzów kilkanaście osób, poszukują kolejnych.
    
    

## Eminem schodzi ze sceny, Barack Obama rapuje jeden z jego hitów 
 - [https://tvn24.pl/wybory-prezydenckie-2024-w-usa/eminem-przemowil-na-wiecu-demokratow-barack-obama-zarapowal-lose-yourself-st8147561?source=rss](https://tvn24.pl/wybory-prezydenckie-2024-w-usa/eminem-przemowil-na-wiecu-demokratow-barack-obama-zarapowal-lose-yourself-st8147561?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:33:25+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4706305-barack-obama-rapuje-hit-eminema-na-wiecu-w-detroit-ph8147513/alternates/LANDSCAPE_1280" alt="Eminem schodzi ze sceny, Barack Obama rapuje jeden z jego hitów " />
    Barack Obama wystąpił podczas wtorkowego wiecu demokratów w Detroit. Na scenie stanął tuż po Eminemie. Wchodząc na mównicę były prezydent żartobliwie nawiązał do piosenki "Lose Yourself", jednego z największych hitów rapera. I wykonał jej fragment.  
    
    

## To będzie dłuższa noc. Kontrowersje nie milkną
 - [https://tvn24.pl/biznes/ze-swiata/zmiana-czasu-2024-kontrowersje-w-krajach-na-calym-swiecie-m-in-w-chile-niemczech-i-australii-st8147508?source=rss](https://tvn24.pl/biznes/ze-swiata/zmiana-czasu-2024-kontrowersje-w-krajach-na-calym-swiecie-m-in-w-chile-niemczech-i-australii-st8147508?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:28:02+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-mhlkli-zmiana-czasu-7409500/alternates/LANDSCAPE_1280" alt="To będzie dłuższa noc. Kontrowersje nie milkną" />
    Zmiana czasu wywołuje kontrowersje w krajach na całym świecie. W Chile, Niemczech i we Włoszech wskazuje się na negatywne skutki zdrowotne i społeczne przestawiania zegarków, z kolei w Brazylii i niektórych częściach Australii rozważa się powrót do zmiany czasu.
    
    

## Potrącił nastolatków na przejściu. Miał 2,5 promila
 - [https://tvn24.pl/wroclaw/olawa-50-latek-potracil-nastolatkow-na-przejsciu-mial-2-5-promila-st8147594?source=rss](https://tvn24.pl/wroclaw/olawa-50-latek-potracil-nastolatkow-na-przejsciu-mial-2-5-promila-st8147594?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:27:22+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1308476-potracil-dwoch-nastolatkow-na-przejsciu-dla-pieszych-byl-pijany-ph8147557/alternates/LANDSCAPE_1280" alt="Potrącił nastolatków na przejściu. Miał 2,5 promila" />
    Poważnie wyglądający wypadek w Oławie (woj. dolnośląskie). Kompletnie pijany 50-latek jadący samochodem osobowym potrącił na oznakowanym przejściu dla pieszych dwóch nastolatków. - Kierowca miał ponad 2,5 promila alkoholu w organizmie - informuje policja. Kierującemu grozi do trzech lat więzienia.
    
    

## Specjalne linie cmentarne od weekendu
 - [https://tvn24.pl/tvnwarszawa/bielany/specjalne-linie-cmentarne-od-weekendu-st8147577?source=rss](https://tvn24.pl/tvnwarszawa/bielany/specjalne-linie-cmentarne-od-weekendu-st8147577?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:16:45+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4281555-warszawskie-cmentarze-ph8142046/alternates/LANDSCAPE_1280" alt="Specjalne linie cmentarne od weekendu" />
    W najbliższy weekend, 26-27 października, uruchomione zostaną tramwaje i autobusy specjalnych linii cmentarnych. Ułatwią one dojazd do największych warszawskich nekropolii tym wszystkim, którzy chcą odwiedzić groby bliskich przed dniem Wszystkich Świętych.
    
    

## Nie będzie państwowych obchodów powstania węgierskiego 1956 roku? To nieprawda
 - [https://konkret24.tvn24.pl/swiat/nie-bedzie-panstwowych-obchodow-powstania-wegierskiego-1956-roku-to-nieprawda-st8146812?source=rss](https://konkret24.tvn24.pl/swiat/nie-bedzie-panstwowych-obchodow-powstania-wegierskiego-1956-roku-to-nieprawda-st8146812?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:12:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6812046-w-tym-roku-nie-bedzie-panstwowych-obchodow-powstania-wegierskiego-1956-roku-to-nieprawda-ph8147124/alternates/LANDSCAPE_1280" alt="Nie będzie państwowych obchodów powstania węgierskiego 1956 roku? To nieprawda" />
    Węgrzy obchodzą 68. rocznicę wybuchu powstania przeciwko reżimowi komunistycznemu. Jednak w sieci pojawił się doniesienia, że w tym roku na Węgrzech nie będzie państwowych obchodów upamiętniających to wydarzenie. "Oni juz kochaja Putina", "Skąd to info? Co to za brednie?" - pisali internauci w reakcji. Jak sprawdziliśmy, zaplanowano państwowe obchody tego święta.
    
    

## Nie żyje Dick Pope. Prócz nominacji do Oscara na koncie miał dwie Złote Żaby festiwalu Camerimage
 - [https://tvn24.pl/kultura-i-styl/dick-pope-nie-zyje-operator-filmowy-sekrety-i-klamstwa-vera-drake-iluzjonista-na-koncie-mial-dwie-zlote-zaby-festiwalu-camerimage-st8147424?source=rss](https://tvn24.pl/kultura-i-styl/dick-pope-nie-zyje-operator-filmowy-sekrety-i-klamstwa-vera-drake-iluzjonista-na-koncie-mial-dwie-zlote-zaby-festiwalu-camerimage-st8147424?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T07:11:21+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6760600-nie-zyje-wybitny-operator-filmowy-dick-pope-ph8147441/alternates/LANDSCAPE_1280" alt="Nie żyje Dick Pope. Prócz nominacji do Oscara na koncie miał dwie Złote Żaby festiwalu Camerimage" />
    Nie żyje Dick Pope - wybitny brytyjski operator filmowy, który zasłynął przede wszystkim jako autor zdjęć do wielkich filmów Mike'a Leigh, takich jak "Sekrety i kłamstwa" czy "Pan Turner". Pope dwukrotnie był nominowany do Oscara, a na długiej liście nagród miał również dwie Złote Żaby zdobyte na Festiwalu Sztuki Operatorskiej Camerimage.
    
    

## Samochód koziołkował i dachował, z auta wypadła nastolatka  
 - [https://tvn24.pl/lublin/krolewski-dwor-samochod-dachowal-dwie-nastolatki-w-szpitalu-st8147503?source=rss](https://tvn24.pl/lublin/krolewski-dwor-samochod-dachowal-dwie-nastolatki-w-szpitalu-st8147503?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:45:05+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2189660-kierujaca-i-pasazerka-samochodu-zostaly-przetransportowane-do-szpitali-ph8147507/alternates/LANDSCAPE_1280" alt="Samochód koziołkował i dachował, z auta wypadła nastolatka  " />
    Dwie nastolatki zostały ranne w wypadku, do którego doszło w miejscowości Królewski Dwór (Lubelskie). Ze wstępnych ustaleń policjantów wynika, że ich samochód wypadł z drogi i kilkukrotnie przekoziołkował zatrzymując się na dachu. Chwilę później w ich pojazd uderzyło inne auto. 
    
    

## Zatrzymano męża więzionej dziennikarki Biełsatu
 - [https://tvn24.pl/swiat/bialorus-ihar-iliasz-maz-wiezionej-dziennikarki-bielsatu-kaciaryny-andrejewej-zatrzymany-st8147416?source=rss](https://tvn24.pl/swiat/bialorus-ihar-iliasz-maz-wiezionej-dziennikarki-bielsatu-kaciaryny-andrejewej-zatrzymany-st8147416?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:41:26+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5217160-bialoruskie-wiezienie-zdjecie-ilustracyjne-ph7216995/alternates/LANDSCAPE_1280" alt="Zatrzymano męża więzionej dziennikarki Biełsatu" />
    Ihar Iliasz, mąż więzionej dziennikarki telewizji Biełsat Kaciaryny Andrejewej, został zatrzymany za udzielanie komentarzy mediom uznanym przez białoruski reżim za "organizacje ekstremistyczne".
    
    

## "Ilości wody są bezprecedensowe", a najgorsze "dopiero nadejdzie"
 - [https://tvn24.pl/tvnmeteo/swiat/zalane-domy-tysiace-ewakuowanych-prezydent-najgorsze-dopiero-nadejdzie-st8147454?source=rss](https://tvn24.pl/tvnmeteo/swiat/zalane-domy-tysiace-ewakuowanych-prezydent-najgorsze-dopiero-nadejdzie-st8147454?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:18:16+00:00


    
    <img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8262504-w-miescie-naga-w-regionie-bicol-doszlo-do-powodzi-blyskawicznych-ph8147501/alternates/LANDSCAPE_1280" alt=""Ilości wody są bezprecedensowe", a najgorsze "dopiero nadejdzie"" />
    Na Filipiny nadciąga burza tropikalna Trami. Na wyspie już drastycznie pogorszyła się pogoda. W centralnym regionie Bicol, gdzie doszło do gwałtownych powodzi, zginęła co najmniej jedna osoba, są ranni i zaginieni. Ewakuowano kilkanaście tysięcy osób. Zwieszona została działalność biur oraz szkół na głównej wyspie Luzon.
    
    

## Wody po dachy. Żywioł jeszcze nie uderzył, ale już zabija
 - [https://tvn24.pl/tvnmeteo/swiat/wody-po-dachy-zywiol-jeszcze-nie-uderzyl-ale-juz-zabija-st8147454?source=rss](https://tvn24.pl/tvnmeteo/swiat/wody-po-dachy-zywiol-jeszcze-nie-uderzyl-ale-juz-zabija-st8147454?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:18:16+00:00


    
    <img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2575113-powodz-w-prowincji-albay-ph8148106/alternates/LANDSCAPE_1280" alt="Wody po dachy. Żywioł jeszcze nie uderzył, ale już zabija" />
    Burza tropikalna Trami jeszcze nie dotarła nad Filipiny, ale już spowodowała katastrofalne powodzie, a także ofiary śmiertelne. W centralnym regionie Bicol zginęło co najmniej 14 osób. Domy opuściły dziesiątki tysięcy ludzi. Zwieszona została działalność biur oraz szkół na głównej wyspie Luzon.
    
    

## Czterolatka przewróciła się na pasach, kompletnie pijany ojciec nie był w stanie jej pomóc
 - [https://tvn24.pl/lublin/lublin-kompletnie-pijany-ojciec-opiekowal-sie-corkami-zareagowali-swiadkowie-st8147481?source=rss](https://tvn24.pl/lublin/lublin-kompletnie-pijany-ojciec-opiekowal-sie-corkami-zareagowali-swiadkowie-st8147481?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:09:21+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-s2w8u7-rodzice-byli-kompletnie-pijani-3115475/alternates/LANDSCAPE_1280" alt="Czterolatka przewróciła się na pasach, kompletnie pijany ojciec nie był w stanie jej pomóc" />
    Prawie cztery promile alkoholu miał w organizmie 35-latek, który kompletnie pijany wybrał się z córkami na spacer po Lublinie. Gdy jednak z nich przewróciła się na rowerku, nie był w stanie jej pomóc. O sprawie powiadomili policję świadkowie zdarzenia. Mężczyzna odpowie za narażenie córek na bezpośrednie niebezpieczeństwo.
    
    

## Poszukiwany za podwójne zabójstwo w Stambule wyszedł na balkon w Tomaszowie Mazowieckim. Czeka na ekstradycję
 - [https://tvn24.pl/lodz/tomaszow-mazowiecki-poszukiwany-czerwona-nota-interpolu-za-podwojne-zabojstwo-w-stambule-wyszedl-na-balkon-zostal-zatrzymany-czeka-na-ekstradycje-st8147494?source=rss](https://tvn24.pl/lodz/tomaszow-mazowiecki-poszukiwany-czerwona-nota-interpolu-za-podwojne-zabojstwo-w-stambule-wyszedl-na-balkon-zostal-zatrzymany-czeka-na-ekstradycje-st8147494?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T06:05:44+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5637995-mezczyzna-zostal-zatrzymany-w-tomaszowie-mazowieckim-ph8147490/alternates/LANDSCAPE_1280" alt="Poszukiwany za podwójne zabójstwo w Stambule wyszedł na balkon w Tomaszowie Mazowieckim. Czeka na ekstradycję" />
    Policja zatrzymała obywatela Turcji podejrzanego o dokonanie podwójnego zabójstwa w Stambule. Ukrywał się w Tomaszowie Mazowieckim (woj. łódzkie). Mężczyzna po przesłuchaniu w prokuraturze czeka w areszcie na decyzję sądu o ekstradycji do Turcji.
    
    

## Usunęli nielegalne sieci kłusownicze
 - [https://tvn24.pl/szczecin/szczecin-nielegalne-sieci-klusownicze-wylowione-z-toru-wodnego-st8146109?source=rss](https://tvn24.pl/szczecin/szczecin-nielegalne-sieci-klusownicze-wylowione-z-toru-wodnego-st8146109?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:52:40+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6095946-szczecin-usuniecie-sieci-klusowniczych-ph8146083/alternates/LANDSCAPE_1280" alt="Usunęli nielegalne sieci kłusownicze" />
    Na jednym ze szczecińskich torów wodnych policjanci razem ze strażą rybacką wyłowili nielegalnie zarzucone sieci kłusownicze. Mundurowi zabezpieczyli materiał dowodowy i przekazali go do Inspektoratu Rybołówstwa Morskiego w Szczecinie. Sprawcom grozi kara administracyjna.
    
    

## Skrajnej prawicy się nie udało. Dotychczasowy kanclerz Austrii z misją
 - [https://tvn24.pl/swiat/austria-dotychczasowy-kanclerz-karl-nehammer-otrzymal-misje-utworzenia-nowego-rzadu-st8147407?source=rss](https://tvn24.pl/swiat/austria-dotychczasowy-kanclerz-karl-nehammer-otrzymal-misje-utworzenia-nowego-rzadu-st8147407?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:46:40+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-873784-karl-nehammer-ph8147386/alternates/LANDSCAPE_1280" alt="Skrajnej prawicy się nie udało. Dotychczasowy kanclerz Austrii z misją" />
    Prezydent Austrii Alexander Van der Bellen powierzył misję utworzenia rządu dotychczasowemu kanclerzowi, chadekowi Karlowi Nehammerowi, ponieważ skrajnie prawicowa FPOe nie byłaby w stanie stworzyć koalicji. Kanclerz oświadczył, że koalicja z socjaldemokracją (SPO) wymagałaby włączenia trzeciej partii.
    
    

## Nie ma jedzenia, wody, prądu, wszędzie czuć palony węgiel drzewny
 - [https://tvn24.pl/tvnmeteo/swiat/nie-ma-jedzenia-wody-pradu-wszedzie-czuc-palony-wegiel-drzewny-st8147466?source=rss](https://tvn24.pl/tvnmeteo/swiat/nie-ma-jedzenia-wody-pradu-wszedzie-czuc-palony-wegiel-drzewny-st8147466?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:39:34+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8562086-w-zambii-panuje-najwieksza-od-40-lat-susza-ph8147477/alternates/LANDSCAPE_1280" alt="Nie ma jedzenia, wody, prądu, wszędzie czuć palony węgiel drzewny" />
    Zambia doświadczyła w tym roku najgorszej od czterdziestu lat suszy. Zniszczona została połowa upraw kukurydzy, która jest podstawą tamtejszej kuchni. W wielu miejscach brakuje żywności i wody, występują częste przerwy w dostawach prądu. Zamożniejsi używają generatorów, a biedni, czyli większość, palą węgiel drzewny.
    
    

## "Zgierzuwiusz" wybuchł blisko siedem lat temu. Do dziś odpadów nikt nie sprzątnął. Pomóc miał "okrągły stół"
 - [https://tvn24.pl/lodz/zgierz-blisko-siedem-lat-od-pozaru-skladowiska-sad-wydal-wyrok-kto-ma-uprzatnac-odpady-do-dzis-nikt-tego-nie-zrobil-st8146681?source=rss](https://tvn24.pl/lodz/zgierz-blisko-siedem-lat-od-pozaru-skladowiska-sad-wydal-wyrok-kto-ma-uprzatnac-odpady-do-dzis-nikt-tego-nie-zrobil-st8146681?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:32:38+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9302977-policja-bada-zwiazki-miedzy-pozarami-skladowisk-odpadow-ph1782101/alternates/LANDSCAPE_1280" alt=""Zgierzuwiusz" wybuchł blisko siedem lat temu. Do dziś odpadów nikt nie sprzątnął. Pomóc miał "okrągły stół"" />
    Od jednego z największych pożarów odpadów w Polsce mija siódmy rok. Pogorzelisko do dziś nie zostało uprzątnięte, bo starostwo powiatowe z urzędem marszałkowskim kłóci się, kto ma za to zapłacić. Nie pomógł nawet wyrok NSA, który zobowiązał do tego marszałka. Na przeszkodzie stanęła polityka, bo marszałek był z PiS, a starosta z PSL. Teraz wszyscy aktorzy dramatu są z jednego politycznego środowiska, ale problem wciąż jest daleki od rozwiązania. - Okrągły stół do końca to nie był. Jesteśmy na dwóch różnych stanowiskach, ale rozmawiamy - podsumowała pierwsze od lat spotkanie na ten temat starosta zgierska Iwona Dąbek. 
    
    

## Potężne straty Orlenu. Koncern podaje kwoty
 - [https://tvn24.pl/biznes/z-kraju/orlen-inwestycje-w-ruch-i-polska-press-przyniosly-straty-na-275-mln-zl-st8147464?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-inwestycje-w-ruch-i-polska-press-przyniosly-straty-na-275-mln-zl-st8147464?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:28:50+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4267928-orlen-siedziba-shutterstock1833447871-ph7757612/alternates/LANDSCAPE_1280" alt="Potężne straty Orlenu. Koncern podaje kwoty" />
    Inwestycje w Ruch i Polska Press przyniosły Grupie Orlen dotychczas 275 milionów złotych strat - poinformowało biuro prasowe Orlenu w mediach społecznościowych.
    
    

## Trump wpisuje się "w ogólną definicję faszysty". Kelly: mówił, że potrzebuje takich generałów, jakich miał Hitler
 - [https://tvn24.pl/wybory-prezydenckie-2024-w-usa/wybory-prezydenckie-usa-2024-general-kelly-donald-trump-spelnia-definicje-faszysty-mowil-ze-potrzebuje-generalow-takich-jakich-mial-adolf-hitler-st8147443?source=rss](https://tvn24.pl/wybory-prezydenckie-2024-w-usa/wybory-prezydenckie-usa-2024-general-kelly-donald-trump-spelnia-definicje-faszysty-mowil-ze-potrzebuje-generalow-takich-jakich-mial-adolf-hitler-st8147443?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:18:55+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6723901-donald-trump-i-john-kelly-na-zdjeciu-z-2017-roku-ph8147445/alternates/LANDSCAPE_1280" alt="Trump wpisuje się "w ogólną definicję faszysty". Kelly: mówił, że potrzebuje takich generałów, jakich miał Hitler" />
    Donald Trump jest na skrajnej prawicy, jest autorytarny, podziwia ludzi, którzy są dyktatorami, więc z pewnością mieści się w ogólnej definicji faszysty - stwierdził były kluczowy współpracownik republikanina, szef personelu Białego Domu w latach 2017-2019 John Kelly w wywiadach dla "New York Timesa" i magazynu "The Atlantic". Kelly bezpośrednio potwierdził doniesienia o tym, że były prezydent USA miał mówić "więcej niż raz", że Adolf Hitler "robił też trochę dobrych rzeczy". Według "The Atlantic" w czasie jednej z rozmów w Białym Domu Trump miał też stwierdzić, że potrzebuje tak lojalnych generałów, jakich miał Hitler. Sztab kampanii republikanina zapewnia, że takie słowa nie padły.
    
    

## W dziewięciu województwach może być niebezpiecznie
 - [https://tvn24.pl/tvnmeteo/prognoza/w-dziewieciu-wojewodztwach-moze-byc-niebezpiecznie-st8147461?source=rss](https://tvn24.pl/tvnmeteo/prognoza/w-dziewieciu-wojewodztwach-moze-byc-niebezpiecznie-st8147461?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:08:28+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-v1e5h5-nad-ranem-pojawia-sie-mgly-5409885/alternates/LANDSCAPE_1280" alt="W dziewięciu województwach może być niebezpiecznie" />
    Kierowcy na dużym obszarze Polski powinni spodziewać się trudnych warunków pogodowych. Mogą pojawić się gęste mgły - prognozuje Instytut Meteorologii i Gospodarki Wodnej. 
    
    

## 25 zarzutów dla 25-latka, chodzi o 38 kilogramów narkotyków
 - [https://tvn24.pl/tvnwarszawa/okolice/otwock-warszawa-jest-podejrzany-o-udzial-w-zorganizowanej-grupie-przestepczej-w-tle-narkotyki-zostal-zatrzymany-st8147333?source=rss](https://tvn24.pl/tvnwarszawa/okolice/otwock-warszawa-jest-podejrzany-o-udzial-w-zorganizowanej-grupie-przestepczej-w-tle-narkotyki-zostal-zatrzymany-st8147333?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:07:35+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4299177-zatrzymany-26-latek-zostal-tymczasowo-aresztowany-ph8147462/alternates/LANDSCAPE_1280" alt="25 zarzutów dla 25-latka, chodzi o 38 kilogramów narkotyków" />
    Policjanci zatrzymali 25-latka z Warszawy, który jest podejrzany o wprowadzenie do obrotu 38 kilogramów narkotyków. Usłyszał 25 zarzutów, w tym udziału w zorganizowanej grupie przestępczej. 
    
    

## Przychodził do sklepu, obrażał ekspedientki i groził im śmiercią
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-agresywny-mezczyzna-w-sklepie-krzyczal-i-wyzywal-ekspedientki-grozil-im-pozbawieniem-zycia-st8147300?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-agresywny-mezczyzna-w-sklepie-krzyczal-i-wyzywal-ekspedientki-grozil-im-pozbawieniem-zycia-st8147300?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T05:00:00+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9210346-zatrzymanie-ph8048038/alternates/LANDSCAPE_1280" alt="Przychodził do sklepu, obrażał ekspedientki i groził im śmiercią" />
    Agresywny mężczyzna wystraszył ekspedientki w jednym ze sklepów na Woli. Krzyczał i wyzywał kobiety, a także groził, że je zabije. Został zatrzymany. 
    
    

## Ostrzeżenia IMGW dla większości kraju
 - [https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-dla-wiekszosci-kraju-st8147461?source=rss](https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-dla-wiekszosci-kraju-st8147461?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T04:58:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9846346-uwaga-na-mgly-ph5637837/alternates/LANDSCAPE_1280" alt="Ostrzeżenia IMGW dla większości kraju" />
    Na przeważającym obszarze Polski warunki do jazdy w ciągu najbliższej nocy i o poranku w czwartek będą trudne. Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia przed gęstą mgłą.
    
    

## Media: Republika Serbska odbiera ziemię nie-Serbom w Bośni 
 - [https://tvn24.pl/swiat/bosnia-o-hercegowina-dziennik-oslobodzienie-republika-serbska-konfiskuje-mienie-repatriantow-nie-serbow-st8147431?source=rss](https://tvn24.pl/swiat/bosnia-o-hercegowina-dziennik-oslobodzienie-republika-serbska-konfiskuje-mienie-repatriantow-nie-serbow-st8147431?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T04:38:51+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2045681-banja-luka-stolica-autonomicznej-republiki-serbskiej-w-ramach-bosni-i-hercegowiny-ph3146590/alternates/LANDSCAPE_1280" alt="Media: Republika Serbska odbiera ziemię nie-Serbom w Bośni " />
    Osoby powracające do domów na terenie Republiki Serbskiej - autonomicznej części Bośni i Hercegowiny - są pozbawiane ziemi i nie mają żadnej ochrony ze strony państwa - alarmuje dziennik "Oslobodzienie". Rozmówca tej gazety wezwał władze Bośni i Hercegowiny do udzielenia pomocy prawnej tysiącom osób podzielających jego los. 
    
    

## Niezbędna pomoc zagrożona przez rosyjskie ataki
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-informacje-niezbedna-pomoc-zagrozona-przez-rosyjskie-ataki-st8147425?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-informacje-niezbedna-pomoc-zagrozona-przez-rosyjskie-ataki-st8147425?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T04:18:35+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1200772-ukraina-zboze-zboze-z-ukrainy-kryzys-zbozowy-kijow-ph7279492/alternates/LANDSCAPE_1280" alt="Niezbędna pomoc zagrożona przez rosyjskie ataki" />
    973 dni temu rozpoczęła się pełnoskalowa rosyjska inwazja na Ukrainę. Rosja wzmogła ataki na ukraińską infrastrukturę portową na Morzu Czarnym, co opóźnia dostawy niezbędnej pomocy dla Palestyńczyków i uniemożliwia dostarczenie kluczowych dostaw zboża na globalne południe - ostrzegł brytyjski premier Keir Starmer. Oto co wydarzyło się w Ukrainie i wokół niej w ciągu ostatniej doby.
    
    

## 18-latek na parkingu "ćwiczył" jazdę bokiem. Czeka go powtórka egzaminu na prawo jazdy
 - [https://tvn24.pl/tvnwarszawa/okolice/otwock-18-latek-na-parkingu-cwiczyl-jazde-bokiem-czeka-go-powtorka-egzaminu-na-prawo-jazdy-st8147436?source=rss](https://tvn24.pl/tvnwarszawa/okolice/otwock-18-latek-na-parkingu-cwiczyl-jazde-bokiem-czeka-go-powtorka-egzaminu-na-prawo-jazdy-st8147436?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T04:10:00+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8751405-18-latek-czeka-powtorka-egzaminu-ph8147434/alternates/LANDSCAPE_1280" alt="18-latek na parkingu "ćwiczył" jazdę bokiem. Czeka go powtórka egzaminu na prawo jazdy" />
    18-letni kierowca dwa dni z rzędu na sklepowym parkingu "ćwiczył" jazdę bokiem. Został za to ukarany dwoma mandatami i 30 punktami. Policjanci zatrzymali mu prawo jazdy i czeka go powtórka egzaminu. 
    
    

## "Weszli w tłum i otworzyli ogień". Pięciu zabitych po meczu piłkarskim
 - [https://tvn24.pl/swiat/jamajka-strzelanina-po-meczu-nie-zyje-piec-osob-st8147426?source=rss](https://tvn24.pl/swiat/jamajka-strzelanina-po-meczu-nie-zyje-piec-osob-st8147426?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T03:40:30+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-117982-interwencja-sluzb-bezpieczenstwa-na-jamajce-ph8147430/alternates/LANDSCAPE_1280" alt=""Weszli w tłum i otworzyli ogień". Pięciu zabitych po meczu piłkarskim" />
    Grupa mężczyzn weszła w tłum i otworzyła ogień w kierunku uczestników towarzyskiego meczu piłki nożnej na przedmieściach stolicy Jamajki, Kingston - podały lokalne media. W wyniku tragicznego zdarzenia pięć osób zginęło, a dwie zostały ranne. Policja zastrzeliła jednego z domniemanych napastników. 
    
    

## Rośnie liczba związków niesformalizowanych
 - [https://tvn24.pl/polska/zwiazki-partnerskie-rosnie-liczba-zwiazkow-niesformalizowanych-st8147421?source=rss](https://tvn24.pl/polska/zwiazki-partnerskie-rosnie-liczba-zwiazkow-niesformalizowanych-st8147421?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T03:26:25+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6032483-rosnie-liczba-zwiazkow-niesformalizowanych-ph8147420/alternates/LANDSCAPE_1280" alt="Rośnie liczba związków niesformalizowanych" />
    Projekt ustawy o związkach partnerskich został ogłoszony. Polskie Stronnictwo Ludowe mówi, że to ustawa małżeńsko-podobna. Społeczna rewolucja jest faktem i dzieje się na naszych oczach, czego niektórzy politycy zdają się nie zauważać. Coraz więcej rozwodów, coraz mniej małżeństw i coraz więcej dzieci w nieformalnych związkach partnerskich. Materiał magazynu "Polska i Świat". Całe wydanie dostępne w TVN24 GO.
    
    

## Ponad 1000 skazanych wypuszczonych z więzień w Wielkiej Brytanii
 - [https://tvn24.pl/swiat/ponad-1000-skazanych-wypuszczonych-z-wiezien-w-wielkiej-brytanii-st8147412?source=rss](https://tvn24.pl/swiat/ponad-1000-skazanych-wypuszczonych-z-wiezien-w-wielkiej-brytanii-st8147412?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T03:15:09+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5113456-shutterstock-529543903-ph8147387/alternates/LANDSCAPE_1280" alt="Ponad 1000 skazanych wypuszczonych z więzień w Wielkiej Brytanii" />
    Brytyjski resort sprawiedliwości, w ramach rozwiązania problemu braku miejsc w więzieniach, informuje o wypuszczeniu kolejnych 1100 więźniów w Anglii i Walii. Plan ten wywołuje duże kontrowersje.
    
    

## Kokaina do pizzy w restauracji w Niemczech
 - [https://tvn24.pl/swiat/niemcy-restauracja-w-duesseldorfie-sprzedawala-kokaine-do-pizzy-st8147417?source=rss](https://tvn24.pl/swiat/niemcy-restauracja-w-duesseldorfie-sprzedawala-kokaine-do-pizzy-st8147417?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T03:10:29+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-fva52x-shutterstock_1995245237-7292477/alternates/LANDSCAPE_1280" alt="Kokaina do pizzy w restauracji w Niemczech" />
    Niemiecka policja rozbiła sieć dilerów narkotyków. Kiedy policjanci zadzwonili do drzwi mieszkania 36-letniego kierownika pizzerii, aby go aresztować, miał on wyrzucić przez okno torbę pełną narkotyków.
    
    

## Izrael potwierdza: następca Nasrallaha zabity
 - [https://tvn24.pl/swiat/izrael-potwierdza-zabojstwo-haszema-safiedinego-nastepcy-przywodcy-hezbollahu-hassana-nasrallaha-st8147419?source=rss](https://tvn24.pl/swiat/izrael-potwierdza-zabojstwo-haszema-safiedinego-nastepcy-przywodcy-hezbollahu-hassana-nasrallaha-st8147419?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T03:04:24+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6052706-haszem-safiedine-byl-nastepca-przywodcy-hezbollahu-hassana-nasrallaha-ph8147418/alternates/LANDSCAPE_1280" alt="Izrael potwierdza: następca Nasrallaha zabity" />
    Izrael potwierdził, że zabił Haszema Safiedinego, następcy przywódcy Hezbollahu Hassana Nasrallaha, który zginął w izraelskim ataku wymierzonym we wspieraną przez Iran libańską grupę. Izrael będzie kontynuować ataki na Hezbollah nawet po zakończeniu operacji lądowej na południu Libanu - zapowiedział minister obrony Joaw Galant podczas spotkania z amerykańskim sekretarzem stanu Antonym Blinkenem.
    
    

## Pogoda na dziś - środa 23.10. Chwilami mocno się zachmurzy
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-sroda-23-10-chwilami-mocno-sie-zachmurzy-st8147304?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-sroda-23-10-chwilami-mocno-sie-zachmurzy-st8147304?source=rss)
 - RSS feed: $source
 - date published: 2024-10-23T00:00:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-188k5f-zimno-pochmurno-moze-przelotnie-padac-7380411/alternates/LANDSCAPE_1280" alt="Pogoda na dziś - środa 23.10. Chwilami mocno się zachmurzy" />
    Pogoda na dziś. Środa 23.10 przyniesie dużo slońca, ale czekają nas też chwile, w których niebo się zachmurzy. Nie powinno jednak padać. nieba. Temperatura nie przekroczy 15 stopni Celsjusza.
    
    

