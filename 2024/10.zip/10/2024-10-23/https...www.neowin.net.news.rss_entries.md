# Source:Neowin, URL:https://www.neowin.net/news/rss, language:en-us

## WhatsApp may soon let you create and share sticker packs
 - [https://www.neowin.net/news/whatsapp-may-soon-let-you-create-and-share-sticker-packs](https://www.neowin.net/news/whatsapp-may-soon-let-you-create-and-share-sticker-packs)
 - RSS feed: $source
 - date published: 2024-10-23T14:26:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/08/1723724887_whatsapp-hero_medium.jpg" alt="" /></div>WhatsApp is working on a new feature that will help users not only create but also share sticker packs with friends. <a href="https://www.neowin.net/news/whatsapp-may-soon-let-you-create-and-share-sticker-packs/">Read more...</a>

## Samsung reportedly considers launching triple-foldable phone in 2025
 - [https://www.neowin.net/news/samsung-reportedly-considers-launching-triple-foldable-phone-in-2025](https://www.neowin.net/news/samsung-reportedly-considers-launching-triple-foldable-phone-in-2025)
 - RSS feed: $source
 - date published: 2024-10-23T14:10:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715583350_galaxy-z-fold5-hero_medium.jpg" alt="" /></div>Samsung is reportedly considering launching a new tri-fold smartphone by 2025 to compete with Huawei&#039;s recent entry into the multi-screen foldable device market.  <a href="https://www.neowin.net/news/samsung-reportedly-considers-launching-triple-foldable-phone-in-2025/">Read more...</a>

## Save 30% on four variants of the 64GB Apple iPad Mini on Amazon
 - [https://www.neowin.net/deals/save-30-on-four-variants-of-the-64gb-apple-ipad-mini-on-amazon](https://www.neowin.net/deals/save-30-on-four-variants-of-the-64gb-apple-ipad-mini-on-amazon)
 - RSS feed: $source
 - date published: 2024-10-23T13:54:02+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/10/1728554541_ezgif.com-webp-to-jpg-converter_medium.jpg" alt="" /></div>Powered by the A15 Bionic chip, four variants of the 6th Gen Apple iPad Mini are currently selling at a 30% discount off their original MSRP on Amazon US. <a href="https://www.neowin.net/deals/save-30-on-four-variants-of-the-64gb-apple-ipad-mini-on-amazon/">Read more...</a>

## The No Man's Sky: The Cursed update offers some spooky new space content
 - [https://www.neowin.net/news/the-no-mans-sky-the-cursed-update-offers-some-spooky-new-space-content](https://www.neowin.net/news/the-no-mans-sky-the-cursed-update-offers-some-spooky-new-space-content)
 - RSS feed: $source
 - date published: 2024-10-23T13:40:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/10/1729688748_no-mans-sky-the-cursed-screen-1-efe589e6a8d3d2c88938-1900x1080_medium.jpg" alt="" /></div>Hello Games is rolling out the latest free content update for its space-based survival game No Man&#039;s Sky. The Cursed will make some interesting changes to the game. <a href="https://www.neowin.net/news/the-no-mans-sky-the-cursed-update-offers-some-spooky-new-space-content/">Read more...</a>

## Apple rumored to be developing a dedicated iOS game store
 - [https://www.neowin.net/news/apple-rumored-to-be-developing-a-dedicated-ios-game-store](https://www.neowin.net/news/apple-rumored-to-be-developing-a-dedicated-ios-game-store)
 - RSS feed: $source
 - date published: 2024-10-23T13:24:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2023/04/1681962512_apple-app-store-awards-2022-trophy.jpg.landing-big_medium.jpg" alt="" /></div>Apple&#039;s game store will include a Play Now tab, letting users browse games from Apple Arcade and the App Store. <a href="https://www.neowin.net/news/apple-rumored-to-be-developing-a-dedicated-ios-game-store/">Read more...</a>

## Samsung Galaxy AI to add support for four new languages by the year end
 - [https://www.neowin.net/news/samsung-galaxy-ai-to-add-support-for-four-new-languages-by-the-year-end](https://www.neowin.net/news/samsung-galaxy-ai-to-add-support-for-four-new-languages-by-the-year-end)
 - RSS feed: $source
 - date published: 2024-10-23T12:12:02+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/10/1729682454_galaxy-ai_medium.jpg" alt="" /></div>Samsung has recently confirmed adding support for four new languages and dialects to Galaxy AI, taking the total to 20. <a href="https://www.neowin.net/news/samsung-galaxy-ai-to-add-support-for-four-new-languages-by-the-year-end/">Read more...</a>

## Qualcomm announces Snapdragon Game Super Resolution 2 with several significant improvements
 - [https://www.neowin.net/news/qualcomm-announces-snapdragon-game-super-resolution-2-with-several-significant-improvements](https://www.neowin.net/news/qualcomm-announces-snapdragon-game-super-resolution-2-with-several-significant-improvements)
 - RSS feed: $source
 - date published: 2024-10-23T11:42:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/10/1729680494_snapdragon_game_super_resolution_2_medium.jpg" alt="" /></div>Qualcomm has released Snapdragon Game Super Resolution 2 (GSR2), a new temporal upscaling technology for Adreno GPUs. <a href="https://www.neowin.net/news/qualcomm-announces-snapdragon-game-super-resolution-2-with-several-significant-improvements/">Read more...</a>

## Save up to 19% on Samsung's new 990 EVO Plus SSDs
 - [https://www.neowin.net/deals/save-up-to-19-on-samsungs-new-990-evo-plus-ssds](https://www.neowin.net/deals/save-up-to-19-on-samsungs-new-990-evo-plus-ssds)
 - RSS feed: $source
 - date published: 2024-10-23T10:30:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/09/1727280832_samsung-semiconductors-ssd-990-evo-plus-supported-by-pcle-4.0_dl1_medium.jpg" alt="" /></div>Samsung&#039;s new 990 EVO Plus SSDs are now available, and the 1TB and 2TB versions are already available with up to a 19% discount. <a href="https://www.neowin.net/deals/save-up-to-19-on-samsungs-new-990-evo-plus-ssds/">Read more...</a>

## Microsoft releases fixes for incorrect battery estimation on Surface Pro 9
 - [https://www.neowin.net/news/microsoft-releases-fixes-for-incorrect-battery-estimation-on-surface-pro-9](https://www.neowin.net/news/microsoft-releases-fixes-for-incorrect-battery-estimation-on-surface-pro-9)
 - RSS feed: $source
 - date published: 2024-10-23T09:46:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2022/10/1665393862_surface_pro_9_3_medium.jpg" alt="" /></div>If your Surface Pro 9 is shutting down abruptly due to incorrect battery level estimation, the latest firmware update will save your day. <a href="https://www.neowin.net/news/microsoft-releases-fixes-for-incorrect-battery-estimation-on-surface-pro-9/">Read more...</a>

## New Outlook for Windows finally getting personal non-Microsoft account support
 - [https://www.neowin.net/news/new-outlook-for-windows-finally-getting-personal-non-microsoft-account-support](https://www.neowin.net/news/new-outlook-for-windows-finally-getting-personal-non-microsoft-account-support)
 - RSS feed: $source
 - date published: 2024-10-23T09:06:02+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2020/07/1594748445_outlook_new_features_medium.jpg" alt="" /></div>Microsoft has confirmed that the New Outlook for Windows app is finally getting personal account support. <a href="https://www.neowin.net/news/new-outlook-for-windows-finally-getting-personal-non-microsoft-account-support/">Read more...</a>

## TSMC might have possibly violated U.S. export bans after its chip was found in Huawei device
 - [https://www.neowin.net/news/tsmc-might-have-possibly-violated-us-export-bans-after-its-chip-was-found-in-huawei-device](https://www.neowin.net/news/tsmc-might-have-possibly-violated-us-export-bans-after-its-chip-was-found-in-huawei-device)
 - RSS feed: $source
 - date published: 2024-10-23T08:38:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2022/12/1672410610_653753-1-6ke4q_medium.jpg" alt="" /></div>TSMC might be in trouble after its chip was found in a teardown of a Huawei device, which is a possible violation of U.S. export restrictions on Chinese companies.  <a href="https://www.neowin.net/news/tsmc-might-have-possibly-violated-us-export-bans-after-its-chip-was-found-in-huawei-device/">Read more...</a>

## Microsoft changes what happens when you open Office files on iOS and Android
 - [https://www.neowin.net/news/microsoft-changes-what-happens-when-you-open-office-files-on-ios-and-android](https://www.neowin.net/news/microsoft-changes-what-happens-when-you-open-office-files-on-ios-and-android)
 - RSS feed: $source
 - date published: 2024-10-23T07:50:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2022/04/1650984596_office_ios_app_medium.jpg" alt="" /></div>Microsoft is making changes to how its mobile productivity apps open Word, Excel, and PowerPoint files. <a href="https://www.neowin.net/news/microsoft-changes-what-happens-when-you-open-office-files-on-ios-and-android/">Read more...</a>

## Microsoft Authenticator gets three major improvements to enable secure authentication
 - [https://www.neowin.net/news/microsoft-authenticator-gets-three-major-improvements-to-enable-secure-authentication](https://www.neowin.net/news/microsoft-authenticator-gets-three-major-improvements-to-enable-secure-authentication)
 - RSS feed: $source
 - date published: 2024-10-23T07:16:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2020/12/1608058141_microsoft_authenticator_pwd_manager_medium.jpg" alt="" /></div>Microsoft has released a major update to its Authenticator app, enhancing the passkey registration process and overall security. <a href="https://www.neowin.net/news/microsoft-authenticator-gets-three-major-improvements-to-enable-secure-authentication/">Read more...</a>

## Samsung may have finally ended the chipset confusion for the Galaxy S25 series
 - [https://www.neowin.net/news/samsung-may-have-finally-ended-the-chipset-confusion-for-the-galaxy-s25-series](https://www.neowin.net/news/samsung-may-have-finally-ended-the-chipset-confusion-for-the-galaxy-s25-series)
 - RSS feed: $source
 - date published: 2024-10-23T06:50:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/10/1729663792_snapdragon-8-elite_medium.jpg" alt="" /></div>The latest report suggests that Samsung may have finally found the chipset it wants inside next year&#039;s Galaxy S25 series. <a href="https://www.neowin.net/news/samsung-may-have-finally-ended-the-chipset-confusion-for-the-galaxy-s25-series/">Read more...</a>

## Google Translate on Android may soon let you undo a deleted translation
 - [https://www.neowin.net/news/google-translate-on-android-may-soon-let-you-undo-a-deleted-translation](https://www.neowin.net/news/google-translate-on-android-may-soon-let-you-undo-a-deleted-translation)
 - RSS feed: $source
 - date published: 2024-10-23T06:16:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/06/1719483689_google_translate_new_languages_medium.jpg" alt="" /></div>Google is developing some new features for the Translate app on Android that will facilitate a seamless instant translation experience. <a href="https://www.neowin.net/news/google-translate-on-android-may-soon-let-you-undo-a-deleted-translation/">Read more...</a>

## Microsoft is making Windows great for musicians and other audio professionals
 - [https://www.neowin.net/news/microsoft-is-making-windows-great-for-musicians-and-other-audio-professionals](https://www.neowin.net/news/microsoft-is-making-windows-great-for-musicians-and-other-audio-professionals)
 - RSS feed: $source
 - date published: 2024-10-23T06:02:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2023/07/1689248583_windows_on_arm_medium.jpg" alt="" /></div>Microsoft is making several improvements to Windows for music industry professionals, including MIDI 2.0 support, a new USB Audio Class 2 Driver, and more. <a href="https://www.neowin.net/news/microsoft-is-making-windows-great-for-musicians-and-other-audio-professionals/">Read more...</a>

## Arm cancels Qualcomm's license to make ARM-based chips
 - [https://www.neowin.net/news/arm-cancels-qualcomms-license-to-make-arm-based-chips](https://www.neowin.net/news/arm-cancels-qualcomms-license-to-make-arm-based-chips)
 - RSS feed: $source
 - date published: 2024-10-23T05:46:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2021/01/1610555488_qualcomm_nuvia_medium.jpg" alt="" /></div>Arm is revoking Qualcomm&#039;s license to design chips using Arm&#039;s technology, potentially disrupting the smartphone and automotive industries. <a href="https://www.neowin.net/news/arm-cancels-qualcomms-license-to-make-arm-based-chips/">Read more...</a>

## The Google Pixel 9a's upgraded camera may offer better low-light performance
 - [https://www.neowin.net/news/the-google-pixel-9as-upgraded-camera-may-offer-better-low-light-performance](https://www.neowin.net/news/the-google-pixel-9as-upgraded-camera-may-offer-better-low-light-performance)
 - RSS feed: $source
 - date published: 2024-10-23T05:30:03+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/08/1724682116_pixel-9a_medium.jpg" alt="" /></div>Google is tipped to pack the same primary camera on the Pixel 9a as the Pixel 9 Pro Fold, which may offer better low-light performance. <a href="https://www.neowin.net/news/the-google-pixel-9as-upgraded-camera-may-offer-better-low-light-performance/">Read more...</a>

