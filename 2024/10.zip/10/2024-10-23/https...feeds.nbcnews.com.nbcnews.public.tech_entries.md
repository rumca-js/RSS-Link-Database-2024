# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## WNBA Finals Game 5 draws highest viewership in 25 years 
 - [https://www.nbcnews.com/sports/wnba/wnba-finals-game-5-draws-highest-viewership-25-years-rcna176752](https://www.nbcnews.com/sports/wnba/wnba-finals-game-5-draws-highest-viewership-25-years-rcna176752)
 - RSS feed: $source
 - date published: 2024-10-23T12:51:17+00:00

The fifth game of this year’s WNBA Finals between the Minnesota Lynx and the New York Liberty was the most-viewed WNBA finals game in 25 years across all networks, according to ESPN, citing Nielsen data. 

## McDonald's Quarter Pounders linked to deadly E. coli outbreak
 - [https://www.today.com/video/deadly-e-coli-outbreak-linked-to-mcdonald-s-quarter-pounders-222458949684](https://www.today.com/video/deadly-e-coli-outbreak-linked-to-mcdonald-s-quarter-pounders-222458949684)
 - RSS feed: $source
 - date published: 2024-10-23T11:57:09+00:00

The CDC is investigating a severe E. coli outbreak, spanning nearly a dozen states linked to McDonald’s popular Quarter Pounder hamburgers. The outbreak has sickened nearly 50 people and has caused at least one death in Colorado. NBC’s Maggie Vespa reports for TODAY.

## Former White House chief of staff John Kelly says Trump meets the definition of a 'fascist'
 - [https://www.nbcnews.com/politics/2024-election/john-kelly-says-donald-trump-meets-definition-fascist-rcna176706](https://www.nbcnews.com/politics/2024-election/john-kelly-says-donald-trump-meets-definition-fascist-rcna176706)
 - RSS feed: $source
 - date published: 2024-10-23T06:45:56+00:00

John Kelly, who served as White House chief of staff in the Trump administration, also said his one-time boss had spoken positively about Adolf Hitler while in office.

## Scientists use AI to help track whale migration
 - [https://www.nbcnews.com/now/video/scientists-use-ai-to-help-track-whale-migration-222438469550](https://www.nbcnews.com/now/video/scientists-use-ai-to-help-track-whale-migration-222438469550)
 - RSS feed: $source
 - date published: 2024-10-23T01:35:54+00:00

Scientists in California are using artificial intelligence to help match humpback whale tails that tell them where they have been and how healthy they are. NBC News'  Anne Thompson spoke to one scientist about how the whale tracking has helped preserve the ocean. 

