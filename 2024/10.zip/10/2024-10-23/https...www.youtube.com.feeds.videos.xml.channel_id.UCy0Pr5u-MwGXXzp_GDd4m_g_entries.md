# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Ghost baseball is real?
 - [https://www.youtube.com/watch?v=Do6xX3qMpxo](https://www.youtube.com/watch?v=Do6xX3qMpxo)
 - RSS feed: $source
 - date published: 2024-10-23T15:11:55+00:00

None

