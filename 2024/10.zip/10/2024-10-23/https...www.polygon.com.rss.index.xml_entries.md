# Source:Polygon -  All, URL:https://www.polygon.com/rss/index.xml, language:en

## Severance’s new season 2 trailer brings back the melon bar, now more terrifying than ever
 - [https://www.polygon.com/trailer/468810/severance-season-2-trailer-release-date-apple-tv](https://www.polygon.com/trailer/468810/severance-season-2-trailer-release-date-apple-tv)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:00+00:00


											

						
<figure>

<img alt="" data-caption="" data-portal-copyright="" data-has-syndication-rights="1" src="https://platform.polygon.com/wp-content/uploads/sites/2/2024/10/severance_s2_trailer.jpg?quality=90&#038;strip=all&#038;crop=0,0,100,100" />
	<figcaption></figcaption>
</figure>
<p class="has-text-align-none">The innies and outies of Apple TV Plus series <em><a href="https://www.polygon.com/reviews/22939662/severance-review-apple-tv">Severance</a></em> will return to the workplace in 2025. A new trailer for the second season of the Ben Stiller-produced sci-fi drama picks up right where the first season left off — with Adam Scott’s character Mark Scout (and audiences) reeling from <a href="https://www.polygon.com/23010270/severance-season-finale-explained-questions-creator">the shocking revelations of the finale</a>.</p>

<p class="has-text-align-none"><em>Severance</em> season 2’s teaser trailer is a dizzying first look at the show’s return, with Mark desperately sp

## ‘The Ballad of the Witches’ Road’ covers, ranked
 - [https://www.polygon.com/tv/464056/witches-road-ballad-ranking-agatha-all-along](https://www.polygon.com/tv/464056/witches-road-ballad-ranking-agatha-all-along)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:00+00:00


											

						
<figure>

<img alt="Agatha in ’70s rocker wear, singing with a band behind her in Agatha All Along" data-caption="" data-portal-copyright="" data-has-syndication-rights="1" src="https://platform.polygon.com/wp-content/uploads/sites/2/2024/10/MPY-104-13602_RC.jpeg?quality=90&#038;strip=all&#038;crop=0,0,100,100" />
	<figcaption></figcaption>
</figure>
<p class="has-text-align-none">Like <em>WandaVision </em>before it, one of the fun quirks of <a href="https://www.polygon.com/marvel/453203/agatha-all-along-darkhold-scarlet-witch-where-dead-body-who"><em>Agatha All Along</em></a> is putting a new spin on a certain <em>thing </em>in each episode. In this case, instead of a TV show format, it’s the song <a href="https://www.polygon.com/marvel/456912/agatha-all-along-witches-road-song-spoilers-clues-episode">“The Ballad of the Witches’ Road,”</a> which, for a bit there, was giving us approximately one new cover per episode. </p>

<p class="has-text-align-none">Since it 

## A new Ghibli-inspired open-world game is coming next month and it looks beautiful
 - [https://www.polygon.com/preview/468520/towers-aghasba-studio-ghibli](https://www.polygon.com/preview/468520/towers-aghasba-studio-ghibli)
 - RSS feed: $source
 - date published: 2024-10-23T08:00:00+00:00


											

						
<figure>

<img alt="" data-caption="" data-portal-copyright="" data-has-syndication-rights="1" src="https://platform.polygon.com/wp-content/uploads/sites/2/2024/10/Towers_Trailer_Screenshot_028.jpg?quality=90&#038;strip=all&#038;crop=0,0,100,100" />
	<figcaption></figcaption>
</figure>
<p class="has-text-align-none">If you’re a big fan of Studio Ghibli, or find yourself wishing you could dive into its worlds as you watch the films, you might want to check out the upcoming game <em>Towers of Aghasba</em>. Earlier this month, Polygon attended a remote preview where the devs showcased a prerecorded look at the game and talked about their inspiration.</p>

<p class="has-text-align-none">The open-world fantasy survival builder game is the first title from Dreamlit Games —&nbsp;with developers having previously worked on everything from <em>Hawken</em> to <em>Titanfall</em> and <em>Call of Duty 2</em>, not to mention films such as <em>Independence Day</em> and <em>Ready

## What time does Black Ops 6 release in your time zone?
 - [https://www.polygon.com/black-ops-6-guides/468014/release-time-date-est-pst-bst-bo6](https://www.polygon.com/black-ops-6-guides/468014/release-time-date-est-pst-bst-bo6)
 - RSS feed: $source
 - date published: 2024-10-23T00:01:00+00:00


											

						
<figure>

<img alt="A special forces soldier stands next to a pool and aims at the camera" data-caption="" data-portal-copyright="Image: Activision" data-has-syndication-rights="1" src="https://platform.polygon.com/wp-content/uploads/sites/2/2024/10/BO6-LAUNCH-WEEK-IMAGE-003.jpg?quality=90&#038;strip=all&#038;crop=0,0,100,100" />
	<figcaption></figcaption>
</figure>
<p class="has-text-align-none"><em><a href="https://www.polygon.com/game/call-of-duty-black-ops-6/443261">Black Ops 6</a></em> is the latest entry in the very long-running Black Ops wing of Activision’s Call of Duty series. Specializing more in alternate history and spy craft than other Call of Duty games, <em><a href="https://www.polygon.com/black-ops-6-guides">Black Ops 6</a></em> launches with a new campaign set during the height of the Gulf War. As usual, the game will offer a campaign, multiplayer, and a zombies mode.</p>

<p class="has-text-align-none">Here’s <strong>what time <em>Black Ops 6</em

