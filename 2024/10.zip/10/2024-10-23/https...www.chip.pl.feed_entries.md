# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Test Lenovo Yoga 9i 2-in-1 Gen 9 14 – kto tu odpowiada za wzornictwo?
 - [https://www.chip.pl/2024/10/test-lenovo-yoga-9i-2-in-1-recenzja-opinia](https://www.chip.pl/2024/10/test-lenovo-yoga-9i-2-in-1-recenzja-opinia)
 - RSS feed: $source
 - date published: 2024-10-23T14:00:00+00:00

<img width="2560" height="1707" src="https://konto.chip.pl/wp-content/uploads/2024/10/Lenovo-Yoga-9i-2-in-1-Gen-9-14-011.jpg" class="attachment-full size-full wp-post-image" alt="Lenovo Yoga 9i 2-in-1 Gen 9 14" style="margin-bottom:10px;" decoding="async" fetchpriority="high" srcset="https://konto.chip.pl/wp-content/uploads/2024/10/Lenovo-Yoga-9i-2-in-1-Gen-9-14-011.jpg 2560w, https://konto.chip.pl/wp-content/uploads/2024/10/Lenovo-Yoga-9i-2-in-1-Gen-9-14-011-1200x800.jpg 1200w, https://konto.chip.pl/wp-content/uploads/2024/10/Lenovo-Yoga-9i-2-in-1-Gen-9-14-011-1600x1067.jpg 1600w, https://konto.chip.pl/wp-content/uploads/2024/10/Lenovo-Yoga-9i-2-in-1-Gen-9-14-011-770x513.jpg 770w, https://konto.chip.pl/wp-content/uploads/2024/10/Lenovo-Yoga-9i-2-in-1-Gen-9-14-011-1536x1024.jpg 1536w, https://konto.chip.pl/wp-content/uploads/2024/10/Lenovo-Yoga-9i-2-in-1-Gen-9-14-011-2048x1366.jpg 2048w" sizes="(max-width: 2560px) 100vw, 2560px" /><p><img src="https://konto.chip.pl/wp-content/uploads/

## Mogłeś tam przynudzać o osiągnięciach zawodowych i szukać nowej pracy. Koniec popularnej społecznościówki
 - [https://www.chip.pl/2024/10/koniec-goldenline-agora-polski-linkedin](https://www.chip.pl/2024/10/koniec-goldenline-agora-polski-linkedin)
 - RSS feed: $source
 - date published: 2024-10-23T13:31:21+00:00

<img width="2560" height="1706" src="https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-scaled.jpg" class="attachment-full size-full wp-post-image" alt="" style="margin-bottom:10px;" decoding="async" srcset="https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-scaled.jpg 2560w, https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-1200x800.jpg 1200w, https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-1600x1067.jpg 1600w, https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-770x513.jpg 770w, https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-1536x1024.jpg 1536w, https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-2048x1365.jpg 2048w" sizes="(max-width: 2560px) 100vw, 2560px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/10/spolecznosciowki-scaled.jpg" style="display: block; margin: 1em auto"></p>
<p>Są miejsca w internecie, które doskonale odzwierciedlają nasze typowo ludzkie

## Najnowszy raport pokazuje, że Apple Intelligence jest dwa lata za ChatGPT
 - [https://www.chip.pl/2024/10/apple-intelligence-mozliwosci-dostepnosc-funkcje](https://www.chip.pl/2024/10/apple-intelligence-mozliwosci-dostepnosc-funkcje)
 - RSS feed: $source
 - date published: 2024-10-23T13:30:00+00:00

<img width="1532" height="1020" src="https://konto.chip.pl/wp-content/uploads/2024/07/apple-intelligence-nie-pojawi-sie-w-europie-2.jpg" class="attachment-full size-full wp-post-image" alt="Apple Intelligence" style="margin-bottom:10px;" decoding="async" srcset="https://konto.chip.pl/wp-content/uploads/2024/07/apple-intelligence-nie-pojawi-sie-w-europie-2.jpg 1532w, https://konto.chip.pl/wp-content/uploads/2024/07/apple-intelligence-nie-pojawi-sie-w-europie-2-1200x799.jpg 1200w, https://konto.chip.pl/wp-content/uploads/2024/07/apple-intelligence-nie-pojawi-sie-w-europie-2-770x513.jpg 770w" sizes="(max-width: 1532px) 100vw, 1532px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/07/apple-intelligence-nie-pojawi-sie-w-europie-2.jpg" style="display: block; margin: 1em auto"></p>
<p>Na kilka dni przed publicznym debiutem Apple Intelligence pojawia się raport, który sugeruje, że producent z Cupertino może mieć trochę do nadrobienia względem konkurencji. Różnice w możliwościach

## Lepsze telewizory i wydajniejsze panele słoneczne. Naukowcy przeszli samych siebie
 - [https://www.chip.pl/2024/10/rewolucja-nanokrysztaly-lepsze-telewizory-panele-sloneczne](https://www.chip.pl/2024/10/rewolucja-nanokrysztaly-lepsze-telewizory-panele-sloneczne)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:00+00:00

<img width="1280" height="853" src="https://konto.chip.pl/wp-content/uploads/2024/01/ai-generated-8486817_1280.png" class="attachment-full size-full wp-post-image" alt="" style="margin-bottom:10px;" decoding="async" loading="lazy" srcset="https://konto.chip.pl/wp-content/uploads/2024/01/ai-generated-8486817_1280.png 1280w, https://konto.chip.pl/wp-content/uploads/2024/01/ai-generated-8486817_1280-1200x800.png 1200w, https://konto.chip.pl/wp-content/uploads/2024/01/ai-generated-8486817_1280-770x513.png 770w" sizes="(max-width: 1280px) 100vw, 1280px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/01/ai-generated-8486817_1280.png" style="display: block; margin: 1em auto"></p>
<p>Co mają ze sobą wspólnego telewizory i panele słoneczne? Najnowsze dzieło naukowców z Curtin University właśnie nam o tym przypomniało, jako że upiekło przysłowiowe dwie pieczenie na jednym ogniu, potencjalnie rewolucjonizując zarówno telewizory, jak i panele słoneczne. Rewolucja nanokryształów, czy

## Uwaga! Hakerzy infekują tysiące witryn WordPress wtyczkami malware
 - [https://www.chip.pl/2024/10/wordpress-falszywe-wtyczki-infekuja-strony-www](https://www.chip.pl/2024/10/wordpress-falszywe-wtyczki-infekuja-strony-www)
 - RSS feed: $source
 - date published: 2024-10-23T12:00:00+00:00

<img width="684" height="450" src="https://konto.chip.pl/wp-content/uploads/2020/02/Svz0pfQr.png" class="attachment-full size-full wp-post-image" alt="" style="margin-bottom:10px;" decoding="async" fetchpriority="high" /><p><img src="https://konto.chip.pl/wp-content/uploads/2020/02/Svz0pfQr.png" style="display: block; margin: 1em auto"></p>
<p>WordPress to jedna z podstaw nowoczesnej sieci. Korzystają z niego miliony stron internetowych należących zarówno do osób prywatnych, jak też do wielkich korporacji. Niestety, wiedzą o tym hakerzy i oszuści, którzy przeprowadzili wymierzoną w niego kamapnię. Dostawca usług i hostingu internetowego GoDaddy informuje, że nowa infekcja szybko rozprzestrzenia się w implementacjach WordPressa. Powoduje uruchamianie spreparowanych [&#8230;]</p>


## Qualcomm ogłosił świetną nowość dla telefonów ze Snapdragon 8 Elite
 - [https://www.chip.pl/2024/10/qualcomm-snapdragon-8-elite](https://www.chip.pl/2024/10/qualcomm-snapdragon-8-elite)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:00+00:00

<img width="683" height="376" src="https://konto.chip.pl/wp-content/uploads/2024/10/Qualcomm.jpg" class="attachment-full size-full wp-post-image" alt="Qualcomm" style="margin-bottom:10px;" decoding="async" fetchpriority="high" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/10/Qualcomm.jpg" style="display: block; margin: 1em auto"></p>
<p>Zaledwie wczoraj Qualcomm ogłosił swój najnowszy układ mobilny Snapdragon 8 Elite, a już dzisiaj pojawia się informacja dla posiadaczy telefonów, które będą go używać. Przypomnę, że pojawi się on we flagowcach niemal wszystkich marek na rynku. Otóż dzięki temu procesorowi będzie możliwe wsparcie dla smartfonów aż przez 8 lat! Zazwyczaj flagowce mają swoje chipsety aktualizowane [&#8230;]</p>


## Huawei bierze rozwód z Androidem – oto HarmonyOS Next
 - [https://www.chip.pl/2024/10/harmonyos-next-premiera-nowosci](https://www.chip.pl/2024/10/harmonyos-next-premiera-nowosci)
 - RSS feed: $source
 - date published: 2024-10-23T10:30:00+00:00

<img width="1200" height="562" src="https://konto.chip.pl/wp-content/uploads/2024/10/harmonyos-next-premiera-nowosci-4.jpg" class="attachment-full size-full wp-post-image" alt="" style="margin-bottom:10px;" decoding="async" fetchpriority="high" srcset="https://konto.chip.pl/wp-content/uploads/2024/10/harmonyos-next-premiera-nowosci-4.jpg 1200w, https://konto.chip.pl/wp-content/uploads/2024/10/harmonyos-next-premiera-nowosci-4-770x361.jpg 770w" sizes="(max-width: 1200px) 100vw, 1200px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/10/harmonyos-next-premiera-nowosci-4.jpg" style="display: block; margin: 1em auto"></p>
<p>Kiedy USA nałożyło sankcje na Huawei, odcinając go m.in. od usług Google, firma zmuszona była opracować własne rozwiązania systemowe. W ten sposób powstało HarmonyOS. W ostatnich latach oprogramowanie było stale rozwijane, by wyewoluować w HarmonyOS Nex, rozwiązanie zbudowane całkowicie niezależnie nie tylko od Androida, ale też od Linuxa. To już piąta ge

## Trakcja i brak gumy gwarantowane. Na rowerowe opony WTB SG1 po prostu czekałeś
 - [https://www.chip.pl/2024/10/rowerowe-opony-wtb-sg1](https://www.chip.pl/2024/10/rowerowe-opony-wtb-sg1)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

<img width="1620" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/10/Trakcja-i-brak-gumy-gwarantowane.-Na-rowerowe-opony-WTB-SG1-po-prostu-czekales-1.jpg" class="attachment-full size-full wp-post-image" alt="" style="margin-bottom:10px;" decoding="async" srcset="https://konto.chip.pl/wp-content/uploads/2024/10/Trakcja-i-brak-gumy-gwarantowane.-Na-rowerowe-opony-WTB-SG1-po-prostu-czekales-1.jpg 1620w, https://konto.chip.pl/wp-content/uploads/2024/10/Trakcja-i-brak-gumy-gwarantowane.-Na-rowerowe-opony-WTB-SG1-po-prostu-czekales-1-1200x800.jpg 1200w, https://konto.chip.pl/wp-content/uploads/2024/10/Trakcja-i-brak-gumy-gwarantowane.-Na-rowerowe-opony-WTB-SG1-po-prostu-czekales-1-1600x1067.jpg 1600w, https://konto.chip.pl/wp-content/uploads/2024/10/Trakcja-i-brak-gumy-gwarantowane.-Na-rowerowe-opony-WTB-SG1-po-prostu-czekales-1-770x513.jpg 770w, https://konto.chip.pl/wp-content/uploads/2024/10/Trakcja-i-brak-gumy-gwarantowane.-Na-rowerowe-opony-WTB-SG1-po-prostu-czekales-1

## Oto najnowsza turecka broń. Yavuz strzela tak szybko, że zaleje wrogów pociskami
 - [https://www.chip.pl/2024/10/najnowsza-turecka-artyleria-yavuz](https://www.chip.pl/2024/10/najnowsza-turecka-artyleria-yavuz)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:00+00:00

<img width="1280" height="753" src="https://konto.chip.pl/wp-content/uploads/2022/06/Opisujemy-norweskie-samobiezne-haubice-M109A3GN-ktore-sluza-juz-Ukrainie-3.jpg" class="attachment-full size-full wp-post-image" alt="Amerykańska artyleria samobieżna" style="margin-bottom:10px;" decoding="async" fetchpriority="high" srcset="https://konto.chip.pl/wp-content/uploads/2022/06/Opisujemy-norweskie-samobiezne-haubice-M109A3GN-ktore-sluza-juz-Ukrainie-3.jpg 1280w, https://konto.chip.pl/wp-content/uploads/2022/06/Opisujemy-norweskie-samobiezne-haubice-M109A3GN-ktore-sluza-juz-Ukrainie-3-829x488.jpg 829w, https://konto.chip.pl/wp-content/uploads/2022/06/Opisujemy-norweskie-samobiezne-haubice-M109A3GN-ktore-sluza-juz-Ukrainie-3-352x207.jpg 352w, https://konto.chip.pl/wp-content/uploads/2022/06/Opisujemy-norweskie-samobiezne-haubice-M109A3GN-ktore-sluza-juz-Ukrainie-3-390x229.jpg 390w" sizes="(max-width: 1280px) 100vw, 1280px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/06/Opisuj

## Było źle, jest jeszcze gorzej. Windows 11 24H2 objawia kolejne defekty
 - [https://www.chip.pl/2024/10/windows-11-24h2-kolejne-problemy-z-aktualizacja](https://www.chip.pl/2024/10/windows-11-24h2-kolejne-problemy-z-aktualizacja)
 - RSS feed: $source
 - date published: 2024-10-23T08:00:00+00:00

<img width="2560" height="1707" src="https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-scaled.jpg" class="attachment-full size-full wp-post-image" alt="Windows 11 24H2 problemy" style="margin-bottom:10px;" decoding="async" fetchpriority="high" srcset="https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-scaled.jpg 2560w, https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-1200x800.jpg 1200w, https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-1600x1067.jpg 1600w, https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-770x513.jpg 770w, https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-1536x1024.jpg 1536w, https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-2048x1365.jpg 2048w" sizes="(max-width: 2560px) 100vw, 2560px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/10/Windows-11-24H2-problemy-scaled.jpg" style="display: b

## Ten izotop nie pochodzi z Ziemi. Stanowi pamiątkę po wyjątkowo energetycznych zjawiskach
 - [https://www.chip.pl/2024/10/izotop-zelazo-60-pierwiastek-uklad-sloneczny](https://www.chip.pl/2024/10/izotop-zelazo-60-pierwiastek-uklad-sloneczny)
 - RSS feed: $source
 - date published: 2024-10-23T07:00:00+00:00

<img width="2400" height="1100" src="https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny.jpeg" class="attachment-full size-full wp-post-image" alt="" style="margin-bottom:10px;" decoding="async" fetchpriority="high" srcset="https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny.jpeg 2400w, https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny-1200x550.jpeg 1200w, https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny-1600x733.jpeg 1600w, https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny-770x353.jpeg 770w, https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny-1536x704.jpeg 1536w, https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny-2048x939.jpeg 2048w" sizes="(max-width: 2400px) 100vw, 2400px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/09/uklad-sloneczny.jpeg" style="display: block; margin: 1em auto"></p>
<p>Pierwiastki mogą mieć różne liczby neutronów w jądrze, za sprawą których mówimy 

## Oczko w głowie amerykańskiego wojska skopiowane przez Chiny. Z-21 to coś więcej, niż byle helikopter
 - [https://www.chip.pl/2024/10/chiny-ciezki-helikopter-z-21](https://www.chip.pl/2024/10/chiny-ciezki-helikopter-z-21)
 - RSS feed: $source
 - date published: 2024-10-23T04:13:37+00:00

<img width="1920" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/05/Chiny-mysliwce-sterowane-sztuczna-inteligencja-2.jpg" class="attachment-full size-full wp-post-image" alt="" style="margin-bottom:10px;" decoding="async" fetchpriority="high" srcset="https://konto.chip.pl/wp-content/uploads/2024/05/Chiny-mysliwce-sterowane-sztuczna-inteligencja-2.jpg 1920w, https://konto.chip.pl/wp-content/uploads/2024/05/Chiny-mysliwce-sterowane-sztuczna-inteligencja-2-1200x675.jpg 1200w, https://konto.chip.pl/wp-content/uploads/2024/05/Chiny-mysliwce-sterowane-sztuczna-inteligencja-2-1600x900.jpg 1600w, https://konto.chip.pl/wp-content/uploads/2024/05/Chiny-mysliwce-sterowane-sztuczna-inteligencja-2-770x433.jpg 770w, https://konto.chip.pl/wp-content/uploads/2024/05/Chiny-mysliwce-sterowane-sztuczna-inteligencja-2-1536x864.jpg 1536w" sizes="(max-width: 1920px) 100vw, 1920px" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/05/Chiny-mysliwce-sterowane-sztuczna-inteligencj

