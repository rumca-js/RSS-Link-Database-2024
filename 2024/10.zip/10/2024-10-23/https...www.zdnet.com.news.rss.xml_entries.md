# Source:ZDNET, URL:https://www.zdnet.com/news/rss.xml, language:en-US

## iPhone users can try AT&T's mobile network for free for 30 days - here's how
 - [https://www.zdnet.com/home-and-office/networking/iphone-users-can-try-at-ts-mobile-network-for-free-for-30-days-heres-how/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/networking/iphone-users-can-try-at-ts-mobile-network-for-free-for-30-days-heres-how/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T13:52:48+00:00

Thinking of switching carriers? You can tap into AT&T's network without losing your existing carrier if you have an eSIM-compatible iPhone. But Android users aren't totally out of luck. Here's what to know.

## I replaced my Apple Watch Ultra with the 47mm Series 10 for a month, and it's surprisingly capable
 - [https://www.zdnet.com/article/i-replaced-my-apple-watch-ultra-with-the-47mm-series-10-for-a-month-and-its-surprisingly-capable/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-replaced-my-apple-watch-ultra-with-the-47mm-series-10-for-a-month-and-its-surprisingly-capable/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T13:51:00+00:00

The Apple Watch Series 10 sports a lighter, slimmer design that allows it to stand out among a sea of big, chunky watches. Ahead of Black Friday, you can buy one at a discount.

## How to subscribe to your favorite writers online: 4 easy ways
 - [https://www.zdnet.com/home-and-office/work-life/how-to-subscribe-to-your-favorite-writers-online-4-easy-ways/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/how-to-subscribe-to-your-favorite-writers-online-4-easy-ways/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T13:38:00+00:00

If you're looking to stay up-to-date with your favorite journalists, bloggers, and authors, here are a few tips to make that happen.

## Buy a Microsoft Visual Studio Pro license for $30 - the lowest price yet
 - [https://www.zdnet.com/article/buy-a-microsoft-visual-studio-pro-license-for-30-the-lowest-price-yet/#ftag=RSSbaffb68](https://www.zdnet.com/article/buy-a-microsoft-visual-studio-pro-license-for-30-the-lowest-price-yet/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T13:30:17+00:00

Code faster and work smarter with a Microsoft Visual Studio Professional 2022 license, now on sale for 93% off.

## This $399 Polar may be the best Apple Watch alternative for multi-sport athletes
 - [https://www.zdnet.com/article/this-399-polar-may-be-the-best-apple-watch-alternative-for-multi-sport-athletes/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-399-polar-may-be-the-best-apple-watch-alternative-for-multi-sport-athletes/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T13:30:00+00:00

The new Vantage M3 brings flagship performance and recovery tools to the masses with a form factor that appeals to that same group of people.

## Otter.ai's transcriptions are now available in more languages. Here's how to access them
 - [https://www.zdnet.com/article/otter-ais-transcriptions-are-now-available-in-more-languages-heres-how-to-access-them/#ftag=RSSbaffb68](https://www.zdnet.com/article/otter-ais-transcriptions-are-now-available-in-more-languages-heres-how-to-access-them/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:16+00:00

Your meeting transcriptions no longer have to be limited to English.

## Grab a Microsoft 365 license for just $40
 - [https://www.zdnet.com/article/grab-a-microsoft-365-license-for-just-40/#ftag=RSSbaffb68](https://www.zdnet.com/article/grab-a-microsoft-365-license-for-just-40/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T12:30:17+00:00

With this deal, you can access Office apps like Word, Excel, PowerPoint, and Outlook, along with 1TB of OneDrive cloud storage, for the lowest price we've seen.

## Buy a BJ's membership for $20, and get a $20 gift card. Here's how
 - [https://www.zdnet.com/home-and-office/buy-a-bjs-membership-for-20-and-get-a-20-gift-card-heres-how/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/buy-a-bjs-membership-for-20-and-get-a-20-gift-card-heres-how/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T11:30:17+00:00

Get an annual BJ's Wholesale Club membership for 63% off right now, and get a $20 gift card in return, to save on groceries, gas, household items, and more.

## The best battery life laptops of 2024: Expert tested and reviewed
 - [https://www.zdnet.com/article/best-battery-life-laptop/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-battery-life-laptop/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:18+00:00

We've gone hands on with dozens of the longest-lasting laptops from Microsoft, Dell, Asus, and more to rate their battery performance.

## This new Polar watch may be the best mid-range choice for multi-sport athletes
 - [https://www.zdnet.com/article/this-new-polar-watch-may-be-the-best-mid-range-choice-for-multi-sport-athletes/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-new-polar-watch-may-be-the-best-mid-range-choice-for-multi-sport-athletes/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:23+00:00

The new Vantage M3 brings flagship performance and recovery tools to the masses with a form factor that appeals to that same group of people.

## Solus 4.6 is a delightful-to-use Linux distro - with next to zero learning curve
 - [https://www.zdnet.com/article/solus-4-6-is-a-delightful-to-use-linux-distro-with-next-to-zero-learning-curve/#ftag=RSSbaffb68](https://www.zdnet.com/article/solus-4-6-is-a-delightful-to-use-linux-distro-with-next-to-zero-learning-curve/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T09:59:29+00:00

If you're looking for a Linux distribution to help ween yourself from Windows or MacOS, the latest release of Solus is a great option.

## How to use Android 15's App Freeze feature to clear space on your phone
 - [https://www.zdnet.com/article/how-to-use-android-15s-app-freeze-feature-to-clear-space-on-your-phone/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-use-android-15s-app-freeze-feature-to-clear-space-on-your-phone/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-23T08:57:23+00:00

Google has been slowly adding some fantastic features to Android. Version 15 adds a feature that helps you save space on your Pixel phone.

