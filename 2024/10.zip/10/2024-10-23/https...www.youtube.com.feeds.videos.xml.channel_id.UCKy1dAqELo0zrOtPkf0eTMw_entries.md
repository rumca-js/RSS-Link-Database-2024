# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## The Bornless - Official Halloween Playtest Trailer
 - [https://www.youtube.com/watch?v=oRGIItJwKTg](https://www.youtube.com/watch?v=oRGIItJwKTg)
 - RSS feed: $source
 - date published: 2024-10-23T13:01:04+00:00

Tour the creepy locations of The Bornless in this latest trailer for the free-to-play action horror FPS game. A closed playtest weekend for The Bornless will be available on Steam from October 26 to October 27, 2024.

#IGN #Gaming

## No Man's Sky: The Cursed Expedition - Official Trailer
 - [https://www.youtube.com/watch?v=h_ZnVrQooIs](https://www.youtube.com/watch?v=h_ZnVrQooIs)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:53+00:00

Fight to keep a grip on reality in No Man's Sky: The Cursed, the action-adventure survival game's creepy new update. Prepare to be haunted by visions and voices from another dimension in the 16th No Man's Sky Expedition. Watch the new No Man's Sky trailer for a look at the No Man's Sky: The Cursed Expedition, launching today and running for approximately three weeks.

It's up to you to protect yourself from the weakening of the boundaries of reality, using a specialised Anomaly Suppressor. Come face to face with spectral beings and plan your interstellar travel carefully by using the ancient portal network. Play the latest No Man's Sky expedition to collect exclusive rewards such as the Boundary Herald Starship, Cthulhu-inspired Horror Exosuit customisation, and bioluminescent pets.

#NoMansSky #Gaming #Games

## Inayah: Life After Gods - Official Inayah Character Spotlight Trailer
 - [https://www.youtube.com/watch?v=EXZp0Vl1mEM](https://www.youtube.com/watch?v=EXZp0Vl1mEM)
 - RSS feed: $source
 - date published: 2024-10-23T13:00:16+00:00

Meet Inayah and learn about the character's past and abilities in this Inayah: Life After Gods trailer for the upcoming 2D action-platformer game. Inayah: Life After Gods will be available on PC, PS4, PS5, Xbox One, Xbox Series X/S, and Nintendo Switch in 2025.

#IGN #Gaming

## A Day in the Life of a Royal Navy Esports Captain
 - [https://www.youtube.com/watch?v=mgO7kHRJZ7k](https://www.youtube.com/watch?v=mgO7kHRJZ7k)
 - RSS feed: $source
 - date published: 2024-10-23T11:39:16+00:00

Meet David, a leading air engineer technician at Royal Navy Air Station Culdrose, and captain of the Royal Navy’s F1 esports team. What’s it like to be part of a military squadron and a gaming squad? We spent the day with David to find out. Sponsored by Royal Navy.

Interested in a career in the Royal Navy? Use the role finder at royalnavy.mod.uk/careers/find-a-role for more information.

#Esports #Gaming #IGN

## These Kong moments are fun but aren’t enough…
 - [https://www.youtube.com/watch?v=h0_nNxiKA5w](https://www.youtube.com/watch?v=h0_nNxiKA5w)
 - RSS feed: $source
 - date published: 2024-10-23T00:54:34+00:00

None

## The hardest Elden Ring challenge yet?
 - [https://www.youtube.com/watch?v=Zpg4o4mpzwg](https://www.youtube.com/watch?v=Zpg4o4mpzwg)
 - RSS feed: $source
 - date published: 2024-10-23T00:51:54+00:00

None

## Ke Huy Quan reunites with a Goonies co-star in his new movie!
 - [https://www.youtube.com/watch?v=5v4M90qVLYk](https://www.youtube.com/watch?v=5v4M90qVLYk)
 - RSS feed: $source
 - date published: 2024-10-23T00:50:24+00:00

None

## Skull and Bones - Official Halloween Event Trailer
 - [https://www.youtube.com/watch?v=Ow8RUG-Qqyc](https://www.youtube.com/watch?v=Ow8RUG-Qqyc)
 - RSS feed: $source
 - date published: 2024-10-23T00:00:12+00:00

Take to the seas in Skull and Bones' Requiem of the Lost Halloween event. Watch the latest Skull and Bones trailer to see what to expect with the Requiem of the Lost Halloween event, available from today (October 22) to November 18, 2024. 

The boundary between the living and the dead has thinned, and vengeful spirits, known as The Lost, now roam the treacherous seas of the Indian Ocean. These wandering souls, believed to be the remnants of countless seafarers lost in battle, seek to bring chaos and destruction. But beware, their leader, the Reaper of the Lost, awaits those who dare to challenge the dead. 

Will you conquer these spirits or become one of them?

