# Source:RP - Cyfrowa, URL:https://cyfrowa.rp.pl/rss/2991-cyfrowa, language:pl-PL

## Koniec ze śledzeniem celebrytów. W ślady Elona Muska poszedł Mark Zuckerberg
 - [https://cyfrowa.rp.pl/globalne-interesy/art41338421-koniec-ze-sledzeniem-celebrytow-w-slady-elona-muska-poszedl-mark-zuckerberg](https://cyfrowa.rp.pl/globalne-interesy/art41338421-koniec-ze-sledzeniem-celebrytow-w-slady-elona-muska-poszedl-mark-zuckerberg)
 - RSS feed: $source
 - date published: 2024-10-23T10:40:22.575915+00:00

Meta zawiesiła konto ElonJet, które pozwalało na bieżąco monitorować loty prywatnego samolotu Elona Muska. Kilka lat temu głośno było o wyrzuceniu tego profilu z Twittera. To jednak tylko wierzchołek góry lodowej.

