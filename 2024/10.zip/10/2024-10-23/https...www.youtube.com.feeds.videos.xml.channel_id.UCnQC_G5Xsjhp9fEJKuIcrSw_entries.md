# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## One of the dumbest takes I've heard in a while
 - [https://www.youtube.com/watch?v=5e_Le_p4iG8](https://www.youtube.com/watch?v=5e_Le_p4iG8)
 - RSS feed: $source
 - date published: 2024-10-23T03:00:05+00:00

#BenShapiro #palestine  #comedian

## It's a good thing, according to Mark Cuban...
 - [https://www.youtube.com/watch?v=EY9TxIkJaTE](https://www.youtube.com/watch?v=EY9TxIkJaTE)
 - RSS feed: $source
 - date published: 2024-10-23T01:00:09+00:00

#BenShapiro #markcuban  #kamalaharris  #flipflop

