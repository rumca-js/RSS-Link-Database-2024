# Source:Wired, URL:https://www.wired.com/feed/rss, language:en-US

## How to Fly With a Personal Item—Plus Our 3 Favorite Small Bags (2024)
 - [https://www.wired.com/story/how-to-fly-with-a-personal-item](https://www.wired.com/story/how-to-fly-with-a-personal-item)
 - RSS feed: $source
 - date published: 2024-10-23T13:07:00+00:00

Maximize your travel enjoyment while minimizing your stuff by flying with only one small bag.

## Nintendo Alarmo Review: Nagging Nostalgia
 - [https://www.wired.com/review/nintendo-alarmo](https://www.wired.com/review/nintendo-alarmo)
 - RSS feed: $source
 - date published: 2024-10-23T12:30:00+00:00

Nintendo's alarm clock does less than we want it to for more than we want to pay. You might want to buy one anyway.

## Tiger Siphonysta Review: Fun Yet Flawed Coffee Brewer
 - [https://www.wired.com/review/tiger-siphonysta](https://www.wired.com/review/tiger-siphonysta)
 - RSS feed: $source
 - date published: 2024-10-23T12:09:00+00:00

The niche coffee maker brews a great cup of coffee. But at this price, parts of the machine should be better quality.

## Using Artificial Intelligence Is Easier Than You Think
 - [https://www.wired.com/story/artificial-intelligence-tools-ai-unlocked-newsletter-season-two](https://www.wired.com/story/artificial-intelligence-tools-ai-unlocked-newsletter-season-two)
 - RSS feed: $source
 - date published: 2024-10-23T11:30:00+00:00

WIRED’s AI Unlocked newsletter about using chatbots and other generative AI tools is back for a second season. We’ve incorporated reader feedback and answered your burning questions.

## Loop Switch 2 Review: Volume-Adjustable Earplugs
 - [https://www.wired.com/review/loop-switch-2](https://www.wired.com/review/loop-switch-2)
 - RSS feed: $source
 - date published: 2024-10-23T11:00:00+00:00

These earplugs let you fine-tune your noise reduction—within reason.

## Online Talk About ‘Civil War’ Could Inspire Real-World Violence, DHS Warns Cops
 - [https://www.wired.com/story/extremists-civil-war-dhs](https://www.wired.com/story/extremists-civil-war-dhs)
 - RSS feed: $source
 - date published: 2024-10-23T10:30:00+00:00

The agency also cautioned that it’s unable to get a grasp on the full scale of the threat, due to extremists increasingly using encrypted chat tools.

## Meta Quest 3S Review: The Best Headset for VR Noobs
 - [https://www.wired.com/review/meta-quest-3s](https://www.wired.com/review/meta-quest-3s)
 - RSS feed: $source
 - date published: 2024-10-23T10:00:00+00:00

Meta’s most affordable VR headset is cheap, light, and easy to use. Just don’t expect to wear it too long, as the battery life isn't great.

## AT&T and T-Mobile Claim Locked Phones Are Good, Actually
 - [https://www.wired.com/story/att-tmobile-claim-locked-phones-are-good-actually](https://www.wired.com/story/att-tmobile-claim-locked-phones-are-good-actually)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:00+00:00

Mobile carriers argue that locking devices helps them lower costs. Consumer protection groups see it a little differently.

## Here’s What the Sustainable Cities of Tomorrow Could Look Like
 - [https://www.wired.com/story/heres-what-the-sustainable-cities-of-tomorrow-could-look-like](https://www.wired.com/story/heres-what-the-sustainable-cities-of-tomorrow-could-look-like)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:00+00:00

Around the world, seeds of regenerative cities have already been planted. As they grow, they will shape the metropolises of tomorrow.

## Squarespace Promo Codes - 10% Off in October 2024
 - [https://www.wired.com/story/squarespace-promo-code](https://www.wired.com/story/squarespace-promo-code)
 - RSS feed: $source
 - date published: 2024-10-23T06:00:00+00:00

Get 10% off a website or domain, on any plan, with this exclusive Squarespace promo code from WIRED. Save on your next big project this October.

