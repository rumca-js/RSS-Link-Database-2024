# Source:Reddit - World News, URL:https://www.reddit.com/r/worldnews/.rss, language:en

## McDonald's shares tumble after burger kills one and leaves dozens sick
 - [https://www.reddit.com/r/worldnews/comments/1gaa447/mcdonalds_shares_tumble_after_burger_kills_one](https://www.reddit.com/r/worldnews/comments/1gaa447/mcdonalds_shares_tumble_after_burger_kills_one)
 - RSS feed: $source
 - date published: 2024-10-23T13:07:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1gaa447/mcdonalds_shares_tumble_after_burger_kills_one/"> <img src="https://external-preview.redd.it/b4TuETaxFuUK5vKXqcjqwBeVe94agbuxWNWIVURq4fo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=85374625ea6a3e2823394d05c71d179ff0f941d5" alt="McDonald's shares tumble after burger kills one and leaves dozens sick " title="McDonald's shares tumble after burger kills one and leaves dozens sick " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dailymail"> /u/dailymail </a> <br/> <span><a href="https://www.dailymail.co.uk/news/article-13991887/mcdonalds-shares-ecoli-outbreak-us.html?ito=social-reddit">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1gaa447/mcdonalds_shares_tumble_after_burger_kills_one/">[comments]</a></span> </td></tr></table>

## Russian GRU behind arsons in Wrocław, confirms Polish Foreign Ministry
 - [https://www.reddit.com/r/worldnews/comments/1ga8xu1/russian_gru_behind_arsons_in_wrocław_confirms](https://www.reddit.com/r/worldnews/comments/1ga8xu1/russian_gru_behind_arsons_in_wrocław_confirms)
 - RSS feed: $source
 - date published: 2024-10-23T12:08:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga8xu1/russian_gru_behind_arsons_in_wrocław_confirms/"> <img src="https://external-preview.redd.it/EPXp5BE4q8IeNa79IO3iBuHGK-sy0xGTEAAIGtwITqs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=587e578c92d40d3ac3c70ec20c918b9ac349063a" alt="Russian GRU behind arsons in Wrocław, confirms Polish Foreign Ministry" title="Russian GRU behind arsons in Wrocław, confirms Polish Foreign Ministry" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BubsyFanboy"> /u/BubsyFanboy </a> <br/> <span><a href="https://www.polskieradio.pl/395/7784/Artykul/3438168,russian-gru-behind-arsons-in-wroclaw-confirms-polish-foreign-ministry">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga8xu1/russian_gru_behind_arsons_in_wrocław_confirms/">[comments]</a></span> </td></tr></table>

## North Korean troops are already in Russia, Lloyd Austin confirms
 - [https://www.reddit.com/r/worldnews/comments/1ga8xrl/north_korean_troops_are_already_in_russia_lloyd](https://www.reddit.com/r/worldnews/comments/1ga8xrl/north_korean_troops_are_already_in_russia_lloyd)
 - RSS feed: $source
 - date published: 2024-10-23T12:08:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga8xrl/north_korean_troops_are_already_in_russia_lloyd/"> <img src="https://external-preview.redd.it/dSIDcl09EkbHdhcqvvQuFcQaP9dQgFh9utOtymdnoZc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=132b4fa5ecb94e3892acdf3854037fa6a9b48789" alt="North Korean troops are already in Russia, Lloyd Austin confirms" title="North Korean troops are already in Russia, Lloyd Austin confirms" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/M795"> /u/M795 </a> <br/> <span><a href="https://abcnews.go.com/International/north-korean-troops-russia-lloyd-austin-confirms/story?id=115057351">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga8xrl/north_korean_troops_are_already_in_russia_lloyd/">[comments]</a></span> </td></tr></table>

## North Korea has sent troops to Russia, U.S. confirms
 - [https://www.reddit.com/r/worldnews/comments/1ga8dxt/north_korea_has_sent_troops_to_russia_us_confirms](https://www.reddit.com/r/worldnews/comments/1ga8dxt/north_korea_has_sent_troops_to_russia_us_confirms)
 - RSS feed: $source
 - date published: 2024-10-23T11:40:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga8dxt/north_korea_has_sent_troops_to_russia_us_confirms/"> <img src="https://external-preview.redd.it/CZO8WiNkrHAHuCFhm5DqILRrVpQNUD7I69n9AQria64.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=79817600d8d32d7eb635caf509dff8fc8563e51e" alt="North Korea has sent troops to Russia, U.S. confirms" title="North Korea has sent troops to Russia, U.S. confirms" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ObjectiveAd6551"> /u/ObjectiveAd6551 </a> <br/> <span><a href="https://www.nbcnews.com/news/world/north-korean-troops-sent-russia-us-confirms-war-ukraine-rcna176346">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga8dxt/north_korea_has_sent_troops_to_russia_us_confirms/">[comments]</a></span> </td></tr></table>

## Israel kills three Hezbollah commanders, some 70 fighters in 48 hours: Destroyed in the attack were the base's headquarters, ammunition depots, underground infrastructure, fast vessels, and other assets
 - [https://www.reddit.com/r/worldnews/comments/1ga7twg/israel_kills_three_hezbollah_commanders_some_70](https://www.reddit.com/r/worldnews/comments/1ga7twg/israel_kills_three_hezbollah_commanders_some_70)
 - RSS feed: $source
 - date published: 2024-10-23T11:07:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga7twg/israel_kills_three_hezbollah_commanders_some_70/"> <img src="https://external-preview.redd.it/lSRzj-nUtz8ysa34aXu00HOX1K9wcy3lNaxhdokFg1E.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=3b73f119042e934551c0a2189f50ce897d3f9a77" alt="Israel kills three Hezbollah commanders, some 70 fighters in 48 hours: Destroyed in the attack were the base's headquarters, ammunition depots, underground infrastructure, fast vessels, and other assets" title="Israel kills three Hezbollah commanders, some 70 fighters in 48 hours: Destroyed in the attack were the base's headquarters, ammunition depots, underground infrastructure, fast vessels, and other assets" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/larki18"> /u/larki18 </a> <br/> <span><a href="https://www.business-standard.com/world-news/israel-strikes-hezbollah-s-main-naval-base-in-beirut-confirms-idf-124102300073_1.html">[link]</a></s

## North Korea is sending thousands of soldiers to help Vladimir Putin
 - [https://www.reddit.com/r/worldnews/comments/1ga5zbk/north_korea_is_sending_thousands_of_soldiers_to](https://www.reddit.com/r/worldnews/comments/1ga5zbk/north_korea_is_sending_thousands_of_soldiers_to)
 - RSS feed: $source
 - date published: 2024-10-23T09:00:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga5zbk/north_korea_is_sending_thousands_of_soldiers_to/"> <img src="https://external-preview.redd.it/lDZh4W_YodbCfMizosYF-q9CQBcsYIB06VZ2TMlRy38.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9bfaff51fcd741234ce3a12b46ac1dc8906b9d46" alt="North Korea is sending thousands of soldiers to help Vladimir Putin" title="North Korea is sending thousands of soldiers to help Vladimir Putin" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/KadmonX"> /u/KadmonX </a> <br/> <span><a href="https://www.economist.com/europe/2024/10/22/north-korea-is-sending-thousands-of-soldiers-to-help-vladimir-putin">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga5zbk/north_korea_is_sending_thousands_of_soldiers_to/">[comments]</a></span> </td></tr></table>

## Chinese blockade would be act of war, Taiwan says
 - [https://www.reddit.com/r/worldnews/comments/1ga5p2g/chinese_blockade_would_be_act_of_war_taiwan_says](https://www.reddit.com/r/worldnews/comments/1ga5p2g/chinese_blockade_would_be_act_of_war_taiwan_says)
 - RSS feed: $source
 - date published: 2024-10-23T08:38:24+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/OkMap12"> /u/OkMap12 </a> <br/> <span><a href="https://www.reuters.com/world/asia-pacific/taiwan-says-chinese-aircraft-carrier-group-sailed-through-taiwan-strait-2024-10-22/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga5p2g/chinese_blockade_would_be_act_of_war_taiwan_says/">[comments]</a></span>

## Israel says it killed Hezbollah official who was set to be group’s next leader
 - [https://www.reddit.com/r/worldnews/comments/1ga5f5z/israel_says_it_killed_hezbollah_official_who_was](https://www.reddit.com/r/worldnews/comments/1ga5f5z/israel_says_it_killed_hezbollah_official_who_was)
 - RSS feed: $source
 - date published: 2024-10-23T08:16:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga5f5z/israel_says_it_killed_hezbollah_official_who_was/"> <img src="https://external-preview.redd.it/HG3PCl1xCgxAHZWw3UjocCTSqYk3UNQFTbby4VTsrz4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1bbd6d2693cbe71ce1ddc8f0444ca8b00662549a" alt="Israel says it killed Hezbollah official who was set to be group’s next leader" title="Israel says it killed Hezbollah official who was set to be group’s next leader" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nbcnews"> /u/nbcnews </a> <br/> <span><a href="https://www.nbcnews.com/news/world/israel-says-killed-hezbollah-official-was-set-groups-leader-rcna176723">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga5f5z/israel_says_it_killed_hezbollah_official_who_was/">[comments]</a></span> </td></tr></table>

## Putin lacks support as only 14 percent of Russians back his foreign policy
 - [https://www.reddit.com/r/worldnews/comments/1ga4unu/putin_lacks_support_as_only_14_percent_of](https://www.reddit.com/r/worldnews/comments/1ga4unu/putin_lacks_support_as_only_14_percent_of)
 - RSS feed: $source
 - date published: 2024-10-23T07:38:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga4unu/putin_lacks_support_as_only_14_percent_of/"> <img src="https://external-preview.redd.it/d1EzEUhDl2cbFLJeDCWwnZouk8-owjQOPQDPgREcX-s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=99f5fef5767c8a12ccf99eb59d68230190791db8" alt="Putin lacks support as only 14 percent of Russians back his foreign policy" title="Putin lacks support as only 14 percent of Russians back his foreign policy" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tomorrow509"> /u/tomorrow509 </a> <br/> <span><a href="https://www.newsweek.com/russia-putin-ukraine-war-1972857">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga4unu/putin_lacks_support_as_only_14_percent_of/">[comments]</a></span> </td></tr></table>

## Chinese mercenary claims eight N. Korean officers killed on first day in Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1ga4jkc/chinese_mercenary_claims_eight_n_korean_officers](https://www.reddit.com/r/worldnews/comments/1ga4jkc/chinese_mercenary_claims_eight_n_korean_officers)
 - RSS feed: $source
 - date published: 2024-10-23T07:15:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga4jkc/chinese_mercenary_claims_eight_n_korean_officers/"> <img src="https://external-preview.redd.it/bVNAhcwwcQI5a5WIZ0i1nEiSlFwBjHP9yuwAXxn0RYY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=466f8bf0c6a25856ba14169e76e0574b083cab08" alt="Chinese mercenary claims eight N. Korean officers killed on first day in Ukraine" title="Chinese mercenary claims eight N. Korean officers killed on first day in Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/KrzyHooy"> /u/KrzyHooy </a> <br/> <span><a href="https://tvpworld.com/83102764/chinese-mercenary-claims-eight-n-korean-officers-killed-on-first-day-in-ukraine">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga4jkc/chinese_mercenary_claims_eight_n_korean_officers/">[comments]</a></span> </td></tr></table>

## Israel says it killed Hezbollah official expected to be group's next leader
 - [https://www.reddit.com/r/worldnews/comments/1ga1qj3/israel_says_it_killed_hezbollah_official_expected](https://www.reddit.com/r/worldnews/comments/1ga1qj3/israel_says_it_killed_hezbollah_official_expected)
 - RSS feed: $source
 - date published: 2024-10-23T04:08:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga1qj3/israel_says_it_killed_hezbollah_official_expected/"> <img src="https://external-preview.redd.it/Dx_MRlLH-D4am-drufo2JS2hkc9_ejDlyN4CDh7L7N0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cc233115669522d97186c5aad1d781b2c0e463fc" alt="Israel says it killed Hezbollah official expected to be group's next leader" title="Israel says it killed Hezbollah official expected to be group's next leader" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BobbyLucero"> /u/BobbyLucero </a> <br/> <span><a href="https://apnews.com/article/israel-palestinians-hamas-war-lebanon-hezbollah-news-10-22-2024-5a8d5a051e05267007192ac5c8d80efd">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga1qj3/israel_says_it_killed_hezbollah_official_expected/">[comments]</a></span> </td></tr></table>

## South Korea warns it can send arms to Ukraine after reports of North’s troops in Russia
 - [https://www.reddit.com/r/worldnews/comments/1ga1p7v/south_korea_warns_it_can_send_arms_to_ukraine](https://www.reddit.com/r/worldnews/comments/1ga1p7v/south_korea_warns_it_can_send_arms_to_ukraine)
 - RSS feed: $source
 - date published: 2024-10-23T04:07:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga1p7v/south_korea_warns_it_can_send_arms_to_ukraine/"> <img src="https://external-preview.redd.it/osPJ47Zh7Fj-DqXgauLQF89WVVPmqWWWtSbv2BOJC6Q.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a4dc30bdb8c439e2a196cf8e262c779499e452d1" alt="South Korea warns it can send arms to Ukraine after reports of North’s troops in Russia" title="South Korea warns it can send arms to Ukraine after reports of North’s troops in Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/eaglemaxie"> /u/eaglemaxie </a> <br/> <span><a href="https://apnews.com/article/north-korea-south-russia-troops-ukraine-3bf74624cfa6856edd4f15fb3992bfa0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga1p7v/south_korea_warns_it_can_send_arms_to_ukraine/">[comments]</a></span> </td></tr></table>

## /r/WorldNews Live Thread: Russian Invasion of Ukraine Day 972, Part 1 (Thread #1119)
 - [https://www.reddit.com/r/worldnews/comments/1ga1me8/rworldnews_live_thread_russian_invasion_of](https://www.reddit.com/r/worldnews/comments/1ga1me8/rworldnews_live_thread_russian_invasion_of)
 - RSS feed: $source
 - date published: 2024-10-23T04:02:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga1me8/rworldnews_live_thread_russian_invasion_of/"> <img src="https://a.thumbs.redditmedia.com/jWqSTFxxKuo9aDK8JeM4yZL4Nb_RTA85H45u1-h63L8.jpg" alt="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 972, Part 1 (Thread #1119)" title="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 972, Part 1 (Thread #1119)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WorldNewsMods"> /u/WorldNewsMods </a> <br/> <span><a href="https://www.reddit.com/live/18hnzysb1elcs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga1me8/rworldnews_live_thread_russian_invasion_of/">[comments]</a></span> </td></tr></table>

## Iran complains to UN watchdog, alleging Israeli threats to hit its nuclear sites
 - [https://www.reddit.com/r/worldnews/comments/1ga1f1j/iran_complains_to_un_watchdog_alleging_israeli](https://www.reddit.com/r/worldnews/comments/1ga1f1j/iran_complains_to_un_watchdog_alleging_israeli)
 - RSS feed: $source
 - date published: 2024-10-23T03:51:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1ga1f1j/iran_complains_to_un_watchdog_alleging_israeli/"> <img src="https://external-preview.redd.it/eukAIVBN56yJm8Gl6QfEmA589gGhktO5BsxnLhcbD6g.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cf8d47dde3c2fcfb869fda86d57dd0029c7a0332" alt="Iran complains to UN watchdog, alleging Israeli threats to hit its nuclear sites" title="Iran complains to UN watchdog, alleging Israeli threats to hit its nuclear sites" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Saltedline"> /u/Saltedline </a> <br/> <span><a href="https://www.timesofisrael.com/iran-complains-to-un-watchdog-alleging-israeli-threats-to-hit-its-nuclear-sites/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1ga1f1j/iran_complains_to_un_watchdog_alleging_israeli/">[comments]</a></span> </td></tr></table>

## South Korea threatens to send arms, personnel to Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1g9zux7/south_korea_threatens_to_send_arms_personnel_to](https://www.reddit.com/r/worldnews/comments/1g9zux7/south_korea_threatens_to_send_arms_personnel_to)
 - RSS feed: $source
 - date published: 2024-10-23T02:25:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g9zux7/south_korea_threatens_to_send_arms_personnel_to/"> <img src="https://external-preview.redd.it/ZKCKCSbUcavZ5cQPukpys3miUeJtYlkjFY9sDw-23U4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e4f36766adfe815f99f14e395d9049b2c70745f0" alt="South Korea threatens to send arms, personnel to Ukraine" title="South Korea threatens to send arms, personnel to Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IrreverentSunny"> /u/IrreverentSunny </a> <br/> <span><a href="https://www.voanews.com/a/south-korea-threatens-to-send-arms-personnel-to-ukraine/7832347.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g9zux7/south_korea_threatens_to_send_arms_personnel_to/">[comments]</a></span> </td></tr></table>

## Finland's largest energy company files €800 million lawsuit against Russia
 - [https://www.reddit.com/r/worldnews/comments/1g9yn0e/finlands_largest_energy_company_files_800_million](https://www.reddit.com/r/worldnews/comments/1g9yn0e/finlands_largest_energy_company_files_800_million)
 - RSS feed: $source
 - date published: 2024-10-23T01:23:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g9yn0e/finlands_largest_energy_company_files_800_million/"> <img src="https://external-preview.redd.it/bbSVdXr5U4zx1LOtzVeGBLRedzyAs0f5nj_f4P7v3Vg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=103beea5162cea4603ddac900848f6a8e6b54331" alt="Finland's largest energy company files €800 million lawsuit against Russia" title="Finland's largest energy company files €800 million lawsuit against Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/10/22/7480891/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g9yn0e/finlands_largest_energy_company_files_800_million/">[comments]</a></span> </td></tr></table>

## Russia detains 18 North Korean soldiers who left positions in Kursk Oblast, source says
 - [https://www.reddit.com/r/worldnews/comments/1g9yblr/russia_detains_18_north_korean_soldiers_who_left](https://www.reddit.com/r/worldnews/comments/1g9yblr/russia_detains_18_north_korean_soldiers_who_left)
 - RSS feed: $source
 - date published: 2024-10-23T01:07:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g9yblr/russia_detains_18_north_korean_soldiers_who_left/"> <img src="https://external-preview.redd.it/lR4yNWDsLU-bg3ANv-mR5R-aa-i7zI8gQVQv5vo8ABQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=850bc2aa2c6e06881c6a42be35208b9b79bafc47" alt="Russia detains 18 North Korean soldiers who left positions in Kursk Oblast, source says" title="Russia detains 18 North Korean soldiers who left positions in Kursk Oblast, source says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ethereal3xp"> /u/ethereal3xp </a> <br/> <span><a href="https://kyivindependent.com/18-north-korean-soldier-detained/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g9yblr/russia_detains_18_north_korean_soldiers_who_left/">[comments]</a></span> </td></tr></table>

## Zelenskyy asks allies to act on reports of North Korean troops helping Russia
 - [https://www.reddit.com/r/worldnews/comments/1g9y2z4/zelenskyy_asks_allies_to_act_on_reports_of_north](https://www.reddit.com/r/worldnews/comments/1g9y2z4/zelenskyy_asks_allies_to_act_on_reports_of_north)
 - RSS feed: $source
 - date published: 2024-10-23T00:55:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g9y2z4/zelenskyy_asks_allies_to_act_on_reports_of_north/"> <img src="https://external-preview.redd.it/7gQWk-vfjys6LsSMYYhUWFhTLlRQC9hLdi2A5GWHRW0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f1aa18fe9e5bc73328b3b2280a56dc185a6ac0e6" alt="Zelenskyy asks allies to act on reports of North Korean troops helping Russia" title="Zelenskyy asks allies to act on reports of North Korean troops helping Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BothZookeepergame612"> /u/BothZookeepergame612 </a> <br/> <span><a href="https://www.politico.eu/article/volodymyr-zelenskyy-allies-north-korean-troops/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g9y2z4/zelenskyy_asks_allies_to_act_on_reports_of_north/">[comments]</a></span> </td></tr></table>

## Tim Walz is the victim of a disturbing deepfake campaign & Russia is likely behind it
 - [https://www.reddit.com/r/worldnews/comments/1g9xwsk/tim_walz_is_the_victim_of_a_disturbing_deepfake](https://www.reddit.com/r/worldnews/comments/1g9xwsk/tim_walz_is_the_victim_of_a_disturbing_deepfake)
 - RSS feed: $source
 - date published: 2024-10-23T00:47:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g9xwsk/tim_walz_is_the_victim_of_a_disturbing_deepfake/"> <img src="https://external-preview.redd.it/U3A77ZnEznWWo3SCWrvgSMUNzgLkdGvkyLzElWXnyHI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c5cf57a5324551956c9fa494fee7b17ef362c147" alt="Tim Walz is the victim of a disturbing deepfake campaign &amp; Russia is likely behind it" title="Tim Walz is the victim of a disturbing deepfake campaign &amp; Russia is likely behind it" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/etfvfva"> /u/etfvfva </a> <br/> <span><a href="https://www.lgbtqnation.com/2024/10/tim-walz-is-the-victim-of-a-disturbing-deepfake-campaign-russia-is-likely-behind-it/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g9xwsk/tim_walz_is_the_victim_of_a_disturbing_deepfake/">[comments]</a></span> </td></tr></table>

