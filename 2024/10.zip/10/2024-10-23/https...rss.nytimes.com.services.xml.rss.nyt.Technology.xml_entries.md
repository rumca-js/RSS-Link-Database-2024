# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Binance Employee, in Custody for 8 Months in Nigeria, Will Be Released
 - [https://www.nytimes.com/2024/10/23/business/nigeria-binance-cryptocurrency-money-laundering.html](https://www.nytimes.com/2024/10/23/business/nigeria-binance-cryptocurrency-money-laundering.html)
 - RSS feed: $source
 - date published: 2024-10-23T12:36:38+00:00

Prosecutors have dropped the criminal case against Tigran Gambaryan so he can receive medical care, a government spokesman said.

## As Election Looms, Disinformation ‘Has Never Been Worse’
 - [https://www.nytimes.com/2024/10/23/business/media/election-disinformation.html](https://www.nytimes.com/2024/10/23/business/media/election-disinformation.html)
 - RSS feed: $source
 - date published: 2024-10-23T09:10:06+00:00

A torrent of falsehoods, from home and abroad, have undermined what was once a shared faith in the honesty of America’s democracy.

## How to Use Images From Your Phone to Search the Web
 - [https://www.nytimes.com/2024/10/23/technology/personaltech/phone-web-search-images.html](https://www.nytimes.com/2024/10/23/technology/personaltech/phone-web-search-images.html)
 - RSS feed: $source
 - date published: 2024-10-23T09:06:38+00:00

If you’re not sure how to describe what you want with keywords, use your camera or photo library to get those search results.

