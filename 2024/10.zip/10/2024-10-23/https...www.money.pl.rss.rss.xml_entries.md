# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Do 2150 zł na seniora. Skorzysta nawet 300 tys. osób
 - [https://www.money.pl/gospodarka/do-2150-zl-na-seniora-skorzysta-nawet-300-tys-osob-7084777044568672a.html](https://www.money.pl/gospodarka/do-2150-zl-na-seniora-skorzysta-nawet-300-tys-osob-7084777044568672a.html)
 - RSS feed: $source
 - date published: 2024-10-23T11:40:52.480860+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f28e893f-cd5b-4a06-9325-4f2caeabdaad" width="308" /> Minister ds. polityki senioralnej Marzena Okła-Drewnowicz oszacowała w środę w Lublinie, że ok. 300 tys. osób może zostać objętych bonem senioralnym w 2026 r. To też oznacza, że potrzebujemy do 40 tys. rąk do pracy – dodała. 

## Są nowe dane o kondycji polskiego przemysłu
 - [https://www.money.pl/gospodarka/sa-nowe-dane-o-kondycji-polskiego-przemyslu-7084743296531008a.html](https://www.money.pl/gospodarka/sa-nowe-dane-o-kondycji-polskiego-przemyslu-7084743296531008a.html)
 - RSS feed: $source
 - date published: 2024-10-23T10:35:37.899741+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/310580b0-a869-4e9c-b143-abc9ecde65d9" width="308" /> Nowe zamówienia w przemyśle na eksport we wrześniu 2024 r. w ujęciu rok do roku spadły o 7,7 proc., po wzroście o 0,6 proc. rdr miesiąc wcześniej - podał Główny Urząd Statystyczny. 

## Ceny ropy w USA zaciągnęły hamulec. Maklerzy wskazali przyczyny
 - [https://www.money.pl/gielda/ceny-ropy-w-usa-zaciagnely-hamulec-maklerzy-wskazali-przyczyny-7084723167836768a.html](https://www.money.pl/gielda/ceny-ropy-w-usa-zaciagnely-hamulec-maklerzy-wskazali-przyczyny-7084723167836768a.html)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:10.353373+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d3f9b13e-e456-445a-a566-6194ef0882c8" width="308" /> Ceny ropy naftowej na giełdzie paliw w Nowym Jorku stabilizują się po dwóch dniach, gdy wzrosły o ok. 4 proc., co oceniono jako dużą zwyżkę. Maklerzy wskazują m.in. na wizytę Sekretarza Stanu USA Bliski Wschód, a także wzrost zapasów surowca w Stanach Zjednoczonych. 

## Urlop w 2025 roku. Jak zaplanować dni wolne. Kalendarz
 - [https://www.money.pl/gospodarka/urlop-w-2025-roku-jak-zaplanowac-dni-wolne-kalendarz-7084728704186944a.html](https://www.money.pl/gospodarka/urlop-w-2025-roku-jak-zaplanowac-dni-wolne-kalendarz-7084728704186944a.html)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:10.163156+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a3029df8-129c-4943-ad99-5b1a5fdac132" width="308" /> Wykorzystanie podstawowego 26-dniowego urlopu można rozszerzyć do nawet 62 dni wolnych od pracy. Kluczowym elementem jest odpowiednie zaplanowanie urlopu na nadchodzący rok. Dzięki strategicznemu rozłożeniu dni wolnych oraz korzystnemu układowi świąt, można odpoczywać nawet przez dwa miesiące. 

## Pogorszenie  nastrojów wśród polskich konsumentów. Są nowe dane
 - [https://www.money.pl/gospodarka/pogorszenie-nastrojow-wsrod-polskich-konsumentow-sa-nowe-dane-7084734971468352a.html](https://www.money.pl/gospodarka/pogorszenie-nastrojow-wsrod-polskich-konsumentow-sa-nowe-dane-7084734971468352a.html)
 - RSS feed: $source
 - date published: 2024-10-23T09:30:09.974667+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0c4dbe31-8dbf-4886-98e0-fe7618719d3e" width="308" /> W październiku 2024 r. odnotowano pogorszenie zarówno obecnych, jak i przyszłych nastrojów konsumenckich w stosunku do poprzedniego miesiąca - podał Główny Urząd Statystyczny. 

## Minister klimatu skomentowała alarmujące dane. "Nawet dobrze". Jest fala komentarzy
 - [https://www.money.pl/gospodarka/minister-klimatu-skomentowala-alarmujace-dane-nawet-dobrze-jest-fala-komentarzy-7084695558146624a.html](https://www.money.pl/gospodarka/minister-klimatu-skomentowala-alarmujace-dane-nawet-dobrze-jest-fala-komentarzy-7084695558146624a.html)
 - RSS feed: $source
 - date published: 2024-10-23T07:15:34.316724+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/526ea39f-85e7-4720-9890-ef3361d7a8af" width="308" /> - Spadają głównie nie rzeczy pierwszej potrzeby, tylko raczej takie, bez których czasami możemy się obyć - tak gwałtowny spadek sprzedaży detalicznej komentowała  Paulina Hennig-Kloska, minister klimatu i środowiska. Dodała, że  "z punktu widzenia klimatu to nawet dobrze". Jest już fala komentarzy po jej wypowiedzi 

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 23.10.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-23-10-2024-7084685954107968a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-23-10-2024-7084685954107968a.html)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:17.012620+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 23.10.2024. W środę za jednego dolara (USD) trzeba zapłacić 4.0037 zł. 

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 23.10.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-23-10-2024-7084686014618208a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-23-10-2024-7084686014618208a.html)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:16.887941+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 23.10.2024. W środę za jednego franka (CHF) trzeba zapłacić 4.6178 zł. 

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 23.10.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-23-10-2024-7084686014618209a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-23-10-2024-7084686014618209a.html)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:16.779512+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 23.10.2024. W środę za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.1991 zł. 

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 23.10.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-23-10-2024-7084686015052384a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-23-10-2024-7084686015052384a.html)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:16.664217+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 23.10.2024. W środę za jedno euro (EUR) trzeba zapłacić 4.3245 zł. 

## Samorządowcy chcą zmian. Rząd odkręci reformę PiS-u? "Narasta zniecierpliwienie"
 - [https://www.money.pl/gospodarka/samorzadowcy-chca-zmian-rzad-odkreci-reforme-pis-u-narasta-zniecierpliwienie-7084683081902688a.html](https://www.money.pl/gospodarka/samorzadowcy-chca-zmian-rzad-odkreci-reforme-pis-u-narasta-zniecierpliwienie-7084683081902688a.html)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:16.556147+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/60b8861d-22e4-4656-923b-eafc7130b820" width="308" /> Zniesienie dwukadencyjności, znaczne poszerzenie kompetencji samorządu m.in. w sprawach ochrony środowiska - to niektóre z postulatów samorządowców, które wkrótce będą omawiane z rządem - informuje w środowym wydaniu "Rzeczpospolita". 

## Branża motoryzacyjna na zakręcie. Prognozy są złe
 - [https://www.money.pl/gospodarka/branza-motoryzacyjna-na-zakrecie-prognozy-sa-zle-7084689328536160a.html](https://www.money.pl/gospodarka/branza-motoryzacyjna-na-zakrecie-prognozy-sa-zle-7084689328536160a.html)
 - RSS feed: $source
 - date published: 2024-10-23T06:10:16.437267+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/43691d2a-262e-4a5d-8a38-9ca5649864cb" width="308" /> Perspektywy polskiego przemysłu motoryzacyjnego szybko się pogarszają. W ciągu ostatnich 12 miesięcy odsetek szefów firm tego sektora przewidujących spadki produkcji wzrósł pięciokrotnie - informuje w środowym wydaniu "Rzeczpospolita". 

## Wielka Brytania ostrzega. Putin "nasila ataki na porty na Morzu Czarnym". Konsekwencje już są
 - [https://www.money.pl/gospodarka/wielka-brytania-ostrzega-putin-nasila-ataki-na-porty-na-morzu-czarnym-konsekwencje-juz-sa-7084668916456000a.html](https://www.money.pl/gospodarka/wielka-brytania-ostrzega-putin-nasila-ataki-na-porty-na-morzu-czarnym-konsekwencje-juz-sa-7084668916456000a.html)
 - RSS feed: $source
 - date published: 2024-10-23T05:05:25.860413+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/53b2ad55-d3b7-44fa-8d8b-5e9d20c076dc" width="308" /> Rosja wzmogła ataki na ukraińską infrastrukturę portową na Morzu Czarnym, co opóźnia dostawy niezbędnej pomocy dla Palestyńczyków i uniemożliwia dostarczenie kluczowych dostaw zboża na globalne południe - ostrzegł we wtorek wieczorem brytyjski premier Keir Starmer. 

## Kursy walut 23.10.2024. Środowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-23-10-2024-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-7084678620818016a.html](https://www.money.pl/pieniadze/kursy-walut-23-10-2024-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-7084678620818016a.html)
 - RSS feed: $source
 - date published: 2024-10-23T05:05:25.649218+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/183881f7-a666-4129-a751-e4034862f0e8" width="308" /> Kursy walut - 23.10.2024. W środę za jednego dolara (USD) zapłacimy 4,00 zł. Cena jednego funta szterlinga (GBP) to 5,19 zł, a franka szwajcarskiego (CHF) 4,61 zł. Z kolei euro (EUR) możemy zakupić za 4,32 zł. 

