# Source:Jeff Geerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Linus vs iFixit: LTT Precision Screwdriver, Tested
 - [https://www.youtube.com/watch?v=bUl6MbI2jKo](https://www.youtube.com/watch?v=bUl6MbI2jKo)
 - RSS feed: $source
 - date published: 2024-10-31T14:00:40+00:00

Is the LTT Precision Screwdriver a clone of the iFixit Precision Bit Driver?

Or does it have something unique to offer? I'll test both in this video, and compare them to some other precision screwdrivers I own.

NOTE: LMG sent the LTT Precision screwdriver I tested in this video. They did not pay me to make a video, nor did they have any input into the (silly) testing methodologies I used, nor were they able to see any part of this video before it went live on YouTube.

Links to all the things I mentioned (some links are affiliate links):

  - LTT Precision Screwdriver Kit (61 bits): https://www.lttstore.com/products/precision-multi-bit-screwdriver-bundle
  - iFixit Mako Driver Kit (64 bits): https://amzn.to/3YCtmcd
  - iFixit Moray Driver Kit (32 bits): https://amzn.to/3YGXK4j
  - Klein Tools 14-in-1 Precision Screwdriver: https://amzn.to/48oXbAl
  - Klein Tools 4-in-1 Electronics Pocket Screwdriver: https://amzn.to/4hibTgH
  - MacBook Air to Linux upgrade: https://www.youtube.com/

