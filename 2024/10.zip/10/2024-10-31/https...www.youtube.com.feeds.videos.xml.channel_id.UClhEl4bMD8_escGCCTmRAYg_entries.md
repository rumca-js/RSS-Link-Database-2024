# Source:Kanał Zero, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClhEl4bMD8_escGCCTmRAYg, language:pl

## JAK PREZYDENT USA SPĘDZA HALLOWEEN? BYLIŚMY W BIAŁYM DOMU, ŻEBY WAM TO POKAZAĆ
 - [https://www.youtube.com/watch?v=6jlZK91msdw](https://www.youtube.com/watch?v=6jlZK91msdw)
 - RSS feed: $source
 - date published: 2024-10-31T18:00:09+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Zastanawialiście się kiedyś jak Prezydent Stanów Zjednoczonych obchodzi Halloween? Albo jak przebiera się na tę zabawę? Jeśli tak, to już nie musicie - Joanna Pinkwart była w Białym Domu, żeby Wam to pokazać. Co roku w okolicach 31 października Pierwsza Para Ameryki zaprasza setki dzieci, które dają jej wybór: cukierek albo psikus. Bo psikusy w waszyngtońskiej rezydencji są mile widziane tylko w ten jeden dzień.

https://www.siepomaga.pl/kanalzero

✅ Załóż profil na rockejobs.pl i otrzymuj dopasowane oferty pracy: https://oferty.rocketjobs.pl/wAsiLcW

💰Śledź media społecznościowe STS (szczególnie FB, X, IG) i wypatruj konkursów z nagrodami! - linktr.ee/stspl (+18)

🧡💙 Bonus powitalny od STS z kodem ""ZERO"" - https://oferta.sts.pl/ZERO (+18)
Regulaminy oferty powitalnej i ZBR - https://oferta.sts.pl/regulaminsts + https://oferta.sts.pl/regulaminsts_ZBR

STS to legalny bukmacher. Gra u nielegalnych podlega karze. Hazard może uzależ

## DYMISJA W RZĄDZIE TUSKA. MINISTER TOMCZAK - RAŻĄCY KONFLIKT INTERESÓW I CHIŃSKI LOBBING
 - [https://www.youtube.com/watch?v=f30uFbH3-UU](https://www.youtube.com/watch?v=f30uFbH3-UU)
 - RSS feed: $source
 - date published: 2024-10-31T17:08:08+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Wiceminister Jacek Tomczak zrezygnował ze swojego stanowiska. To efekt informacji, jakie ukazały się dotyczące jego biznesu. Otóż kancelaria notarialna należąca do Jacka Tomczaka pomagała deweloperom. Może nie byłoby w tym nic złego, ale sam wiceminister jest zwolennikiem kredytów na start, które najbardziej pomogą właśnie deweloperom. Dodatkowo Jacek Tomczak lobbował na rzecz chińskich deweloperów. Dawid Chęć przygląda się działaniom byłego już wiceministra i wraz z Szymonem Jadczakiem tłumaczą w czym dokładnie jest problem.

https://www.siepomaga.pl/kanalzero

✅ Załóż profil na rockejobs.pl i otrzymuj dopasowane oferty pracy: https://oferty.rocketjobs.pl/wAsiLcW

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQgeK3frVnhfoEM9xP3oWfqD

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.faceb

## TWÓRCA RED IS BAD JUŻ W POLSCE. CZY PAWEŁ SZOPA PÓJDZIE NA WSPÓŁPRACĘ ZE SŁUŻBAMI?
 - [https://www.youtube.com/watch?v=tddQ2Xzyycc](https://www.youtube.com/watch?v=tddQ2Xzyycc)
 - RSS feed: $source
 - date published: 2024-10-31T14:54:56+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Paweł Szopa wrócił do Polski. Został sprowadzony przez polskie służby. Monika Krześniak przypomina kim jest Paweł Szopa i jak osiągnął tak dużą karierę w taki krótkim czasie. Kluczową rolę odegrały znajomości i lukratywne kontrakty z rządem. Jednak, czy doszło do złamania prawa? O tym w dzisiejszym odcinku?

✅ Załóż profil na rockejobs.pl i otrzymuj dopasowane oferty pracy: https://oferty.rocketjobs.pl/wAsiLcW

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQgeK3frVnhfoEM9xP3oWfqD

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #redisbad #szopa #pieniąd

## ARESZT TYMCZASOWY, WYDOBYWCZY. PRAWO WYMKNĘŁO SIĘ SPOD KONTROLI I NIEPOPRAWNIK #37
 - [https://www.youtube.com/watch?v=Cgs6fktyrxU](https://www.youtube.com/watch?v=Cgs6fktyrxU)
 - RSS feed: $source
 - date published: 2024-10-31T13:17:51+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Jeżeli śledzisz media, możesz zauważyć informacje, że ktoś został skazany na areszt tymczasowy. Niestety potrafi on trwać nawet kilka lat, a zatrzymany ma mniej praw niż w więzieniu. Cały ten system działa źle, a czasem areszt tymczasowy jest używany jako narzędzie do wydobywania informacji. W 37. odcinku "Niepoprawnika"  mec. Bogusław Leśnodorski i prof. Marcin Matczak omawiają ten temat. Co można zrobić, aby takie praktyki nie były stosowane? O tym opowie nasz dzisiejszy gość - Szymon Pawelec - szef Katedry Międzynarodowego Prawa Karnego UW.

🔥Aplikuj na Just Join IT, największym portalu pracy dla branży IT: https://jjit.it/aRjT9MT

📈 Wybierz IKE najlepsze dla Twojej emerytury ➡️ https://link-pso.xtb.com/pso/Vsogf Inwestowanie jest ryzykowne. Inwestuj odpowiedzialnie

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQhCqSlr-j3z8Hg-KZY_D1oa

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/U

## MODELKI VS JAMAL - O CO CHODZI?
 - [https://www.youtube.com/watch?v=6NnYfbAtiIM](https://www.youtube.com/watch?v=6NnYfbAtiIM)
 - RSS feed: $source
 - date published: 2024-10-31T11:30:35+00:00

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #jamal #muzyka #modelki #godzinazero #nowakowska #fijak #kowalska #pop

## 7:00 WARGA & WUWUNIO - POBUDKA!
 - [https://www.youtube.com/watch?v=k2hyrXUfDyA](https://www.youtube.com/watch?v=k2hyrXUfDyA)
 - RSS feed: $source
 - date published: 2024-10-31T11:23:19+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Maciej Dąbrowski i Wuwunio zapraszają na poniedziałkowy poranek! 😊

Link do zbiórki: https://www.siepomaga.pl/kanalzero

Goście:
👤Marta Łachacz - koordynatorka scen intymnych
👤Jarosław Juszkiewicz - lektor, głos Google Maps
👤Jarek Pruchniewski - strzelectwo westernowe

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQib0kFamBx6c5j8fOfYMuXh

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #warga #wuwunio #pornek #dąbrowski #lektor #głos #western #łachacz #juszkiewicz #pruchniewski

## TERLIKOWSKI ZASKAKUJE: HALLOWEEN JEST OKEJ. KATOLICY MOGĄ SIĘ BAWIĆ
 - [https://www.youtube.com/watch?v=Jke1tOeBqDw](https://www.youtube.com/watch?v=Jke1tOeBqDw)
 - RSS feed: $source
 - date published: 2024-10-31T11:00:31+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Czy chrześcijanie mogą obchodzić Halloween? Takie pytanie i debaty wokół tego tematu pojawiają się co roku. Tomasz Terlikowski przygląda się temu świętu i przytacza jego genezę. Co może być zaskakujące, Halloween może mieć korzenie w wierze katolickiej, przez co nie stoi w sprzeczności z wyznawaniem tej wiary.

Link do zbiórki: https://www.siepomaga.pl/kanalzero

🔥Sprawdź oferty z AI na Just Join IT: https://jjit.it/fdm2nvl"

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQgeK3frVnhfoEM9xP3oWfqD

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #halloween

## OTO ADA. BY NORMALNIE ŻYĆ, MUSI MIEĆ OPERACJĘ W USA. ZBIÓRKA KANAŁU ZERO
 - [https://www.youtube.com/watch?v=yepD4k2_UME](https://www.youtube.com/watch?v=yepD4k2_UME)
 - RSS feed: $source
 - date published: 2024-10-31T09:01:03+00:00

Audycja przeznaczona dla osób powyżej 16. roku życia.
Od jakiegoś czasu na Kanale Zero prowadzimy zbiórkę na leczenie małej Ady. Kwota jest olbrzymia, bo to 8 milionów złotych. W tym materiale Emilia Dulnik udała się, by porozmawiać z rodziną i lekarzami Ady, aby poznać ich sytuację oraz dowiedzieć się na zostaną przekazane pieniądze, które wpłacacie. Każda złotówka się liczy i jesteśmy Wam bardzo wdzięczni za pomoc, której udzielacie!

Link do zbiórki: https://www.siepomaga.pl/kanalzero

🎬 Wszystkie odcinki: https://www.youtube.com/playlist?list=PLvLrA9jH7wQgeK3frVnhfoEM9xP3oWfqD

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero 

## PAWEŁ SZOPA JUŻ W POLSCE
 - [https://www.youtube.com/watch?v=Egyw6Vrty5Y](https://www.youtube.com/watch?v=Egyw6Vrty5Y)
 - RSS feed: $source
 - date published: 2024-10-31T08:53:19+00:00

Wpadnij tutaj:
🔴 Kanał Zero Extra: https://www.youtube.com/channel/UCNbQpy2EqkiK0AUdyyr35vA
🔴 Instagram: https://www.instagram.com/oficjalnezero/
🔴 Facebook: https://www.facebook.com/oficjalnezeroo
🔴 Grupa Facebook: https://www.facebook.com/groups/sekcjazero/?ref=share_group_link
🔴 TikTok: https://www.tiktok.com/@oficjalnezero
🔴 Twitter: https://twitter.com/oficjalnezero

📩 biznes@kanalzero.pl

#kanałzero #szopa #redisbad #areszt #bodnar #pieniądze #polityka #polska

