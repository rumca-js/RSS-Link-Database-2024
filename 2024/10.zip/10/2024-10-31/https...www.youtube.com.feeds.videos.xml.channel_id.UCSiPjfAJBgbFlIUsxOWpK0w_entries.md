# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## Ben gets real sassy on this one.
 - [https://www.youtube.com/watch?v=u4TkeYmRX6g](https://www.youtube.com/watch?v=u4TkeYmRX6g)
 - RSS feed: $source
 - date published: 2024-10-31T18:12:55+00:00

None

