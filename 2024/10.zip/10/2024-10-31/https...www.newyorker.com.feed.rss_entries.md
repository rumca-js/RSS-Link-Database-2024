# Source:The New Yorker, URL:https://www.newyorker.com/feed/rss, language:en-US

## Garbage Time at the 2024 Finish Line
 - [https://www.newyorker.com/news/letter-from-bidens-washington/garbage-time-at-the-2024-finish-line](https://www.newyorker.com/news/letter-from-bidens-washington/garbage-time-at-the-2024-finish-line)
 - RSS feed: $source
 - date published: 2024-10-31T23:21:51+00:00

Nine years in, Trump is in reach of another term as the technocrats struggle to contain him.

## An Election-Threat Task Force at Work
 - [https://www.newyorker.com/newsletter/the-daily/an-election-threat-task-force-at-work](https://www.newyorker.com/newsletter/the-daily/an-election-threat-task-force-at-work)
 - RSS feed: $source
 - date published: 2024-10-31T22:00:00+00:00

From the daily newsletter: Eliza Griswold reports from Pennsylvania. Plus: Richard Brody’s spooky-movie suggestions, the faces of newly naturalized citizens in Arizona, and Clint Eastwood’s courtroom thriller.

## Bonus Daily Cartoon: Canvassing
 - [https://www.newyorker.com/cartoons/daily-cartoon/bonus-daily-cartoon-canvassing](https://www.newyorker.com/cartoons/daily-cartoon/bonus-daily-cartoon-canvassing)
 - RSS feed: $source
 - date published: 2024-10-31T18:00:00+00:00

Trump’s mischief night.

## The Joy of New Americans
 - [https://www.newyorker.com/culture/photo-booth/the-joy-of-new-americans](https://www.newyorker.com/culture/photo-booth/the-joy-of-new-americans)
 - RSS feed: $source
 - date published: 2024-10-31T15:31:21+00:00

At ceremonies in Arizona, hundreds of people were naturalized, and many prepared to vote.

## Daily Cartoon: Thursday, October 31st
 - [https://www.newyorker.com/cartoons/daily-cartoon/thursday-october-31st-kamala-harris-canvasser](https://www.newyorker.com/cartoons/daily-cartoon/thursday-october-31st-kamala-harris-canvasser)
 - RSS feed: $source
 - date published: 2024-10-31T12:48:58+00:00

“I’m going door-to-door on behalf of Kamala Harris. She prefers Reese’s, but she wouldn’t say no to a Snickers.”

## Critics at Large Live: Julio Torres’s Dreamy Surrealism
 - [https://www.newyorker.com/podcast/critics-at-large/critics-at-large-live-julio-torress-dreamy-surrealism](https://www.newyorker.com/podcast/critics-at-large/critics-at-large-live-julio-torress-dreamy-surrealism)
 - RSS feed: $source
 - date published: 2024-10-31T10:00:00+00:00

In projects like “Problemista” and HBO’s “Fantasmas,” the multihyphenate uses uncanny flourishes to make sense of our most convoluted bureaucratic systems.

## Halloween Decorations Explained
 - [https://www.newyorker.com/humor/shouts-murmurs/halloween-decorations-explained](https://www.newyorker.com/humor/shouts-murmurs/halloween-decorations-explained)
 - RSS feed: $source
 - date published: 2024-10-31T10:00:00+00:00

Witches and skeletons make sense for this holiday, but your guess is as good as mine when it comes to “a general spooky vibe.”

## Safeguarding the Pennsylvania Election
 - [https://www.newyorker.com/news/the-political-scene/safeguarding-the-pennsylvania-election](https://www.newyorker.com/news/the-political-scene/safeguarding-the-pennsylvania-election)
 - RSS feed: $source
 - date published: 2024-10-31T10:00:00+00:00

For months, state officials have prepared to manage the threat of far-right conspiracists who may try to “stop the steal.”

## The Fight Over Truth in a Blue-Collar Pennsylvania County
 - [https://www.newyorker.com/news/the-lede/the-fight-over-truth-in-a-blue-collar-pennsylvania-county](https://www.newyorker.com/news/the-lede/the-fight-over-truth-in-a-blue-collar-pennsylvania-county)
 - RSS feed: $source
 - date published: 2024-10-31T10:00:00+00:00

Lackawanna County was once a Democratic stronghold. In 2024, it is a hotly contested battleground, where the stakes go far beyond politics.

## The Mini Crossword: Thursday, October 31, 2024
 - [https://www.newyorker.com/puzzles-and-games-dept/mini-crossword/2024/10/31](https://www.newyorker.com/puzzles-and-games-dept/mini-crossword/2024/10/31)
 - RSS feed: $source
 - date published: 2024-10-31T10:00:00+00:00

Castle whose name is repeatedly rhymed with “Shalott,” in “The Lady of Shalott”: seven letters.

