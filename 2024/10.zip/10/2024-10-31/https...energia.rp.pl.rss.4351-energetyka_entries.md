# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Fiasko gazowego projektu Enei. Cios w plany, aby pokryć braki mocy do produkcji prądu
 - [https://energia.rp.pl/energetyka-zawodowa/art41386571-fiasko-gazowego-projektu-enei-cios-w-plany-aby-pokryc-braki-mocy-do-produkcji-pradu](https://energia.rp.pl/energetyka-zawodowa/art41386571-fiasko-gazowego-projektu-enei-cios-w-plany-aby-pokryc-braki-mocy-do-produkcji-pradu)
 - RSS feed: $source
 - date published: 2024-10-31T19:07:52.174887+00:00

Poznańska Enea unieważniła przetarg na budowę elektrowni gazowej w Kozienicach. To już druga taka sytuacja w ciągu ostatniego roku. Żadna nie wpłynęła w wyznaczonym czasie, a więc 30 października. Elektrownia miała być ważnym elementem pokrywającym lukę w mocy wytwórczej w 2030 r.

## Będą zmiany w kopalniach największej spółki górniczej w Polsce. Zwolnień ma nie być
 - [https://energia.rp.pl/wegiel/art41384791-beda-zmiany-w-kopalniach-najwiekszej-spolki-gorniczej-w-polsce-zwolnien-ma-nie-byc](https://energia.rp.pl/wegiel/art41384791-beda-zmiany-w-kopalniach-najwiekszej-spolki-gorniczej-w-polsce-zwolnien-ma-nie-byc)
 - RSS feed: $source
 - date published: 2024-10-31T15:52:50.059553+00:00

Nie będzie zwolnień w największej grupie górniczej w Polsce - Polskiej Grupie Górniczej. Takie ryzyko było w związku z planami połączenia ruchów Bielszowice i Halemba w jednoruchową kopalnię Ruda.

## Kończy się czas na przyjęcie nowych norm jakości węgla. Zależy od tego 9 mld euro
 - [https://energia.rp.pl/surowce-i-paliwa/art41384171-konczy-sie-czas-na-przyjecie-nowych-norm-jakosci-wegla-zalezy-od-tego-9-mld-euro](https://energia.rp.pl/surowce-i-paliwa/art41384171-konczy-sie-czas-na-przyjecie-nowych-norm-jakosci-wegla-zalezy-od-tego-9-mld-euro)
 - RSS feed: $source
 - date published: 2024-10-31T13:46:29.339907+00:00

Z końcem października mija okres przejściowy dotyczący rozporządzenia o jakości paliw stałych, w tym węgla, spalanych w gospodarstwach domowych. Minister funduszy Katarzyna Pełczyńska-Nałęcz twierdzi jednak, że mamy czas do połowy listopada.

## Sam Hall: OZE pomogły Wielkiej Brytanii odejść od węgla
 - [https://energia.rp.pl/oze/art41383331-sam-hall-oze-pomogly-wielkiej-brytanii-odejsc-od-wegla](https://energia.rp.pl/oze/art41383331-sam-hall-oze-pomogly-wielkiej-brytanii-odejsc-od-wegla)
 - RSS feed: $source
 - date published: 2024-10-31T07:25:00+00:00

Odnawialne źródła energii przyniosły dziesiątki tysięcy miejsc pracy, także w słabo rozwiniętych częściach Wielkiej Brytanii. To był potężny sygnał, że w transformacji energetycznej jest ogromna korzyść dla gospodarki i społeczeństwa - ocenia Sam Hall, szef brytyjskiego think tanku Conservative Environmental Network.

