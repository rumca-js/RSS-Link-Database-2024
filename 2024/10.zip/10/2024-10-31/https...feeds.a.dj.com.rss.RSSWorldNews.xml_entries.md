# Source:The Wall Street Journal, URL:https://feeds.a.dj.com/rss/RSSWorldNews.xml, language:en-US

## In Shanghai, Halloween Passes Quietly a Year After Boisterous Celebrations
 - [https://www.wsj.com/articles/in-shanghai-halloween-passes-quietly-a-year-after-boisterous-celebrations-0996be44](https://www.wsj.com/articles/in-shanghai-halloween-passes-quietly-a-year-after-boisterous-celebrations-0996be44)
 - RSS feed: $source
 - date published: 2024-10-31T17:03:00+00:00

Authorities tightened security in an apparent attempt at avoiding howls of defiance.

## John McQuown, Who Pioneered Index Funds and Transformed Investing, Dies at 90
 - [https://www.wsj.com/articles/john-mcquown-index-fund-investing-pioneer-dead-1ee3b579](https://www.wsj.com/articles/john-mcquown-index-fund-investing-pioneer-dead-1ee3b579)
 - RSS feed: $source
 - date published: 2024-10-31T10:00:00+00:00

The Illinois native jumped from family farm to mechanical engineering and then led a ‘Manhattan Project’ of finance.

## U.S. Officials in Israel Working on Proposal to End Lebanon War
 - [https://www.wsj.com/articles/u-s-officials-in-israel-working-on-proposal-to-end-lebanon-war-6e20c3f3](https://www.wsj.com/articles/u-s-officials-in-israel-working-on-proposal-to-end-lebanon-war-6e20c3f3)
 - RSS feed: $source
 - date published: 2024-10-31T09:41:00+00:00

The proposal would allow Israel to continue striking Lebanon for a two-month period, but that could face resistance from Hezbollah and the Lebanese government.

