# Source:Road to VR, URL:https://www.roadtovr.com/feed, language:en-US

## Google Prepares Support for XR Headsets on Play Store, Marking The Next Chapter in XR Competition
 - [https://www.roadtovr.com/google-play-store-xr-headset-support](https://www.roadtovr.com/google-play-store-xr-headset-support)
 - RSS feed: $source
 - date published: 2024-10-31T10:46:22+00:00

<img width="640" height="360" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-640x360.jpg" class="webfeedsFeaturedVisual wp-post-image" alt="" style="display: block; margin-bottom: 10px; clear: both; max-width: 100%;" srcset="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-640x360.jpg 640w, https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-125x70.jpg 125w, https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-320x180.jpg 320w, https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-768x432.jpg 768w, https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-747x420.jpg 747w, https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-681x383.jpg 681w" sizes="(max-width: 640px) 100vw, 640px" /><div style="margin: 5px 5% 10px 5%;"><img src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/10/google-play-341x220.jpg" width=

