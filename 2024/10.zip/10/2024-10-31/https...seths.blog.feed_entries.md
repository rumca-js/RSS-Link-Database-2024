# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Wearing the costume
 - [https://seths.blog/2024/10/wearing-the-costume](https://seths.blog/2024/10/wearing-the-costume)
 - RSS feed: $source
 - date published: 2024-10-31T09:03:00+00:00

There&#8217;s a huge difference between carrying a stethoscope and being a doctor. And being a clown requires far more than getting a clown suit. Entrepreneurs with business cards, slick websites and mission statements are confused. That&#8217;s not the hard part. If the costume puts you in the right frame of mind, that&#8217;s great. But the [&#8230;]

