# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## OpenAI Adds Search Engine to ChatGPT
 - [https://www.nytimes.com/2024/10/31/technology/chatgpt-openai-search-engine.html](https://www.nytimes.com/2024/10/31/technology/chatgpt-openai-search-engine.html)
 - RSS feed: $source
 - date published: 2024-10-31T17:00:12+00:00

The popular online chatbot can now access and deliver information from across the internet in real time, including news, stock prices and sports scores.

## Why a Memphis Community Is Fighting Elon Musk’s Supercomputer
 - [https://www.nytimes.com/2024/10/31/business/energy-environment/elon-musk-ai-memphis-pollution.html](https://www.nytimes.com/2024/10/31/business/energy-environment/elon-musk-ai-memphis-pollution.html)
 - RSS feed: $source
 - date published: 2024-10-31T15:07:33+00:00

Residents say Mr. Musk’s data center for artificial intelligence is compounding their pollution burden and adding stress on the local electrical grid.

## Election Falsehoods Take Off on YouTube as It Looks the Other Way
 - [https://www.nytimes.com/2024/10/31/technology/youtube-election-conspiracy-theories-misinformation.html](https://www.nytimes.com/2024/10/31/technology/youtube-election-conspiracy-theories-misinformation.html)
 - RSS feed: $source
 - date published: 2024-10-31T09:00:34+00:00

The video site removed 2020 misinformation, fearing real-world harm. Now it’s amplifying and profiting from 2024 falsehoods, researchers said.

