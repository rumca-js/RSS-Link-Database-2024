# Source:Reverse Engineering, URL:https://www.reddit.com/r/ReverseEngineering/.rss, language:

## How do i workaround ASLR and get constant and offset values for game hacking?
 - [https://www.reddit.com/r/ReverseEngineering/comments/1ggr6py/how_do_i_workaround_aslr_and_get_constant_and](https://www.reddit.com/r/ReverseEngineering/comments/1ggr6py/how_do_i_workaround_aslr_and_get_constant_and)
 - RSS feed: $source
 - date published: 2024-10-31T22:44:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/NoAide6382"> /u/NoAide6382 </a> <br/> <span><a href="https://www.reddit.com/r/ReverseEngineering/submit/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/ReverseEngineering/comments/1ggr6py/how_do_i_workaround_aslr_and_get_constant_and/">[comments]</a></span>

## Job offer (hope that's allowed here)
 - [https://www.reddit.com/r/ReverseEngineering/comments/1gg2i8q/job_offer_hope_thats_allowed_here](https://www.reddit.com/r/ReverseEngineering/comments/1gg2i8q/job_offer_hope_thats_allowed_here)
 - RSS feed: $source
 - date published: 2024-10-31T00:59:22+00:00

<!-- SC_OFF --><div class="md"><p>I&#39;m trying to get the API of a website which is very well protected by Akamai und Cloudflare. Would anyone be able to help me with that?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Limp_Attention_9783"> /u/Limp_Attention_9783 </a> <br/> <span><a href="http://random.de">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/ReverseEngineering/comments/1gg2i8q/job_offer_hope_thats_allowed_here/">[comments]</a></span>

