# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## The First Ryzen Ai 9 HX370 Handheld Gaming PC Is Coming! ONEXFLY F1 Pro
 - [https://www.youtube.com/watch?v=LHishIrb-JA](https://www.youtube.com/watch?v=LHishIrb-JA)
 - RSS feed: $source
 - date published: 2024-10-31T14:30:13+00:00

The OneXfly f1 pro is powered by the all new AMD Ryzen Ai 9 HX 370 and has a 144HZ OLED Screen!
Just announced the first gaming handheld powered by the HX370 and backed the the radeon 890M iGPU. they will also be releasing an Ryzen HX 365 version with the radeon 880M iGPU plus a special edition EVA Version!

https://onexplayerstore.com/

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

Vip-Urcdkey Sale Code for software: ETA
Windows 10 Pro OEM Key($17): https://biitt.ly/KpEmf
Windows 11 Pro Key($23):https://biitt.ly/RUZiX
Windows10 Home Key($16):https://biitt.ly/2tPi1
Office 2019 pro key($51):https://biitt.ly/o0OQT
Office 2021 pro key($97):https://biitt.ly/iDMHc  
Office 2016 pro key($28): https://biitt.ly/xWmvn

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Cop

## Anbernic RG P01 The Best $15 Game Controller You Can Buy!
 - [https://www.youtube.com/watch?v=UxCSrilWbds](https://www.youtube.com/watch?v=UxCSrilWbds)
 - RSS feed: $source
 - date published: 2024-10-31T13:05:02+00:00

The new Anbernic RG P01 is an all new controller that has it all, 6 Axis Gyro, Hall Based sticks, Hall based Triggers, Bluetooth, 2.4Gz and more! but thye best part is this gamepad only cost $15! It works with the Nintendo switch, PC, android, steam and more!

Buy The RG P01 Here: https://anbernic.com?sca_ref=2193181.CeT6UNbFuN&sca_source=https://anbernic.com/products/rg-p01

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

Vip-Urcdkey Sale Code for software: ETA
Windows 10 Pro OEM Key($17): https://biitt.ly/KpEmf
Windows 11 Pro Key($23):https://biitt.ly/RUZiX
Windows10 Home Key($16):https://biitt.ly/2tPi1
Office 2019 pro key($51):https://biitt.ly/o0OQT
Office 2021 pro key($97):https://biitt.ly/iDMHc  
Office 2016 pro key($28): https://biitt.ly/xWmvn

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra co

