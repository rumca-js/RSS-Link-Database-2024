# Source:/r/Technology, URL:https://www.reddit.com/r/technology/.rss, language:en

## Headlights are too bright! But US experts say they’re not bright enough | Driver complaints about high beams are commonplace, though specialists say US roads need to be better lit
 - [https://www.reddit.com/r/technology/comments/1ggoa33/headlights_are_too_bright_but_us_experts_say](https://www.reddit.com/r/technology/comments/1ggoa33/headlights_are_too_bright_but_us_experts_say)
 - RSS feed: $source
 - date published: 2024-10-31T20:30:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggoa33/headlights_are_too_bright_but_us_experts_say/"> <img src="https://external-preview.redd.it/2GU4_3D_CPAjJDJcB7V4SUFdOgVuBPfYBS46qn_Xipg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f2049f0a719c5cd1495e735f24ae8b4d53eced47" alt="Headlights are too bright! But US experts say they’re not bright enough | Driver complaints about high beams are commonplace, though specialists say US roads need to be better lit" title="Headlights are too bright! But US experts say they’re not bright enough | Driver complaints about high beams are commonplace, though specialists say US roads need to be better lit" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hashirama4AP"> /u/Hashirama4AP </a> <br/> <span><a href="https://www.theguardian.com/global/2024/oct/31/headlights-too-bright">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggoa33/headlights_are_too_b

## 'World-first' indoor vertical farm to produce 4M pounds of berries a year
 - [https://www.reddit.com/r/technology/comments/1ggn5x7/worldfirst_indoor_vertical_farm_to_produce_4m](https://www.reddit.com/r/technology/comments/1ggn5x7/worldfirst_indoor_vertical_farm_to_produce_4m)
 - RSS feed: $source
 - date published: 2024-10-31T19:42:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggn5x7/worldfirst_indoor_vertical_farm_to_produce_4m/"> <img src="https://external-preview.redd.it/P174pV0Zq5BQ0IZqjYvz4B1wpw8tGyJBWosZ23qSDFs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d1e95154d2e4af0eb358f89e2f98d53a3ee81797" alt="'World-first' indoor vertical farm to produce 4M pounds of berries a year" title="'World-first' indoor vertical farm to produce 4M pounds of berries a year" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/fchung"> /u/fchung </a> <br/> <span><a href="https://newatlas.com/manufacturing/world-first-vertical-strawberry-farm-plenty/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggn5x7/worldfirst_indoor_vertical_farm_to_produce_4m/">[comments]</a></span> </td></tr></table>

## Zuckerberg: The AI Slop Will Continue Until Morale Improves
 - [https://www.reddit.com/r/technology/comments/1gglng8/zuckerberg_the_ai_slop_will_continue_until_morale](https://www.reddit.com/r/technology/comments/1gglng8/zuckerberg_the_ai_slop_will_continue_until_morale)
 - RSS feed: $source
 - date published: 2024-10-31T18:37:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1gglng8/zuckerberg_the_ai_slop_will_continue_until_morale/"> <img src="https://external-preview.redd.it/yBWf3TJzo0eVOpR39WpnS6L0aQQ5kVvUnvkYTTF8FYI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=68455679306b29566de30792741ffd3da4e51d89" alt="Zuckerberg: The AI Slop Will Continue Until Morale Improves" title="Zuckerberg: The AI Slop Will Continue Until Morale Improves" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Well_Socialized"> /u/Well_Socialized </a> <br/> <span><a href="https://www.404media.co/zuckerberg-the-ai-slop-will-continue-until-morale-improves/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gglng8/zuckerberg_the_ai_slop_will_continue_until_morale/">[comments]</a></span> </td></tr></table>

## 'A lot of demoralized people': Ghost jobs wreaking havoc on tech workers
 - [https://www.reddit.com/r/technology/comments/1ggjo54/a_lot_of_demoralized_people_ghost_jobs_wreaking](https://www.reddit.com/r/technology/comments/1ggjo54/a_lot_of_demoralized_people_ghost_jobs_wreaking)
 - RSS feed: $source
 - date published: 2024-10-31T17:12:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggjo54/a_lot_of_demoralized_people_ghost_jobs_wreaking/"> <img src="https://external-preview.redd.it/DJ1dkpgX8mDF4q14UjdzL3HHHP3V8bt2ZoDsR03oagg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1f5df8493b8ae8eb87f58f84ab02d2f5332cbb01" alt="'A lot of demoralized people': Ghost jobs wreaking havoc on tech workers" title="'A lot of demoralized people': Ghost jobs wreaking havoc on tech workers" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/abrownn"> /u/abrownn </a> <br/> <span><a href="https://www.sfgate.com/tech/article/ghost-jobs-california-tech-industry-19871249.php">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggjo54/a_lot_of_demoralized_people_ghost_jobs_wreaking/">[comments]</a></span> </td></tr></table>

## Microsoft wants $30 to let you keep using Windows 10 securely for another year | Windows 10 end of support is coming in October 2025, and consumers will only be able to buy an extra year of security updates.
 - [https://www.reddit.com/r/technology/comments/1ggiow7/microsoft_wants_30_to_let_you_keep_using_windows](https://www.reddit.com/r/technology/comments/1ggiow7/microsoft_wants_30_to_let_you_keep_using_windows)
 - RSS feed: $source
 - date published: 2024-10-31T16:29:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggiow7/microsoft_wants_30_to_let_you_keep_using_windows/"> <img src="https://external-preview.redd.it/R4EEYQGDs5L_GcawVAHbvqv1OR-g_i-WyF-xFQzUsvY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c4323e9dc784c6dd55ddccadf99467ca9531df98" alt="Microsoft wants $30 to let you keep using Windows 10 securely for another year | Windows 10 end of support is coming in October 2025, and consumers will only be able to buy an extra year of security updates." title="Microsoft wants $30 to let you keep using Windows 10 securely for another year | Windows 10 end of support is coming in October 2025, and consumers will only be able to buy an extra year of security updates." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/chrisdh79"> /u/chrisdh79 </a> <br/> <span><a href="https://www.theverge.com/2024/10/31/24284398/microsoft-windows-10-extended-security-updates-consumer-pricing">[link]</a></span> 

## The company building Trump Media’s tech has historic links to Iran, Russia, and China
 - [https://www.reddit.com/r/technology/comments/1ggimz8/the_company_building_trump_medias_tech_has](https://www.reddit.com/r/technology/comments/1ggimz8/the_company_building_trump_medias_tech_has)
 - RSS feed: $source
 - date published: 2024-10-31T16:27:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggimz8/the_company_building_trump_medias_tech_has/"> <img src="https://external-preview.redd.it/JPdfIrVhsZj8fdMORXXW5fge2hjgJT6_thiXAA-jIkY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6b433067a6aac7e943020b6ac753b37b30b2c961" alt="The company building Trump Media’s tech has historic links to Iran, Russia, and China" title="The company building Trump Media’s tech has historic links to Iran, Russia, and China" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Wagamaga"> /u/Wagamaga </a> <br/> <span><a href="https://fortune.com/2024/10/18/trump-media-iran-russia-china/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggimz8/the_company_building_trump_medias_tech_has/">[comments]</a></span> </td></tr></table>

## New York semiconductor research site picked for $825 million in CHIPS act funding
 - [https://www.reddit.com/r/technology/comments/1ggigd0/new_york_semiconductor_research_site_picked_for](https://www.reddit.com/r/technology/comments/1ggigd0/new_york_semiconductor_research_site_picked_for)
 - RSS feed: $source
 - date published: 2024-10-31T16:19:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggigd0/new_york_semiconductor_research_site_picked_for/"> <img src="https://external-preview.redd.it/BPOsmkxP_r6ED1tf0Fc9BdbzOZSsV1SHW9-La-MLguk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a9782b4e4005c46a94f18cb65c4b810191f46e64" alt="New York semiconductor research site picked for $825 million in CHIPS act funding" title="New York semiconductor research site picked for $825 million in CHIPS act funding" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>NanoTech complex will serve as the national headquarters for research in extreme ultraviolet (EUV) lithography, a cutting-edge semiconductor technology.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bedbathnyourmom"> /u/Bedbathnyourmom </a> <br/> <span><a href="https://fortune.com/2024/10/31/new-york-semiconductor-research-site-825-million-chips-act-funding/">[link]</a></span> &#32; <span><a href="https://www.reddit

## Study reveals billionaires produce as much carbon pollution in 90 minutes as an average person does in a lifetime | Via their jets, superyachts, and investments
 - [https://www.reddit.com/r/technology/comments/1gghgak/study_reveals_billionaires_produce_as_much_carbon](https://www.reddit.com/r/technology/comments/1gghgak/study_reveals_billionaires_produce_as_much_carbon)
 - RSS feed: $source
 - date published: 2024-10-31T15:37:00+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/chrisdh79"> /u/chrisdh79 </a> <br/> <span><a href="https://www.techspot.com/news/105382-study-reveals-billionaires-produce-much-carbon-90-minutes.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gghgak/study_reveals_billionaires_produce_as_much_carbon/">[comments]</a></span>

## Amazon workers 'appalled' by AWS CEO's return to office remarks, urge reversal
 - [https://www.reddit.com/r/technology/comments/1gghawk/amazon_workers_appalled_by_aws_ceos_return_to](https://www.reddit.com/r/technology/comments/1gghawk/amazon_workers_appalled_by_aws_ceos_return_to)
 - RSS feed: $source
 - date published: 2024-10-31T15:30:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/gargage93"> /u/gargage93 </a> <br/> <span><a href="https://www.reuters.com/business/retail-consumer/amazon-workers-appalled-by-aws-ceos-return-office-remarks-urge-policy-reversal-2024-10-30/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gghawk/amazon_workers_appalled_by_aws_ceos_return_to/">[comments]</a></span>

## Facebook Took More Than $1 Million For Ads Sowing Election Lies
 - [https://www.reddit.com/r/technology/comments/1ggfxj3/facebook_took_more_than_1_million_for_ads_sowing](https://www.reddit.com/r/technology/comments/1ggfxj3/facebook_took_more_than_1_million_for_ads_sowing)
 - RSS feed: $source
 - date published: 2024-10-31T14:31:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggfxj3/facebook_took_more_than_1_million_for_ads_sowing/"> <img src="https://external-preview.redd.it/3C-g8qCzoaaEwIEf3mdMhNU0R-eZvymZQBcRqYrzqQA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6cc2ecf179937c78c0e4f12faee6b5a38d665b27" alt="Facebook Took More Than $1 Million For Ads Sowing Election Lies" title="Facebook Took More Than $1 Million For Ads Sowing Election Lies" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/indig0sixalpha"> /u/indig0sixalpha </a> <br/> <span><a href="https://www.forbes.com/sites/emilybaker-white/2024/10/30/facebook-ads-election-misinformation">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggfxj3/facebook_took_more_than_1_million_for_ads_sowing/">[comments]</a></span> </td></tr></table>

## ‘It’s the First Amendment, stupid’: the bizarre fight between Trump and broadcast TV
 - [https://www.reddit.com/r/technology/comments/1ggfl8u/its_the_first_amendment_stupid_the_bizarre_fight](https://www.reddit.com/r/technology/comments/1ggfl8u/its_the_first_amendment_stupid_the_bizarre_fight)
 - RSS feed: $source
 - date published: 2024-10-31T14:16:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggfl8u/its_the_first_amendment_stupid_the_bizarre_fight/"> <img src="https://external-preview.redd.it/xOS8EZVnABNox-2Sva2UqK_zltfKWBT1DscPimEdru4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4682bf95123c6144362f4e2b773938217c5c305c" alt="‘It’s the First Amendment, stupid’: the bizarre fight between Trump and broadcast TV" title="‘It’s the First Amendment, stupid’: the bizarre fight between Trump and broadcast TV" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/a_Ninja_b0y"> /u/a_Ninja_b0y </a> <br/> <span><a href="https://www.theverge.com/24283652/fcc-license-donald-trump-elon-musk-first-amendment-fairness-doctrine-please-vote-decoder">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggfl8u/its_the_first_amendment_stupid_the_bizarre_fight/">[comments]</a></span> </td></tr></table>

## Over 25% of Google’s code is now written by AI—and CEO Sundar Pichai says it’s just the start
 - [https://www.reddit.com/r/technology/comments/1ggfjct/over_25_of_googles_code_is_now_written_by_aiand](https://www.reddit.com/r/technology/comments/1ggfjct/over_25_of_googles_code_is_now_written_by_aiand)
 - RSS feed: $source
 - date published: 2024-10-31T14:14:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggfjct/over_25_of_googles_code_is_now_written_by_aiand/"> <img src="https://external-preview.redd.it/9330QrszN0cPZj5zgwih5TerEnWMNTcuPzcutNozb5w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0782a01ef12a9863fbd3341a625519cd81a61efc" alt="Over 25% of Google’s code is now written by AI—and CEO Sundar Pichai says it’s just the start" title="Over 25% of Google’s code is now written by AI—and CEO Sundar Pichai says it’s just the start" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/arslanfromnarnia"> /u/arslanfromnarnia </a> <br/> <span><a href="https://fortune.com/2024/10/30/googles-code-ai-sundar-pichai/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggfjct/over_25_of_googles_code_is_now_written_by_aiand/">[comments]</a></span> </td></tr></table>

## Mark Zuckerberg says a lot more AI generated content is coming to fill up your Facebook and Instagram feeds
 - [https://www.reddit.com/r/technology/comments/1ggfie9/mark_zuckerberg_says_a_lot_more_ai_generated](https://www.reddit.com/r/technology/comments/1ggfie9/mark_zuckerberg_says_a_lot_more_ai_generated)
 - RSS feed: $source
 - date published: 2024-10-31T14:13:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggfie9/mark_zuckerberg_says_a_lot_more_ai_generated/"> <img src="https://external-preview.redd.it/z6tjubhE05k_0bbtTWzrLKH-H54j_Py_RTH2PvBEBK8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8074d570de7da030732b452136129904136e268a" alt="Mark Zuckerberg says a lot more AI generated content is coming to fill up your Facebook and Instagram feeds" title="Mark Zuckerberg says a lot more AI generated content is coming to fill up your Facebook and Instagram feeds" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/arslanfromnarnia"> /u/arslanfromnarnia </a> <br/> <span><a href="https://fortune.com/2024/10/30/mark-zuckerberg-ai-generated-content-next-big-category-social-media-feeds/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggfie9/mark_zuckerberg_says_a_lot_more_ai_generated/">[comments]</a></span> </td></tr></table>

## Meta’s Reality Labs posts $4.4 billion loss in third quarter
 - [https://www.reddit.com/r/technology/comments/1ggfbeu/metas_reality_labs_posts_44_billion_loss_in_third](https://www.reddit.com/r/technology/comments/1ggfbeu/metas_reality_labs_posts_44_billion_loss_in_third)
 - RSS feed: $source
 - date published: 2024-10-31T14:04:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggfbeu/metas_reality_labs_posts_44_billion_loss_in_third/"> <img src="https://external-preview.redd.it/r_b25NYkBNGTkVN_zQDLMtElFncKz3lS9zEEfTw3pIg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5b00612859b526cd3227c85e51e498c5e61cc0ab" alt="Meta’s Reality Labs posts $4.4 billion loss in third quarter" title="Meta’s Reality Labs posts $4.4 billion loss in third quarter" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BlueLightStruct"> /u/BlueLightStruct </a> <br/> <span><a href="https://www.cnbc.com/2024/10/30/metas-reality-labs-posts-4point4-billion-loss-in-third-quarter.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggfbeu/metas_reality_labs_posts_44_billion_loss_in_third/">[comments]</a></span> </td></tr></table>

## Today In Court of Appeals Open-Internet Allies Defend FCC Authority to Protect Internet Users
 - [https://www.reddit.com/r/technology/comments/1ggeozp/today_in_court_of_appeals_openinternet_allies](https://www.reddit.com/r/technology/comments/1ggeozp/today_in_court_of_appeals_openinternet_allies)
 - RSS feed: $source
 - date published: 2024-10-31T13:36:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggeozp/today_in_court_of_appeals_openinternet_allies/"> <img src="https://external-preview.redd.it/FQ9Nua1U6ujYmBJUlbHFus6c-fFw2qLlNtb4Cmn-X9Q.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=25549b65c8f076b74278a7ece5aaba6102c32df4" alt="Today In Court of Appeals Open-Internet Allies Defend FCC Authority to Protect Internet Users" title="Today In Court of Appeals Open-Internet Allies Defend FCC Authority to Protect Internet Users" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/oimebaby"> /u/oimebaby </a> <br/> <span><a href="https://www.freepress.net/news/press-releases/free-press-and-open-internet-allies-will-defend-net-neutrality-court">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggeozp/today_in_court_of_appeals_openinternet_allies/">[comments]</a></span> </td></tr></table>

## Trump loses $1.3 billion in net worth after the worst-ever day for his social media stock
 - [https://www.reddit.com/r/technology/comments/1ggenw7/trump_loses_13_billion_in_net_worth_after_the](https://www.reddit.com/r/technology/comments/1ggenw7/trump_loses_13_billion_in_net_worth_after_the)
 - RSS feed: $source
 - date published: 2024-10-31T13:34:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggenw7/trump_loses_13_billion_in_net_worth_after_the/"> <img src="https://external-preview.redd.it/2ZBelZIWWoQHWbqzP8Bte4caQoI6FyRgwADBXgqpUiI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=163a1d5dcd4cb7f83dbfcf4a3a1aff2d6c0f17d1" alt="Trump loses $1.3 billion in net worth after the worst-ever day for his social media stock" title="Trump loses $1.3 billion in net worth after the worst-ever day for his social media stock" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rejs7"> /u/rejs7 </a> <br/> <span><a href="https://www.cnn.com/2024/10/30/business/trump-stock-truth-social/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggenw7/trump_loses_13_billion_in_net_worth_after_the/">[comments]</a></span> </td></tr></table>

## 300 percent price hikes push disgruntled VMware customers toward Broadcom rivals
 - [https://www.reddit.com/r/technology/comments/1ggdx3u/300_percent_price_hikes_push_disgruntled_vmware](https://www.reddit.com/r/technology/comments/1ggdx3u/300_percent_price_hikes_push_disgruntled_vmware)
 - RSS feed: $source
 - date published: 2024-10-31T13:00:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggdx3u/300_percent_price_hikes_push_disgruntled_vmware/"> <img src="https://external-preview.redd.it/7pYnlSTiRYJ84PYeu0vKyDC8BBFvDXQMmYFrrs-zBk4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a24ab81c98ee7e1cf4601fd474f10b58bbe73192" alt="300 percent price hikes push disgruntled VMware customers toward Broadcom rivals" title="300 percent price hikes push disgruntled VMware customers toward Broadcom rivals" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AdSpecialist6598"> /u/AdSpecialist6598 </a> <br/> <span><a href="https://arstechnica.com/information-technology/2024/10/a-year-after-broadcoms-vmware-buy-customers-eye-exit-strategies/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggdx3u/300_percent_price_hikes_push_disgruntled_vmware/">[comments]</a></span> </td></tr></table>

## Report says crowd-sourced fact checks on X fail to address flood of US election misinformation
 - [https://www.reddit.com/r/technology/comments/1ggda20/report_says_crowdsourced_fact_checks_on_x_fail_to](https://www.reddit.com/r/technology/comments/1ggda20/report_says_crowdsourced_fact_checks_on_x_fail_to)
 - RSS feed: $source
 - date published: 2024-10-31T12:27:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggda20/report_says_crowdsourced_fact_checks_on_x_fail_to/"> <img src="https://external-preview.redd.it/WVwe4ckBLUlxx6jdwcwVrTVXNEpdJa5LgSZhzZqzIhQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=46cd96805d742e3c132766e1f53ef175ca50ee59" alt="Report says crowd-sourced fact checks on X fail to address flood of US election misinformation" title="Report says crowd-sourced fact checks on X fail to address flood of US election misinformation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Wagamaga"> /u/Wagamaga </a> <br/> <span><a href="https://apnews.com/article/x-musk-twitter-misinformation-ccdh-0fa4fec0f703369b93be248461e8005d">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggda20/report_says_crowdsourced_fact_checks_on_x_fail_to/">[comments]</a></span> </td></tr></table>

## Opera Browser Fixes Critical Data-Exposing Security Flaw in Recent Update
 - [https://www.reddit.com/r/technology/comments/1ggclfq/opera_browser_fixes_critical_dataexposing](https://www.reddit.com/r/technology/comments/1ggclfq/opera_browser_fixes_critical_dataexposing)
 - RSS feed: $source
 - date published: 2024-10-31T11:50:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggclfq/opera_browser_fixes_critical_dataexposing/"> <img src="https://external-preview.redd.it/Q8bkZw5cg8HauizG0Y5m1ro_sb6Dbwoxh4M09-LuNN4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0bc59bf005f673ea09f00187c2901fb97f6e18b9" alt="Opera Browser Fixes Critical Data-Exposing Security Flaw in Recent Update" title="Opera Browser Fixes Critical Data-Exposing Security Flaw in Recent Update" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/warkollons0"> /u/warkollons0 </a> <br/> <span><a href="https://www.technadu.com/opera-browser-fixes-critical-data-exposing-security-flaw-in-recent-update/554294/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggclfq/opera_browser_fixes_critical_dataexposing/">[comments]</a></span> </td></tr></table>

## New documentary reveals that 21,000 laborers have died working on Saudi Vision 2030, which includes NEOM, since construction began
 - [https://www.reddit.com/r/technology/comments/1ggbgw2/new_documentary_reveals_that_21000_laborers_have](https://www.reddit.com/r/technology/comments/1ggbgw2/new_documentary_reveals_that_21000_laborers_have)
 - RSS feed: $source
 - date published: 2024-10-31T10:42:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1ggbgw2/new_documentary_reveals_that_21000_laborers_have/"> <img src="https://external-preview.redd.it/edEVpQ0AQ6PYQLazj3DVd1e0tz5nX38I73dqL7gquYg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=af39c98145f396b6be2a7a2d055da9cce84b0b2a" alt="New documentary reveals that 21,000 laborers have died working on Saudi Vision 2030, which includes NEOM, since construction began" title="New documentary reveals that 21,000 laborers have died working on Saudi Vision 2030, which includes NEOM, since construction began" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/uhhhwhatok"> /u/uhhhwhatok </a> <br/> <span><a href="https://www.archpaper.com/2024/10/documentary-reveals-21000-workers-killed-saudi-vision-2030-neom/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1ggbgw2/new_documentary_reveals_that_21000_laborers_have/">[comments]</a></span> </td></tr></tab

## Microsoft CEO's pay rises 63% to $79m, despite devastating year for layoffs 2550 jobs lost in 2024.
 - [https://www.reddit.com/r/technology/comments/1gg9cu0/microsoft_ceos_pay_rises_63_to_79m_despite](https://www.reddit.com/r/technology/comments/1gg9cu0/microsoft_ceos_pay_rises_63_to_79m_despite)
 - RSS feed: $source
 - date published: 2024-10-31T08:02:54+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://www.eurogamer.net/microsoft-ceos-pay-rises-63-to-73m-despite-devastating-year-for-layoffs">https://www.eurogamer.net/microsoft-ceos-pay-rises-63-to-73m-despite-devastating-year-for-layoffs</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Marco_12343"> /u/Marco_12343 </a> <br/> <span><a href="https://www.reddit.com/r/technology/comments/1gg9cu0/microsoft_ceos_pay_rises_63_to_79m_despite/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gg9cu0/microsoft_ceos_pay_rises_63_to_79m_despite/">[comments]</a></span>

## Boeing allegedly overcharged the military 8,000% for airplane soap dispensers
 - [https://www.reddit.com/r/technology/comments/1gg7hyd/boeing_allegedly_overcharged_the_military_8000](https://www.reddit.com/r/technology/comments/1gg7hyd/boeing_allegedly_overcharged_the_military_8000)
 - RSS feed: $source
 - date published: 2024-10-31T05:38:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1gg7hyd/boeing_allegedly_overcharged_the_military_8000/"> <img src="https://external-preview.redd.it/h0IX9veo36gULiRCIzTvgnSUZIjO9RhH9Us39Q-ZQX0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2ca632f44350d21baa1f6de9ecded22010ef34b1" alt="Boeing allegedly overcharged the military 8,000% for airplane soap dispensers" title="Boeing allegedly overcharged the military 8,000% for airplane soap dispensers" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/unplug67"> /u/unplug67 </a> <br/> <span><a href="https://www.popsci.com/technology/boeing-soap-dispensers-audit/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gg7hyd/boeing_allegedly_overcharged_the_military_8000/">[comments]</a></span> </td></tr></table>

## Steam now requires developers to tell people when their games have kernel mode anticheat
 - [https://www.reddit.com/r/technology/comments/1gg6wni/steam_now_requires_developers_to_tell_people_when](https://www.reddit.com/r/technology/comments/1gg6wni/steam_now_requires_developers_to_tell_people_when)
 - RSS feed: $source
 - date published: 2024-10-31T04:58:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1gg6wni/steam_now_requires_developers_to_tell_people_when/"> <img src="https://external-preview.redd.it/uHfB-CwxdgajJIzAFy6yM-z9QLXLvRLEtGI_1F6QF8g.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8b7e1a1cc5971ae2a0b1602ee4a5195ab25a1617" alt="Steam now requires developers to tell people when their games have kernel mode anticheat" title="Steam now requires developers to tell people when their games have kernel mode anticheat" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/a_Ninja_b0y"> /u/a_Ninja_b0y </a> <br/> <span><a href="https://www.pcgamer.com/games/steam-now-requires-developers-to-tell-people-when-their-games-have-kernel-mode-anticheat/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gg6wni/steam_now_requires_developers_to_tell_people_when/">[comments]</a></span> </td></tr></table>

## 14-year-old named America’s top young scientist for pesticide detector
 - [https://www.reddit.com/r/technology/comments/1gg1sy9/14yearold_named_americas_top_young_scientist_for](https://www.reddit.com/r/technology/comments/1gg1sy9/14yearold_named_americas_top_young_scientist_for)
 - RSS feed: $source
 - date published: 2024-10-31T00:25:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1gg1sy9/14yearold_named_americas_top_young_scientist_for/"> <img src="https://external-preview.redd.it/fYEgMrttMvgA6uAKJ6_UM27f4H1Tf2T49Y0sHCZvs1A.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c6c7bc5946fe6db79102bdbf0d83401dd739909e" alt="14-year-old named America’s top young scientist for pesticide detector" title="14-year-old named America’s top young scientist for pesticide detector" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/upyoars"> /u/upyoars </a> <br/> <span><a href="https://interestingengineering.com/culture/america-top-young-scientist-sirish-subash">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gg1sy9/14yearold_named_americas_top_young_scientist_for/">[comments]</a></span> </td></tr></table>

## Jack Dorsey hits Tidal with another mass layoff: "We need to build like a startup again"
 - [https://www.reddit.com/r/technology/comments/1gg1b3z/jack_dorsey_hits_tidal_with_another_mass_layoff](https://www.reddit.com/r/technology/comments/1gg1b3z/jack_dorsey_hits_tidal_with_another_mass_layoff)
 - RSS feed: $source
 - date published: 2024-10-31T00:02:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/technology/comments/1gg1b3z/jack_dorsey_hits_tidal_with_another_mass_layoff/"> <img src="https://external-preview.redd.it/q89KNNMw_zOjoawObO_LLoLRp6nkZ3ZudXxmX83sm_U.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aae0c9bc6bd076a09b79860541a85cd82cfac817" alt="Jack Dorsey hits Tidal with another mass layoff: &quot;We need to build like a startup again&quot;" title="Jack Dorsey hits Tidal with another mass layoff: &quot;We need to build like a startup again&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/McFatty7"> /u/McFatty7 </a> <br/> <span><a href="https://fortune.com/2024/10/30/jack-dorsey-layoffs-streaming-music-app-tidal-block-leaked-email/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/technology/comments/1gg1b3z/jack_dorsey_hits_tidal_with_another_mass_layoff/">[comments]</a></span> </td></tr></table>

