# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #2221 - JD Vance
 - [https://www.youtube.com/watch?v=fRyyTAs1XY8](https://www.youtube.com/watch?v=fRyyTAs1XY8)
 - RSS feed: $source
 - date published: 2024-10-31T17:00:40+00:00

This episode is brought to you by AG1. Take ownership of your health with AG1 and get a FREE 1-year supply of Vitamin D3+K2 AND 5 free Travel Packs with your first subscription. Go to http://drinkag1.com/joerogan

This episode of The Joe Rogan Experience is brought to you by Call of Duty Black Ops 6. Available now at http://callofduty.com/blackops6

JD Vance is currently the 2024 Vice Presidential Candidate of the Republican Party. He is also an author and Marine veteran who has served since 2023 as the junior United States senator from Ohio.

