# Source:RP - Regiony, URL:https://regiony.rp.pl/rss/1441-regiony, language:pl-PL

## Na ratowanie cmentarnych zabytków. Wpłaty do puszki, ale i przelewem
 - [https://regiony.rp.pl/z-regionow/art41384501-na-ratowanie-cmentarnych-zabytkow-wplaty-do-puszki-ale-i-przelewem](https://regiony.rp.pl/z-regionow/art41384501-na-ratowanie-cmentarnych-zabytkow-wplaty-do-puszki-ale-i-przelewem)
 - RSS feed: $source
 - date published: 2024-10-31T15:59:06.916462+00:00

Nie tylko do puszek, ale i blikiem lub przez internet będzie można w tym roku złożyć datki na renowację grobów na Starych Powązkach w Warszawie. Kwesta organizowana jest tam po raz 50. Podobne zbiórki odbędą się na innych nekropoliach w Polsce. Na niektórych już trwają.

## Rower na co dzień w Białej Podlaskiej
 - [https://regiony.rp.pl/rowerem-przez-polske/art41383751-rower-na-co-dzien-w-bialej-podlaskiej](https://regiony.rp.pl/rowerem-przez-polske/art41383751-rower-na-co-dzien-w-bialej-podlaskiej)
 - RSS feed: $source
 - date published: 2024-10-31T13:51:28.897432+00:00

Trzykrotne zwycięstwo Białej Podlaskiej w rowerowym wyścigu o tytuł Rowerowej Stolicy Polski to fenomen. Maluchy ze żłobków, uczniowie, seniorzy, grupy powstałe w instytucjach i zakładach pracy – w czerwcu już po raz trzeci rowerowa społeczność miasta wykręciła rekord: tym razem to 1 mln 441 tys km!

## Małopolska – bogactwo oferty rowerowej
 - [https://regiony.rp.pl/rowerem-przez-polske/art41383251-malopolska-bogactwo-oferty-rowerowej](https://regiony.rp.pl/rowerem-przez-polske/art41383251-malopolska-bogactwo-oferty-rowerowej)
 - RSS feed: $source
 - date published: 2024-10-31T00:01:00+00:00

Województwo małopolskie to niekwestionowany lider turystyki rowerowej w Polsce i pionier w budowie ścieżek rowerowych na wałach rzek.

