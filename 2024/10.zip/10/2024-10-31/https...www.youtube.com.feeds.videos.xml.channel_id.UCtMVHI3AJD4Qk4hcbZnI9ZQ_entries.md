# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## I've Got A Stalker Problem...
 - [https://www.youtube.com/watch?v=iabPYA9uBcw](https://www.youtube.com/watch?v=iabPYA9uBcw)
 - RSS feed: $source
 - date published: 2024-10-31T16:27:09+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at a game where the only monster is one that slowly tracks you down in a crowd of people. The only way to get away is to run, hard enough when breathing is such a hassle. This is "Crowded. Followed" and I've been waiting for this one. Thanks for watching!
Like, Comment and Subscribe for more videos!

