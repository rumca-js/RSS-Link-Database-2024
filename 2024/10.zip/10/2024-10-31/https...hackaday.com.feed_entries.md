# Source:Hackaday, URL:https://hackaday.com/feed, language:en-US

## Bakelite to the Future – A 1950s Bluetooth Headset
 - [https://hackaday.com/2024/10/31/bakelite-to-the-future-a-1950s-bluetooth-headset](https://hackaday.com/2024/10/31/bakelite-to-the-future-a-1950s-bluetooth-headset)
 - RSS feed: $source
 - date published: 2024-10-31T23:00:58+00:00

<div><img width="800" height="609" src="https://hackaday.com/wp-content/uploads/2024/10/IMG_20241027_164108724-featured.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/IMG_20241027_164108724-featured.png 1536w, https://hackaday.com/wp-content/uploads/2024/10/IMG_20241027_164108724-featured.png?resize=250,190 250w, https://hackaday.com/wp-content/uploads/2024/10/IMG_20241027_164108724-featured.png?resize=400,304 400w, https://hackaday.com/wp-content/uploads/2024/10/IMG_20241027_164108724-featured.png?resize=800,609 800w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="731955" data-permalink="https://hackaday.com/2024/10/31/bakelite-to-the-future-a-1950s-bluetooth-headset/img_20241027_164108724-featured/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/IMG_20241027_164108724-featured.png" data-orig-siz

## Small Volumetric Lamp Spins at 6000 RPM
 - [https://hackaday.com/2024/10/31/small-volumetric-lamp-spins-at-6000-rpm](https://hackaday.com/2024/10/31/small-volumetric-lamp-spins-at-6000-rpm)
 - RSS feed: $source
 - date published: 2024-10-31T20:00:03+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/I-Made-a-Tiny-Volumetric-Lamp-5-35-screenshot.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/I-Made-a-Tiny-Volumetric-Lamp-5-35-screenshot.png 1920w, https://hackaday.com/wp-content/uploads/2024/10/I-Made-a-Tiny-Volumetric-Lamp-5-35-screenshot.png?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/I-Made-a-Tiny-Volumetric-Lamp-5-35-screenshot.png?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/10/I-Made-a-Tiny-Volumetric-Lamp-5-35-screenshot.png?resize=800,450 800w, https://hackaday.com/wp-content/uploads/2024/10/I-Made-a-Tiny-Volumetric-Lamp-5-35-screenshot.png?resize=1536,864 1536w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="731467" data-permalink="https://hackaday.com/2024/10/31/small-

## 3D Printing With a Hot Glue Gun
 - [https://hackaday.com/2024/10/31/3d-printing-with-a-hot-glue-gun](https://hackaday.com/2024/10/31/3d-printing-with-a-hot-glue-gun)
 - RSS feed: $source
 - date published: 2024-10-31T18:30:08+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/hot-glue-print-featured.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" loading="lazy" srcset="https://hackaday.com/wp-content/uploads/2024/10/hot-glue-print-featured.jpg 800w, https://hackaday.com/wp-content/uploads/2024/10/hot-glue-print-featured.jpg?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/hot-glue-print-featured.jpg?resize=400,225 400w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="730974" data-permalink="https://hackaday.com/2024/10/31/3d-printing-with-a-hot-glue-gun/hot-glue-print-featured/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/hot-glue-print-featured.jpg" data-orig-size="800,450" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&qu

## Supercon 2024 Flower SAO Badge Redrawing in KiCad
 - [https://hackaday.com/2024/10/31/supercon-2024-flower-sao-badge-redrawing-in-kicad](https://hackaday.com/2024/10/31/supercon-2024-flower-sao-badge-redrawing-in-kicad)
 - RSS feed: $source
 - date published: 2024-10-31T17:28:06+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/badge24-feature_a95c16.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/badge24-feature_a95c16.png 2939w, https://hackaday.com/wp-content/uploads/2024/10/badge24-feature_a95c16.png?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/badge24-feature_a95c16.png?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/10/badge24-feature_a95c16.png?resize=800,450 800w, https://hackaday.com/wp-content/uploads/2024/10/badge24-feature_a95c16.png?resize=1536,864 1536w, https://hackaday.com/wp-content/uploads/2024/10/badge24-feature_a95c16.png?resize=2048,1152 2048w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="731491" data-permalink="https://hackaday.com/2024/10/31/supercon-2024-flower-sao-badge-redrawing-in-k

## A Look Inside A Canadian Satellite TV Facility
 - [https://hackaday.com/2024/10/31/a-look-inside-a-canadian-satellite-tv-facility](https://hackaday.com/2024/10/31/a-look-inside-a-canadian-satellite-tv-facility)
 - RSS feed: $source
 - date published: 2024-10-31T15:30:00+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/Quick-Tour-of-CBC-_-Radio-Canada-Satellite-Facilities-0-37-screenshot.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/Quick-Tour-of-CBC-_-Radio-Canada-Satellite-Facilities-0-37-screenshot.png 1920w, https://hackaday.com/wp-content/uploads/2024/10/Quick-Tour-of-CBC-_-Radio-Canada-Satellite-Facilities-0-37-screenshot.png?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/Quick-Tour-of-CBC-_-Radio-Canada-Satellite-Facilities-0-37-screenshot.png?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/10/Quick-Tour-of-CBC-_-Radio-Canada-Satellite-Facilities-0-37-screenshot.png?resize=800,450 800w, https://hackaday.com/wp-content/uploads/2024/10/Quick-Tour-of-CBC-_-Radio-Canada-Satellite-Facilities-0-37-screenshot.png?r

## Voyager 1 Fault Forces Switch to S-Band
 - [https://hackaday.com/2024/10/31/voyager-1-fault-forces-switch-to-s-band](https://hackaday.com/2024/10/31/voyager-1-fault-forces-switch-to-s-band)
 - RSS feed: $source
 - date published: 2024-10-31T11:00:50+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2022/05/voyager_feat.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2022/05/voyager_feat.jpg 800w, https://hackaday.com/wp-content/uploads/2022/05/voyager_feat.jpg?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2022/05/voyager_feat.jpg?resize=400,225 400w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="538785" data-permalink="https://hackaday.com/2022/06/08/how-is-voyager-still-talking-after-all-these-years/voyager_feat/" data-orig-file="https://hackaday.com/wp-content/uploads/2022/05/voyager_feat.jpg" data-orig-size="800,450" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&

## Bogey Six O’clock!: The AN/APS-13 Tail Warning Radar
 - [https://hackaday.com/2024/10/31/bogey-six-oclock-the-an-aps-13-tail-warning-radar](https://hackaday.com/2024/10/31/bogey-six-oclock-the-an-aps-13-tail-warning-radar)
 - RSS feed: $source
 - date published: 2024-10-31T08:00:06+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/tail-warning-radar.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/tail-warning-radar.png 1920w, https://hackaday.com/wp-content/uploads/2024/10/tail-warning-radar.png?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/tail-warning-radar.png?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/10/tail-warning-radar.png?resize=800,450 800w, https://hackaday.com/wp-content/uploads/2024/10/tail-warning-radar.png?resize=1536,864 1536w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="730963" data-permalink="https://hackaday.com/2024/10/31/bogey-six-oclock-the-an-aps-13-tail-warning-radar/tail-warning-radar/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/tail-warning-radar.png" data-orig

## An Electric Vehicle Conversion With A Difference
 - [https://hackaday.com/2024/10/30/an-electric-vehicle-conversion-with-a-difference](https://hackaday.com/2024/10/30/an-electric-vehicle-conversion-with-a-difference)
 - RSS feed: $source
 - date published: 2024-10-31T05:00:48+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/10/electric-tractor-featured.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/electric-tractor-featured.jpg 800w, https://hackaday.com/wp-content/uploads/2024/10/electric-tractor-featured.jpg?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/10/electric-tractor-featured.jpg?resize=400,225 400w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="730959" data-permalink="https://hackaday.com/2024/10/30/an-electric-vehicle-conversion-with-a-difference/electric-tractor-featured-2/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/electric-tractor-featured.jpg" data-orig-size="800,450" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;

## KolibriOS: The Operating System That Fits on a 1.44 MB 3.5″ Floppy Disk
 - [https://hackaday.com/2024/10/30/kolibrios-the-operating-system-that-fits-on-a-1-44-mb-3-5-floppy-disk](https://hackaday.com/2024/10/30/kolibrios-the-operating-system-that-fits-on-a-1-44-mb-3-5-floppy-disk)
 - RSS feed: $source
 - date published: 2024-10-31T02:00:34+00:00

<div><img width="800" height="391" src="https://hackaday.com/wp-content/uploads/2024/10/michael_mjd_doom_on_kolibriOS.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/10/michael_mjd_doom_on_kolibriOS.jpg 1313w, https://hackaday.com/wp-content/uploads/2024/10/michael_mjd_doom_on_kolibriOS.jpg?resize=250,122 250w, https://hackaday.com/wp-content/uploads/2024/10/michael_mjd_doom_on_kolibriOS.jpg?resize=400,196 400w, https://hackaday.com/wp-content/uploads/2024/10/michael_mjd_doom_on_kolibriOS.jpg?resize=800,391 800w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="730875" data-permalink="https://hackaday.com/2024/10/30/kolibrios-the-operating-system-that-fits-on-a-1-44-mb-3-5-floppy-disk/michael_mjd_doom_on_kolibrios/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/10/michael_mjd_doom_on_kolibriOS.jpg" data-o

