# Source:Tehran Times, URL:https://www.tehrantimes.com/rss, language:en-US

## Sohmor mayor among 3 martyred in Israeli strike on Baaloul
 - [https://www.tehrantimes.com/news/505250/Sohmor-mayor-among-3-martyred-in-Israeli-strike-on-Baaloul](https://www.tehrantimes.com/news/505250/Sohmor-mayor-among-3-martyred-in-Israeli-strike-on-Baaloul)
 - RSS feed: $source
 - date published: 2024-10-20T19:06:47+00:00

BEIRUT - Since the start of the Israeli full-scale war on Lebanon on September 23, the occupation army has been deliberately targeting all forms of basic life in all regions. There is no safe place in Lebanon. Everyone is targeted.

## Israel kills Iranian woman in Lebanon, Tehran vows retribution 
 - [https://www.tehrantimes.com/news/505230/Israel-kills-Iranian-woman-in-Lebanon-Tehran-vows-retribution](https://www.tehrantimes.com/news/505230/Israel-kills-Iranian-woman-in-Lebanon-Tehran-vows-retribution)
 - RSS feed: $source
 - date published: 2024-10-20T19:04:22+00:00

TEHRAN – Iran has vowed to hold Israel accountable after the regime killed an Iranian woman and her Lebanese husband in northern Beirut, targeting the couple’s car and then pursuing them with drones after they fled on foot. 
    

## Pezeshkian to meet with Egyptian counterpart in Russia
 - [https://www.tehrantimes.com/news/505231/Pezeshkian-to-meet-with-Egyptian-counterpart-in-Russia](https://www.tehrantimes.com/news/505231/Pezeshkian-to-meet-with-Egyptian-counterpart-in-Russia)
 - RSS feed: $source
 - date published: 2024-10-20T19:02:28+00:00

TEHRAN – Iranian President Masoud Pezeshkian is scheduled to hold a bilateral meeting with Egyptian President Abdel Fattah El-Sisi on the sidelines of the upcoming BRICS summit in Russia, Arab media reported.

## Saudi TV's new role: A mouthpiece for US and Israel assassination campaigns
 - [https://www.tehrantimes.com/news/505232/Saudi-TV-s-new-role-A-mouthpiece-for-US-and-Israel-assassination](https://www.tehrantimes.com/news/505232/Saudi-TV-s-new-role-A-mouthpiece-for-US-and-Israel-assassination)
 - RSS feed: $source
 - date published: 2024-10-20T19:02:13+00:00

TEHRAN- The recent controversy ignited by a Saudi-owned television channel has spotlighted the animosity of certain Arab states towards the Palestinian resistance and their struggle against the Israeli occupation.

## Beit Lahiya bloodshed: Palestinians pay the price for Arab and Western leaders' inaction
 - [https://www.tehrantimes.com/news/505233/Beit-Lahiya-bloodshed-Palestinians-pay-the-price-for-Arab-and](https://www.tehrantimes.com/news/505233/Beit-Lahiya-bloodshed-Palestinians-pay-the-price-for-Arab-and)
 - RSS feed: $source
 - date published: 2024-10-20T19:01:27+00:00

TEHRAN- Israel’s weekend massacre of Palestinian people in the town of Beit Lahiya in the northern Gaza Strip has once again underscored the inaction of Arab and Western leaders in the face of the regime’s appalling atrocities.

## Hezbollah escalates missile attacks on Israel
 - [https://www.tehrantimes.com/news/505234/Hezbollah-escalates-missile-attacks-on-Israel](https://www.tehrantimes.com/news/505234/Hezbollah-escalates-missile-attacks-on-Israel)
 - RSS feed: $source
 - date published: 2024-10-20T18:58:34+00:00

TEHRAN- Sirens were sounding in Haifa and its surroundings including Krayot with multiple explosions heard in Haifa, Israeli media reported.

## Henrik Ibsen’s “Ghosts” to be staged at Molavi Theater
 - [https://www.tehrantimes.com/news/505237/Henrik-Ibsen-s-Ghosts-to-be-staged-at-Molavi-Theater](https://www.tehrantimes.com/news/505237/Henrik-Ibsen-s-Ghosts-to-be-staged-at-Molavi-Theater)
 - RSS feed: $source
 - date published: 2024-10-20T18:56:23+00:00

TEHRAN-Molavi Theater Hall in Tehran will host the play “Ghosts,” written by the Norwegian playwright Henrik Ibsen from October 22.

## Arab war instead of Israeli war
 - [https://www.tehrantimes.com/news/505238/Arab-war-instead-of-Israeli-war](https://www.tehrantimes.com/news/505238/Arab-war-instead-of-Israeli-war)
 - RSS feed: $source
 - date published: 2024-10-20T18:55:58+00:00

TEHRAN - Shargh devoted its editorial to the position of the European Union regarding the three Iranian islands and said: The position of the EU regarding the "occupation" of the three islands by Iran has a clear message, and that is that the possible future conflict between Iran and Israel will turn into a war between the Arabs and Iran.

## 14894
 - [https://www.tehrantimes.com/news/505251/14894](https://www.tehrantimes.com/news/505251/14894)
 - RSS feed: $source
 - date published: 2024-10-20T18:37:01+00:00

None

## Ryan Crocker: I foresee a very long insurgency by Hamas
 - [https://www.tehrantimes.com/news/505249/Ryan-Crocker-I-foresee-a-very-long-insurgency-by-Hamas](https://www.tehrantimes.com/news/505249/Ryan-Crocker-I-foresee-a-very-long-insurgency-by-Hamas)
 - RSS feed: $source
 - date published: 2024-10-20T18:32:57+00:00

TEHRAN - Former US ambassador Ryan Crocker, a veteran diplomat known as “America’s Lawrence of Arabia” for his deep understanding of the Middle East, tells Politico that the Israelis have forgotten their own recent history.

## 'Targets ready' for future strikes, Iran FM warns as potential Israeli attack looms
 - [https://www.tehrantimes.com/news/505241/Targets-ready-for-future-strikes-Iran-FM-warns-as-potential](https://www.tehrantimes.com/news/505241/Targets-ready-for-future-strikes-Iran-FM-warns-as-potential)
 - RSS feed: $source
 - date published: 2024-10-20T18:32:39+00:00

TEHRAN – Iran’s Foreign Minister Abbas Araqchi has issued a stark warning, stating that Iran has "identified all its targets" in the occupied territories and is prepared to retaliate against Israel in response to any military strike.

## Iran’s high council for human rights denounces rampant Israeli aggression
 - [https://www.tehrantimes.com/news/505247/Iran-s-high-council-for-human-rights-denounces-rampant-Israeli](https://www.tehrantimes.com/news/505247/Iran-s-high-council-for-human-rights-denounces-rampant-Israeli)
 - RSS feed: $source
 - date published: 2024-10-20T18:32:19+00:00

TEHRAN – Iran’s High Council for Human Rights has issued a strong condemnation of the Israeli regime's acts of terror, including the assassination and massacre of Palestinians and the Resistance leaders.

## Hungary’s ambassador summoned by Iran over EU-GCC statement on Persian Gulf islands
 - [https://www.tehrantimes.com/news/505242/Hungary-s-ambassador-summoned-by-Iran-over-EU-GCC-statement-on](https://www.tehrantimes.com/news/505242/Hungary-s-ambassador-summoned-by-Iran-over-EU-GCC-statement-on)
 - RSS feed: $source
 - date published: 2024-10-20T18:31:05+00:00

TEHRAN – The Hungarian ambassador to Iran, Giola Peto, was summoned to the Iranian Foreign Ministry following a joint statement by the European Union (EU) and the Persian Gulf Cooperation Council (GCC) that reiterated claims over three islands in the Persian Gulf, a move Iran strongly opposes.

## Tehran rejects claims of involvement in drone attack on Netanyahu's residence
 - [https://www.tehrantimes.com/news/505243/Tehran-rejects-claims-of-involvement-in-drone-attack-on-Netanyahu-s](https://www.tehrantimes.com/news/505243/Tehran-rejects-claims-of-involvement-in-drone-attack-on-Netanyahu-s)
 - RSS feed: $source
 - date published: 2024-10-20T18:30:41+00:00

TEHRAN – Iran’s Permanent Mission to the United Nations has responded to claims surrounding a drone attack on the residence of Israeli Prime Minister Benjamin Netanyahu, distancing itself from the incident and attributing responsibility to the Lebanese Resistance group, Hezbollah.

## Sinwar’s dedication to Resistance delivered critical blow to Israel, says Iranian commander
 - [https://www.tehrantimes.com/news/505244/Sinwar-s-dedication-to-Resistance-delivered-critical-blow-to](https://www.tehrantimes.com/news/505244/Sinwar-s-dedication-to-Resistance-delivered-critical-blow-to)
 - RSS feed: $source
 - date published: 2024-10-20T18:30:03+00:00

TEHRAN – The commander of Iran’s Khatam al-Anbia Central Headquarters Rashid has praised Sinwar’s leadership and declared that his efforts had escalated the resistance against Israel, delivering a significant blow to the regime’s power.

## Hamas to remain a powerful force despite loss of Sinwar: Iran FM
 - [https://www.tehrantimes.com/news/505245/Hamas-to-remain-a-powerful-force-despite-loss-of-Sinwar-Iran](https://www.tehrantimes.com/news/505245/Hamas-to-remain-a-powerful-force-despite-loss-of-Sinwar-Iran)
 - RSS feed: $source
 - date published: 2024-10-20T18:29:44+00:00

TEHRAN – Iranian Foreign Minister Abbas Araqchi has declared that the Palestinian Resistance group Hamas remains a powerful force, undeterred by the recent loss of its leader, Yahya Sinwar.

## Qalibaf upbraids Persian Gulf states for picking quarrels with Iran instead of focusing on Israel
 - [https://www.tehrantimes.com/news/505246/Qalibaf-upbraids-Persian-Gulf-states-for-picking-quarrels-with](https://www.tehrantimes.com/news/505246/Qalibaf-upbraids-Persian-Gulf-states-for-picking-quarrels-with)
 - RSS feed: $source
 - date published: 2024-10-20T18:29:20+00:00

TEHRAN – Iranian Parliament Speaker Mohammad Baqer Qalibaf strongly condemned the Persian Gulf Cooperation Council (GCC) for its recent accusations against Iran, urging the regional body to redirect its efforts toward halting Israeli aggression rather than making baseless claims.

## Decoding a leak
 - [https://www.tehrantimes.com/news/505248/Decoding-a-leak](https://www.tehrantimes.com/news/505248/Decoding-a-leak)
 - RSS feed: $source
 - date published: 2024-10-20T18:28:52+00:00

TEHRAN – On Friday, a telegram channel released what it said were 'top secret' U.S. intelligence documents prepared by the U.S. Geospatial Intelligence Agency. The leaked documents spun out Washington’s assessment of the Israeli Air Force’s alleged preparations to attack Iran.  

## 2024 IONS Maritime Exercise concludes in Iran’s southern waters
 - [https://www.tehrantimes.com/news/505229/2024-IONS-Maritime-Exercise-concludes-in-Iran-s-southern-waters](https://www.tehrantimes.com/news/505229/2024-IONS-Maritime-Exercise-concludes-in-Iran-s-southern-waters)
 - RSS feed: $source
 - date published: 2024-10-20T15:58:07+00:00

TEHRAN – The IONS 2024 joint naval exercise, concluded on Sunday with a grand naval parade showcasing the participating surface vessels. 

## IAF cinematheque to show Al Pacino’s “Looking for Richard”
 - [https://www.tehrantimes.com/news/505236/IAF-cinematheque-to-show-Al-Pacino-s-Looking-for-Richard](https://www.tehrantimes.com/news/505236/IAF-cinematheque-to-show-Al-Pacino-s-Looking-for-Richard)
 - RSS feed: $source
 - date published: 2024-10-20T15:57:08+00:00

TEHRAN- The 1996 American documentary film “Looking for Richard” directed by the renowned actor Al Pacino will be screened at the cinematheque of the Iranian Artists Forum (IAF) in Tehran on Wednesday.

## “The Old Bachelor” to premiere in UK at London Breeze Film Festival
 - [https://www.tehrantimes.com/news/505235/The-Old-Bachelor-to-premiere-in-UK-at-London-Breeze-Film-Festival](https://www.tehrantimes.com/news/505235/The-Old-Bachelor-to-premiere-in-UK-at-London-Breeze-Film-Festival)
 - RSS feed: $source
 - date published: 2024-10-20T15:50:00+00:00

TEHRAN-The critically acclaimed Iranian feature film “The Old Bachelor” directed by Oktay Baraheni will have its UK premiere at the London Breeze Film Festival (LBFF), due to be held form October 23 to 27.

## Tehran to host intl. conference on digital games 
 - [https://www.tehrantimes.com/news/505214/Tehran-to-host-intl-conference-on-digital-games](https://www.tehrantimes.com/news/505214/Tehran-to-host-intl-conference-on-digital-games)
 - RSS feed: $source
 - date published: 2024-10-20T15:45:20+00:00

TEHRAN- Tehran is set to host the 7th edition of an international conference on digital games on December 10 and 11. 

## “Tutankhamun: The Book of Shadows” comes to Iranian bookstores
 - [https://www.tehrantimes.com/news/505215/Tutankhamun-The-Book-of-Shadows-comes-to-Iranian-bookstores](https://www.tehrantimes.com/news/505215/Tutankhamun-The-Book-of-Shadows-comes-to-Iranian-bookstores)
 - RSS feed: $source
 - date published: 2024-10-20T15:43:45+00:00

TEHRAN- A Persian translation of British author Nick Drake’s novel “Tutankhamun: The Book of Shadows” has recently been published by Qoqnus Publications in Tehran.

## Leader’s advisor tells UAE to ‘review historical records’ as dispute over Persian Gulf islands feste
 - [https://www.tehrantimes.com/news/505206/Leader-s-advisor-tells-UAE-to-review-historical-records-as](https://www.tehrantimes.com/news/505206/Leader-s-advisor-tells-UAE-to-review-historical-records-as)
 - RSS feed: $source
 - date published: 2024-10-20T15:42:58+00:00

TEHRAN – The chairman of Iran's Strategic Council of Foreign Relations has urged the United Arab Emirates to reconsider its current stance of antagonism towards Iran. 

## Georgia transfers 17 Iranian prisoners back to Iran
 - [https://www.tehrantimes.com/news/505205/Georgia-transfers-17-Iranian-prisoners-back-to-Iran](https://www.tehrantimes.com/news/505205/Georgia-transfers-17-Iranian-prisoners-back-to-Iran)
 - RSS feed: $source
 - date published: 2024-10-20T15:41:30+00:00

TEHRAN – Iran has repatriated 17 Iranian prisoners from Georgia, according to Askar Jalalian, Deputy for Human Rights and International Affairs of the Iranian Ministry of Justice. 

## Iran criticizes US, UK for 'dangerous' involvement in Israeli escalation
 - [https://www.tehrantimes.com/news/505204/Iran-criticizes-US-UK-for-dangerous-involvement-in-Israeli](https://www.tehrantimes.com/news/505204/Iran-criticizes-US-UK-for-dangerous-involvement-in-Israeli)
 - RSS feed: $source
 - date published: 2024-10-20T15:36:08+00:00

TEHRAN – The spokesperson for the Iranian foreign ministry characterized the attacks by the United States and the United Kingdom on regions of Sana'a and Saada in Yemen as serious breaches of the United Nations Charter and international law, particularly regarding the prohibition of force and the respect for national sovereignty. 

## Archaeological survey in northern Iran uncovers 4,000-year-old artifacts
 - [https://www.tehrantimes.com/news/505228/Archaeological-survey-in-northern-Iran-uncovers-4-000-year-old](https://www.tehrantimes.com/news/505228/Archaeological-survey-in-northern-Iran-uncovers-4-000-year-old)
 - RSS feed: $source
 - date published: 2024-10-20T14:27:31+00:00

TEHRAN - An archaeological survey aimed at defining the boundaries and proposing a protected zone for Tepe Kafshgiri, a historic hill in Gorgan county of Golestan province, has concluded under the supervision of the Research Institute of Cultural Heritage and Tourism.

## 24 tourism projects planned in Hormozgan with $4 million investment
 - [https://www.tehrantimes.com/news/505227/24-tourism-projects-planned-in-Hormozgan-with-4-million-investment](https://www.tehrantimes.com/news/505227/24-tourism-projects-planned-in-Hormozgan-with-4-million-investment)
 - RSS feed: $source
 - date published: 2024-10-20T14:24:35+00:00

TEHRAN – Hormozgan’s tourism directorate has approved 24 projects to be developed across the southern Iranian province, backed by an estimated investment of about $4 million.

## Commentary book on Great Mongol Shahnameh to be unveiled in Tehran
 - [https://www.tehrantimes.com/news/505226/Commentary-book-on-Great-Mongol-Shahnameh-to-be-unveiled-in-Tehran](https://www.tehrantimes.com/news/505226/Commentary-book-on-Great-Mongol-Shahnameh-to-be-unveiled-in-Tehran)
 - RSS feed: $source
 - date published: 2024-10-20T14:22:21+00:00

TEHRAN - A Persian translation of a commentary book on the Great Ilkhanid Shahnameh, which is one of the oldest and most valuable illustrated manuscripts remaining from Ferdowsi’s Shahnameh, is set to be unveiled in Tehran on Tuesday.

## Standardization project for lighting and landscaping begins at Hafez mausoleum
 - [https://www.tehrantimes.com/news/505225/Standardization-project-for-lighting-and-landscaping-begins-at](https://www.tehrantimes.com/news/505225/Standardization-project-for-lighting-and-landscaping-begins-at)
 - RSS feed: $source
 - date published: 2024-10-20T14:12:19+00:00

TEHRAN – Fars province’s tourism chief has announced the launch of a project aimed at standardizing the landscaping, lighting, and visitor signage at Hafez mausoleum, a historical and cultural site where the 14th-century Persian poet is laid to rest.

## Haj Agha Ali’s house: a glimpse into Iran’s architectural heritage
 - [https://www.tehrantimes.com/news/505224/Haj-Agha-Ali-s-house-a-glimpse-into-Iran-s-architectural-heritage](https://www.tehrantimes.com/news/505224/Haj-Agha-Ali-s-house-a-glimpse-into-Iran-s-architectural-heritage)
 - RSS feed: $source
 - date published: 2024-10-20T14:05:06+00:00

TEHRAN - Located near Rafsanjan in Kerman province, southern Iran, Haj Agha Ali’s house stands as one of the largest and most striking adobe residences in Iran, attracting visitors with its grandeur and intricate design.

## Mosimane’s duty bringing back Esteghlal’s heydays
 - [https://www.tehrantimes.com/news/505223/Mosimane-s-duty-bringing-back-Esteghlal-s-heydays](https://www.tehrantimes.com/news/505223/Mosimane-s-duty-bringing-back-Esteghlal-s-heydays)
 - RSS feed: $source
 - date published: 2024-10-20T13:11:45+00:00

TEHRAN - Iran’s football powerhouse, Esteghlal, are currently in a tumultuous period. Having finished as runners-up last season under Javad Nekounam, the club's recent form has been a stark contrast to their previous success. A series of poor results led to Nekounam's resignation, despite having personally assembled the squad. The club signed every player that the former head coach wanted, but the results were poor.

## Foolad, Shahdab discover fate in 2024 FIVB Volleyball Club World Championship
 - [https://www.tehrantimes.com/news/505222/Foolad-Shahdab-discover-fate-in-2024-FIVB-Volleyball-Club-World](https://www.tehrantimes.com/news/505222/Foolad-Shahdab-discover-fate-in-2024-FIVB-Volleyball-Club-World)
 - RSS feed: $source
 - date published: 2024-10-20T12:24:19+00:00

TEHRAN – Iranian teams Foolad Sirjan and Shahdab Yazd discovered their opponents in the 2024 FIVB Volleyball Men's Club World Championship.

## Artificial intelligence to help protect natural areas
 - [https://www.tehrantimes.com/news/505221/Artificial-intelligence-to-help-protect-natural-areas](https://www.tehrantimes.com/news/505221/Artificial-intelligence-to-help-protect-natural-areas)
 - RSS feed: $source
 - date published: 2024-10-20T12:12:29+00:00

TEHRAN – The Department of Environment plans to utilize systems based on artificial intelligence to help manage and protect natural areas across the country.

## National determination, collaborative plans essential for disaster risk reduction
 - [https://www.tehrantimes.com/news/505219/National-determination-collaborative-plans-essential-for-disaster](https://www.tehrantimes.com/news/505219/National-determination-collaborative-plans-essential-for-disaster)
 - RSS feed: $source
 - date published: 2024-10-20T12:09:46+00:00

TEHRAN –Reducing the risks posed by natural disasters and climate change requires national determination and collaborative plans, Alireza Raeisi, an official with the health ministry, has said.

## Iranian university, Russian academy to enhance ties
 - [https://www.tehrantimes.com/news/505217/Iranian-university-Russian-academy-to-enhance-ties](https://www.tehrantimes.com/news/505217/Iranian-university-Russian-academy-to-enhance-ties)
 - RSS feed: $source
 - date published: 2024-10-20T12:03:39+00:00

TEHRAN – Allameh Tabatabai University of Tehran and the Russian Presidential Academy of National Economy and Public Administration (RANEPA) have signed a memorandum of understanding (MOU) to boost scientific cooperation.

## Iranian women make history in 2024 Canoe Polo World Championships
 - [https://www.tehrantimes.com/news/505210/Iranian-women-make-history-in-2024-Canoe-Polo-World-Championships](https://www.tehrantimes.com/news/505210/Iranian-women-make-history-in-2024-Canoe-Polo-World-Championships)
 - RSS feed: $source
 - date published: 2024-10-20T11:53:20+00:00

TEHRAN – Iran’s women’s team qualified for the World Games 2025 to be held in Chengdu, China.

## TEDPIX falls nearly 20,000 points on Sunday
 - [https://www.tehrantimes.com/news/505213/TEDPIX-falls-nearly-20-000-points-on-Sunday](https://www.tehrantimes.com/news/505213/TEDPIX-falls-nearly-20-000-points-on-Sunday)
 - RSS feed: $source
 - date published: 2024-10-20T11:41:30+00:00

TEHRAN- TEDPIX, the main index of the Tehran Stock Exchange (TSE), fell 19,959 points to 2,021,117 on Sunday, which is the second day of the Iranian calendar week.

## Iran marking national bone health week
 - [https://www.tehrantimes.com/news/505212/Iran-marking-national-bone-health-week](https://www.tehrantimes.com/news/505212/Iran-marking-national-bone-health-week)
 - RSS feed: $source
 - date published: 2024-10-20T11:32:58+00:00

TEHRAN –The national bone health week is being observed in the country from October 19 to 25, aiming to raise public awareness on osteoporosis.

## Container operation rises 5% in Iran’s ports in H1
 - [https://www.tehrantimes.com/news/505209/Container-operation-rises-5-in-Iran-s-ports-in-H1](https://www.tehrantimes.com/news/505209/Container-operation-rises-5-in-Iran-s-ports-in-H1)
 - RSS feed: $source
 - date published: 2024-10-20T10:31:33+00:00

TEHRAN- Based on the data released by Iranian Transport and Urban Development Ministry, the container operation has increased five percent in the ports of country during the first half of the current Iranian calendar year (March 20-September 21), as compared to the same period of time in the past year.

## Over $9.2b invested in water, wastewater projects
 - [https://www.tehrantimes.com/news/505208/Over-9-2b-invested-in-water-wastewater-projects](https://www.tehrantimes.com/news/505208/Over-9-2b-invested-in-water-wastewater-projects)
 - RSS feed: $source
 - date published: 2024-10-20T10:28:13+00:00

TEHRAN – Iran’s National Water and Wastewater Engineering Company has managed to attract 4.6 quadrillion rials (over $9.2 billion) of investment in the country’s water and wastewater projects, an official with the company said.

## Iran, China stress promoting trade ties, exchanging business delegations
 - [https://www.tehrantimes.com/news/505207/Iran-China-stress-promoting-trade-ties-exchanging-business](https://www.tehrantimes.com/news/505207/Iran-China-stress-promoting-trade-ties-exchanging-business)
 - RSS feed: $source
 - date published: 2024-10-20T10:24:06+00:00

TEHRAN – In a meeting between the head of the Tehran Chamber of Commerce, Industries, Mines and Agriculture (TCCIMA) Mahmoud Najafi-Arab and Zong Pei Wu, the ambassador of the People's Republic of China in Iran, the two sides stressed promoting trade ties and the exchange of business delegations between the two countries.

## Iran, Iraq to build border terminal along Shalamcheh-Basra railway
 - [https://www.tehrantimes.com/news/505203/Iran-Iraq-to-build-border-terminal-along-Shalamcheh-Basra-railway](https://www.tehrantimes.com/news/505203/Iran-Iraq-to-build-border-terminal-along-Shalamcheh-Basra-railway)
 - RSS feed: $source
 - date published: 2024-10-20T10:22:53+00:00

TEHRAN - Iran and Iraq railway officials, during a field visit to the Shalamcheh-Basra railway, met and held talks at Iran’s Arvand Free Zone and agreed on building Shalamcheh border terminal along the Shalamcheh-Basra railway.

## ‘Iran ready to host TRACECA ministerial meeting’
 - [https://www.tehrantimes.com/news/505201/Iran-ready-to-host-TRACECA-ministerial-meeting](https://www.tehrantimes.com/news/505201/Iran-ready-to-host-TRACECA-ministerial-meeting)
 - RSS feed: $source
 - date published: 2024-10-20T08:21:31+00:00

TEHRAN – Iranian Transport and Urban Development Minister Farzaneh Sadegh has expressed Iran’s readiness for hosting the upcoming meeting of the TRACECA ministers which is due to be held in February 2025.

## Cultural collaboration showcases Iranian rugs & Malaysian textiles and art in Tehran
 - [https://www.tehrantimes.com/news/505202/Cultural-collaboration-showcases-Iranian-rugs-Malaysian-textiles](https://www.tehrantimes.com/news/505202/Cultural-collaboration-showcases-Iranian-rugs-Malaysian-textiles)
 - RSS feed: $source
 - date published: 2024-10-20T08:19:19+00:00

TEHRAN– The Embassy of Malaysia in Tehran proudly hosted “Threads of Heritage: Persian and Malaysian Artistry”, a cultural event showcasing the timeless beauty and craftsmanship of Persian carpets and Malaysian traditional textiles and art.

## TehranTimes' journalist in interview with CGTN
 - [https://www.tehrantimes.com/news/505199/TehranTimes-journalist-in-interview-with-CGTN](https://www.tehrantimes.com/news/505199/TehranTimes-journalist-in-interview-with-CGTN)
 - RSS feed: $source
 - date published: 2024-10-20T07:55:30+00:00

None

## Iran basketball coach Manolopoulos returns to Tehran
 - [https://www.tehrantimes.com/news/505198/Iran-basketball-coach-Manolopoulos-returns-to-Tehran](https://www.tehrantimes.com/news/505198/Iran-basketball-coach-Manolopoulos-returns-to-Tehran)
 - RSS feed: $source
 - date published: 2024-10-20T07:53:54+00:00

TEHRAN – Iran national basketball team head coach Sotirios Alex Manolopoulos returned to Tehran Saturday evening.

