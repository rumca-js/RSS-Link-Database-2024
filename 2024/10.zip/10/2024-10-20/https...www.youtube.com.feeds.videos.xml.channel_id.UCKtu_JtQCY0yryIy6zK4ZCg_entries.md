# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## The crazy benefits of NOT using layers ❌ (digital art tutorial)
 - [https://www.youtube.com/watch?v=GG019qhs5wg](https://www.youtube.com/watch?v=GG019qhs5wg)
 - RSS feed: $source
 - date published: 2024-10-20T12:30:24+00:00

🧙‍♂️ ART School is 5 years old!! Get a MASSIVE 33% OFF the ART School: Digital Artists program 🎓 http://cgart.school until October 31st 2024! 

Join the program and access our private art community on Discord! WE JUST PASSED 25,000 ENROLLED STUDENTS! 💥 Nani?! What are you waiting for!

Reference packs: https://tinyurl.com/tnt2b6sp

🖌 Get my brushes for FREE here: http://cbr.sh/befto

💻 HOW TO USE THE FREE BRUSHES: https://youtu.be/8EC1Ibda3BI
🖌 Clip Studio Paint MB LENGENDARY Lineart Brush: http://cbr.sh/vb2lt6
🖌 Get my advanced brush set here: http://cbr.sh/btml0
🚀 My Store: https://cubebrush.co/mb
🎨 Practice files download: http://cbr.sh/xsqi64

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

FOLLOW ME ON SOCIAL MEDIA:
✏ Twitter: https://twitter.com/bluefley
📷 Instagram: https://instagram.com/bluefley

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 


#learntodraw #drawingtutorial #drawingprocess

