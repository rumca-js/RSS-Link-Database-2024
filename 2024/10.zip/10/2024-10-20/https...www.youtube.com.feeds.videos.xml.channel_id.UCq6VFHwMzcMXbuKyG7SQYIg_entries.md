# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Worst Father of the Year
 - [https://www.youtube.com/watch?v=gGmzl5P_z8k](https://www.youtube.com/watch?v=gGmzl5P_z8k)
 - RSS feed: $source
 - date published: 2024-10-20T18:30:36+00:00

Get Goof Juice https://gamersupps.gg/?ref=moist
This is the greatest terrible father of All Time
Get a Starforge PC https://starforgepc.com/moist-yt
Merch https://moistglobal.com/
Comics https://badegg.co/

## Dark Souls is Still Amazing
 - [https://www.youtube.com/watch?v=_MrYA_I7hMU](https://www.youtube.com/watch?v=_MrYA_I7hMU)
 - RSS feed: $source
 - date published: 2024-10-20T16:11:19+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

