# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Serbian President Speaks to Putin for First Time in 2.5 Years – Presidency
 - [https://www.themoscowtimes.com/2024/10/20/serbian-president-speaks-to-putin-for-first-time-in-25-years-presidency-a86751](https://www.themoscowtimes.com/2024/10/20/serbian-president-speaks-to-putin-for-first-time-in-25-years-presidency-a86751)
 - RSS feed: $source
 - date published: 2024-10-20T13:25:32.590079+00:00


								Serbia, a European Union candidate, has refused to impose sanctions on Russia, maintaining close and friendly relations — but Vucic has had limited bilateral talks with Putin.			

## Ukraine Drones Target Major Russian Explosive Plant
 - [https://www.themoscowtimes.com/2024/10/20/ukraine-drones-target-major-russian-explosive-plant-a86752](https://www.themoscowtimes.com/2024/10/20/ukraine-drones-target-major-russian-explosive-plant-a86752)
 - RSS feed: $source
 - date published: 2024-10-20T13:25:30.365425+00:00


								The Sverdlov plant in the Nizhny Novgorod region is one of Russia's largest manufacturers of military explosives.			

