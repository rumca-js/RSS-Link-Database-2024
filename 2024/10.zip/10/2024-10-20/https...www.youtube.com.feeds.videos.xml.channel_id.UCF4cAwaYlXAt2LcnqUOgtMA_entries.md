# Source:A Vox in the Void, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF4cAwaYlXAt2LcnqUOgtMA, language:en

## "THUNDER AND LIGHTNING" - UNOFFICIAL 40K AUDIO - THE THUNDER WARRIORS
 - [https://www.youtube.com/watch?v=S5BJ06LK7zI](https://www.youtube.com/watch?v=S5BJ06LK7zI)
 - RSS feed: $source
 - date published: 2024-10-20T16:56:39+00:00

"THUNDER AND LIGHTNING" - AN UNOFFICIAL THUNDER WARRIOR STORY BY TOD TOWNSEND.

Thankyou Tod for crafting this amazing story for the channel. I couldn't have asked for more!

Read along here:

https://archiveofourown.org/works/59044300/chapters/150528964?view_adult=true

COVER ART: Thunder Warriors by Ronan Toulhoat 

https://www.instagram.com/ronan.toulhoat/

Incredible music by @DreamClinicOfficial 

https://www.youtube.com/watch?v=L6htbEVUK38&t=250s

ICARUS @Sunchaserofficial 

https://www.youtube.com/watch?v=WXbT_TcQGPE&list=RDEM24qmC7R6WkcfVGls8aWYNQ&start_radio=1

additional music and sound effects:  Epidemic Sound

