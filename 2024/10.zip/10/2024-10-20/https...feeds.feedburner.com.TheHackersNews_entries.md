# Source:The Hacker News, URL:https://feeds.feedburner.com/TheHackersNews, language:en-US

## Hackers Exploit Roundcube Webmail XSS Vulnerability to Steal Login Credentials
 - [https://thehackernews.com/2024/10/hackers-exploit-roundcube-webmail-xss.html](https://thehackernews.com/2024/10/hackers-exploit-roundcube-webmail-xss.html)
 - RSS feed: $source
 - date published: 2024-10-20T09:25:19.903857+00:00

Unknown threat actors have been observed attempting to exploit a now-patched security flaw in the open-source Roundcube webmail software as part of a phishing attack designed to steal user credentials.
Russian cybersecurity company Positive Technologies said it discovered last month that an email was sent to an unspecified governmental organization located in one of the Commonwealth of

