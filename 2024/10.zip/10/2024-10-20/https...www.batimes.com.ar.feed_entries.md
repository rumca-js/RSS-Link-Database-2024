# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## Messi's Inter Miami to play in FIFA's Club World Cup in 2025
 - [https://www.batimes.com.ar/news/sports/messis-inter-miami-to-play-in-fifas-club-world-cup-in-2025.phtml](https://www.batimes.com.ar/news/sports/messis-inter-miami-to-play-in-fifas-club-world-cup-in-2025.phtml)
 - RSS feed: $source
 - date published: 2024-10-20T11:09:01+00:00

<p><img src="https://fotos.perfil.com/2024/10/20/trim/540/304/inter-miami-supporters-shield-1895016.jpg" alt="Inter Miami, Supporters Shield" /></p>Lionel Messi and Inter Miami will feature in next year's expanded FIFA Club World Cup, FIFA president Gianni Infantino announced on Saturday.
 <a href="https://www.batimes.com.ar/news/sports/messis-inter-miami-to-play-in-fifas-club-world-cup-in-2025.phtml">Leer más</a>

