# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Boimy się śmierci. To dlaczego gromadzimy i posiadamy coraz więcej
 - [https://deon.pl/wiara/boimy-sie-smierci-to-dlaczego-gromadzimy-i-posiadamy-coraz-wiecej,2951258](https://deon.pl/wiara/boimy-sie-smierci-to-dlaczego-gromadzimy-i-posiadamy-coraz-wiecej,2951258)
 - RSS feed: $source
 - date published: 2024-10-20T22:46:58.827239+00:00

Fot. depositphotos.com

## Katolicy na świecie – jest nas o 13 milionów więcej!
 - [https://deon.pl/wiara/katolicy-na-swiecie--jest-nas-o-13-milionow-wiecej,2951291](https://deon.pl/wiara/katolicy-na-swiecie--jest-nas-o-13-milionow-wiecej,2951291)
 - RSS feed: $source
 - date published: 2024-10-20T14:05:45.400092+00:00

depositphotos.com

## Papież po raz pierwszy nazwał Palestynę „umęczoną”
 - [https://deon.pl/kosciol/papiez-po-raz-pierwszy-nazwal-palestyne-umeczona,2951276](https://deon.pl/kosciol/papiez-po-raz-pierwszy-nazwal-palestyne-umeczona,2951276)
 - RSS feed: $source
 - date published: 2024-10-20T13:00:41.707006+00:00

Fot. ANSA / PAP

## W sobotę w Łodzi odbyły się święcenia dwóch nowych biskupów
 - [https://deon.pl/kosciol/w-sobote-w-lodzi-odbyly-sie-swiecenia-dwoch-nowych-biskupow,2951243](https://deon.pl/kosciol/w-sobote-w-lodzi-odbyly-sie-swiecenia-dwoch-nowych-biskupow,2951243)
 - RSS feed: $source
 - date published: 2024-10-20T11:55:37.719160+00:00

Fot. episkopat.pl

## Franciszek: służba jest chrześcijańskim stylem życia
 - [https://deon.pl/kosciol/franciszek-sluzba-jest-chrzescijanskim-stylem-zycia,2951225](https://deon.pl/kosciol/franciszek-sluzba-jest-chrzescijanskim-stylem-zycia,2951225)
 - RSS feed: $source
 - date published: 2024-10-20T10:50:32.107633+00:00

Fot. vaticannews.va

## W Lewinie Brzeskim na Opolszczyźnie rozpoczęła się zbiórka podpisów pod pozwem przeciwko Wodom Polskim
 - [https://deon.pl/swiat/w-lewinie-brzeskim-na-opolszczyznie-rozpoczela-sie-zbiorka-podpisow-pod-pozwem-przeciwko-wodom-polskim,2951210](https://deon.pl/swiat/w-lewinie-brzeskim-na-opolszczyznie-rozpoczela-sie-zbiorka-podpisow-pod-pozwem-przeciwko-wodom-polskim,2951210)
 - RSS feed: $source
 - date published: 2024-10-20T09:45:38.048005+00:00

Fot. PAP

## „Idźcie i zaproście wszystkich na ucztę!”. Papieskie orędzie na Światowy Dzień Misyjny
 - [https://deon.pl/kosciol/idzcie-i-zaproscie-wszystkich-na-uczte-papieskie-oredzie-na-swiatowy-dzien-misyjny,2951183](https://deon.pl/kosciol/idzcie-i-zaproscie-wszystkich-na-uczte-papieskie-oredzie-na-swiatowy-dzien-misyjny,2951183)
 - RSS feed: $source
 - date published: 2024-10-20T08:40:31.306278+00:00

fot. Vatican Media

## Dym papierosowy jest szkodliwy nie tylko ludzi, ale także dla roślin
 - [https://deon.pl/po-godzinach/dym-papierosowy-jest-szkodliwy-nie-tylko-ludzi-ale-takze-dla-roslin,2951198](https://deon.pl/po-godzinach/dym-papierosowy-jest-szkodliwy-nie-tylko-ludzi-ale-takze-dla-roslin,2951198)
 - RSS feed: $source
 - date published: 2024-10-20T08:40:31.181661+00:00

Fot. depositphotos.com

## W Królestwie Bożym nie ma VIP-ów
 - [https://deon.pl/wiara/w-krolestwie-bozym-nie-ma-vip-ow,2951165](https://deon.pl/wiara/w-krolestwie-bozym-nie-ma-vip-ow,2951165)
 - RSS feed: $source
 - date published: 2024-10-20T07:35:22.615340+00:00

Fot. episkopat.pl

## Słuchać bardziej Boga niż ludzi
 - [https://deon.pl/kosciol/komentarze/sluchac-bardziej-boga-niz-ludzi,2951132](https://deon.pl/kosciol/komentarze/sluchac-bardziej-boga-niz-ludzi,2951132)
 - RSS feed: $source
 - date published: 2024-10-20T06:30:27.352679+00:00

Zakopane - widok na Giewont - fot. materiały własne

