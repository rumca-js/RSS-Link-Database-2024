# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## “HM Surf” macOS Flaw Lets Attackers Access Camera and Mic – Patch Now!
 - [https://hackread.com/hm-surf-macos-flaw-attackers-access-camera-mic](https://hackread.com/hm-surf-macos-flaw-attackers-access-camera-mic)
 - RSS feed: $source
 - date published: 2024-10-20T20:06:18+00:00

Researchers at Microsoft discovered a new macOS vulnerability, &#8220;HM Surf&#8221; (CVE-2024-44133), which bypasses TCC protections, allowing unauthorized access&#8230;

## Mirai-Inspired Gorilla Botnet Hits 0.3 Million Targets Across 100 Countries
 - [https://hackread.com/mira-gorilla-botnet-ddos-attacks-hit-100-countries](https://hackread.com/mira-gorilla-botnet-ddos-attacks-hit-100-countries)
 - RSS feed: $source
 - date published: 2024-10-20T15:40:24+00:00

A new Gorilla Botnet has launched massive DDoS attacks, targeting over 100 countries, according to cybersecurity firm NSFOCUS.&#8230;

