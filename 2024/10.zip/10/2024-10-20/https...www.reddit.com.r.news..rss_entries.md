# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## One of the last Navajo Code Talkers from World War II dies at 107
 - [https://www.reddit.com/r/news/comments/1g8ch3x/one_of_the_last_navajo_code_talkers_from_world](https://www.reddit.com/r/news/comments/1g8ch3x/one_of_the_last_navajo_code_talkers_from_world)
 - RSS feed: $source
 - date published: 2024-10-20T23:46:00+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/WhileFalseRepeat"> /u/WhileFalseRepeat </a> <br/> <span><a href="https://apnews.com/article/navajo-code-talkers-word-war-ii-5f527f43eebaede11eb86f7bdad27a39">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g8ch3x/one_of_the_last_navajo_code_talkers_from_world/">[comments]</a></span>

## Oregon man found guilty after police say he held a woman hostage in a cinder block dungeon
 - [https://www.reddit.com/r/news/comments/1g8bwn0/oregon_man_found_guilty_after_police_say_he_held](https://www.reddit.com/r/news/comments/1g8bwn0/oregon_man_found_guilty_after_police_say_he_held)
 - RSS feed: $source
 - date published: 2024-10-20T23:17:38+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/lala_b11"> /u/lala_b11 </a> <br/> <span><a href="https://www.cnn.com/2024/10/19/us/negasi-zuberi-guilty-klamath-falls-oregon/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g8bwn0/oregon_man_found_guilty_after_police_say_he_held/">[comments]</a></span>

## The statutory rape allegations against former Bolivian President Evo Morales
 - [https://www.reddit.com/r/news/comments/1g8bsv1/the_statutory_rape_allegations_against_former](https://www.reddit.com/r/news/comments/1g8bsv1/the_statutory_rape_allegations_against_former)
 - RSS feed: $source
 - date published: 2024-10-20T23:12:28+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Some-Technology4413"> /u/Some-Technology4413 </a> <br/> <span><a href="https://latinamericareports.com/the-statutory-rape-allegations-against-former-bolivian-president-evo-morales/9909/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g8bsv1/the_statutory_rape_allegations_against_former/">[comments]</a></span>

## Two athletes die at World Triathlon Championships in Spain
 - [https://www.reddit.com/r/news/comments/1g8bmj1/two_athletes_die_at_world_triathlon_championships](https://www.reddit.com/r/news/comments/1g8bmj1/two_athletes_die_at_world_triathlon_championships)
 - RSS feed: $source
 - date published: 2024-10-20T23:03:48+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/madrid987"> /u/madrid987 </a> <br/> <span><a href="https://edition.cnn.com/2024/10/18/sport/two-die-triathlon-world-championships-spain-spt-intl/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g8bmj1/two_athletes_die_at_world_triathlon_championships/">[comments]</a></span>

## Cuba grid collapses again as hurricane looms
 - [https://www.reddit.com/r/news/comments/1g8b1yz/cuba_grid_collapses_again_as_hurricane_looms](https://www.reddit.com/r/news/comments/1g8b1yz/cuba_grid_collapses_again_as_hurricane_looms)
 - RSS feed: $source
 - date published: 2024-10-20T22:36:08+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/BluntBastard"> /u/BluntBastard </a> <br/> <span><a href="https://www.reuters.com/world/americas/cuba-suffers-third-major-setback-restoring-power-island-millions-still-dark-2024-10-20/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g8b1yz/cuba_grid_collapses_again_as_hurricane_looms/">[comments]</a></span>

## Egypt declared malaria-free by World Health Organization
 - [https://www.reddit.com/r/news/comments/1g8aatl/egypt_declared_malariafree_by_world_health](https://www.reddit.com/r/news/comments/1g8aatl/egypt_declared_malariafree_by_world_health)
 - RSS feed: $source
 - date published: 2024-10-20T22:00:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/JackABoioi"> /u/JackABoioi </a> <br/> <span><a href="https://www.bbc.com/news/articles/cm2yl8pjgn2o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g8aatl/egypt_declared_malariafree_by_world_health/">[comments]</a></span>

## Most common US pesticide may affect brain development similarly to nicotine | US news
 - [https://www.reddit.com/r/news/comments/1g87sq8/most_common_us_pesticide_may_affect_brain](https://www.reddit.com/r/news/comments/1g87sq8/most_common_us_pesticide_may_affect_brain)
 - RSS feed: $source
 - date published: 2024-10-20T20:09:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/nwatab"> /u/nwatab </a> <br/> <span><a href="https://www.theguardian.com/us-news/2024/oct/19/pesticide-neonicotinoids-brain-development">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g87sq8/most_common_us_pesticide_may_affect_brain/">[comments]</a></span>

## Health Ministry in Northern Gaza says at least 87 killed in Israeli Strike
 - [https://www.reddit.com/r/news/comments/1g84ygz/health_ministry_in_northern_gaza_says_at_least_87](https://www.reddit.com/r/news/comments/1g84ygz/health_ministry_in_northern_gaza_says_at_least_87)
 - RSS feed: $source
 - date published: 2024-10-20T18:08:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/George_Zerd"> /u/George_Zerd </a> <br/> <span><a href="https://www.zeo7.com/world-news/health-ministry-in-northern-gaza-says-at-least-87-killed-in-israeli-strike/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g84ygz/health_ministry_in_northern_gaza_says_at_least_87/">[comments]</a></span>

## Cindy Charles, Twitch's Head of Music, Dead After Traffic Accident
 - [https://www.reddit.com/r/news/comments/1g846l1/cindy_charles_twitchs_head_of_music_dead_after](https://www.reddit.com/r/news/comments/1g846l1/cindy_charles_twitchs_head_of_music_dead_after)
 - RSS feed: $source
 - date published: 2024-10-20T17:35:12+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sfchurn"> /u/sfchurn </a> <br/> <span><a href="https://www.billboard.com/pro/cindy-charles-twitch-head-of-music-dead-traffic-accident/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g846l1/cindy_charles_twitchs_head_of_music_dead_after/">[comments]</a></span>

## Woman sentenced to life in deaths of 2 young children found hanging in home's basement 5 years ago
 - [https://www.reddit.com/r/news/comments/1g7z2b4/woman_sentenced_to_life_in_deaths_of_2_young](https://www.reddit.com/r/news/comments/1g7z2b4/woman_sentenced_to_life_in_deaths_of_2_young)
 - RSS feed: $source
 - date published: 2024-10-20T13:46:29+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/lala_b11"> /u/lala_b11 </a> <br/> <span><a href="https://apnews.com/article/pennsylvania-brother-sister-hanging-deaths-daad920aa08e12addd1df7e2ca3aa860">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7z2b4/woman_sentenced_to_life_in_deaths_of_2_young/">[comments]</a></span>

## Musk to give away $1m per day to Pennsylvania voters
 - [https://www.reddit.com/r/news/comments/1g7yjaz/musk_to_give_away_1m_per_day_to_pennsylvania](https://www.reddit.com/r/news/comments/1g7yjaz/musk_to_give_away_1m_per_day_to_pennsylvania)
 - RSS feed: $source
 - date published: 2024-10-20T13:19:55+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/madman66254"> /u/madman66254 </a> <br/> <span><a href="https://www.bbc.co.uk/news/articles/cg78ljxn8g7o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7yjaz/musk_to_give_away_1m_per_day_to_pennsylvania/">[comments]</a></span>

## Elon Musk pledges to give away $1m per day to Pennsylvania voters
 - [https://www.reddit.com/r/news/comments/1g7yil1/elon_musk_pledges_to_give_away_1m_per_day_to](https://www.reddit.com/r/news/comments/1g7yil1/elon_musk_pledges_to_give_away_1m_per_day_to)
 - RSS feed: $source
 - date published: 2024-10-20T13:18:57+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TigreSauvage"> /u/TigreSauvage </a> <br/> <span><a href="https://www.bbc.com/news/articles/cg78ljxn8g7o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7yil1/elon_musk_pledges_to_give_away_1m_per_day_to/">[comments]</a></span>

## Dracula author Bram Stoker's lost story unearthed after 134 years
 - [https://www.reddit.com/r/news/comments/1g7w08x/dracula_author_bram_stokers_lost_story_unearthed](https://www.reddit.com/r/news/comments/1g7w08x/dracula_author_bram_stokers_lost_story_unearthed)
 - RSS feed: $source
 - date published: 2024-10-20T10:50:08+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Plainchant"> /u/Plainchant </a> <br/> <span><a href="https://www.bbc.com/news/articles/c4g9119l64qo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7w08x/dracula_author_bram_stokers_lost_story_unearthed/">[comments]</a></span>

## Cher, Kool & the Gang, Dionne Warwick inducted into Rock & Roll Hall of Fame
 - [https://www.reddit.com/r/news/comments/1g7t3hu/cher_kool_the_gang_dionne_warwick_inducted_into](https://www.reddit.com/r/news/comments/1g7t3hu/cher_kool_the_gang_dionne_warwick_inducted_into)
 - RSS feed: $source
 - date published: 2024-10-20T07:09:24+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/armeniapedia"> /u/armeniapedia </a> <br/> <span><a href="https://www.cbsnews.com/news/rock-roll-hall-of-fame-induction-ceremony-cher-dionne-warwick-mary-j-blige-jimmy-buffett/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7t3hu/cher_kool_the_gang_dionne_warwick_inducted_into/">[comments]</a></span>

## Drug kingpin Demetrius ‘Big Meech’ Flenory leaves federal prison for a residential program in Miami
 - [https://www.reddit.com/r/news/comments/1g7s23k/drug_kingpin_demetrius_big_meech_flenory_leaves](https://www.reddit.com/r/news/comments/1g7s23k/drug_kingpin_demetrius_big_meech_flenory_leaves)
 - RSS feed: $source
 - date published: 2024-10-20T05:53:52+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/massacreek"> /u/massacreek </a> <br/> <span><a href="https://apnews.com/article/big-meech-black-mafia-family-drug-gang-6aac7b6877b7710dd23a826c67ad06c3">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7s23k/drug_kingpin_demetrius_big_meech_flenory_leaves/">[comments]</a></span>

## At least 7 dead after ferry dock gangway collapses on Georgia’s Sapelo Island
 - [https://www.reddit.com/r/news/comments/1g7o70e/at_least_7_dead_after_ferry_dock_gangway](https://www.reddit.com/r/news/comments/1g7o70e/at_least_7_dead_after_ferry_dock_gangway)
 - RSS feed: $source
 - date published: 2024-10-20T01:49:04+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br/> <span><a href="https://apnews.com/article/ferry-dock-collapse-deaths-sapelo-island-georgia-66ea381cb0f9fd697fc51fc7aa853038">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7o70e/at_least_7_dead_after_ferry_dock_gangway/">[comments]</a></span>

## Parents pull children from class over presentation at Halifax area school
 - [https://www.reddit.com/r/news/comments/1g7n86l/parents_pull_children_from_class_over](https://www.reddit.com/r/news/comments/1g7n86l/parents_pull_children_from_class_over)
 - RSS feed: $source
 - date published: 2024-10-20T00:54:40+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Embarrassed-Mouse-49"> /u/Embarrassed-Mouse-49 </a> <br/> <span><a href="https://atlantic.ctvnews.ca/parents-pull-children-from-class-over-presentation-at-halifax-area-school-1.7079434">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1g7n86l/parents_pull_children_from_class_over/">[comments]</a></span>

