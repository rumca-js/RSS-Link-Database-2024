# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Kolejny rosyjski menedżer nie żyje. Były wiceprezes Jukosu wypadł przez okno
 - [https://forsal.pl/swiat/rosja/artykuly/9637801,kolejny-rosyjski-menedzer-nie-zyje-byly-wiceprezes-jukosu-wypadl-prze.html](https://forsal.pl/swiat/rosja/artykuly/9637801,kolejny-rosyjski-menedzer-nie-zyje-byly-wiceprezes-jukosu-wypadl-prze.html)
 - RSS feed: $source
 - date published: 2024-10-20T17:11:56+00:00

None

## Trump i UE coraz bliżej siebie ws. migracji. Politico: Mają podobne cele, ale stosują inne języki
 - [https://forsal.pl/swiat/usa/artykuly/9637588,trump-i-ue-coraz-blizej-siebie-ws-migracji-politico-maja-podobne-ce.html](https://forsal.pl/swiat/usa/artykuly/9637588,trump-i-ue-coraz-blizej-siebie-ws-migracji-politico-maja-podobne-ce.html)
 - RSS feed: $source
 - date published: 2024-10-20T13:25:54+00:00

None

## Pomaga zwierzętom i wszedł do Sejmu. Teraz może być kandydatem Lewicy na prezydenta
 - [https://forsal.pl/kraj/polityka/artykuly/9637565,lukasz-litewka-pomag-zwierzetom-i-wszedl-do-sejmu-teraz-moze-byc-kandydatem-lewicy.html](https://forsal.pl/kraj/polityka/artykuly/9637565,lukasz-litewka-pomag-zwierzetom-i-wszedl-do-sejmu-teraz-moze-byc-kandydatem-lewicy.html)
 - RSS feed: $source
 - date published: 2024-10-20T11:00:48+00:00

None

## Izrael zaatakował siedzibę wywiadu Hezbollahu w Bejrucie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9637561,izrael-zaatakowal-siedzibe-wywiadu-hezbollahu-w-bejrucie.html](https://forsal.pl/swiat/aktualnosci/artykuly/9637561,izrael-zaatakowal-siedzibe-wywiadu-hezbollahu-w-bejrucie.html)
 - RSS feed: $source
 - date published: 2024-10-20T10:18:39+00:00

None

## NSA: MOPS nie może w ten sposób oceniać zdrowia staruszka. Należy się świadczenie pielęgnacyjne 2988 zł (3287 zł w 2025 r.)
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/9553405,nsa-mops-nie-moze-w-ten-sposob-oceniac-zdrowia-staruszka-nalezy-sie-swiadczenie-pielegnacyjne-2988-zl-3287-zl-w-2025-r.html](https://forsal.pl/praca/wynagrodzenia/artykuly/9553405,nsa-mops-nie-moze-w-ten-sposob-oceniac-zdrowia-staruszka-nalezy-sie-swiadczenie-pielegnacyjne-2988-zl-3287-zl-w-2025-r.html)
 - RSS feed: $source
 - date published: 2024-10-20T09:51:17+00:00

None

## Covid-19 to nic? Naukowcy alarmują: kolejna pandemia to tylko kwestia czasu [RAPORT]
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9637551,covid-19-to-nic-naukowcy-alarmuja-kolejna-pandemia-to-tylko-kwestia.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9637551,covid-19-to-nic-naukowcy-alarmuja-kolejna-pandemia-to-tylko-kwestia.html)
 - RSS feed: $source
 - date published: 2024-10-20T08:23:45+00:00

None

## WSA: Czy abonament RTV płaci Polak mieszkający na stałe w Anglii albo Francji? Nie wyrejestrował telewizora
 - [https://forsal.pl/finanse/artykuly/9566726,wsa-czy-abonament-rtv-placi-polak-mieszkajacy-na-stale-w-anglii-albo-francji-nie-wyrejestrowal-telewizora.html](https://forsal.pl/finanse/artykuly/9566726,wsa-czy-abonament-rtv-placi-polak-mieszkajacy-na-stale-w-anglii-albo-francji-nie-wyrejestrowal-telewizora.html)
 - RSS feed: $source
 - date published: 2024-10-20T07:59:56+00:00

None

## Zmiana czasu jest szkodliwa dla zdrowia. Ekspertka: To szok dla naszego zegara biologicznego
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9637544,zmiana-czasu-jest-szkodliwa-dla-zdrowia-ekspertka-to-szok-dla-naszeg.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9637544,zmiana-czasu-jest-szkodliwa-dla-zdrowia-ekspertka-to-szok-dla-naszeg.html)
 - RSS feed: $source
 - date published: 2024-10-20T06:57:32+00:00

None

## Atak na dom premiera Izraela. Netanjahu: Hezbollah popełnił "poważny błąd"
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9637267,atak-na-dom-premiera-izraela-netanjahu-hezbollah-popelnil-powazny-b.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9637267,atak-na-dom-premiera-izraela-netanjahu-hezbollah-popelnil-powazny-b.html)
 - RSS feed: $source
 - date published: 2024-10-20T05:38:03+00:00

None

## Trump: Prezydent Chin mnie szanuje i wie, że jestem szalony
 - [https://forsal.pl/swiat/usa/artykuly/9637266,trump-prezydent-chin-mnie-szanuje-i-wie-ze-jestem-szalony.html](https://forsal.pl/swiat/usa/artykuly/9637266,trump-prezydent-chin-mnie-szanuje-i-wie-ze-jestem-szalony.html)
 - RSS feed: $source
 - date published: 2024-10-20T05:05:04+00:00

None

## Czy rząd Donalda Tuska wywiązuje się z obietnic? Polacy ocenili [SONDAŻ]
 - [https://forsal.pl/kraj/polityka/artykuly/9637264,czy-rzad-donalda-tuska-wywiazuje-sie-z-obietnic-polacy-ocenili-sonda.html](https://forsal.pl/kraj/polityka/artykuly/9637264,czy-rzad-donalda-tuska-wywiazuje-sie-z-obietnic-polacy-ocenili-sonda.html)
 - RSS feed: $source
 - date published: 2024-10-20T04:08:00+00:00

None

## Wyciek tajnych dokumentów ws. ataku Izraela na Iran. Amerykanie są "skrajnie zaniepokojeni"
 - [https://forsal.pl/swiat/usa/artykuly/9637269,wyciek-tajnych-dokumentow-ws-ataku-izraela-na-iran-amerykanie-sa-sk.html](https://forsal.pl/swiat/usa/artykuly/9637269,wyciek-tajnych-dokumentow-ws-ataku-izraela-na-iran-amerykanie-sa-sk.html)
 - RSS feed: $source
 - date published: 2024-10-20T04:06:02+00:00

None

