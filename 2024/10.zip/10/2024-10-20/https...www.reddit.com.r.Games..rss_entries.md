# Source:Quality Gaming Content and Discussion -- /r/Games, URL:https://www.reddit.com/r/Games/.rss, language:en

## The Making of Worms (1995) | Video documentary
 - [https://www.reddit.com/r/Games/comments/1g8a8e9/the_making_of_worms_1995_video_documentary](https://www.reddit.com/r/Games/comments/1g8a8e9/the_making_of_worms_1995_video_documentary)
 - RSS feed: $source
 - date published: 2024-10-20T21:57:38+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Dwedit"> /u/Dwedit </a> <br/> <span><a href="https://www.youtube.com/watch?v=lMZjptU64oI">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g8a8e9/the_making_of_worms_1995_video_documentary/">[comments]</a></span>

## Ale & Tale Tavern - Scienart Games - Online Co-op Tavern Sim
 - [https://www.reddit.com/r/Games/comments/1g87017/ale_tale_tavern_scienart_games_online_coop_tavern](https://www.reddit.com/r/Games/comments/1g87017/ale_tale_tavern_scienart_games_online_coop_tavern)
 - RSS feed: $source
 - date published: 2024-10-20T19:35:31+00:00

<!-- SC_OFF --><div class="md"><p>Hello, our game was released on Steam 6 weeks ago and yesterday we got first (many to come) major content update.</p> <p>We built the game on everything we loved about the original, but made it deeper and more engaging.</p> <ul> <li>Steam: <a href="https://store.steampowered.com/app/2683150/Ale__Tale_Tavern/">Save 25% on Ale &amp; Tale Tavern on Steam</a></li> <li>YouTube: <a href="https://www.youtube.com/watch?v=tavnFQ4J3jc">Ale &amp; Tale Tavern Final Trailer</a></li> </ul> <p>Get ready for a thrilling mix of genres: a cooperative, first-person, open-world fantasy tavern simulator, action, fishing, hunting, exploration, and completing fun and diverse quests. And, of course, COOKING! Play with friends, feed and quench the thirst of the entire world! </p> <p>Try it out and share your feedback!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Aletaletavernsim"> /u/Aletaletavernsim </a> <br/> <span><a href="https://

## Exploring the new world of Chinese FMV games
 - [https://www.reddit.com/r/Games/comments/1g862j1/exploring_the_new_world_of_chinese_fmv_games](https://www.reddit.com/r/Games/comments/1g862j1/exploring_the_new_world_of_chinese_fmv_games)
 - RSS feed: $source
 - date published: 2024-10-20T18:55:32+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Ashes0fTheWake"> /u/Ashes0fTheWake </a> <br/> <span><a href="https://www.eurogamer.net/exploring-the-new-world-of-chinese-fmv-games">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g862j1/exploring_the_new_world_of_chinese_fmv_games/">[comments]</a></span>

## Introducing Atomfall | Gameplay & World First Look
 - [https://www.reddit.com/r/Games/comments/1g84t8f/introducing_atomfall_gameplay_world_first_look](https://www.reddit.com/r/Games/comments/1g84t8f/introducing_atomfall_gameplay_world_first_look)
 - RSS feed: $source
 - date published: 2024-10-20T18:02:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.youtube.com/watch?v=mDNzwnwk4pQ">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g84t8f/introducing_atomfall_gameplay_world_first_look/">[comments]</a></span>

## Noblesse Oblige: Legacy of the Sorcerer Kings - Lord Forte Games - 2D JRPG-style game with realm management, castle customization, and innovative combat
 - [https://www.reddit.com/r/Games/comments/1g84mmx/noblesse_oblige_legacy_of_the_sorcerer_kings_lord](https://www.reddit.com/r/Games/comments/1g84mmx/noblesse_oblige_legacy_of_the_sorcerer_kings_lord)
 - RSS feed: $source
 - date published: 2024-10-20T17:54:21+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://www.youtube.com/watch?v=NpOU-Fgx104">Story Trailer</a></p> <p><a href="https://www.youtube.com/watch?v=Vj0lFOFDH3A">Gameplay trailer</a></p> <p><a href="https://store.steampowered.com/app/2537730/Noblesse_Oblige_Legacy_of_the_Sorcerer_Kings/">Noblesse Oblige on Steam</a></p> <p>Current content: +40 hours/+500k words of story and gameplay across twelve finished chapters, an eclectic soundtrack of over 140 carefully chosen songs, intricate maps made with over 65 separate tilesets, hundreds of customized animations, and several major story branches with continuing differences.</p> <p>Hey there! I&#39;m Lord Forte, the solo developer of <a href="https://www.lordfortegames.com">Noblesse Oblige: Legacy of the Sorcerer Kings</a>, an epic high fantasy ruler RPG being created in an episodic release format! I call Noblesse Oblige a ruler RPG because it combines exploration and turn-based RPG combat using a core party with aspects of rulership, 

## The Secret Internet (is in Trackmania)
 - [https://www.reddit.com/r/Games/comments/1g84lgr/the_secret_internet_is_in_trackmania](https://www.reddit.com/r/Games/comments/1g84lgr/the_secret_internet_is_in_trackmania)
 - RSS feed: $source
 - date published: 2024-10-20T17:52:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/megaapple"> /u/megaapple </a> <br/> <span><a href="https://www.youtube.com/watch?v=SiMiV8tixao">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g84lgr/the_secret_internet_is_in_trackmania/">[comments]</a></span>

## Kota`s New Journey - KotaMota Games - A free humorous game for the evening
 - [https://www.reddit.com/r/Games/comments/1g84kdj/kotas_new_journey_kotamota_games_a_free_humorous](https://www.reddit.com/r/Games/comments/1g84kdj/kotas_new_journey_kotamota_games_a_free_humorous)
 - RSS feed: $source
 - date published: 2024-10-20T17:51:36+00:00

<!-- SC_OFF --><div class="md"><p>Hi, folks!</p> <p>My friends are going to release their new game soon, and I want to tell you about it.</p> <p>This is a cute, funny and slightly cheesy sfw game about the adventurers of an elf cosplayer (it has absolutely nothing to do with a certain popular manga and anime). Also, this game is <strong>totally free</strong>. It has no in-game purchases, ads, paywalls or other bullshit. No, it&#39;s a completely free, albeit small, game whose main goal is to make you, the player, smile.</p> <p>Steam page: <a href="https://store.steampowered.com/app/3270680/Kotas_New_Journey/">https://store.steampowered.com/app/3270680/Kotas_New_Journey/</a></p> <p>Trailer: <a href="https://youtu.be/e2ohx_tTKY8">https://youtu.be/e2ohx_tTKY8</a></p> <p>It&#39;s scheduled for release in less than a month. The plan is to get more wishlists before then... Why would a free game need that? It&#39;s simple: If the game gets into the Popular Upcoming list, more people will kno

## Rock Digger - Rockin'Games - A digging game with a ton of upgrades, inspired by SteamWorld: Dig and Motherload
 - [https://www.reddit.com/r/Games/comments/1g84eb1/rock_digger_rockingames_a_digging_game_with_a_ton](https://www.reddit.com/r/Games/comments/1g84eb1/rock_digger_rockingames_a_digging_game_with_a_ton)
 - RSS feed: $source
 - date published: 2024-10-20T17:44:35+00:00

<!-- SC_OFF --><div class="md"><p>Hello there! </p> <p>I&#39;m running a Next Fest demo for <strong>Rock Digger</strong> right now (don&#39;t worry, it&#39;ll stay up after fest). Give it a try! </p> <p><strong>Steam Page</strong> : <a href="https://store.steampowered.com/app/3096260/Rock_Digger/?utm_source=indiesunday&amp;utm_medium=reddit">https://store.steampowered.com/app/3096260/Rock_Digger/</a><br/> <strong>Trailer</strong> : <a href="https://www.youtube.com/watch?v=dgIMEbyd3Ro">https://www.youtube.com/watch?v=dgIMEbyd3Ro</a> </p> <p>You start as a rock with absolutely no ability, <strong>you can&#39;t even move</strong>! But over the course of the game you&#39;ll collect a <strong>shit-ton of new powers and upgrades</strong> until you become a literal rock god. </p> <p>The demo is very short currently (~30 mins) so you won&#39;t end up <em>that</em> powerful, but it&#39;s just a quick preview of the gameplay loop to get you hooked and make you wishlist the game ;) </p> <p>Any f

## IT Startup: Tech Fodder - KupilasMedia - Dev 💻 themed Roguelike Deckbuilder. Squeeze out your employees to gain Project Points [Steam Next Fest Demo]
 - [https://www.reddit.com/r/Games/comments/1g836cz/it_startup_tech_fodder_kupilasmedia_dev_themed](https://www.reddit.com/r/Games/comments/1g836cz/it_startup_tech_fodder_kupilasmedia_dev_themed)
 - RSS feed: $source
 - date published: 2024-10-20T16:51:20+00:00

<!-- SC_OFF --><div class="md"><p><strong>IT Startup is a dev themed Roguelike Deckbuilder</strong>. We play Developer Cards to gain project points. Raise your DEV’s efficiency with Knowledge Cards. Sabotage your opponents or steal their Developers. Craft a unique deck and squeeze out your employees to win the next Project Battle!</p> <p><strong>Steam</strong>: <a href="https://store.steampowered.com/app/1704120/IT_Startup_Tech_Fodder/">https://store.steampowered.com/app/1704120/IT_Startup_Tech_Fodder/</a></p> <p>Some of the features:</p> <ul> <li><strong>Employee Burnout Mechanic</strong> - Employees on the board gain burnout over time. You have to manage it, or abuse it to squeeze them for some quick points.</li> <li><strong>Modificator Modules</strong> - modules modify the game rules and make some cards and strategies much stronger. This includes an OP Starter module that significantly impacts how you play your cards.</li> <li><strong>Starter Deck Selection</strong> - you don&#39;t

## Stellar outpost commander - Kinderril games - Majesty like RTS
 - [https://www.reddit.com/r/Games/comments/1g8342v/stellar_outpost_commander_kinderril_games_majesty](https://www.reddit.com/r/Games/comments/1g8342v/stellar_outpost_commander_kinderril_games_majesty)
 - RSS feed: $source
 - date published: 2024-10-20T16:48:37+00:00

<!-- SC_OFF --><div class="md"><p>Hi! Stellar outpost commander Majesty-like RTS. Place targets for pilots, upgrade trade routs, and complete different missions.</p> <ul> <li>Steam <a href="https://store.steampowered.com/app/2820020/Stellar_outpost_commander/">https://store.steampowered.com/app/2820020/Stellar_outpost_commander/</a></li> </ul> <p>Demo is playable now! Two missions: one is easy and one is hard (really hard). 6 types of playable ships. And full types of pilots behaviours.</p> <ul> <li>Trailer <a href="https://youtu.be/Am50obCVF30">https://youtu.be/Am50obCVF30</a></li> <li>Gameplay <a href="https://youtu.be/bpwh-L8i7KU">https://youtu.be/bpwh-L8i7KU</a></li> </ul> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Kinderril"> /u/Kinderril </a> <br/> <span><a href="https://www.reddit.com/r/Games/comments/1g8342v/stellar_outpost_commander_kinderril_games_majesty/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/

## Frogmageddon - Frog Mage Udon - Vampire Survivors Meets Katamari! Bullet heaven survival game.
 - [https://www.reddit.com/r/Games/comments/1g82r1w/frogmageddon_frog_mage_udon_vampire_survivors](https://www.reddit.com/r/Games/comments/1g82r1w/frogmageddon_frog_mage_udon_vampire_survivors)
 - RSS feed: $source
 - date published: 2024-10-20T16:33:08+00:00

<!-- SC_OFF --><div class="md"><p>Hello Froggy folk! My name is Manny Mallea, one of the developers behind Frogmageddon, a survival game where 1 frog becomes 100 against a horde of slithery foes and buff bros. Initially done for a game jam, we wanted to develop a Steam release to include new features and content:</p> <ul> <li>Controller Support</li> <li>Steam Achievements</li> <li>New gameplay content</li> <li>Improved Flappy Bird Gameplay</li> <li>You&#39;re friends will finally know you play Frogmageddon.</li> </ul> <p>Please feel free to try the original on itch (link below) and give us a wishlist on our brand new Steam Page (link also below).</p> <p><a href="https://austinszema.itch.io/frogmageddon">The original Itch.io release</a></p> <p><a href="https://store.steampowered.com/app/3201190/Frogmageddon/?curator_clanid=4777282">The Steam page link is here frog folk!</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Darkokillzall"> /u/Darkoki

## Dreamless - Setone Games - A chilling descent into horror
 - [https://www.reddit.com/r/Games/comments/1g81ez9/dreamless_setone_games_a_chilling_descent_into](https://www.reddit.com/r/Games/comments/1g81ez9/dreamless_setone_games_a_chilling_descent_into)
 - RSS feed: $source
 - date published: 2024-10-20T15:34:58+00:00

<!-- SC_OFF --><div class="md"><p>Hello, <a href="/r/Games">r/Games</a>! </p> <p>We are very excited to share with you information about our upcoming release “Dreamless”, which will be released on October 25th. </p> <p>🎮 <a href="https://store.steampowered.com/app/3011020?utm_source=reddit">Steam Page</a></p> <p>▶️ <a href="https://www.youtube.com/watch?v=82f-qf3HcaI">Trailer</a></p> <p>🕹️ <a href="https://store.steampowered.com/app/3248750/Dreamless_Demo/">Demo </a></p> <p>👾 <strong>Genres:</strong> Horror, Adventure </p> <p><strong>Dreamless Key Features:</strong> </p> <ul> <li>Photorealistic visuals: the game&#39;s realistic visuals help you immerse yourself in the world of the game</li> <li>Atmospheric soundtrack: A growing and frightening soundtrack, as well as a sound-designed environment.</li> <li>Dynamic Environment: Move through an ever-changing haunted house filled with evolving puzzles and surprises.</li> <li>Deep, intriguing plot: Uncover the dark secrets of a small town a

## BOUNCE GUN - DeadmanDev - Fast-Paced Hardcore Arcade Neon Roguelike Game where you bounce off walls and shoot enemies with a focus on decision-making and replayability
 - [https://www.reddit.com/r/Games/comments/1g80x6c/bounce_gun_deadmandev_fastpaced_hardcore_arcade](https://www.reddit.com/r/Games/comments/1g80x6c/bounce_gun_deadmandev_fastpaced_hardcore_arcade)
 - RSS feed: $source
 - date published: 2024-10-20T15:12:32+00:00

<!-- SC_OFF --><div class="md"><p>Hi! I&#39;m the solo indie developer of <a href="https://store.steampowered.com/app/2860780/Bounce_Gun/">BOUNCE GUN</a> a neon pixel art hardcore arcade rogue-like game with a huge focus on upgrade synergies/deckbuilding and replayability. BUT in addition to Upgrades, you also get Debuffs and it&#39;s important to keep the balance to win.</p> <p>✅ Key Features:</p> <ul> <li>Unique gameplay, inspired by Pong, but you play as ball and interesting difficulty progression</li> <li>Huge number of unique upgrades for you to make different builds</li> <li>Giant replayability with a lot of modifiers, characters, enemy waves, progressive bosses and random-generated situations</li> <li>A lot of decision-making</li> <li>Every run can is unique</li> </ul> <p>🎥<a href="https://youtu.be/ptS-7YrHCPI">Announcement trailer</a> is focused on gameplay. Its a bit fast honestly, but the game is quite fast too, so hope you like it</p> <p>🕹If you like what you see or how it 

## Super Spelling Ducks - chaotic run-based (multiplayer) word-building
 - [https://www.reddit.com/r/Games/comments/1g80p4r/super_spelling_ducks_chaotic_runbased_multiplayer](https://www.reddit.com/r/Games/comments/1g80p4r/super_spelling_ducks_chaotic_runbased_multiplayer)
 - RSS feed: $source
 - date published: 2024-10-20T15:02:34+00:00

<!-- SC_OFF --><div class="md"><p>Hi!</p> <p>I&#39;m developing a game called Super Spelling Ducks. It&#39;s a run-based game - you push around letters to make words and then set off satisfying combos to earn gems and coins! Gems must be periodically paid to continue, and coins can be used to buy perks that help you! If you&#39;re low on coins, there&#39;s always the possibility to take some curses to fund your perks as well.</p> <p>The final version of the game will have lots of unlockable ducks, perks &amp; curses, and difficulty tiers.</p> <p>Here&#39;s a little clip from Youtube: <a href="https://www.youtube.com/watch?v=Yl_qFbbfz_w">https://www.youtube.com/watch?v=Yl_qFbbfz_w</a></p> <p>If you want to see someone else playing the game, jump into a VOD from WillOBot&#39;s recent stream: <a href="https://www.twitch.tv/videos/2279163492?t=01h43m20s">https://www.twitch.tv/videos/2279163492?t=01h43m20s</a></p> <p>And finally if you like what you see, please consider throwing me a wishl

## Polygon of Reality - Dark Games DGG - A non-linear survival horror game with other dimensions, clever and cunning creatures.
 - [https://www.reddit.com/r/Games/comments/1g80lb5/polygon_of_reality_dark_games_dgg_a_nonlinear](https://www.reddit.com/r/Games/comments/1g80lb5/polygon_of_reality_dark_games_dgg_a_nonlinear)
 - RSS feed: $source
 - date published: 2024-10-20T14:57:59+00:00

<!-- SC_OFF --><div class="md"><p>Hello, <a href="https://www.reddit.com/r/Games/">r/Games</a></p> <p>I finished the <strong>Polygon of Reality</strong> game, <strong>it&#39;s coming out in four days!</strong></p> <p>🕹️<strong>Steam page:</strong> <a href="https://store.steampowered.com/app/1860320?utm_source=reddit">Steam link</a></p> <p>▶️<strong>Trailer</strong>: <a href="https://youtu.be/rXz58K5vQOk?si=XAANY4eZFtXFP1Mt">Youtube link</a></p> <p><strong>👾Game Genres: horror, survival horror, action</strong></p> <p>❗<strong>Game Features</strong></p> <ul> <li>Gameplay and locations <strong>change depending</strong> <strong>on your choices</strong>.</li> <li>Different endings that <strong>depend entirely on your actions</strong>.</li> <li>Meet a wide variety of creatures and <strong>explore their</strong> <strong>unique behaviors and features in order to survive</strong>.</li> <li>Survive by making the right decisions and avoiding the <strong>wrath</strong> of the <strong>creatures</s

## Lessaria: Fantasy Kingdom Sim - RockBee - Majesty meets WarCraft 3
 - [https://www.reddit.com/r/Games/comments/1g7zy47/lessaria_fantasy_kingdom_sim_rockbee_majesty](https://www.reddit.com/r/Games/comments/1g7zy47/lessaria_fantasy_kingdom_sim_rockbee_majesty)
 - RSS feed: $source
 - date published: 2024-10-20T14:28:14+00:00

<!-- SC_OFF --><div class="md"><p>We’ve long dreamed of Majesty 3, having been active members of the community for years, but a new installment of the legendary RTS never came. That’s why we decided to create our own Majesty.</p> <p>We built the game on everything we loved about the original, but made it deeper and more engaging.</p> <ul> <li>Steam: <a href="https://store.steampowered.com/app/2461280/Lessaria_Fantasy_kingdom_sim/">https://store.steampowered.com/app/2461280/Lessaria_Fantasy_kingdom_sim/</a></li> <li>YouTube: <a href="https://youtu.be/78qY8ELN4lE">https://youtu.be/78qY8ELN4lE</a></li> </ul> <p>We gave heroes more stats, perks, and abilities. Now, no two warriors or rangers are alike. Depending on what happens to the hero, they develop unique traits. If a large spider frightens a hero at early levels, they’ll carry a &#39;fear of spiders&#39; trait for life.</p> <p>Indirect control is a complex feature, which is why we’re constantly playtesting the game. Head over to Ste

## Stickin' the Landing - Adrift Team - Cozy gravity puzzle game coming to Switch and Steam 24 October!
 - [https://www.reddit.com/r/Games/comments/1g7zvgd/stickin_the_landing_adrift_team_cozy_gravity](https://www.reddit.com/r/Games/comments/1g7zvgd/stickin_the_landing_adrift_team_cozy_gravity)
 - RSS feed: $source
 - date published: 2024-10-20T14:24:53+00:00

<!-- SC_OFF --><div class="md"><p>In Stickin&#39; The Landing you will have to help a paper ship adrift in space to reach the goal, but... how do you fly a ship whose engine doesn&#39;t work?</p> <p>By using the pull of the planets and letting ourselves be carried along by their orbits!</p> <ul> <li>Steam: <a href="https://store.steampowered.com/app/2740260/Stickin_the_Landing/">https://store.steampowered.com/app/2740260/Stickin_the_Landing/</a></li> <li>Twitter: <a href="https://x.com/AdriftTeam">https://x.com/AdriftTeam</a></li> <li>Trailer: <a href="https://www.youtube.com/watch?v=ldFvES2MGiA">https://www.youtube.com/watch?v=ldFvES2MGiA</a></li> </ul> <p>Stickin&#39; the Landing tells the story of a kid whose parents are astrophysicists and who has been passionate about space and being an astronaut navigating the cosmos since he was a child. One day, he decides to make use of his drawing and crafting skills to turn all the rooms in his house into a big universe where he can have ad

## Pest Apocalypse - Kikimora Games - Pizza Delivery Rogue-lite! Play The Demo, Feed The Wasteland!
 - [https://www.reddit.com/r/Games/comments/1g7zlrz/pest_apocalypse_kikimora_games_pizza_delivery](https://www.reddit.com/r/Games/comments/1g7zlrz/pest_apocalypse_kikimora_games_pizza_delivery)
 - RSS feed: $source
 - date published: 2024-10-20T14:12:21+00:00

<!-- SC_OFF --><div class="md"><p>Hi, this is Adriano from Kikimora Games! I&#39;m excited to tell you about <strong><em>Pest Apocalypse</em></strong>!</p> <h1>Links To All The Things!</h1> <ul> <li><a href="https://store.steampowered.com/app/2506810/Pest_Apocalypse?utm_source=reddit&amp;utm_campaign=indie_sunday">Play The Demo!</a></li> <li><a href="https://youtu.be/zGumwTZ4RkA">Trailer</a></li> <li><a href="https://youtu.be/S4dDDbHxPFw">Gameplay Video</a></li> </ul> <h1>What Is It?</h1> <p>Do YOU <strong>like pizza</strong>? Do YOU <strong>hate monsters</strong>? Then <strong>YOU</strong> are the only hope for the hungry wastelanders! </p> <p><strong><em>Pest Apocalypse</em></strong> is a pizza delivery action rogue-lite where you deliver cheesy hot slices to hungry wastelanders. Boost, jump, and drift across different maps in a bouncy physics-based pizza van. Pick up kooky passengers along the way and focus on the driving while they handle the shooting! </p> <h3>What&#39;s differen

## Vampire Clans - RockGame S.A. - A tactical RPG where you will revive a clan of vampires and become the plague that devours 19th-century Paris.
 - [https://www.reddit.com/r/Games/comments/1g7zkvj/vampire_clans_rockgame_sa_a_tactical_rpg_where](https://www.reddit.com/r/Games/comments/1g7zkvj/vampire_clans_rockgame_sa_a_tactical_rpg_where)
 - RSS feed: $source
 - date published: 2024-10-20T14:11:08+00:00

<!-- SC_OFF --><div class="md"><p>Hello and happy Sunday!</p> <p>After countless nights of coding and testing, I’m excited to present our project, Vampire Clans.</p> <p>Steam: <a href="https://store.steampowered.com/app/1578940/Vampire_Clans/">https://store.steampowered.com/app/1578940/Vampire_Clans/</a></p> <p>Trailer: <a href="https://www.youtube.com/watch?v=owoArrCFhmQ&amp;t">https://www.youtube.com/watch?v=owoArrCFhmQ&amp;t</a></p> <p>Welcome to Vampire Clans! You will experience a dark, atmospheric tactical RPG where you will revive a clan of vampires and become a true plague upon 19th-century Paris.</p> <p>You’ll need to plan your underground life. Build and expand your lair by unlocking new rooms and floors, enhancing your vampires&#39; abilities, and unlocking exciting new features.</p> <p>Blood magic consumes the remnants of humanity within you, but it also makes you stronger. Use its powers to fight against humans and monsters alike. Feed on your enemies to fuel your vampiri

## Reviewing Every Single UFO 50 Game
 - [https://www.reddit.com/r/Games/comments/1g7zhjo/reviewing_every_single_ufo_50_game](https://www.reddit.com/r/Games/comments/1g7zhjo/reviewing_every_single_ufo_50_game)
 - RSS feed: $source
 - date published: 2024-10-20T14:06:34+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/popcar2"> /u/popcar2 </a> <br/> <span><a href="https://popcar.bearblog.dev/reviewing-every-ufo50-game/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7zhjo/reviewing_every_single_ufo_50_game/">[comments]</a></span>

## Militsioner - by TallBoys - Every move you make is being followed by a Colossal Policeman 👮
 - [https://www.reddit.com/r/Games/comments/1g7ys3z/militsioner_by_tallboys_every_move_you_make_is](https://www.reddit.com/r/Games/comments/1g7ys3z/militsioner_by_tallboys_every_move_you_make_is)
 - RSS feed: $source
 - date published: 2024-10-20T13:32:12+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone! I’m Dima from Tallboys, and we’re working on our first-person Kafkaesque immersive sim, <em>Militsioner</em>.</p> <p>You&#39;re an ordinary no-one, who hasn&#39;t done anything noteworthy, let alone... a crime. Must be a mistake, yet this morning you were arrested. Pack your stuff and leave as fast as possible, but be wary - every move you make is being followed by a <strong>Giant-Policeman</strong>.</p> <p><a href="https://youtu.be/4SxuWCXPDZQ">10-minute gameplay video</a></p> <p><a href="https://store.steampowered.com/app/1373530/Militsioner/">Militsioner on Steam</a></p> <p>What does the gameplay loop look like?</p> <h1>EXPLORE &amp; PLAN</h1> <p><em>- While exploring potential ways to get to the train station you see the ticket gate.</em> </p> <p>And in a true immersive-sim manner, there always are a few options to solve every problem that you face. </p> <h1>MANIPULATE RELATIONSHIPS</h1> <p><em>- Try to give a gift to the cashier, and

## Party Club - Lucid11 - Overcooked inspired 4 Player Co-op Cooking Game
 - [https://www.reddit.com/r/Games/comments/1g7yjmm/party_club_lucid11_overcooked_inspired_4_player](https://www.reddit.com/r/Games/comments/1g7yjmm/party_club_lucid11_overcooked_inspired_4_player)
 - RSS feed: $source
 - date published: 2024-10-20T13:20:21+00:00

<!-- SC_OFF --><div class="md"><p>Hello everyone! We are a team that really enjoys Overcooked, and we’re developing a 4-player co-op game called Party Club. The main goal is to serve customers&#39; orders within a time limit, earn enough money, and complete the tasks.</p> <p>Our Steam Page: <a href="https://store.steampowered.com/app/2796010/Party_Club/">https://store.steampowered.com/app/2796010/Party_Club/</a><br/> Our Trailer: <a href="https://www.youtube.com/watch?v=iLWBue9-ZMI">https://www.youtube.com/watch?v=iLWBue9-ZMI</a></p> <p>We’ve taken the best parts of Overcooked and combined them with our unique mechanics. One of the key differences is that all the customers in the game are animals, and their interactions with each other play a crucial role. You are responsible for seating the customers, so deciding which animal sits where is entirely up to you. For instance, if you seat a wolf next to a rabbit, the wolf might attack the rabbit! This adds a layer of strategy when arrang

## Skel Dungeon : Heroes Must Die! - Buff Studio - A Real-Time Strategy defense genre game where you expand dungeons and set traps to fend off invading heroes.
 - [https://www.reddit.com/r/Games/comments/1g7y58w/skel_dungeon_heroes_must_die_buff_studio_a](https://www.reddit.com/r/Games/comments/1g7y58w/skel_dungeon_heroes_must_die_buff_studio_a)
 - RSS feed: $source
 - date published: 2024-10-20T13:00:15+00:00

<!-- SC_OFF --><div class="md"><p><strong>Game</strong>: Skel Dungeon : Heroes Must Die! </p> <p><strong>Genre</strong>: Defense + Dark fantasy, Real-Time Strategy, Base Building</p> <p><strong>Platforms:</strong> PC (Steam)</p> <p>Skel Dungeon is a real-time strategy defense game. Play as a tiny skeleton to fend off hordes of heroes and resurrect demons! Set up trap rooms and create your own dungeon. Discover new trap rooms and artifacts and combine them to create stronger traps.</p> <p><strong>Gameplay Trailer:</strong> <a href="https://youtu.be/DNQVpWXUdWU">https://youtu.be/DNQVpWXUdWU</a></p> <p><strong>Steam Page:</strong> <a href="https://store.steampowered.com/app/2963830/Skel_Dungeon/">https://store.steampowered.com/app/2963830/Skel_Dungeon/</a></p> <h1>Features?</h1> <p><strong>Expanding Dungeons and Setting Up Traps</strong></p> <p>: Set up trap rooms and make your heroes suffer. Set up trap rooms with different concepts and discover hidden combinations to create unique trap

## Synchro Bright Future - Komisoft - Turn-based roguelite-RPG inspired by Darkest Dungeon with horror elements in a dark cyberpunk world
 - [https://www.reddit.com/r/Games/comments/1g7y2gu/synchro_bright_future_komisoft_turnbased](https://www.reddit.com/r/Games/comments/1g7y2gu/synchro_bright_future_komisoft_turnbased)
 - RSS feed: $source
 - date published: 2024-10-20T12:56:01+00:00

<!-- SC_OFF --><div class="md"><p>Synchro Bright Future is a challenging roguelike turn-based RPG about the ascent of a person in inhuman conditions. Uncover the mystery of living plastic experiments and fight robotic abominations with an innovative synchronous combat system. </p> <p>We are currently working on releasing a demo. You can add the game to your wishlist on <a href="https://store.steampowered.com/app/2814880/Synchro_Bright_Future/?utm_source=Reddit&amp;utm_campaign=GamesIndieSunday">Steam</a>. You can watch a short gameplay video <a href="https://youtu.be/F6T4FH578lY?si=daPojPYWa3iFeeW6">here</a>.</p> <p>Game Features: </p> <ul> <li>Unique setting of a Eurasian techno-dystopia on the verge of cyberpunk, imbued with a dark 2.5D comic book style;<br/></li> <li>New synchronous turn-based combat system - anticipate enemy movements to survive;<br/></li> <li>Procedurally generated Solar-30 districts with tense gameplay;<br/></li> <li>Secret hideout in one of the city skyscrapers

## Seer's Gambit - Unleash the Giraffe - Roguelite, hero-drafter RPG inspired by TeamFight Tactics
 - [https://www.reddit.com/r/Games/comments/1g7xvkj/seers_gambit_unleash_the_giraffe_roguelite](https://www.reddit.com/r/Games/comments/1g7xvkj/seers_gambit_unleash_the_giraffe_roguelite)
 - RSS feed: $source
 - date published: 2024-10-20T12:45:48+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone.</p> <p><a href="https://store.steampowered.com/app/2219450/Seers_Gambit/">Steam Demo </a></p> <p><a href="https://youtu.be/UKAQgW9itn8">Trailer</a></p> <p>Seer&#39;s Gambit came from our love of the synergies, snowball builds and crazy combos you can achieve in TeamFight Tactics and Hearthstone.</p> <p>It&#39;s both games we love and have played A LOT, but there were 2 things we missed in those games.</p> <ol> <li><strong>The ability to pause.</strong> Once you enter a TFT or Hearthstone match you&#39;re committed to stay put for 30+ minutes, but our current life doesn&#39;t always allow for uninterrupted gameplay. Kids wake up, someone&#39;s at the door or the cat wants belly rubs. We wanted to create the same feeling of building a great synergistic team, but as a single player experience.</li> <li><strong>Permanent progression.</strong> In TFT and Hearthstone the only progression you have between games is the skill and knowledge which y

## Evoplasm - Freezebeam - Creature Building and Fighting Roguelite
 - [https://www.reddit.com/r/Games/comments/1g7xeau/evoplasm_freezebeam_creature_building_and](https://www.reddit.com/r/Games/comments/1g7xeau/evoplasm_freezebeam_creature_building_and)
 - RSS feed: $source
 - date published: 2024-10-20T12:18:08+00:00

<!-- SC_OFF --><div class="md"><p>Hi all!</p> <p>I&#39;m the solo dev of Evoplasm, a creature building and battling roguelite. I just launched the demo on Steam as part of the 2024 Roguelike Celebration and would love to know what you think.</p> <p><a href="https://store.steampowered.com/app/3010490/Evoplasm?utm_source=reddit&amp;utm_campaign=is">Steam Page</a></p> <p><a href="https://www.youtube.com/watch?v=AdhoRLpLqjI">Trailer</a></p> <p>In Evoplasm you build custom microorganisms out of cells, evolve and mutate to get stronger, and fight other weird/cute microscopic abominations over three campaign acts. The creature building is inspired by the cell stage of Spore and the battles are inspired by the real-time with pause tactical battles of FTL.</p> <p>Planning to launch the game in early 2025 most likely. Thanks for checking it out!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/freezebeamgames"> /u/freezebeamgames </a> <br/> <span><a href="h

## Persona 5 And Metaphor ReFantazio Director Katsura Hashino Says He Has Already Started Work On His Next Project.
 - [https://www.reddit.com/r/Games/comments/1g7x55y/persona_5_and_metaphor_refantazio_director](https://www.reddit.com/r/Games/comments/1g7x55y/persona_5_and_metaphor_refantazio_director)
 - RSS feed: $source
 - date published: 2024-10-20T12:03:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/MapCold6687"> /u/MapCold6687 </a> <br/> <span><a href="https://x.com/Genki_JPN/status/1847942889923658044">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7x55y/persona_5_and_metaphor_refantazio_director/">[comments]</a></span>

## Stickin' the Landing - Adrift Team - Cozy gravity puzzle game coming to Switch and Steam 24 October!
 - [https://www.reddit.com/r/Games/comments/1g7wydm/stickin_the_landing_adrift_team_cozy_gravity](https://www.reddit.com/r/Games/comments/1g7wydm/stickin_the_landing_adrift_team_cozy_gravity)
 - RSS feed: $source
 - date published: 2024-10-20T11:53:01+00:00

<!-- SC_OFF --><div class="md"><p>In Stickin&#39; The Landing you will have to help a paper ship adrift in space to reach the goal, but... how do you fly a ship whose engine doesn&#39;t work?</p> <p>By using the pull of the planets and letting ourselves be carried along by their orbits!</p> <ul> <li>Steam: <a href="https://store.steampowered.com/app/2740260/Stickin_the_Landing/">https://store.steampowered.com/app/2740260/Stickin_the_Landing/</a></li> <li>Twitter: <a href="https://x.com/AdriftTeam">https://x.com/AdriftTeam</a></li> </ul> <p>Stickin&#39; the Landing tells the story of a kid whose parents are astrophysicists and who has been passionate about space and being an astronaut navigating the cosmos since he was a child. One day, he decides to make use of his drawing and crafting skills to turn all the rooms in his house into a big universe where he can have adventures with his paper spaceship and his planetary stickers. But in one of these adventures the ship suffers an acciden

## Black Myth Wukong Has Been Rated For Xbox
 - [https://www.reddit.com/r/Games/comments/1g7wqmk/black_myth_wukong_has_been_rated_for_xbox](https://www.reddit.com/r/Games/comments/1g7wqmk/black_myth_wukong_has_been_rated_for_xbox)
 - RSS feed: $source
 - date published: 2024-10-20T11:39:09+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/MapCold6687"> /u/MapCold6687 </a> <br/> <span><a href="https://www.esrb.org/ratings/40203/black-myth-wukong/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7wqmk/black_myth_wukong_has_been_rated_for_xbox/">[comments]</a></span>

## Cardinal Descent - Liam Flannery - element based deckbuilder inspired by Balatro (playtesting this week!) 💧️‍🔥🪨⚡
 - [https://www.reddit.com/r/Games/comments/1g7wahc/cardinal_descent_liam_flannery_element_based](https://www.reddit.com/r/Games/comments/1g7wahc/cardinal_descent_liam_flannery_element_based)
 - RSS feed: $source
 - date published: 2024-10-20T11:09:22+00:00

<!-- SC_OFF --><div class="md"><p>Hey <a href="/r/Games">r/Games</a>, </p> <p>Cardinal Descent is an upcoming roguelike deckbuilder I&#39;m currently solo developing.</p> <p>Your deck consists of playing cards that have elemental suits (water, fire, earth and lightning) you can use these elements in combination or by themselves to target enemy cards and progress through harder and harder rounds.</p> <p>You can also buy Space cards (like Balatro&#39;s jokers) that add game changing modifiers by manipulating the damage of each suit as well as things like the amount of steam damage done (when water and fire combine) or the amount of burning damage a card will take. The Space cards synergise together and can create crazy amounts of damage.</p> <p>There&#39;s currently 50 Space cards, 15 Suit cards with special abilities, and 4 types of enemy cards so each run is very different depending on the cards you see. There are also a decent amount of potential builds so its pretty replayable alrea

## Reality Drift - Arganoid Industries - A roguelike racing game where your choices matter!
 - [https://www.reddit.com/r/Games/comments/1g7w9uw/reality_drift_arganoid_industries_a_roguelike](https://www.reddit.com/r/Games/comments/1g7w9uw/reality_drift_arganoid_industries_a_roguelike)
 - RSS feed: $source
 - date published: 2024-10-20T11:08:06+00:00

<!-- SC_OFF --><div class="md"><p>New video - How Leading Edge became Reality Drift: <a href="https://youtu.be/MOKuoIbv72A">https://youtu.be/MOKuoIbv72A</a></p> <p>Steam: <a href="https://store.steampowered.com/app/3078120/Reality_Drift/">https://store.steampowered.com/app/3078120/Reality_Drift/</a></p> <p>I recently announced my game Reality Drift, which is a roguelike racing game partly inspired by Outrun and Slay the Spire. It started as a game written in Python called Leading Edge, which I was writing for the book &quot;Code the Classics Volume II&quot;, recently published by Raspberry Pi Press. When I started working on this book, I had no idea how to write a 2.5D racing game. As it turned out I was pretty pleased with the game (the last version shown here is not quite the final version), but Python and the Pygame library I used are very slow, and I wanted to see how far I could draw into the distance if I ported the code to Unity. As it turns out, the answer is a very long way -

## Marines vs God - by MvG team - Co-op asymmetrical PvP game (4vs1) where Four Marines play versus God.
 - [https://www.reddit.com/r/Games/comments/1g7w89p/marines_vs_god_by_mvg_team_coop_asymmetrical_pvp](https://www.reddit.com/r/Games/comments/1g7w89p/marines_vs_god_by_mvg_team_coop_asymmetrical_pvp)
 - RSS feed: $source
 - date published: 2024-10-20T11:05:09+00:00

<!-- SC_OFF --><div class="md"><p>Hi folks! I&#39;m Denis from Marines vs God team. </p> <p>Our third person shooter with RTS elements has been in development for quite a few years now, so we&#39;re super super excited to finally be able to share a first <a href="https://youtu.be/MZUh1PwKs2A"><strong>trailer</strong></a> and very soon is demo.</p> <p><a href="https://store.steampowered.com/app/3209950?utm_source=reddit&amp;utm_campaign=post&amp;utm_medium=r/games"><strong>Steam page</strong></a></p> <p>In our game you will fight with your friends in 4 vs 1 mode. You can play as both marines and god. </p> <ul> <li>Marine&#39;s goal: the Company sent you as space marines to an unfamiliar planet where you must complete the mission and escape before the bomb explodes that leads to doom of the God. </li> <li> God&#39;s goal: destroy the Marines or prevent them from completing their mission.</li> </ul> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Vascul

## AETHUS - Pawsmonaut Games - Dystopian Sci-fi survival-crafting on an alien planet created by former GTA dev.
 - [https://www.reddit.com/r/Games/comments/1g7w487/aethus_pawsmonaut_games_dystopian_scifi](https://www.reddit.com/r/Games/comments/1g7w487/aethus_pawsmonaut_games_dystopian_scifi)
 - RSS feed: $source
 - date published: 2024-10-20T10:57:48+00:00

<!-- SC_OFF --><div class="md"><p>Hi! I&#39;m the solo-indie developer of <a href="https://store.steampowered.com/app/2541530/AETHUS/?utm_source=redgamesis">AETHUS</a>, a dystopian sci-fi, physics-driven survival/base-building game, which I&#39;m making pretty much on my own after leaving AAA after ~7 years, at studios like Rockstar North.</p> <p>☑ Key Features:</p> <ul> <li>Descend into the depths of an alien planet - Aethus - to mine for valuable resources in a tactile, physicalised world powered by Unreal Engine 5.</li> <li>Utilise both your mining laser and explosives to gather resources, then Prospect your finds to discover the rarest ores and gem to package up according to demand in order to sell for maximum profit.</li> <li>Construct your own outpost from the ground-up using the resources you mine from the planet, building highly customisable habitats to extend your reach underground, explore mysterious new biomes, and automate your gameplay.</li> <li>Discover and purchase new 

## March March! - Lepka Games - Turn-based roguelike autobattler 🎲
 - [https://www.reddit.com/r/Games/comments/1g7veqg/march_march_lepka_games_turnbased_roguelike](https://www.reddit.com/r/Games/comments/1g7veqg/march_march_lepka_games_turnbased_roguelike)
 - RSS feed: $source
 - date published: 2024-10-20T10:07:02+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://www.youtube.com/watch?v=--6EMJWT7ek">Gameplay by Retromation</a></p> <p><a href="https://store.steampowered.com/app/1607300/March_March/">Steam page (with demo)</a></p> <p>Hi everyone! We&#39;ve been working on our game in our spare time for quite a while and wanted to share it.</p> <p>The game loop goes similarly to most roguelike games but there&#39;s a twist!</p> <p>Each turn in battle, you get a random piece with different units (kinda like in tetri). After that, you get to decide where to place it (you can also rotate it). After that, ALL units on the battlefield perform an attack/ability. To win you have to attack empty enemy lines which makes him lose Morale (basically the HP of the army).</p> <p>Between battles, you can hire new units or upgrade existing ones, learn spells and abilities, and find artifacts. This all happens on a global map, and at the end of the chapter, you get to fight the boss.</p> <p>We tried to merge mech

## Majuular: "FMV Horror | A Strange Moment in Gaming History"
 - [https://www.reddit.com/r/Games/comments/1g7vao5/majuular_fmv_horror_a_strange_moment_in_gaming](https://www.reddit.com/r/Games/comments/1g7vao5/majuular_fmv_horror_a_strange_moment_in_gaming)
 - RSS feed: $source
 - date published: 2024-10-20T09:58:57+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/daughterskin"> /u/daughterskin </a> <br/> <span><a href="https://www.youtube.com/watch?v=t6V2RExwglg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7vao5/majuular_fmv_horror_a_strange_moment_in_gaming/">[comments]</a></span>

## Death Row Escape - Sercan Evyapan - Half-Life inspired first-person horror shooter with mercenaries and zombies
 - [https://www.reddit.com/r/Games/comments/1g7v9q7/death_row_escape_sercan_evyapan_halflife_inspired](https://www.reddit.com/r/Games/comments/1g7v9q7/death_row_escape_sercan_evyapan_halflife_inspired)
 - RSS feed: $source
 - date published: 2024-10-20T09:56:56+00:00

<!-- SC_OFF --><div class="md"><p><strong>Death Row Escape</strong> is a first-person horror shooter where you play as a repair worker trapped in a terrifying prison overtaken by mercenaries. After getting locked in a cell, you must escape and face not only the heavily armed mercenaries but also the undead as the prison becomes a battleground for survival. The game blends horror, action, and environmental puzzles, offering a gripping and tense experience.</p> <ul> <li><strong>Platform</strong>: PC (Steam)</li> <li><strong>Target Release Date</strong>: Mid-2025 (may be delayed to end of 2025)</li> <li><strong>Features</strong>: <ul> <li>Intense first-person shooter combat</li> <li>Zombies and mercenaries as enemies</li> <li>Puzzle-solving elements</li> <li>Atmospheric storytelling</li> </ul></li> </ul> <p><strong>Links</strong>:</p> <ul> <li><a href="https://store.steampowered.com/app/2670780/Death_Row_Escape">Steam Page</a></li> <li><a href="https://www.youtube.com/watch?v=84M6k9ty33E

## WHERE BIRDS GO TO SLEEP – Quiet Little Feet – Story Rich Adventure RPG with Survival Elements inspired by Disco Elysium and Pathologic 2
 - [https://www.reddit.com/r/Games/comments/1g7ul2i/where_birds_go_to_sleep_quiet_little_feet_story](https://www.reddit.com/r/Games/comments/1g7ul2i/where_birds_go_to_sleep_quiet_little_feet_story)
 - RSS feed: $source
 - date published: 2024-10-20T09:04:41+00:00

<!-- SC_OFF --><div class="md"><p>Hello again <a href="/r/Games">r/Games</a>,</p> <p>Steam page: <a href="https://store.steampowered.com/app/1387640/">https://store.steampowered.com/app/1387640/</a></p> <p>Short Trailer: <a href="https://www.youtube.com/watch?v=Vweo8K41mSg">https://www.youtube.com/watch?v=Vweo8K41mSg</a></p> <p>We are a married couple making <a href="https://store.steampowered.com/app/1387640/Where_Birds_Go_to_Sleep/">Where Birds Go to Sleep</a>, a narrative adventure RPG often dubbed an &quot;intrusive thought simulator&quot; in which you do not directly control the main character.</p> <p>In line with our tagline &quot;Become what you hate&quot;, the character, Cormo, whose consciousness you inhabit is a former smuggler - you influence his psyche via your choices with a unique twist: he can disagree with your choices or vice-versa, which makes the player/main character dynamic unique and fun! You can try making him a decent man or watch how low he will sink.</p> <p>Y

## Squadron 42 CitizenCon 2954 Live Gameplay Reveal
 - [https://www.reddit.com/r/Games/comments/1g7ujnf/squadron_42_citizencon_2954_live_gameplay_reveal](https://www.reddit.com/r/Games/comments/1g7ujnf/squadron_42_citizencon_2954_live_gameplay_reveal)
 - RSS feed: $source
 - date published: 2024-10-20T09:01:39+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/ZyreHD"> /u/ZyreHD </a> <br/> <span><a href="https://youtu.be/1H-0x4xk2Xk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7ujnf/squadron_42_citizencon_2954_live_gameplay_reveal/">[comments]</a></span>

## Crapette ! - Romain Bitard - multiplayer Klondike (kinda with some twist)
 - [https://www.reddit.com/r/Games/comments/1g7uj8o/crapette_romain_bitard_multiplayer_klondike_kinda](https://www.reddit.com/r/Games/comments/1g7uj8o/crapette_romain_bitard_multiplayer_klondike_kinda)
 - RSS feed: $source
 - date published: 2024-10-20T09:00:54+00:00

<!-- SC_OFF --><div class="md"><p><strong>tldr;</strong></p> <p><strong>a multiplayer (vs bots or humans) klondike like card game with up to 4 players and some alternative rules</strong></p> <p><strong>How to play in two minutes :</strong></p> <p><a href="https://www.youtube.com/watch?v=hTh4yruDoHg">https://www.youtube.com/watch?v=hTh4yruDoHg</a></p> <p><strong>Quick game of crapette to show gameplay :</strong> <a href="https://www.youtube.com/watch?v=B08cYLqzr0E">https://www.youtube.com/watch?v=B08cYLqzr0E</a> <strong>(~6 min)(no ads for the first game if you wanna try, after that I tried to keep them minimal)</strong></p> <p><strong>/tldr;</strong></p> <p>It&#39;s a traditional chill card game (you can improve your odds by making better decisions). I&#39;m not a (pro) gamedev but I try to make the game as best as I can and as fun as possible on my spare time !</p> <p>It&#39;s one of my favorite card games and I try to improve it regularly (I added card backs, portrait/landscape, a m

## Weekly /r/Games Discussion - What have you been playing, and what are your thoughts? - October 20, 2024
 - [https://www.reddit.com/r/Games/comments/1g7uj3y/weekly_rgames_discussion_what_have_you_been](https://www.reddit.com/r/Games/comments/1g7uj3y/weekly_rgames_discussion_what_have_you_been)
 - RSS feed: $source
 - date published: 2024-10-20T09:00:39+00:00

<!-- SC_OFF --><div class="md"><p>Use this thread to discuss whatever game you&#39;ve been playing lately: old or new, AAA or indie, on any platform between Atari and XBox. Please don&#39;t just list off the games you&#39;re playing in your comment. Elaborate with your thoughts on the games and make it easier for other users to find what game you&#39;re talking about by putting the title in <strong>bold</strong>. </p> <p>Also, please make sure to use spoiler tags if you&#39;re revealing anything about a game&#39;s plot that may significantly impact another player&#39;s experience who has not played the game yet, no matter how retro or recent the game is. You can find instructions on how to do so in the subreddit sidebar. </p> <p>This thread is set to sort comments by &#39;new&#39; on default. </p> <p><strong>Obligatory Advertisements</strong></p> <p>For a subreddit devoted to this type of discussion during the rest of the week, please check out <a href="/r/WhatAreYouPlaying">/r/WhatAr

## Spot Has Found This - POINTZERO COMPANY - Narrative-driven idle game
 - [https://www.reddit.com/r/Games/comments/1g7uh94/spot_has_found_this_pointzero_company](https://www.reddit.com/r/Games/comments/1g7uh94/spot_has_found_this_pointzero_company)
 - RSS feed: $source
 - date published: 2024-10-20T08:56:34+00:00

<!-- SC_OFF --><div class="md"><p>Happy Indie Sunday, everyone!</p> <p>We’d like to highlight our mobile game, Spot Has Found This.</p> <h2>🌟 Game Overview 🌟</h2> <p><strong>Genre</strong>: idle, adventure</p> <p><strong>Platform</strong>: Mobile Game App 📱</p> <p><strong>Rating</strong>: 4.6</p> <p><strong>Features</strong>: </p> <ul> <li>Total Items: 617 🗝️</li> <li>Engaging Storyline: Dive into an immersive narrative!</li> <li>Regular Updates: New content added.</li> <li>User-Friendly Interface: Easy navigation and gameplay!</li> </ul> <p><strong>Latest</strong>:Added new junk and stories, including fresh episodes about the twin sisters and the epic third adventure of Edward Griffiths!</p> <p><strong>HOMEPAGE</strong> : <a href="https://www.pointzero.co.jp/inufetch/index_e.html">https://www.pointzero.co.jp/inufetch/index_e.html</a></p> <p><strong>TRAILER</strong> : <a href="https://youtu.be/v3R7_12MiBM?si=yhhXipD4RmS_gRJl">https://youtu.be/v3R7_12MiBM?si=yhhXipD4RmS_gRJl</a></p> <h

## VOID CREW - Hutlihut Games - Chaotic, co-op roguelite for 1-4 players
 - [https://www.reddit.com/r/Games/comments/1g7udyy/void_crew_hutlihut_games_chaotic_coop_roguelite](https://www.reddit.com/r/Games/comments/1g7udyy/void_crew_hutlihut_games_chaotic_coop_roguelite)
 - RSS feed: $source
 - date published: 2024-10-20T08:49:20+00:00

<!-- SC_OFF --><div class="md"><p>Hey everyone!</p> <p>We are <strong>Hutlihut Games</strong>, small indie studio based in Denmark (Copenhagen).</p> <p>Creators of <strong>Void Crew:</strong> <strong><em>Chaotic, co-op roguelite for 1 to 4 players</em></strong> <em>– Outfit your spaceship and crew for thrilling quests, brave fierce enemies in space battles... and try not to panic!</em></p> <p>Just announced:</p> <h1>Void Crew 1.0 release date: 25. November 2024.</h1> <p>We&#39;ve worked on <strong>Void Crew</strong> for years, been in Early Access for over a year now. This allowed us to use all the feedback, streams, talks, discussions, reviews, and bug reports to transform the game into something even better than we had hoped. Without a doubt, the game is in a much better place, so thank you for all your contributions!</p> <p><strong>Read 1.0 sneak peeks here:</strong> <a href="https://store.steampowered.com/news/app/1063420/view/4517765223385627106?l=english">https://store.steampowe

## Squadron 42 - 1 hour Prologue Gameplay
 - [https://www.reddit.com/r/Games/comments/1g7u9ug/squadron_42_1_hour_prologue_gameplay](https://www.reddit.com/r/Games/comments/1g7u9ug/squadron_42_1_hour_prologue_gameplay)
 - RSS feed: $source
 - date published: 2024-10-20T08:40:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/NightlyKnightMight"> /u/NightlyKnightMight </a> <br/> <span><a href="https://youtu.be/1H-0x4xk2Xk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7u9ug/squadron_42_1_hour_prologue_gameplay/">[comments]</a></span>

## The Nightwatch - Astrow Games - Challenging survivors-like with bosses, shops, talent trees and a different take on meta-progression
 - [https://www.reddit.com/r/Games/comments/1g7u0xf/the_nightwatch_astrow_games_challenging](https://www.reddit.com/r/Games/comments/1g7u0xf/the_nightwatch_astrow_games_challenging)
 - RSS feed: $source
 - date published: 2024-10-20T08:20:57+00:00

<!-- SC_OFF --><div class="md"><p>Hello everyone, I&#39;m the solo developer of <strong>The Nightwatch</strong>.</p> <p>I&#39;ve been working on this game for more than a year and I&#39;m 3 days away to release it (23rd of October). As you can guess I&#39;m incredibly nervous.<br/> You can try out the demo right now on Steam as I&#39;m participating in the current <strong>Steam Next Fest</strong> :</p> <ul> <li><a href="https://store.steampowered.com/app/2817910/The_Nightwatch/">Steam Link</a></li> <li><a href="https://youtu.be/yIg1FmrpEG0?si=CO3tequgIf8ZWeVF">Youtube Trailer</a></li> </ul> <p>In this game, you try to find the source of the attack and put an end to it. On the way you will get stronger by eliminating enemies, buying items, upgrading them and specialising your character by selecting a talent tree.</p> <ul> <li>9 Talent trees</li> </ul> <p>There are 9 talent trees to choose from : Fire, Lightning, Ice, Critical Strikes, Physical, Speed, Bleeding, Poison and Periodic (a m

## HeistGeist - Doublequote Studio - A story-focused cyberpunk RPG about the consequences of that 'one last job' going terribly wrong. Coming to Steam on November 11th.
 - [https://www.reddit.com/r/Games/comments/1g7twsm/heistgeist_doublequote_studio_a_storyfocused](https://www.reddit.com/r/Games/comments/1g7twsm/heistgeist_doublequote_studio_a_storyfocused)
 - RSS feed: $source
 - date published: 2024-10-20T08:11:53+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone and good IndieSunday to you! Allow me to introduce you to the game we&#39;re making in our small team of four, based in Bratislava, Slovakia. It&#39;s called <strong>HeistGeist</strong>.</p> <p><a href="https://store.steampowered.com/app/1982940/HeistGeist/">Steam page</a> (freshly updated)</p> <p><a href="https://youtu.be/Z78sutHyZzE?si=2y-kmgxIbWinkdcy">Watch our Story Trailer</a></p> <p><a href="https://discord.com/invite/HgrJJfK7Ky">Join our Discord</a></p> <h1>About the game</h1> <p>Our game is a story-focused (non-roguelike) cyberpunk RPG with cards instead of skill trees. In <strong>HeistGeist</strong>, you play as Alexandra, a professional thief for hire who&#39;s desperately trying to stay alive after her last job in Venice went terribly wrong. On the run from corporate assassins and with a knife to her throat courtesy of a very unhappy client, Alex needs to assemble a team of professionals to pull off the heist of a lifetime.</p>

## With the master disc for Black Myth Wukong ready, the PS5 physical edition will be available to you very soon
 - [https://www.reddit.com/r/Games/comments/1g7tsz0/with_the_master_disc_for_black_myth_wukong_ready](https://www.reddit.com/r/Games/comments/1g7tsz0/with_the_master_disc_for_black_myth_wukong_ready)
 - RSS feed: $source
 - date published: 2024-10-20T08:03:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://x.com/BlackMythGame/status/1847911254234468563">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7tsz0/with_the_master_disc_for_black_myth_wukong_ready/">[comments]</a></span>

## Dragon's Dogma 2 Apparently Had Framerate Troubles Because the NPCs Were Thinking Too Hard
 - [https://www.reddit.com/r/Games/comments/1g7tqo2/dragons_dogma_2_apparently_had_framerate_troubles](https://www.reddit.com/r/Games/comments/1g7tqo2/dragons_dogma_2_apparently_had_framerate_troubles)
 - RSS feed: $source
 - date published: 2024-10-20T07:59:13+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.ign.com/articles/dragons-dogma-2-apparently-had-framerate-troubles-because-the-npcs-were-thinking-too-hard">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7tqo2/dragons_dogma_2_apparently_had_framerate_troubles/">[comments]</a></span>

## Dunebound Tactics - Terahard - Sail on the desert and fight to be free in a Roguelite Turn-Based RPG
 - [https://www.reddit.com/r/Games/comments/1g7tl9c/dunebound_tactics_terahard_sail_on_the_desert_and](https://www.reddit.com/r/Games/comments/1g7tl9c/dunebound_tactics_terahard_sail_on_the_desert_and)
 - RSS feed: $source
 - date published: 2024-10-20T07:47:40+00:00

<!-- SC_OFF --><div class="md"><p>Hi, <a href="/r/Games">r/Games</a>!<br/> I’m thrilled to introduce <em>Dunebound Tactics</em>, a roguelite turn-based tactical RPG where you lead your caravan and crew across the vast, shifting dunes, with a promise of a better future. </p> <p><strong>Steampage</strong>: <a href="https://store.steampowered.com/app/3034660/Dunebound_Tactics/">https://store.steampowered.com/app/3034660/Dunebound_Tactics/</a><br/> <strong>Trailer</strong>: <a href="https://www.youtube.com/watch?v=v1YgHbn-ye8">https://www.youtube.com/watch?v=v1YgHbn-ye8</a> </p> <p><strong>About The Game</strong></p> <p><em>Dunebound Tactics</em> will push both your strategic and tactical prowess as you navigate the unforgiving wastes. Lead your crew on a daring voyage in search of a new life, making a perilous exodus across Imperial-controlled territories.</p> <p>Follow the Elios leylines aboard your fragile sand-crossing ship, embarking on a journey where risk and reward constantly inte

## Path to Serenity - Ludus Pax Studios -Chil cosy walking simulator
 - [https://www.reddit.com/r/Games/comments/1g7tcd6/path_to_serenity_ludus_pax_studios_chil_cosy](https://www.reddit.com/r/Games/comments/1g7tcd6/path_to_serenity_ludus_pax_studios_chil_cosy)
 - RSS feed: $source
 - date published: 2024-10-20T07:28:14+00:00

<!-- SC_OFF --><div class="md"><p>Path to Serenity announcement trailer: <a href="https://youtu.be/JqA8oW5N8Fk">https://youtu.be/JqA8oW5N8Fk</a></p> <p>My second game &quot;Path to Serenity&quot;, plans to release on Steam, Itch io and Humble Bundle Store for PC and its a walking simulator chill cosy game. Path to Serenity is a cosy, relaxing walking simulator where players help the protagonist find a new path that will change his life for the better.</p> <p>Consider wishlisting if you like here:</p> <p><a href="https://store.steampowered.com/app/3265030/Path_to_Serenity/">https://store.steampowered.com/app/3265030/Path_to_Serenity/</a></p> <p>Thank you for your consideration.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MonkeyboyGamer"> /u/MonkeyboyGamer </a> <br/> <span><a href="https://www.reddit.com/r/Games/comments/1g7tcd6/path_to_serenity_ludus_pax_studios_chil_cosy/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/

## Cerulean Singe - pl0s - A Snappy and Fast-paced First-Person Souls-Like
 - [https://www.reddit.com/r/Games/comments/1g7szn0/cerulean_singe_pl0s_a_snappy_and_fastpaced](https://www.reddit.com/r/Games/comments/1g7szn0/cerulean_singe_pl0s_a_snappy_and_fastpaced)
 - RSS feed: $source
 - date published: 2024-10-20T07:01:18+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone! I&#39;m a solo developer and have been working on this passion project for about 2 years now. I wanted this game to show off my capabilities as a developer, meaning almost every asset was made from scratch.</p> <p>Gameplay Trailer: <a href="https://www.youtube.com/watch?v=Y72tVXQbTew">https://www.youtube.com/watch?v=Y72tVXQbTew</a></p> <p>Steam Page (Demo coming later this year!): <a href="https://store.steampowered.com/app/2530550/Cerulean_Singe/">https://store.steampowered.com/app/2530550/Cerulean_Singe/</a></p> <p>Discord: <a href="https://discord.gg/RsahK2a86W">https://discord.gg/RsahK2a86W</a></p> <p><strong>About the Game:</strong><br/> Cerulean Singe is a first-person souls-like taking heavy inspiration from the mechanics and themes of games like Bloodborne and Dark Souls III.</p> <p>The game focuses on 3 core aspects:</p> <ul> <li>Fast and Snappy Combat</li> <li>Challenging and Engaging Boss Fights</li> <li>Immersive worlds encour

## Path to Serenity - My second game -Chil cosy walking simulator
 - [https://www.reddit.com/r/Games/comments/1g7sriv/path_to_serenity_my_second_game_chil_cosy_walking](https://www.reddit.com/r/Games/comments/1g7sriv/path_to_serenity_my_second_game_chil_cosy_walking)
 - RSS feed: $source
 - date published: 2024-10-20T06:45:55+00:00

<!-- SC_OFF --><div class="md"><p>Path to Serenity announcement trailer: <a href="https://youtu.be/JqA8oW5N8Fk">https://youtu.be/JqA8oW5N8Fk</a></p> <p>My second game &quot;Path to Serenity&quot;, plans to release on Steam, Itch io and Humble Bundle Store for PC and its a walking simulator chill cosy game. Path to Serenity is a cosy, relaxing walking simulator where players help the protagonist find a new path that will change his life for the better.</p> <p>Consider wishlisting if you like here: </p> <p><a href="https://store.steampowered.com/app/3265030/Path_to_Serenity/">https://store.steampowered.com/app/3265030/Path_to_Serenity/</a></p> <p>Thank you for your consideration.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MonkeyboyGamer"> /u/MonkeyboyGamer </a> <br/> <span><a href="https://www.reddit.com/r/Games/comments/1g7sriv/path_to_serenity_my_second_game_chil_cosy_walking/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/

## Lo-Fi Room - Bearmask - A lo-fi hip-hop inspired hidden object & rhythm game
 - [https://www.reddit.com/r/Games/comments/1g7sm6h/lofi_room_bearmask_a_lofi_hiphop_inspired_hidden](https://www.reddit.com/r/Games/comments/1g7sm6h/lofi_room_bearmask_a_lofi_hiphop_inspired_hidden)
 - RSS feed: $source
 - date published: 2024-10-20T06:35:02+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://youtu.be/UcmGWFHnRKM">Trailer</a></p> <p><a href="https://store.steampowered.com/app/2980020/LoFi_Room/">Steam Page</a></p> <p><a href="https://bearmask.itch.io/lofi-room">Free Web Demo (itch)</a></p> <p>Hi, I&#39;ve just released the Steam Page for Lo-Fi Room! I&#39;ve been working on it for a long time and a free web demo has been available on itch from the start of development (in 2018).It started off as a game jam game and I&#39;m working to build the full ~30 level version.</p> <p>Lo-Fi Room is a hidden object &amp; rhythm game where you build lo-fi beats by finding instruments and playing their loops one at a time.Play through a relaxing day of music, make &amp; share your own beats and play endless procedurally generated beats.</p> <p>Thanks!</p> <p>(Sorry the previous post had a typo in the title)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bearmask_io"> /u/bearmask_io </a> <br/> <spa

## Atomic Exile - Inferno Muse Interactive - A survival extraction shooter with loot and weapon mods.
 - [https://www.reddit.com/r/Games/comments/1g7s96s/atomic_exile_inferno_muse_interactive_a_survival](https://www.reddit.com/r/Games/comments/1g7s96s/atomic_exile_inferno_muse_interactive_a_survival)
 - RSS feed: $source
 - date published: 2024-10-20T06:08:01+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone,</p> <p>Atomic Exile. is a top down post-apocalyptic extraction shooter set in the desert wastelands of near future America. Find loot and mod weapons. Explore devastated ruins and encounter NPCs such as other survivors, raiders, mutated beasts and rogue machines. Each run is a new experience. </p> <p>There is a new demo on Steam here: <a href="https://store.steampowered.com/app/2956440/Atomic_Exile/?utm_source=Reddit">Steam Demo</a> </p> <p>Youtube: <a href="https://www.youtube.com/watch?v=UyvfPnStqqQ">https://www.youtube.com/watch?v=UyvfPnStqqQ</a> </p> <p>X/Twitter: <a href="https://twitter.com/infernomuse">https://twitter.com/infernomuse</a> </p> <p>Find weapons to modify. Add enhanced sights, improve handling with better grips, swap out magazines and more. Craft the weapon that’s right for each situation. The denizens of the wasteland are on alert for wayward travellers. Keep out of sight and keep quiet unless you want to be diner. To

## Commander Tiberius Troubleson - Jos_a.b - Play as a Space Wizard with a Gun in this action focused roguelite.
 - [https://www.reddit.com/r/Games/comments/1g7s0e2/commander_tiberius_troubleson_jos_ab_play_as_a](https://www.reddit.com/r/Games/comments/1g7s0e2/commander_tiberius_troubleson_jos_ab_play_as_a)
 - RSS feed: $source
 - date published: 2024-10-20T05:50:13+00:00

<!-- SC_OFF --><div class="md"><p>Test your resolve in this fast, unforgiving, action focused, roguelite platformer, where you play as a space wizard with a gun. No fall damage, no spikes.</p> <p>Try the demo on steam:</p> <p><a href="https://store.steampowered.com/app/2341710/Commander_Tiberius_Troubleson/">https://store.steampowered.com/app/2341710/Commander_Tiberius_Troubleson/</a></p> <p>Release Trailer:</p> <p><a href="https://youtu.be/-5eEvFsn4w4?si=-IZ2qp9G8BsVKkKt">https://youtu.be/-5eEvFsn4w4?si=-IZ2qp9G8BsVKkKt</a></p> <p>CTT combines random elements with a large pool of handcrafted levels that encourage exploration. Each level features a unique layout, special items, different secrets, challenges, bosses and mini bosses which makes each run feel very different.</p> <p>CTT&#39;s main focus is on action. Apart from your core skills, you will pickup spells, upgrades and level ups that will help you along the way. Die, improve and try again stronger. </p> </div><!-- SC_ON --> &

## METAL SUITS - Eggtart Inc - Platformer Action Shoot 'em up
 - [https://www.reddit.com/r/Games/comments/1g7rkld/metal_suits_eggtart_inc_platformer_action_shoot](https://www.reddit.com/r/Games/comments/1g7rkld/metal_suits_eggtart_inc_platformer_action_shoot)
 - RSS feed: $source
 - date published: 2024-10-20T05:18:55+00:00

<!-- SC_OFF --><div class="md"><p>Hello everyone. Today is a good Sunday!</p> <p>I am happy to introduce our game <strong>METAL SUITS</strong>!</p> <h1>Don&#39;t tick him off!!</h1> <p><strong>METAL SUITS</strong> is a game where the protagonist, who lost everything to an alien that suddenly appeared and was reborn as a cyborg, takes revenge on the aliens.</p> <p>Use various powerful metal combat suits to counterattack the aliens that have conquered all the planets.</p> <p>You must defeat them all, and find hidden things.</p> <p>There are mysterious planets, diverse enemies, threatening gimmicks, and powerful bosses, the success of the counterattack depends on your control!</p> <p><strong>Platforms</strong>: PC(Steam + @), Nintendo Switch, Playstation, Xbox</p> <p><strong>YouTube</strong>: <a href="https://www.youtube.com/watch?v=uAWjsii8PeQ">https://www.youtube.com/watch?v=uAWjsii8PeQ</a></p> <p><strong>Official Website</strong>: <a href="https://www.metalsuits.com/">https://www.meta

## MOMIBOSU - GCM - Precision 2D platformer inspired by Metroidvanias
 - [https://www.reddit.com/r/Games/comments/1g7qwhz/momibosu_gcm_precision_2d_platformer_inspired_by](https://www.reddit.com/r/Games/comments/1g7qwhz/momibosu_gcm_precision_2d_platformer_inspired_by)
 - RSS feed: $source
 - date published: 2024-10-20T04:33:07+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://store.steampowered.com/app/2487340?utm_source=Reddit&amp;utm_campaign=Demo&amp;utm_medium=POST1020">Steam Page</a> </p> <p>Hi. </p> <p>This game is currently featured in Steam Next Fest, and the demo is available to play for free! </p> <p>If you love Metroidvania and precise 2D platformers, be sure to give it a try!!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Peng_Momibosu"> /u/Peng_Momibosu </a> <br/> <span><a href="https://www.reddit.com/r/Games/comments/1g7qwhz/momibosu_gcm_precision_2d_platformer_inspired_by/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7qwhz/momibosu_gcm_precision_2d_platformer_inspired_by/">[comments]</a></span>

## Lo-Fi Room - Bearmask - A lo-fi hip-hop inspired hidden object and rhythm
 - [https://www.reddit.com/r/Games/comments/1g7qomp/lofi_room_bearmask_a_lofi_hiphop_inspired_hidden](https://www.reddit.com/r/Games/comments/1g7qomp/lofi_room_bearmask_a_lofi_hiphop_inspired_hidden)
 - RSS feed: $source
 - date published: 2024-10-20T04:18:38+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://youtu.be/UcmGWFHnRKM">Trailer</a></p> <p><a href="https://store.steampowered.com/app/2980020/LoFi_Room/">Steam Page</a></p> <p><a href="https://bearmask.itch.io/lofi-room">Free Web Demo (itch)</a></p> <p>Hi, I&#39;ve just released the Steam Page for Lo-Fi Room! I&#39;ve been working on it for a long time and a free web demo has been available on itch from the start of development (in 2018).<br/> It started off as a game jam game and I&#39;m working to build the full ~30 level version.</p> <p>Lo-Fi Room is a hidden object &amp; rhythm game where you build lo-fi beats by finding instruments and playing their loops one at a time.<br/> Play through a relaxing day of music, make &amp; share your own beats and play endless procedurally generated beats.</p> <p>Thanks!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bearmask_io"> /u/bearmask_io </a> <br/> <span><a href="https://www.reddit.com/r/Games/com

## Indie Sunday Hub - October 20, 2024
 - [https://www.reddit.com/r/Games/comments/1g7qeo9/indie_sunday_hub_october_20_2024](https://www.reddit.com/r/Games/comments/1g7qeo9/indie_sunday_hub_october_20_2024)
 - RSS feed: $source
 - date published: 2024-10-20T04:01:22+00:00

<!-- SC_OFF --><div class="md"><p>Welcome to another Indie Sunday! <strong>This event starts at 12 AM EST and will run for 24 hours.</strong></p> <p>Please read the below guidelines carefully before participating. If you have any questions please don&#39;t hesitate to send us a modmail. </p> <p>A reminder that Rule 8 is not enforced during this event for submissions which follow the participation guidelines. </p> <h1>Submission Restrictions</h1> <ul> <li><p>Games may be unreleased or finished</p></li> <li><p>You must provide video footage of the game in action. This can be a prototype, alpha, beta, etc. Images and concept art are nice but you must include a trailer or video of gameplay footage of the game. </p></li> <li><p>No key/game giveaways</p></li> <li><p>Only developers may make submissions for their games - if you would like to highlight a game on your own, please do so in this hub thread</p></li> <li><p>The same game/developer can not be shared more than once every 30 days. </

## The Legend of Zelda: Echoes of Wisdom has been out for a few weeks. What are your thoughts on it?
 - [https://www.reddit.com/r/Games/comments/1g7p6sk/the_legend_of_zelda_echoes_of_wisdom_has_been_out](https://www.reddit.com/r/Games/comments/1g7p6sk/the_legend_of_zelda_echoes_of_wisdom_has_been_out)
 - RSS feed: $source
 - date published: 2024-10-20T02:46:58+00:00

<!-- SC_OFF --><div class="md"><p>I just beat the final boss of Echoes of Wisdom last night and have been thinking about my experience with the game. Overall, I really enjoyed it, probably more than I expected. While it was an imperfect experience, it&#39;s exactly what I&#39;ve come to hope and expect from the Zelda series - a whole game based around a unique mechanic.</p> <p>The first hour or so of the game was charming, but I already was feeling friction - echoes were slow to attack and damage, running through the UI was tiring, and the first dungeon was very basic. But as the game continued, my playstyle changed while the content also improved. The second set of dungeons are much stronger than the earlier ones, new echoes made exploration open up considerably, and I started to embrace the &quot;summoner&quot; playstyle and realised it&#39;s not just about dumping monster echoes out and waiting for them to act - it&#39;s about positioning and casting the right ones and the right ti

## SimGrid Partnership, Customization, In-Game Economy: Kunos Shares Further Assetto Corsa EVO Details
 - [https://www.reddit.com/r/Games/comments/1g7oavk/simgrid_partnership_customization_ingame_economy](https://www.reddit.com/r/Games/comments/1g7oavk/simgrid_partnership_customization_ingame_economy)
 - RSS feed: $source
 - date published: 2024-10-20T01:55:21+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/messem10"> /u/messem10 </a> <br/> <span><a href="https://www.overtake.gg/news/simgrid-partnership-customization-in-game-economy-kunos-shares-further-assetto-corsa-evo-details.2523/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7oavk/simgrid_partnership_customization_ingame_economy/">[comments]</a></span>

## A Trip To Machida, The Real-Life 'Pallet Town' That Inspired Pokémon
 - [https://www.reddit.com/r/Games/comments/1g7no7t/a_trip_to_machida_the_reallife_pallet_town_that](https://www.reddit.com/r/Games/comments/1g7no7t/a_trip_to_machida_the_reallife_pallet_town_that)
 - RSS feed: $source
 - date published: 2024-10-20T01:19:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/No-You-5591"> /u/No-You-5591 </a> <br/> <span><a href="https://www.nintendolife.com/features/a-trip-to-machida-the-real-life-pallet-town-that-inspired-pokemon">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7no7t/a_trip_to_machida_the_reallife_pallet_town_that/">[comments]</a></span>

## Squadron 42 CitizenCon 2954 Live Gameplay Reveal
 - [https://www.reddit.com/r/Games/comments/1g7mhm0/squadron_42_citizencon_2954_live_gameplay_reveal](https://www.reddit.com/r/Games/comments/1g7mhm0/squadron_42_citizencon_2954_live_gameplay_reveal)
 - RSS feed: $source
 - date published: 2024-10-20T00:14:37+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.youtube.com/watch?v=1H-0x4xk2Xk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Games/comments/1g7mhm0/squadron_42_citizencon_2954_live_gameplay_reveal/">[comments]</a></span>

