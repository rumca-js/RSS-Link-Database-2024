# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## Tributes flow after pilot’s ‘sudden’ death
 - [https://www.news.com.au/travel/travel-updates/incidents/light-in-many-peoples-lives-familys-tearful-tribute-after-qantaslink-pilots-sudden-unexpected-death/news-story/d80891338312b5e81fa1bd5bb0df8472?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/light-in-many-peoples-lives-familys-tearful-tribute-after-qantaslink-pilots-sudden-unexpected-death/news-story/d80891338312b5e81fa1bd5bb0df8472?from=rss-basic)
 - RSS feed: $source
 - date published: 2024-10-20T03:35:07.603190+00:00

Family of a Qantaslink pilot have paid tribute to their “super human” brother and a “light in many people’s lives” following his “sudden and unexpected” death.

## ‘Not what foreigners think’: Truth behind common sight in Japan
 - [https://www.news.com.au/travel/destinations/asia/not-what-foreigners-think-truth-behind-common-sight-in-japan/news-story/55ebb3ca1c6373deaee782f6b6ee56ac?from=rss-basic](https://www.news.com.au/travel/destinations/asia/not-what-foreigners-think-truth-behind-common-sight-in-japan/news-story/55ebb3ca1c6373deaee782f6b6ee56ac?from=rss-basic)
 - RSS feed: $source
 - date published: 2024-10-20T01:29:54.215228+00:00

This common sight while walking the city streets of Japan serves a very different purpose than most foreigners assume.

