# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## INSULTING Politicians Correctly for a Better America
 - [https://www.youtube.com/watch?v=YVJZhZukj1Y](https://www.youtube.com/watch?v=YVJZhZukj1Y)
 - RSS feed: $source
 - date published: 2024-10-20T16:41:35+00:00

Compare news coverage. Spot media bias. Avoid algorithms. Try Ground News today and get 40% off your subscription by going to https://ground.news/AWAKEN 

Welcome to Brent Pella Saves America Episode 6! 
Tonight we teach you how to insult politicians correctly!
Brought to you by  @brentpella  

Get your Freedom Merch Here - https://awakenwithjp.com/shop

Upcoming LIVE shows - https://awakenwithjp.com/pages/tour

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
http://www.AwakenWithJP.com

