# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Trump smażył frytki w McDonaldzie, Harris poszła ze Steviem Wonderem do kościoła
 - [https://www.rmf24.pl/raporty/raport-wybory-prezydenta-usa-2024/fakty/news-trump-smazyl-frytki-w-mcdonaldzie-harris-poszla-ze-steviem-w,nId,7839860](https://www.rmf24.pl/raporty/raport-wybory-prezydenta-usa-2024/fakty/news-trump-smazyl-frytki-w-mcdonaldzie-harris-poszla-ze-steviem-w,nId,7839860)
 - RSS feed: $source
 - date published: 2024-10-20T21:39:17.319296+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wybory-prezydenta-usa-2024/fakty/news-trump-smazyl-frytki-w-mcdonaldzie-harris-poszla-ze-steviem-w,nId,7839860"><img src="https://interia-s.pluscdn.pl/trump-smazyl-frytki-w-mcdonaldzie-harris-poszla-ze-steviem-w/000JYL4WC84XCVED-C307.jpg" alt="Trump smażył frytki w McDonaldzie, Harris poszła ze Steviem Wonderem do kościoła" align="left" /></a>Donald Trump odwiedził restaurację McDonald's na przedmieściach Filadelfii, gdzie smażył frytki i obsługiwał kasę drive-thru. Tymczasem Kamala Harris wystąpiła w afroamerykańskim kościele w Georgii, gdzie świętowała 60. urodziny u boku Steviego Wondera.</p><br clear="all" />

## Częściowe wyniki w Mołdawii: Sandu prowadzi w wyborach, referendum na „nie”
 - [https://www.rmf24.pl/fakty/swiat/news-czesciowe-wyniki-w-moldawii-sandu-prowadzi-w-wyborach-refere,nId,7839864](https://www.rmf24.pl/fakty/swiat/news-czesciowe-wyniki-w-moldawii-sandu-prowadzi-w-wyborach-refere,nId,7839864)
 - RSS feed: $source
 - date published: 2024-10-20T21:39:17.076327+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-czesciowe-wyniki-w-moldawii-sandu-prowadzi-w-wyborach-refere,nId,7839864"><img src="https://interia-s.pluscdn.pl/czesciowe-wyniki-w-moldawii-sandu-prowadzi-w-wyborach-refere/000JYL5GD3BBPKPV-C307.jpg" alt="Częściowe wyniki w Mołdawii: Sandu prowadzi w wyborach, referendum na „nie” " align="left" /></a>Maia Sandu, która ubiega się o reelekcję, prowadzi w niedzielnych wyborach prezydenckich w Mołdawii z wynikiem 35,8 proc. po zliczeniu 55 proc. głosów. W referendum dotyczącym wpisania wejścia kraju do UE do konstytucji po przeliczeniu głosów z 59 proc. komisji odpowiedź „nie” wybrało 55,5 proc. osób.</p><br clear="all" />

## Ekstraklasa piłkarska: Rozpędzony Raków wiceliderem, Śląsk znów bez wygranej
 - [https://www.rmf24.pl/sport/news-ekstraklasa-pilkarska-rozpedzony-rakow-wiceliderem-slask-zno,nId,7839823](https://www.rmf24.pl/sport/news-ekstraklasa-pilkarska-rozpedzony-rakow-wiceliderem-slask-zno,nId,7839823)
 - RSS feed: $source
 - date published: 2024-10-20T20:33:46.917430+00:00

<p><a href="https://www.rmf24.pl/sport/news-ekstraklasa-pilkarska-rozpedzony-rakow-wiceliderem-slask-zno,nId,7839823"><img src="https://interia-s.pluscdn.pl/ekstraklasa-pilkarska-rozpedzony-rakow-wiceliderem-slask-zno/000JYKYCMOLUKAQW-C307.jpg" alt="Ekstraklasa piłkarska: Rozpędzony Raków wiceliderem, Śląsk znów bez wygranej " align="left" /></a>Piłkarze Rakowa Częstochowa odnieśli piąte ligowe zwycięstwo z rzędu. W 12. kolejce ekstraklasy pokonali u siebie Pogoń Szczecin 1:0 i zajmują drugie miejsce w tabeli. Bez zwycięstwa w sezonie pozostaje ostatni Ślask, tym razem wrocławianie zremisowali w Katowicach z GKS 0:0.</p><br clear="all" />

## "Jest ich więcej". Sfilmowano żołnierzy Kim Dzong Una przed wyruszeniem na Ukrainę
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-jest-ich-wiecej-sfilmowano-zolnierzy-kim-dzong-una-przed-wyr,nId,7839814](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-jest-ich-wiecej-sfilmowano-zolnierzy-kim-dzong-una-przed-wyr,nId,7839814)
 - RSS feed: $source
 - date published: 2024-10-20T20:33:45.589284+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-jest-ich-wiecej-sfilmowano-zolnierzy-kim-dzong-una-przed-wyr,nId,7839814"><img src="https://interia-s.pluscdn.pl/jest-ich-wiecej-sfilmowano-zolnierzy-kim-dzong-una-przed-wyr/000JYKWFF6NQPEV8-C307.jpg" alt="&quot;Jest ich więcej&quot;. Sfilmowano żołnierzy Kim Dzong Una przed wyruszeniem na Ukrainę" align="left" /></a>Kijów opublikował nagranie, które ma potwierdzać, że północnokoreańscy żołnierze przechodzą szkolenia w rosyjskich obozach wojskowych zanim dołączą do armii walczącej na froncie w Ukrainie.</p><br clear="all" />

## Działaczka opozycji porwana, pobita i pozostawiona w dżungli
 - [https://www.rmf24.pl/fakty/swiat/news-dzialaczka-opozycji-porwana-pobita-i-pozostawiona-w-dzungli,nId,7839807](https://www.rmf24.pl/fakty/swiat/news-dzialaczka-opozycji-porwana-pobita-i-pozostawiona-w-dzungli,nId,7839807)
 - RSS feed: $source
 - date published: 2024-10-20T19:09:01.305603+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-dzialaczka-opozycji-porwana-pobita-i-pozostawiona-w-dzungli,nId,7839807"><img src="https://interia-s.pluscdn.pl/dzialaczka-opozycji-porwana-pobita-i-pozostawiona-w-dzungli/000JYKQVFA3MTC6V-C307.jpg" alt="Działaczka opozycji porwana, pobita i pozostawiona w dżungli" align="left" /></a>Niezidentyfikowani mężczyźni porwali, pobili i poważnie zranili wysoką rangą działaczkę tanzańskiej partii opozycyjnej. Kobietę porzucili później w dżungli. Wydarzenia miały miejsce miesiąc po tym, gdy porwano i zamordowano innego lidera opozycyjnej partii.</p><br clear="all" />

## Applebaum odbiera nagrodę, krytykuje niemiecki pacyfizm i opowiada się za pomocą Ukrainie
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-applebaum-odbiera-nagrode-krytykuje-niemiecki-pacyfizm-i-opo,nId,7839797](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-applebaum-odbiera-nagrode-krytykuje-niemiecki-pacyfizm-i-opo,nId,7839797)
 - RSS feed: $source
 - date published: 2024-10-20T18:04:29.473445+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-applebaum-odbiera-nagrode-krytykuje-niemiecki-pacyfizm-i-opo,nId,7839797"><img src="https://interia-s.pluscdn.pl/applebaum-odbiera-nagrode-krytykuje-niemiecki-pacyfizm-i-opo/000JYKNO93QG46I3-C307.jpg" alt="Applebaum odbiera nagrodę, krytykuje niemiecki pacyfizm i opowiada się za pomocą Ukrainie" align="left" /></a>Anne Applebaum odebrała we Frankfurcie Nagrodą Pokojową Niemieckich Księgarzy. Polsko-amerykańska publicystka, zdobywczyni nagrody Pulitzera w swoim przemówieniu skrytykowała &quot;pacyfizm za wszelką cenę&quot; i wezwała do pomocy militarnej Ukrainie.</p><br clear="all" />

## Powódź w rejonie Bolonii. Zalane lotnisko, ulicami płyną rwące potoki [ZDJĘCIA]
 - [https://www.rmf24.pl/fakty/swiat/news-powodz-w-rejonie-bolonii-zalane-lotnisko-ulicami-plyna-rwace,nId,7839800](https://www.rmf24.pl/fakty/swiat/news-powodz-w-rejonie-bolonii-zalane-lotnisko-ulicami-plyna-rwace,nId,7839800)
 - RSS feed: $source
 - date published: 2024-10-20T18:04:29.275055+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-powodz-w-rejonie-bolonii-zalane-lotnisko-ulicami-plyna-rwace,nId,7839800"><img src="https://interia-s.pluscdn.pl/powodz-w-rejonie-bolonii-zalane-lotnisko-ulicami-plyna-rwace/000JYKOC3H7J2RN2-C307.jpg" alt="Powódź w rejonie Bolonii. Zalane lotnisko, ulicami płyną rwące potoki [ZDJĘCIA]" align="left" /></a>Jedna osoba zginęła w wyniku powodzi w rejonie Bolonii - podały miejscowe władze. 20-latek utonął w nocy z soboty na niedzielę w samochodzie porwanym przez nurt rzeki, która wystąpiła z brzegów w miejscowości Pianoro. W Bolonii i okolicach trwa wielkie sprzątanie po fali powodziowej.</p><br clear="all" />

## Pięć osób rannych w wypadku na krajowej "59". Ucierpiało dwoje dzieci
 - [https://www.rmf24.pl/regiony/olsztyn/news-piec-osob-rannych-w-wypadku-na-krajowej-59-ucierpialo-dwoje-,nId,7839780](https://www.rmf24.pl/regiony/olsztyn/news-piec-osob-rannych-w-wypadku-na-krajowej-59-ucierpialo-dwoje-,nId,7839780)
 - RSS feed: $source
 - date published: 2024-10-20T17:50:48+00:00

<p><a href="https://www.rmf24.pl/regiony/olsztyn/news-piec-osob-rannych-w-wypadku-na-krajowej-59-ucierpialo-dwoje-,nId,7839780"><img src="https://interia-s.pluscdn.pl/piec-osob-rannych-w-wypadku-na-krajowej-59-ucierpialo-dwoje/000JYKGCH7HTO13C-C307.jpg" alt="Pięć osób rannych w wypadku na krajowej &quot;59&quot;. Ucierpiało dwoje dzieci" align="left" /></a>Groźny wypadek w Warmińsko-Mazurskiem. Pięć osób zostało rannych w wyniku zderzenia dwóch aut osobowych. Wśród poszkodowanych jest dwoje dzieci. 
</p><br clear="all" />

## Krzysztof Brejza gościem Rozmowy o 7:00 w Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-krzysztof-brejza-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7839784](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-krzysztof-brejza-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7839784)
 - RSS feed: $source
 - date published: 2024-10-20T16:58:27.608256+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-krzysztof-brejza-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7839784"><img src="https://interia-s.pluscdn.pl/krzysztof-brejza-gosciem-rozmowy-o-7-00-w-radiu-rmf24/000JYKGZEESUTNRU-C307.jpg" alt="Krzysztof Brejza gościem Rozmowy o 7:00 w Radiu RMF24" align="left" /></a>Gościem Tomasza Terlikowskiego w Rozmowie o 7:00 w Radiu RMF24 będzie Krzysztof Brejza, europoseł Koalicji Obywatelskiej.</p><br clear="all" />

## 85-latek jechał pod prąd A1. "Z Gliwic dojechał do Bytomia"
 - [https://www.rmf24.pl/regiony/slaskie/news-85-latek-jechal-pod-prad-a1-z-gliwic-dojechal-do-bytomia,nId,7839792](https://www.rmf24.pl/regiony/slaskie/news-85-latek-jechal-pod-prad-a1-z-gliwic-dojechal-do-bytomia,nId,7839792)
 - RSS feed: $source
 - date published: 2024-10-20T16:58:27.064554+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-85-latek-jechal-pod-prad-a1-z-gliwic-dojechal-do-bytomia,nId,7839792"><img src="https://interia-s.pluscdn.pl/85-latek-jechal-pod-prad-a1-z-gliwic-dojechal-do-bytomia/000JYKKL0WJ0CRTT-C307.jpg" alt="85-latek jechał pod prąd A1. &quot;Z Gliwic dojechał do Bytomia&quot;" align="left" /></a>Policjanci zatrzymali 85-letniego kierowcę hyundaia, który w Gliwicach pomylił zjazdy i wjechał pod prąd na autostradę A1. W taki sposób dotarł aż do Bytomia. Zatrzymano mu prawo jazdy – podała policja.</p><br clear="all" />

## Śmierć byłego wiceprezesa Jukosu. Miał wypaść przez okno
 - [https://www.rmf24.pl/fakty/swiat/news-smierc-bylego-wiceprezesa-jukosu-mial-wypasc-przez-okno,nId,7839785](https://www.rmf24.pl/fakty/swiat/news-smierc-bylego-wiceprezesa-jukosu-mial-wypasc-przez-okno,nId,7839785)
 - RSS feed: $source
 - date published: 2024-10-20T16:58:26.488547+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-smierc-bylego-wiceprezesa-jukosu-mial-wypasc-przez-okno,nId,7839785"><img src="https://interia-s.pluscdn.pl/smierc-bylego-wiceprezesa-jukosu-mial-wypasc-przez-okno/000JYKJISH0KWTEJ-C307.jpg" alt="Śmierć byłego wiceprezesa Jukosu. Miał wypaść przez okno" align="left" /></a>Nie żyje były wiceprezes ds. zarządzania korporacyjnego koncernu naftowego Jukos Michaił Rogaczow. Został znaleziony martwy na chodniku przed domem. Według lokalnych mediów wypadł z okna.</p><br clear="all" />

## Zachód kontra Rosja. Trwa bitwa o Mołdawię
 - [https://www.rmf24.pl/fakty/swiat/news-zachod-kontra-rosja-trwa-bitwa-o-moldawie,nId,7839758](https://www.rmf24.pl/fakty/swiat/news-zachod-kontra-rosja-trwa-bitwa-o-moldawie,nId,7839758)
 - RSS feed: $source
 - date published: 2024-10-20T16:58:25.951535+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-zachod-kontra-rosja-trwa-bitwa-o-moldawie,nId,7839758"><img src="https://interia-s.pluscdn.pl/zachod-kontra-rosja-trwa-bitwa-o-moldawie/000JYKE98AQXIP4D-C307.jpg" alt="Zachód kontra Rosja. Trwa bitwa o Mołdawię" align="left" /></a>Przyszłość Mołdawii decyduje się w cieniu rosyjskiej intensywnej kampanii propagandowej. Na lotnisku w Kiszyniowie wprowadzono wzmożone kontrole, w obawie przed agentami Moskwy, którzy walizkami dostarczają gotówkę - ta pomoże ingerować w wybory. W akcję antyrosyjską zaangażowały się także amerykańskie i natowskie służby. Mołdawianie głosują dziś w wyborach prezydenckich i referendum w sprawie przystąpienia do Unii Europejskiej.</p><br clear="all" />

## Trzy osoby ranne w wypadku na krajowej "59". Ucierpiało dwoje dzieci
 - [https://www.rmf24.pl/regiony/olsztyn/news-trzy-osoby-ranne-w-wypadku-na-krajowej-59-ucierpialo-dwoje-d,nId,7839780](https://www.rmf24.pl/regiony/olsztyn/news-trzy-osoby-ranne-w-wypadku-na-krajowej-59-ucierpialo-dwoje-d,nId,7839780)
 - RSS feed: $source
 - date published: 2024-10-20T16:58:25.427528+00:00

<p><a href="https://www.rmf24.pl/regiony/olsztyn/news-trzy-osoby-ranne-w-wypadku-na-krajowej-59-ucierpialo-dwoje-d,nId,7839780"><img src="https://interia-s.pluscdn.pl/trzy-osoby-ranne-w-wypadku-na-krajowej-59-ucierpialo-dwoje-d/000JYKGCH7HTO13C-C307.jpg" alt="Trzy osoby ranne w wypadku na krajowej &quot;59&quot;. Ucierpiało dwoje dzieci" align="left" /></a>Groźny wypadek w Warmińsko-Mazurskiem. Trzy osoby zostały ranne w wyniku zderzenia dwóch aut osobowych. Wśród poszkodowanych jest dwoje dzieci. 
</p><br clear="all" />

## Dwucyfrowy mróz i pierwszy śnieg szybciej niż się wydaje. Podano datę
 - [https://www.rmf24.pl/pogoda/news-dwucyfrowy-mroz-i-pierwszy-snieg-szybciej-niz-sie-wydaje-pod,nId,7839762](https://www.rmf24.pl/pogoda/news-dwucyfrowy-mroz-i-pierwszy-snieg-szybciej-niz-sie-wydaje-pod,nId,7839762)
 - RSS feed: $source
 - date published: 2024-10-20T15:54:27.811526+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-dwucyfrowy-mroz-i-pierwszy-snieg-szybciej-niz-sie-wydaje-pod,nId,7839762"><img src="https://interia-s.pluscdn.pl/dwucyfrowy-mroz-i-pierwszy-snieg-szybciej-niz-sie-wydaje-pod/000JYK6MUYCPKSA0-C307.jpg" alt="Dwucyfrowy mróz i pierwszy śnieg szybciej niż się wydaje. Podano datę" align="left" /></a>Niebawem przydadzą się zdecydowanie cieplejsze buty i ubrania. Powinniśmy się szykować na atak zimy i to już w połowie listopada - wynika z analizy serwisu fanipogody.pl przeprowadzonej na podstawie modeli meteorologicznych. </p><br clear="all" />

## Jarosław Gwizdak został pełnomocnikiem Adama Bodnara ds. otwartego wymiaru sprawiedliwości
 - [https://www.rmf24.pl/polityka/news-jaroslaw-gwizdak-zostal-pelnomocnikiem-adama-bodnara-ds-otwa,nId,7839736](https://www.rmf24.pl/polityka/news-jaroslaw-gwizdak-zostal-pelnomocnikiem-adama-bodnara-ds-otwa,nId,7839736)
 - RSS feed: $source
 - date published: 2024-10-20T14:48:14.942586+00:00

<p><a href="https://www.rmf24.pl/polityka/news-jaroslaw-gwizdak-zostal-pelnomocnikiem-adama-bodnara-ds-otwa,nId,7839736"><img src="https://interia-s.pluscdn.pl/jaroslaw-gwizdak-zostal-pelnomocnikiem-adama-bodnara-ds-otwa/000JYK33O1292LTD-C307.jpg" alt="Jarosław Gwizdak został pełnomocnikiem Adama Bodnara ds. otwartego wymiaru sprawiedliwości" align="left" /></a>Jarosław Gwizdak został dziś powołany na stanowisko Pełnomocnika Ministra Sprawiedliwości ds. otwartego wymiaru sprawiedliwości. Informację ogłosił resort na swojej stronie internetowej.</p><br clear="all" />

## W środę debata o migracji w Parlamencie Europejskim
 - [https://www.rmf24.pl/polityka/news-w-srode-debata-o-migracji-w-parlamencie-europejskim,nId,7839753](https://www.rmf24.pl/polityka/news-w-srode-debata-o-migracji-w-parlamencie-europejskim,nId,7839753)
 - RSS feed: $source
 - date published: 2024-10-20T14:48:14.829671+00:00

<p><a href="https://www.rmf24.pl/polityka/news-w-srode-debata-o-migracji-w-parlamencie-europejskim,nId,7839753"><img src="https://interia-s.pluscdn.pl/w-srode-debata-o-migracji-w-parlamencie-europejskim/000JYK2NHAWPWC3C-C307.jpg" alt="W środę debata o migracji w Parlamencie Europejskim" align="left" /></a>Najważniejszym punktem przyszłotygodniowej sesji Parlamentu Europejskiego będzie debata o migracji. Europosłowie będą rozmawiać o wynikach zakończonego w czwartek wieczorem szczytu unijnego w Brukseli.</p><br clear="all" />

## Nadchodzi zmiana prawa w UE. Chodzi o zwiększenie finansowania usuwania skutków powodzi
 - [https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-nadchodzi-zmiana-prawa-w-ue-chodzi-o-zwiekszenie-finansowani,nId,7839725](https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-nadchodzi-zmiana-prawa-w-ue-chodzi-o-zwiekszenie-finansowani,nId,7839725)
 - RSS feed: $source
 - date published: 2024-10-20T14:13:56+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-nadchodzi-zmiana-prawa-w-ue-chodzi-o-zwiekszenie-finansowani,nId,7839725"><img src="https://interia-s.pluscdn.pl/nadchodzi-zmiana-prawa-w-ue-chodzi-o-zwiekszenie-finansowani/000JYJ8OOU7J2QH8-C307.jpg" alt="Nadchodzi zmiana prawa w UE. Chodzi o zwiększenie finansowania usuwania skutków powodzi" align="left" /></a>W ciągu najbliższych dni Komisja Europejska ma przedstawić propozycję zmian prawnych w funduszach unijnych. Chodzi o stworzenie mechanizmu wypłaty wsparcia krajom dotkniętym ostatnimi powodziami - dowiedziała się nieoficjalnie dziennikarka RMF FM Katarzyna Szymańska-Borginon. Na razie z unijnych funduszy nie wypłacano na wsparcie dla powodzian ani jednego euro ani z funduszy spójności ani z Funduszu Solidarności.</p><br clear="all" />

## Firmy już szukają pracowników sezonowych. Powód to... Boże Narodzenie
 - [https://www.rmf24.pl/ekonomia/news-firmy-juz-szukaja-pracownikow-sezonowych-powod-to-boze-narod,nId,7838443](https://www.rmf24.pl/ekonomia/news-firmy-juz-szukaja-pracownikow-sezonowych-powod-to-boze-narod,nId,7838443)
 - RSS feed: $source
 - date published: 2024-10-20T13:42:56.342703+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-firmy-juz-szukaja-pracownikow-sezonowych-powod-to-boze-narod,nId,7838443"><img src="https://interia-s.pluscdn.pl/firmy-juz-szukaja-pracownikow-sezonowych-powod-to-boze-narod/000JY8UO1282IIYB-C307.jpg" alt="Firmy już szukają pracowników sezonowych. Powód to... Boże Narodzenie" align="left" /></a>Choć w drugiej połowie października może brzmieć to zaskakująco, rośnie liczba ofert pracy sezonowej związanych z tegorocznymi Świętami Bożego Narodzenia. Do samych Świąt jeszcze ponad dwa miesiące, a dodatkowi pracownicy już są poszukiwani.</p><br clear="all" />

## Musk agituje na rzecz Trumpa i płaci milion dolarów za podpis pod petycją
 - [https://www.rmf24.pl/raporty/raport-wybory-prezydenta-usa-2024/fakty/news-musk-agituje-na-rzecz-trumpa-i-placi-milion-dolarow-za-podpi,nId,7839731](https://www.rmf24.pl/raporty/raport-wybory-prezydenta-usa-2024/fakty/news-musk-agituje-na-rzecz-trumpa-i-placi-milion-dolarow-za-podpi,nId,7839731)
 - RSS feed: $source
 - date published: 2024-10-20T13:42:56.052572+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wybory-prezydenta-usa-2024/fakty/news-musk-agituje-na-rzecz-trumpa-i-placi-milion-dolarow-za-podpi,nId,7839731"><img src="https://interia-s.pluscdn.pl/musk-agituje-na-rzecz-trumpa-i-placi-milion-dolarow-za-podpi/000JYJCQAWTDFYND-C307.jpg" alt="Musk agituje na rzecz Trumpa i płaci milion dolarów za podpis pod petycją" align="left" /></a>Elon Musk obiecał, że aż do listopadowych wyborów prezydenckich w USA będzie wypłacał 1 mln dolarów dziennie osobie, która podpisze jego internetową petycję dotyczącą wolności wypowiedzi i prawa do noszenia broni. Jak obiecał, tak też uczynił. Pierwszy milion został już wypłacony w sobotę, a obserwatorzy zastanawiają się, jak daleko może posunąć się miliarder we wsparciu kampanii Donalda Trumpa.</p><br clear="all" />

## Tragiczny karambol na S7. Kierowca ciężarówki usłyszał zarzut
 - [https://www.rmf24.pl/regiony/trojmiasto/news-tragiczny-karambol-na-s7-kierowca-ciezarowki-uslyszal-zarzut,nId,7839737](https://www.rmf24.pl/regiony/trojmiasto/news-tragiczny-karambol-na-s7-kierowca-ciezarowki-uslyszal-zarzut,nId,7839737)
 - RSS feed: $source
 - date published: 2024-10-20T13:42:55.730651+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-tragiczny-karambol-na-s7-kierowca-ciezarowki-uslyszal-zarzut,nId,7839737"><img src="https://interia-s.pluscdn.pl/tragiczny-karambol-na-s7-kierowca-ciezarowki-uslyszal-zarzut/000JYJCYAT8NL3MT-C307.jpg" alt="Tragiczny karambol na S7. Kierowca ciężarówki usłyszał zarzut" align="left" /></a>Zarzut popełniania katastrofy w ruchu lądowym usłyszał Mateusz M. - 37-letni kierowca, który doprowadził do karambolu na obwodnicy Gdańska. W wypadku zginęły 4 osoby, w tym dwóch chłopców w wieku 7 i 10 lat.</p><br clear="all" />

## 5 mld euro na usuwanie skutków powodzi w Europie. Decyzja coraz bliżej
 - [https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-5-mld-euro-na-usuwanie-skutkow-powodzi-w-europie-decyzja-cor,nId,7839725](https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-5-mld-euro-na-usuwanie-skutkow-powodzi-w-europie-decyzja-cor,nId,7839725)
 - RSS feed: $source
 - date published: 2024-10-20T12:37:48.832836+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-5-mld-euro-na-usuwanie-skutkow-powodzi-w-europie-decyzja-cor,nId,7839725"><img src="https://interia-s.pluscdn.pl/5-mld-euro-na-usuwanie-skutkow-powodzi-w-europie-decyzja-cor/000JYJ8OOU7J2QH8-C307.jpg" alt="5 mld euro na usuwanie skutków powodzi w Europie. Decyzja coraz bliżej" align="left" /></a>W ciągu najbliższych dni Komisja Europejska ma przedstawić propozycję zmian prawnych w funduszach unijnych. Chodzi o stworzenie mechanizmu wypłaty wsparcia krajom dotkniętym ostatnimi powodziami - dowiedziała się nieoficjalnie dziennikarka RMF FM.</p><br clear="all" />

## Portret oszczędnego Polaka. Sprawdziliśmy, jak odkładają młodsi i starsi
 - [https://www.rmf24.pl/ekonomia/news-portret-oszczednego-polaka-sprawdzilismy-jak-odkladaja-mlods,nId,7839664](https://www.rmf24.pl/ekonomia/news-portret-oszczednego-polaka-sprawdzilismy-jak-odkladaja-mlods,nId,7839664)
 - RSS feed: $source
 - date published: 2024-10-20T12:37:48.436337+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-portret-oszczednego-polaka-sprawdzilismy-jak-odkladaja-mlods,nId,7839664"><img src="https://interia-s.pluscdn.pl/portret-oszczednego-polaka-sprawdzilismy-jak-odkladaja-mlods/000JYJ59N2DLXYXW-C307.jpg" alt="Portret oszczędnego Polaka. Sprawdziliśmy, jak odkładają młodsi i starsi" align="left" /></a>Dorośli szukają promocji w sklepach, unikają stołowania się w restauracji i wybierają transport publiczny, a dzieci oraz młodzież odkładają z kieszonkowego lub z otrzymanych na urodziny pieniędzy - tak oszczędzają Polacy. Dziennikarze RMF FM zapytali mieszkańców Warszawy, Lublina i Wrocławia o ich sposoby na odkładanie pieniędzy na później. A na później lepiej tego nie odkładać. &quot;Często słyszymy argument, że mnie nie stać na oszczędzanie i jest to w obecnej sytuacji argument całkowicie błędny&quot; - zwraca uwagę Paweł Majtkowski, analityk...</p><br clear="all" />

## Awaria w banku ING
 - [https://www.rmf24.pl/ekonomia/news-awaria-w-banku-ing,nId,7839683](https://www.rmf24.pl/ekonomia/news-awaria-w-banku-ing,nId,7839683)
 - RSS feed: $source
 - date published: 2024-10-20T11:34:03+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-awaria-w-banku-ing,nId,7839683"><img src="https://interia-s.pluscdn.pl/awaria-w-banku-ing/000JYILJ36NT6B6U-C307.jpg" alt="Awaria w banku ING" align="left" /></a>&quot;Obecnie wszystkie nasze systemy działają już prawidłowo. Przepraszamy Was za utrudnienia&quot; - przekazał po godz. 12 ING Polska. Wcześniej, przez kilkadziesiąt minut, klienci banku nie mogli korzystać z aplikacji i nie działała poprawnie strona, po zalogowaniu.</p><br clear="all" />

## Złota jesień na Jurze. Zachywcające zdjęcia
 - [https://www.rmf24.pl/foto/zdjecie,iId,3454991,iAId,450724](https://www.rmf24.pl/foto/zdjecie,iId,3454991,iAId,450724)
 - RSS feed: $source
 - date published: 2024-10-20T11:33:01.446031+00:00

<p><a href="https://www.rmf24.pl/foto/zdjecie,iId,3454991,iAId,450724"><img src="https://interia-s.pluscdn.pl/zlota-jesien-na-jurze-zachywcajace-zdjecia/000JYJ2M7C4IB16U-C307.jpg" alt="Złota jesień na Jurze. Zachywcające zdjęcia" align="left" /></a>Pomarańcz, czerwień, zieleń czy brąz. Złota polska jesień komponuje swoją szatę z wielu kolorów, okraszając je promieniami słońca. Tych ostatnio nie brakuje, co cieszy spacerowiczów zarówno w miastach, jak i poza nimi. Reporter RMF FM Marcin Buczek wybrał się na przechadzkę po Jurze Krakowsko-Częstochowskiej, skąd przysłał wspaniałe zdjęcia ilustrujące tamtejszy spektakl przyrody.</p><br clear="all" />

## Zmiana czasu na zimowy 2024. Kiedy trzeba przestawić zegarki?
 - [https://www.rmf24.pl/fakty/polska/news-zmiana-czasu-na-zimowy-2024-kiedy-trzeba-przestawic-zegarki,nId,7839686](https://www.rmf24.pl/fakty/polska/news-zmiana-czasu-na-zimowy-2024-kiedy-trzeba-przestawic-zegarki,nId,7839686)
 - RSS feed: $source
 - date published: 2024-10-20T11:33:01.161285+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-zmiana-czasu-na-zimowy-2024-kiedy-trzeba-przestawic-zegarki,nId,7839686"><img src="https://interia-s.pluscdn.pl/zmiana-czasu-na-zimowy-2024-kiedy-trzeba-przestawic-zegarki/000JYILHLMF7SELU-C307.jpg" alt="Zmiana czasu na zimowy 2024. Kiedy trzeba przestawić zegarki? " align="left" /></a>Polska złota jesień coraz częściej zaskakuje ulewnymi deszczami i gwałtownym spadkiem temperatury. Dni są coraz krótsze, a chłodne i ciemne wieczory dłużą się bezlitośnie. To znak, że zbliża się zima i czeka nas zmiana czasu. Kiedy przestawiamy zegarki? Sprawdź! </p><br clear="all" />

## Awaria w banku ING. "Trwa naprawa"
 - [https://www.rmf24.pl/ekonomia/news-awaria-w-banku-ing-trwa-naprawa,nId,7839683](https://www.rmf24.pl/ekonomia/news-awaria-w-banku-ing-trwa-naprawa,nId,7839683)
 - RSS feed: $source
 - date published: 2024-10-20T10:27:13.553335+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-awaria-w-banku-ing-trwa-naprawa,nId,7839683"><img src="https://interia-s.pluscdn.pl/awaria-w-banku-ing-trwa-naprawa/000JYILJ36NT6B6U-C307.jpg" alt="Awaria w banku ING. &quot;Trwa naprawa&quot;" align="left" /></a>Brak możliwości zalogowania się do aplikacji i nieaktywne niektóre usługi na stronie internetowej po zalogowaniu - to dzisiejsze problemy klientów ING. Głos zabrał rzecznik banku.</p><br clear="all" />

## Dramatyczny wypadek w Warszawie. Poważnie ranni nastolatkowie
 - [https://www.rmf24.pl/regiony/warszawa/news-dramatyczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie,nId,7839678](https://www.rmf24.pl/regiony/warszawa/news-dramatyczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie,nId,7839678)
 - RSS feed: $source
 - date published: 2024-10-20T10:27:13.402959+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-dramatyczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie,nId,7839678"><img src="https://interia-s.pluscdn.pl/dramatyczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie/000JYIKH2OBKWUJ7-C307.jpg" alt="Dramatyczny wypadek w Warszawie. Poważnie ranni nastolatkowie" align="left" /></a>W sobotę późnym wieczorem w warszawskiej dzielnicy Wesoła doszło do poważnego wypadku na skrzyżowaniu ulic Niemcewicza i Narutowicza. Auto, które próbowało uniknąć samochodu wymuszającego pierwszeństwo, wypadło z jezdni i wpadło w drzewa. 5 osób zostało rannych. Uderzenie było tak silne, że urwało silnik pojazdu.</p><br clear="all" />

## Dwójka dzieci wśród ofiar karambolu na S7
 - [https://www.rmf24.pl/regiony/trojmiasto/news-dwojka-dzieci-wsrod-ofiar-karambolu-na-s7,nId,7839684](https://www.rmf24.pl/regiony/trojmiasto/news-dwojka-dzieci-wsrod-ofiar-karambolu-na-s7,nId,7839684)
 - RSS feed: $source
 - date published: 2024-10-20T10:27:13.125525+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-dwojka-dzieci-wsrod-ofiar-karambolu-na-s7,nId,7839684"><img src="https://interia-s.pluscdn.pl/dwojka-dzieci-wsrod-ofiar-karambolu-na-s7/000JYIMCU2OBJSEL-C307.jpg" alt="Dwójka dzieci wśród ofiar karambolu na S7" align="left" /></a>Dwie spośród czterech osób, które zginęły w piątkowym karambolu na trasie S7 w okolicach Gdańska to dzieci. Jedno z nich miało 7, a drugie 10 lat. Taką informację przekazała prokuratura w Gdańsku. Do godziny 13 ma rozpocząć się przesłuchanie 37-letniego kierowcy, który jest sprawcą wypadku.</p><br clear="all" />

## Tragiczny wypadek w Warszawie. Poważnie ranni nastolatkowie
 - [https://www.rmf24.pl/regiony/warszawa/news-tragiczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie,nId,7839678](https://www.rmf24.pl/regiony/warszawa/news-tragiczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie,nId,7839678)
 - RSS feed: $source
 - date published: 2024-10-20T09:22:06.090143+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-tragiczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie,nId,7839678"><img src="https://interia-s.pluscdn.pl/tragiczny-wypadek-w-warszawie-powaznie-ranni-nastolatkowie/000JYIKH2OBKWUJ7-C307.jpg" alt="Tragiczny wypadek w Warszawie. Poważnie ranni nastolatkowie" align="left" /></a>W sobotę późnym wieczorem w warszawskiej dzielnicy Wesoła doszło do poważnego wypadku na skrzyżowaniu ulic Niemcewicza i Narutowicza. Auto, które próbowało uniknąć samochodu wymuszającego pierwszeństwo, wypadło z jezdni i wpadło w drzewa. 5 osób zostało rannych. Uderzenie było tak silne, że urwało silnik pojazdu.</p><br clear="all" />

## Zbiorowy pozew przeciwko Wodom Polskim. Trwa zbieranie podpisów
 - [https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-zbiorowy-pozew-przeciwko-wodom-polskim-trwa-zbieranie-podpis,nId,7839674](https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-zbiorowy-pozew-przeciwko-wodom-polskim-trwa-zbieranie-podpis,nId,7839674)
 - RSS feed: $source
 - date published: 2024-10-20T09:22:05.834203+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-powodz-w-polsce-2024/fakty/news-zbiorowy-pozew-przeciwko-wodom-polskim-trwa-zbieranie-podpis,nId,7839674"><img src="https://interia-s.pluscdn.pl/zbiorowy-pozew-przeciwko-wodom-polskim-trwa-zbieranie-podpis/000JYIIHY3JJ1IHY-C307.jpg" alt="Zbiorowy pozew przeciwko Wodom Polskim. Trwa zbieranie podpisów" align="left" /></a>W Lewinie Brzeskim trwa zbiórka podpisów pod pozwem zbiorowym przeciwko Wodom Polskim, którym zarzuca się błędne decyzje podczas wrześniowej powodzi. Akcja w Miejsko-Gminnym Domu Kultury zakończy się o godzinie 19.00. </p><br clear="all" />

## Masowa turystyka. Włochy chcą ją ograniczyć, Portugalia korzysta
 - [https://www.rmf24.pl/fakty/swiat/news-masowa-turystyka-wlochy-chca-ja-ograniczyc-portugalia-korzys,nId,7839559](https://www.rmf24.pl/fakty/swiat/news-masowa-turystyka-wlochy-chca-ja-ograniczyc-portugalia-korzys,nId,7839559)
 - RSS feed: $source
 - date published: 2024-10-20T08:17:27.005347+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-masowa-turystyka-wlochy-chca-ja-ograniczyc-portugalia-korzys,nId,7839559"><img src="https://interia-s.pluscdn.pl/masowa-turystyka-wlochy-chca-ja-ograniczyc-portugalia-korzys/000JYIAGJEEU4YKV-C307.jpg" alt="Masowa turystyka. Włochy chcą ją ograniczyć, Portugalia korzysta" align="left" /></a>&quot;W Europie nie ma narzędzi, by uporać się z masowym napływem turystów&quot; - stwierdzili burmistrzowie włoskich miast. Urzędnicy chcą większych uprawnień, by móc ograniczać masową turystykę. Z kolei portugalscy przedsiębiorcy podwyższają turystyczne marże. Kraj mimo rekordowych cen, cieszy się niesłabnącym zainteresowaniem cudzoziemców.</p><br clear="all" />

## Siedem osób trafiło do szpitala po podtruciu czadem w Siemianowicach Śląskich
 - [https://www.rmf24.pl/regiony/slaskie/news-siedem-osob-trafilo-do-szpitala-po-podtruciu-czadem-w-siemia,nId,7839567](https://www.rmf24.pl/regiony/slaskie/news-siedem-osob-trafilo-do-szpitala-po-podtruciu-czadem-w-siemia,nId,7839567)
 - RSS feed: $source
 - date published: 2024-10-20T08:17:26.092872+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-siedem-osob-trafilo-do-szpitala-po-podtruciu-czadem-w-siemia,nId,7839567"><img src="https://interia-s.pluscdn.pl/siedem-osob-trafilo-do-szpitala-po-podtruciu-czadem-w-siemia/000JYICYFBDVE962-C307.jpg" alt="Siedem osób trafiło do szpitala po podtruciu czadem w Siemianowicach Śląskich" align="left" /></a>Siedmioro mieszkańców Siemianowic Śląskich trafiło do szpitala z objawami podtrucia czadem. Wśród poszkodowanych jest troje dzieci.</p><br clear="all" />

## Na wyspie Sapelo zawalił się pomost. Kilka osób nie żyje
 - [https://www.rmf24.pl/fakty/swiat/news-na-wyspie-sapelo-zawalil-sie-pomost-kilka-osob-nie-zyje,nId,7839553](https://www.rmf24.pl/fakty/swiat/news-na-wyspie-sapelo-zawalil-sie-pomost-kilka-osob-nie-zyje,nId,7839553)
 - RSS feed: $source
 - date published: 2024-10-20T07:11:30.940338+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-na-wyspie-sapelo-zawalil-sie-pomost-kilka-osob-nie-zyje,nId,7839553"><img src="https://interia-s.pluscdn.pl/na-wyspie-sapelo-zawalil-sie-pomost-kilka-osob-nie-zyje/000JYI8Z183RMVGM-C307.jpg" alt="Na wyspie Sapelo zawalił się pomost. Kilka osób nie żyje" align="left" /></a>Co najmniej siedem osób zginęło w wyniku zawalenia się pomostu na wyspie Sapelo w amerykańskim stanie Georgia. Jak podaje Reuters, okoliczności wypadku nie są znane. 
</p><br clear="all" />

## Jubileuszowy 10. Cracovia Półmaraton Królewski z rekordową frekwencją
 - [https://www.rmf24.pl/fakty/polska/news-jubileuszowy-10-cracovia-polmaraton-krolewski-z-rekordowa-fr,nId,7839542](https://www.rmf24.pl/fakty/polska/news-jubileuszowy-10-cracovia-polmaraton-krolewski-z-rekordowa-fr,nId,7839542)
 - RSS feed: $source
 - date published: 2024-10-20T07:11:30.520651+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-jubileuszowy-10-cracovia-polmaraton-krolewski-z-rekordowa-fr,nId,7839542"><img src="https://interia-s.pluscdn.pl/jubileuszowy-10-cracovia-polmaraton-krolewski-z-rekordowa-fr/000JYI6T8HOYS323-C307.jpg" alt="Jubileuszowy 10. Cracovia Półmaraton Królewski z rekordową frekwencją" align="left" /></a>12 tys. osób - dokładnie tylu miłośników biegania weźmie udział w jubileuszowej edycji Cracovia Półmaratonu Królewskiego. &quot;To rekordowa frekwencja&quot; - zapewniają organizatorzy. W niedzielę na kierowców i pasażerów komunikacji miejskiej czekają spore utrudnienia w związku z biegiem. </p><br clear="all" />

## Hamas: Kilkadziesiąt ofiar izraelskiego ataku w Strefie Gazy
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-hamas-kilkadziesiat-ofiar-izraelskiego-ataku-w-strefie-gazy,nId,7839562](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-hamas-kilkadziesiat-ofiar-izraelskiego-ataku-w-strefie-gazy,nId,7839562)
 - RSS feed: $source
 - date published: 2024-10-20T07:11:30.222819+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-hamas-kilkadziesiat-ofiar-izraelskiego-ataku-w-strefie-gazy,nId,7839562"><img src="https://interia-s.pluscdn.pl/hamas-kilkadziesiat-ofiar-izraelskiego-ataku-w-strefie-gazy/000JYIBLSXCUATB6-C307.jpg" alt="Hamas: Kilkadziesiąt ofiar izraelskiego ataku w Strefie Gazy" align="left" /></a>73 osoby miały zginąć w sobotnim ataku Izraela na miasto Bajt Lahija w północnej części Strefy Gazy. Atak, wymierzony w infrastrukturę Hamasu, miał trafić w domy i blok. Dane o ofiarach, którymi podzieliło się biuro prasowe Hamasu, zostały uznane przez stronę izraelską za przesadzone.</p><br clear="all" />

## Kilkudziesięciu rannych, ostrzelana ważna fabryka. Niespokojna noc nad Ukrainą i Rosją
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kilkudziesieciu-rannych-ostrzelana-wazna-fabryka-niespokojna,nId,7839544](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kilkudziesieciu-rannych-ostrzelana-wazna-fabryka-niespokojna,nId,7839544)
 - RSS feed: $source
 - date published: 2024-10-20T07:11:30.068908+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kilkudziesieciu-rannych-ostrzelana-wazna-fabryka-niespokojna,nId,7839544"><img src="https://interia-s.pluscdn.pl/kilkudziesieciu-rannych-ostrzelana-wazna-fabryka-niespokojna/000JYI6ZVAT8OSYF-C307.jpg" alt="Kilkudziesięciu rannych, ostrzelana ważna fabryka. Niespokojna noc nad Ukrainą i Rosją" align="left" /></a>Ostatnio noc była niespokojna zarówno dla mieszkańców Ukrainy, jak i Rosji. Oba kraje zaatakowały się nawzajem z powietrza. W Zaporożu rannych zostało 10 osób, a w Krzywym Rogu 17. Ukraiński atak celował w zakład produkujący materiały wybuchowe w Dzierżyńsku w obwodzie niżnonowogrodzkim, ok. 400 km na wschód od Moskwy.</p><br clear="all" />

## Łukasz Litewka kandydatem Lewicy na prezydenta? "Ma sporo fanów"
 - [https://www.rmf24.pl/fakty/polska/news-lukasz-litewka-kandydatem-lewicy-na-prezydenta-ma-sporo-fano,nId,7839538](https://www.rmf24.pl/fakty/polska/news-lukasz-litewka-kandydatem-lewicy-na-prezydenta-ma-sporo-fano,nId,7839538)
 - RSS feed: $source
 - date published: 2024-10-20T06:06:53.655548+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-lukasz-litewka-kandydatem-lewicy-na-prezydenta-ma-sporo-fano,nId,7839538"><img src="https://interia-s.pluscdn.pl/lukasz-litewka-kandydatem-lewicy-na-prezydenta-ma-sporo-fano/000JYI61HB3KK67H-C307.jpg" alt="Łukasz Litewka kandydatem Lewicy na prezydenta? &quot;Ma sporo fanów&quot;" align="left" /></a>&quot;Poseł Łukasz Litewka ma sporą grupę fanów i potencjał&quot; - powiedział wiceszef klubu Lewicy Tomasz Trela. Jak dodał potem, jego partia rozważa wielu potencjalnych kandydatów na urząd prezydenta.</p><br clear="all" />

## Ilu cudzoziemców przekazały nam Niemcy? Straż graniczna podała liczbę
 - [https://www.rmf24.pl/fakty/polska/news-ilu-cudzoziemcow-przekazaly-nam-niemcy-straz-graniczna-podal,nId,7839536](https://www.rmf24.pl/fakty/polska/news-ilu-cudzoziemcow-przekazaly-nam-niemcy-straz-graniczna-podal,nId,7839536)
 - RSS feed: $source
 - date published: 2024-10-20T06:06:53.301386+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-ilu-cudzoziemcow-przekazaly-nam-niemcy-straz-graniczna-podal,nId,7839536"><img src="https://interia-s.pluscdn.pl/ilu-cudzoziemcow-przekazaly-nam-niemcy-straz-graniczna-podal/000JYI5CU2O84V4X-C307.jpg" alt="Ilu cudzoziemców przekazały nam Niemcy? Straż graniczna podała liczbę" align="left" /></a>570 – tylu łącznie cudzoziemców od początku roku do końca września przekazały do Polski niemieckie służby. Danymi podzielił się z PAP rzecznik straży granicznej ppłk SG Andrzej Juźwiak. Podstawą prawną przekazań była umowa o readmisji i porozumienie Dublin III.</p><br clear="all" />

## Kilkudziesięciu rannych i ostrzelana ważna fabryka. Niespokojna noc nad Ukrainą i Rosją
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kilkudziesieciu-rannych-i-ostrzelana-wazna-fabryka-niespokoj,nId,7839544](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kilkudziesieciu-rannych-i-ostrzelana-wazna-fabryka-niespokoj,nId,7839544)
 - RSS feed: $source
 - date published: 2024-10-20T06:06:53.007210+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kilkudziesieciu-rannych-i-ostrzelana-wazna-fabryka-niespokoj,nId,7839544"><img src="https://interia-s.pluscdn.pl/kilkudziesieciu-rannych-i-ostrzelana-wazna-fabryka-niespokoj/000JYI6ZVAT8OSYF-C307.jpg" alt="Kilkudziesięciu rannych i ostrzelana ważna fabryka. Niespokojna noc nad Ukrainą i Rosją" align="left" /></a>Ostatnio noc była niespokojna zarówno dla mieszkańców Ukrainy, jak i Rosji. Oba kraje zaatakowały się nawzajem z powietrza. W Zaporożu rannych zostało 10 osób, a w Krzywym Rogu 17. Ukraiński atak celował w zakład produkujący materiały wybuchowe w Dzierżyńsku w obwodzie niżnonowogrodzkim, ok. 400 km na wschód od Moskwy.</p><br clear="all" />

## Polski turysta zmarł w Tatrach słowackich
 - [https://www.rmf24.pl/fakty/swiat/news-polski-turysta-zmarl-w-tatrach-slowackich,nId,7839534](https://www.rmf24.pl/fakty/swiat/news-polski-turysta-zmarl-w-tatrach-slowackich,nId,7839534)
 - RSS feed: $source
 - date published: 2024-10-20T05:01:56.114910+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-polski-turysta-zmarl-w-tatrach-slowackich,nId,7839534"><img src="https://interia-s.pluscdn.pl/polski-turysta-zmarl-w-tatrach-slowackich/000JYI4PCRW8GKHR-C307.jpg" alt="Polski turysta zmarł w Tatrach słowackich" align="left" /></a>Tragiczne wieści doszły do Polski w sobotę wieczorem. Słowacka Horska Zachranna Slużba (HZS) poinformowała, że na jednym ze szlaków w Tatrach Wysokich zmarł 67-letni turysta z naszego kraju. </p><br clear="all" />

