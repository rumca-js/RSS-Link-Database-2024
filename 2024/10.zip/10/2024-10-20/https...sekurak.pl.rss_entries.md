# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Grafana łata poważną podatność umożliwiającą RCE i LFI
 - [https://sekurak.pl/grafana-lata-powazna-podatnosc-umozliwiajaca-rce-i-lfi](https://sekurak.pl/grafana-lata-powazna-podatnosc-umozliwiajaca-rce-i-lfi)
 - RSS feed: $source
 - date published: 2024-10-20T19:46:06+00:00

<p>Autorzy narzędzia Grafana opublikowali na blogu artykuł dotyczący błędu oznaczonego symbolem CVE-2024-9264 oraz zaktualizowane wersje. Błąd został odkryty przez inżyniera Grafana Labs i dotyczy Grafany serii 11.x (wersje z serii 10.x nie są podatne). Podatność dotyczy jedynie instalacji, które zawierają – nieobecny domyślnie – plik wykonywalny DuckDB w zmiennej środowiskowej PATH...</p>
<p>Artykuł <a rel="nofollow" href="https://sekurak.pl/grafana-lata-powazna-podatnosc-umozliwiajaca-rce-i-lfi/">Grafana łata poważną podatność umożliwiającą RCE i LFI</a> pochodzi z serwisu <a rel="nofollow" href="https://sekurak.pl">Sekurak</a>.</p>


