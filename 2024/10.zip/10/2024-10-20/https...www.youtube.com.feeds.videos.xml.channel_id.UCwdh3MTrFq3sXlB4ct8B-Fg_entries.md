# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## This Week in Warhammer – Choose Your Kill Team
 - [https://www.youtube.com/watch?v=Ik240tdO-Ok](https://www.youtube.com/watch?v=Ik240tdO-Ok)
 - RSS feed: $source
 - date published: 2024-10-20T17:00:23+00:00

The new Kill Team Starter Set is up for pre-order next weekend, along with a selection of kill teams, Warhammer 40,000 characters, and more! Get a closer look: https://ow.ly/4eZN50TOuEq

Follow for more Warhammer, more often:

- Instagram: https://www.instagram.com/warhammerofficial/
- Facebook: https://www.facebook.com/WarhammerOfficial/
- X: https://x.com/warhammer
- Warhammer Community: https://www.warhammer-community.com/
- Get Warhammer in your inbox: https://ow.ly/6SJq50T3NL1

