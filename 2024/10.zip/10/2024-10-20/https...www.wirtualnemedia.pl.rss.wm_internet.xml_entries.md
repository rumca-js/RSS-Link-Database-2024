# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Legimi traci kolejne książki. Głos zabrało stowarzyszenie pisarzy
 - [https://www.wirtualnemedia.pl/artykul/legimi-podwyzka-cena-pakiet-klubowy-ile-oferta-biblioteczna-virtualo](https://www.wirtualnemedia.pl/artykul/legimi-podwyzka-cena-pakiet-klubowy-ile-oferta-biblioteczna-virtualo)
 - RSS feed: $source
 - date published: 2024-10-20T16:31:47.181360+00:00

Należąca do Empiku spóła Virtualo skrytykowała działania platformy Legimi wobec wydawców i zawiesiła z nią współpracę „do czasu wyjaśnienia wszystkich wątpliwości”. - Ujawnione patologie Legimi w Polsce są częścią całości patologii rynku książki i wymagają silnej i szybkiej interwencji władz państwa, ponieważ prowadzą do destrukcji naszej literatury - skomentowała Unia Literacka.

