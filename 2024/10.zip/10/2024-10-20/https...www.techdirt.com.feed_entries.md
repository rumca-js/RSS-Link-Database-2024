# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## Funniest/Most Insightful Comments Of The Week At Techdirt
 - [https://www.techdirt.com/2024/10/20/funniest-most-insightful-comments-of-the-week-at-techdirt-132](https://www.techdirt.com/2024/10/20/funniest-most-insightful-comments-of-the-week-at-techdirt-132)
 - RSS feed: $source
 - date published: 2024-10-20T19:00:00+00:00

This week, both our winners on the insightful side come in response to our post about the judge who smacked down Florida&#8217;s attempt to censor abortion initiative ads. In first place, it&#8217;s an anonymous comment about our description of the legislature being &#8220;confused&#8221; about the first amendment: Make no mistake: They know exactly how it [&#8230;]

