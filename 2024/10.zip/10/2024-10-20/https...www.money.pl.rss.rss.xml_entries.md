# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## 800 tysięcy osób wpadło w skrajne ubóstwo. 2023 to był krytyczny rok [OPINIA]
 - [https://www.money.pl/pieniadze/800-tysiecy-osob-wpadlo-w-skrajne-ubostwo-2023-to-byl-krytyczny-rok-opinia-7083776671160896a.html](https://www.money.pl/pieniadze/800-tysiecy-osob-wpadlo-w-skrajne-ubostwo-2023-to-byl-krytyczny-rok-opinia-7083776671160896a.html)
 - RSS feed: $source
 - date published: 2024-10-20T16:31:52.016130+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bbc334a2-bf6c-4287-981c-759f6aa0f82b" width="308" /> Raport Poverty Watch 2024, który ukazał się w zeszłym tygodniu, przedstawił niezwykle niepokojące, by nie powiedzieć haniebne, dane. Otóż w roku 2023 względem roku poprzedniego gwałtownie wzrosło w Polsce skrajne ubóstwo, również skrajne ubóstwo dzieci. Między innymi przez brak waloryzacji programu 500+ (przypomnijmy, że mówimy o roku 2023). Ale po kolei. 

## Polacy kupują firmę z Hull. Dużego gracza na brytyjskim rynku
 - [https://www.money.pl/gospodarka/polacy-kupuja-firme-z-hull-duzego-gracza-na-brytyjskim-rynku-7083753602140736a.html](https://www.money.pl/gospodarka/polacy-kupuja-firme-z-hull-duzego-gracza-na-brytyjskim-rynku-7083753602140736a.html)
 - RSS feed: $source
 - date published: 2024-10-20T14:21:25.202840+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0a72c1a1-1ab4-4427-b94e-5fca4f1395ca" width="308" /> Polska firma Suempol, świętująca 35 lat działalności, nabyła brytyjską Copernus Ltd z siedzibą w Hull, czołowego dostawcę świeżych ryb. Dzięki temu przejęciu polska rodzinna firma umacnia swoją pozycję na rynku brytyjskim, oferując szerszy asortyment produktów rybnych. 

## Dino szuka ponad 2 tys. pracowników. Oto zarobki
 - [https://www.money.pl/gospodarka/dino-szuka-ponad-2-tys-pracownikow-oto-zarobki-7083734204119648a.html](https://www.money.pl/gospodarka/dino-szuka-ponad-2-tys-pracownikow-oto-zarobki-7083734204119648a.html)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:10.630864+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/dd4fe4ac-8a35-4d0e-9b94-a21d1dadff32" width="308" /> Aktualnie na stronie internetowej Dino znajduje się aż 2400 ofert pracy w różnych kategoriach, takich jak markety, magazyny, centrala i praca w terenie. Firma zatrudnia około 45 tys. osób, oferując konkurencyjne wynagrodzenia, rozwój zawodowy i stabilne zatrudnienie. 

## Amazon zmienia zasady w tym kraju. Chodzi o zwroty
 - [https://www.money.pl/gospodarka/zmiany-w-niemieckim-amazonie-chodzi-o-zwroty-7083715073092192a.html](https://www.money.pl/gospodarka/zmiany-w-niemieckim-amazonie-chodzi-o-zwroty-7083715073092192a.html)
 - RSS feed: $source
 - date published: 2024-10-20T12:11:00.188804+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6a7b2aa3-d23e-4e35-b45b-bc4363bc9d14" width="308" /> Niemiecki Amazon wprowadza nowe zasady dotyczące zwrotów dużych i ciężkich paczek. Od 30 października sprzedawcy będą musieli organizować zwroty dla produktów ponad 1,75 metra lub ważących ponad 31,5 kilograma, oferując przedpłacone etykiety i odbiór z domu klienta. 

## Praca marzeń w Wiedniu. Oto ile zarabia tester pizzy
 - [https://www.money.pl/gospodarka/praca-marzen-w-wiedniu-oto-ile-zarabia-tester-pizzy-7083721517394496a.html](https://www.money.pl/gospodarka/praca-marzen-w-wiedniu-oto-ile-zarabia-tester-pizzy-7083721517394496a.html)
 - RSS feed: $source
 - date published: 2024-10-20T12:10:59.936813+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f0aaa14b-8ba9-4fef-a1a0-9eeb7b861cb7" width="308" /> Włoska pizzeria „Il Rione” w Wiedniu poszukuje osoby na nietypowe stanowisko testera pizzy. Idealny kandydat będzie codziennie oceniać potrawy przygotowane przez neapolitańskich kucharzy oraz nadzorować jakość składników. Na szczęśliwca czeka atrakcyjne wynagrodzenie i wiele benefitów.
 

## Ostatnia zmiana czasu w tym kraju. Powody polityczne i zdrowotne
 - [https://www.money.pl/gospodarka/ostatnia-zmian-czasu-w-tym-kraju-powody-polityczne-i-zdrowotne-7083699320728128a.html](https://www.money.pl/gospodarka/ostatnia-zmian-czasu-w-tym-kraju-powody-polityczne-i-zdrowotne-7083699320728128a.html)
 - RSS feed: $source
 - date published: 2024-10-20T11:06:11.750749+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/26146fd4-a49a-46b3-ac8b-2ba88a3d8e84" width="308" /> Zmiana czasu, kultywowana przez około 40 proc. krajów, wkrótce zniknie z Ukrainy. Kraj ten ostatni raz cofnie zegarki w październiku, decydując się na stały czas strefowy. W Polsce zmiana czasu na zimowy będzie miała miejsce z 26 na 27 października.
 

## Polska jest krainą szczęśliwości. Ale nie wiadomo dlaczego [ANALIZA]
 - [https://www.money.pl/gospodarka/polska-jest-kraina-szczesliwosci-ale-nie-wiadomo-dlaczego-analiza-7082354770254400a.html](https://www.money.pl/gospodarka/polska-jest-kraina-szczesliwosci-ale-nie-wiadomo-dlaczego-analiza-7082354770254400a.html)
 - RSS feed: $source
 - date published: 2024-10-20T11:06:11.599506+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5fc973fa-56cc-4df7-80b1-09a25897da64" width="308" /> Pod względem satysfakcji mieszkańców z życia Polska należy do unijnych liderów, a w ciągu minionej dekady przesunęła się w tym rankingu w górę. Ten awans można częściowo wyjaśnić szybkim na tle UE tempem wzrostu dochodów Polaków. Ale sam poziom satysfakcji jest wyższy, niż wynikałoby z warunków życia nad Wisłą. 

## Rząd uderzy podatkami w OZE? "To otwiera furtkę"
 - [https://www.money.pl/podatki/rzad-uderzy-podatkami-w-oze-to-otwiera-furtke-7082746968865344a.html](https://www.money.pl/podatki/rzad-uderzy-podatkami-w-oze-to-otwiera-furtke-7082746968865344a.html)
 - RSS feed: $source
 - date published: 2024-10-20T10:01:06.472893+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/47d47ec2-b4ca-43e1-9560-4946db34cf5b" width="308" /> Przyjęty niedawno przez rząd projekt przepisów uderzy w branżę OZE, co sprawi, że inwestycje w tym sektorze przestaną się opłacać - ostrzegają eksperci. Według nich gminy będą mogły w całości opodatkować farmy fotowoltaiczne i wiatrowe. Resort finansów temu zaprzecza. 

## Obawiasz się podania numeru PESEL w aptece? Oto kiedy nie musisz
 - [https://www.money.pl/gospodarka/obawiasz-sie-podania-numeru-pesel-w-aptece-oto-kiedy-nie-musisz-7083681300126304a.html](https://www.money.pl/gospodarka/obawiasz-sie-podania-numeru-pesel-w-aptece-oto-kiedy-nie-musisz-7083681300126304a.html)
 - RSS feed: $source
 - date published: 2024-10-20T10:01:06.020055+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/870b2718-6ca8-4334-94d2-7a49a7079104" width="308" /> Od prawie pięciu lat lekarze w Polsce wystawiają pacjentom głównie elektroniczne recepty, które można przechowywać w smartfonie dzięki aplikacji mObywatel. Poznaj korzyści płynące z e-recepty oraz jak łatwo zrealizować ją w aptece, skanując kod QR.
 

## Coraz bliżej końca dużej inwestycji. Oto co powstanie pod Rzeszowem
 - [https://www.money.pl/gospodarka/coraz-blizej-konca-duzej-inwestycji-oto-co-powstanie-pod-rzeszowem-7083675928767040a.html](https://www.money.pl/gospodarka/coraz-blizej-konca-duzej-inwestycji-oto-co-powstanie-pod-rzeszowem-7083675928767040a.html)
 - RSS feed: $source
 - date published: 2024-10-20T08:55:48.073147+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d51b5774-29f9-4e1e-b708-71c87b27bd2d" width="308" /> Rzeszów odnotowuje dynamiczny rozwój, co widać w planach budowy dwóch nowych obiektów w CTPark o łącznej powierzchni blisko 50 000 mkw. Grzegorz Sikora z CTP Polska podkreśla, że miasto staje się kluczowym centrum logistyczno-przemysłowym w Polsce.
 

## Podatek katastralny a kondycja gospodarki. Były premier ma obawy. Ale niesłusznie [OPINIA]
 - [https://www.money.pl/gospodarka/podatek-katastralny-a-kondycja-gospodarki-byly-premier-ma-obawy-ale-nieslusznie-opinia-7082226350324320a.html](https://www.money.pl/gospodarka/podatek-katastralny-a-kondycja-gospodarki-byly-premier-ma-obawy-ale-nieslusznie-opinia-7082226350324320a.html)
 - RSS feed: $source
 - date published: 2024-10-20T07:50:54.206102+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1909f56b-4bc2-4155-a0f8-7e4fd0bb03ba" width="308" /> Kaskadujące kryzysy gospodarcze zdarzają się na świecie, ale rzadko są one wynikiem wprowadzenia pojedynczego podatku - pisze w opinii dla money.pl dziennikarz Kamil Fejfer, odnosząc się do słów Marka Belki. Według byłego premiera podatek katastralny stanowiłby silny cios w polską gospodarkę. 

## Złoto znów stało się walutą. To zmienia równowagę. "Ten rok jest fascynujący"
 - [https://www.money.pl/gielda/zloto-znow-stalo-sie-waluta-to-zmienia-rownowage-ten-rok-jest-fascynujacy-7082988283722336a.html](https://www.money.pl/gielda/zloto-znow-stalo-sie-waluta-to-zmienia-rownowage-ten-rok-jest-fascynujacy-7082988283722336a.html)
 - RSS feed: $source
 - date published: 2024-10-20T04:35:43.063257+00:00

 <img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/810bea1b-d66f-4e0f-a8f6-4bf886b081ab" width="308" /> Kraje, które z powodu sankcji nie mogą rozliczać się w dolarach lub euro, korzystają ze złota. To, że złoto znów stało się pieniądzem, jest jedną z kilku sił, które sprzyjają wzrostowi notowań kruszcu - tłumaczy money.pl Steve Land, analityk i zarządzający funduszami inwestującymi w metale szlachetne. 

