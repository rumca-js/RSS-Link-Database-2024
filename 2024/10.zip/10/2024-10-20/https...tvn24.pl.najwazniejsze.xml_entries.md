# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Efektowne zwycięstwo Barcelony. Lewandowski skuteczny jak Messi
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2024-2025/robert-lewandowski-z-dubletem-w-meczu-barcelona-sevilla-wynik-i-relacja-z-meczu_sto20047007/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2024-2025/robert-lewandowski-z-dubletem-w-meczu-barcelona-sevilla-wynik-i-relacja-z-meczu_sto20047007/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T21:00:33+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3018856-imagetitle/alternates/LANDSCAPE_1280" alt="Efektowne zwycięstwo Barcelony. Lewandowski skuteczny jak Messi" />
    Kolejny popisowy mecz.
    
    

## Lewandowski w pierwszym składzie na mecz Barcelony
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2024-2025/live-fc-barcelona-sevilla-fc_mtc1524114/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2024-2025/live-fc-barcelona-sevilla-fc_mtc1524114/live-commentary.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T18:11:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4548875-barcelona-sevilla-relacja-live-i-wynik-meczu-ph8144008/alternates/LANDSCAPE_1280" alt="Lewandowski w pierwszym składzie na mecz Barcelony" />
    Wynik i relacja na żywo.
    
    

## Raków rzutem na taśmę zdobył trzy punkty
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/pko-bp-ekstraklasa-202425.-rakow-czestochowa-pokonal-grajaca-w-oslabieniu-pogon-szczecin_sto20046957/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/pko-bp-ekstraklasa-202425.-rakow-czestochowa-pokonal-grajaca-w-oslabieniu-pogon-szczecin_sto20046957/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T17:44:26+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6848279-imagetitle/alternates/LANDSCAPE_1280" alt="Raków rzutem na taśmę zdobył trzy punkty" />
    Bohaterem spotkania został Matej Rodin.
    
    

## Teatr dwóch aktorów. Liverpool nie pękł w hicie 
 - [https://eurosport.tvn24.pl/pilka-nozna/premier-league/2024-2025/liverpool-chelsea-wynik-meczu-i-relacja_sto20046967/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/premier-league/2024-2025/liverpool-chelsea-wynik-meczu-i-relacja_sto20046967/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T17:37:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5676585-imagetitle/alternates/LANDSCAPE_1280" alt="Teatr dwóch aktorów. Liverpool nie pękł w hicie " />
    Grał z Chelsea.
    
    

## Świetna jazda polskich załóg
 - [https://eurosport.tvn24.pl/wrc/swietna-jazda-polskich-zalog-w-rajdzie-europy-centralnej_sto20046973/story.shtml?source=rss](https://eurosport.tvn24.pl/wrc/swietna-jazda-polskich-zalog-w-rajdzie-europy-centralnej_sto20046973/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T16:27:51+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2998654-imagetitle/alternates/LANDSCAPE_1280" alt="Świetna jazda polskich załóg" />
    W Rajdzie Europy Centralnej. 
    
    

## Medalista olimpijski ukarany dyskwalifikacją. "Nigdy już tego nie zrobię"
 - [https://eurosport.tvn24.pl/tenis-stolowy/mistrzostwa-europy-2024-francuz-felix-lebrun-zdyskwalifikowany-za-rzucenie-rakietka-w-meczu-z-niemcem-benediktem-duda_sto20046958/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis-stolowy/mistrzostwa-europy-2024-francuz-felix-lebrun-zdyskwalifikowany-za-rzucenie-rakietka-w-meczu-z-niemcem-benediktem-duda_sto20046958/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T15:54:17+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1437093-imagetitle/alternates/LANDSCAPE_1280" alt="Medalista olimpijski ukarany dyskwalifikacją. "Nigdy już tego nie zrobię"" />
    Utalentowany francuski tenisista stołowy narobił sobie problemów podczas mistrzostw Europy.
    
    

## "Wyskoczył i ukłuł prosto w klatkę piersiową". Tragiczna śmierć 
 - [https://eurosport.tvn24.pl/surfing/giulia-manfrini-nie-zyje.-wloska-surferka-zginela-w-indonezji-po-ataku-miecznika_sto20046912/story.shtml?source=rss](https://eurosport.tvn24.pl/surfing/giulia-manfrini-nie-zyje.-wloska-surferka-zginela-w-indonezji-po-ataku-miecznika_sto20046912/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T14:47:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8590522-imagetitle/alternates/LANDSCAPE_1280" alt=""Wyskoczył i ukłuł prosto w klatkę piersiową". Tragiczna śmierć " />
    Kolejny podobny przypadek. 
    
    

## Turniejowy triumf Kasatkiny. Piękny gest po meczu
 - [https://eurosport.tvn24.pl/tenis/daria-kasatkina-mirra-andriejewa-wynik-meczu-i-relacja_sto20046891/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/daria-kasatkina-mirra-andriejewa-wynik-meczu-i-relacja_sto20046891/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T13:26:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4875146-imagetitle/alternates/LANDSCAPE_1280" alt="Turniejowy triumf Kasatkiny. Piękny gest po meczu" />
    Rosjanka pokonała w finale swoją rodaczkę.
    
    

## Historyczny tytuł młodej polskiej tenisistki
 - [https://eurosport.tvn24.pl/tenis/itf-w35-faro-2024.-monika-stankiewicz-wygrala-turniej.-w-finale-pokonala-matilde-jorge_sto20046870/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/itf-w35-faro-2024.-monika-stankiewicz-wygrala-turniej.-w-finale-pokonala-matilde-jorge_sto20046870/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T12:43:29+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2118913-imagetitle/alternates/LANDSCAPE_1280" alt="Historyczny tytuł młodej polskiej tenisistki" />
    Monika Stankiewicz świętuje.
    
    

## Legendarny olimpijczyk nieuleczalnie chory. Liczy czas do końca 
 - [https://eurosport.tvn24.pl/kolarstwo-torowe/sir-chris-hoy-chory-na-raka-w-fazie-terminalnej.-zostalo-mu-od-dwoch-do-czterech-lat-zycia_sto20046852/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo-torowe/sir-chris-hoy-chory-na-raka-w-fazie-terminalnej.-zostalo-mu-od-dwoch-do-czterech-lat-zycia_sto20046852/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T12:38:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9094464-imagetitle/alternates/LANDSCAPE_1280" alt="Legendarny olimpijczyk nieuleczalnie chory. Liczy czas do końca " />
    Poruszający wywiad sir Chrisa Hoya. 
    
    

## Trzy gole w niespełna kwadrans
 - [https://eurosport.tvn24.pl/pilka-nozna/mls/2024/lionel-messi-strzelil-trzy-gole-w-12-minut-w-meczu-inter-miami-new-england-revolution_sto20046851/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/mls/2024/lionel-messi-strzelil-trzy-gole-w-12-minut-w-meczu-inter-miami-new-england-revolution_sto20046851/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T11:54:29+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8559272-imagetitle/alternates/LANDSCAPE_1280" alt="Trzy gole w niespełna kwadrans" />
    Messi dał kolejny popis.
    
    

## Futbol, ludzie, polityka. "Piłką nożną można wytłumaczyć świat"
 - [https://eurosport.tvn24.pl/pilka-nozna/anita-werner-i-michal-kolodziejczyk-ksiazka-nadzieja-fc.-futbol-ludzie-polityka_sto20046829/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/anita-werner-i-michal-kolodziejczyk-ksiazka-nadzieja-fc.-futbol-ludzie-polityka_sto20046829/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T10:27:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7083509-imagetitle/alternates/LANDSCAPE_1280" alt="Futbol, ludzie, polityka. "Piłką nożną można wytłumaczyć świat"" />
    Premiera książki Anity Werner i Michała Kołodziejczyka.
    
    

## Wyjątkowy prezent dla Nadala
 - [https://eurosport.tvn24.pl/tenis/rafael-nadal-otrzymal-zlota-rakiete-od-organizatorow-pokazowego-turnieju-six-kings-slam-w-rijadzie_sto20046798/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/rafael-nadal-otrzymal-zlota-rakiete-od-organizatorow-pokazowego-turnieju-six-kings-slam-w-rijadzie_sto20046798/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T10:00:43+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7249324-imagetitle/alternates/LANDSCAPE_1280" alt="Wyjątkowy prezent dla Nadala" />
    "W pełni zasłużony".
    
    

## "Jak pocisk balistyczny"
 - [https://eurosport.tvn24.pl/pilka-nozna/turecka-super-lig/2024-2025/gol-osimhen-galatasaray-turcja-wideo_sto20046795/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/turecka-super-lig/2024-2025/gol-osimhen-galatasaray-turcja-wideo_sto20046795/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T09:09:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2941765-imagetitle/alternates/LANDSCAPE_1280" alt=""Jak pocisk balistyczny"" />
    Kapitalne trafienie w Turcji.
    
    

## Oto najlepiej zarabiający piłkarze świata
 - [https://eurosport.tvn24.pl/pilka-nozna/forbes-cristiano-ronaldo-najlepiej-zarabiajacym-pilkarzem-na-swiecie_sto20046434/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/forbes-cristiano-ronaldo-najlepiej-zarabiajacym-pilkarzem-na-swiecie_sto20046434/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T07:51:51+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3446602-imagetitle/alternates/LANDSCAPE_1280" alt="Oto najlepiej zarabiający piłkarze świata" />
    Ronaldo na czele. 
    
    

## Hat-trick Nowozelandczyków w Pucharze Ameryki
 - [https://eurosport.tvn24.pl/zeglarstwo/america-s-cup/2024/puchar-ameryki-2024.-emirates-team-new-zealand-pokonal-ineos-britannia_sto20046787/story.shtml?source=rss](https://eurosport.tvn24.pl/zeglarstwo/america-s-cup/2024/puchar-ameryki-2024.-emirates-team-new-zealand-pokonal-ineos-britannia_sto20046787/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T06:56:59+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2495852-imagetitle/alternates/LANDSCAPE_1280" alt="Hat-trick Nowozelandczyków w Pucharze Ameryki" />
    Emirates Team New Zealand po raz kolejny triumfatorem Pucharu Ameryki. Dla załogi z Oceanii to trzeci tytuł z rzędu w najstarszych żeglarskich regatach świata. W rywalizacji do siedmiu wygranych wyścigów u wybrzeży Barcelony ekipa sternika Petera Burlinga pokonała INEOS Britannia 7:2.
    
    

## W nagrodę sześć milionów dolarów
 - [https://eurosport.tvn24.pl/tenis/jannik-sinner-pokonal-carlosa-alcaraza-w-finale-turnieju-six-kings-slam-w-rijadzie.-trzecie-miejsce-dla-djokovicia_sto20046725/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/jannik-sinner-pokonal-carlosa-alcaraza-w-finale-turnieju-six-kings-slam-w-rijadzie.-trzecie-miejsce-dla-djokovicia_sto20046725/story.shtml?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T05:36:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2834495-imagetitle/alternates/LANDSCAPE_1280" alt="W nagrodę sześć milionów dolarów" />
    Jannik Sinner triumfuje w Rijadzie.
    
    

## Sandra Drzymalska: ciężko jest mi oglądać się na ekranie, dużo rzeczy mi nie pasuje
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-206,S00E206,1485696?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-206,S00E206,1485696?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T03:05:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8929759-img-20241017-wa0008-ph8143344/alternates/LANDSCAPE_1280" alt="Sandra Drzymalska: ciężko jest mi oglądać się na ekranie, dużo rzeczy mi nie pasuje" />
    Aktorka o sławie, ambicjach oraz oczekiwaniach, jakie na siebie nakłada.
    
    

