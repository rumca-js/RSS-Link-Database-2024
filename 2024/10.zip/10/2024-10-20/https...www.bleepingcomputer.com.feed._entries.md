# Source:BleepingComputer, URL:https://www.bleepingcomputer.com/feed/, language:en-US

## Severe flaws in E2EE cloud storage platforms used by millions
 - [https://www.bleepingcomputer.com/news/security/severe-flaws-in-e2ee-cloud-storage-platforms-used-by-millions](https://www.bleepingcomputer.com/news/security/severe-flaws-in-e2ee-cloud-storage-platforms-used-by-millions)
 - RSS feed: $source
 - date published: 2024-10-20T12:06:35+00:00

Several end-to-end encrypted (E2EE) cloud storage platforms are vulnerable to a set of security issues that could expose user data to malicious actors. [...]

## Internet Archive breached again through stolen access tokens
 - [https://www.bleepingcomputer.com/news/security/internet-archive-breached-again-through-stolen-access-tokens](https://www.bleepingcomputer.com/news/security/internet-archive-breached-again-through-stolen-access-tokens)
 - RSS feed: $source
 - date published: 2024-10-20T10:46:56+00:00

The Internet Archive was breached again, this time on their Zendesk email support platform after repeated warnings that threat actors stole exposed GitLab authentication tokens. [...]

