# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## 12 Deep Sea Jobs Around the World | Business Insider Marathon | Business Insider
 - [https://www.youtube.com/watch?v=lC4e8Uh_C-o](https://www.youtube.com/watch?v=lC4e8Uh_C-o)
 - RSS feed: $source
 - date published: 2024-10-20T15:00:47+00:00

From the miners who suck rare metals off the seafloor to the divers working in America’s sea sponge capital, we met people around the world who rely on the sea for their livelihoods.

MORE BUSINESS INSIDER MARATHON VIDEOS:
14 Fascinating Businesses Behind The Scenes | Business Insider Marathon
https://www.youtube.com/watch?v=cKn4i2dvya0&t=10s
How 14 Expensive Instruments Are Crafted By Masters | Business Insider Marathon
https://www.youtube.com/watch?v=s-tYE79uyCk
16 Dangerous Jobs Around The World | Business Insider Marathon
https://www.youtube.com/watch?v=OLxbAW9Cid0&t=166s

00:00:00 - Intro
00:00:21 - Seafloor Mining
00:13:20 - Sea Sponges
00:23:57 - Cleaning Oceans
00:34:14 - Cruise Ships
01:02:02 - Seaweed Harvesting
01:14:34 - Gooseneck Barnacles
01:20:23 - Pearl Lobsters
01:28:20 - Underwater Welding
01:42:19 - Sea Salt Harvesting
01:50:19 - South Sea Pearls
01:59:00 - Sea Urchin Harvesting
02:08:33 - Tyrian Purple Dye
02:19:07 - Credits

---------------------------------------

