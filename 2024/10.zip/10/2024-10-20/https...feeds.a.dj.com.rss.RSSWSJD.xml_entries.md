# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## AI Startup Perplexity in Funding Talks to More Than Double Valuation to $8 Billion
 - [https://www.wsj.com/articles/ai-startup-perplexity-in-funding-talks-to-more-than-double-valuation-to-8-billion-54d36787?mod=rss_Technology](https://www.wsj.com/articles/ai-startup-perplexity-in-funding-talks-to-more-than-double-valuation-to-8-billion-54d36787?mod=rss_Technology)
 - RSS feed: $source
 - date published: 2024-10-20T16:12:00+00:00

The search-based chatbot is seeking to raise around $500 million in what would be its fourth funding round in a year.

## The 'October Theory' of Changing Your Life
 - [https://www.wsj.com/articles/the-october-theory-of-changing-your-life-62732270?mod=rss_Technology](https://www.wsj.com/articles/the-october-theory-of-changing-your-life-62732270?mod=rss_Technology)
 - RSS feed: $source
 - date published: 2024-10-20T05:30:00+00:00

As part of the “October Theory” trend, people are rethinking their approach to the last three months of the year. They’re mostly using it as a time to set goals and reflect.

