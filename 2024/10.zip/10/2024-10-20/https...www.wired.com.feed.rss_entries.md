# Source:Wired, URL:https://www.wired.com/feed/rss, language:en-US

## 12 Best Bookshelf Speakers (2024): Active, Passive, and Hi-Fi
 - [https://www.wired.com/gallery/best-bookshelf-speakers](https://www.wired.com/gallery/best-bookshelf-speakers)
 - RSS feed: $source
 - date published: 2024-10-20T13:03:00+00:00

Soup up your sound with these active and passive speakers. We have picks for every budget.

## Everything You Can Do From Google Chrome’s Address Bar (Besides Run Searches)
 - [https://www.wired.com/story/google-chrome-address-bar-omnibox-shortcuts-everything-you-can-do](https://www.wired.com/story/google-chrome-address-bar-omnibox-shortcuts-everything-you-can-do)
 - RSS feed: $source
 - date published: 2024-10-20T12:30:00+00:00

Chrome’s omnibox is not just for typing out URLs or searching Google. Use it to take notes, write emails, and chat with Gemini.

## Vizio 5.1 Soundbar SE Review: Pretty Good, Hilariously Cheap
 - [https://www.wired.com/review/vizio-51-soundbar-se](https://www.wired.com/review/vizio-51-soundbar-se)
 - RSS feed: $source
 - date published: 2024-10-20T12:02:00+00:00

This Vizio soundbar system brings the sound of the movies to your living room, and it costs less than $250.

## The 7 Best Blackout Curtains, Tested and Reviewed
 - [https://www.wired.com/gallery/best-blackout-curtains](https://www.wired.com/gallery/best-blackout-curtains)
 - RSS feed: $source
 - date published: 2024-10-20T11:39:00+00:00

We tested many options on bright windows to see which curtains actually give us a dark night’s sleep.

## How Cells Resist the Pressure of the Deep Sea
 - [https://www.wired.com/story/the-cellular-secret-to-resisting-the-pressure-of-the-deep-sea](https://www.wired.com/story/the-cellular-secret-to-resisting-the-pressure-of-the-deep-sea)
 - RSS feed: $source
 - date published: 2024-10-20T11:00:00+00:00

Cell membranes from comb jellies reveal a new kind of adaptation to the deep sea: curvy lipids that conform to an ideal shape under pressure.

