# Source:China Uncensored, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCgFP46yVT-GG4o1TgXn-04Q, language:en

## China's Ambitions Are Crumbling
 - [https://www.youtube.com/watch?v=S5hlpUlU0H8](https://www.youtube.com/watch?v=S5hlpUlU0H8)
 - RSS feed: $source
 - date published: 2024-10-20T21:35:55+00:00

Another failure of the Belt and Road Initiative—Pakistani terrorists attack Chinese nationals. And the CCP's global ambitions are teetering on the brink. 

Help SAVE China Uncensored! https://GiveSendGo.com/ChinaUncensored

COLUMBUS DID NOTHING WRONG According to Diablo 4 Vessel of Hatred https://youtu.be/cp_JtGxqn-k

YouTube demonetizes our channels, we need your support!
https://www.patreon.com/ChinaUncensored
https://chinauncensored.locals.com

We also accept bitcoin!
https://chinauncensored.tv/bitcoin

And Paypal: 
https://www.paypal.com/donate/?hosted_button_id=GAHZXYHGCBP3L

Buy our merchandise!
https://chinauncensored.tv/merchandise

China Uncensored on Odysee
https://odysee.com/@ChinaUncensored

China Uncensored on Rumble
https://rumble.com/c/ChinaUncensored

Make sure to share this video with your friends!
______________________________
Subscribe for updates:
youtube.com/ChinaUncensored?sub_confirmation=1

______________________________
Twitter: https://twitter.com/ChinaUncen

