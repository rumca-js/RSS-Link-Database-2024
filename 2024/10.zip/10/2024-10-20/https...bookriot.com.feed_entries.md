# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## Enter to Win $100 to Bookshop.org!
 - [https://bookriot.com/enter-to-win-100-to-bookshop-org](https://bookriot.com/enter-to-win-100-to-bookshop-org)
 - RSS feed: $source
 - date published: 2024-10-20T15:00:00+00:00

None

## The Week’s Biggest Book News
 - [https://bookriot.com/today-in-books-october-20-2024](https://bookriot.com/today-in-books-october-20-2024)
 - RSS feed: $source
 - date published: 2024-10-20T15:00:00+00:00

Amazon introduces the first color-screen Kindle, Taylor Swift will publish her first book, and more of the week's biggest news.

## Cover Craft: 8 of the Best Romantasy Covers
 - [https://bookriot.com/cover-craft-8-of-the-best-romantasy-covers](https://bookriot.com/cover-craft-8-of-the-best-romantasy-covers)
 - RSS feed: $source
 - date published: 2024-10-20T12:30:00+00:00

What's your favorite recent book cover?

## Book Riot’s Deals of the Day for October 20, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-october-20-2024](https://bookriot.com/book-riots-deals-of-the-day-for-october-20-2024)
 - RSS feed: $source
 - date published: 2024-10-20T12:00:00+00:00

A Guide to Bookstore Customers, Award-Winning Fantasy, MId-Century Queer Romance, and More in Today's Best Book Deals

