# Source:FOSS Force, URL:https://fossforce.com/feed, language:en-US

## ‘All Things Open’ Revives the OpenSource.com Community Abandoned by Red Hat
 - [https://fossforce.com/2024/10/ato-revives-the-opensource-com-community-abandoned-by-red-hat](https://fossforce.com/2024/10/ato-revives-the-opensource-com-community-abandoned-by-red-hat)
 - RSS feed: $source
 - date published: 2024-10-20T12:00:51+00:00

<p><em>The All Things Open organization is pickling up the baton abandoned by Red Hat when it quit publishing OpenSource.com.</em></p>
<p>The post <a href="https://fossforce.com/2024/10/ato-revives-the-opensource-com-community-abandoned-by-red-hat/">&#8216;All Things Open&#8217; Revives the OpenSource.com Community Abandoned by Red Hat</a> appeared first on <a href="https://fossforce.com">FOSS Force</a>.</p>


