# Source:Pakistan Observer, URL:https://pakobserver.net/feed, language:en-US

## Senate passes 26th constitutional amendment bill
 - [https://pakobserver.net/senate-passes-26th-constitutional-amendment-bill](https://pakobserver.net/senate-passes-26th-constitutional-amendment-bill)
 - RSS feed: $source
 - date published: 2024-10-20T18:59:14+00:00

ISLAMABAD &#8211; Following approval from the federal cabinet, the Senate passed the 26th Constitutional Amendment Bill with a majority on…

## New Zealand beat South Africa by 32 runs to lift Women’s T20 World Cup
 - [https://pakobserver.net/new-zealand-beat-south-africa-by-32-runs-to-lift-womens-t20-world-cup](https://pakobserver.net/new-zealand-beat-south-africa-by-32-runs-to-lift-womens-t20-world-cup)
 - RSS feed: $source
 - date published: 2024-10-20T15:40:01+00:00

DUBAI – New Zealand beat South Africa by 32-run in the final to lift the ICC Women’s T20 World Cup…

## South Africa opt to bowl against New Zealand in Women’s T20 World Cup final
 - [https://pakobserver.net/south-africa-opt-to-bowl-against-new-zealand-in-womens-t20-world-cup-final](https://pakobserver.net/south-africa-opt-to-bowl-against-new-zealand-in-womens-t20-world-cup-final)
 - RSS feed: $source
 - date published: 2024-10-20T14:05:01+00:00

DUBAI – South Africa skipper Laura Wolvaardt has won the toss and opted to bowl first against New Zealand in…

## Challengers, Conquerors secure wins in U19 Women’s T20 Tournament
 - [https://pakobserver.net/challengers-conquerors-secure-wins-in-u19-womens-t20-tournament](https://pakobserver.net/challengers-conquerors-secure-wins-in-u19-womens-t20-tournament)
 - RSS feed: $source
 - date published: 2024-10-20T13:34:59+00:00

LAHORE &#8211; Aleesa Mukhtiar’s three-fer helped Challengers beat Invincibles by 28 runs, while Conquerors’ Komal Khan 97 helped her side…

## Cabinet approves 26th constitutional amendment
 - [https://pakobserver.net/cabinet-approves-26th-constitutional-amendment](https://pakobserver.net/cabinet-approves-26th-constitutional-amendment)
 - RSS feed: $source
 - date published: 2024-10-20T13:24:05+00:00

ISLAMABAD &#8211; The federal cabinet approved the proposed draft of the 26th Constitutional Amendment on Sunday. The proposed legislation will…

## Currency exchange rates in Pakistan today – 20 October, 2024
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-20-october-2024](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-20-october-2024)
 - RSS feed: $source
 - date published: 2024-10-20T11:11:24+00:00

KARACHI—The exchange rate for one US Dollar against Pakistani rupees was recorded at Rs 277.75 in the local and open…

## Gold rate in Pakistan today, 20 October, 2024
 - [https://pakobserver.net/gold-rate-in-pakistan-today-20-october-2024](https://pakobserver.net/gold-rate-in-pakistan-today-20-october-2024)
 - RSS feed: $source
 - date published: 2024-10-20T11:05:55+00:00

KARACHI—The price of 24-karat gold was recorded at PKR 279,300. Similarly, the bullion market registered the price of 24-karat gold…

## Lahore, Karachi among most polluted cities in world
 - [https://pakobserver.net/lahore-karachi-among-most-polluted-cities-in-world](https://pakobserver.net/lahore-karachi-among-most-polluted-cities-in-world)
 - RSS feed: $source
 - date published: 2024-10-20T11:05:55+00:00

LAHORE &#8211; With an Air Quality Index (AQI) of 185 (unhealthy), Lahore (Pakistan) ranked second on the list of the…

## Emerging Teams T20 Asia Cup: India A beat Shaheens in last over thriller
 - [https://pakobserver.net/emerging-teams-t20-asia-cup-india-a-beat-shaheens-in-last-over-thriller](https://pakobserver.net/emerging-teams-t20-asia-cup-india-a-beat-shaheens-in-last-over-thriller)
 - RSS feed: $source
 - date published: 2024-10-20T10:22:15+00:00

MUSQAT – India A beat Pakistan Shaheens by seven runs in the ACC Men’s Emerging Teams T20 Asia Cup 2024…

## Govt, IFAD, WFP, FAO committed to enhance food security, nutrition for low communities
 - [https://pakobserver.net/govt-ifad-wfp-fao-committed-to-enhance-food-security-nutrition-for-low-communities](https://pakobserver.net/govt-ifad-wfp-fao-committed-to-enhance-food-security-nutrition-for-low-communities)
 - RSS feed: $source
 - date published: 2024-10-20T01:59:50+00:00

&#160; The United Nations-affiliated organisations, the World Food Programme (WFP), the International Fund for Agricultural Development (IFAD) and the Food…

## SWCCI organizes awareness session
 - [https://pakobserver.net/swcci-organizes-awareness-session](https://pakobserver.net/swcci-organizes-awareness-session)
 - RSS feed: $source
 - date published: 2024-10-20T01:59:49+00:00

&#160; The National Bank of Pakistan and Sargodha Women Chamber of Commerce and Industry (SWCCI) Saturday jointly organised an awareness…

## 10 megawatt solar energy project inaugurated in Kabul
 - [https://pakobserver.net/10-megawatt-solar-energy-project-inaugurated-in-kabul](https://pakobserver.net/10-megawatt-solar-energy-project-inaugurated-in-kabul)
 - RSS feed: $source
 - date published: 2024-10-20T01:59:48+00:00

Acting Minister of Energy and Water Abdul Latif Mansoor stated during the inauguration ceremony that this ten megawatts of energy…

## Indonesia invites Japan to invest in agricultural program
 - [https://pakobserver.net/indonesia-invites-japan-to-invest-in-agricultural-program](https://pakobserver.net/indonesia-invites-japan-to-invest-in-agricultural-program)
 - RSS feed: $source
 - date published: 2024-10-20T01:59:47+00:00

&#160; Deputy Minister of Agriculture Sudaryono invited Japan to invest in Indonesia and intensify cooperation in the agricultural sector, including…

## LCCI President meets DC to discuss Lahore’s business issues
 - [https://pakobserver.net/lcci-president-meets-dc-to-discuss-lahores-business-issues](https://pakobserver.net/lcci-president-meets-dc-to-discuss-lahores-business-issues)
 - RSS feed: $source
 - date published: 2024-10-20T01:59:46+00:00

&#160; A productive meeting held at the Lahore Chamber of Commerce &#38; Industry between LCCI President Mian Abuzar Shad and…

## State Bank of Pakistan releases governor’s annual report 2023-24
 - [https://pakobserver.net/state-bank-of-pakistan-releases-governors-annual-report-2023-24](https://pakobserver.net/state-bank-of-pakistan-releases-governors-annual-report-2023-24)
 - RSS feed: $source
 - date published: 2024-10-20T01:59:45+00:00

&#160; The fiscal year 2024 witnessed improvements across key macroeconomic indicators after two challenging years, according to the Governor’s Annual…

## Faysal Funds participates in Investor Weekend 2024
 - [https://pakobserver.net/faysal-funds-participates-in-investor-weekend-2024](https://pakobserver.net/faysal-funds-participates-in-investor-weekend-2024)
 - RSS feed: $source
 - date published: 2024-10-20T01:57:05+00:00

&#160; Faysal Funds participated in the Investor Weekend 2024, an event aimed at empowering investors with knowledge of new and…

## ABHI secures $15m credit facility
 - [https://pakobserver.net/abhi-secures-15m-credit-facility](https://pakobserver.net/abhi-secures-15m-credit-facility)
 - RSS feed: $source
 - date published: 2024-10-20T01:56:42+00:00

&#160; ABHI, a leading fintech company seeking to enhance financial inclusion for employees and small and medium-sized enterprises (MENAP) in…

## Azerbaijan sees 21% increase  in flights
 - [https://pakobserver.net/azerbaijan-sees-21-increase-in-flights](https://pakobserver.net/azerbaijan-sees-21-increase-in-flights)
 - RSS feed: $source
 - date published: 2024-10-20T01:56:23+00:00

&#160; From January to September of this year, Azerbaijan organized 20,345 flights from 40 countries, Azernews reports citing the State…

## Shaza: Pakistan emerges as leading Global Tech Hub at GITEX
 - [https://pakobserver.net/shaza-pakistan-emerges-as-leading-global-tech-hub-at-gitex](https://pakobserver.net/shaza-pakistan-emerges-as-leading-global-tech-hub-at-gitex)
 - RSS feed: $source
 - date published: 2024-10-20T01:56:19+00:00

&#160; Minister of State for IT and Telecommunication Shaza Fatima Khawaja on Saturday Pakistan’s emergence as a global technology hub…

