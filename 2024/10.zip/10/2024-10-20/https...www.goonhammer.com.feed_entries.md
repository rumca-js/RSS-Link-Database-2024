# Source:Goonhammer, URL:https://www.goonhammer.com/feed, language:en-GB

## Content We Liked: 20th October, 2024
 - [https://www.goonhammer.com/content-we-liked-20th-october-2024](https://www.goonhammer.com/content-we-liked-20th-october-2024)
 - RSS feed: $source
 - date published: 2024-10-20T20:28:59+00:00

The Biggest Shortest King in this week's Content We Liked.

