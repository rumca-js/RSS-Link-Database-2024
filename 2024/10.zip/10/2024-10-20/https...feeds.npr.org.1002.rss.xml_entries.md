# Source:NPR News, URL:https://feeds.npr.org/1002/rss.xml, language:en

## Rock & Roll Hall of Fame inducts Cher, Foreigner, Mary J. Blige, Ozzy and more
 - [https://www.npr.org/2024/10/20/g-s1-29086/rock-roll-hall-of-fame-induct-cher-foreigner-mary-j-blige-ozzy](https://www.npr.org/2024/10/20/g-s1-29086/rock-roll-hall-of-fame-induct-cher-foreigner-mary-j-blige-ozzy)
 - RSS feed: $source
 - date published: 2024-10-20T02:21:45+00:00

Inductees this year also included A Tribe Called Quest and Dave Matthews Band, and posthumous recognition for Jimmy Buffett, MC5, Alexis Korner, John Mayall, Norman Whitfield and Big Mama Thornton.

