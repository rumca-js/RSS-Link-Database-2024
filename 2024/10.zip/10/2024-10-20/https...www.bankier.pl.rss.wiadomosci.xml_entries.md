# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Nie żyje były wiceprezes Jukosu. Wypadł przez okno
 - [https://www.bankier.pl/wiadomosc/Nie-zyje-byly-wiceprezes-Jukosu-Wypadl-przez-okno-8831846.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-zyje-byly-wiceprezes-Jukosu-Wypadl-przez-okno-8831846.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T20:20:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/2/3/3b46823da14366-945-560-0-445-1503-901.jpg" alt="" align="left" />Michaił Rogaczow, były wiceprezes ds. zarządzania korporacyjnego koncernu naftowego Jukos, zostal znaleziony martwy na chodniku przed domem; według lokalnych mediów wypadł z okna.</p>

## "FT": Senatorowie chcą zaostrzenia sankcji wobec rosyjskiej branży naftowej
 - [https://www.bankier.pl/wiadomosc/FT-Senatorowie-chca-zaostrzenia-sankcji-wobec-rosyjskiej-branzy-naftowej-8831856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/FT-Senatorowie-chca-zaostrzenia-sankcji-wobec-rosyjskiej-branzy-naftowej-8831856.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T19:34:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/0/d/d29a81071e4c59-948-568-0-55-4458-2674.jpg" alt="" align="left" />Pięćdziesięciu  senatorów z obu amerykańskich partii domaga się od administracji USA zaostrzenia sankcji wobec rosyjskiej branży usług naftowych, twierdząc, że obecne przepisy pozwalają amerykańskiej firmie SBL na napędzanie rosyjskiej machiny wojennej, poinformował w niedzielę "Financial Times".</p>

## Meteorolog: Ludzie mają wpływ na klimat. Dobrze, że nie możemy wpływać na pogodę
 - [https://www.bankier.pl/wiadomosc/Meteorolog-Ludzie-maja-wplyw-na-klimat-Dobrze-ze-nie-mozemy-wplywac-na-pogode-8831775.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Meteorolog-Ludzie-maja-wplyw-na-klimat-Dobrze-ze-nie-mozemy-wplywac-na-pogode-8831775.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T18:39:49.031208+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/b/4/15d7e8a6609706-948-568-105-0-3395-2036.jpg" alt="" align="left" />W atmosferze Ziemi gromadzi się energia zdolna zatapiać miasta, zrównywać budynki z ziemią, zrzucać na każdy metr kwadratowy hektolitry wody. Choć kontrolowanie pogody może się wydawać kuszące - dobrze, że ludzie tego nie umieją. Taka władza mogłaby być używana nieodpowiednio - powiedział PAP meteorolog dr Dariusz Baranowski.</p>

## Polacy najliczniejszą grupą obcokrajowców w Danii siadających za kółko po alkoholu
 - [https://www.bankier.pl/wiadomosc/Polacy-najliczniejsza-grupa-obcokrajowcow-w-Danii-siadajacych-za-kolko-po-alkoholu-8831706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-najliczniejsza-grupa-obcokrajowcow-w-Danii-siadajacych-za-kolko-po-alkoholu-8831706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T18:39:48.358959+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/0/5/b840ff26cea9c4-948-568-0-139-1904-1142.jpg" alt="" align="left" />W Danii więcej niż co czwarty nietrzeźwy lub przekraczający prędkość kierowca jest obcokrajowcem, Polacy stanowią największą grupę narodowościową, której stawiane są tego rodzaju zarzuty - wynika ze statystyk duńskiej policji. Politycy w Kopenhadze chcą zaostrzyć przepisy.</p>

## Wielotysięczny marsz w Madrycie przeciwko rządowi Sancheza. „Premier jest przestępcą”
 - [https://www.bankier.pl/wiadomosc/Wielotysieczny-marsz-w-Madrycie-przeciwko-rzadowi-Sancheza-Premier-jest-przestepca-8831855.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielotysieczny-marsz-w-Madrycie-przeciwko-rzadowi-Sancheza-Premier-jest-przestepca-8831855.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T18:39:47.910495+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/1/2/ddba80ac5a287e-948-568-0-217-2975-1784.jpg" alt="" align="left" />Tysiące osób protestowały w niedzielę w Madrycie przeciwko lewicowemu rządowi Pedro Sancheza, wzywając do rozpisania nowych wyborów parlamentarnych. Według danych rządowych protest zgromadził ok. 25 tys. osób, organizatorzy podają, że było ich nawet 400 tys.</p>

## Motoryzacyjna rewolucja w Niemczech się nie przyjęła? Kierowcy elektryków wracają do aut spalinowych
 - [https://www.bankier.pl/wiadomosc/Motoryzacyjna-rewolucja-w-Niemczech-sie-nie-przyjela-Kierowcy-elektrykow-wracaja-do-aut-spalinowych-8829529.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Motoryzacyjna-rewolucja-w-Niemczech-sie-nie-przyjela-Kierowcy-elektrykow-wracaja-do-aut-spalinowych-8829529.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T18:39:47.104334+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/3/f/bef5b318d24308-948-568-93-8-3304-1982.jpg" alt="" align="left" />Coraz więcej kierowców samochodów elektrycznych w Niemczech wraca do silników spalinowych przy zakupie kolejnego pojazdu - wynika z danych firmy ubezpieczeniowej Huk Coburg. Wielu Niemców zdecydowałoby się na samochód elektryczny tylko wtedy, gdyby zostali do tego zmuszeni.</p>

## Psycholożka: Zmiana czasu to szok dla naszego zegara biologicznego
 - [https://www.bankier.pl/wiadomosc/Psycholozka-Zmiana-czasu-to-szok-dla-naszego-zegara-biologicznego-8831765.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Psycholozka-Zmiana-czasu-to-szok-dla-naszego-zegara-biologicznego-8831765.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T18:39:46.127719+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/b/8/4e52e527d98788-948-568-0-228-1500-899.jpg" alt="" align="left" />Zmiana czasu jest zakłóceniem funkcjonowania naszego zegara biologicznego poprzez manipulację dostępnością światła - zwraca uwagę psycholożka zdrowia prof. Marta Jackowska z Uniwersytetu SWPS w Sopocie. Tymczasem reguluje on funkcje naszego organizmu, np. sen, trawienie, a nawet nastrój.</p>

## Tragiczny karambol w Gdańsku. 37-letni kierowca tira usłyszał zarzuty 
 - [https://www.bankier.pl/wiadomosc/Tragiczny-karambol-w-Gdansku-37-letni-kierowca-tira-uslyszal-zarzuty-8831835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tragiczny-karambol-w-Gdansku-37-letni-kierowca-tira-uslyszal-zarzuty-8831835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T15:26:57.661938+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/9/7fb2562c18930c-948-568-27-228-1354-812.png" alt="" align="left" />37-letni Mateusz M. kierowca tira, który staranował auta na S7 w Borkowie k. Gdańska usłyszał zarzut spowodowania katastrofy drogowej, w wyniku której zginęły cztery osoby, a 15 zostało rannych. Prokuratura złożyła wniosek do sądu o tymczasowe aresztowanie podejrzanego na trzy miesiące.</p>

## Hejt wśród najczęstszych nieodpowiednich zachowań w internecie
 - [https://www.bankier.pl/wiadomosc/Hejt-wsrod-najczestszych-nieodpowiednich-zachowan-w-internecie-8828622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hejt-wsrod-najczestszych-nieodpowiednich-zachowan-w-internecie-8828622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T15:26:57.161131+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/3/9/4d8e5ed226dafc-948-568-0-124-1765-1059.jpg" alt="" align="left" />Osoby, które w internetowych materiałach wideo czy komentarzach spotkały się z nieodpowiednimi, rażącymi zachowaniami i wypowiedziami, najczęściej wskazywały, że był to hejt. Oprócz niego wskazano na wulgarne treści i dyskryminację - wynika z badania CBOS.</p>

## Rosnąca popularność elektryków może doprowadzić do zakłóceń na rynku ropy. Raport MAE
 - [https://www.bankier.pl/wiadomosc/Rosnaca-popularnosc-elektrykow-moze-doprowadzic-do-zaklocen-na-rynku-ropy-Raport-MAE-8830128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnaca-popularnosc-elektrykow-moze-doprowadzic-do-zaklocen-na-rynku-ropy-Raport-MAE-8830128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T15:26:56.853802+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/9/5/ffd4d0e8caa7f5-948-568-0-270-4000-2399.jpg" alt="" align="left" />Rosnąca popularność samochodów elektrycznych może 
doprowadzić do zakłóceń na rynku ropy, a świat będzie w coraz większym 
stopniu opierać się na czystych źródłach energii elektrycznej - wynika z
 dorocznego raportu Międzynarodowej Agencji Energetycznej (MAE) i 
oświadczenia jej dyrektora Fatiha Birola.</p>

## Bank Światowy: niemal 130 mln Nigeryjczyków żyje w ubóstwie
 - [https://www.bankier.pl/wiadomosc/Bank-Swiatowy-niemal-130-mln-Nigeryjczykow-zyje-w-ubostwie-8831750.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-Swiatowy-niemal-130-mln-Nigeryjczykow-zyje-w-ubostwie-8831750.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:26.552635+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/2/9/a4e99aa8fc86cf-945-560-15-112-2977-1786.jpg" alt="" align="left" />Ponad 129 milionów Nigeryjczyków żyje obecnie poniżej krajowej granicy ubóstwa, co oznacza życie za mniej 1,9 dolara dziennie - poinformował w swoim raporcie Bank Światowy.</p>

## Szefowa Polskiej Izby Mleka: Niepewna przyszłość polskiego mleka na chińskim rynku
 - [https://www.bankier.pl/wiadomosc/Szefowa-Polskiej-Izby-Mleka-Niepewna-przyszlosc-polskiego-mleka-na-chinskim-rynku-8831784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szefowa-Polskiej-Izby-Mleka-Niepewna-przyszlosc-polskiego-mleka-na-chinskim-rynku-8831784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:26.132273+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/6/06abdb944521dc-948-567-0-5-1000-599.jpg" alt="" align="left" />Wzrost chińskiej produkcji mleka, duża konkurencja ze strony innych krajów, groźba zakazu importu produktów mleczarskich jako odwet za cła UE na chińskie sprawiają, że przyszłość polskiego mleka na tym rynku jest niepewna - uważa dyrektor Polskiej Izby Mleka Agnieszka Maliszewska.</p>

## Pendolino pojedzie trasą Szczecin-Warszawa
 - [https://www.bankier.pl/wiadomosc/Pendolino-pojedzie-trasa-Szczecin-Warszawa-8831794.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pendolino-pojedzie-trasa-Szczecin-Warszawa-8831794.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:25.539268+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/4/1/67a86f1ecb55c7-945-560-242-64-2774-1664.jpg" alt="" align="left" />Dzięki wprowadzeniu pociągów Pendolino na trasie łączącej Szczecin z Warszawą będziemy odzyskiwać pasażerów, po remoncie prowadzonym tam w ostatnich latach - zapowiedział w rozmowie z PAP rzecznik PKP Intercity Maciej Dutkiewicz.</p>

## Kuba powstaje z ciemności. Udało się częściowo przywrócić dostawy prądu na wyspie
 - [https://www.bankier.pl/wiadomosc/Kuba-powstaje-z-ciemnosci-Udalo-sie-czesciowo-przywrocic-dostawy-pradu-na-wyspie-8831819.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kuba-powstaje-z-ciemnosci-Udalo-sie-czesciowo-przywrocic-dostawy-pradu-na-wyspie-8831819.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:24.976751+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/2/b/8f8764d0f58e0a-948-568-0-303-4500-2699.jpg" alt="" align="left" />Na części terytorium Kuby udało się w niedzielę przywrócić dostawy energii elektrycznej wstrzymanych w piątek z powodu awarii głównej elektrowni kraju, Antonio Guiteras w Matanzas.</p>

## Do samolotu marsz. Goldman Sachs prognozuje duży wzrost zapotrzebowania na paliwo lotnicze  
 - [https://www.bankier.pl/wiadomosc/Do-samolotu-marsz-Goldman-Sachs-prognozuje-duzy-wzrost-zapotrzebowania-na-paliwo-lotnicze-8829918.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Do-samolotu-marsz-Goldman-Sachs-prognozuje-duzy-wzrost-zapotrzebowania-na-paliwo-lotnicze-8829918.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:24.456041+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/3/5/aeb47a04e8ee76-948-568-1166-0-2124-1274.jpg" alt="" align="left" />Według prognoz Goldman Sachs zapotrzebowanie na paliwo lotnicze na świecie wzrośnie do 2040 r. o 45 proc. Jak tłumaczą ekonomiści, wynika to ze spodziewanego wzrostu liczby pasażerów linii lotniczych oraz wyzwań dot. zielonych alternatyw.</p>

## Witczak: W ciągu dekady zagłosujemy w Polsce przez internet
 - [https://www.bankier.pl/wiadomosc/Witczak-W-ciagu-dekady-zaglosujemy-w-Polsce-przez-internet-8831606.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Witczak-W-ciagu-dekady-zaglosujemy-w-Polsce-przez-internet-8831606.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:24.081171+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/c/1/9efb187e9697ed-948-567-0-7-1000-599.jpg" alt="" align="left" />W aplikacji mObywatel są już pierwsze elementy, z których będzie można skorzystać w zdigitalizacji podejścia do wyborów. Jestem przekonany, że w ciągu 10 lat będzie można głosować w wyborach przez internet - powiedział w Studiu PAP Mariusz Witczak (KO), szef podkomisji ds. zmian w prawie wyborczym.</p>

## Trump: Xi nie zablokuje Tajwanu. Wie, że jestem szalony
 - [https://www.bankier.pl/wiadomosc/Trump-Xi-nie-zablokuje-Tajwanu-Wie-ze-jestem-szalony-8831725.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trump-Xi-nie-zablokuje-Tajwanu-Wie-ze-jestem-szalony-8831725.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:23.702401+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/6/6/1ac7ed54ea024c-945-560-0-202-3000-1799.jpg" alt="" align="left" />Xi Jinping nie zdecyduje się na blokadę Tajwanu, bo mnie szanuje i wie że jestem szalony - powiedział Donald Trump w opublikowanym w sobotę wywiadzie dla "Wall Street Journal". Były prezydent twierdził też, że groził Władimirowi Putinowi uderzeniem na Moskwę, gdyby ten najechał Ukrainę.</p>

## Światowy system żywnościowy może się załamać. Są z nim związane miliardy dolarów ukrytych kosztów  
 - [https://www.bankier.pl/wiadomosc/Swiatowy-system-zywnosciowy-moze-sie-zalamac-Sa-z-nim-zwiazane-miliardy-dolarow-ukrytych-kosztow-8821542.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Swiatowy-system-zywnosciowy-moze-sie-zalamac-Sa-z-nim-zwiazane-miliardy-dolarow-ukrytych-kosztow-8821542.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:23.268014+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/c/b/21d90b8546169e-948-568-0-147-3272-1963.jpg" alt="" align="left" />Ukryte koszty związane z negatywnym wpływem światowego systemu żywnościowego na środowisko i zdrowie publiczne wynoszą ok. 15 mld dol. rocznie - pokazał niedawny raport Food System Economic Commission (FSEC). Naukowcy wskazują...</p>

## 170 mld zł na politykę społeczną. Rząd reaguje na dane o rekordowo wysokim stopniu ubóstwa w Polsce
 - [https://www.bankier.pl/wiadomosc/170-mld-zl-na-polityke-spoleczna-Rzad-reaguje-na-dane-o-rekordowo-wysokim-stopniu-ubostwa-w-Polsce-8831782.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/170-mld-zl-na-polityke-spoleczna-Rzad-reaguje-na-dane-o-rekordowo-wysokim-stopniu-ubostwa-w-Polsce-8831782.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:22.708601+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/5/1/1b1cbdd593c413-948-568-10-140-3990-2393.jpg" alt="" align="left" />Wyniki raportu na temat ubóstwa mobilizują polski rząd do podjęcia działań, które pozwolą odmienić obserwowaną od niespełna dekady tendencję; w walce z wysokim stopniem ubóstwa pomoże rekordowe 170 mld zł na politykę społeczną w budżecie na 2025 r. - przekazał PAP resort rodziny.</p>

## Łukasz Litewka kandydatem Lewicy na prezydenta? "Ma sporą grupę fanów, a do tego potencjał"
 - [https://www.bankier.pl/wiadomosc/Lukasz-Litewka-kandydatem-Lewicy-na-prezydenta-Ma-spora-grupe-fanow-a-do-tego-potencjal-8831760.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lukasz-Litewka-kandydatem-Lewicy-na-prezydenta-Ma-spora-grupe-fanow-a-do-tego-potencjal-8831760.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T08:56:00.254239+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/c/0/6caa18117e7a26-948-568-51-15-1893-1136.jpg" alt="" align="left" />Poseł Łukasz Litewka ma sporą grupę fanów i potencjał; rozważamy wielu potencjalnych kandydatów na urząd prezydenta - powiedział PAP wiceszef klubu Lewicy Tomasz Trela. Z kolei europoseł Krzysztof Śmiszek zapewnił, że Lewica będzie indywidualnie oceniała każdego z kandydatów za ich dokonania.</p>

## Kolejna pandemia to tylko kwestia czasu - mówi raport, który powstał dla rządu Kanady
 - [https://www.bankier.pl/wiadomosc/Kolejna-pandemia-to-tylko-kwestia-czasu-mowi-raport-ktory-powstal-dla-rzadu-Kanady-8831791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejna-pandemia-to-tylko-kwestia-czasu-mowi-raport-ktory-powstal-dla-rzadu-Kanady-8831791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T08:56:00.055144+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/d/b/ba55a130e5a230-945-567-127-203-3266-1960.jpg" alt="" align="left" />Kolejna pandemia to kwestia czasu, może być groźniejsza niż Covid-19. Należy przygotowywać się już teraz, a rządy powinny w swoich planach zwrócić uwagę na uboższe i doświadczające dyskryminacji grupy społeczne – napisali autorzy najnowszego kanadyjskiego raportu.</p>

## Mołdawia wybiera prezydenta. Trwa też referendum w sprawie wpisania eurointegracji do konstytucji
 - [https://www.bankier.pl/wiadomosc/Moldawia-wybiera-prezydenta-Trwa-tez-referendum-w-sprawie-wpisania-eurointegracji-do-konstytucji-8831792.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Moldawia-wybiera-prezydenta-Trwa-tez-referendum-w-sprawie-wpisania-eurointegracji-do-konstytucji-8831792.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T08:55:59.806885+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/e/7/b619e2b9b12288-948-568-10-270-3983-2390.jpg" alt="" align="left" />W niedzielę w Mołdawii odbywają się wybory prezydenckie i referendum, dotyczące wpisania eurointegracji do konstytucji jako celu strategicznego kraju. Lokale wyborcze będą otwarte do godziny 21 czasu lokalnego (20 w Polsce).</p>

## W grach hazardowych prawo nie nadąża za technologią. Branża apeluje o zmiany
 - [https://www.bankier.pl/wiadomosc/W-grach-hazardowych-prawo-nie-nadaza-za-technologia-Branza-apeluje-o-zmiany-8830828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-grach-hazardowych-prawo-nie-nadaza-za-technologia-Branza-apeluje-o-zmiany-8830828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T07:51:07.056666+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/3/377b971c52ba18-948-568-0-130-1632-979.jpg" alt="" align="left" />Konieczne jest niezwłoczne dostosowanie ustawy o grach hazardowych do zmieniającej się rzeczywistości i technologii; rozwiązaniem mogłyby być państwowe licencje - przekazało stowarzyszenie "Graj Legalnie" działające na rzecz legalnych firm bukmacherskich.</p>

## Finanse w polskiej nauce są niewystarczające. Badacze rezygnują albo wyjeżdżają za granicę
 - [https://www.bankier.pl/wiadomosc/Finanse-w-polskiej-nauce-sa-niewystarczajace-Badacze-rezygnuja-albo-wyjezdzaja-za-granice-8826562.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finanse-w-polskiej-nauce-sa-niewystarczajace-Badacze-rezygnuja-albo-wyjezdzaja-za-granice-8826562.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T07:51:06.809737+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/5/2/8553300a2a6023-948-568-102-0-3840-2303.jpg" alt="" align="left" />W Polsce wzrost pensji w nauce nie postępuje w tym samym tempie, co wzrost pensji w gospodarce ogółem. To budzi frustrację zarówno wśród młodych badaczy na początku kariery, jak i naukowców...</p>

## 37 proc. Polaków uważa, że rząd Donalda Tuska wywiązuje się z obietnic
 - [https://www.bankier.pl/wiadomosc/36-9-proc-Polakow-uwaza-ze-rzad-Donalda-Tuska-wywiazuje-sie-z-obietnic-8831721.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/36-9-proc-Polakow-uwaza-ze-rzad-Donalda-Tuska-wywiazuje-sie-z-obietnic-8831721.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T07:51:06.589306+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/e/a/191635dcb7760c-948-568-15-148-2030-1218.jpg" alt="" align="left" />36,9 proc. Polaków uważa, że rząd Donalda Tuska wywiązuje się z obietnic, przeciwnego zdania jest 51,4 proc. badanych; 11,7 proc. nie ma w tej sprawie zdania - wynika z opublikowanego w sobotę sondażu United Surveys dla Wirtualnej Polski.</p>

## Polskie banki powyżej światowej średniej w obszarze cyfryzacji usług bankowości detalicznej
 - [https://www.bankier.pl/wiadomosc/Polskie-banki-powyzej-swiatowej-sredniej-w-obszarze-cyfryzacji-uslug-bankowosci-detalicznej-8829071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-banki-powyzej-swiatowej-sredniej-w-obszarze-cyfryzacji-uslug-bankowosci-detalicznej-8829071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T07:51:06.414648+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/1/d/05e10eba95c18f-948-568-110-0-3816-2289.jpg" alt="" align="left" />W ciągu ostatnich dwóch lat banki przesunęły priorytety z dodawania i rozwijania nowych funkcjonalności na doskonalenie istniejących rozwiązań oraz optymalizację doświadczeń użytkowników - wynika z raportu Deloitte. Polskie banki utrzymują wyniki powyżej światowej średniej w obszarze cyfryzacji usług bankowości detalicznej.</p>

## Wczasy w Portugalii najdroższe w historii, ale turystów to nie odstrasza
 - [https://www.bankier.pl/wiadomosc/Wczasy-w-Portugalii-najdrozsze-w-historii-ale-turystow-to-nie-odstrasza-8831777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wczasy-w-Portugalii-najdrozsze-w-historii-ale-turystow-to-nie-odstrasza-8831777.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T07:51:06.214548+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/3/1/12517515181d4c-948-569-7-72-991-595.jpg" alt="" align="left" />Organizacje turystyczne i pracownicy sektora hotelarsko-restauracyjnego odnotowują coraz większe zainteresowanie cudzoziemców wakacjami w Portugalii mimo utrzymujących się rekordowych kosztów spędzania urlopu w tym kraju.</p>

## Koniec strajku w Boeingu. Jest wstępne porozumienie z pracownikami
 - [https://www.bankier.pl/wiadomosc/Koniec-strajku-w-Boeingu-Jest-wstepne-porozumienie-z-pracownikami-8831723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-strajku-w-Boeingu-Jest-wstepne-porozumienie-z-pracownikami-8831723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T07:51:05.631533+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/3/e/d36244bc5d611d-948-568-0-165-3000-1799.jpg" alt="" align="left" />Osiągnięto wstępne porozumienie w sprawie zakończenia pięciotygodniowego strajku w produkującej samoloty firmie Boeing, poinformował związek zawodowy w sobotę. W strajku uczestniczyły 33 tys. pracowników, przypomniał portal CNN.</p>

## Domy na kołach nową polską modą. Tylu kamperów jeszcze nie rejestrowaliśmy
 - [https://www.bankier.pl/wiadomosc/Domy-na-kolach-nowa-polska-moda-Tylu-kamperow-jeszcze-nie-rejestrowalismy-8830464.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Domy-na-kolach-nowa-polska-moda-Tylu-kamperow-jeszcze-nie-rejestrowalismy-8830464.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T06:00:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/8/e976cffb74f8bf-948-568-0-133-1980-1188.jpg" alt="" align="left" />Blisko 4 tys. kamperów zarejestrowali Polacy w ciągu pierwszych trzech kwartałów 2024 r. – wynika z danych Polskiego Związku Przemysłu Motoryzacyjnego. To najwyższy wynik w historii. O ile jednak wcześniej dominowały nowe pojazdy, tym razem Polacy zdecydowanie częściej stawiali na używane kampery z zagranicy.</p>

## Mechanik samochodowy na wagę złota? Większość warsztatów poszukuje rąk do pracy, a tych brakuje
 - [https://www.bankier.pl/wiadomosc/Mechanik-samochodowy-na-wage-zlota-Wiekszosc-warsztatow-poszukuje-rak-do-pracy-a-tych-brakuje-8829555.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mechanik-samochodowy-na-wage-zlota-Wiekszosc-warsztatow-poszukuje-rak-do-pracy-a-tych-brakuje-8829555.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T06:00:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/8/7/b6a0469dd9be55-948-568-0-29-1991-1194.jpg" alt="" align="left" />Spośród 24 tys. polskich warsztatów 75 proc. poszukuje fachowców, a głównym problemem niedoborów jest mała liczba młodych ludzi wybierających zawód mechanika - poinformowało Stowarzyszenie Dystrybutorów i Producentów Części Motoryzacyjnych. Konkurs "Wyścig Talentów" ma poprawić tę sytuację.</p>

## Nieprzewidywalna pogoda może zagrozić fotowoltaice? Ubezpieczyciele zacierają ręce
 - [https://www.bankier.pl/wiadomosc/Nieprzewidywalna-pogoda-moze-zagrozic-fotowoltaice-Ubezpieczyciele-zacieraja-rece-8829183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nieprzewidywalna-pogoda-moze-zagrozic-fotowoltaice-Ubezpieczyciele-zacieraja-rece-8829183.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T06:00:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/b/7/e97d011a79c849-948-568-0-0-4598-2758.jpg" alt="" align="left" />Liczba i moc instalacji fotowoltaicznych wciąż rosną. Taka
sytuacja prawdopodobnie przełoży się na większą liczbę ubezpieczeń.</p>

## Rekordowa liczba biernych Polaków na rynku pracy. Coraz mniejsza rotacja pracowników między firmami 
 - [https://www.bankier.pl/wiadomosc/Rekordowa-liczba-biernych-Polakow-na-rynku-pracy-Coraz-mniejsza-rotacja-pracownikow-miedzy-firmami-8829077.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowa-liczba-biernych-Polakow-na-rynku-pracy-Coraz-mniejsza-rotacja-pracownikow-miedzy-firmami-8829077.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T06:00:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/7/f/45630926aa8aac-948-568-0-150-4000-2399.jpg" alt="" align="left" />Na polskim rynku pracy utrzymuje się trend coraz mniejszej rotacji pracowników między firmami, jest on efektem m.in. mniejszej dostępności atrakcyjnych ofert zatrudnienia - wynika z najnowszego badania "Monitor Rynku Pracy" przygotowanego przez Randstad.</p>

## Rośnie liczba Ukraińców posiadających swoje mieszkanie lub dom w Polsce
 - [https://www.bankier.pl/wiadomosc/Rosnie-liczba-Ukraincow-posiadajacych-swoje-mieszkanie-lub-dom-w-Polsce-8828180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnie-liczba-Ukraincow-posiadajacych-swoje-mieszkanie-lub-dom-w-Polsce-8828180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T06:00:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/9/c/3c2b6f15b5d8f0-948-568-0-0-1859-1115.jpg" alt="" align="left" />W grupie  imigrantów ekonomicznych  z Ukrainy, którzy mieszkają w Polsce, rośnie odsetek osób, które posiadają własne mieszkania lub domy - informuje grupa badawcza Openfield. W 2024 roku wśród osób z Ukrainy, które przyjechały do Polski przed 2022 roku, 15 procent deklaruje posiadanie własnej nieruchomości.</p>

## Zapaść demograficzna w Polsce a rynek pracy. Analitycy nie mają dobrych wieści 
 - [https://www.bankier.pl/wiadomosc/Zapasc-demograficzna-w-Polsce-a-rynek-pracy-Analitycy-nie-maja-dobrych-wiesci-8828484.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zapasc-demograficzna-w-Polsce-a-rynek-pracy-Analitycy-nie-maja-dobrych-wiesci-8828484.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: $source
 - date published: 2024-10-20T06:00:00+00:00

<p><img width="945" height="560" class="webfeedsFeaturedVisual" style="display: block; margin-bottom: 5px; clear:both;max-width: 100%;" src="http://galeria.bankier.pl/p/5/2/8ae1a529069f75-945-567-11-93-1488-893.jpg" alt="" align="left" />Przy obecnych trendach demograficznych liczba pracowników do 2035 roku zmniejszy się o 2,1 mln osób -  podają w raporcie analitycy Polskiego Instytutu Ekonomicznego.</p>

