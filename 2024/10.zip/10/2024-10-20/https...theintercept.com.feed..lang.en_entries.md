# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Trump’s Housing Platform Is as Absurd as It Is Cruel — and That’s the Point
 - [https://theintercept.com/2024/10/20/trump-affordable-housing-republican-platform](https://theintercept.com/2024/10/20/trump-affordable-housing-republican-platform)
 - RSS feed: $source
 - date published: 2024-10-20T12:00:00+00:00

<p>From building futuristic cities to rounding up unhoused and undocumented people, the plans send a message about who does and doesn’t belong in Trump's America.</p>
<p>The post <a href="https://theintercept.com/2024/10/20/trump-affordable-housing-republican-platform/">Trump’s Housing Platform Is as Absurd as It Is Cruel — and That’s the Point</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>


## Israeli Military Joins In on Settlers’ War to Displace Palestinian Bedouins
 - [https://theintercept.com/2024/10/20/israel-military-settlers-palestine-bedouins](https://theintercept.com/2024/10/20/israel-military-settlers-palestine-bedouins)
 - RSS feed: $source
 - date published: 2024-10-20T10:00:00+00:00

<p>With the Israeli military standing by or, increasingly, joining settler attacks, Bedouin communities are especially vulnerable.</p>
<p>The post <a href="https://theintercept.com/2024/10/20/israel-military-settlers-palestine-bedouins/">Israeli Military Joins In on Settlers’ War to Displace Palestinian Bedouins</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>


