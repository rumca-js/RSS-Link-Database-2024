# Source:Reddit - World News, URL:https://www.reddit.com/r/worldnews/.rss, language:en

## US writer Anne Applebaum appeals for arms for Ukraine as she accepts German peace prize
 - [https://www.reddit.com/r/worldnews/comments/1g8bmea/us_writer_anne_applebaum_appeals_for_arms_for](https://www.reddit.com/r/worldnews/comments/1g8bmea/us_writer_anne_applebaum_appeals_for_arms_for)
 - RSS feed: $source
 - date published: 2024-10-20T23:03:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g8bmea/us_writer_anne_applebaum_appeals_for_arms_for/"> <img src="https://external-preview.redd.it/6m5pccuikQnmoAV8G3hjAIf_qLHoB9V0g5ju7zeWWpI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d31ce74232daf664284acb9f4de342282b1f7139" alt="US writer Anne Applebaum appeals for arms for Ukraine as she accepts German peace prize" title="US writer Anne Applebaum appeals for arms for Ukraine as she accepts German peace prize" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/eaglemaxie"> /u/eaglemaxie </a> <br/> <span><a href="https://abcnews.go.com/US/wireStory/us-writer-anne-applebaum-appeals-arms-ukraine-accepts-114968905">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g8bmea/us_writer_anne_applebaum_appeals_for_arms_for/">[comments]</a></span> </td></tr></table>

## ‘Resurgent’ ISIS and al Qaeda targeting Europe once again, Britain’s MI5 chief warns
 - [https://www.reddit.com/r/worldnews/comments/1g8a7rt/resurgent_isis_and_al_qaeda_targeting_europe_once](https://www.reddit.com/r/worldnews/comments/1g8a7rt/resurgent_isis_and_al_qaeda_targeting_europe_once)
 - RSS feed: $source
 - date published: 2024-10-20T21:56:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g8a7rt/resurgent_isis_and_al_qaeda_targeting_europe_once/"> <img src="https://external-preview.redd.it/--Iave52KG8peuBtDQxUcxS2ygdZ691Q0yEfyphhhDs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=255c41046ee60572e39cb292e81091de5f26dcc3" alt="‘Resurgent’ ISIS and al Qaeda targeting Europe once again, Britain’s MI5 chief warns" title="‘Resurgent’ ISIS and al Qaeda targeting Europe once again, Britain’s MI5 chief warns" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DoremusJessup"> /u/DoremusJessup </a> <br/> <span><a href="https://www.cnn.com/2024/10/08/uk/mi5-terrorism-speech-isis-al-qaeda-gbr-intl/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g8a7rt/resurgent_isis_and_al_qaeda_targeting_europe_once/">[comments]</a></span> </td></tr></table>

## Moldovans voting 'no' against pro-EU constitution change - early results
 - [https://www.reddit.com/r/worldnews/comments/1g89lmc/moldovans_voting_no_against_proeu_constitution](https://www.reddit.com/r/worldnews/comments/1g89lmc/moldovans_voting_no_against_proeu_constitution)
 - RSS feed: $source
 - date published: 2024-10-20T21:29:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g89lmc/moldovans_voting_no_against_proeu_constitution/"> <img src="https://external-preview.redd.it/jqHsv7jzrDrmYAt-ijVKG5HCGwXE-dfG0R2vwi14UmQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c50b942c4877870074011a94737654b435494c81" alt="Moldovans voting 'no' against pro-EU constitution change - early results" title="Moldovans voting 'no' against pro-EU constitution change - early results" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GeoWa"> /u/GeoWa </a> <br/> <span><a href="https://www.bbc.com/news/articles/c1wnr5qdxe7o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g89lmc/moldovans_voting_no_against_proeu_constitution/">[comments]</a></span> </td></tr></table>

## Egypt declared malaria-free after 100-year effort
 - [https://www.reddit.com/r/worldnews/comments/1g88hb2/egypt_declared_malariafree_after_100year_effort](https://www.reddit.com/r/worldnews/comments/1g88hb2/egypt_declared_malariafree_after_100year_effort)
 - RSS feed: $source
 - date published: 2024-10-20T20:39:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g88hb2/egypt_declared_malariafree_after_100year_effort/"> <img src="https://external-preview.redd.it/b13Mqmg3UB3sDZEKKaaoz3tk2EFFY5M8Uc04iYTzvRc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d0780f92f20dc4dee9c55e42325b242a19f96d45" alt="Egypt declared malaria-free after 100-year effort" title="Egypt declared malaria-free after 100-year effort" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/giuliomagnifico"> /u/giuliomagnifico </a> <br/> <span><a href="https://www.bbc.com/news/articles/cm2yl8pjgn2o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g88hb2/egypt_declared_malariafree_after_100year_effort/">[comments]</a></span> </td></tr></table>

## Preliminary results indicate that Moldova’s pro-European incumbent president Maia Sandu is in the lead, however the proposition to enshrine the country’s European aspirations in Moldova’s constitution may have fallen through
 - [https://www.reddit.com/r/worldnews/comments/1g87v73/preliminary_results_indicate_that_moldovas](https://www.reddit.com/r/worldnews/comments/1g87v73/preliminary_results_indicate_that_moldovas)
 - RSS feed: $source
 - date published: 2024-10-20T20:12:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g87v73/preliminary_results_indicate_that_moldovas/"> <img src="https://external-preview.redd.it/wgvgf_I2RCmwGUygzEotXttcifYtmY6BJtai5fTvIeI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9c91908a9743d6518ae3c3661868c120c20ac733" alt="Preliminary results indicate that Moldova’s pro-European incumbent president Maia Sandu is in the lead, however the proposition to enshrine the country’s European aspirations in Moldova’s constitution may have fallen through" title="Preliminary results indicate that Moldova’s pro-European incumbent president Maia Sandu is in the lead, however the proposition to enshrine the country’s European aspirations in Moldova’s constitution may have fallen through" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/green_flash"> /u/green_flash </a> <br/> <span><a href="https://tvpworld.com/83067932/moldovan-presidential-elections-and-referendum-conclude">[link]</a><

## U.S. investigating apparent leak of 'top secret' U.S. documents regarding Israel
 - [https://www.reddit.com/r/worldnews/comments/1g85xnv/us_investigating_apparent_leak_of_top_secret_us](https://www.reddit.com/r/worldnews/comments/1g85xnv/us_investigating_apparent_leak_of_top_secret_us)
 - RSS feed: $source
 - date published: 2024-10-20T18:49:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g85xnv/us_investigating_apparent_leak_of_top_secret_us/"> <img src="https://external-preview.redd.it/nrPz2RxVKuDlqGWKgxWZLM9_MflTb2GMXK2OT3qsXAU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6cfa605c927b6fff6f73ff8020f9f5931c2c2400" alt="U.S. investigating apparent leak of 'top secret' U.S. documents regarding Israel " title="U.S. investigating apparent leak of 'top secret' U.S. documents regarding Israel " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IntelligentRub9254"> /u/IntelligentRub9254 </a> <br/> <span><a href="https://www.nbcnews.com/news/us-investigating-apparent-leak-top-secret-us-documents-israel-rcna176286?cid=sm_npd_nn_tw_ma&amp;taid=671543477579ab00015eb76a&amp;utm_campaign=trueanthem&amp;utm_medium=social&amp;utm_source=twitter">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g85xnv/us_investigating_apparent_leak_of_top_secret

## Tens of thousands of pro-EU supporters rally in Georgia ahead of key vote
 - [https://www.reddit.com/r/worldnews/comments/1g85uaz/tens_of_thousands_of_proeu_supporters_rally_in](https://www.reddit.com/r/worldnews/comments/1g85uaz/tens_of_thousands_of_proeu_supporters_rally_in)
 - RSS feed: $source
 - date published: 2024-10-20T18:45:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g85uaz/tens_of_thousands_of_proeu_supporters_rally_in/"> <img src="https://external-preview.redd.it/i17lY5WmcCm6OQ0A6gE-3ShUmylz1XtmcuRSWDIjzLo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d9c92656871cd74c9216ee40c1f1dfd761d4d5c0" alt="Tens of thousands of pro-EU supporters rally in Georgia ahead of key vote" title="Tens of thousands of pro-EU supporters rally in Georgia ahead of key vote" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/No_Discussion6913"> /u/No_Discussion6913 </a> <br/> <span><a href="https://www.france24.com/en/europe/20241020-tens-of-thousands-of-pro-eu-supporters-rally-in-georgia-ahead-of-key-vote?utm_medium=social&amp;utm_campaign=telegram&amp;utm_source=shorty&amp;utm_slink=f24.my%2FAgI5">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g85uaz/tens_of_thousands_of_proeu_supporters_rally_in/">[comments]</a></span> </td></tr

## Israel says it will target Hezbollah's financial arm and announces imminent strikes in Lebanon
 - [https://www.reddit.com/r/worldnews/comments/1g85m8d/israel_says_it_will_target_hezbollahs_financial](https://www.reddit.com/r/worldnews/comments/1g85m8d/israel_says_it_will_target_hezbollahs_financial)
 - RSS feed: $source
 - date published: 2024-10-20T18:36:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g85m8d/israel_says_it_will_target_hezbollahs_financial/"> <img src="https://external-preview.redd.it/9Llvkit81h2jFKwOwYMrmrfpwTp-1jT4Dw34IdZs8S4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3602ab6bf290b0f63a15b4ecf45b9ee948b5d125" alt="Israel says it will target Hezbollah's financial arm and announces imminent strikes in Lebanon" title="Israel says it will target Hezbollah's financial arm and announces imminent strikes in Lebanon" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Impossible_Piano_29"> /u/Impossible_Piano_29 </a> <br/> <span><a href="https://apnews.com/article/42ea48ce0f6a31d53a25dc50f16796bc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g85m8d/israel_says_it_will_target_hezbollahs_financial/">[comments]</a></span> </td></tr></table>

## Germany: police arrest man over Israeli Embassy attack plot
 - [https://www.reddit.com/r/worldnews/comments/1g84ma4/germany_police_arrest_man_over_israeli_embassy](https://www.reddit.com/r/worldnews/comments/1g84ma4/germany_police_arrest_man_over_israeli_embassy)
 - RSS feed: $source
 - date published: 2024-10-20T17:53:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g84ma4/germany_police_arrest_man_over_israeli_embassy/"> <img src="https://external-preview.redd.it/9CMeFm0GuIkIR8ELbS50s8qxZR3Hde9EoAxnUpQ485U.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a289c3fa7ede2e2f36ede2fcda952517309cb9ad" alt="Germany: police arrest man over Israeli Embassy attack plot" title="Germany: police arrest man over Israeli Embassy attack plot" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DoremusJessup"> /u/DoremusJessup </a> <br/> <span><a href="https://www.dw.com/en/germany-police-arrest-man-over-israeli-embassy-attack-plot/a-70544628">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g84ma4/germany_police_arrest_man_over_israeli_embassy/">[comments]</a></span> </td></tr></table>

## Brazil's Lula cancels trip to Russia for BRICS summit after an accident
 - [https://www.reddit.com/r/worldnews/comments/1g84hmd/brazils_lula_cancels_trip_to_russia_for_brics](https://www.reddit.com/r/worldnews/comments/1g84hmd/brazils_lula_cancels_trip_to_russia_for_brics)
 - RSS feed: $source
 - date published: 2024-10-20T17:48:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g84hmd/brazils_lula_cancels_trip_to_russia_for_brics/"> <img src="https://external-preview.redd.it/HPsNs2lJHqd5ju2KqVj6J-Nmo7bb7UNk-VYumVV4iQw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=05dbc3b73c8fa76813ed05b6264f21133f7bbaf9" alt="Brazil's Lula cancels trip to Russia for BRICS summit after an accident" title="Brazil's Lula cancels trip to Russia for BRICS summit after an accident" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/loggiews"> /u/loggiews </a> <br/> <span><a href="https://apnews.com/article/brazil-lula-russia-brics-accident-72bb15272a99afa06f0f0562ae6d006a">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g84hmd/brazils_lula_cancels_trip_to_russia_for_brics/">[comments]</a></span> </td></tr></table>

## Police deny Polish opposition leader’s claim that “migrants are occupying buildings in Warsaw”
 - [https://www.reddit.com/r/worldnews/comments/1g83htt/police_deny_polish_opposition_leaders_claim_that](https://www.reddit.com/r/worldnews/comments/1g83htt/police_deny_polish_opposition_leaders_claim_that)
 - RSS feed: $source
 - date published: 2024-10-20T17:05:00+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/BubsyFanboy"> /u/BubsyFanboy </a> <br/> <span><a href="https://notesfrompoland.com/2024/10/19/police-deny-opposition-leaders-claim-that-migrants-are-occupying-buildings-in-warsaw/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g83htt/police_deny_polish_opposition_leaders_claim_that/">[comments]</a></span>

## Ukraine attacks forced Black Sea Fleet to move warships from Sevastopol, Russian official says
 - [https://www.reddit.com/r/worldnews/comments/1g83gxj/ukraine_attacks_forced_black_sea_fleet_to_move](https://www.reddit.com/r/worldnews/comments/1g83gxj/ukraine_attacks_forced_black_sea_fleet_to_move)
 - RSS feed: $source
 - date published: 2024-10-20T17:03:56+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Alternative-Dog7185"> /u/Alternative-Dog7185 </a> <br/> <span><a href="https://www.reuters.com/world/europe/ukraine-attacks-forced-black-sea-fleet-move-warships-sevastopol-russian-official-2024-10-20/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g83gxj/ukraine_attacks_forced_black_sea_fleet_to_move/">[comments]</a></span>

## France open to idea of inviting Ukraine to join NATO – French foreign minister
 - [https://www.reddit.com/r/worldnews/comments/1g83ca0/france_open_to_idea_of_inviting_ukraine_to_join](https://www.reddit.com/r/worldnews/comments/1g83ca0/france_open_to_idea_of_inviting_ukraine_to_join)
 - RSS feed: $source
 - date published: 2024-10-20T16:58:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g83ca0/france_open_to_idea_of_inviting_ukraine_to_join/"> <img src="https://external-preview.redd.it/GXypNGC6bHC1YuGPwKVGVQIIMtVZiLtpheGWYLt1CHc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d79334dc74599f90e2019eb6c6c3f9f97b675233" alt="France open to idea of inviting Ukraine to join NATO – French foreign minister" title="France open to idea of inviting Ukraine to join NATO – French foreign minister" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheRealMykola"> /u/TheRealMykola </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/10/19/7480469/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g83ca0/france_open_to_idea_of_inviting_ukraine_to_join/">[comments]</a></span> </td></tr></table>

## U.S. on DPRK involvement in Russia’s war effort: Sign of Moscow’s desperation, not strength
 - [https://www.reddit.com/r/worldnews/comments/1g81o4a/us_on_dprk_involvement_in_russias_war_effort_sign](https://www.reddit.com/r/worldnews/comments/1g81o4a/us_on_dprk_involvement_in_russias_war_effort_sign)
 - RSS feed: $source
 - date published: 2024-10-20T15:46:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g81o4a/us_on_dprk_involvement_in_russias_war_effort_sign/"> <img src="https://external-preview.redd.it/ExCLIhBteBhcaoflCSqIpRidvhxCgshksGEgjK6nuvA.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=ecef3221d4043545a6500f7d7ffd10297097ccc2" alt="U.S. on DPRK involvement in Russia’s war effort: Sign of Moscow’s desperation, not strength" title="U.S. on DPRK involvement in Russia’s war effort: Sign of Moscow’s desperation, not strength" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/blllrrrrr"> /u/blllrrrrr </a> <br/> <span><a href="https://www.ukrinform.net/rubric-polytics/3917954-us-on-dprk-involvement-in-russias-war-effort-sign-of-moscows-desperation-not-strength.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g81o4a/us_on_dprk_involvement_in_russias_war_effort_sign/">[comments]</a></span> </td></tr></table>

## Finnish children attend Kremlin-sponsored summer camp in Russian-occupied Crimea
 - [https://www.reddit.com/r/worldnews/comments/1g81k9n/finnish_children_attend_kremlinsponsored_summer](https://www.reddit.com/r/worldnews/comments/1g81k9n/finnish_children_attend_kremlinsponsored_summer)
 - RSS feed: $source
 - date published: 2024-10-20T15:41:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g81k9n/finnish_children_attend_kremlinsponsored_summer/"> <img src="https://external-preview.redd.it/EdBwP1ZW5vVo9R8XN1sOldvSh11mQHeuP5b6GJpUh4I.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=598c59411b8b39c3e1feecfb8d48664a2685c7e9" alt="Finnish children attend Kremlin-sponsored summer camp in Russian-occupied Crimea" title="Finnish children attend Kremlin-sponsored summer camp in Russian-occupied Crimea" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/YourShowerCompanion"> /u/YourShowerCompanion </a> <br/> <span><a href="https://yle.fi/a/74-20119032">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g81k9n/finnish_children_attend_kremlinsponsored_summer/">[comments]</a></span> </td></tr></table>

## Israel to take legal action against Macron over naval trade show ban
 - [https://www.reddit.com/r/worldnews/comments/1g81j8z/israel_to_take_legal_action_against_macron_over](https://www.reddit.com/r/worldnews/comments/1g81j8z/israel_to_take_legal_action_against_macron_over)
 - RSS feed: $source
 - date published: 2024-10-20T15:40:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g81j8z/israel_to_take_legal_action_against_macron_over/"> <img src="https://external-preview.redd.it/BW2lbSSOaHFVHYuQaTTEV9-NoHVeB6etWWZGwqh5L5Y.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4879d10093f7c83556a86ad0cd2610bf0cff62f0" alt="Israel to take legal action against Macron over naval trade show ban" title="Israel to take legal action against Macron over naval trade show ban" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://www.voanews.com/a/israel-to-take-legal-action-against-macron-over-naval-trade-show-ban/7829303.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g81j8z/israel_to_take_legal_action_against_macron_over/">[comments]</a></span> </td></tr></table>

## Moldovans Poised to Clear Hurdle as Country Votes on EU Path
 - [https://www.reddit.com/r/worldnews/comments/1g816rx/moldovans_poised_to_clear_hurdle_as_country_votes](https://www.reddit.com/r/worldnews/comments/1g816rx/moldovans_poised_to_clear_hurdle_as_country_votes)
 - RSS feed: $source
 - date published: 2024-10-20T15:24:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g816rx/moldovans_poised_to_clear_hurdle_as_country_votes/"> <img src="https://external-preview.redd.it/0b2za2l107FfuWfBCbw0HSZ0yVwMvzimkNvRbztvQzo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=162b02afcef5fb0e38bfa819eca83b945d2ef631" alt="Moldovans Poised to Clear Hurdle as Country Votes on EU Path" title="Moldovans Poised to Clear Hurdle as Country Votes on EU Path" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bloomberg"> /u/bloomberg </a> <br/> <span><a href="https://www.bloomberg.com/news/articles/2024-10-20/moldovans-poised-to-clear-hurdle-as-country-votes-on-eu-path">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g816rx/moldovans_poised_to_clear_hurdle_as_country_votes/">[comments]</a></span> </td></tr></table>

## Denmark will provide Ukraine with a new military aid package worth over 320 million euros
 - [https://www.reddit.com/r/worldnews/comments/1g80ek2/denmark_will_provide_ukraine_with_a_new_military](https://www.reddit.com/r/worldnews/comments/1g80ek2/denmark_will_provide_ukraine_with_a_new_military)
 - RSS feed: $source
 - date published: 2024-10-20T14:49:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g80ek2/denmark_will_provide_ukraine_with_a_new_military/"> <img src="https://external-preview.redd.it/1mJ-mOZnEYPg8YLLQV0c8A68ISp-ILC2kTBBypOUb7s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5c9a0dcfbee34d6af12f9895df52b93193070d6a" alt="Denmark will provide Ukraine with a new military aid package worth over 320 million euros " title="Denmark will provide Ukraine with a new military aid package worth over 320 million euros " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CompetitiveNovel8990"> /u/CompetitiveNovel8990 </a> <br/> <span><a href="https://odessa-journal.com/denmark-will-provide-ukraine-with-a-new-military-aid-package-worth-over-320-million-euros">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g80ek2/denmark_will_provide_ukraine_with_a_new_military/">[comments]</a></span> </td></tr></table>

## S. Korean satellite captures image of N. Korean troop movement to Russia: source
 - [https://www.reddit.com/r/worldnews/comments/1g80aj5/s_korean_satellite_captures_image_of_n_korean](https://www.reddit.com/r/worldnews/comments/1g80aj5/s_korean_satellite_captures_image_of_n_korean)
 - RSS feed: $source
 - date published: 2024-10-20T14:44:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g80aj5/s_korean_satellite_captures_image_of_n_korean/"> <img src="https://external-preview.redd.it/8UDkIj4hNtJtaa9dyiPAAZMT7bwFMH4JbYWEenKfjlQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=434392f95c524d76881cdd4a7232bfb410ccc088" alt="S. Korean satellite captures image of N. Korean troop movement to Russia: source " title="S. Korean satellite captures image of N. Korean troop movement to Russia: source " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Saltedline"> /u/Saltedline </a> <br/> <span><a href="https://m-en.yna.co.kr/view/AEN20241020002800315?section=nk/nk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g80aj5/s_korean_satellite_captures_image_of_n_korean/">[comments]</a></span> </td></tr></table>

## U.S. investigating unauthorized release of classified documents on Israel attack plans
 - [https://www.reddit.com/r/worldnews/comments/1g7zvf6/us_investigating_unauthorized_release_of](https://www.reddit.com/r/worldnews/comments/1g7zvf6/us_investigating_unauthorized_release_of)
 - RSS feed: $source
 - date published: 2024-10-20T14:24:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7zvf6/us_investigating_unauthorized_release_of/"> <img src="https://external-preview.redd.it/XkseCs_YYSpKQctbIawQkLQA5eycAXvT7ob9U7vflJg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=300ef903cd0af00fb67e489acb44bb4f80c808b4" alt="U.S. investigating unauthorized release of classified documents on Israel attack plans" title="U.S. investigating unauthorized release of classified documents on Israel attack plans" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PoorIsTheNewSwag"> /u/PoorIsTheNewSwag </a> <br/> <span><a href="https://www.npr.org/2024/10/19/g-s1-29081/us-investigating-unauthorized-release-classified-documents-israel-attack-plans">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7zvf6/us_investigating_unauthorized_release_of/">[comments]</a></span> </td></tr></table>

## Russian army after war may be stronger than it is today – NATO top general
 - [https://www.reddit.com/r/worldnews/comments/1g7ynw6/russian_army_after_war_may_be_stronger_than_it_is](https://www.reddit.com/r/worldnews/comments/1g7ynw6/russian_army_after_war_may_be_stronger_than_it_is)
 - RSS feed: $source
 - date published: 2024-10-20T13:26:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7ynw6/russian_army_after_war_may_be_stronger_than_it_is/"> <img src="https://external-preview.redd.it/VVNKlkTjDnfyMkUGS-rtd7LIDSMujzWYPH9sxuOUa5A.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cc48c6fd87046ec1230a38d53f8f49e3f1df870b" alt="Russian army after war may be stronger than it is today – NATO top general" title="Russian army after war may be stronger than it is today – NATO top general" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/snowy_heart"> /u/snowy_heart </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/10/20/7480538/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7ynw6/russian_army_after_war_may_be_stronger_than_it_is/">[comments]</a></span> </td></tr></table>

## Russian victory would bring 'chaos,' French FM says
 - [https://www.reddit.com/r/worldnews/comments/1g7ygn3/russian_victory_would_bring_chaos_french_fm_says](https://www.reddit.com/r/worldnews/comments/1g7ygn3/russian_victory_would_bring_chaos_french_fm_says)
 - RSS feed: $source
 - date published: 2024-10-20T13:16:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7ygn3/russian_victory_would_bring_chaos_french_fm_says/"> <img src="https://external-preview.redd.it/l-dJ2gI1KoCeMG3WkWG3SFkV7e-aZXERn3FRTvnmxPk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4528d151a9126b72266b23c5c29b71e6e55e442a" alt="Russian victory would bring 'chaos,' French FM says" title="Russian victory would bring 'chaos,' French FM says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AdSpecialist6598"> /u/AdSpecialist6598 </a> <br/> <span><a href="https://kyivindependent.com/russian-victory-would-bring-chaos-french-fm-says/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7ygn3/russian_victory_would_bring_chaos_french_fm_says/">[comments]</a></span> </td></tr></table>

## Xi Jinping Asks Troops To Prepare For War As Battle Drills Intensify Around Taiwan
 - [https://www.reddit.com/r/worldnews/comments/1g7yefa/xi_jinping_asks_troops_to_prepare_for_war_as](https://www.reddit.com/r/worldnews/comments/1g7yefa/xi_jinping_asks_troops_to_prepare_for_war_as)
 - RSS feed: $source
 - date published: 2024-10-20T13:13:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7yefa/xi_jinping_asks_troops_to_prepare_for_war_as/"> <img src="https://external-preview.redd.it/AvH4tqyNNbTFSvjRezo3Pvv0p3rVqHOhbVtZbheXerw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4333bb34e5b1c6d10babb6ddd263f38d1452241f" alt="Xi Jinping Asks Troops To Prepare For War As Battle Drills Intensify Around Taiwan" title="Xi Jinping Asks Troops To Prepare For War As Battle Drills Intensify Around Taiwan" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/blllrrrrr"> /u/blllrrrrr </a> <br/> <span><a href="https://www.ndtv.com/world-news/xi-jinping-asks-troops-to-prepare-for-war-as-battle-drills-intensify-around-taiwan-6826978">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7yefa/xi_jinping_asks_troops_to_prepare_for_war_as/">[comments]</a></span> </td></tr></table>

## Canada’s fight with India puts spotlight on claims New Delhi is watching Sikhs around the world
 - [https://www.reddit.com/r/worldnews/comments/1g7y9r0/canadas_fight_with_india_puts_spotlight_on_claims](https://www.reddit.com/r/worldnews/comments/1g7y9r0/canadas_fight_with_india_puts_spotlight_on_claims)
 - RSS feed: $source
 - date published: 2024-10-20T13:06:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7y9r0/canadas_fight_with_india_puts_spotlight_on_claims/"> <img src="https://external-preview.redd.it/2mnzHdNWIRyh7WRQaQQJHxC3kG1sPzrw0tXtHao-mEs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8f76daecdc7e98f2ca9eedd70d47c01033df8d09" alt="Canada’s fight with India puts spotlight on claims New Delhi is watching Sikhs around the world" title="Canada’s fight with India puts spotlight on claims New Delhi is watching Sikhs around the world" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yimmy51"> /u/yimmy51 </a> <br/> <span><a href="https://www.thestar.com/news/world/canadas-fight-with-india-puts-spotlight-on-claims-new-delhi-is-watching-sikhs-around-the/article_6522a3b4-8c89-11ef-8abf-db9eccd451aa.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7y9r0/canadas_fight_with_india_puts_spotlight_on_claims/">[comments]</a></span> </td></tr></table

## North Korea Threatens To Declare War With South Korea
 - [https://www.reddit.com/r/worldnews/comments/1g7y7fp/north_korea_threatens_to_declare_war_with_south](https://www.reddit.com/r/worldnews/comments/1g7y7fp/north_korea_threatens_to_declare_war_with_south)
 - RSS feed: $source
 - date published: 2024-10-20T13:03:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7y7fp/north_korea_threatens_to_declare_war_with_south/"> <img src="https://external-preview.redd.it/8SiVc4ZvvawALMIUUY7G8a3ptuIwvwpzZSDu_moBbsY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=706f36099b581b226c797f051df7ef984f529919" alt="North Korea Threatens To Declare War With South Korea" title="North Korea Threatens To Declare War With South Korea" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AdHaunting954"> /u/AdHaunting954 </a> <br/> <span><a href="https://www.newsweek.com/north-korea-south-korea-war-drills-1971637">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7y7fp/north_korea_threatens_to_declare_war_with_south/">[comments]</a></span> </td></tr></table>

## Hoax Bomb Threats Disrupt Air Travel As Over 20 Flights Across 4 Carriers Targeted In 24-Hour Span
 - [https://www.reddit.com/r/worldnews/comments/1g7xw0y/hoax_bomb_threats_disrupt_air_travel_as_over_20](https://www.reddit.com/r/worldnews/comments/1g7xw0y/hoax_bomb_threats_disrupt_air_travel_as_over_20)
 - RSS feed: $source
 - date published: 2024-10-20T12:46:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7xw0y/hoax_bomb_threats_disrupt_air_travel_as_over_20/"> <img src="https://external-preview.redd.it/KMBZ2EjPujyueMworbPki3jgImmmCm54S1782Nuf-Zc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ced644f6d9843a1b66b895dc2af9b80faf919be2" alt="Hoax Bomb Threats Disrupt Air Travel As Over 20 Flights Across 4 Carriers Targeted In 24-Hour Span" title="Hoax Bomb Threats Disrupt Air Travel As Over 20 Flights Across 4 Carriers Targeted In 24-Hour Span" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JKKIDD231"> /u/JKKIDD231 </a> <br/> <span><a href="https://www.news18.com/amp/india/bomb-threat-to-flights-vistara-akasa-airline-airport-authority-alert-october-20-latest-updates-9092516.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7xw0y/hoax_bomb_threats_disrupt_air_travel_as_over_20/">[comments]</a></span> </td></tr></table>

## Leak of Israeli plan to strike Iran in coming days to be investigated by US
 - [https://www.reddit.com/r/worldnews/comments/1g7xas4/leak_of_israeli_plan_to_strike_iran_in_coming](https://www.reddit.com/r/worldnews/comments/1g7xas4/leak_of_israeli_plan_to_strike_iran_in_coming)
 - RSS feed: $source
 - date published: 2024-10-20T12:12:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7xas4/leak_of_israeli_plan_to_strike_iran_in_coming/"> <img src="https://external-preview.redd.it/t97RvYplsnts-02rOUP0GLgaoQsuaveTuWV5B4uKTNs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4d18583bbdc54042242e0211b0286588ec58aa16" alt="Leak of Israeli plan to strike Iran in coming days to be investigated by US" title="Leak of Israeli plan to strike Iran in coming days to be investigated by US" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheTelegraph"> /u/TheTelegraph </a> <br/> <span><a href="https://www.telegraph.co.uk/world-news/2024/10/20/leak-israeli-plan-strike-iran-coming-days-investigation/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7xas4/leak_of_israeli_plan_to_strike_iran_in_coming/">[comments]</a></span> </td></tr></table>

## Ukrainian drones hit Russian key weapons factory 900 km deep into Russia
 - [https://www.reddit.com/r/worldnews/comments/1g7waxh/ukrainian_drones_hit_russian_key_weapons_factory](https://www.reddit.com/r/worldnews/comments/1g7waxh/ukrainian_drones_hit_russian_key_weapons_factory)
 - RSS feed: $source
 - date published: 2024-10-20T11:10:12+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://english.nv.ua/nation/ukrainian-drones-hit-russian-military-plant-900-km-from-the-border-50459917.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7waxh/ukrainian_drones_hit_russian_key_weapons_factory/">[comments]</a></span>

## Explosives plant in Russia hit by Ukrainian Special Forces Drones
 - [https://www.reddit.com/r/worldnews/comments/1g7vgak/explosives_plant_in_russia_hit_by_ukrainian](https://www.reddit.com/r/worldnews/comments/1g7vgak/explosives_plant_in_russia_hit_by_ukrainian)
 - RSS feed: $source
 - date published: 2024-10-20T10:10:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7vgak/explosives_plant_in_russia_hit_by_ukrainian/"> <img src="https://external-preview.redd.it/F-m7axSFy6zarJpi5V4yIoz_LYONCqv-F8N8UAiRDPo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d1d678e7fd4b59952f3fb72f6661545ce90617ba" alt="Explosives plant in Russia hit by Ukrainian Special Forces Drones " title="Explosives plant in Russia hit by Ukrainian Special Forces Drones " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tomorrow509"> /u/tomorrow509 </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/10/20/7480514/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7vgak/explosives_plant_in_russia_hit_by_ukrainian/">[comments]</a></span> </td></tr></table>

## Yazidi woman freed by IDF from Gaza reveals ISIS made them eat babies
 - [https://www.reddit.com/r/worldnews/comments/1g7vcv7/yazidi_woman_freed_by_idf_from_gaza_reveals_isis](https://www.reddit.com/r/worldnews/comments/1g7vcv7/yazidi_woman_freed_by_idf_from_gaza_reveals_isis)
 - RSS feed: $source
 - date published: 2024-10-20T10:03:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7vcv7/yazidi_woman_freed_by_idf_from_gaza_reveals_isis/"> <img src="https://external-preview.redd.it/sF_d46t6YZnn0qSZV54oUJSqI2W9EXm0ACRbwYYDHJ0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=02c32faa71ad698ed475181a1219cce162de7864" alt="Yazidi woman freed by IDF from Gaza reveals ISIS made them eat babies" title="Yazidi woman freed by IDF from Gaza reveals ISIS made them eat babies" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BlitzOrion"> /u/BlitzOrion </a> <br/> <span><a href="https://m.jpost.com/middle-east/article-825066">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7vcv7/yazidi_woman_freed_by_idf_from_gaza_reveals_isis/">[comments]</a></span> </td></tr></table>

## US agrees to contribute up to US$20bn to G7 loan for Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1g7v0lu/us_agrees_to_contribute_up_to_us20bn_to_g7_loan](https://www.reddit.com/r/worldnews/comments/1g7v0lu/us_agrees_to_contribute_up_to_us20bn_to_g7_loan)
 - RSS feed: $source
 - date published: 2024-10-20T09:37:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7v0lu/us_agrees_to_contribute_up_to_us20bn_to_g7_loan/"> <img src="https://external-preview.redd.it/oB_nmWkBwdvRMaZrR2O6fisPAntyai4xiyebvAyVUzg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=64043739c40a1da840fb93bb7b03ef6cdd9a9d85" alt="US agrees to contribute up to US$20bn to G7 loan for Ukraine" title="US agrees to contribute up to US$20bn to G7 loan for Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/eaglemaxie"> /u/eaglemaxie </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/10/20/7480505/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7v0lu/us_agrees_to_contribute_up_to_us20bn_to_g7_loan/">[comments]</a></span> </td></tr></table>

## Moldova votes in election, EU referendum in shadow of alleged Russian meddling
 - [https://www.reddit.com/r/worldnews/comments/1g7utij/moldova_votes_in_election_eu_referendum_in_shadow](https://www.reddit.com/r/worldnews/comments/1g7utij/moldova_votes_in_election_eu_referendum_in_shadow)
 - RSS feed: $source
 - date published: 2024-10-20T09:22:45+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Advanced_Drink_8536"> /u/Advanced_Drink_8536 </a> <br/> <span><a href="https://www.reuters.com/world/europe/moldova-votes-election-eu-referendum-shadow-alleged-russian-meddling-2024-10-20/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7utij/moldova_votes_in_election_eu_referendum_in_shadow/">[comments]</a></span>

## 1 in 7 willing to fight if war breaks out: survey in South Korea
 - [https://www.reddit.com/r/worldnews/comments/1g7tnui/1_in_7_willing_to_fight_if_war_breaks_out_survey](https://www.reddit.com/r/worldnews/comments/1g7tnui/1_in_7_willing_to_fight_if_war_breaks_out_survey)
 - RSS feed: $source
 - date published: 2024-10-20T07:53:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7tnui/1_in_7_willing_to_fight_if_war_breaks_out_survey/"> <img src="https://external-preview.redd.it/TtQeTywNIY0vP6-rVALlkm4Zz4E4hXMDllCCFd4QNqY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bfa5a9f499d8686a7080494afd01389ee9087514" alt="1 in 7 willing to fight if war breaks out: survey in South Korea" title="1 in 7 willing to fight if war breaks out: survey in South Korea" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/michaelbachari"> /u/michaelbachari </a> <br/> <span><a href="https://m.koreaherald.com/view.php?ud=20241018050224">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7tnui/1_in_7_willing_to_fight_if_war_breaks_out_survey/">[comments]</a></span> </td></tr></table>

## ‘Grave mistake,’ says Netanyahu after attempt on his life; Iran alleges Hezbollah behind drone attack
 - [https://www.reddit.com/r/worldnews/comments/1g7r9i8/grave_mistake_says_netanyahu_after_attempt_on_his](https://www.reddit.com/r/worldnews/comments/1g7r9i8/grave_mistake_says_netanyahu_after_attempt_on_his)
 - RSS feed: $source
 - date published: 2024-10-20T04:57:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7r9i8/grave_mistake_says_netanyahu_after_attempt_on_his/"> <img src="https://external-preview.redd.it/c8c5yUfi-hzrnhWxL-rJg_2_Hq5iYFSVHvW5JJSQ-GM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=042a63e8e757bf161f8b670c51b575df820becad" alt="‘Grave mistake,’ says Netanyahu after attempt on his life; Iran alleges Hezbollah behind drone attack" title="‘Grave mistake,’ says Netanyahu after attempt on his life; Iran alleges Hezbollah behind drone attack" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/milktanksadmirer"> /u/milktanksadmirer </a> <br/> <span><a href="https://www.thehindu.com/news/international/israel-netanyahu-assassination-bid-grave-mistake-iran-hezbollah-drone-attack-caesarea/article68773975.ece/amp/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7r9i8/grave_mistake_says_netanyahu_after_attempt_on_his/">[comments]</a></span> </td><

## Delhi chokes as air quality plummets to ‘severe’ category, AQI surpasses 400
 - [https://www.reddit.com/r/worldnews/comments/1g7qz82/delhi_chokes_as_air_quality_plummets_to_severe](https://www.reddit.com/r/worldnews/comments/1g7qz82/delhi_chokes_as_air_quality_plummets_to_severe)
 - RSS feed: $source
 - date published: 2024-10-20T04:38:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7qz82/delhi_chokes_as_air_quality_plummets_to_severe/"> <img src="https://external-preview.redd.it/hJnmo6IYemNcHLPUBZOsEk-G5F6wUz0wqnqMGnS_WxQ.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=772f2747343409cb80c95b0f4966cc1b051e0963" alt="Delhi chokes as air quality plummets to ‘severe’ category, AQI surpasses 400" title="Delhi chokes as air quality plummets to ‘severe’ category, AQI surpasses 400" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Past_Kaleidoscope393"> /u/Past_Kaleidoscope393 </a> <br/> <span><a href="https://www.cnbctv18.com/india/environment/delhi-chokes-as-air-quality-plummets-to-severe-category-aqi-over-400-19495525.htm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7qz82/delhi_chokes_as_air_quality_plummets_to_severe/">[comments]</a></span> </td></tr></table>

## Investigation: Russians carry out systemic terror in occupied part of Kherson Oblast
 - [https://www.reddit.com/r/worldnews/comments/1g7qtg4/investigation_russians_carry_out_systemic_terror](https://www.reddit.com/r/worldnews/comments/1g7qtg4/investigation_russians_carry_out_systemic_terror)
 - RSS feed: $source
 - date published: 2024-10-20T04:27:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7qtg4/investigation_russians_carry_out_systemic_terror/"> <img src="https://external-preview.redd.it/YfCDQm5SUXWynVBBzDcHQzR_heZIzYDSasOQ5J1XUSk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c996abe39f461719eb94ccabc28c1559d1f19bcf" alt="Investigation: Russians carry out systemic terror in occupied part of Kherson Oblast" title="Investigation: Russians carry out systemic terror in occupied part of Kherson Oblast" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BothZookeepergame612"> /u/BothZookeepergame612 </a> <br/> <span><a href="https://kyivindependent.com/investigation-russians-carry-out-systemic-terror-in-occupied-part-of-kherson-oblast/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7qtg4/investigation_russians_carry_out_systemic_terror/">[comments]</a></span> </td></tr></table>

## /r/WorldNews Live Thread: Russian Invasion of Ukraine Day 969, Part 1 (Thread #1116)
 - [https://www.reddit.com/r/worldnews/comments/1g7qfm4/rworldnews_live_thread_russian_invasion_of](https://www.reddit.com/r/worldnews/comments/1g7qfm4/rworldnews_live_thread_russian_invasion_of)
 - RSS feed: $source
 - date published: 2024-10-20T04:02:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7qfm4/rworldnews_live_thread_russian_invasion_of/"> <img src="https://a.thumbs.redditmedia.com/jWqSTFxxKuo9aDK8JeM4yZL4Nb_RTA85H45u1-h63L8.jpg" alt="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 969, Part 1 (Thread #1116)" title="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 969, Part 1 (Thread #1116)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WorldNewsMods"> /u/WorldNewsMods </a> <br/> <span><a href="https://www.reddit.com/live/18hnzysb1elcs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7qfm4/rworldnews_live_thread_russian_invasion_of/">[comments]</a></span> </td></tr></table>

## Israel drops leaflets over Gaza showing Yahya Sinwar’s body and message to Hamas
 - [https://www.reddit.com/r/worldnews/comments/1g7odvm/israel_drops_leaflets_over_gaza_showing_yahya](https://www.reddit.com/r/worldnews/comments/1g7odvm/israel_drops_leaflets_over_gaza_showing_yahya)
 - RSS feed: $source
 - date published: 2024-10-20T02:00:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7odvm/israel_drops_leaflets_over_gaza_showing_yahya/"> <img src="https://external-preview.redd.it/FVUxHboMtHJdN5Q_W61hrKsKRo0Kxr59NI2_PZXsHRU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=acab6a68b0e81aad4e7701996345b67d5d613761" alt="Israel drops leaflets over Gaza showing Yahya Sinwar’s body and message to Hamas" title="Israel drops leaflets over Gaza showing Yahya Sinwar’s body and message to Hamas" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://www.straitstimes.com/world/middle-east/israeli-strikes-kill-32-in-gaza-siege-around-hospitals-tightens-health-officials-say">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7odvm/israel_drops_leaflets_over_gaza_showing_yahya/">[comments]</a></span> </td></tr></table>

## US investigating unauthorized release of classified documents on Israel attack plans
 - [https://www.reddit.com/r/worldnews/comments/1g7o9wu/us_investigating_unauthorized_release_of](https://www.reddit.com/r/worldnews/comments/1g7o9wu/us_investigating_unauthorized_release_of)
 - RSS feed: $source
 - date published: 2024-10-20T01:53:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7o9wu/us_investigating_unauthorized_release_of/"> <img src="https://external-preview.redd.it/fECcw_C0U5aueafqjt3peSYxiqxWEcdjGovjeQmB0J0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f753f9e9823927ac74986f624e874a30d270bbc7" alt="US investigating unauthorized release of classified documents on Israel attack plans" title="US investigating unauthorized release of classified documents on Israel attack plans" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/UsualVisible5512"> /u/UsualVisible5512 </a> <br/> <span><a href="https://apnews.com/article/israel-iran-us-documents-attack-e7e23d09a2f1fc14498e64b38d74576f">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7o9wu/us_investigating_unauthorized_release_of/">[comments]</a></span> </td></tr></table>

## Khamenei insists ‘Hamas is alive,’ and ‘resistance’ goes on, despite Sinwar’s death
 - [https://www.reddit.com/r/worldnews/comments/1g7nt5e/khamenei_insists_hamas_is_alive_and_resistance](https://www.reddit.com/r/worldnews/comments/1g7nt5e/khamenei_insists_hamas_is_alive_and_resistance)
 - RSS feed: $source
 - date published: 2024-10-20T01:27:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7nt5e/khamenei_insists_hamas_is_alive_and_resistance/"> <img src="https://external-preview.redd.it/aOvJFss9Y4WCG6Nr24bq_ElDtsek5JJQAJOWocdtaY8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6ea5f3326dc3e78f5c3567ff176a914f8ac0d4bc" alt="Khamenei insists ‘Hamas is alive,’ and ‘resistance’ goes on, despite Sinwar’s death" title="Khamenei insists ‘Hamas is alive,’ and ‘resistance’ goes on, despite Sinwar’s death" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Saltedline"> /u/Saltedline </a> <br/> <span><a href="https://www.timesofisrael.com/irans-supreme-leader-vows-hamas-is-alive-despite-sinwars-death/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7nt5e/khamenei_insists_hamas_is_alive_and_resistance/">[comments]</a></span> </td></tr></table>

## Ukraine signs air defence agreement with Germany, four more countries to join
 - [https://www.reddit.com/r/worldnews/comments/1g7msh2/ukraine_signs_air_defence_agreement_with_germany](https://www.reddit.com/r/worldnews/comments/1g7msh2/ukraine_signs_air_defence_agreement_with_germany)
 - RSS feed: $source
 - date published: 2024-10-20T00:30:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1g7msh2/ukraine_signs_air_defence_agreement_with_germany/"> <img src="https://external-preview.redd.it/c6Rze269oKpuUrBomjW_SeOjF_IwvzIUQ3xMr7z-tIM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e3f56687330c926ed80ac7dce5ceaf99d9c5f443" alt="Ukraine signs air defence agreement with Germany, four more countries to join" title="Ukraine signs air defence agreement with Germany, four more countries to join" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/10/19/7480477/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1g7msh2/ukraine_signs_air_defence_agreement_with_germany/">[comments]</a></span> </td></tr></table>

