# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Tucker Carlson’s Mind Blown As Guest Drops Terrifying Health Data
 - [https://www.youtube.com/watch?v=UrXeUr0ZmhA](https://www.youtube.com/watch?v=UrXeUr0ZmhA)
 - RSS feed: $source
 - date published: 2024-10-20T20:00:18+00:00

Order today at http://www.1775coffee.com/BRAND - code BRAND to save 15% off your order

Watch my new Locals series 'The Oracles' here: https://russellbrand.locals.com/upost/6159441/the-last-pandemic-and-the-next-pandemic

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Watch my exclusive LIVE weekly special, “Break Bread”, get access to all of my interviews a week early, send in questions for me to respond to with guests, and more HERE: https://bit.ly/joinlocals

All links: https://linktr.ee/RussellBrand

## “They’re Trying To DE-NATIONALISE The US Population! Col. Douglas Macgregor On The Border Crisis
 - [https://www.youtube.com/watch?v=_svubfy57yg](https://www.youtube.com/watch?v=_svubfy57yg)
 - RSS feed: $source
 - date published: 2024-10-20T17:08:24+00:00

Go to http://rumble.com/premium/brand and use code BRAND to save $10 off!

Watch my new Locals series 'The Oracles' here: https://russellbrand.locals.com/upost/6159441/the-last-pandemic-and-the-next-pandemic

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Watch my exclusive LIVE weekly special, “Break Bread”, get access to all of my interviews a week early, send in questions for me to respond to with guests, and more HERE: https://bit.ly/joinlocals

All links: https://linktr.ee/RussellBrand

