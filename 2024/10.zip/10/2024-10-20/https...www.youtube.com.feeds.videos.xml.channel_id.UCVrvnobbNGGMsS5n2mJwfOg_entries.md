# Source:FunForLouis, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCVrvnobbNGGMsS5n2mJwfOg, language:en-US

## Building a Solar Powered Boat - Infinite Range
 - [https://www.youtube.com/watch?v=mDdrL_Zb9N8](https://www.youtube.com/watch?v=mDdrL_Zb9N8)
 - RSS feed: $source
 - date published: 2024-10-20T16:46:52+00:00

If you want to chat about buying my van email me here
voltswagonsale@gmail.com

Go follow Kira and Brett at Solar Rolla
https://www.youtube.com/@UCFxsrz7GsBj053Bl8KLMkQg 
http://www.instagram.com/solarrolla
http://www.tiktok.com/@solarrolla
https://solarrolla.com/

Please support us on Patreon... https://bit.ly/RayaandLouisPatreon

Our couples channel
https://www.youtube.com/rayaandlouis

thanks to Beth & Jamarl for editing
https://www.youtube.com/c/BethandJamarl

follow what I'm up to
http://www.instagram.com/louiscole
http://www.tiktok.com/@funforlouis
http://www.twitter.com/louiscole
http://www.facebook.com/louiscole

Make sure you subscribe for New Videos! http://www.youtube.com/subscription_center?add_user=funforlouis

Big thanks to the Music by
https://soundcloud.com/conoralbert
Epidemic Sound (unlimited copyright free music) http://share.epidemicsound.com/qcWWh

Music wanted!!
If you are a music producer and would like me to use your music (funky jazz hiphop vibes) please email

