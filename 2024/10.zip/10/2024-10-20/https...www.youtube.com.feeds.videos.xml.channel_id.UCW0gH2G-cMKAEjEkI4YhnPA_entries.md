# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Lord of the Rings: The War of the Rohirrim NYCC 2024 Interviews!
 - [https://www.youtube.com/watch?v=OESHLPv4pOg](https://www.youtube.com/watch?v=OESHLPv4pOg)
 - RSS feed: $source
 - date published: 2024-10-20T19:15:00+00:00

After the panel for The Lord of the Rings: The War of the Rohirrim, I was able to chat with some of the filmmakers to discuss this new Middle-earth film! We chat about bringing Tolkien to anime, Peter Jackson's reaction to the film, and whether we could get an Extended Edition!

Philippa Boyens (producer)
Phoebe Gittins (writer)
Arty Papageorgiou (writer)
Jason DeMarco (producer)
Luke Pasqualino (“Wulf”)
Gaia Wise (“Héra”)
Kenji Kamiyama (director)
Joseph Chou (producer)

#lordoftherings #waroftherohirrim #tolkien

