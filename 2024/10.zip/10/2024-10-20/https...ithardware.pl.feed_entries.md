# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## iPhone 17 w przeciekach. Co wiemy już o nowej generacji smartfonów Apple?
 - [https://ithardware.pl/aktualnosci/iphone_17_w_przeciekach_co_wiemy_juz_o_nowej_generacji_smartfonow_apple-35928.html](https://ithardware.pl/aktualnosci/iphone_17_w_przeciekach_co_wiemy_juz_o_nowej_generacji_smartfonow_apple-35928.html)
 - RSS feed: $source
 - date published: 2024-10-20T22:40:00.483404+00:00

 <img src="https://ithardware.pl/artykuly/min/35928_1.jpg">            Za nami premiera iPhone 16, więc można już skupić się na przyszłorocznej generacji smartfon&oacute;w Apple. Co takiego zaoferuje iPhone 17? Na rewolucję się niestety nie zanosi, ale może czekać nas większa ewolucja.

iPhone 17 Air

W...
            

## Windows 11 poważnie zagraża użytkownikom. W co piątym przypadku nawet śmiercią
 - [https://ithardware.pl/aktualnosci/microsoft_windows_11_copilot_porady_medyczne-35929.html](https://ithardware.pl/aktualnosci/microsoft_windows_11_copilot_porady_medyczne-35929.html)
 - RSS feed: $source
 - date published: 2024-10-20T20:30:47.194548+00:00

 <img src="https://ithardware.pl/artykuly/min/35929_1.jpg">            Wbudowany w system Windows 11 chatbot Copilot potrafi być przydatny, ale lepiej nie pytać go o sprawy medyczne. Taki wniosek płynie z badania opublikowanego w naukowym czasopiśmie&nbsp;BMJ&nbsp;Quality&nbsp;&amp;&nbsp;Safety.

Chatboty AI robią...
            

## Windows 11 nie będzie gorszy niż macOS. Też dostanie dedykowany pakiet narzędzi AI
 - [https://ithardware.pl/aktualnosci/windows_intelligence_microsoft_win_11-35927.html](https://ithardware.pl/aktualnosci/windows_intelligence_microsoft_win_11-35927.html)
 - RSS feed: $source
 - date published: 2024-10-20T18:58:36.885419+00:00

 <img src="https://ithardware.pl/artykuly/min/35927_1.jpg">            Microsoft zamierza wprowadzić nowości bazujące na sztucznej inteligencji dla Windowsa 11 pod nazwą&nbsp;Windows Intelligence. Szykuje się odpowiedź na Apple Intelligence?

Narzędzia AI już teraz znajdziemy w Windowsie 11, ale Microsoft nie...
            

## Pogrom w Call of Duty. Tysiące uczciwych graczy dostało bany przez głupi błąd
 - [https://ithardware.pl/aktualnosci/call_of_duty_anticheat_ricochet_bany-35926.html](https://ithardware.pl/aktualnosci/call_of_duty_anticheat_ricochet_bany-35926.html)
 - RSS feed: $source
 - date published: 2024-10-20T17:53:50.202824+00:00

 <img src="https://ithardware.pl/artykuly/min/35926_1.jpg">            Cheaterzy stanowią wyzwanie dla tw&oacute;rc&oacute;w oraz graczy i chociaż ciężko ich wszystkich skutecznie wyeliminować z gier online, to stosowane są r&oacute;żne zabezpieczenia, by zmniejszyć ich ilość. Najgorzej gdy zabezpieczenie...
            

## iPhone, którego Polak kupi za jedną wypłatę nadchodzi. Tak może wyglądać
 - [https://ithardware.pl/aktualnosci/apple_iphone_se_4_wyglad-35925.html](https://ithardware.pl/aktualnosci/apple_iphone_se_4_wyglad-35925.html)
 - RSS feed: $source
 - date published: 2024-10-20T13:40:21.257011+00:00

 <img src="https://ithardware.pl/artykuly/min/35925_1.jpg">            iPhone SE 4 zn&oacute;w stał się bohaterem spekulacji na temat wyglądu. W sieci udostępnione zostało nagranie przedstawiające atrapę tego urządzenia. Co ciekawe na filmiku pojawiła się także wersja Plus.



iPhone SE 4 to smartfon,...
            

## Policja rozbiła gang handlujący podróbkami Apple. Przejęto sprzęt o wartości 700 tys. zł
 - [https://ithardware.pl/aktualnosci/policja_irlandia_apple_iphone_podrobki-35924.html](https://ithardware.pl/aktualnosci/policja_irlandia_apple_iphone_podrobki-35924.html)
 - RSS feed: $source
 - date published: 2024-10-20T12:35:14.343704+00:00

 <img src="https://ithardware.pl/artykuly/min/35924_1.jpg">            W Irlandii zidentyfikowano miejsca związane ze sprzedażą podrobionych urządzeń Apple. Tamtejsza policja zatrzymała około 800 fałszywych produkt&oacute;w. Wartość tych przedmiot&oacute;w oszacowano na blisko 700 tysięcy...
            

## Monitor dosłownie poprosił o zgodę. Użytkownik zwraca uwagę na alarmujący trend
 - [https://ithardware.pl/aktualnosci/monitor_smart_sledzenie_reklamy_telemetria-35923.html](https://ithardware.pl/aktualnosci/monitor_smart_sledzenie_reklamy_telemetria-35923.html)
 - RSS feed: $source
 - date published: 2024-10-20T11:30:15.901703+00:00

 <img src="https://ithardware.pl/artykuly/min/35923_1.jpg">            Komputery, smartfony, telewizory, a nawet &quot;zwykłe&quot;&nbsp;monitory zbierają dane na temat treści jakie są oglądane przez użytkownik&oacute;w. Wszystko po to by p&oacute;źniej m&oacute;c na podstawie zebranych danych tworzyć dostosowane...
            

## Mapy Google nagminnie wprowadzają Polaków w błąd. Pogotowie wydaje ostrzeżenie
 - [https://ithardware.pl/aktualnosci/mapy_google_tatry_topr_ostrzezenie-35922.html](https://ithardware.pl/aktualnosci/mapy_google_tatry_topr_ostrzezenie-35922.html)
 - RSS feed: $source
 - date published: 2024-10-20T10:25:07.838240+00:00

 <img src="https://ithardware.pl/artykuly/min/35922_1.jpg">            Mapy Google to niezwykle przydatne w podr&oacute;ży narzędzie, ale nie jest pozbawione wad. Aplikacja ma mylić turyst&oacute;w w g&oacute;rach, o czym alarmuje&nbsp;Tatrzańskie Ochotnicze Pogotowie Ratunkowe.

TOPR wskazuje, iż Mapy Google powinny...
            

## Uśpione zagrożenie: pracownicy IT z Korei Północnej
 - [https://ithardware.pl/aktualnosci/pracownicy_it_z_korea_polnocna_ransomware-35920.html](https://ithardware.pl/aktualnosci/pracownicy_it_z_korea_polnocna_ransomware-35920.html)
 - RSS feed: $source
 - date published: 2024-10-20T09:20:11.380052+00:00

 <img src="https://ithardware.pl/artykuly/min/35920_1.jpg">            Pracownicy z Korei P&oacute;łnocnej, zatrudniani w zachodnich firmach IT pod fałszywymi tożsamościami, nie tylko kradną własność intelektualną, ale także zaczynają żądać okupu w zamian za jej nieujawnianie. To nowa forma atak&oacute;w...
            

## Bloober Team ujawnia wymagania sprzętowe Cronos: The New Dawn
 - [https://ithardware.pl/aktualnosci/bloober_team_cronos_the_new_dawn_wymagania-35917.html](https://ithardware.pl/aktualnosci/bloober_team_cronos_the_new_dawn_wymagania-35917.html)
 - RSS feed: $source
 - date published: 2024-10-20T09:20:11.285506+00:00

 <img src="https://ithardware.pl/artykuly/min/35917_1.jpg">            Bloober Team podał&nbsp;na Steam wymagania sprzętowe&nbsp;Cronos: The New Dawn. Jak się okazuje będą one wyższe&nbsp;od Silent Hill 2 Remake. Obecnie nie wiadomo, do jakiej rozdzielczości i detali zostały przygotowane.

Według wymagań...
            

## Rekord świata? Google zapłaciło 2,7 mld dolarów za pracownika
 - [https://ithardware.pl/aktualnosci/rekordowy_transfer_google_sciaga_do_siebie_pioniera_ai-35918.html](https://ithardware.pl/aktualnosci/rekordowy_transfer_google_sciaga_do_siebie_pioniera_ai-35918.html)
 - RSS feed: $source
 - date published: 2024-10-20T08:15:08.381156+00:00

 <img src="https://ithardware.pl/artykuly/min/35918_1.jpg">            Google sięgnęło głęboko do swojego portfela i wstrząsnęło branżą technologiczną, wydając 2,7 miliarda dolar&oacute;w na ponowne zatrudnienie Noama Shazeera, pioniera sztucznej inteligencji i byłego pracownika firmy.

Choć oficjalnie...
            

## Koniec gotówki w Polsce? Dane NBP nie pozostawiają złudzeń
 - [https://ithardware.pl/aktualnosci/banknot_100_zlotych_nbp_rekord_gotowka-35919.html](https://ithardware.pl/aktualnosci/banknot_100_zlotych_nbp_rekord_gotowka-35919.html)
 - RSS feed: $source
 - date published: 2024-10-20T08:15:08.138192+00:00

 <img src="https://ithardware.pl/artykuly/min/35919_1.jpg">            Narodowy Bank Polski (NBP) opublikował najnowsze dane dotyczące got&oacute;wki będącej w obiegu, kt&oacute;re pokazują, że jej łączna wartość po raz pierwszy w historii przekroczyła 400 miliard&oacute;w złotych. 

W trzecim kwartale 2024...
            

## PlayStation przegrało w sądzie w 15-letniej sprawie. Sami oceńcie, czy słusznie
 - [https://ithardware.pl/aktualnosci/playtation_datel_trybunal_sprawiedliwosci_ue-35921.html](https://ithardware.pl/aktualnosci/playtation_datel_trybunal_sprawiedliwosci_ue-35921.html)
 - RSS feed: $source
 - date published: 2024-10-20T08:15:07.894316+00:00

 <img src="https://ithardware.pl/artykuly/min/35921_1.jpg">            Modyfikacja zawartości pamięci operacyjnej nie stanowi naruszenia praw autorskich &ndash; orzekł TSUE w sporze pomiędzy Sony a brytyjską firmą Datel. Firmy toczyły batalię od niemal 15 lat.

Sp&oacute;r między Sony i Datel sięga 2009 roku i...
            

