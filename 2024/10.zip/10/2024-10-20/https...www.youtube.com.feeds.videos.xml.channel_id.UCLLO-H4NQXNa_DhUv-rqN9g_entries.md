# Source:CD-Action - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## Steam a posiadanie gier
 - [https://www.youtube.com/watch?v=qUZTMi4VfyI](https://www.youtube.com/watch?v=qUZTMi4VfyI)
 - RSS feed: $source
 - date published: 2024-10-20T14:22:05+00:00

00:00 Dzień dobry!
07:03 W co ostatnio graliśmy?
25:42 🚅 CD-Express (newsy ze świata gier)
1:04:02 🪗 Dogrywka (co działo się w grach dokładnie 10 lat temu?)
1:11:29 🎲 A teraz quiz

#steam #xbox #gry

Wesprzyj nas, będziemy turbo wdzięczni + co tydzień dostaniesz pół godziny naszej gadaniny ekstra:
https://www.youtube.com/channel/UCLLO-H4NQXNa_DhUv-rqN9g/join

🚨 Znajdziesz nas na 🚨

YouTube: https://www.youtube.com/playlist?list=PLgIOCkyhQc1XcTKR7tTyRWyFrIff9h-4H
Spotify: https://open.spotify.com/show/7HB6VeV12NEHafy2NyNz62
Apple Podcasts: https://podcasts.apple.com/pl/podcast/cd-action-air/id1682760714?l=pl
Feed RSS do użycia w innych podcastowniach: https://anchor.fm/s/e050e890/podcast/rss

Omawiane newsy:

https://cdaction.pl/newsy/steam-wprowadzil-ostrzezenie-ze-nie-kupujemy-gier-na-wlasnosc-gogcom-wbija-bolesna-szpileczke
https://www.youtube.com/watch?v=mF6rXas66ns
https://cdaction.pl/newsy/bandai-namco-zwalnia-pracownikow-firma-przenosi-ich-do-pomieszczen-w-ktorych-nie-maja-nic-d

