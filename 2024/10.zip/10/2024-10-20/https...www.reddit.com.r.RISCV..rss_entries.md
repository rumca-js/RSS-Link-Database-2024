# Source:The RISC-V Instruction Set Architecture, URL:https://www.reddit.com/r/RISCV/.rss, language:en

## DC Roma Pad II Impressions
 - [https://www.reddit.com/r/RISCV/comments/1g86lo9/dc_roma_pad_ii_impressions](https://www.reddit.com/r/RISCV/comments/1g86lo9/dc_roma_pad_ii_impressions)
 - RSS feed: $source
 - date published: 2024-10-20T19:18:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/RISCV/comments/1g86lo9/dc_roma_pad_ii_impressions/"> <img src="https://b.thumbs.redditmedia.com/yiM3ADLPlB0zfCVV1Y-EgXHZbicXDYmYSckQKHVUHXY.jpg" alt="DC Roma Pad II Impressions " title="DC Roma Pad II Impressions " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I got mine via UPS a couple of days ago. It comes in a nice slim box, with tablet, SIM/SD card release pin, and an SD Card with original OS images. I&#39;m not using a SIM, but I did add an SD Card. This is the 8 GB RAM/128 GB storage model. I also opted to get a keyboard with fold out stand, and with a tablet this size, it works better with the tablet in landscape mode.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/John_from_ne_il"> /u/John_from_ne_il </a> <br/> <span><a href="https://www.reddit.com/gallery/1g86lo9">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/RISCV/comments/1g86lo9/dc_roma_pad_ii_impressions/">[

