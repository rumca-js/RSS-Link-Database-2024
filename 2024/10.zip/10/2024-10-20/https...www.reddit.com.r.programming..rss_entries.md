# Source:programming, URL:https://www.reddit.com/r/programming/.rss, language:

## Vaadin, the battery-included server-side AJAX framework
 - [https://www.reddit.com/r/programming/comments/1g8ar05/vaadin_the_batteryincluded_serverside_ajax](https://www.reddit.com/r/programming/comments/1g8ar05/vaadin_the_batteryincluded_serverside_ajax)
 - RSS feed: $source
 - date published: 2024-10-20T22:21:35+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/bitter-cognac"> /u/bitter-cognac </a> <br/> <span><a href="https://nfrankel.medium.com/vaadin-the-battery-included-server-side-ajax-framework-231492de7907?source=friends_link&amp;sk=4aa2ee11e0bb5f3fd0a48e3ea940a619">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g8ar05/vaadin_the_batteryincluded_serverside_ajax/">[comments]</a></span>

## Introducing AI Assistance in Chrome DevTools
 - [https://www.reddit.com/r/programming/comments/1g870tv/introducing_ai_assistance_in_chrome_devtools](https://www.reddit.com/r/programming/comments/1g870tv/introducing_ai_assistance_in_chrome_devtools)
 - RSS feed: $source
 - date published: 2024-10-20T19:36:29+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/feross"> /u/feross </a> <br/> <span><a href="https://addyosmani.com/blog/ai-assistance/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g870tv/introducing_ai_assistance_in_chrome_devtools/">[comments]</a></span>

## Easy Coin Detection with Python and OpenCV
 - [https://www.reddit.com/r/programming/comments/1g86uxo/easy_coin_detection_with_python_and_opencv](https://www.reddit.com/r/programming/comments/1g86uxo/easy_coin_detection_with_python_and_opencv)
 - RSS feed: $source
 - date published: 2024-10-20T19:29:28+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Feitgemel"> /u/Feitgemel </a> <br/> <span><a href="https://eranfeit.net/easy-coin-detection-with-python-and-opencv/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g86uxo/easy_coin_detection_with_python_and_opencv/">[comments]</a></span>

## The empire of C++ strikes back with Safe C++ blueprint: « After two years of being beaten with the memory-safety stick, the C++ community has published a proposal to help developers write less vulnerable code. »
 - [https://www.reddit.com/r/programming/comments/1g85xbs/the_empire_of_c_strikes_back_with_safe_c](https://www.reddit.com/r/programming/comments/1g85xbs/the_empire_of_c_strikes_back_with_safe_c)
 - RSS feed: $source
 - date published: 2024-10-20T18:49:19+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/fchung"> /u/fchung </a> <br/> <span><a href="https://www.theregister.com/2024/09/16/safe_c_plusplus/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g85xbs/the_empire_of_c_strikes_back_with_safe_c/">[comments]</a></span>

## Summary of the AJAX frameworks comparison
 - [https://www.reddit.com/r/programming/comments/1g85ume/summary_of_the_ajax_frameworks_comparison](https://www.reddit.com/r/programming/comments/1g85ume/summary_of_the_ajax_frameworks_comparison)
 - RSS feed: $source
 - date published: 2024-10-20T18:46:09+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/nfrankel"> /u/nfrankel </a> <br/> <span><a href="https://blog.frankel.ch/ajax-ssr/7/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g85ume/summary_of_the_ajax_frameworks_comparison/">[comments]</a></span>

## Don’t Start Coding Yet: The best software engineers learn first about Parkinson's law, artificial deadlines and working backward plans
 - [https://www.reddit.com/r/programming/comments/1g85i32/dont_start_coding_yet_the_best_software_engineers](https://www.reddit.com/r/programming/comments/1g85i32/dont_start_coding_yet_the_best_software_engineers)
 - RSS feed: $source
 - date published: 2024-10-20T18:31:28+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/strategizeyourcareer"> /u/strategizeyourcareer </a> <br/> <span><a href="https://strategizeyourcareer.com/p/dont-start-coding-yet-heres-what-great-engineers-do-first">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g85i32/dont_start_coding_yet_the_best_software_engineers/">[comments]</a></span>

## This week's JavaScript news: JS might split into 2 languages, Node.js 23, Next.js 15 RC2, and more.
 - [https://www.reddit.com/r/programming/comments/1g83j79/this_weeks_javascript_news_js_might_split_into_2](https://www.reddit.com/r/programming/comments/1g83j79/this_weeks_javascript_news_js_might_split_into_2)
 - RSS feed: $source
 - date published: 2024-10-20T17:06:38+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/ThisWeekinJavaScript"> /u/ThisWeekinJavaScript </a> <br/> <span><a href="https://thisweekinjavascript.com/p/javascript-js0jssugar-proposals-nodejs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g83j79/this_weeks_javascript_news_js_might_split_into_2/">[comments]</a></span>

## How to do distributed locking (2016)
 - [https://www.reddit.com/r/programming/comments/1g83a6s/how_to_do_distributed_locking_2016](https://www.reddit.com/r/programming/comments/1g83a6s/how_to_do_distributed_locking_2016)
 - RSS feed: $source
 - date published: 2024-10-20T16:56:00+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/yusufaytas"> /u/yusufaytas </a> <br/> <span><a href="https://martin.kleppmann.com/2016/02/08/how-to-do-distributed-locking.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g83a6s/how_to_do_distributed_locking_2016/">[comments]</a></span>

## Boilerplate: Video server using go-lang
 - [https://www.reddit.com/r/programming/comments/1g835tz/boilerplate_video_server_using_golang](https://www.reddit.com/r/programming/comments/1g835tz/boilerplate_video_server_using_golang)
 - RSS feed: $source
 - date published: 2024-10-20T16:50:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Sensitive_Ad8262"> /u/Sensitive_Ad8262 </a> <br/> <span><a href="https://github.com/nicolassps/go-video-server">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g835tz/boilerplate_video_server_using_golang/">[comments]</a></span>

## How to use engineering metrics for the success of engineers and teams
 - [https://www.reddit.com/r/programming/comments/1g82963/how_to_use_engineering_metrics_for_the_success_of](https://www.reddit.com/r/programming/comments/1g82963/how_to_use_engineering_metrics_for_the_success_of)
 - RSS feed: $source
 - date published: 2024-10-20T16:11:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/gregorojstersek"> /u/gregorojstersek </a> <br/> <span><a href="https://newsletter.eng-leadership.com/p/how-to-use-engineering-metrics-for">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g82963/how_to_use_engineering_metrics_for_the_success_of/">[comments]</a></span>

## Software Engineer Titles Have (Almost) Lost All Their Meaning
 - [https://www.reddit.com/r/programming/comments/1g823xn/software_engineer_titles_have_almost_lost_all](https://www.reddit.com/r/programming/comments/1g823xn/software_engineer_titles_have_almost_lost_all)
 - RSS feed: $source
 - date published: 2024-10-20T16:05:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/suckaturdnow"> /u/suckaturdnow </a> <br/> <span><a href="https://www.trevorlasn.com/blog/software-engineer-titles-have-almost-lost-all-their-meaning">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g823xn/software_engineer_titles_have_almost_lost_all/">[comments]</a></span>

## 3 Steps for a Successful Software Migration Plan from a System Design Expert
 - [https://www.reddit.com/r/programming/comments/1g81ql9/3_steps_for_a_successful_software_migration_plan](https://www.reddit.com/r/programming/comments/1g81ql9/3_steps_for_a_successful_software_migration_plan)
 - RSS feed: $source
 - date published: 2024-10-20T15:49:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/xxjcutlerxx"> /u/xxjcutlerxx </a> <br/> <span><a href="https://read.highgrowthengineer.com/p/3-steps-for-a-successful-migration">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g81ql9/3_steps_for_a_successful_software_migration_plan/">[comments]</a></span>

## SMURF: Beyond the Test Pyramid
 - [https://www.reddit.com/r/programming/comments/1g7z90g/smurf_beyond_the_test_pyramid](https://www.reddit.com/r/programming/comments/1g7z90g/smurf_beyond_the_test_pyramid)
 - RSS feed: $source
 - date published: 2024-10-20T13:55:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/codingindoc"> /u/codingindoc </a> <br/> <span><a href="https://testing.googleblog.com/2024/10/smurf-beyond-test-pyramid.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7z90g/smurf_beyond_the_test_pyramid/">[comments]</a></span>

## Meta's Llama 3.2: The AI That Does It All!
 - [https://www.reddit.com/r/programming/comments/1g7ywwp/metas_llama_32_the_ai_that_does_it_all](https://www.reddit.com/r/programming/comments/1g7ywwp/metas_llama_32_the_ai_that_does_it_all)
 - RSS feed: $source
 - date published: 2024-10-20T13:38:51+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Wise-Assignment1478"> /u/Wise-Assignment1478 </a> <br/> <span><a href="https://youtu.be/iGMUOWH0fmY">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7ywwp/metas_llama_32_the_ai_that_does_it_all/">[comments]</a></span>

## REST APIs Turn 25: How They Came To Be and What Could Be Next
 - [https://www.reddit.com/r/programming/comments/1g7yi6i/rest_apis_turn_25_how_they_came_to_be_and_what](https://www.reddit.com/r/programming/comments/1g7yi6i/rest_apis_turn_25_how_they_came_to_be_and_what)
 - RSS feed: $source
 - date published: 2024-10-20T13:18:22+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/shrsv"> /u/shrsv </a> <br/> <span><a href="https://journal.hexmos.com/rest-turns-25/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7yi6i/rest_apis_turn_25_how_they_came_to_be_and_what/">[comments]</a></span>

## How to Learn Python the Lazy Way - KDnuggets
 - [https://www.reddit.com/r/programming/comments/1g7y7o4/how_to_learn_python_the_lazy_way_kdnuggets](https://www.reddit.com/r/programming/comments/1g7y7o4/how_to_learn_python_the_lazy_way_kdnuggets)
 - RSS feed: $source
 - date published: 2024-10-20T13:03:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/kingabzpro"> /u/kingabzpro </a> <br/> <span><a href="https://www.kdnuggets.com/how-to-learn-python-the-lazy-way">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7y7o4/how_to_learn_python_the_lazy_way_kdnuggets/">[comments]</a></span>

## How to Represent Single-Variable Functions Using Functional Graphs
 - [https://www.reddit.com/r/programming/comments/1g7y127/how_to_represent_singlevariable_functions_using](https://www.reddit.com/r/programming/comments/1g7y127/how_to_represent_singlevariable_functions_using)
 - RSS feed: $source
 - date published: 2024-10-20T12:53:57+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/albeXL"> /u/albeXL </a> <br/> <span><a href="https://albexl.substack.com/p/functional-graphs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7y127/how_to_represent_singlevariable_functions_using/">[comments]</a></span>

## 8 effective debugging strategies to find and fix bugs like a pro
 - [https://www.reddit.com/r/programming/comments/1g7xhhz/8_effective_debugging_strategies_to_find_and_fix](https://www.reddit.com/r/programming/comments/1g7xhhz/8_effective_debugging_strategies_to_find_and_fix)
 - RSS feed: $source
 - date published: 2024-10-20T12:23:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/pepincho"> /u/pepincho </a> <br/> <span><a href="https://thetshaped.dev/p/8-effective-debugging-strategies">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7xhhz/8_effective_debugging_strategies_to_find_and_fix/">[comments]</a></span>

## C preprocessor in Python
 - [https://www.reddit.com/r/programming/comments/1g7x2ak/c_preprocessor_in_python](https://www.reddit.com/r/programming/comments/1g7x2ak/c_preprocessor_in_python)
 - RSS feed: $source
 - date published: 2024-10-20T11:59:23+00:00

<!-- SC_OFF --><div class="md"><p>Hi. I&#39;ve made a C language preprocessor in Python. It&#39;s nothing too fancy, but it can be useful if you work with C and need to expand macros in a controlled manner for some special purposes. The main highlight is that the expanded macros retain the original formatting, i.e., the whitespaces are preserved (well, mostly...). Feel free to use it if you want.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/solitary_black_sheep"> /u/solitary_black_sheep </a> <br/> <span><a href="https://github.com/lubomilko/pycpp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7x2ak/c_preprocessor_in_python/">[comments]</a></span>

## Add AI to Your App with Cloudflare Workers – No Headaches!
 - [https://www.reddit.com/r/programming/comments/1g7wmom/add_ai_to_your_app_with_cloudflare_workers_no](https://www.reddit.com/r/programming/comments/1g7wmom/add_ai_to_your_app_with_cloudflare_workers_no)
 - RSS feed: $source
 - date published: 2024-10-20T11:31:37+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Wise-Assignment1478"> /u/Wise-Assignment1478 </a> <br/> <span><a href="https://youtu.be/YsLDFuifH8Y">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7wmom/add_ai_to_your_app_with_cloudflare_workers_no/">[comments]</a></span>

## Think Python always has to be slow? Well think again. Check out this article on methods to achieve near native performance.
 - [https://www.reddit.com/r/programming/comments/1g7w125/think_python_always_has_to_be_slow_well_think](https://www.reddit.com/r/programming/comments/1g7w125/think_python_always_has_to_be_slow_well_think)
 - RSS feed: $source
 - date published: 2024-10-20T10:51:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/davidmezzetti"> /u/davidmezzetti </a> <br/> <span><a href="https://neuml.hashnode.dev/building-an-efficient-sparse-keyword-index-in-python">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7w125/think_python_always_has_to_be_slow_well_think/">[comments]</a></span>

## QUIC is not Quick Enough over Fast Internet
 - [https://www.reddit.com/r/programming/comments/1g7vv66/quic_is_not_quick_enough_over_fast_internet](https://www.reddit.com/r/programming/comments/1g7vv66/quic_is_not_quick_enough_over_fast_internet)
 - RSS feed: $source
 - date published: 2024-10-20T10:40:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/MissionToAfrica"> /u/MissionToAfrica </a> <br/> <span><a href="https://arxiv.org/abs/2310.09423">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7vv66/quic_is_not_quick_enough_over_fast_internet/">[comments]</a></span>

## Searching for and navigating Git commits
 - [https://www.reddit.com/r/programming/comments/1g7vkkr/searching_for_and_navigating_git_commits](https://www.reddit.com/r/programming/comments/1g7vkkr/searching_for_and_navigating_git_commits)
 - RSS feed: $source
 - date published: 2024-10-20T10:18:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/XLEX97"> /u/XLEX97 </a> <br/> <span><a href="https://alexharri.com/blog/searching-and-navigating-git-commits">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7vkkr/searching_for_and_navigating_git_commits/">[comments]</a></span>

## When and Where to Use Pointers in Go
 - [https://www.reddit.com/r/programming/comments/1g7v2p3/when_and_where_to_use_pointers_in_go](https://www.reddit.com/r/programming/comments/1g7v2p3/when_and_where_to_use_pointers_in_go)
 - RSS feed: $source
 - date published: 2024-10-20T09:42:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/stackoverflooooooow"> /u/stackoverflooooooow </a> <br/> <span><a href="https://www.pixelstech.net/article/1651389580-When-and-Where-to-Use-Pointers-in-Go">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7v2p3/when_and_where_to_use_pointers_in_go/">[comments]</a></span>

## Desktop version 2024.10.0 is no longer free software
 - [https://www.reddit.com/r/programming/comments/1g7uwu7/desktop_version_2024100_is_no_longer_free_software](https://www.reddit.com/r/programming/comments/1g7uwu7/desktop_version_2024100_is_no_longer_free_software)
 - RSS feed: $source
 - date published: 2024-10-20T09:29:51+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/pigage145"> /u/pigage145 </a> <br/> <span><a href="https://github.com/bitwarden/clients/issues/11611">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7uwu7/desktop_version_2024100_is_no_longer_free_software/">[comments]</a></span>

## Top JavaScript Tools for Developers
 - [https://www.reddit.com/r/programming/comments/1g7tvot/top_javascript_tools_for_developers](https://www.reddit.com/r/programming/comments/1g7tvot/top_javascript_tools_for_developers)
 - RSS feed: $source
 - date published: 2024-10-20T08:09:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Latter-Dust8587"> /u/Latter-Dust8587 </a> <br/> <span><a href="https://makemychance.com/top-javascript-tools-for-developers/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7tvot/top_javascript_tools_for_developers/">[comments]</a></span>

## Are LLMs Any Good at Ranking People?
 - [https://www.reddit.com/r/programming/comments/1g7s8rl/are_llms_any_good_at_ranking_people](https://www.reddit.com/r/programming/comments/1g7s8rl/are_llms_any_good_at_ranking_people)
 - RSS feed: $source
 - date published: 2024-10-20T06:07:09+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/wilsoniumite"> /u/wilsoniumite </a> <br/> <span><a href="https://wilsoniumite.com/2024/10/18/are-llms-any-good-at-ranking-people/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7s8rl/are_llms_any_good_at_ranking_people/">[comments]</a></span>

## Group for coding learners
 - [https://www.reddit.com/r/programming/comments/1g7rp3a/group_for_coding_learners](https://www.reddit.com/r/programming/comments/1g7rp3a/group_for_coding_learners)
 - RSS feed: $source
 - date published: 2024-10-20T05:27:32+00:00

<!-- SC_OFF --><div class="md"><p>Hey everyone! If you&#39;re learning programming and want a space to share your progress, projects, and meet others just as interested, feel free to join our group, Programming Journey. We chat in English so everyone can join in, and we’re all about supporting each other as we learn and grow.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/marc1an4"> /u/marc1an4 </a> <br/> <span><a href="https://chat.whatsapp.com/KBcHmaEPIN9FZiFKGxppXz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7rp3a/group_for_coding_learners/">[comments]</a></span>

## Mastering Time Management as a Staff SWE
 - [https://www.reddit.com/r/programming/comments/1g7qu62/mastering_time_management_as_a_staff_swe](https://www.reddit.com/r/programming/comments/1g7qu62/mastering_time_management_as_a_staff_swe)
 - RSS feed: $source
 - date published: 2024-10-20T04:28:52+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/musskk"> /u/musskk </a> <br/> <span><a href="https://open.substack.com/pub/thehustlingengineer/p/mastering-time-management-by-a-staff?r=yznlc&amp;utm_medium=ios">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7qu62/mastering_time_management_as_a_staff_swe/">[comments]</a></span>

## Low Down & Dirty Web Developers - Learn Webassembly, the low level language made just for Web Devs
 - [https://www.reddit.com/r/programming/comments/1g7oxrp/low_down_dirty_web_developers_learn_webassembly](https://www.reddit.com/r/programming/comments/1g7oxrp/low_down_dirty_web_developers_learn_webassembly)
 - RSS feed: $source
 - date published: 2024-10-20T02:31:33+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Late_Bowl_9505"> /u/Late_Bowl_9505 </a> <br/> <span><a href="https://youtu.be/2_x1WsGanAo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7oxrp/low_down_dirty_web_developers_learn_webassembly/">[comments]</a></span>

## Bare metal raycaster in x86 assembly by stillwwater -- boots from floppy image
 - [https://www.reddit.com/r/programming/comments/1g7niq9/bare_metal_raycaster_in_x86_assembly_by](https://www.reddit.com/r/programming/comments/1g7niq9/bare_metal_raycaster_in_x86_assembly_by)
 - RSS feed: $source
 - date published: 2024-10-20T01:10:39+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/r_retrohacking_mod2"> /u/r_retrohacking_mod2 </a> <br/> <span><a href="https://github.com/stillwwater/raycaster">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/programming/comments/1g7niq9/bare_metal_raycaster_in_x86_assembly_by/">[comments]</a></span>

