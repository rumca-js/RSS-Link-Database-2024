# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Kto będzie kandydatem PiS na prezydenta? "Do gry wszedł Przemysław Czarnek"
 - [https://tvn24.pl/polska/wybory-prezydenckie-2025-kto-bedzie-kandydatem-do-gry-wszedl-przemyslaw-czarnek-st8144066?source=rss](https://tvn24.pl/polska/wybory-prezydenckie-2025-kto-bedzie-kandydatem-do-gry-wszedl-przemyslaw-czarnek-st8144066?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T20:45:05+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4102019-przemyslaw-czarnek-jaroslaw-kaczynski-ph8144056/alternates/LANDSCAPE_1280" alt="Kto będzie kandydatem PiS na prezydenta? "Do gry wszedł Przemysław Czarnek"" />
    To, kto wystartuje w wyścigu o prezydenturę wciąż pozostaje otwarte. W przypadku PiS realną, choć niecodzienną, opcją są prawybory. - Do tej pory wydawało się, że na czele listy jest trójka kandydatów. Teraz zaczął się liczyć  "ten czwarty" - powiedział w programie "W kuluarach" Konrad Piasecki. Według Arlety Zalewskiej może chodzić o Przemysława Czarnka. 
    
    

## Wirus RSV krąży, dzieci po przeszczepach powinny dostać drogi lek. Czemu nie jest refundowany dla wszystkich?
 - [https://fakty.tvn24.pl/zobacz-fakty/wirus-rsv-krazy-dzieci-po-przeszczepach-powinny-dostac-drogi-lek-czemu-nie-jest-refundowany-dla-wszystkich-st8144041?source=rss](https://fakty.tvn24.pl/zobacz-fakty/wirus-rsv-krazy-dzieci-po-przeszczepach-powinny-dostac-drogi-lek-czemu-nie-jest-refundowany-dla-wszystkich-st8144041?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T19:28:53+00:00


    
    <img src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-9106761-now-000813-ph8144043/alternates/LANDSCAPE_1280" alt="Wirus RSV krąży, dzieci po przeszczepach powinny dostać drogi lek. Czemu nie jest refundowany dla wszystkich?" />
    W tej chwili są skazane na życie w izolatce, a tak być nie musi. Dzieci czekające na przeszczepy lub te już po przeszczepach powinny dostać lek chroniący przed wirusem RSV, ale to koszt kilkudziesięciu tysięcy złotych. Ministerstwo Zdrowia twierdzi, że to lekarze powinni wystąpić o refundację.
    
    

## "Myślę, że prezydent sam się złapał za głowę"
 - [https://tvn24.pl/polska/marcin-kierwinski-o-oredziu-andrzeja-dudy-mysle-ze-prezydent-sam-sie-zlapal-za-glowe-st8143936?source=rss](https://tvn24.pl/polska/marcin-kierwinski-o-oredziu-andrzeja-dudy-mysle-ze-prezydent-sam-sie-zlapal-za-glowe-st8143936?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T18:29:08+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1171720-andrzej-duda-ph8138989/alternates/LANDSCAPE_1280" alt=""Myślę, że prezydent sam się złapał za głowę"" />
    Marcin Mastalerek chyba miał zły dzień i jakoś słabo napisał przemówienie panu prezydentowi. Myślę, że jak pan prezydent Duda zobaczył wieczorne serwisy, to sam się złapał za głowę, jak karykaturalne przemówienie wygłosił - powiedział w "Faktach po Faktach" Marcin Kierwiński (PO), komentując orędzie prezydenta Andrzeja Dudy. 
    
    

## 85-latek jechał autostradą pod prąd
 - [https://tvn24.pl/polska/gliwice-85-latek-jechal-autostrada-pod-prad-zostal-zatrzymany-st8143946?source=rss](https://tvn24.pl/polska/gliwice-85-latek-jechal-autostrada-pod-prad-zostal-zatrzymany-st8143946?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T17:29:52+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5644613-463844265-953848850112347-1149133887133774417-n-ph8143955/alternates/LANDSCAPE_1280" alt="85-latek jechał autostradą pod prąd" />
    Policjanci zatrzymali 85-letniego kierowcę hyundaia, który w Gliwicach pomylił zjazdy i wjechał pod prąd na autostradę A1. W taki sposób dotarł aż do Bytomia. Zatrzymano mu prawo jazdy - podała w niedzielę policja.
    
    

## Gigantyczny park rozrywki powstaje na Pomorzu Zachodnim
 - [https://tvn24.pl/szczecin/brojce-park-rozrywki-hossoland-zmieni-gmine-rolnicza-na-turystyczna-st8129163?source=rss](https://tvn24.pl/szczecin/brojce-park-rozrywki-hossoland-zmieni-gmine-rolnicza-na-turystyczna-st8129163?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T16:15:03+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4057906-park-rozrywki-hossoland-ph8128866/alternates/LANDSCAPE_1280" alt="Gigantyczny park rozrywki powstaje na Pomorzu Zachodnim" />
    W niewielkiej gminie Brojce (Zachodniopomorskie) od dwóch lat trwa budowa parku rozrywki Hossoland. Ma to być jedno z największych tego typu miejsc w Polsce. Zdaniem wójta gminy transformacja rolniczej wsi w turystyczną jest dużym wyzwaniem. Otwarcie nowego parku rozrywki zaplanowano na 31 maja 2025 roku.
    
    

## Eksperci ostrzegali od lat. "Jesteśmy wyspą zombie"
 - [https://tvn24.pl/swiat/blackout-na-kubie-dlaczego-nie-ma-pradu-st8143840?source=rss](https://tvn24.pl/swiat/blackout-na-kubie-dlaczego-nie-ma-pradu-st8143840?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T15:11:09+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5165669-forum-0923710735-ph8143872/alternates/LANDSCAPE_1280" alt="Eksperci ostrzegali od lat. "Jesteśmy wyspą zombie"" />
    Kuba mierzy się z poważnym paraliżem systemu energetycznego. To największa taka awaria od czasu upadku Związku Radzieckiego. - Jesteśmy wyspą zombie, błąkamy się bez celu - powiedział dziennikowi "New York Times" mieszkaniec Hawany. - Jesteśmy na Titanicu, który powoli tonie - dodał.
    
    

## Astronomiczna podróż i przechadzka po ogrodzie z olbrzymimi różami
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-krolewski-ogrod-swiatla-w-muzeum-palacu-krola-jana-iii-w-wilanowie-iluminacja-atrakcje-godziny-wejscia-st8143809?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-krolewski-ogrod-swiatla-w-muzeum-palacu-krola-jana-iii-w-wilanowie-iluminacja-atrakcje-godziny-wejscia-st8143809?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T15:08:47+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2597141-krolewski-ogrod-swiatla-ph8143836/alternates/LANDSCAPE_1280" alt="Astronomiczna podróż i przechadzka po ogrodzie z olbrzymimi różami" />
    W Muzeum Pałacu Króla Jana III w Wilanowie działa już Królewski Ogród Światła. Jednym z motywów ogrodu jest astronomia, stanowiąca nawiązanie do pasji króla Jana III. Historię patrona placówki przybliży też świetlny mapping. W ogrodach nie zabraknie także róż, które w 13 edycji będzie można zobaczyć w wielkim formacie. 
    
    

## Obcokrajowcy "zajmują miejsca na uczelniach medycznych", a płaci "polski podatnik"? Dwie nieprawdy
 - [https://konkret24.tvn24.pl/polska/obcokrajowcy-zajmuja-miejsca-na-uczelniach-medycznych-a-placi-polski-podatnik-dwie-nieprawdy-st8141769?source=rss](https://konkret24.tvn24.pl/polska/obcokrajowcy-zajmuja-miejsca-na-uczelniach-medycznych-a-placi-polski-podatnik-dwie-nieprawdy-st8141769?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T13:08:00+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3434640-obcokrajowcy-zajmuja-miejsca-na-uczelniach-medycznych-i-placi-polski-podatnik-nie-ph8142258/alternates/LANDSCAPE_1280" alt="Obcokrajowcy "zajmują miejsca na uczelniach medycznych", a płaci "polski podatnik"? Dwie nieprawdy" />
    Według popularnego przekazu z mediów społecznościowych miejsca na uczelniach medycznych zostały "pozajmowane przez obcokrajowców, którym studia opłaca polski podatnik". Wyjaśniamy, co to się zgadza.
    
    

## "Zerwali hamulec awaryjny" i zdewastowali pociąg metra. Szuka ich policja 
 - [https://tvn24.pl/tvnwarszawa/bielany/warszawa-uszkodzony-pociag-metra-ktos-namalowal-graffiti-st8143627?source=rss](https://tvn24.pl/tvnwarszawa/bielany/warszawa-uszkodzony-pociag-metra-ktos-namalowal-graffiti-st8143627?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T12:00:07+00:00


    
    <img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7b0mrf-metro-w-warszawie-zdjecie-ilustracyjne-6770679/alternates/LANDSCAPE_1280" alt=""Zerwali hamulec awaryjny" i zdewastowali pociąg metra. Szuka ich policja " />
    Na stacji Stare Bielany wandale uszkodzili pociąg metra - pomalowali go graffiti. Poszukuje ich policja. 
    
    

## Znajdujemy się w słonecznym maksimum. Co przyniosą kolejne miesiące?
 - [https://tvn24.pl/tvnmeteo/nauka/znajdujemy-sie-w-slonecznym-maksimum-co-przyniosa-kolejne-miesiace-st8143578?source=rss](https://tvn24.pl/tvnmeteo/nauka/znajdujemy-sie-w-slonecznym-maksimum-co-przyniosa-kolejne-miesiace-st8143578?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T11:55:20+00:00


    
    <img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5012244-slonce-w-okresie-maksimum-cyklu-sierpien-2024-ph8143743/alternates/LANDSCAPE_1280" alt="Znajdujemy się w słonecznym maksimum. Co przyniosą kolejne miesiące?" />
    Słońce znalazło się w maksimum swojego cyklu. Jak wyjaśnili badacze z NASA i Narodowej Służby Oceaniczno-Atmosferycznej, okres największej aktywności naszej gwiazdy jeszcze się nie kończy. Nadchodzące miesiące mogą przynieść kolejne burze geomagnetyczne i zorze polarne rozświetlające niebo. 
    
    

## Jest decyzja w sprawie aresztu dla kierowcy tira po tragicznym karambolu 
 - [https://tvn24.pl/trojmiasto/gdansk-jest-decyzja-sadu-w-sprawie-aresztu-dla-kierowcy-tira-po-tragicznym-karambolu-pod-gdanskiem-st8143570?source=rss](https://tvn24.pl/trojmiasto/gdansk-jest-decyzja-sadu-w-sprawie-aresztu-dla-kierowcy-tira-po-tragicznym-karambolu-pod-gdanskiem-st8143570?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T09:51:44+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5510482-doprowadzenie-kierowcy-ciezarowki-do-prokuratury-rejonowej-w-pruszczu-gdanskim-ph8143733/alternates/LANDSCAPE_1280" alt="Jest decyzja w sprawie aresztu dla kierowcy tira po tragicznym karambolu " />
    Zarzut spowodowania katastrofy w ruchu lądowym ze skutkiem śmiertelnym usłyszał 37-letni kierowca tira, który na drodze S7 w Borkowie (Pomorskie) spowodował karambol 21 aut. Mężczyzna nie przyznał się do zarzutu i odmówił składania wyjaśnień. Sąd nie przychylił się do wniosku prokuratury o tymczasowy areszt. Zdecydował, że 37-latek będzie pod dozorem policyjnym i siedem razy w tygodniu musi stawiać się we właściwej jednostce policji. Kierowca za pośrednictwem adwokata złożył bliskim ofiar "wyrazy najszczerszego współczucia". 
    
    

## Nowe ustalenia prokuratury po tragicznym karambolu pod Gdańskiem
 - [https://tvn24.pl/trojmiasto/gdansk-nowe-ustalenia-prokuratury-po-tragicznym-karambolu-st8143570?source=rss](https://tvn24.pl/trojmiasto/gdansk-nowe-ustalenia-prokuratury-po-tragicznym-karambolu-st8143570?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T09:51:44+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5221100-karambol-na-s7-ph8142747/alternates/LANDSCAPE_1280" alt="Nowe ustalenia prokuratury po tragicznym karambolu pod Gdańskiem" />
    Nowe ustalenia w sprawie tragicznego wypadku na drodze S7 w Borkowie, gdzie zginęły cztery osoby, a 15 zostało rannych. Zidentyfikowano dwie ofiary, to chłopcy z wieku 7 i 10 lat. W sprawie toczy się śledztwo. W niedzielę kierowca zostanie przesłuchany i usłyszy zarzut. 
    
    

## Wyniki Lotto z 19 października 2024. Jakie liczby padły podczas losowania?
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-19-10-2024-jakie-liczby-padly-podczas-losowania-st8143388?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-19-10-2024-jakie-liczby-padly-podczas-losowania-st8143388?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T06:29:18+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-dnysue-lotto_1997459012-5742813/alternates/LANDSCAPE_1280" alt="Wyniki Lotto z 19 października 2024. Jakie liczby padły podczas losowania?" />
    W sobotę w losowaniu Lotto żaden z graczy nie trafił szóstki. Kumulacja rośnie do ośmiu milionów złotych. Oto wyniki losowania Lotto i Lotto Plus z 19 października 2024 roku.
    
    

## Wypadek w słowackich Tatrach. Nie żyje turysta z Polski
 - [https://tvn24.pl/tvnmeteo/swiat/slowacja-wypadek-w-tatrach-nie-zyje-turysta-z-polski-st8143370?source=rss](https://tvn24.pl/tvnmeteo/swiat/slowacja-wypadek-w-tatrach-nie-zyje-turysta-z-polski-st8143370?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T05:32:27+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4987495-placzliwa-skala-tatry-slowacja-shutterstock-1229094874-ph8143375/alternates/LANDSCAPE_1280" alt="Wypadek w słowackich Tatrach. Nie żyje turysta z Polski" />
    Słowacka Horska Zachranna Sluzba poinformowała w sobotę wieczorem o śmierci 67-letniego Polaka w Tatrach Wysokich. Mężczyzna zasłabł na szlaku pod Rakuską Czubą (słowacka nazwa Velka Svisztovka), uderzył się w głowę i stracił przytomność. Nie udało się go uratować.
    
    

## Nie tylko blackout. W kierunku wysypu nadciąga huragan
 - [https://tvn24.pl/swiat/kuba-chaos-na-ogarnietej-brakiem-pradu-wyspie-nad-ktora-nadciaga-huragan-st8143361?source=rss](https://tvn24.pl/swiat/kuba-chaos-na-ogarnietej-brakiem-pradu-wyspie-nad-ktora-nadciaga-huragan-st8143361?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T05:31:49+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-337474-hawana-przerwa-w-dostawie-pradu-zdjecie-z-18-pazdziernika-ph8143362/alternates/LANDSCAPE_1280" alt="Nie tylko blackout. W kierunku wysypu nadciąga huragan" />
    Na Kubie, na której od piątku występuje paraliż systemu energetycznego, panuje chaos, a władzom pomimo zapowiedzi wznowienia dostaw prądu nie udało się do sobotniego wieczora przywrócić energii elektrycznej. Sytuację Kubańczyków pogorszyć może nadciągający od wschodu nad wyspę huragan Oscar.
    
    

## Ojciec Liama Payne'a pojawił się w hotelu, w którym zginął jego syn
 - [https://tvn24.pl/swiat/liam-payne-byly-muzyk-one-direction-nie-zyje-w-buenos-aires-pojawil-sie-jego-ojciec-geoff-payne-st8143355?source=rss](https://tvn24.pl/swiat/liam-payne-byly-muzyk-one-direction-nie-zyje-w-buenos-aires-pojawil-sie-jego-ojciec-geoff-payne-st8143355?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T05:25:21+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3194251-geoff-payne-wsrod-osob-skladajacych-kwiaty-rzed-hotelem-w-buenos-aires-gdzie-zginal-jego-syn-liam-payne-ph8143357/alternates/LANDSCAPE_1280" alt="Ojciec Liama Payne'a pojawił się w hotelu, w którym zginął jego syn" />
    Ojciec Liama ​​Payne'a, Geoff, pojawił się w hotelu w Buenos Aires, w którym muzyk i były wokalista One Direction zginął w wyniku upadku z balkonu. Agencja Associated Press przekazała, że Geoff Payne udał się do Argentyny, aby zorganizować sprowadzenie ciała syna do Wielkiej Brytanii. 
    
    

## "Dwie ważne decyzje". Liczą głosy 
 - [https://tvn24.pl/swiat/moldawia-wyniki-maia-sandu-na-czele-w-wyscigu-o-prezydenture-st8143347?source=rss](https://tvn24.pl/swiat/moldawia-wyniki-maia-sandu-na-czele-w-wyscigu-o-prezydenture-st8143347?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T04:45:09+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4874758-maia-sandu-zaglosowala-ph8143908/alternates/LANDSCAPE_1280" alt=""Dwie ważne decyzje". Liczą głosy " />
    W Mołdawii odbyły się wybory prezydenckie. Jak przekazała w niedzielę wieczorem Centralna Komisja Wyborcza, urzędująca prezydent Maia Sandu prowadzi z wynikiem 34 procent po przeliczeniu głosów z 24 procent komisji wyborczych. 
    
    

## Średnio pięć egzekucji dziennie. Nie minął miesiąc, stracono tu prawie stu więźniów
 - [https://tvn24.pl/swiat/iran-wykonal-co-najmniej-92-egzekucje-od-poczatku-pazdziernika-st8143333?source=rss](https://tvn24.pl/swiat/iran-wykonal-co-najmniej-92-egzekucje-od-poczatku-pazdziernika-st8143333?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T04:27:49+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9684270-wybory-prezydenckie-w-iranie-ajatollah-ali-chamenei-oddal-glos-2024-r-ph7983035/alternates/LANDSCAPE_1280" alt="Średnio pięć egzekucji dziennie. Nie minął miesiąc, stracono tu prawie stu więźniów" />
    Od początku października w Iranie stracono co najmniej 92 więźniów. To około pięciu egzekucji dziennie. Informację przekazał emigracyjny portal Iran International, powołując się na dane zestawione przez zlokalizowaną w Norwegii organizację Iran Human Rights (IHR). Natomiast Amnesty International zaalarmowała, że wyznaczono datę egzekucji Mohammada Rezy Aziziego, który został aresztowany i skazany na śmierć zanim ukończył 18 lat. 
    
    

## Karambol na S7, wybory w Mołdawii, atak na dom Netanjahu 
 - [https://tvn24.pl/polska/karambol-na-s7-wybory-w-moldawii-atak-na-dom-netanjahu-piec-rzeczy-ktore-warto-wiedziec-w-niedziele-20-pazdziernika-st8143358?source=rss](https://tvn24.pl/polska/karambol-na-s7-wybory-w-moldawii-atak-na-dom-netanjahu-piec-rzeczy-ktore-warto-wiedziec-w-niedziele-20-pazdziernika-st8143358?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T03:22:05+00:00


    
    <img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5931470-karambol-na-s7-ph8142747/alternates/LANDSCAPE_1280" alt="Karambol na S7, wybory w Mołdawii, atak na dom Netanjahu " />
    W miejscowości Borkowo (woj. pomorskie) doszło do karambolu na remontowanym odcinku drogi S7. W wyniku zderzenia 21 pojazdów zginęły cztery osoby, a 15 zostało rannych. Wypuszczony z Libanu dron zaatakował dom premiera Benjamina Netanjahu w Cezarei. W niedzielę odbywają się wybory prezydenckie w Mołdawii. Oto pięć rzeczy, które warto wiedzieć w niedzielę 20 października.
    
    

## Pogoda na dziś - niedziela 20.10. Złota jesień w całym kraju
 - [https://tvn24.pl/tvnmeteo/najnowsze/pogoda-na-dzis-niedziela-20-10-zlota-jesien-w-calym-kraju-st8143313?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/pogoda-na-dzis-niedziela-20-10-zlota-jesien-w-calym-kraju-st8143313?source=rss)
 - RSS feed: $source
 - date published: 2024-10-20T00:00:00+00:00


    
    <img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5168153-slonecznie-ph5473492/alternates/LANDSCAPE_1280" alt="Pogoda na dziś - niedziela 20.10. Złota jesień w całym kraju" />
    W niedzielę ponownie na niebie będzie królować słońce. Synoptycy nigdzie nie zapowiadają opadów. Temperatura osiągnie od 12 do 19 stopni Celsjusza.
    
    

