# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Is the American Dream Alive?
 - [https://www.youtube.com/watch?v=y4cpBkZqh6Q](https://www.youtube.com/watch?v=y4cpBkZqh6Q)
 - RSS feed: $source
 - date published: 2024-10-20T19:00:34+00:00

#SteveBallmer #AmericanDream #BenShapiro

## A no-nonsense numbers approach to immigration?
 - [https://www.youtube.com/watch?v=sf3GrYpn5no](https://www.youtube.com/watch?v=sf3GrYpn5no)
 - RSS feed: $source
 - date published: 2024-10-20T15:00:56+00:00

#SteveBallmer #Immigration #BenShapiro

## Physicians Couldn't Speak Up During Covid...
 - [https://www.youtube.com/watch?v=EqOkb3X5c60](https://www.youtube.com/watch?v=EqOkb3X5c60)
 - RSS feed: $source
 - date published: 2024-10-20T01:00:08+00:00

None

