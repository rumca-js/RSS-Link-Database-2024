# Source:ZDNET, URL:https://www.zdnet.com/news/rss.xml, language:en-US

## Upgrade to Windows 11 Pro for $18 - new low price
 - [https://www.zdnet.com/article/upgrade-to-windows-11-pro-for-18-new-low-price/#ftag=RSSbaffb68](https://www.zdnet.com/article/upgrade-to-windows-11-pro-for-18-new-low-price/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T16:00:17+00:00

Save 90% on a Windows 11 Pro license with this deal for more productivity features to help you get things done.

## Buy a Microsoft Visual Studio Pro license for $30 - the lowest price we've seen
 - [https://www.zdnet.com/article/buy-a-microsoft-visual-studio-pro-license-for-30-the-lowest-price-weve-seen/#ftag=RSSbaffb68](https://www.zdnet.com/article/buy-a-microsoft-visual-studio-pro-license-for-30-the-lowest-price-weve-seen/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T14:00:16+00:00

Code faster and work smarter with a Microsoft Visual Studio Professional 2022 license, now on sale for 93% off.

## One of the best Mini LED TVs I've tested is not made by Samsung or TCL (and it's on sale)
 - [https://www.zdnet.com/home-and-office/home-entertainment/one-of-the-best-mini-led-tvs-ive-tested-is-not-made-by-samsung-or-tcl-and-its-on-sale/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/one-of-the-best-mini-led-tvs-ive-tested-is-not-made-by-samsung-or-tcl-and-its-on-sale/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T12:00:16+00:00

The Hisense U8N is the brand's flagship QLED TV. And if you've been waiting to upgrade your gaming space with a dedicated, high-quality TV, you can save up to $1,000 on it now.

## One of the best Android smartwatches I've tested is not by Samsung or Google
 - [https://www.zdnet.com/article/one-of-the-best-android-smartwatches-ive-tested-is-not-by-samsung-or-google/#ftag=RSSbaffb68](https://www.zdnet.com/article/one-of-the-best-android-smartwatches-ive-tested-is-not-by-samsung-or-google/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T11:30:16+00:00

Most smartwatches last a day or two between charging, but the Mobvoi TicWatch Atlas offers a unique dual display technology that more than doubles the battery life.

## My new favorite iPhone accessory makes shooting professional videos so much easier
 - [https://www.zdnet.com/article/my-new-favorite-iphone-accessory-makes-shooting-professional-videos-so-much-easier/#ftag=RSSbaffb68](https://www.zdnet.com/article/my-new-favorite-iphone-accessory-makes-shooting-professional-videos-so-much-easier/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T11:00:26+00:00

The Lexar Professional Go Portable SSD is compact, easy to use, and reliably fast - making it the perfect companion to the iPhone Pro models.

## One of the most portable projectors I've tested isn't made by Epson and Samsung (and it's on sale)
 - [https://www.zdnet.com/home-and-office/home-entertainment/one-of-the-most-portable-projectors-ive-tested-isnt-made-by-epson-and-samsung-and-its-on-sale/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/one-of-the-most-portable-projectors-ive-tested-isnt-made-by-epson-and-samsung-and-its-on-sale/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T11:00:23+00:00

Want a portable projector that won't break the bank? Anker's Nebula Capsule Air will satisfy both of those needs.

## Get 74% off a Babbel subscription to learn a new language now
 - [https://www.zdnet.com/article/get-74-off-a-babbel-subscription-to-learn-a-new-language-now/#ftag=RSSbaffb68](https://www.zdnet.com/article/get-74-off-a-babbel-subscription-to-learn-a-new-language-now/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T11:00:17+00:00

Save $449 on a Babbel Language Learning subscription and learn 14 new languages with this deal.

## One of my favorite portable power stations is $50 off ahead of Black Friday
 - [https://www.zdnet.com/home-and-office/one-of-my-favorite-portable-power-stations-is-50-off-ahead-of-black-friday/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/one-of-my-favorite-portable-power-stations-is-50-off-ahead-of-black-friday/#ftag=RSSbaffb68)
 - RSS feed: $source
 - date published: 2024-10-20T10:30:16+00:00

The EcoFlow River 2 is a reliable, lightweight power station for when you're on the move, and this is one of the lowest prices we've seen ahead of Black Friday.

