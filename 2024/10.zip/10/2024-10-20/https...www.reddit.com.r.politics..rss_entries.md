# Source:Reddit - Politics, URL:https://www.reddit.com/r/politics/.rss, language:en-US

## McConnell backed Jack Smith, wanted Trump to “pay” for Jan. 6
 - [https://www.reddit.com/r/politics/comments/1g8bas7/mcconnell_backed_jack_smith_wanted_trump_to_pay](https://www.reddit.com/r/politics/comments/1g8bas7/mcconnell_backed_jack_smith_wanted_trump_to_pay)
 - RSS feed: $source
 - date published: 2024-10-20T22:48:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g8bas7/mcconnell_backed_jack_smith_wanted_trump_to_pay/"> <img src="https://external-preview.redd.it/1HodhU9xr4Vr-I2iTB4r1GOLNA-7fAutE6D-_gyJGFc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f94e9fce5100d74a35c9058f2f9945b21f4a9d0a" alt="McConnell backed Jack Smith, wanted Trump to “pay” for Jan. 6" title="McConnell backed Jack Smith, wanted Trump to “pay” for Jan. 6" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HandSack135"> /u/HandSack135 </a> <br/> <span><a href="https://www.axios.com/2024/10/20/mcconnell-trump-jack-smith-jan-6th-indictment">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g8bas7/mcconnell_backed_jack_smith_wanted_trump_to_pay/">[comments]</a></span> </td></tr></table>

## Nancy Pelosi: Trump is 'the enemy within'
 - [https://www.reddit.com/r/politics/comments/1g89pcu/nancy_pelosi_trump_is_the_enemy_within](https://www.reddit.com/r/politics/comments/1g89pcu/nancy_pelosi_trump_is_the_enemy_within)
 - RSS feed: $source
 - date published: 2024-10-20T21:33:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g89pcu/nancy_pelosi_trump_is_the_enemy_within/"> <img src="https://external-preview.redd.it/6YF-H17s0KHktzuuiQxITDhSwRNNVs7h1EuF1gEfweY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d8ad425943e6606ea47b3909fe111cb3890f6819" alt="Nancy Pelosi: Trump is 'the enemy within'" title="Nancy Pelosi: Trump is 'the enemy within'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/aslan_is_on_the_move"> /u/aslan_is_on_the_move </a> <br/> <span><a href="https://www.cnn.com/2024/10/15/Tv/video/amanpour-nancy-pelosi">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g89pcu/nancy_pelosi_trump_is_the_enemy_within/">[comments]</a></span> </td></tr></table>

## As Harris turns 60, Democrats cast Trump as old and ‘unhinged’
 - [https://www.reddit.com/r/politics/comments/1g888rd/as_harris_turns_60_democrats_cast_trump_as_old](https://www.reddit.com/r/politics/comments/1g888rd/as_harris_turns_60_democrats_cast_trump_as_old)
 - RSS feed: $source
 - date published: 2024-10-20T20:29:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g888rd/as_harris_turns_60_democrats_cast_trump_as_old/"> <img src="https://external-preview.redd.it/pZlfZMnGS5sth4f7A6YiiAxIpRaMwebcxbJp62u1KWE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7d9aaff67daaf4d78edd9232b432881207c36765" alt="As Harris turns 60, Democrats cast Trump as old and ‘unhinged’" title="As Harris turns 60, Democrats cast Trump as old and ‘unhinged’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zphotoreddit"> /u/zphotoreddit </a> <br/> <span><a href="https://www.cnn.com/2024/10/20/politics/kamala-harris-birthday-trump-fitness-president/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g888rd/as_harris_turns_60_democrats_cast_trump_as_old/">[comments]</a></span> </td></tr></table>

## Donald Trump Can’t Shake Off Taylor Swift’s Kamala Harris Endorsement
 - [https://www.reddit.com/r/politics/comments/1g85vpr/donald_trump_cant_shake_off_taylor_swifts_kamala](https://www.reddit.com/r/politics/comments/1g85vpr/donald_trump_cant_shake_off_taylor_swifts_kamala)
 - RSS feed: $source
 - date published: 2024-10-20T18:47:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g85vpr/donald_trump_cant_shake_off_taylor_swifts_kamala/"> <img src="https://external-preview.redd.it/jdTtoRDmSh4sycHQOkru6zwCXIyQlL1AtfeQdDeOqNI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5d8b18b8dee154b358a5875f8183b580e715bc52" alt="Donald Trump Can’t Shake Off Taylor Swift’s Kamala Harris Endorsement" title="Donald Trump Can’t Shake Off Taylor Swift’s Kamala Harris Endorsement" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ubcstaffer123"> /u/ubcstaffer123 </a> <br/> <span><a href="https://newrepublic.com/post/187286/donald-trump-cant-shake-off-taylor-swifts-kamala-harris-endorsement">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g85vpr/donald_trump_cant_shake_off_taylor_swifts_kamala/">[comments]</a></span> </td></tr></table>

## Trump Makes Fries at McDonald's in Bizarre Attempt to Troll Harris
 - [https://www.reddit.com/r/politics/comments/1g85gbt/trump_makes_fries_at_mcdonalds_in_bizarre_attempt](https://www.reddit.com/r/politics/comments/1g85gbt/trump_makes_fries_at_mcdonalds_in_bizarre_attempt)
 - RSS feed: $source
 - date published: 2024-10-20T18:29:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g85gbt/trump_makes_fries_at_mcdonalds_in_bizarre_attempt/"> <img src="https://external-preview.redd.it/E3U4osUof1yg6mMsBpk9j2nREUdCJl7Q6dBP9UIy-dg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1d659a7e6b601f0da175e58e917bf17cef5d4c2f" alt="Trump Makes Fries at McDonald's in Bizarre Attempt to Troll Harris" title="Trump Makes Fries at McDonald's in Bizarre Attempt to Troll Harris" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rollingstone"> /u/rollingstone </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-news/trump-mcdonalds-troll-harris-1235138509/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g85gbt/trump_makes_fries_at_mcdonalds_in_bizarre_attempt/">[comments]</a></span> </td></tr></table>

## The Group Translating Project 2025 Into Spanish to Warn Old Latinos About Trump
 - [https://www.reddit.com/r/politics/comments/1g858sc/the_group_translating_project_2025_into_spanish](https://www.reddit.com/r/politics/comments/1g858sc/the_group_translating_project_2025_into_spanish)
 - RSS feed: $source
 - date published: 2024-10-20T18:20:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g858sc/the_group_translating_project_2025_into_spanish/"> <img src="https://external-preview.redd.it/-f4y26iQr4IDWCO-rrKGrSBJzoTXMSbyrtlv1GP3oLM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a7310e2968461f8e3b159e4272ac910d19897848" alt="The Group Translating Project 2025 Into Spanish to Warn Old Latinos About Trump" title="The Group Translating Project 2025 Into Spanish to Warn Old Latinos About Trump" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nyerinup"> /u/nyerinup </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-features/translating-project-2025-spanish-latino-voters-1235137797/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g858sc/the_group_translating_project_2025_into_spanish/">[comments]</a></span> </td></tr></table>

## Musk accused of illegally paying for votes with $US1 million election giveaway
 - [https://www.reddit.com/r/politics/comments/1g84orz/musk_accused_of_illegally_paying_for_votes_with](https://www.reddit.com/r/politics/comments/1g84orz/musk_accused_of_illegally_paying_for_votes_with)
 - RSS feed: $source
 - date published: 2024-10-20T17:56:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g84orz/musk_accused_of_illegally_paying_for_votes_with/"> <img src="https://external-preview.redd.it/lunqQFohJpBAREXExGqCSOtB82Wca2iq_dIbpt_la9c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0bd6ee765ce828e5ec313f10e13cb74923a924e8" alt="Musk accused of illegally paying for votes with $US1 million election giveaway" title="Musk accused of illegally paying for votes with $US1 million election giveaway" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/drtolmn69"> /u/drtolmn69 </a> <br/> <span><a href="https://www.smh.com.au/world/north-america/musk-accused-of-illegally-paying-for-votes-with-us1-million-election-giveaway-20241021-p5kjtp.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g84orz/musk_accused_of_illegally_paying_for_votes_with/">[comments]</a></span> </td></tr></table>

## Shapiro Wants Musk Investigated for Giving Cash to Registered Voters
 - [https://www.reddit.com/r/politics/comments/1g849wy/shapiro_wants_musk_investigated_for_giving_cash](https://www.reddit.com/r/politics/comments/1g849wy/shapiro_wants_musk_investigated_for_giving_cash)
 - RSS feed: $source
 - date published: 2024-10-20T17:39:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g849wy/shapiro_wants_musk_investigated_for_giving_cash/"> <img src="https://external-preview.redd.it/lyjqbLNhG0kq5GvqtpetaLeMHtHnObm1QeJL7ARSXSo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3ba713a4bdbce3a32d17b95f28716408ff932237" alt="Shapiro Wants Musk Investigated for Giving Cash to Registered Voters" title="Shapiro Wants Musk Investigated for Giving Cash to Registered Voters" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rollingstone"> /u/rollingstone </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-news/shapiro-elon-musk-million-cash-giveaway-1235138501/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g849wy/shapiro_wants_musk_investigated_for_giving_cash/">[comments]</a></span> </td></tr></table>

## Trump’s Latest Appearances Are Unhinged, Profane, and Yes, Dangerous | Over a weeklong stretch, the former president went on increasing bizarre tangents, repeated racist lies, and called the insurrection “a day of love.”
 - [https://www.reddit.com/r/politics/comments/1g83yvv/trumps_latest_appearances_are_unhinged_profane](https://www.reddit.com/r/politics/comments/1g83yvv/trumps_latest_appearances_are_unhinged_profane)
 - RSS feed: $source
 - date published: 2024-10-20T17:25:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g83yvv/trumps_latest_appearances_are_unhinged_profane/"> <img src="https://external-preview.redd.it/UUKGJsD8owaTN1SqSD39nPl6G3FIMPljO3NE5OfFDEQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4f37a2a99116734d474bbd0ab92d2e3dbbb309da" alt="Trump’s Latest Appearances Are Unhinged, Profane, and Yes, Dangerous | Over a weeklong stretch, the former president went on increasing bizarre tangents, repeated racist lies, and called the insurrection “a day of love.”" title="Trump’s Latest Appearances Are Unhinged, Profane, and Yes, Dangerous | Over a weeklong stretch, the former president went on increasing bizarre tangents, repeated racist lies, and called the insurrection “a day of love.”" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lotta_love"> /u/lotta_love </a> <br/> <span><a href="https://www.motherjones.com/politics/2024/10/trump-profane-rallies-insults-campaign/">[link]</a></span> &

## Donald Trump's intel chief suspected Putin's "blackmail": Bob Woodward
 - [https://www.reddit.com/r/politics/comments/1g83pf3/donald_trumps_intel_chief_suspected_putins](https://www.reddit.com/r/politics/comments/1g83pf3/donald_trumps_intel_chief_suspected_putins)
 - RSS feed: $source
 - date published: 2024-10-20T17:14:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g83pf3/donald_trumps_intel_chief_suspected_putins/"> <img src="https://external-preview.redd.it/OWsRAjOsuXEvb833LsIP8LWrs2QCgpOvwMjrzRBAJSQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=dda2226f22a5ff066e25d5f6481eb3c1c4696e59" alt="Donald Trump's intel chief suspected Putin's &quot;blackmail&quot;: Bob Woodward" title="Donald Trump's intel chief suspected Putin's &quot;blackmail&quot;: Bob Woodward" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/erbrr"> /u/erbrr </a> <br/> <span><a href="https://www.newsweek.com/donald-trumps-intel-chief-dan-coats-suspected-putins-blackmail-bob-woodward-1971807">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g83pf3/donald_trumps_intel_chief_suspected_putins/">[comments]</a></span> </td></tr></table>

## Trump Names Pelosi and Schiff as ‘the Enemy From Within’
 - [https://www.reddit.com/r/politics/comments/1g83jxp/trump_names_pelosi_and_schiff_as_the_enemy_from](https://www.reddit.com/r/politics/comments/1g83jxp/trump_names_pelosi_and_schiff_as_the_enemy_from)
 - RSS feed: $source
 - date published: 2024-10-20T17:07:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g83jxp/trump_names_pelosi_and_schiff_as_the_enemy_from/"> <img src="https://external-preview.redd.it/2t33H9ut8PI14YrDtYIWNLhCpa-xn3SWURvdyFX4zYc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f2abb17516c7f7d75241496da2bbb8a9c302f01a" alt="Trump Names Pelosi and Schiff as ‘the Enemy From Within’" title="Trump Names Pelosi and Schiff as ‘the Enemy From Within’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rollingstone"> /u/rollingstone </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-news/trump-pelosi-schiff-enemy-from-within-1235138464/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g83jxp/trump_names_pelosi_and_schiff_as_the_enemy_from/">[comments]</a></span> </td></tr></table>

## "Why is he talking about Arnold Palmer's penis?": Tapper grills Johnson on Trump anecdote
 - [https://www.reddit.com/r/politics/comments/1g8394c/why_is_he_talking_about_arnold_palmers_penis](https://www.reddit.com/r/politics/comments/1g8394c/why_is_he_talking_about_arnold_palmers_penis)
 - RSS feed: $source
 - date published: 2024-10-20T16:54:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g8394c/why_is_he_talking_about_arnold_palmers_penis/"> <img src="https://external-preview.redd.it/OB7CKB4IRACNP-BIw9sbymR5IYTNoeViOEDfnukURas.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6417c26156dfd075e9a4f97bffa0f7af049315c5" alt="&quot;Why is he talking about Arnold Palmer's penis?&quot;: Tapper grills Johnson on Trump anecdote" title="&quot;Why is he talking about Arnold Palmer's penis?&quot;: Tapper grills Johnson on Trump anecdote" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br/> <span><a href="https://www.salon.com/2024/10/20/why-is-he-talking-about-arnold-palmers-penis-tapper-grills-johnson-on-anecdote/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g8394c/why_is_he_talking_about_arnold_palmers_penis/">[comments]</a></span> </td></tr></table>

## Shapiro says Musk plan to award $1 million to Pennsylvania voters who sign his petition is ‘deeply concerning’
 - [https://www.reddit.com/r/politics/comments/1g82r3y/shapiro_says_musk_plan_to_award_1_million_to](https://www.reddit.com/r/politics/comments/1g82r3y/shapiro_says_musk_plan_to_award_1_million_to)
 - RSS feed: $source
 - date published: 2024-10-20T16:33:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g82r3y/shapiro_says_musk_plan_to_award_1_million_to/"> <img src="https://external-preview.redd.it/BE_0EajIoiE7TVD10dLZRlhQ7mMvg7KbQp4hajGJJCI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=dfef65e3308cd399a066592efb85da8226ded9d0" alt="Shapiro says Musk plan to award $1 million to Pennsylvania voters who sign his petition is ‘deeply concerning’" title="Shapiro says Musk plan to award $1 million to Pennsylvania voters who sign his petition is ‘deeply concerning’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/UWCG"> /u/UWCG </a> <br/> <span><a href="https://thehill.com/homenews/campaign/4943422-shapiro-says-musk-plan-to-award-1-million-to-pennsylvania-voters-who-sign-his-petition-is-deeply-concerning/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g82r3y/shapiro_says_musk_plan_to_award_1_million_to/">[comments]</a></span> </td></tr></table>

## Endorsement: Colin Allred is the right choice for Texas in the U.S. Senate
 - [https://www.reddit.com/r/politics/comments/1g82ql7/endorsement_colin_allred_is_the_right_choice_for](https://www.reddit.com/r/politics/comments/1g82ql7/endorsement_colin_allred_is_the_right_choice_for)
 - RSS feed: $source
 - date published: 2024-10-20T16:32:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g82ql7/endorsement_colin_allred_is_the_right_choice_for/"> <img src="https://external-preview.redd.it/YNFJHWdPW86v5effj-hXEMwzOk96P6OHz5fEbpr03Nk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=eaac9583497adb21da7056751a662665e67523d0" alt="Endorsement: Colin Allred is the right choice for Texas in the U.S. Senate" title="Endorsement: Colin Allred is the right choice for Texas in the U.S. Senate" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plz-let-me-in"> /u/plz-let-me-in </a> <br/> <span><a href="https://www.statesman.com/story/opinion/editorials/2024/10/20/endorsement-us-senate-race-candidate-colin-allred-texas-election-2024/75263094007/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g82ql7/endorsement_colin_allred_is_the_right_choice_for/">[comments]</a></span> </td></tr></table>

## Mike Johnson: Trump’s Praise for Palmer’s Genitalia Is ‘Fun’
 - [https://www.reddit.com/r/politics/comments/1g81vcc/mike_johnson_trumps_praise_for_palmers_genitalia](https://www.reddit.com/r/politics/comments/1g81vcc/mike_johnson_trumps_praise_for_palmers_genitalia)
 - RSS feed: $source
 - date published: 2024-10-20T15:55:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g81vcc/mike_johnson_trumps_praise_for_palmers_genitalia/"> <img src="https://external-preview.redd.it/L78ljMws0uaKZ7NwtYqJq06AKTrkWJTqG4_-_R7M0MY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5fa40212e01bbafdeba1147b9208af0fc09510c8" alt="Mike Johnson: Trump’s Praise for Palmer’s Genitalia Is ‘Fun’" title="Mike Johnson: Trump’s Praise for Palmer’s Genitalia Is ‘Fun’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheRealOcsiban"> /u/TheRealOcsiban </a> <br/> <span><a href="https://www.thedailybeast.com/mike-johnson-trumps-praise-for-palmers-genitalia-is-fun/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g81vcc/mike_johnson_trumps_praise_for_palmers_genitalia/">[comments]</a></span> </td></tr></table>

## The Star-Ledger Endorsement: Harris over Trump, by a mile
 - [https://www.reddit.com/r/politics/comments/1g81k27/the_starledger_endorsement_harris_over_trump_by_a](https://www.reddit.com/r/politics/comments/1g81k27/the_starledger_endorsement_harris_over_trump_by_a)
 - RSS feed: $source
 - date published: 2024-10-20T15:41:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g81k27/the_starledger_endorsement_harris_over_trump_by_a/"> <img src="https://external-preview.redd.it/en3OJ6zjULuYKh4eCkhNgwbEjH00YTUfUINBHPBHT3w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=399ebcde8420faff2d8803535656beb20467993f" alt="The Star-Ledger Endorsement: Harris over Trump, by a mile" title="The Star-Ledger Endorsement: Harris over Trump, by a mile" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plz-let-me-in"> /u/plz-let-me-in </a> <br/> <span><a href="https://www.nj.com/opinion/2024/10/the-star-ledger-endorsement-harris-over-trump-by-a-mile.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g81k27/the_starledger_endorsement_harris_over_trump_by_a/">[comments]</a></span> </td></tr></table>

## Mike Johnson Doesn’t Want to Hear About Trump Discussing Arnold Palmer’s Manhood
 - [https://www.reddit.com/r/politics/comments/1g81ifq/mike_johnson_doesnt_want_to_hear_about_trump](https://www.reddit.com/r/politics/comments/1g81ifq/mike_johnson_doesnt_want_to_hear_about_trump)
 - RSS feed: $source
 - date published: 2024-10-20T15:39:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g81ifq/mike_johnson_doesnt_want_to_hear_about_trump/"> <img src="https://external-preview.redd.it/tBURVbW3oU7YANCaNhguPO3nD3RcKPLqSO3bd_-1rbA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4fe4e37b43abb7b6aa0ad31ea8c97bfe7ef0baf9" alt="Mike Johnson Doesn’t Want to Hear About Trump Discussing Arnold Palmer’s Manhood" title="Mike Johnson Doesn’t Want to Hear About Trump Discussing Arnold Palmer’s Manhood" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rollingstone"> /u/rollingstone </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-news/mike-johnson-trump-arnold-palmer-manhood-1235138445/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g81ifq/mike_johnson_doesnt_want_to_hear_about_trump/">[comments]</a></span> </td></tr></table>

## Opinion: Trump said so many stupid things this week, I decided to just round them up
 - [https://www.reddit.com/r/politics/comments/1g81972/opinion_trump_said_so_many_stupid_things_this](https://www.reddit.com/r/politics/comments/1g81972/opinion_trump_said_so_many_stupid_things_this)
 - RSS feed: $source
 - date published: 2024-10-20T15:27:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g81972/opinion_trump_said_so_many_stupid_things_this/"> <img src="https://external-preview.redd.it/1cYTm0YlNCEdIb6GDyrchB19L80t4UaCcKFubUyUPKg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e0fdcb0fcb6731bff8e6ffb4a908d219f06293e5" alt="Opinion: Trump said so many stupid things this week, I decided to just round them up" title="Opinion: Trump said so many stupid things this week, I decided to just round them up" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/plz-let-me-in"> /u/plz-let-me-in </a> <br/> <span><a href="https://www.usatoday.com/story/opinion/columnist/2024/10/19/election-trump-lies-immigrants-abortion-record/75719502007/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g81972/opinion_trump_said_so_many_stupid_things_this/">[comments]</a></span> </td></tr></table>

## Man who questioned Trump on pet-eating lies during Univision town hall admits he is now voting for Harris
 - [https://www.reddit.com/r/politics/comments/1g816ja/man_who_questioned_trump_on_peteating_lies_during](https://www.reddit.com/r/politics/comments/1g816ja/man_who_questioned_trump_on_peteating_lies_during)
 - RSS feed: $source
 - date published: 2024-10-20T15:24:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g816ja/man_who_questioned_trump_on_peteating_lies_during/"> <img src="https://external-preview.redd.it/mzqqK81bPUwWpBrqukVUEOHNYcPH977kOvmuqsK3i48.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3b5842edef69608267709a780b1ba010e804f2b0" alt="Man who questioned Trump on pet-eating lies during Univision town hall admits he is now voting for Harris" title="Man who questioned Trump on pet-eating lies during Univision town hall admits he is now voting for Harris" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WhileFalseRepeat"> /u/WhileFalseRepeat </a> <br/> <span><a href="https://www.the-independent.com/news/world/americas/us-politics/trump-town-hall-pet-eating-harris-vote-b2631966.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g816ja/man_who_questioned_trump_on_peteating_lies_during/">[comments]</a></span> </td></tr></table>

## Pennsylvania Gov. Shapiro: Law enforcement should 'take a look at' Elon Musk voter payments
 - [https://www.reddit.com/r/politics/comments/1g80wkc/pennsylvania_gov_shapiro_law_enforcement_should](https://www.reddit.com/r/politics/comments/1g80wkc/pennsylvania_gov_shapiro_law_enforcement_should)
 - RSS feed: $source
 - date published: 2024-10-20T15:11:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g80wkc/pennsylvania_gov_shapiro_law_enforcement_should/"> <img src="https://external-preview.redd.it/pAtyK6aUZmAL8T6ys44j7yEWe8KfeQR1SjIn50e-6B0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bf6738b9bc9d2218dc5c9ab1b715564b2f791410" alt="Pennsylvania Gov. Shapiro: Law enforcement should 'take a look at' Elon Musk voter payments" title="Pennsylvania Gov. Shapiro: Law enforcement should 'take a look at' Elon Musk voter payments" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/soldierofcinema"> /u/soldierofcinema </a> <br/> <span><a href="https://www.nbcnews.com/politics/2024-election/pennsylvania-gov-shapiro-law-enforcement-take-look-elon-musk-voter-pay-rcna176279">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g80wkc/pennsylvania_gov_shapiro_law_enforcement_should/">[comments]</a></span> </td></tr></table>

## Arnold Palmer Was ‘Appalled’ by ‘Crude’ Trump, Who Praised the Late Golfer’s Genitals
 - [https://www.reddit.com/r/politics/comments/1g80kp4/arnold_palmer_was_appalled_by_crude_trump_who](https://www.reddit.com/r/politics/comments/1g80kp4/arnold_palmer_was_appalled_by_crude_trump_who)
 - RSS feed: $source
 - date published: 2024-10-20T14:57:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g80kp4/arnold_palmer_was_appalled_by_crude_trump_who/"> <img src="https://external-preview.redd.it/qb-sfx8TJWIh8gDR6Pqn74Qqe7i4KVVrrIbLgK2v0KI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c8b5cf38d91132bb31239f983481a1c7f425a3ef" alt="Arnold Palmer Was ‘Appalled’ by ‘Crude’ Trump, Who Praised the Late Golfer’s Genitals" title="Arnold Palmer Was ‘Appalled’ by ‘Crude’ Trump, Who Praised the Late Golfer’s Genitals" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Titfortat101"> /u/Titfortat101 </a> <br/> <span><a href="https://www.thedailybeast.com/arnold-palmer-was-appalled-by-crude-trump-who-praised-the-late-golfers-genitals/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g80kp4/arnold_palmer_was_appalled_by_crude_trump_who/">[comments]</a></span> </td></tr></table>

## Elon Musk's ground game for Donald Trump may be backfiring, analysts warn
 - [https://www.reddit.com/r/politics/comments/1g804et/elon_musks_ground_game_for_donald_trump_may_be](https://www.reddit.com/r/politics/comments/1g804et/elon_musks_ground_game_for_donald_trump_may_be)
 - RSS feed: $source
 - date published: 2024-10-20T14:36:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g804et/elon_musks_ground_game_for_donald_trump_may_be/"> <img src="https://external-preview.redd.it/YaAfbTo0iukZNF4SCQjFv8uf4pR186WWs70kEh3uTmQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=752dadd2956efb02f557e8e00b7d4c8d5c196ba7" alt="Elon Musk's ground game for Donald Trump may be backfiring, analysts warn" title="Elon Musk's ground game for Donald Trump may be backfiring, analysts warn" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tun-Tavern-1775"> /u/Tun-Tavern-1775 </a> <br/> <span><a href="https://www.newsweek.com/elon-musk-ground-game-donald-trump-backfiring-pennsylvania-arizona-nevada-1971789">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g804et/elon_musks_ground_game_for_donald_trump_may_be/">[comments]</a></span> </td></tr></table>

## Harris allies fear one major roadblock if she wins: A GOP Senate
 - [https://www.reddit.com/r/politics/comments/1g7zpve/harris_allies_fear_one_major_roadblock_if_she](https://www.reddit.com/r/politics/comments/1g7zpve/harris_allies_fear_one_major_roadblock_if_she)
 - RSS feed: $source
 - date published: 2024-10-20T14:17:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Kashmir75"> /u/Kashmir75 </a> <br/> <span><a href="https://www.politico.com/news/2024/10/20/harris-gop-senate-2024-elections-00184418">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7zpve/harris_allies_fear_one_major_roadblock_if_she/">[comments]</a></span>

## Harris goes to church, highlighting the absence of religion in the 2024 campaign
 - [https://www.reddit.com/r/politics/comments/1g7zj93/harris_goes_to_church_highlighting_the_absence_of](https://www.reddit.com/r/politics/comments/1g7zj93/harris_goes_to_church_highlighting_the_absence_of)
 - RSS feed: $source
 - date published: 2024-10-20T14:08:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7zj93/harris_goes_to_church_highlighting_the_absence_of/"> <img src="https://external-preview.redd.it/o5LJAy6avLbJt3WEAhCSV5Rk19cFLf6fAmd4oPvCW8Y.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=82d7f7a269b97586745f4ff05ed8866de3768826" alt="Harris goes to church, highlighting the absence of religion in the 2024 campaign" title="Harris goes to church, highlighting the absence of religion in the 2024 campaign" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dizzy-Inspection-492"> /u/Dizzy-Inspection-492 </a> <br/> <span><a href="https://www.nbcnews.com/politics/2024-election/harris-goes-church-highlighting-absence-religion-2024-campaign-rcna176045">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7zj93/harris_goes_to_church_highlighting_the_absence_of/">[comments]</a></span> </td></tr></table>

## There Is No Precedent for Something Like This in American History
 - [https://www.reddit.com/r/politics/comments/1g7zb0k/there_is_no_precedent_for_something_like_this_in](https://www.reddit.com/r/politics/comments/1g7zb0k/there_is_no_precedent_for_something_like_this_in)
 - RSS feed: $source
 - date published: 2024-10-20T13:58:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7zb0k/there_is_no_precedent_for_something_like_this_in/"> <img src="https://external-preview.redd.it/4UD5b83bsomYepbGd38EXEF_9z2mc9P3imdQxLl1R3Y.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6fafe28d7a36ab1c88834a62495055607e68f670" alt="There Is No Precedent for Something Like This in American History" title="There Is No Precedent for Something Like This in American History" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dheber"> /u/dheber </a> <br/> <span><a href="https://www.nytimes.com/2024/10/18/opinion/trump-woodward-milley-mass-deportation.html?unlocked_article_code=1.Tk4.rzpE.9tnND3obWzkg&amp;smid=url-share">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7zb0k/there_is_no_precedent_for_something_like_this_in/">[comments]</a></span> </td></tr></table>

## Trump is the old, exhausted candidate afraid to leave his safe space
 - [https://www.reddit.com/r/politics/comments/1g7y6ig/trump_is_the_old_exhausted_candidate_afraid_to](https://www.reddit.com/r/politics/comments/1g7y6ig/trump_is_the_old_exhausted_candidate_afraid_to)
 - RSS feed: $source
 - date published: 2024-10-20T13:01:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7y6ig/trump_is_the_old_exhausted_candidate_afraid_to/"> <img src="https://external-preview.redd.it/S-imSkBGEYDBYfiKCRuAu2Ex3_qmz7J1NW6UwtU1cto.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=534529b05c6c0dae52a6f11ea6e2e02bd1761fd6" alt="Trump is the old, exhausted candidate afraid to leave his safe space" title="Trump is the old, exhausted candidate afraid to leave his safe space" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/etfvfva"> /u/etfvfva </a> <br/> <span><a href="https://www.msnbc.com/ayman-mohyeldin/watch/-trump-is-the-old-exhausted-candidate-afraid-to-leave-his-safe-space-222195269684">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7y6ig/trump_is_the_old_exhausted_candidate_afraid_to/">[comments]</a></span> </td></tr></table>

## The Very Real Scenario Where Trump Loses and Takes Power Anyway
 - [https://www.reddit.com/r/politics/comments/1g7y1af/the_very_real_scenario_where_trump_loses_and](https://www.reddit.com/r/politics/comments/1g7y1af/the_very_real_scenario_where_trump_loses_and)
 - RSS feed: $source
 - date published: 2024-10-20T12:54:17+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Consistent-Force5375"> /u/Consistent-Force5375 </a> <br/> <span><a href="https://www.politico.com/news/magazine/2024/10/20/trump-overturn-2024-election-plan-00184103">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7y1af/the_very_real_scenario_where_trump_loses_and/">[comments]</a></span>

## /r/Politics' 2024 US Elections Live Thread, Part 46
 - [https://www.reddit.com/r/politics/comments/1g7xuc7/rpolitics_2024_us_elections_live_thread_part_46](https://www.reddit.com/r/politics/comments/1g7xuc7/rpolitics_2024_us_elections_live_thread_part_46)
 - RSS feed: $source
 - date published: 2024-10-20T12:44:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7xuc7/rpolitics_2024_us_elections_live_thread_part_46/"> <img src="https://b.thumbs.redditmedia.com/6VVMgGipe7XrGi7CSABeYGc5q-SEcQseXpVVbyKZs6U.jpg" alt="/r/Politics' 2024 US Elections Live Thread, Part 46" title="/r/Politics' 2024 US Elections Live Thread, Part 46" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PoliticsModeratorBot"> /u/PoliticsModeratorBot </a> <br/> <span><a href="https://www.reddit.com/live/1db9knzhqzdfp/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7xuc7/rpolitics_2024_us_elections_live_thread_part_46/">[comments]</a></span> </td></tr></table>

## Trump’s trillion-dollar tax cuts are spiralling out of control
 - [https://www.reddit.com/r/politics/comments/1g7x9y9/trumps_trilliondollar_tax_cuts_are_spiralling_out](https://www.reddit.com/r/politics/comments/1g7x9y9/trumps_trilliondollar_tax_cuts_are_spiralling_out)
 - RSS feed: $source
 - date published: 2024-10-20T12:11:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7x9y9/trumps_trilliondollar_tax_cuts_are_spiralling_out/"> <img src="https://external-preview.redd.it/0dVMqdp7w3OBp3cUkOriVLe1HUufcoLlq0xt9Pjt7ow.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c5ccb20dbd9e9a18354a34637101e60e1c444ca" alt="Trump’s trillion-dollar tax cuts are spiralling out of control" title="Trump’s trillion-dollar tax cuts are spiralling out of control" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dizzy-Inspection-492"> /u/Dizzy-Inspection-492 </a> <br/> <span><a href="https://www.economist.com/finance-and-economics/2024/10/17/trumps-trillion-dollar-tax-cuts-are-spiralling-out-of-control">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7x9y9/trumps_trilliondollar_tax_cuts_are_spiralling_out/">[comments]</a></span> </td></tr></table>

## Statement from President Joe Biden
 - [https://www.reddit.com/r/politics/comments/1g7wv6t/statement_from_president_joe_biden](https://www.reddit.com/r/politics/comments/1g7wv6t/statement_from_president_joe_biden)
 - RSS feed: $source
 - date published: 2024-10-20T11:47:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7wv6t/statement_from_president_joe_biden/"> <img src="https://external-preview.redd.it/D4ApVTqUzlai30E0NQT1Y_RowF1Ep9U50QtDLAsxB34.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=27928d9be45d463a3b4051943a3034a17f93310c" alt="Statement from President Joe Biden " title="Statement from President Joe Biden " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PseudoPatriotsNotPog"> /u/PseudoPatriotsNotPog </a> <br/> <span><a href="https://www.whitehouse.gov/briefing-room/statements-releases/2024/10/19/statement-from-president-joe-biden-9/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7wv6t/statement_from_president_joe_biden/">[comments]</a></span> </td></tr></table>

## Kamala Harris' Fox News appearance should be a lesson for Democrats
 - [https://www.reddit.com/r/politics/comments/1g7wnng/kamala_harris_fox_news_appearance_should_be_a](https://www.reddit.com/r/politics/comments/1g7wnng/kamala_harris_fox_news_appearance_should_be_a)
 - RSS feed: $source
 - date published: 2024-10-20T11:33:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7wnng/kamala_harris_fox_news_appearance_should_be_a/"> <img src="https://external-preview.redd.it/bBJtPIwp_neK_vznQy5m6dvzi_0Z1ww3y8VeF4AK9DM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=37a552927be54354c4609a874d71d01801809e35" alt="Kamala Harris' Fox News appearance should be a lesson for Democrats" title="Kamala Harris' Fox News appearance should be a lesson for Democrats" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/h2002al"> /u/h2002al </a> <br/> <span><a href="https://www.msnbc.com/inside-with-jen-psaki/kamala-harris-fox-news-appearance-lesson-democrats-rcna176151">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7wnng/kamala_harris_fox_news_appearance_should_be_a/">[comments]</a></span> </td></tr></table>

## At a Pennsylvania Rally, Trump Descends to New Levels of Vulgarity | The G.O.P. nominee repeated crude insults, and his supporters relished each moment. But the display could alienate swing voters.
 - [https://www.reddit.com/r/politics/comments/1g7w5ju/at_a_pennsylvania_rally_trump_descends_to_new](https://www.reddit.com/r/politics/comments/1g7w5ju/at_a_pennsylvania_rally_trump_descends_to_new)
 - RSS feed: $source
 - date published: 2024-10-20T11:00:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7w5ju/at_a_pennsylvania_rally_trump_descends_to_new/"> <img src="https://external-preview.redd.it/HEt4nGrQioTRH1Wfpu14ZMEPrdMjz4yhmQdyFi1x1ec.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=96c1e306e309e6485232e3b2f2d3b67de9b1495b" alt="At a Pennsylvania Rally, Trump Descends to New Levels of Vulgarity | The G.O.P. nominee repeated crude insults, and his supporters relished each moment. But the display could alienate swing voters." title="At a Pennsylvania Rally, Trump Descends to New Levels of Vulgarity | The G.O.P. nominee repeated crude insults, and his supporters relished each moment. But the display could alienate swing voters." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GirasoleDE"> /u/GirasoleDE </a> <br/> <span><a href="https://www.nytimes.com/2024/10/19/us/politics/trump-vulgarity-pennsylvania-rally.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/

## Harris steps up negative attacks on Trump
 - [https://www.reddit.com/r/politics/comments/1g7vmzk/harris_steps_up_negative_attacks_on_trump](https://www.reddit.com/r/politics/comments/1g7vmzk/harris_steps_up_negative_attacks_on_trump)
 - RSS feed: $source
 - date published: 2024-10-20T10:23:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7vmzk/harris_steps_up_negative_attacks_on_trump/"> <img src="https://external-preview.redd.it/MGQoJRrG4djW7kAU4s4j6vApCYnjgrBR214XFkM_wMw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=eecd3f42b6be1ec87bcc5749d882b4d9ab0af6a1" alt="Harris steps up negative attacks on Trump" title="Harris steps up negative attacks on Trump" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/9lobaldude"> /u/9lobaldude </a> <br/> <span><a href="https://thehill.com/homenews/campaign/4942047-kamala-harris-trump-attacks/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7vmzk/harris_steps_up_negative_attacks_on_trump/">[comments]</a></span> </td></tr></table>

## Harris Says Trump Is 'Cruel' As She Spotlights Abortion Restrictions In Georgia During Early Voting
 - [https://www.reddit.com/r/politics/comments/1g7ty20/harris_says_trump_is_cruel_as_she_spotlights](https://www.reddit.com/r/politics/comments/1g7ty20/harris_says_trump_is_cruel_as_she_spotlights)
 - RSS feed: $source
 - date published: 2024-10-20T08:14:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7ty20/harris_says_trump_is_cruel_as_she_spotlights/"> <img src="https://external-preview.redd.it/uGhVXiQQCA2XX3ef1dgW-WJE2opsxhTQsZEuDddkM18.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=104d9ac9cdbe05414b353acde3b674c1445ba2a0" alt="Harris Says Trump Is 'Cruel' As She Spotlights Abortion Restrictions In Georgia During Early Voting " title="Harris Says Trump Is 'Cruel' As She Spotlights Abortion Restrictions In Georgia During Early Voting " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BobbyLucero"> /u/BobbyLucero </a> <br/> <span><a href="https://www.huffpost.com/entry/us-election-2024-harris-trump-georgia-abortion_n_67147362e4b03a110eb47910">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7ty20/harris_says_trump_is_cruel_as_she_spotlights/">[comments]</a></span> </td></tr></table>

## Trump Media Whistleblower Blasts Company for Outsourcing Jobs Abroad as Betrayal of “America First”
 - [https://www.reddit.com/r/politics/comments/1g7q2rk/trump_media_whistleblower_blasts_company_for](https://www.reddit.com/r/politics/comments/1g7q2rk/trump_media_whistleblower_blasts_company_for)
 - RSS feed: $source
 - date published: 2024-10-20T03:40:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7q2rk/trump_media_whistleblower_blasts_company_for/"> <img src="https://external-preview.redd.it/ZXhlnKJ6D0Ubb1U0zCKiLsw3-9aPEUWBpTM_3vWNCzQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c13b67ea6ec6d3a996aef552640de302df9acd3a" alt="Trump Media Whistleblower Blasts Company for Outsourcing Jobs Abroad as Betrayal of “America First”" title="Trump Media Whistleblower Blasts Company for Outsourcing Jobs Abroad as Betrayal of “America First”" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BeginningBunch3924"> /u/BeginningBunch3924 </a> <br/> <span><a href="https://www.propublica.org/article/trump-media-whistleblower-complaint-devin-nunes">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7q2rk/trump_media_whistleblower_blasts_company_for/">[comments]</a></span> </td></tr></table>

## Mark Cuban pitches Harris as better on the economy, says Trump 'asked daddy for money'
 - [https://www.reddit.com/r/politics/comments/1g7pysx/mark_cuban_pitches_harris_as_better_on_the](https://www.reddit.com/r/politics/comments/1g7pysx/mark_cuban_pitches_harris_as_better_on_the)
 - RSS feed: $source
 - date published: 2024-10-20T03:33:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7pysx/mark_cuban_pitches_harris_as_better_on_the/"> <img src="https://external-preview.redd.it/RUPTQ8kBWn9WdyPg18QdXHPka8XcK-DMzZnEJM7D91I.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2f9b12d552f05610f2a4e5ea9cc8f62489e01d75" alt="Mark Cuban pitches Harris as better on the economy, says Trump 'asked daddy for money'" title="Mark Cuban pitches Harris as better on the economy, says Trump 'asked daddy for money'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/InternetPopular3679"> /u/InternetPopular3679 </a> <br/> <span><a href="https://www.azcentral.com/story/news/politics/elections/2024/10/19/in-phoenix-mark-cuban-talks-up-kamala-harris-says-trump-asked-daddy-for-money/75726147007/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7pysx/mark_cuban_pitches_harris_as_better_on_the/">[comments]</a></span> </td></tr></table>

## Trump fixates on Arnold Palmer as ‘all man’ in showers during profane rally
 - [https://www.reddit.com/r/politics/comments/1g7p6ug/trump_fixates_on_arnold_palmer_as_all_man_in](https://www.reddit.com/r/politics/comments/1g7p6ug/trump_fixates_on_arnold_palmer_as_all_man_in)
 - RSS feed: $source
 - date published: 2024-10-20T02:47:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7p6ug/trump_fixates_on_arnold_palmer_as_all_man_in/"> <img src="https://external-preview.redd.it/lTqvl2l_7b6qxUGZCIcV65v1tJsGO2GspcmgYRDLh2E.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b13331a336154a2c964d437a3743bb09c8c637b0" alt="Trump fixates on Arnold Palmer as ‘all man’ in showers during profane rally" title="Trump fixates on Arnold Palmer as ‘all man’ in showers during profane rally" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/anstromm"> /u/anstromm </a> <br/> <span><a href="https://www.washingtonpost.com/politics/2024/10/19/trump-rally-arnold-palmer-attacks-harris/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7p6ug/trump_fixates_on_arnold_palmer_as_all_man_in/">[comments]</a></span> </td></tr></table>

## MSNBC's Chris Hayes Catches Fox News Red-Handed Deceiving Its Audience to 'Clean Up' for Trump | "Do you see what they did there, on their own network?"
 - [https://www.reddit.com/r/politics/comments/1g7p54h/msnbcs_chris_hayes_catches_fox_news_redhanded](https://www.reddit.com/r/politics/comments/1g7p54h/msnbcs_chris_hayes_catches_fox_news_redhanded)
 - RSS feed: $source
 - date published: 2024-10-20T02:44:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7p54h/msnbcs_chris_hayes_catches_fox_news_redhanded/"> <img src="https://external-preview.redd.it/cepeuqhRhV8-fkXBlRHyDW_BXCARbm24_qjGTzJNCXE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1bd09221c1988d255d5df5c34df2b73f311c5568" alt="MSNBC's Chris Hayes Catches Fox News Red-Handed Deceiving Its Audience to 'Clean Up' for Trump | &quot;Do you see what they did there, on their own network?&quot;" title="MSNBC's Chris Hayes Catches Fox News Red-Handed Deceiving Its Audience to 'Clean Up' for Trump | &quot;Do you see what they did there, on their own network?&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murky-Site7468"> /u/Murky-Site7468 </a> <br/> <span><a href="https://www.commondreams.org/news/bret-baier-kamala-harris-interview">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7p54h/msnbcs_chris_hayes_catches_fox_news_redhanded/">[comme

## Trump Talks Arnold Palmer Being Well-Endowed, Calls Harris a ‘Shit’ VP in Bonkers Speech
 - [https://www.reddit.com/r/politics/comments/1g7oi0p/trump_talks_arnold_palmer_being_wellendowed_calls](https://www.reddit.com/r/politics/comments/1g7oi0p/trump_talks_arnold_palmer_being_wellendowed_calls)
 - RSS feed: $source
 - date published: 2024-10-20T02:06:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7oi0p/trump_talks_arnold_palmer_being_wellendowed_calls/"> <img src="https://external-preview.redd.it/mUWKgRqmTGe5jo5KuRdfwqSMtcw0I6nSo0VbD_eLE5o.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cde764dca938fbb9f191bc8275b723299cb4359c" alt="Trump Talks Arnold Palmer Being Well-Endowed, Calls Harris a ‘Shit’ VP in Bonkers Speech" title="Trump Talks Arnold Palmer Being Well-Endowed, Calls Harris a ‘Shit’ VP in Bonkers Speech" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Signal-Lie-6785"> /u/Signal-Lie-6785 </a> <br/> <span><a href="https://www.rollingstone.com/politics/politics-news/trump-arnold-palmer-penis-size-calls-harris-shit-vp-pennsylvania-speech-1235138168/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7oi0p/trump_talks_arnold_palmer_being_wellendowed_calls/">[comments]</a></span> </td></tr></table>

## Harris says she's pleased with record early vote turnout in Georgia and N.C.
 - [https://www.reddit.com/r/politics/comments/1g7nmnz/harris_says_shes_pleased_with_record_early_vote](https://www.reddit.com/r/politics/comments/1g7nmnz/harris_says_shes_pleased_with_record_early_vote)
 - RSS feed: $source
 - date published: 2024-10-20T01:16:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7nmnz/harris_says_shes_pleased_with_record_early_vote/"> <img src="https://external-preview.redd.it/gqMyzDAKOwt1ZwYqtLxqA0-flGMh6gzw2qiDiblULl8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0c61121d819487223ff5477ddf3facdde0adff47" alt="Harris says she's pleased with record early vote turnout in Georgia and N.C." title="Harris says she's pleased with record early vote turnout in Georgia and N.C." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/xjian77"> /u/xjian77 </a> <br/> <span><a href="https://www.msnbc.com/weekends-with-alex-witt/watch/harris-says-she-s-pleased-with-record-early-vote-turnout-in-georgia-and-n-c-222185029527">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7nmnz/harris_says_shes_pleased_with_record_early_vote/">[comments]</a></span> </td></tr></table>

## Trump kicks off a Pennsylvania rally by talking about Arnold Palmer’s genitalia
 - [https://www.reddit.com/r/politics/comments/1g7n5bh/trump_kicks_off_a_pennsylvania_rally_by_talking](https://www.reddit.com/r/politics/comments/1g7n5bh/trump_kicks_off_a_pennsylvania_rally_by_talking)
 - RSS feed: $source
 - date published: 2024-10-20T00:50:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7n5bh/trump_kicks_off_a_pennsylvania_rally_by_talking/"> <img src="https://external-preview.redd.it/7p6xD9FhEbS5HZ0qVpOTLOGRbVsaww8D-c0J1lL_cMA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bc29bab5f69a66c370f7e7557e7e733749a76b7a" alt="Trump kicks off a Pennsylvania rally by talking about Arnold Palmer’s genitalia" title="Trump kicks off a Pennsylvania rally by talking about Arnold Palmer’s genitalia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tank3875"> /u/Tank3875 </a> <br/> <span><a href="https://apnews.com/article/trump-arnold-palmer-closing-arguments-latrobe-pennsylvania-2bea9620c523e531a55259200215284e">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7n5bh/trump_kicks_off_a_pennsylvania_rally_by_talking/">[comments]</a></span> </td></tr></table>

## Harris vs. Trump: New presidential swing state poll has Harris up 8% in Michigan
 - [https://www.reddit.com/r/politics/comments/1g7mvif/harris_vs_trump_new_presidential_swing_state_poll](https://www.reddit.com/r/politics/comments/1g7mvif/harris_vs_trump_new_presidential_swing_state_poll)
 - RSS feed: $source
 - date published: 2024-10-20T00:35:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1g7mvif/harris_vs_trump_new_presidential_swing_state_poll/"> <img src="https://external-preview.redd.it/s9olkpXn9fXViZZwv3GtEPT4q0dhQKZ6ioq5Zcun-P4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=94190e97e7264e11ae8f455cffc1cfbebb474624" alt="Harris vs. Trump: New presidential swing state poll has Harris up 8% in Michigan" title="Harris vs. Trump: New presidential swing state poll has Harris up 8% in Michigan" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/horsepoop1123"> /u/horsepoop1123 </a> <br/> <span><a href="https://www.masslive.com/politics/2024/10/harris-vs-trump-new-presidential-swing-state-poll-has-harris-up-8.html?outputType=amp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1g7mvif/harris_vs_trump_new_presidential_swing_state_poll/">[comments]</a></span> </td></tr></table>

