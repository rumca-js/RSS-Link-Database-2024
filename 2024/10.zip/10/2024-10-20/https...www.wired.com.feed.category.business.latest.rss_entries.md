# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Protesters Say Uber and Lyft Are Still Failing Their Blind Passengers
 - [https://www.wired.com/story/protestors-say-uber-and-lyft-are-still-failing-their-blind-passengers](https://www.wired.com/story/protestors-say-uber-and-lyft-are-still-failing-their-blind-passengers)
 - RSS feed: $source
 - date published: 2024-10-20T10:30:00+00:00

At a protest in San Francisco, blind Uber and Lyft users claim that the ride-hailing companies aren’t doing enough to prevent drivers from turning them away.

