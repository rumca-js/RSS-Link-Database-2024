# Source:Mrwhosetheboss, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA, language:en-US

## I tested the Unspillable mug
 - [https://www.youtube.com/watch?v=_ccxfkmD9Ws](https://www.youtube.com/watch?v=_ccxfkmD9Ws)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA
 - date published: 2024-05-06T09:03:51+00:00

#shorts #tech

I spend a LOT of time trying to make my videos as concise, polished and useful as possible for you - if you would like to support me on that mission then consider subscribing to the channel - you'd make my day 😁

Music is from Epidemic sound:
http://share.epidemicsound.com/pHDFT

