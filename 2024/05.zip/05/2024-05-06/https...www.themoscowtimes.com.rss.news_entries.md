# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Siberia’s Irkutsk Declares Emergency as Fires Ravage Region
 - [https://www.themoscowtimes.com/2024/05/06/siberias-irkutsk-declares-emergency-as-fires-ravage-region-a85051](https://www.themoscowtimes.com/2024/05/06/siberias-irkutsk-declares-emergency-as-fires-ravage-region-a85051)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T14:29:00+00:00

A woman was hospitalized and in critical condition after she suffered burn wounds in the Bratsk district, authorities said.

## Russian Journalist Kevorkova Charged With ‘Justifying Terrorism,’ Lawyer Says
 - [https://www.themoscowtimes.com/2024/05/06/russian-journalist-kevorkova-charged-with-justifying-terrorism-lawyer-says-a85045](https://www.themoscowtimes.com/2024/05/06/russian-journalist-kevorkova-charged-with-justifying-terrorism-lawyer-says-a85045)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T13:53:33+00:00

Nadezhda Kevorkova has written about the Middle East and Russia’s North Caucasus for both independent and state-funded media.

## Russia Says Captured 2 Frontline Villages in Ukraine
 - [https://www.themoscowtimes.com/2024/05/06/russia-says-captured-2-frontline-villages-in-ukraine-a85050](https://www.themoscowtimes.com/2024/05/06/russia-says-captured-2-frontline-villages-in-ukraine-a85050)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T13:09:07+00:00

Kyiv has struggled to hold the front line in recent months as it faces severe ammunition shortages, mostly due to delays in U.S. military aid.

## Germany Recalls Russian Ambassador Over Cyberattack
 - [https://www.themoscowtimes.com/2024/05/06/germany-recalls-russian-ambassador-over-cyberattack-a85049](https://www.themoscowtimes.com/2024/05/06/germany-recalls-russian-ambassador-over-cyberattack-a85049)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T12:36:37+00:00

Alexander Graf Lambsdorff "has been called back for consultations and will stay in Berlin for a week and then return to Moscow," Berlin said.

## Russia Moves to Ban ‘Foreign Agents’ From Running for Political Office
 - [https://www.themoscowtimes.com/2024/05/06/russia-moves-to-ban-foreign-agents-from-running-for-political-office-a85048](https://www.themoscowtimes.com/2024/05/06/russia-moves-to-ban-foreign-agents-from-running-for-political-office-a85048)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T11:59:23+00:00

The restriction was initially proposed after several “foreign agents” announced their plans to run for Moscow’s City Duma later this year.

## Russia's FSB Detains Man Accused of Trying to Blow Up Court Buildings
 - [https://www.themoscowtimes.com/2024/05/06/russias-fsb-detains-man-accused-of-trying-to-blow-up-court-buildings-a85047](https://www.themoscowtimes.com/2024/05/06/russias-fsb-detains-man-accused-of-trying-to-blow-up-court-buildings-a85047)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T10:06:53+00:00

The man was found "placing unknown objects in construction waste" near a railway station.

## What’s Behind Georgia’s ‘Russian Law’?
 - [https://www.themoscowtimes.com/2024/05/06/whats-behind-georgias-russian-law-a85025](https://www.themoscowtimes.com/2024/05/06/whats-behind-georgias-russian-law-a85025)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T09:40:00+00:00

The Moscow Times spoke with experts to make sense of what is happening in Georgia, what might come next, and whether Russia may be involved.

## Russian Strikes Cut Power for Nearly Half a Million Homes in Ukraine
 - [https://www.themoscowtimes.com/2024/05/06/russian-strikes-cut-power-for-nearly-half-a-million-homes-in-ukraine-a85046](https://www.themoscowtimes.com/2024/05/06/russian-strikes-cut-power-for-nearly-half-a-million-homes-in-ukraine-a85046)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T09:33:24+00:00

Ukraine's Energy Ministry said power had been partially restored in the Sumy region on Monday morning.

## Russia Says Preparing Non-Strategic Nuclear Strike Drills
 - [https://www.themoscowtimes.com/2024/05/06/russia-says-preparing-non-strategic-nuclear-strike-drills-a85042](https://www.themoscowtimes.com/2024/05/06/russia-says-preparing-non-strategic-nuclear-strike-drills-a85042)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T08:23:10+00:00

The Defense Ministry said the exercises were in response to “provocative statements and threats by certain Western officials against” Russia.

## 6 Killed in Ukrainian Drone Attack on Russia’s Belgorod
 - [https://www.themoscowtimes.com/2024/05/06/6-killed-in-ukrainian-drone-attack-on-russias-belgorod-a85041](https://www.themoscowtimes.com/2024/05/06/6-killed-in-ukrainian-drone-attack-on-russias-belgorod-a85041)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-05-06T07:56:58+00:00

Belgorod region Governor Vyacheslav Gladkov said several drones struck a car and two vans carrying workers near the village of Berezovka.

