# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Amerykański żołnierz zatrzymany w Rosji. Udał się w "prywatną podróż"
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/amerykanski-zolnierz-zatrzymany-w-rosji-udal-sie-w-prywatna-podroz](https://www.polsatnews.pl/wiadomosc/2024-05-06/amerykanski-zolnierz-zatrzymany-w-rosji-udal-sie-w-prywatna-podroz)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T20:07:00+00:00

Amerykański żołnierz został zatrzymany we Władywostoku w zeszłym tygodniu - poinformował Departament Stanu USA. Wojskowy został aresztowany pod zarzutem kradzieży. Według doniesień mediów Amerykanin miał stacjonować w Korei Południowej, a po zakończeniu służby udał się do Rosji w prywatną podróż.

## Izrael rozpoczął ofensywę. Mówili o ataku na Rafah od dawna
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/izrael-rozpoczal-ofensywe-mowili-o-ataku-na-rafah-od-dawna](https://www.polsatnews.pl/wiadomosc/2024-05-06/izrael-rozpoczal-ofensywe-mowili-o-ataku-na-rafah-od-dawna)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T19:48:00+00:00

Izrael przeprowadził naloty na dzielnice miasta Rafah na południu Strefy Gazy. Ostrzał był bardzo intensywny i trwał ciągiem ok. 30 min. Zaledwie kilka godzin wcześniej mieszkańcom tych okolic nakazano ewakuację. Zapowiadanemu przez Izrael szturmowi na Rafah sprzeciwiał się prezydent USA Joe Biden.

## Ukraina: Chciał uniknąć służby wojskowej. Przebrał się za kobietę
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/ukraina-chcial-uniknac-sluzby-wojskowej-przebral-sie-za-kobiete](https://www.polsatnews.pl/wiadomosc/2024-05-06/ukraina-chcial-uniknac-sluzby-wojskowej-przebral-sie-za-kobiete)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T18:13:00+00:00

44-letni Ukrainiec chciał uniknąć powołania do wojska. W tym celu postanowił uciec do sąsiedniej Rumunii przebrany za kobietę. Gdy mężczyzna w makijażu i peruce próbował przekroczyć granicę natrafił na pograniczników. Okazało się, że przy sobie miał paszport swojej siostry. Uwagę zwraca zwłaszcza przebranie 44-latka - internauci dostrzegli na nim logo popularnego w Polsce dyskontu.

## Miedwiediew rzuca gromami. "Chór nieodpowiedzialnych drani"
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/miedwiediew-rzuca-gromami-chor-nieodpowiedzialnych-drani](https://www.polsatnews.pl/wiadomosc/2024-05-06/miedwiediew-rzuca-gromami-chor-nieodpowiedzialnych-drani)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T14:13:00+00:00

Chór nieodpowiedzialnych drani z zachodnich elit powiększa się - twierdzi Dmitrij Miedwiediew. To reakcja na doniesienia o wysłaniu do Ukrainy żołnierzy Legii Cudzoziemskiej. Zdaniem byłego prezydenta Rosji wśród pomysłodawców znajdować ma się m.in. Polska. Wysłanie wojsk do byłej Ukrainy oznaczać będzie zaangażowanie w wojnę. Będziemy musieli na to odpowiedzieć - grozi Miedwiediew.

## Rodzina królewska zyskuje na popularności. Brytyjczycy docenili króla Karola III
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/rodzina-krolewska-zyskuje-na-popularnosci-brytyjczycy-docenili-krola-karola-iii](https://www.polsatnews.pl/wiadomosc/2024-05-06/rodzina-krolewska-zyskuje-na-popularnosci-brytyjczycy-docenili-krola-karola-iii)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T12:29:00+00:00

Według najnowszego sondażu Karol III cieszy się większą przychylnością Brytyjczyków niż przed rokiem. Więcej osób także uważa, że monarchia powinna zostać utrzymana.

## Sędzia Tomasz Szmydt na Białorusi. Prosi o azyl
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/sedzia-tomasz-szmydt-prosi-o-azyl-na-bialorusi](https://www.polsatnews.pl/wiadomosc/2024-05-06/sedzia-tomasz-szmydt-prosi-o-azyl-na-bialorusi)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T09:25:00+00:00

Sędzia Wojewódzkiego Sądu Administracyjnego w Warszawie zwrócił się do władz Białorusi o azyl. Tomasz Szmydt podczas konferencji prasowej krytykował polskie władze i zapowiedział rezygnację ze swojej funkcji. W Polsce ostatni raz było o nim głośno w związku z tzw. aferą hejterską w Ministerstwie Sprawiedliwości.

## Wojna Izraela z Hamasem. Armia rozpoczęła ewakuację palestyńskich cywilów z Rafah
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/wojna-izraela-z-hamasem-armia-rozpoczela-ewakuacje-palestynskich-cywilow-z-rafah](https://www.polsatnews.pl/wiadomosc/2024-05-06/wojna-izraela-z-hamasem-armia-rozpoczela-ewakuacje-palestynskich-cywilow-z-rafah)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T08:50:00+00:00

Izraelska armia wezwała palestyńskich cywilów z Rafah na południu Strefy Gazy do ewakuacji, w związku z planowanym atakiem na to miasto. Wywiad izraelski uważa, że to tam ukrywają się przywódcy Hamasu. Rafah jest obecnie domem dla 1,4 miliona ludzi, z których większość to uchodźcy.

## Niespokojna Wielkanoc w Ukrainie. Nocny atak Rosjan
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/niespokojna-wielkanoc-w-ukrainie-nocny-atak-rosjan](https://www.polsatnews.pl/wiadomosc/2024-05-06/niespokojna-wielkanoc-w-ukrainie-nocny-atak-rosjan)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T08:02:00+00:00

Rosja przeprowadziła atak lotniczy na północnym wschodzie Ukrainy. Uderzono w obiekty infrastruktury energetycznej, co doprowadziło do braku prądu w wielu miejscowościach regionu. Jak dodała administracja wojskowa, większość z atakujących dronów zestrzelono. W prawosławną Niedzielę Wielkanocną Rosjanie zaatakowali centrum Charkowa. Ucierpiało co najmniej 10 osób.

## Rosja oskarża Ukrainę o atak na cywilów. Są ofiary śmiertelne
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/rosja-oskarza-ukraine-o-atak-na-cywilow-sa-ofiary-smiertelne](https://www.polsatnews.pl/wiadomosc/2024-05-06/rosja-oskarza-ukraine-o-atak-na-cywilow-sa-ofiary-smiertelne)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T08:00:00+00:00

Rosjanie twierdzą, że ukraińskie drony zaatakowały samochody z pracownikami cywilnymi na terytorium Rosji. Zginęło sześć osób, ponad 30 jest rannych.

## Rosja zapowiada ćwiczenia. Wykorzysta broń jądrową
 - [https://www.polsatnews.pl/wiadomosc/2024-05-06/rosja-zapowiada-cwiczenia-wykorzysta-bron-jadrowa](https://www.polsatnews.pl/wiadomosc/2024-05-06/rosja-zapowiada-cwiczenia-wykorzysta-bron-jadrowa)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-05-06T07:15:00+00:00

Rosyjskie ministerstwo obrony zapowiedziało ćwiczenia wojskowe, których elementem ma być rozmieszczenie i użycie niestrategicznej broni jądrowej. Resort twierdzi, że to reakcja na wypowiedzi zachodnich urzędników.

