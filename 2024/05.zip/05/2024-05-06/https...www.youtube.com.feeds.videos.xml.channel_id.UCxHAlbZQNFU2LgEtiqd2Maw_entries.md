# Source:C++ Weekly With Jason Turner, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw, language:en

## C++ Weekly - Ep 427 - Simple Generators Without Coroutines
 - [https://www.youtube.com/watch?v=F37h3FuA8kM](https://www.youtube.com/watch?v=F37h3FuA8kM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw
 - date published: 2024-05-06T15:29:49+00:00

☟☟ Awesome T-Shirts! Sponsors! Books! ☟☟

Upcoming Workshop: Understanding Object Lifetime, C++ On Sea, July 2, 2024
► https://cpponsea.uk/2024/sessions/understanding-object-lifetime-for-efficient-and-safer-cpp.html
Upcoming Workshop: C++ Best Practices, NDC TechTown, Sept 9-10, 2024
► https://ndctechtown.com/workshops/c-best-practices/4ceb8f7cf86c

Episode details: https://github.com/lefticus/cpp_weekly/issues/304

T-SHIRTS AVAILABLE!

► The best C++ T-Shirts anywhere! https://my-store-d16a2f.creator-spring.com/


WANT MORE JASON?

► My Training Classes: http://emptycrate.com/training.html
► Follow me on twitter: https://twitter.com/lefticus


SUPPORT THE CHANNEL

► Patreon: https://www.patreon.com/lefticus 
► Github Sponsors: https://github.com/sponsors/lefticus
► Paypal Donation: https://www.paypal.com/donate/?hosted_button_id=PQ4A2V6ZZFQEU


GET INVOLVED

► Video Idea List: https://github.com/lefticus/cpp_weekly/issues


JASON'S BOOKS

► C++23 Best Practices
  Leanpub Ebook: https

