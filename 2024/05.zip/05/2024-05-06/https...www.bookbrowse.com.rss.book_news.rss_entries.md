# Source:Book Browse, URL:https://www.bookbrowse.com/rss/book_news.rss, language:en

## 2024 Pulitzer Prize Winners announced
 - [http://www.bookbrowse.com/news/detail/index.cfm?news_item_number=3202](http://www.bookbrowse.com/news/detail/index.cfm?news_item_number=3202)
 - RSS feed: https://www.bookbrowse.com/rss/book_news.rss
 - date published: 2024-05-06T19:50:11+00:00

The Pulitzer Prize winners were announced Monday by the Pulitzer Prize Board. To see and read more about the winners, please visit our <a href="https://www.bookbrowse.com/awards/#jump-1">awards page.</a>

