# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Nerwowa inauguracja prezydentury Putina? Rosja boi się ataków Ukrainy
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nerwowa-inauguracja-prezydentury-putina-rosja-boi-sie-atakow,nId,7494131](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nerwowa-inauguracja-prezydentury-putina-rosja-boi-sie-atakow,nId,7494131)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-05-06T20:35:05+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nerwowa-inauguracja-prezydentury-putina-rosja-boi-sie-atakow,nId,7494131"><img align="left" alt="Nerwowa inauguracja prezydentury Putina? Rosja boi się ataków Ukrainy" src="https://i.iplsc.com/nerwowa-inauguracja-prezydentury-putina-rosja-boi-sie-atakow/000J2M3DXXVNKWWR-C321.jpg" /></a>&quot;Ukraińskie Siły Zbrojne przygotowują zmasowany atak na terytorium Rosji 7 maja o godzinie 6 rano&quot; - informuje redakcja RT. Dziennikarze, powołując się na źródła w rosyjskiej armii, przekonują, że władze w Kijowie planują uderzenia, które mają zakłócić inaugurację prezydentury Władimira Putina.</p><br clear="all" />

## Jasne stanowisko Joe Bidena. Naciskał na premiera Izraela
 - [https://wydarzenia.interia.pl/zagranica/news-jasne-stanowisko-joe-bidena-naciskal-na-premiera-izraela,nId,7494078](https://wydarzenia.interia.pl/zagranica/news-jasne-stanowisko-joe-bidena-naciskal-na-premiera-izraela,nId,7494078)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-05-06T18:04:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jasne-stanowisko-joe-bidena-naciskal-na-premiera-izraela,nId,7494078"><img align="left" alt="Jasne stanowisko Joe Bidena. Naciskał na premiera Izraela" src="https://i.iplsc.com/jasne-stanowisko-joe-bidena-naciskal-na-premiera-izraela/000J2LRMUHUSFTVU-C321.jpg" /></a>Prezydent USA Joe Biden naciskał na premiera Izraela Benjamina Netanjahu, aby nie przeprowadzał izraelskiej ofensywy wojskowej w mieście Rafah na południu Strefy Gazy - informuje Reuters. Izrael nakazał w poniedziałek Palestyńczykom, aby ewakuowali część obszaru miasta.</p><br clear="all" />

## Rozmowy pokojowe ws. Ukrainy. Deklaracja Andrzeja Dudy
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rozmowy-pokojowe-ws-ukrainy-deklaracja-andrzeja-dudy,nId,7494038](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rozmowy-pokojowe-ws-ukrainy-deklaracja-andrzeja-dudy,nId,7494038)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-05-06T16:54:12+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rozmowy-pokojowe-ws-ukrainy-deklaracja-andrzeja-dudy,nId,7494038"><img align="left" alt="Rozmowy pokojowe ws. Ukrainy. Deklaracja Andrzeja Dudy" src="https://i.iplsc.com/rozmowy-pokojowe-ws-ukrainy-deklaracja-andrzeja-dudy/000J2LGHGV1F6KC2-C321.jpg" /></a>Prezydent Andrzej Duda potwierdził swój udział w czerwcowym szczycie pokojowym ws. Ukrainy w Szwajcarii. W rozmowie z Wołodymyrem Zełenskim m.in. omówił &quot;kroki mające na celu zapewnienie jak najszerszego udziału krajów globalnego południa&quot; - podano w mediach społecznościowych ukraińskiego przywódcy.</p><br clear="all" />

## Fałszywe monety zalały Europę. Gang rozbity w Hiszpanii
 - [https://wydarzenia.interia.pl/zagranica/news-falszywe-monety-zalaly-europe-gang-rozbity-w-hiszpanii,nId,7493867](https://wydarzenia.interia.pl/zagranica/news-falszywe-monety-zalaly-europe-gang-rozbity-w-hiszpanii,nId,7493867)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-05-06T15:54:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-falszywe-monety-zalaly-europe-gang-rozbity-w-hiszpanii,nId,7493867"><img align="left" alt="Fałszywe monety zalały Europę. Gang rozbity w Hiszpanii" src="https://i.iplsc.com/falszywe-monety-zalaly-europe-gang-rozbity-w-hiszpanii/000J2KXWCF5FQDPF-C321.jpg" /></a>Nawet 400 tysięcy fałszywych monet o wartości dwóch euro trafiło do krajów Europy. Hiszpańska policja poinformowała o rozbiciu grupy przestępczej składającej się głównie z obywateli Chin, którzy podrabiali pieniądze, które następnie wprowadzane były do obrotu.</p><br clear="all" />

## Amerykański polityk wprost. "Wojsko USA może być zmuszone walczyć"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-amerykanski-polityk-wprost-wojsko-usa-moze-byc-zmuszone-walc,nId,7493429](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-amerykanski-polityk-wprost-wojsko-usa-moze-byc-zmuszone-walc,nId,7493429)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-05-06T07:11:49+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-amerykanski-polityk-wprost-wojsko-usa-moze-byc-zmuszone-walc,nId,7493429"><img align="left" alt="Amerykański polityk wprost. &quot;Wojsko USA może być zmuszone walczyć&quot;" src="https://i.iplsc.com/amerykanski-polityk-wprost-wojsko-usa-moze-byc-zmuszone-walc/000J2ENMK7AVME6N-C321.jpg" /></a>- Nie możemy pozwolić Ukrainie upaść, bo jeśli tak się stanie, istnieje duże prawdopodobieństwo, że Ameryka będzie musiała włączyć się w konflikt - nie tylko jeśli chodzi o pieniądze, ale także za pomocą naszych żołnierzy - powiedział Hakeem Jeffries w wywiadzie dla telewizji CBS. Lider Partii Demokratycznej w Izbie Reprezentantów wskazał również na prorosyjskich polityków w Partii Republikańskiej i jednoznacznie skrytykował politykę &quot;ugłaskania&quot; Rosji i Władimira Putina. </p><br clear="all" />

## Mocne słowa Radosława Sikorskiego w USA. Przypomniał sytuację sprzed 20 lat
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mocne-slowa-radoslawa-sikorskiego-w-usa-przypomnial-sytuacje,nId,7493409](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mocne-slowa-radoslawa-sikorskiego-w-usa-przypomnial-sytuacje,nId,7493409)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-05-06T05:53:27+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mocne-slowa-radoslawa-sikorskiego-w-usa-przypomnial-sytuacje,nId,7493409"><img align="left" alt="Mocne słowa Radosława Sikorskiego w USA. Przypomniał sytuację sprzed 20 lat" src="https://i.iplsc.com/mocne-slowa-radoslawa-sikorskiego-w-usa-przypomnial-sytuacje/000J2DSAFQG3226O-C321.jpg" /></a>- Polska góruje w wydatkach na obronność w NATO - podkreślił w wywiadzie dla amerykańskiej stacji Fox News szef MSZ Radosław Sikorski. Dodał, że &quot;po atakach z 11 września Polska wysłała brygadę wojska najpierw do Iraku, a potem do Afganistanu&quot;. - Wtedy z wami byliśmy, teraz to Europa Środkowa potrzebuje amerykańskiego wsparcia - podkreślił. </p><br clear="all" />

