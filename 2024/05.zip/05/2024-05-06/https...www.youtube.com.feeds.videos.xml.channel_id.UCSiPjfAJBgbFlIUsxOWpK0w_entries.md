# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## This song is called “Morning Waterbug” and Jack wrote it in his sleep while lucid dreaming.
 - [https://www.youtube.com/watch?v=fgMixgTkx8Y](https://www.youtube.com/watch?v=fgMixgTkx8Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2024-05-06T17:22:15+00:00



