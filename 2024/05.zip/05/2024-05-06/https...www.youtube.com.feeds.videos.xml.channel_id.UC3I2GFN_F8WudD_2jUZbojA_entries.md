# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Real Estate - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=5yZQFBFG4vs](https://www.youtube.com/watch?v=5yZQFBFG4vs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-06T15:00:04+00:00

http://KEXP.ORG presents Real Estate performing live in the KEXP studio. Recorded March 2, 2024.

Songs:
Somebody New. 00:00
Haunted World  4:05
Water Underground  7:04
Flowers 10:14
Daniel (Elton John cover)  12:57

Martin Courtney - Vocals, Guitar
Julian Lynch - Guitar, Vocals
Alex Bleeker - Bass, Vocals
Matthew Kallman - Keys, Vocals
Samantha (Sammi) Niss - Drums, Percussion

Host: Hans
Audio Engineer: Kevin Sugg
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht & Scott Holpainen
Editor: Scott Holpainen

https://www.realestatetheband.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Real Estate - Daniel (Live on KEXP)
 - [https://www.youtube.com/watch?v=vRSoJKV5j-g](https://www.youtube.com/watch?v=vRSoJKV5j-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-06T11:00:46+00:00

http://KEXP.ORG presents Real Estate performing “Daniel” live in the KEXP studio. Recorded March 2, 2024.

Martin Courtney - Vocals, Guitar
Julian Lynch - Guitar, Vocals
Alex Bleeker - Bass, Vocals
Matthew Kallman - Keys, Vocals
Samantha (Sammi) Niss - Drums, Percussion

Host: Hans
Audio Engineer: Kevin Sugg
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht & Scott Holpainen
Editor: Scott Holpainen

https://www.realestatetheband.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Real Estate - Haunted World (Live on KEXP)
 - [https://www.youtube.com/watch?v=gEdWk-NsyRE](https://www.youtube.com/watch?v=gEdWk-NsyRE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-06T11:00:36+00:00

http://KEXP.ORG presents Real Estate performing “Haunted World” live in the KEXP studio. Recorded March 2, 2024.

Martin Courtney - Vocals, Guitar
Julian Lynch - Guitar, Vocals
Alex Bleeker - Bass, Vocals
Matthew Kallman - Keys, Vocals
Samantha (Sammi) Niss - Drums, Percussion

Host: Hans
Audio Engineer: Kevin Sugg
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht & Scott Holpainen
Editor: Scott Holpainen

https://www.realestatetheband.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Real Estate - Water Underground (Live on KEXP)
 - [https://www.youtube.com/watch?v=LyV3wW4e2QY](https://www.youtube.com/watch?v=LyV3wW4e2QY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-06T11:00:30+00:00

http://KEXP.ORG presents Real Estate performing “Water Underground” live in the KEXP studio. Recorded March 2, 2024.

Martin Courtney - Vocals, Guitar
Julian Lynch - Guitar, Vocals
Alex Bleeker - Bass, Vocals
Matthew Kallman - Keys, Vocals
Samantha (Sammi) Niss - Drums, Percussion

Host: Hans
Audio Engineer: Kevin Sugg
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht & Scott Holpainen
Editor: Scott Holpainen

https://www.realestatetheband.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Real Estate - Flowers (Live on KEXP)
 - [https://www.youtube.com/watch?v=hFx3nkwUwPs](https://www.youtube.com/watch?v=hFx3nkwUwPs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-06T11:00:28+00:00

http://KEXP.ORG presents Real Estate performing “Flowers” live in the KEXP studio. Recorded March 2, 2024.

Martin Courtney - Vocals, Guitar
Julian Lynch - Guitar, Vocals
Alex Bleeker - Bass, Vocals
Matthew Kallman - Keys, Vocals
Samantha (Sammi) Niss - Drums, Percussion

Host: Hans
Audio Engineer: Kevin Sugg
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht & Scott Holpainen
Editor: Scott Holpainen

https://www.realestatetheband.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Real Estate - Somebody New (Live on KEXP)
 - [https://www.youtube.com/watch?v=SZhshnW8Q0s](https://www.youtube.com/watch?v=SZhshnW8Q0s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-06T11:00:19+00:00

http://KEXP.ORG presents Real Estate performing “Somebody New” live in the KEXP studio. Recorded March 2, 2024.

Martin Courtney - Vocals, Guitar
Julian Lynch - Guitar, Vocals
Alex Bleeker - Bass, Vocals
Matthew Kallman - Keys, Vocals
Samantha (Sammi) Niss - Drums, Percussion

Host: Hans
Audio Engineer: Kevin Sugg
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht & Scott Holpainen
Editor: Scott Holpainen

https://www.realestatetheband.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

