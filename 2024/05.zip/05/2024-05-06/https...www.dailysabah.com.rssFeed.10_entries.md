# Source:DAILYSABAH - Turkey News, URL:https://www.dailysabah.com/rssFeed/10, language:en-US

## Istanbul's historic Kariye Mosque opens for worship
 - [https://www.dailysabah.com/turkiye/istanbuls-historic-kariye-mosque-opens-for-worship/news](https://www.dailysabah.com/turkiye/istanbuls-historic-kariye-mosque-opens-for-worship/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-06T11:51:00+00:00

The Kariye Mosque in Istanbul, owned by the General Directorate of Foundations of the Ministry of Culture and Tourism, and reconverted into a mosque from being a museum by a Presid...

## Hidrellez message from first lady Emine Erdoğan
 - [https://www.dailysabah.com/turkiye/hidrellez-message-from-first-lady-emine-erdogan/news](https://www.dailysabah.com/turkiye/hidrellez-message-from-first-lady-emine-erdogan/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-06T11:04:00+00:00

Turkish first lady Emine Erdoğan issued a congratulatory message on the Hidrellez festival.

'May spring, which brings fertility to the soil and abundance to the seeds, fill househ...

## Türkiye's first lady hails spring renewal with warm Hıdrellez wishes
 - [https://www.dailysabah.com/turkiye/turkiyes-first-lady-hails-spring-renewal-with-warm-hidrellez-wishes/news](https://www.dailysabah.com/turkiye/turkiyes-first-lady-hails-spring-renewal-with-warm-hidrellez-wishes/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-06T11:04:00+00:00

Turkish first lady Emine Erdoğan issued a congratulatory message on the Hidrellez festival.

'May spring, which brings fertility to the soil and abundance to the seeds, fill househ...

## Main cause of air pollution in cities is traffic
 - [https://www.dailysabah.com/turkiye/main-cause-of-air-pollution-in-cities-is-traffic/news](https://www.dailysabah.com/turkiye/main-cause-of-air-pollution-in-cities-is-traffic/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-06T09:36:48+00:00

Istanbul Technical University (ITU) Department of Environmental Engineering Faculty member professor Levent Kuzu stated: 'The main cause of air pollution in cities is traffic. Besi...

## Cyzicus: World's largest temple column capital
 - [https://www.dailysabah.com/turkiye/cyzicus-worlds-largest-temple-column-capital/news](https://www.dailysabah.com/turkiye/cyzicus-worlds-largest-temple-column-capital/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-06T09:02:00+00:00

Excavations have started at the ancient city of Cyzicus in the Erdek district in Türkiye's northwestern Balıkesir province. With one of the most important ancient construction...

## Van: Spring on one side, snow on the other
 - [https://www.dailysabah.com/turkiye/van-spring-on-one-side-snow-on-the-other/news](https://www.dailysabah.com/turkiye/van-spring-on-one-side-snow-on-the-other/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-06T08:37:00+00:00

Due to elevation and geographical features, temperature differences are experienced in some areas of Van, eastern Türkiye, where animals graze in the rural neighborhood of Çatak wh...

