# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed, language:en-US

## Colombia’s government and congress rocked by embezzlement scandal
 - [https://colombiareports.com/colombias-government-and-congress-rocked-by-embezzlement-scandal](https://colombiareports.com/colombias-government-and-congress-rocked-by-embezzlement-scandal)
 - RSS feed: https://colombiareports.com/feed
 - date published: 2024-05-06T14:16:12+00:00

<p>Colombia&#8217;s President Gustavo Petro sacked his anti-corruption and regional development advisers for their alleged role in the embezzlement of disaster relief funds. Petro announced this after the former acting director&#8230;</p>
<p>The post <a href="https://colombiareports.com/colombias-government-and-congress-rocked-by-embezzlement-scandal/">Colombia&#8217;s government and congress rocked by embezzlement scandal</a> appeared first on <a href="https://colombiareports.com">Colombia News | Colombia Reports</a>.</p>

