# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## How normal wood crystalizes and hardens into #petrifiedwood. #Nature #Environment
 - [https://www.youtube.com/watch?v=L0rCug56IAQ](https://www.youtube.com/watch?v=L0rCug56IAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2024-05-06T17:00:14+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Business Insider on Facebook: https://www.facebook.com/businessinsider Business Insider on Instagram: https://www.instagram.com/insiderbusiness Business Insider on Twitter: https://www.twitter.com/businessinsider 
Business Insider on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Business Insider on TikTok: https://www.tiktok.com/@businessinsider

