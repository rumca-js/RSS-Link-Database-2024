# Source:RP - Cyfrowa, URL:https://cyfrowa.rp.pl/rss/2991-cyfrowa, language:pl-PL

## Sztuczna inteligencja lubi kłamać. Ufanie jej może być bardzo kosztowne
 - [https://cyfrowa.rp.pl/technologie/art40297371-sztuczna-inteligencja-lubi-klamac-ufanie-jej-moze-byc-bardzo-kosztowne](https://cyfrowa.rp.pl/technologie/art40297371-sztuczna-inteligencja-lubi-klamac-ufanie-jej-moze-byc-bardzo-kosztowne)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-05-06T14:50:00+00:00

Bot wprowadzony przez Nowy Jork doradzał firmom łamanie prawa, zaś AI firmy kurierskiej DPD naśmiewała się z niej, nazywając najgorszą na świecie.

