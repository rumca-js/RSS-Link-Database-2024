# Source:MeatCanyon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC91V6D3nkhP89wUb9f_h17g, language:en-US

## Jo  Jo Siwa’s New Dance
 - [https://www.youtube.com/watch?v=IVOli9wXcm4](https://www.youtube.com/watch?v=IVOli9wXcm4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC91V6D3nkhP89wUb9f_h17g
 - date published: 2024-05-06T19:03:08+00:00

Subscribe to my Patreon:
https://www.patreon.com/meatcanyon

Animators:
Jerb: https://twitter.com/jerbjpg?s=20

Vudujin: https://twitter.com/Vudujin

DublyMike: https://twitter.com/dublymike?s=20

Jamie R : https://youtube.com/@JaimeR2D

Awez: https://mobile.twitter.com/aweztube\

Pfinney - https://www.instagram.com/pfinney_/?hl=en

Sandbag


Clean up Artist:

Lee Thompson - https://www.instagram.com/leethompsonart/?hl=en

Izzi - https://x.com/Izzi8bit?s=20


BG Artist:
Kuo Yang: https://www.artstation.com/kuoyang

Patrick Pedroza: https://www.instagram.com/thepeeetrick/

OkMichie: https://twitter.com/okmichie_art?s=20

Mrmattzan: https://instagram.com/mrmattzan?igshid=YmMyMTA2M2Y=


COMP FX:
Molly Wright: https://www.youtube.com/c/wollymight

Audio Design:
https://twitter.com/imadeasong?s=20

