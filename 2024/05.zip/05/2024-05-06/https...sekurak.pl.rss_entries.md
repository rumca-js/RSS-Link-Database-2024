# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Sprzedał armii USA podrobiony sprzęt Cisco za około $100 000 000.
 - [https://sekurak.pl/sprzedal-armii-usa-podrobiony-sprzet-cisco-za-okolo-100-000-000](https://sekurak.pl/sprzedal-armii-usa-podrobiony-sprzet-cisco-za-okolo-100-000-000)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2024-05-06T16:27:27+00:00

<p>Krótka relacja z informacjami przekazanymi przez ArsTechnica: Podrobiony sprzęt znalazł się w &#8222;systemach wspierających&#8221; samoloty: F-15, F-18, F-22 czy bombowiec B-52. Urządzenia zostały również sprzedane szpitalom czy szkołom, a cały proceder trwał kilka dobrych lat. Dla niepoznaki fejkowe urządzenia były pakowane w normalnie wyglądające kartony oklejone normalnie wyglądającymi naklejkami, a...</p>
<p>Artykuł <a href="https://sekurak.pl/sprzedal-armii-usa-podrobiony-sprzet-cisco-za-okolo-100-000-000/" rel="nofollow">Sprzedał armii USA podrobiony sprzęt Cisco za około $100 000 000.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Zapraszamy na Google Cloud Days – konferencję o bezpieczeństwie i praktycznym wykorzystaniu chmury. To już 15-17 maja!
 - [https://sekurak.pl/zapraszamy-na-google-cloud-days-konferencje-o-bezpieczenstwie-i-praktycznym-wykorzystaniu-chmury-to-juz-15-17-maja](https://sekurak.pl/zapraszamy-na-google-cloud-days-konferencje-o-bezpieczenstwie-i-praktycznym-wykorzystaniu-chmury-to-juz-15-17-maja)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2024-05-06T06:23:43+00:00

<p>Tegoroczna edycja Google Cloud Days skupia uwagę uczestników m.in na kwestiach bezpieczeństwa. Organizowana przez FOTC, partnera Google Cloud charytatywna konferencja odbędzie się w dniach 15-17 maja w warszawskiej siedzibie Google.&#160; Tematyka Google Cloud Days może być szczególnie ciekawa dla czytelników Sekurak.pl. Do głównych wątków poruszanych przez dwa majowe dni będzie...</p>
<p>Artykuł <a href="https://sekurak.pl/zapraszamy-na-google-cloud-days-konferencje-o-bezpieczenstwie-i-praktycznym-wykorzystaniu-chmury-to-juz-15-17-maja/" rel="nofollow">Zapraszamy na Google Cloud Days – konferencję o bezpieczeństwie i praktycznym wykorzystaniu chmury. To już 15-17 maja!</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

