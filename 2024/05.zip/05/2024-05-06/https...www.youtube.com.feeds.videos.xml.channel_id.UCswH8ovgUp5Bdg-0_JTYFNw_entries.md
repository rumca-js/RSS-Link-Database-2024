# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## "Sorry, Putin IS Going To Win” - Prof. John Mearsheimer SHOCKS Piers Morgan With Stark Reality
 - [https://www.youtube.com/watch?v=9ifHXuTtTGI](https://www.youtube.com/watch?v=9ifHXuTtTGI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-05-06T20:00:01+00:00

Prof John Mearsheimer schools Piers Morgan on the reality of the war in Ukraine. 

Watch MY Interview with Tucker Carlson exclusively on Locals here: https://bit.ly/TuckerCarlsonLocals

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

## It's Over. Fauci's F*cked Now
 - [https://www.youtube.com/watch?v=stnVpTf4tfo](https://www.youtube.com/watch?v=stnVpTf4tfo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-05-06T17:01:03+00:00

Why choose American Hartford Gold? Visit this link to see how you can get up to $10,000 of free silver with qualifying purchases: https://offers.americanhartfordgold.com/brand/

As Fauci awaits his origins of Covid enquiry, more evidence emerges of his role in the likely cause of Covid and its origins as a bioweapon.   

Watch MY Interview with Tucker Carlson exclusively on Locals here: https://bit.ly/TuckerCarlsonLocals

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

## Wait, Did They Just Make The Bible Literally ILLEGAL?! - Stay Free #359
 - [https://www.youtube.com/watch?v=hsYXiiDVHnk](https://www.youtube.com/watch?v=hsYXiiDVHnk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-05-06T13:54:34+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me exclusively over on RUMBLE: bit.ly/stayfree359
--------------------------------------------------------------------------------------------------------------------------
Why choose American Hartford Gold? Visit this link to see how you can get up to $10,000 of free silver with qualifying purchases: https://offers.americanhartfordgold.com/brand/

Try Everyday Wellness for yourself today, https://www.trulean.com use code BRAND25 for 25% off, let them know I sent you!

On the show today, we will be discussing the New Anti-Semitism Awareness Act, which alleges that the Bible is anti-Semitic. Additionally, we'll cover the classified documents found in the Mar-a-Lago raid, which were allegedly staged. Also, Ron DeSantis has banned lab-grown meat in Florida. Plus, much more.

Join the awakening wonders community here: https://bit.ly/RussellBrand-Support

Visit the new merch store: htt

