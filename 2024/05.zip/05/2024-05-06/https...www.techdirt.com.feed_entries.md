# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## Welcome To The Brave New World Of Vehicle Insurance Fraud Powered By Shallowfakes
 - [https://www.techdirt.com/2024/05/06/welcome-to-the-brave-new-world-of-vehicle-insurance-fraud-powered-by-shallowfakes](https://www.techdirt.com/2024/05/06/welcome-to-the-brave-new-world-of-vehicle-insurance-fraud-powered-by-shallowfakes)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-05-06T22:42:20+00:00

The harms of deepfakes have been evident for a while. Recent examples include a Biden deepfake designed to influence voters, and the rising use of AI “nudification” apps to produce deepfake nudes of students, often female minors. But alongside the application of sophisticated AI programs to produce deepfakes there are other, lower-tech scams, often known [&#8230;]

## The U.S. House Version Of KOSA: Still A Censorship Bill
 - [https://www.techdirt.com/2024/05/06/the-u-s-house-version-of-kosa-still-a-censorship-bill](https://www.techdirt.com/2024/05/06/the-u-s-house-version-of-kosa-still-a-censorship-bill)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-05-06T19:57:56+00:00

A&#160;companion bill&#160;to the Kids Online Safety Act (KOSA) was introduced in the House last month. Despite minor changes, it suffers from the same fundamental flaws as its&#160;Senate counterpart. At its core, this bill is still an unconstitutional censorship bill that restricts protected online speech and gives the government the power to target services and content [&#8230;]

## Utah Gov’t Leaned So Hard Into Confirmation Bias That Its Transphobic Snitch Form Became A Playground For Trolls
 - [https://www.techdirt.com/2024/05/06/utah-govt-leaned-so-hard-into-confirmation-bias-that-its-transphobic-snitch-form-became-a-playground-for-trolls](https://www.techdirt.com/2024/05/06/utah-govt-leaned-so-hard-into-confirmation-bias-that-its-transphobic-snitch-form-became-a-playground-for-trolls)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-05-06T18:00:56+00:00

This is the sort of dumb shit you do when you feel the only people who will bother responding to your hateful dog whistle are a bunch of dogs (with valid voting registration!) that constantly have one ear cocked towards their master&#8217;s voice. You leave a web form for comments almost completely unsecured and pretty [&#8230;]

## Daily Deal: Babbel Language Learning (All Languages)
 - [https://www.techdirt.com/2024/05/06/daily-deal-babbel-language-learning-all-languages-5](https://www.techdirt.com/2024/05/06/daily-deal-babbel-language-learning-all-languages-5)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-05-06T17:55:56+00:00

You probably already know the benefits of learning a language, so let&#8217;s focus on the app. Right off the bat, let&#8217;s be clear about one thing: When we say &#8220;app&#8221; we don&#8217;t mean that you&#8217;re limited to using Babbel on your phone. You can use Babbel on desktop, too, and your progress is synchronized across [&#8230;]

## Stop Expecting Tech Companies To Provide ‘Consequences’ For Criminal Behavior; That’s Not Their Job
 - [https://www.techdirt.com/2024/05/06/stop-expecting-tech-companies-to-provide-consequences-for-criminal-behavior-thats-not-their-job](https://www.techdirt.com/2024/05/06/stop-expecting-tech-companies-to-provide-consequences-for-criminal-behavior-thats-not-their-job)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-05-06T16:29:30+00:00

Whose job is it to provide consequences when someone breaks the law? It seems like this issue shouldn’t be that complicated. We expect law enforcement to deal with it when someone breaks the law. Not private individuals or organizations. Because that’s vigilantism. Yet, on the internet, over and over again, we keep seeing people set [&#8230;]

## Logitech Launches An “AI” Mouse That’s Just A 2022 Mouse With A Mappable Button
 - [https://www.techdirt.com/2024/05/06/logitech-launches-an-ai-mouse-thats-just-a-2022-mouse-with-a-mappable-button](https://www.techdirt.com/2024/05/06/logitech-launches-an-ai-mouse-thats-just-a-2022-mouse-with-a-mappable-button)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-05-06T12:29:30+00:00

&#8220;AI,&#8221; or semi-cooked language learning models are very cool. There&#8217;s a world of possibility there in terms of creativity and productivity tools to scientific research. But early adoption of AI has been more of a rushed mess driven by speculative VC bros who are more interested in making money off of hype (see: pointless AI [&#8230;]

