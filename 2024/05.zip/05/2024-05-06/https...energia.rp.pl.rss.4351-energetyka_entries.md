# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Masowe redukcje mocy z odnawialnych źródeł energii
 - [https://energia.rp.pl/oze/art40302281-masowe-redukcje-mocy-z-odnawialnych-zrodel-energii](https://energia.rp.pl/oze/art40302281-masowe-redukcje-mocy-z-odnawialnych-zrodel-energii)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-05-06T18:20:09+00:00

Majówka, trwająca od 27 kwietnia do 5 maja, stała pod znakiem redukcji mocy z OZE. W tym roku doszło już do kilkunastu takich redukcji.

