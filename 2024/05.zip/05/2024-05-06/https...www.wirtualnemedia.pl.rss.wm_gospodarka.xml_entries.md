# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Europejski Kongres Gospodarczy - ostatni dzień na rejestrację
 - [https://www.wirtualnemedia.pl/artykul/europejski-kongres-gospodarczy-ostatni-dzien-na-rejestracje](https://www.wirtualnemedia.pl/artykul/europejski-kongres-gospodarczy-ostatni-dzien-na-rejestracje)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-05-06T03:39:27.041757+00:00

Tylko do poniedziałku 6 maja do godziny 16:00 można zarejestrować się na XVI Europejski Kongres Gospodarczy. Od 7 do 9 maja w Katowicach spotkają się kluczowi przedstawiciele polskiego ekosystemu gospodarczego – decydenci polityczni, przedstawiciele świata biznesu, nauki i mediów. Gośćmi specjalnymi będą premier Donald Tusk, Ursula von der Leyen, kandydatka EPL na stanowisko Przewodniczącej Komisji Europejskiej oraz Kadri Simson, komisarz UE ds. energii. Portal Wirtualnemedia.pl jest patronem medialnym wydarzenia.

