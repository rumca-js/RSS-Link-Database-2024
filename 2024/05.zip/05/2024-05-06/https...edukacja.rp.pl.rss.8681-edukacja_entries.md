# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Matura 2024 już we wtorek, internet zalały rzekome „przecieki”
 - [https://edukacja.rp.pl/matura-i-egzamin-osmoklasisty/art40301041-matura-2024-juz-we-wtorek-internet-zalaly-rzekome-przecieki](https://edukacja.rp.pl/matura-i-egzamin-osmoklasisty/art40301041-matura-2024-juz-we-wtorek-internet-zalaly-rzekome-przecieki)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-05-06T17:06:52+00:00

Centralna Komisja Egzaminacyjna podkreśla, że „arkusze maturalne” pojawiające się w sieci nie są prawdziwe. Przestrzega też maturzystów, by nie dali się oszukać.

