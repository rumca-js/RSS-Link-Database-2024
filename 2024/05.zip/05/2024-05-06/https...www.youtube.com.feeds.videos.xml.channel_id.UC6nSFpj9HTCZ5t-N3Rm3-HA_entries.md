# Source:Vsauce, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA, language:en-US

## Dr. Seuss's First Book
 - [https://www.youtube.com/watch?v=P2EylRAenX0](https://www.youtube.com/watch?v=P2EylRAenX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA
 - date published: 2024-05-06T20:37:45+00:00



