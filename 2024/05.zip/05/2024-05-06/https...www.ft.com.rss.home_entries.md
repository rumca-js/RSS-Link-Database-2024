# Source:FT - International homepage, URL:https://www.ft.com/rss/home, language:en

## JPMorgan Chase posts $8bn gain after Visa stake restructuring
 - [https://www.ft.com/content/79ce8953-b6c0-4944-9ef0-f7ee5a6f33b1](https://www.ft.com/content/79ce8953-b6c0-4944-9ef0-f7ee5a6f33b1)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T23:19:44+00:00



## SoftBank leads $1bn funding for British AI group Wayve
 - [https://www.ft.com/content/a5704e29-545c-45e6-b7e3-d0a8cda285c4](https://www.ft.com/content/a5704e29-545c-45e6-b7e3-d0a8cda285c4)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T23:01:34+00:00

Investment in start-up that makes self-driving software represents Europe’s largest AI funding deal to date

## Boeing subject to new FAA probe over 787 Dreamliner inspections
 - [https://www.ft.com/content/1c3a0d4b-46ce-42a5-be1a-f7d588b5acce](https://www.ft.com/content/1c3a0d4b-46ce-42a5-be1a-f7d588b5acce)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T21:29:13+00:00

Plane maker informed aviation safety regulator last month that required tests were not performed

## Fewer Londoners leave for the country as pandemic-era exodus eases
 - [https://www.ft.com/content/1807d78d-b67d-44f4-9eb2-55253a3c3c2e](https://www.ft.com/content/1807d78d-b67d-44f4-9eb2-55253a3c3c2e)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T21:13:45+00:00

The capital regains its appeal to homebuyers as more people return to the office

## Banco Sabadell rejects €12bn takeover bid by BBVA
 - [https://www.ft.com/content/2af2bba8-9c53-4fb8-9ba2-ada07424d101](https://www.ft.com/content/2af2bba8-9c53-4fb8-9ba2-ada07424d101)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T20:22:46+00:00

Spanish lender says the offer by its larger rival undervalues the company

## MDMA-based mental health treatment faces wary US regulator
 - [https://www.ft.com/content/4a176ed2-665a-4b18-8330-a343e7390081](https://www.ft.com/content/4a176ed2-665a-4b18-8330-a343e7390081)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T20:21:59+00:00

Food and Drug Administration poised to call for outside assessment in test for psychedelics sector

## Polish judge defects to Belarus amid conflicting accusations
 - [https://www.ft.com/content/2e9a5eec-ac4d-46ec-a107-8109505471be](https://www.ft.com/content/2e9a5eec-ac4d-46ec-a107-8109505471be)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T19:12:00+00:00

Tomasz Szmydt said he was persecuted by Warsaw, which in turn accused him of treachery

## Hamas accepts draft hostage swap proposal
 - [https://www.ft.com/content/14ff1d0c-23ec-419f-927b-1cfd0601071b](https://www.ft.com/content/14ff1d0c-23ec-419f-927b-1cfd0601071b)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T18:04:12+00:00

Israel yet to officially respond to move, which sparked hopes of a breakthrough in Tel Aviv and Gaza

## Sunak insists UK general election is not a ‘foregone conclusion’
 - [https://www.ft.com/content/a4984bfc-80e2-4b2d-a1a8-f0720247d4ae](https://www.ft.com/content/a4984bfc-80e2-4b2d-a1a8-f0720247d4ae)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T17:22:03+00:00

PM seeks to rally support by warning of dangers of Labour-led coalition after setback in local polls

## Robinhood warns of SEC lawsuit threat over crypto business
 - [https://www.ft.com/content/3e5aba79-2fb3-4432-b518-027147e8b3de](https://www.ft.com/content/3e5aba79-2fb3-4432-b518-027147e8b3de)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T17:15:51+00:00

Retail brokerage says ‘Wells notice’ comes after years of attempts to seek regulatory clarity

## Judge threatens jail if Trump violates ‘hush money’ gag order
 - [https://www.ft.com/content/86e2a1da-1b86-46e9-88b4-9b2df57c6245](https://www.ft.com/content/86e2a1da-1b86-46e9-88b4-9b2df57c6245)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T14:42:22+00:00

Justice Juan Merchan says fines have failed to deter the former president from violating gag order

## Columbia cancels university-wide graduation ceremony
 - [https://www.ft.com/content/e45e43ac-236e-4c1b-99ec-97640a19f3b2](https://www.ft.com/content/e45e43ac-236e-4c1b-99ec-97640a19f3b2)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T13:39:33+00:00

Decision comes after weeks of unrest on campus triggered by pro-Palestinian protesters

## Why precision-guided chemotherapy has driven a dealmaking boom
 - [https://www.ft.com/content/85ab8fe2-d1ec-47e9-83f9-4802682a1c94](https://www.ft.com/content/85ab8fe2-d1ec-47e9-83f9-4802682a1c94)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T13:30:34+00:00

Weight-loss treatments are not the only source of excitement in the pharmaceutical research world

## European stocks near 1-month high after Wall Street’s post-jobs rally
 - [https://www.ft.com/content/38149d15-479b-4a39-9758-94b2ceb53b7f](https://www.ft.com/content/38149d15-479b-4a39-9758-94b2ceb53b7f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T12:03:37+00:00



## Is the corporate DEI panic finally over?
 - [https://www.ft.com/content/94d3fba0-cd65-4bcd-b4ab-1adad97173fe](https://www.ft.com/content/94d3fba0-cd65-4bcd-b4ab-1adad97173fe)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T12:00:29+00:00

In the US, the diversity, equity and inclusion push has quietly rolled on despite political backlash

## Georgia’s puppet master turns towards Moscow
 - [https://www.ft.com/content/07e24da4-5220-4389-9ae7-4b8297932fd5](https://www.ft.com/content/07e24da4-5220-4389-9ae7-4b8297932fd5)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T11:26:24+00:00

Oligarch Bidzina Ivanishvili has sought to steer Caucasus nation back into Russia’s orbit

## Xi is probing for cracks in the EU and Nato
 - [https://www.ft.com/content/669cb64e-0707-4298-9968-1bb4550a5d20](https://www.ft.com/content/669cb64e-0707-4298-9968-1bb4550a5d20)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T11:25:17+00:00

China’s charm offensive in Europe has threatening undertones and is likely to fail as a result

## Italian journalists strike in dispute with Meloni’s right-wing government
 - [https://www.ft.com/content/7fa1e71c-386d-45b6-b1ae-ec71bdace399](https://www.ft.com/content/7fa1e71c-386d-45b6-b1ae-ec71bdace399)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T11:18:57+00:00

Public broadcaster Rai hit by labour action centred on complaints over editorial interference and work conditions

## Higher rates boost bankers to troubled companies
 - [https://www.ft.com/content/151c1589-db4a-4f63-8141-8a0437ab8bdf](https://www.ft.com/content/151c1589-db4a-4f63-8141-8a0437ab8bdf)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T10:00:29+00:00

Fee revenue is up at boutique firms as borrowing costs force more clients to restructure

## French tech group Atos says Křetínský and Onepoint make bailout offers
 - [https://www.ft.com/content/a0e98b36-5f9f-4924-96e5-d9f05d93f3f7](https://www.ft.com/content/a0e98b36-5f9f-4924-96e5-d9f05d93f3f7)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T09:42:05+00:00

Indebted IT services group is trying to agree a restructuring this month

## Brussels to end rule-of-law dispute with Poland
 - [https://www.ft.com/content/168af5db-10bc-4cd7-9e55-235db3c9e8ff](https://www.ft.com/content/168af5db-10bc-4cd7-9e55-235db3c9e8ff)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T09:06:48+00:00

Plan to drop punitive procedure follows pro-EU Donald Tusk’s victory over nationalist right

## Xi and Macron to hold talks with trade tensions on agenda
 - [https://www.ft.com/content/0728c778-4d5a-4dfc-8694-9c493e82df15](https://www.ft.com/content/0728c778-4d5a-4dfc-8694-9c493e82df15)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T07:31:38+00:00

Chinese president signals greater market access for French cosmetics and agriculture amid EU anti-subsidy probes

## Israel begins ‘limited’ evacuation of civilians from Rafah
 - [https://www.ft.com/content/7f5133dc-9085-466f-a0fe-8afd6557bce6](https://www.ft.com/content/7f5133dc-9085-466f-a0fe-8afd6557bce6)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T07:12:29+00:00

Tens of thousands of Palestinians told by Israeli military to move out of the city in southern Gaza

## A warning from the breakdown nations
 - [https://www.ft.com/content/ee51d83e-0037-4130-a4f9-656aa7c4ca97](https://www.ft.com/content/ee51d83e-0037-4130-a4f9-656aa7c4ca97)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

The fates of former ‘model’ economies carry lessons for current stars

## Arab nations warm to peacekeeping force for Gaza
 - [https://www.ft.com/content/1de57fa0-0f30-42c3-ba0a-6f438e17f732](https://www.ft.com/content/1de57fa0-0f30-42c3-ba0a-6f438e17f732)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

Proposal comes as western and Arab capitals struggle to lay out a viable postwar plan for region

## Chinese homebuyers favour ‘second-hand’ houses as property crisis bites
 - [https://www.ft.com/content/aaffd689-16f4-4719-ad41-f4c0c67df29f](https://www.ft.com/content/aaffd689-16f4-4719-ad41-f4c0c67df29f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

With tens of thousands of new developments yet to be completed, buyers are looking again at older buildings

## Health systems and employers count economic cost of long Covid
 - [https://www.ft.com/content/bb09a03d-4a87-4cea-ae87-986769fd4680](https://www.ft.com/content/bb09a03d-4a87-4cea-ae87-986769fd4680)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

Experts warn better data is required to drive policy as debilitating condition reduces workforce

## Last Credit Suisse chief executive, Ulrich Körner, to leave UBS
 - [https://www.ft.com/content/57ef286a-f5cf-49ed-8e16-8b04d39e4276](https://www.ft.com/content/57ef286a-f5cf-49ed-8e16-8b04d39e4276)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

Swiss bank will eliminate management board of former rival within weeks

## Singapore looks at ways to revive stock market
 - [https://www.ft.com/content/656b387e-a21e-4200-9fb6-8e9474408412](https://www.ft.com/content/656b387e-a21e-4200-9fb6-8e9474408412)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

Hosting a regional exchange is one idea but critics say focus should be on improving corporate governance

## The $9tn question: how to pay for the green transition
 - [https://www.ft.com/content/6873d96e-3e40-45c6-9d84-8ce27b7b23e1](https://www.ft.com/content/6873d96e-3e40-45c6-9d84-8ce27b7b23e1)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

The bill for meeting climate goals will be immense. Governments worldwide are trying to figure out how to foot it

## Why don’t auditors find fraud?
 - [https://www.ft.com/content/9f16dc90-ea79-4abf-92f9-2391b2b73ced](https://www.ft.com/content/9f16dc90-ea79-4abf-92f9-2391b2b73ced)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:30+00:00

Regulators have put forward a series of proposals to clarify and extend responsibilities to spot wrongdoing

## Divestment is not as easy as it may seem
 - [https://www.ft.com/content/5d04d5fa-e6a6-4e05-9532-34d6385161e3](https://www.ft.com/content/5d04d5fa-e6a6-4e05-9532-34d6385161e3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:29+00:00

As campus protests rage, passivity over their financial holdings has left universities and other institutions in a bind

## Eurotunnel operator offers to subsidise new cross-Channel rail services
 - [https://www.ft.com/content/b481ef33-bbe6-4397-9b67-e860e46c5090](https://www.ft.com/content/b481ef33-bbe6-4397-9b67-e860e46c5090)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:29+00:00

Getlink chief puts forward €50mn pot for companies considering launching rivals to Eurostar

## Finland boosts war readiness in face of Russian aggression
 - [https://www.ft.com/content/cf28a55d-31d2-433a-a651-e582cca28fa5](https://www.ft.com/content/cf28a55d-31d2-433a-a651-e582cca28fa5)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:29+00:00

Now in Nato, Helsinki disperses military supplies beyond its borders and hones economy for resilience

## Risk of a renminbi devaluation is real
 - [https://www.ft.com/content/3b127b6e-0e64-4e9a-b9d8-d0ddec21b587](https://www.ft.com/content/3b127b6e-0e64-4e9a-b9d8-d0ddec21b587)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T04:00:29+00:00

If there is pressure on the Chinese currency, it could have far-reaching economic and political consequences

## Last-minute stand-in wins Panama presidency
 - [https://www.ft.com/content/0a1b5180-e694-429f-ba87-94dd69c22b98](https://www.ft.com/content/0a1b5180-e694-429f-ba87-94dd69c22b98)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T03:03:27+00:00

José Raúl Mulino pledges to try to reinvigorate economy and manage migration flows from South America

## Bank Indonesia ‘ready for the worst’ in face of hawkish Fed and currency volatility
 - [https://www.ft.com/content/aa57064b-553c-4ac4-833c-dacc5bf6cada](https://www.ft.com/content/aa57064b-553c-4ac4-833c-dacc5bf6cada)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-06T01:00:28+00:00

Senior monetary official says central bank prepared to do more after intervening to shore up rupiah

