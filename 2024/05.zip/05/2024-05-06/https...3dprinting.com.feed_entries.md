# Source:3DPrinting.com, URL:https://3dprinting.com/feed, language:en-US

## Ecogensus Unveils Sustainable Plastic Substitutes from Household Waste - 3DPrinting.com
 - [https://3dprinting.com/news/ecogensus-unveils-sustainable-plastic-substitutes-from-household-waste](https://3dprinting.com/news/ecogensus-unveils-sustainable-plastic-substitutes-from-household-waste)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-05-06T10:00:29+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/ecogensus-unveils-sustainable-plastic-substitutes-from-household-waste/" target="_blank">Ecogensus Unveils Sustainable Plastic Substitutes from Household Waste</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">May 6</span></div><div><img alt="Ecogensus Unveils Sustainable Plastic Substitutes from Household Waste" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="500" src="https://3dprinting.com/wp-content/uploads/image3-161-500x500.png" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

## Lindner Adopts HSS 3D Printing for Tractor Parts - 3DPrinting.com
 - [https://3dprinting.com/news/lindner-adopts-hss-3d-printing-for-tractor-parts](https://3dprinting.com/news/lindner-adopts-hss-3d-printing-for-tractor-parts)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-05-06T09:00:46+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/lindner-adopts-hss-3d-printing-for-tractor-parts/" target="_blank">Lindner Adopts HSS 3D Printing for Tractor Parts</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">May 6</span></div><div><img alt="Lindner Adopts HSS 3D Printing for Tractor Parts" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="500" src="https://3dprinting.com/wp-content/uploads/image1-205-500x500.png" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

## 3D Printed Filter Caps Offer Clean Water for Colombia’s Arid Zones - 3DPrinting.com
 - [https://3dprinting.com/news/3d-printed-filter-caps-offer-clean-water-for-colombias-arid-zones](https://3dprinting.com/news/3d-printed-filter-caps-offer-clean-water-for-colombias-arid-zones)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-05-06T07:28:48+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/3d-printed-filter-caps-offer-clean-water-for-colombias-arid-zones/" target="_blank">3D Printed Filter Caps Offer Clean Water for Colombia&#8217;s Arid Zones</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">May 6</span></div><div><img alt="Ingenious Filter Caps Offer Clean Water for Colombia&#039;s Arid Zones" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="281" src="https://3dprinting.com/wp-content/uploads/image2-198.png" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

