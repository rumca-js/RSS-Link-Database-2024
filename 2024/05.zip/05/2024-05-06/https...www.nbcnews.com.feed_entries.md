# Source:CNBC, URL:https://www.nbcnews.com/feed, language:en-US

## What you missed on Day 12 of Trump's trial: Another gag order ruling and details on how Michael Cohen was paid
 - [https://www.nbcnews.com/politics/donald-trump/missed-day-12-trumps-trial-another-gag-order-ruling-details-michael-co-rcna150964](https://www.nbcnews.com/politics/donald-trump/missed-day-12-trumps-trial-another-gag-order-ruling-details-michael-co-rcna150964)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T23:56:59+00:00

Two new witnesses took the stand Monday on the 12th day of Donald Trump’s hush money trial, shortly after the judge overseeing the case again cited the former president for violating the gag order he imposed last month.

## Spurs star Victor Wembanyama wins NBA Rookie of the Year
 - [https://www.nbcnews.com/news/sports/victor-wembanyama-nba-rookie-year-rcna150961](https://www.nbcnews.com/news/sports/victor-wembanyama-nba-rookie-year-rcna150961)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T23:05:37+00:00

San Antonio Spurs star Victor Wembanyama averaged 21.4 points, 10.6 rebounds, 3.9 assists, 3.6 blocks per game.

## See the red carpet looks from the 2024 Met Gala
 - [https://www.nbcnews.com/pop-culture/celebrity/met-gala-2024-red-carpet-photos-rcna150956](https://www.nbcnews.com/pop-culture/celebrity/met-gala-2024-red-carpet-photos-rcna150956)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T22:20:56+00:00

The biggest celebrities awaken our fashion senses at the 2024 Met Gala. "Sleeping Beauties: Reawakening Fashion"

## Self-funded candidates roil congressional races: From the Politics Desk
 - [https://www.nbcnews.com/politics/2024-election/self-funded-candidates-roil-congressional-races-politics-desk-rcna150943](https://www.nbcnews.com/politics/2024-election/self-funded-candidates-roil-congressional-races-politics-desk-rcna150943)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T21:50:17+00:00

Welcome to the online version of From the Politics Desk, an evening newsletter that brings you the NBC News Politics team’s latest reporting and analysis from the campaign trail, the White House and Capitol Hill.

## FAA investigating whether Boeing completed required inspections on 787 Dreamliner jets
 - [https://www.nbcnews.com/news/us-news/faa-investigating-boeing-over-787-dreamliner-inspections-rcna150953](https://www.nbcnews.com/news/us-news/faa-investigating-boeing-over-787-dreamliner-inspections-rcna150953)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T21:36:34+00:00

The Federal Aviation Administration has opened an investigation into Boeing after it learned the company may not have completed required inspections on 787 Dreamliner jets.

## DOJ seeks 11 years for conservative scion Brent Bozell IV, saying he 'led the charge' on Jan. 6
 - [https://www.nbcnews.com/politics/justice-department/doj-seeks-11-years-conservative-scion-brent-bozell-iv-saying-led-charg-rcna150701](https://www.nbcnews.com/politics/justice-department/doj-seeks-11-years-conservative-scion-brent-bozell-iv-saying-led-charg-rcna150701)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T21:35:20+00:00

Federal prosecutors are seeking more than 11 years in federal prison for Jan. 6 defendant Brent Bozell IV, the son and grandson of major conservative figures.

## The best insoles for your sneakers
 - [https://www.nbcnews.com/select/shopping/best-insoles-rcna150922](https://www.nbcnews.com/select/shopping/best-insoles-rcna150922)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T21:10:19+00:00

Podiatrists give tips on shopping for supportive, comfortable insoles that can help with arch pain, plantar fasciitis and more.

## Texas couple welcomes identical quadruplet girls: ‘Holy moly!’
 - [https://www.nbcnews.com/news/us-news/texas-couple-welcomes-identical-quadruplet-girls-holy-moly-rcna150946](https://www.nbcnews.com/news/us-news/texas-couple-welcomes-identical-quadruplet-girls-holy-moly-rcna150946)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T21:00:21+00:00

Doctors put the odds of having identical quadruplets at about one in 15 million — which makes Mercedes and Jonathan Sandhu very special.

## Rich people are spending more than ever to run for Congress. A big test is coming in Maryland.
 - [https://www.nbcnews.com/politics/2024-election/rich-people-running-for-congress-big-test-coming-maryland-rcna150607](https://www.nbcnews.com/politics/2024-election/rich-people-running-for-congress-big-test-coming-maryland-rcna150607)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T20:52:39+00:00

Wealthy office-seekers plowed more of their own money than ever into runs for Congress last year. Now, the biggest one of all is facing an important hurdle.

## Social Security now expected to run short on funds in 2035, one year later than previously projected, Treasury says
 - [https://www.nbcnews.com/business/consumer/social-security-now-expected-run-short-funds-2035-one-year-later-previ-rcna150936](https://www.nbcnews.com/business/consumer/social-security-now-expected-run-short-funds-2035-one-year-later-previ-rcna150936)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T20:44:03+00:00

The trust funds the Social Security Administration relies on to pay benefits are now projected to run out in 2035, one year later than previously projected, according to the annual trustees’ report released on Monday.

## Charges dropped against five deputies in death of Irvo Otieno
 - [https://www.nbcnews.com/news/us-news/charges-dropped-five-deputies-death-irvo-otieno-rcna150826](https://www.nbcnews.com/news/us-news/charges-dropped-five-deputies-death-irvo-otieno-rcna150826)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T20:40:45+00:00

The mother of Irvo Otieno, who suffocated to death in police custody at a Virginia psychiatric hospital, expressed outrage over the withdrawal of murder charges against five sheriff's deputies indicted in his death.

## The courtroom for Trump's trial becomes a test of power for an ex-president and a judge
 - [https://www.nbcnews.com/politics/donald-trump/courtroom-trumps-trial-becomes-test-power-ex-president-judge-rcna150893](https://www.nbcnews.com/politics/donald-trump/courtroom-trumps-trial-becomes-test-power-ex-president-judge-rcna150893)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T20:31:13+00:00

A striking aspect of Donald Trump’s criminal trial is Judge Juan Merchan’s no-nonsense approach and the degree to which he — and he alone — controls the proceedings.

## U.S. Capitol swaps statue of obscure Arkansas figure for mentor to Little Rock Nine
 - [https://www.nbcnews.com/news/nbcblk/us-capitol-swaps-statue-obscure-arkansas-figure-mentor-little-rock-nin-rcna150941](https://www.nbcnews.com/news/nbcblk/us-capitol-swaps-statue-obscure-arkansas-figure-mentor-little-rock-nin-rcna150941)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T20:18:29+00:00

Arkansas will be represented by musician Johnny Cash and Daisy Bates, a civil rights leader, instead of two little-known figures from the 18th and 19th centuries in Statuary Hall in the U.S. Capitol.

## House Republicans plan to move forward with contempt against Attorney General Merrick Garland
 - [https://www.nbcnews.com/politics/congress/house-republicans-plan-move-forward-contempt-attorney-general-merrick-rcna150937](https://www.nbcnews.com/politics/congress/house-republicans-plan-move-forward-contempt-attorney-general-merrick-rcna150937)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T20:02:29+00:00

The House Judiciary Committee plans to prepare a resolution to hold Attorney General Merrick Garland in contempt of Congress.

## Miss USA Noelia Voigt resigns, cites her mental health while relinquishing crown
 - [https://www.nbcnews.com/news/us-news/miss-usa-noelia-voigt-resigns-cites-mental-health-relinquishing-crown-rcna150931](https://www.nbcnews.com/news/us-news/miss-usa-noelia-voigt-resigns-cites-mental-health-relinquishing-crown-rcna150931)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T19:54:25+00:00

Miss USA Noelia Voigt announced Monday she is relinquishing her crown to prioritize her mental health.

## Milwaukee removes elections chief in unexpected battleground-state shakeup
 - [https://www.nbcnews.com/politics/2024-election/milwaukee-removes-elections-chief-unexpected-battleground-state-shakeu-rcna150927](https://www.nbcnews.com/politics/2024-election/milwaukee-removes-elections-chief-unexpected-battleground-state-shakeu-rcna150927)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T19:51:08+00:00

The top elections official in Milwaukee County was removed from her post Monday, an unexpected shakeup in the most populous county in battleground Wisconsin.

## Best butt acne treatments
 - [https://www.nbcnews.com/select/shopping/best-butt-acne-treatments-rcna150875](https://www.nbcnews.com/select/shopping/best-butt-acne-treatments-rcna150875)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T19:44:43+00:00

Butt acne can be caused by pants that are too tight, sweating and more. Dermatologists explain the best ways to treat butt acne and how to prevent it in the future.

## U.S. soldier detained in Russia, officials say
 - [https://www.nbcnews.com/politics/politics-news/us-soldier-detained-russia-officials-say-rcna150928](https://www.nbcnews.com/politics/politics-news/us-soldier-detained-russia-officials-say-rcna150928)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T18:46:48+00:00

A U.S. soldier was detained in Russia over the weekend, according to three U.S. officials.

## Elizabeth Holmes sees more months trimmed from prison release date
 - [https://www.nbcnews.com/news/us-news/elizabeth-holmes-prison-release-date-rcna149825](https://www.nbcnews.com/news/us-news/elizabeth-holmes-prison-release-date-rcna149825)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T18:33:29+00:00

The Theranos founder has shaved more months from her initial 11-year-plus sentence for wire fraud and conspiracy, federal records show, and is still due to be released two years earlier than expected.

## Ole Miss fraternity expels member who appeared to make ape-like sounds toward Black protester
 - [https://www.nbcnews.com/news/nbcblk/fraternity-expels-member-university-mississippi-taunt-black-woman-rcna150860](https://www.nbcnews.com/news/nbcblk/fraternity-expels-member-university-mississippi-taunt-black-woman-rcna150860)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T18:16:39+00:00

A fraternity at Ole Miss where a member last week jeered a Black female protester released a statement saying the man has been expelled from the organization.

## Georgia's former lieutenant governor backs Biden in high-profile defection from GOP
 - [https://www.nbcnews.com/politics/2024-election/georgias-former-lieutenant-governor-backs-biden-high-profile-defection-rcna150894](https://www.nbcnews.com/politics/2024-election/georgias-former-lieutenant-governor-backs-biden-high-profile-defection-rcna150894)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T18:14:15+00:00

Former Georgia Lt. Gov. Jeff Duncan says he’s voting for President Joe Biden in 2024, and he's urging other Republicans to do so, too.

## Fashion's biggest night: Zendaya, Jennifer Lopez and more celebs expected at Met Gala
 - [https://www.nbcnews.com/pop-culture/pop-culture-news/live-blog/met-gala-2024-live-updates-rcna149860](https://www.nbcnews.com/pop-culture/pop-culture-news/live-blog/met-gala-2024-live-updates-rcna149860)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T18:00:28+00:00

Fashion's biggest night: Zendaya, Jennifer Lopez and more celebs expected at Met Gala

## Scientists identify a genetic cause of some cases of Alzheimer's for the first time
 - [https://www.nbcnews.com/health/aging/cases-alzheimers-caused-two-copies-single-gene-rcna150909](https://www.nbcnews.com/health/aging/cases-alzheimers-caused-two-copies-single-gene-rcna150909)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T17:48:48+00:00

For the first time, researchers have identified a genetic form of late-in-life Alzheimer’s disease — in people who inherit two copies of a worrisome gene.

## Marjorie Taylor Greene to meet with Speaker Mike Johnson as she threatens vote to oust him
 - [https://www.nbcnews.com/politics/congress/marjorie-taylor-greene-meet-speaker-johnson-threatens-vote-oust-rcna150841](https://www.nbcnews.com/politics/congress/marjorie-taylor-greene-meet-speaker-johnson-threatens-vote-oust-rcna150841)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T17:47:00+00:00

Rep. Marjorie Taylor Greene will meet with House Speaker Mike Johnson ahead of her push this week to force a vote to depose him over aid to Ukraine.

## New Superman fully revealed in photo from director James Gunn for upcoming movie
 - [https://www.nbcnews.com/pop-culture/pop-culture-news/new-superman-fully-revealed-photo-director-james-gunn-upcoming-movie-rcna150896](https://www.nbcnews.com/pop-culture/pop-culture-news/new-superman-fully-revealed-photo-director-james-gunn-upcoming-movie-rcna150896)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T17:30:16+00:00

Superman’s new suit was revealed by director James Gunn for his 2025 superhero reboot starring David Corenswet, taking over for Henry Cavill in the Zack Snyder version of the DC universe.

## Panama's new president-elect was practically retired: 'I never imagined this'
 - [https://www.nbcnews.com/news/latino/jose-raul-mulino-panama-new-president-rcna150895](https://www.nbcnews.com/news/latino/jose-raul-mulino-panama-new-president-rcna150895)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T17:26:25+00:00

José Raúl Mulino who was practically retired will now he'll be Panama's president. A maritime law attorney, he became known as a private business leader who took part in a civil movement against the dictatorship of Gen. Manuel Antonio Noriega.

## Everything you need for a new kitten
 - [https://www.nbcnews.com/select/shopping/new-kitten-checklist-rcna150829](https://www.nbcnews.com/select/shopping/new-kitten-checklist-rcna150829)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T17:07:29+00:00

What does a new kitten need? Shop our new kitten checklist, including picks recommended by cat parents from Litter Genie, Modkat, Temptations and more.

## Renters' hopes of being able to buy a home have fallen to a record low, survey shows
 - [https://www.nbcnews.com/business/economy/renters-hopes-able-buy-home-fallen-record-low-new-york-fed-survey-show-rcna150891](https://www.nbcnews.com/business/economy/renters-hopes-able-buy-home-fallen-record-low-new-york-fed-survey-show-rcna150891)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T17:03:16+00:00

The dream of home ownership has gotten even further away for renters, with higher housing costs and elevated interest rates standing in the way of the American housing dream, according to a New York Federal Reserve survey released Monday.

## 82-year-old U.S. Sen. Bernie Sanders is running for re-election to a fourth term
 - [https://www.nbcnews.com/politics/2024-election/82-year-old-us-sen-bernie-sanders-running-re-election-fourth-term-rcna150861](https://www.nbcnews.com/politics/2024-election/82-year-old-us-sen-bernie-sanders-running-re-election-fourth-term-rcna150861)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T16:49:03+00:00

Vermont Sen. Bernie Sanders, an independent, will run for re-election in 2024 at age 82.

## Tom Brady caught on camera warning comic about Robert Kraft massage joke at Netflix roast
 - [https://www.nbcnews.com/news/us-news/tom-brady-caught-camera-warning-comic-robert-kraft-massage-joke-netfli-rcna150869](https://www.nbcnews.com/news/us-news/tom-brady-caught-camera-warning-comic-robert-kraft-massage-joke-netfli-rcna150869)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T16:42:29+00:00

Brady lashed out at funnyman Jeff Ross during Sunday's "The Roast of Tom Brady" on Netflix over a massage joke about New England Patriots owner Robert Kraft.

## Planters nuts recalled due to potential for listeria contamination
 - [https://www.nbcnews.com/news/us-news/planters-nuts-recalled-due-potential-listeria-contamination-rcna150844](https://www.nbcnews.com/news/us-news/planters-nuts-recalled-due-potential-listeria-contamination-rcna150844)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T16:08:49+00:00

Hormel Foods is recalling two types of Planters nuts due to the potential for contamination with the germ listeria, the manufacturer announced.

## Biden speaks to Netanyahu amid cease-fire talks and evacuation of Rafah
 - [https://www.nbcnews.com/politics/white-house/biden-speaks-netanyahu-cease-fire-talks-evacuation-rafah-rcna150863](https://www.nbcnews.com/politics/white-house/biden-speaks-netanyahu-cease-fire-talks-evacuation-rafah-rcna150863)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T16:08:08+00:00

WASHINGTON — President Joe Biden spoke to Israeli Prime Minister Benjamin Netanyahu on Monday morning as a potential ground assault in Rafah looms and as negotiations over a cease-fire between Hamas and Israel have stalled.

## Severe weather leaves millions at risk as storms sweep across the South
 - [https://www.nbcnews.com/news/weather/severe-weather-leaves-millions-risk-storms-sweep-south-rcna150823](https://www.nbcnews.com/news/weather/severe-weather-leaves-millions-risk-storms-sweep-south-rcna150823)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T15:47:28+00:00

Following a week of heavy flooding which resulted in rescue crews pulling hundreds of people to safety, the Southeastern part of Texas is underwater.

## Man attempts to shoot Pennsylvania pastor during sermon livestream, suspect's relative found dead
 - [https://www.nbcnews.com/news/us-news/man-attempts-shoot-pennsylvania-pastor-sermon-livestream-suspects-rela-rcna150817](https://www.nbcnews.com/news/us-news/man-attempts-shoot-pennsylvania-pastor-sermon-livestream-suspects-rela-rcna150817)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T15:45:50+00:00

A Pennsylvania man has been arrested after he attempted to shoot a pastor during a sermon that was livestreamed, hours before a relative was found dead in a home where the suspect lived.

## ‘Friends’ creators say finale episode leak was an ‘inside job’ — and reveal if they got to the bottom of it
 - [https://www.nbcnews.com/news/us-news/friends-creators-say-finale-episode-leak-was-job-reveal-got-bottom-rcna150847](https://www.nbcnews.com/news/us-news/friends-creators-say-finale-episode-leak-was-job-reveal-got-bottom-rcna150847)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T15:35:45+00:00

Twenty years ago, 52.5 million Americans tuned in to the finale of the beloved TV show “Friends.”

## 10-month-old girl abducted from New Mexico park found safe after mother, another woman found dead
 - [https://www.nbcnews.com/news/10-month-old-girl-abducted-new-mexico-park-found-safe-mother-another-w-rcna150854](https://www.nbcnews.com/news/10-month-old-girl-abducted-new-mexico-park-found-safe-mother-another-w-rcna150854)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T15:33:01+00:00

A 10-month-old girl abducted from a New Mexico park Friday has been found safe, authorities said Monday.

## JoJo Siwa reacts to ‘SNL’ poking fun at her new edgy look
 - [https://www.nbcnews.com/pop-culture/pop-culture-news/jojo-siwa-reacts-snl-poking-fun-new-edgy-look-rcna150851](https://www.nbcnews.com/pop-culture/pop-culture-news/jojo-siwa-reacts-snl-poking-fun-new-edgy-look-rcna150851)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T15:28:54+00:00

“Saturday Night Live” tackled JoJo Siwa’s new look during their May 4 show — and the former “Dance Moms” star is taking the jokes in stride.

## Equinox launches $40,000 membership to help you live longer
 - [https://www.nbcnews.com/business/business-news/equinox-launches-40000-membership-help-live-longer-rcna150846](https://www.nbcnews.com/business/business-news/equinox-launches-40000-membership-help-live-longer-rcna150846)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T14:57:45+00:00

High-end fitness chain Equinox is launching one of the most expensive gym memberships in the world — a $40,000-per-year program aimed at improving overall health and longevity.

## Methodists end anti-gay bans, closing 50 years of battles over sexuality for mainline Protestants
 - [https://www.nbcnews.com/nbc-out/out-news/methodists-end-anti-gay-bans-closing-50-years-battles-sexuality-mainli-rcna150836](https://www.nbcnews.com/nbc-out/out-news/methodists-end-anti-gay-bans-closing-50-years-battles-sexuality-mainli-rcna150836)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T14:04:56+00:00

It took just a few days for United Methodist delegates to remove a half-century’s worth of denominational bans on gay clergy and same-sex marriages.

## Former Starbucks CEO says company needs to revamp its stores after big earnings miss
 - [https://www.nbcnews.com/business/business-news/ex-starbucks-ceo-says-company-needs-revamp-stores-earnings-miss-rcna150830](https://www.nbcnews.com/business/business-news/ex-starbucks-ceo-says-company-needs-revamp-stores-earnings-miss-rcna150830)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T13:49:55+00:00

Former Starbucks CEO Howard Schultz weighed in Sunday on the coffee chain’s dismal latest quarterly report, saying he believes the company will recover if it improves its U.S. stores.

## Judge finds Trump further violated gag order and again threatens him with jail 'if necessary'
 - [https://www.nbcnews.com/politics/donald-trump/judge-finds-trump-violated-gag-order-threatens-jail-rcna150560](https://www.nbcnews.com/politics/donald-trump/judge-finds-trump-violated-gag-order-threatens-jail-rcna150560)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T13:47:45+00:00

Judge Juan Merchan on Monday again cited former President Donald Trump for violating the gag order he imposed on the trial and warned he could face jail "if necessary" for continuing to ignore it.

## Tom Brady’s Netflix roast features lots of humor, reunion between Robert Kraft and Bill Belichick
 - [https://www.nbcnews.com/news/us-news/tom-bradys-netflix-roast-features-lots-humor-reunion-robert-kraft-bill-rcna150814](https://www.nbcnews.com/news/us-news/tom-bradys-netflix-roast-features-lots-humor-reunion-robert-kraft-bill-rcna150814)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T11:47:07+00:00

Three months before Tom Brady gets roasted by critics as Fox Sports’ top NFL analyst, he took his share of barbs from comedians, former teammates and his longtime coach Sunday night during a made-for-streaming comedy live event on Netflix.

## IDF urges civilians to evacuate parts of Rafah and Ole Miss opens student conduct investigation: Morning Rundown
 - [https://www.nbcnews.com/news/idf-eastern-rafah-evacuation-morning-rundown-rcna150802](https://www.nbcnews.com/news/idf-eastern-rafah-evacuation-morning-rundown-rcna150802)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T11:07:07+00:00

Israel’s military urges civilians to evacuate parts of Rafah. Ole Miss opens a student conduct investigation.

## Displaced teachers set up tent school in Rafah as Israeli assault looms
 - [https://www.nbcnews.com/news/world/israel-hamas-war-gaza-rafah-invasion-school-tents-teachers-pupils-rcna150163](https://www.nbcnews.com/news/world/israel-hamas-war-gaza-rafah-invasion-school-tents-teachers-pupils-rcna150163)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T10:00:41+00:00

As an Israeli assault on Gaza's southern city of Rafah displaced Palestinians have set up a tent school to help educate children.

## Democrats have beef with a Montana GOP Senate candidate’s cattle ranch
 - [https://www.nbcnews.com/politics/2024-election/democrats-montana-gop-senate-candidate-cattle-ranch-rcna149570](https://www.nbcnews.com/politics/2024-election/democrats-montana-gop-senate-candidate-cattle-ranch-rcna149570)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T10:00:00+00:00

As they navigate a tough 2024 map to maintain their slim Senate majority, Democrats are attempting to frame a key race in Montana around issues with unique resonance in the state: authenticity and access to public land.

## Democrats prepare to go on the offensive on immigration in the coming weeks
 - [https://www.nbcnews.com/politics/immigration/democrats-prepare-go-offensive-immigration-coming-weeks-rcna150781](https://www.nbcnews.com/politics/immigration/democrats-prepare-go-offensive-immigration-coming-weeks-rcna150781)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T10:00:00+00:00

WASHINGTON — Democrats are preparing an aggressive new immigration strategy months after Republicans blocked a bipartisan border security bill aimed at easing record-high illegal crossings along the southern border, according to officials who discussed the plans with NBC News.

## Macron makes Ukraine top priority as China's Xi Jinping visits Europe
 - [https://www.nbcnews.com/news/world/macron-makes-ukraine-top-priority-chinas-xi-jinping-visits-europe-rcna150804](https://www.nbcnews.com/news/world/macron-makes-ukraine-top-priority-chinas-xi-jinping-visits-europe-rcna150804)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T09:40:29+00:00

French President Emmanuel Macron seeks to press China’s Xi Jinping to move Russia toward ending the war in Ukraine during a two-day visit to France.

## North Korea bolsters leader Kim Jong UN with birthday loyalty oaths
 - [https://www.nbcnews.com/news/world/north-korea-bolsters-leader-kim-jong-un-birthday-loyalty-oaths-rcna150805](https://www.nbcnews.com/news/world/north-korea-bolsters-leader-kim-jong-un-birthday-loyalty-oaths-rcna150805)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T09:38:44+00:00

North Koreans were asked to take loyalty oaths on his birthday, a South Korean research institute said, amid other steps the country is taking to solidify his rule.

## Russia announces nuclear weapon drills after angry exchange with senior Western officials
 - [https://www.nbcnews.com/news/world/russia-announces-nuclear-weapon-drills-angry-exchange-senior-western-o-rcna150806](https://www.nbcnews.com/news/world/russia-announces-nuclear-weapon-drills-angry-exchange-senior-western-o-rcna150806)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T09:36:48+00:00

Russia plans to hold drills simulating the use of tactical nuclear weapons, the Defense Ministry announced Monday, days after the Kremlin reacted angrily to comments by senior Western officials about the war in Ukraine.

## French bakers make world’s longest baguette, beating Italy
 - [https://www.nbcnews.com/news/world/french-bakers-make-worlds-longest-baguette-beating-italy-rcna150807](https://www.nbcnews.com/news/world/french-bakers-make-worlds-longest-baguette-beating-italy-rcna150807)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T09:29:08+00:00

French bakers cooked the world’s longest baguette on Sunday at 140.53 meters (461 ft), reclaiming a record for one of the nation’s best-known emblems taken by Italy for five years.

## 3 bodies found in Mexico identified as 2 Australians, American killed in carjacking
 - [https://www.nbcnews.com/news/mexico/3-bodies-found-mexico-identified-missing-surfers-rcna150790](https://www.nbcnews.com/news/mexico/3-bodies-found-mexico-identified-missing-surfers-rcna150790)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T03:24:43+00:00

The remains of three men found near the Mexican fishing port of Ensenada are those of missing surfers from Australia and the U.S. who were killed in an apparent carjacking, authorities said Sunday.

## Person fatally falls from stands during Ohio State graduation
 - [https://www.nbcnews.com/news/us-news/person-fatally-falls-stands-ohio-state-graduation-rcna150787](https://www.nbcnews.com/news/us-news/person-fatally-falls-stands-ohio-state-graduation-rcna150787)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T00:30:02+00:00

A person died after falling from spectator stands to the ground level during Ohio State University's graduation ceremony Sunday in Columbus, school leaders said.

## Kristi Noem suggests Biden's dog Commander should be killed like hers
 - [https://www.nbcnews.com/politics/2024-election/kristi-noem-suggests-bidens-dog-commander-killed-hers-rcna150789](https://www.nbcnews.com/politics/2024-election/kristi-noem-suggests-bidens-dog-commander-killed-hers-rcna150789)
 - RSS feed: https://www.nbcnews.com/feed
 - date published: 2024-05-06T00:04:01+00:00

WASHINGTON — Kristi Noem suggested on Sunday that President Joe Biden's dog Commander should meet a similar fate as her 14-month-old dog Cricket, who the South Dakota governor reportedly described shooting and killing in her upcoming book.

