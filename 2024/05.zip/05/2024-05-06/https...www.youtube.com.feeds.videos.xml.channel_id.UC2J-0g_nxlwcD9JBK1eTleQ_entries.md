# Source:Auto Focus, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2J-0g_nxlwcD9JBK1eTleQ, language:en

## Convincing your parents to get you a Lamborghini is easy…
 - [https://www.youtube.com/watch?v=WwFMzX-8_Tk](https://www.youtube.com/watch?v=WwFMzX-8_Tk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2J-0g_nxlwcD9JBK1eTleQ
 - date published: 2024-05-06T20:59:37+00:00



