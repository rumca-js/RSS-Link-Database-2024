# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## 15 must-see looks from the Met Gala 2024 red carpet
 - [https://www.cbc.ca/life/style/met-gala-fashion-red-carpet-2024-1.7192217?cmp=rss](https://www.cbc.ca/life/style/met-gala-fashion-red-carpet-2024-1.7192217?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T21:41:57+00:00

<img alt="Greta Lee wearing an architectural, sheer white gown; Zendaya wearing a blue and green one-shoulder, mermaid-hem gown; and Wisdom Kaye wearing an all-red suit and hat with a jacket that has a rose on the lapel and a long train." height="349" src="https://i.cbc.ca/1.7196126.1715047036!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/greta-lee-zendaya-and-wisdom-kaye-attend-the-2024-met-gala.jpg" title="Greta Lee, Zendaya and Wisdom Kaye attend the 2024 Met Gala celebrating this year&apos;s Costume Institute exhibition at the Metropolitan Museum of Art, titled &apos;Sleeping Beauties: Reawakening Fashion.&apos;" width="620" /><p>Zendaya, Cardi B, Lana Del Rey and more standouts from one of fashion's biggest nights, the Met Gala, an annual fundraiser for The Costume Institute at the Metropolitan Museum of Art in New York City.</p>

## PWHL Toronto picks Minnesota as 1st-round playoff opponent
 - [https://www.cbc.ca/sports/hockey/pwhl/pwhl-playoffs-toronto-first-round-opponent-1.7195885?cmp=rss](https://www.cbc.ca/sports/hockey/pwhl/pwhl-playoffs-toronto-first-round-opponent-1.7195885?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T20:25:38+00:00

<img alt="Two female hockey players skate on the ice." height="349" src="https://i.cbc.ca/1.7195917.1715040854!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/pwhl-minnesota-vs-toronto.jpg" title="PWHL - Minnesota vs Toronto May 1, 2024 Photo by: Alex D’Addese/PWHL" width="620" /><p>The best-of-5 series between Toronto and Minnesota will begin Wednesday evening in Toronto. Montreal will play Boston in the other semi-final series, which begins Thursday evening in Laval, Que.</p>

## Met Gala 2024: What does ‘Garden of Time’ dress code mean?
 - [https://www.cbc.ca/news/met-gala-2024-what-does-garden-of-time-dress-code-mean-1.7196042?cmp=rss](https://www.cbc.ca/news/met-gala-2024-what-does-garden-of-time-dress-code-mean-1.7196042?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T19:20:00+00:00

<img alt="" height="349" src="https://thumbnails.cbc.ca/maven_legacy/thumbnails/747/439/1-met.jpg" title="" width="620" /><p>The short story behind this year’s Met Gala dress code.</p>

## Canadian military should turn to private sector for space surveillance tech, MPs told
 - [https://www.cbc.ca/news/politics/radarsat-constellation-satellites-military-mda-1.7195713?cmp=rss](https://www.cbc.ca/news/politics/radarsat-constellation-satellites-military-mda-1.7195713?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T16:14:03+00:00

<img alt="A man rides a snowmobile over icy terrain." height="349" src="https://i.cbc.ca/1.3776785.1678031639!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/canada-sovereignty.jpg" title="A Canadian part-time military volunteer drives over the frozen sea past an abandoned landing craft off Cornwallis Island, Nunavut April 9, 2006. He had taken part in a two-week patrol designed to boost Canadian sovereignty in the remote and resource-rich High Arctic. After decades of virtually ignoring its remote, frozen Arctic lands, Canada is belatedly trying to assert its sovereignty over a gigantic region rich in mineral resources. The 1.3 million square miles (3.4 million sq km) of ice, rock and sea comprise 40 percent of Canada&apos;s land mass yet forces stationed there are minuscule -- 190 soldiers, 1700 part-time Inuit volunteers and four small, slow aircraft.  To match feature  Canada-Sovereignty   Photo taken April 9, 2006.  " width="620" /><p>The Canadian military could have mode

## Liberal government tables bill aimed at curbing foreign interference
 - [https://www.cbc.ca/news/politics/foreign-interference-bill-csis-agent-registry-1.7195528?cmp=rss](https://www.cbc.ca/news/politics/foreign-interference-bill-csis-agent-registry-1.7195528?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T15:37:48+00:00

<img alt="Minister of Public Safety, Democratic Institutions and Intergovernmental Affairs Dominic LeBlanc reacts to the Initial Report from the Public Inquiry into Foreign Interference in Federal Electoral Processes and Democratic Institutions in the foyer of the House of Commons on Parliament Hill in Ottawa on Friday, May 3, 2024. " height="349" src="https://i.cbc.ca/1.7195657.1715022833!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/foreign-interference-20240503.jpg" title="Minister of Public Safety, Democratic Institutions and Intergovernmental Affairs Dominic LeBlanc reacts to the Initial Report from the Public Inquiry into Foreign Interference in Federal Electoral Processes and Democratic Institutions in the foyer of the House of Commons on Parliament Hill in Ottawa on Friday, May 3, 2024. " width="620" /><p>The federal government has tabled a bill aimed at countering foreign interference, just days after a public inquiry said attempts by other countries to meddle in Cana

## Incendiary devices found under heavy machinery on Northvolt's future EV battery plant in Quebec
 - [https://www.cbc.ca/news/canada/montreal/incendiary-devices-northvolt-quebec-1.7195624?cmp=rss](https://www.cbc.ca/news/canada/montreal/incendiary-devices-northvolt-quebec-1.7195624?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T15:31:43+00:00

<img alt="Heavy machinery picks up tree trunks with a claw." height="349" src="https://i.cbc.ca/1.7106486.1707244889!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/northvolt.jpg" title="Northvolt has resumed work to clear trees from the site of its future installation in Saint-Basile-le-Grand, Que." width="620" /><p>Swedish manufacturer Northvolt says homemade incendiary devices were found Monday morning under machinery on the site of its future electric vehicle battery plant near Montreal.</p>

## Appeals dismissed for father, son convicted in killings of Métis hunters
 - [https://www.cbc.ca/news/canada/edmonton/appeals-dismissed-for-father-son-found-guilty-of-killings-m%C3%A9tis-hunters-1.7195612?cmp=rss](https://www.cbc.ca/news/canada/edmonton/appeals-dismissed-for-father-son-found-guilty-of-killings-m%C3%A9tis-hunters-1.7195612?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T15:30:10+00:00

<img alt="A courtroom sketch showing a man with a blue shirt and a black tie." height="349" src="https://i.cbc.ca/1.6467474.1709773358!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/anthony-bilodeau.JPG" title="Anthony Bilodeau, 33, spent two days testifying in his own defence at an Edmonton Court of Queen&apos;s Bench second-degree murder trial. His father Roger Bilodeau is co-accused. " width="620" /><p>The Court of Appeal of Alberta has upheld convictions against a father and son found guilty in the shooting deaths of Métis hunters Jacob Sansom and Maurice Cardinal.</p>

## Peter Nygard's extradition appeal dismissed by Manitoba court
 - [https://www.cbc.ca/news/canada/manitoba/peter-nygard-extradition-appeal-dismissed-manitoba-1.7195436?cmp=rss](https://www.cbc.ca/news/canada/manitoba/peter-nygard-extradition-appeal-dismissed-manitoba-1.7195436?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T14:52:10+00:00

<img alt="A white-haired man wears a surgical mask in a screen shot from a video call." height="349" src="https://i.cbc.ca/1.6196363.1674079429!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/peter-nygard.jpg" title="Peter Nygard appeared in court via video conference from the Headingley Correctional Centre in Manitoba on the morning of Friday, Oct. 1, 2021." width="620" /><p>A Manitoba court has dismissed Peter Nygard’s extradition appeal more than a year after the former fashion executive’s lawyers argued their case in court.</p>

## No jail time for Hamilton police officer who sexually assaulted woman he was mentoring, judge rules
 - [https://www.cbc.ca/news/canada/hamilton/michael-lacombe-sex-assault-1.7195412?cmp=rss](https://www.cbc.ca/news/canada/hamilton/michael-lacombe-sex-assault-1.7195412?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T14:24:51+00:00

<img alt="The side of a Hamilton police officer&apos;s uniform." height="349" src="https://i.cbc.ca/1.7188396.1714416610!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/hamilton-police.jpg" title="Hamilton police" width="620" /><p>Michael LaCombe, 54, will instead serve 12 months of house arrest followed by 12 months of probation. He resigned from the Hamilton Police Service after a judge found him guilty of two counts of sexual assault against a woman who he was mentoring to become a police officer.</p>

## Quebec hospital trains nurses, creates new position after man developed fatal bedsore
 - [https://www.cbc.ca/news/canada/montreal/quebec-hospital-saint-j%C3%A9r%C3%B4me-bedsore-corrective-measures-1.7195225?cmp=rss](https://www.cbc.ca/news/canada/montreal/quebec-hospital-saint-j%C3%A9r%C3%B4me-bedsore-corrective-measures-1.7195225?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T13:39:57+00:00

<img alt="A close up photo of a man&apos;s face" height="349" src="https://i.cbc.ca/1.7195235.1715008891!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/normand-meunier.jpg" title="The Laurentian health authority is investigating after Normand Meunier developed a severe bedsore during his hospital stay. He said he preferred putting an end to his physical and psychological suffering by opting for medical assistance in dying in March." width="620" /><p>Weeks after the death of Normand Meunier, who developed a severe bedsore in the Saint-Jérôme hospital, the local health authority has announced new measures and training to better care for patients with disabilities.</p>

## Hamas says it's accepted proposed ceasefire agreement from Qatar, Egypt
 - [https://www.cbc.ca/news/world/israel-hamas-gaza-ceasefire-agreement-1.7195368?cmp=rss](https://www.cbc.ca/news/world/israel-hamas-gaza-ceasefire-agreement-1.7195368?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T13:01:59+00:00

<img alt="People in hooded sweaters stand across the street from the concrete rubble of a building." height="349" src="https://i.cbc.ca/1.7195379.1715014388!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/israel-palestinians-gaza-rafah.JPG" title="Palestinians gather as rescuers search for casualties under the rubble of a house destroyed in an Israeli strike in Rafah, in the southern Gaza Strip, on May 6, 2024." width="620" /><p>Hamas said on Monday that it had accepted a Gaza ceasefire proposal from Egypt and Qatar, though there were no immediate details on what the agreement contained.</p>

## Ontario legislature keffiyeh ban loosened, but not overturned
 - [https://www.cbc.ca/news/canada/toronto/ontario-legislature-keffiyeh-ban-1.7195283?cmp=rss](https://www.cbc.ca/news/canada/toronto/ontario-legislature-keffiyeh-ban-1.7195283?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T11:59:53+00:00

<img alt="Independent MPP Sarah Jama is spoken to in the Ontario legislature on Thursday." height="349" src="https://i.cbc.ca/1.7185189.1714177793!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/mpp-sarah-jama.JPG" title="Independent MPP Sarah Jama is spoken to in the Ontario legislature on Thursday." width="620" /><p>The Speaker of Ontario's legislature says politicians, staff and visitors will be allowed to enter the building while wearing a keffiyeh, but he is upholding his ban on the scarf inside the legislative chamber.</p>

## Number of antisemitic incidents reached record high in 2023, says B'nai Brith Canada audit
 - [https://www.cbc.ca/news/politics/bnai-brith-antisemitic-report-record-high-1.7195197?cmp=rss](https://www.cbc.ca/news/politics/bnai-brith-antisemitic-report-record-high-1.7195197?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T11:58:59+00:00

<img alt="police tape in front of synagogue. " height="349" src="https://i.cbc.ca/1.7020930.1699377243!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/firebombing-synagogue.jpg" title="Police investigators examine the exterior of a synagogue in Dollard-des-Ormeaux, Que., where an incendiary device was ignited overnight Monday. " width="620" /><p>B’nai Brith Canada has released its annual audit that found the number of antisemitic incidents in the country more than doubled from 2022 to 2023 and has now reached record heights. </p>

## Winnipeg man admits to killing 4 women, says not criminally responsible
 - [https://www.cbc.ca/news/canada/manitoba/jeremy-skibicki-trial-judge-1.7195215?cmp=rss](https://www.cbc.ca/news/canada/manitoba/jeremy-skibicki-trial-judge-1.7195215?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T11:34:56+00:00

<img alt="A photo shows a man in a cap looking at the camera." height="349" src="https://i.cbc.ca/1.7193823.1714768176!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/jeremy-skibicki.jpg" title="Jeremy Skibicki is shown in an undated photo provided to CBC. In 2022, Winnipeg police charged him with first-degree murder in the deaths of four women: Morgan Harris, 39, Marcedes Myran, 26, and Rebecca Contois, 24, and a fourth unidentified woman, who has been given the name Mashkode Bizhiki&apos;ikwe, or Buffalo Woman, by community members." width="620" /><p>Jeremy Skibicki has admitted in court that he killed four women in Winnipeg in 2022.</p>

## 'People will be shocked': WNBA star Griner details Russian prison experience in book
 - [https://www.cbc.ca/sports/basketball/brittney-griner-wnba-mercury-book-russian-prison-1.7195186?cmp=rss](https://www.cbc.ca/sports/basketball/brittney-griner-wnba-mercury-book-russian-prison-1.7195186?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T11:11:52+00:00

<img alt="A WNBA player, wearing a Mercury jersey and sporting tattoos on each arm, walks on the court during a break in game action at T-Mobile Arena on September 10, 2023 in Las Vegas, Nevada. " height="349" src="https://i.cbc.ca/1.7195216.1715008210!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/griner-brittney-230910-1180.jpg" title="Brittney Griner&apos;s familiar dreadlocks are gone, she regularly sees a therapist to help her cope after being imprisoned for 10 months, and on Tuesday she&apos;s releasing a book." width="620" /><p>Brittney Griner continues her efforts to settle into a normal routine following her release from a Russian prison 17 months ago. Life isn't what it once was for the perennial WNBA all-star.</p>

## Heavy rains cause deadly flooding in southern Brazil
 - [https://www.cbc.ca/news/world/brazil-rain-flood-rio-grande-do-sul-1.7195015?cmp=rss](https://www.cbc.ca/news/world/brazil-rain-flood-rio-grande-do-sul-1.7195015?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T10:17:35+00:00

<img alt="People reach for two fishing boats are they are rescued during flooding in Brazil." height="349" src="https://i.cbc.ca/1.7195099.1715004712!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/brazil-rains.JPG" title="People are rescued after flooding in Canoas, at the Rio Grande do Sul state, Brazil, May 5, 2024. " width="620" /><p>Brazil's southernmost state of Rio Grande do Sul says flooding has killed at least 83 people and left more than 100 missing.</p>

## Russia says it plans to hold tactical nuclear weapon drills
 - [https://www.cbc.ca/news/world/russia-nuclear-deals-1.7195018?cmp=rss](https://www.cbc.ca/news/world/russia-nuclear-deals-1.7195018?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T09:54:59+00:00

<img alt="Two people covered from head to toe in baggy safety uniforms are shown near a large, cylindrical pointed weapon." height="349" src="https://i.cbc.ca/1.7195046.1715003247!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/russia-nuclear-drills-explainer.jpg" title="FILE In this photo released by Russian Defense Ministry Press Service on Friday, Feb. 2, 2024, Russian troops load an Iskander missile onto a mobile launcher during drills at an undisclosed location in Russia. The Russian Defense Ministry said that the military will hold drills involving tactical nuclear weapons – the first time such exercise was publicly announced by Moscow. " width="620" /><p>Russia plans to hold drills simulating the use of battlefield nuclear weapons, the Defence Ministry announced Monday, days after the Kremlin reacted angrily to comments by senior Western officials about the war in Ukraine.</p>

## Israeli army urges Palestinians to evacuate parts of Rafah ahead of 'limited' action
 - [https://www.cbc.ca/news/world/israel-rafah-evacuation-order-1.7194984?cmp=rss](https://www.cbc.ca/news/world/israel-rafah-evacuation-order-1.7194984?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T06:11:59+00:00

<img alt="A child and an adult whose face isn&apos;t shown together hold up a piece of paper that has Arabic writing on it." height="349" src="https://i.cbc.ca/1.7194986.1714987237!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/israel-palestinians.jpg" title="Palestinians hold leaflets dropped by Israeli planes calling on them to evacuate ahead of an Israeli military operation in Rafah, southern Gaza Strip, Monday, May 6, 2024. The order affects tens of thousands of people and could signal a broader invasion of Rafah, which Israel has identified as Hamas&apos; last major stronghold after seven months of war.  " width="620" /><p>Israel told Palestinians to evacuate parts of Rafah on Monday in what appeared to be preparation for a long-threatened assault on Hamas holdouts in the southern Gaza Strip city where more than a million war-displaced people have been sheltering.</p>

## 'They suck': Sask. MP takes aim at paper straws, tables bill pushing back against single-use plastics ban
 - [https://www.cbc.ca/news/canada/saskatchewan/sask-mp-plastic-versus-paper-straws-1.7193099?cmp=rss](https://www.cbc.ca/news/canada/saskatchewan/sask-mp-plastic-versus-paper-straws-1.7193099?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T05:00:00+00:00

<img alt="A few paper straws wit in a jar labelled &apos;paper straws&apos;" height="349" src="https://i.cbc.ca/1.5052157.1714760907!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/paper-straws.jpg" title="Paper straws at Happy Mama are available for customers to use. " width="620" /><p>Conservative MPs Corey Tochor and Branden Leslie say evidence suggests the push against plastics, including plastic straws, is worse for health, economy and environment. A scientist says the picture is more nuanced.</p>

## India's Hindu nationalists are petitioning courts to tear down mosques and replace them with temples
 - [https://www.cbc.ca/news/world/hindu-nationalists-mosques-india-1.7193591?cmp=rss](https://www.cbc.ca/news/world/hindu-nationalists-mosques-india-1.7193591?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-05-06T04:00:00+00:00

<img alt="Aerial view of Gvanvapi mosque." height="349" src="https://i.cbc.ca/1.7193650.1714764487!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/india-the-resurrected-mughal.jpg" title="An Aerial view shows Gyanvapi mosque, left, and Kashiviswanath temple on the banks of the river Ganges in Varanasi, India, Dec. 12, 2021. The 17th-century mosque in Varanasi, Hinduism&apos;s holiest city, has emerged as the latest flashpoint between Hindus and Muslims. A court case will decide whether the site would be given to Hindus, who claim it was built on a temple destroyed on the orders of Aurangzeb. " width="620" /><p>Gvanvapi mosque in the holy city of Varanasi is one of hundreds of mosques and other Muslim sites being targeted by Hindu nationalist groups in India. The petitioners say they want to restore previously destroyed Hindu holy sites, but some historians accuse the groups of aggressively attempting to rewrite history. </p>

