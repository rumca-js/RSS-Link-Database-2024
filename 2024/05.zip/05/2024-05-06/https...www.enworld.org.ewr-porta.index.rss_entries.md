# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## Here It Comes... The Voidrunner's Codex: A5E in SPACE!
 - [https://www.enworld.org/threads/here-it-comes-the-voidrunners-codex-a5e-in-space.704063](https://www.enworld.org/threads/here-it-comes-the-voidrunners-codex-a5e-in-space.704063)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-05-06T20:05:00+00:00

<div class="bbWrapper">Explore new worlds, fight oppressive empires, fend off fearsome aliens, and use powerful psionics with this comprehensive expansion!</div>

## 2024 D&D Core Rules Will Be Added To SRD In 2025
 - [https://www.enworld.org/threads/2024-d-d-core-rules-will-be-added-to-srd-in-2025.704057](https://www.enworld.org/threads/2024-d-d-core-rules-will-be-added-to-srd-in-2025.704057)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-05-06T17:10:00+00:00

<div class="bbWrapper">SRD 5.2 will be released under Creative Commons next year.</div>

## Play To Lose Yourself In The Zone
 - [https://www.enworld.org/threads/play-to-lose-yourself-in-the-zone.703591](https://www.enworld.org/threads/play-to-lose-yourself-in-the-zone.703591)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-05-06T09:36:00+00:00

<div class="bbWrapper">You won't survive this tragedy of doomed heroes!</div>

## Obsessive Dwarven Adventurer Seeks Rivals
 - [https://www.enworld.org/threads/obsessive-dwarven-adventurer-seeks-rivals.704050](https://www.enworld.org/threads/obsessive-dwarven-adventurer-seeks-rivals.704050)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-05-06T00:00:00+00:00

<div class="bbWrapper">Garr is obsessed with proving that he’s better at it than you are—no matter what it is.</div>

