# Source:RP - Regiony, URL:https://regiony.rp.pl/rss/1441-regiony, language:pl-PL

## Mija czas na zaprzysiężenie nowych włodarzy. Wielu zrobi to w ostatniej chwili
 - [https://regiony.rp.pl/spolecznosci-lokalne/art40300841-mija-czas-na-zaprzysiezenie-nowych-wlodarzy-wielu-zrobi-to-w-ostatniej-chwili](https://regiony.rp.pl/spolecznosci-lokalne/art40300841-mija-czas-na-zaprzysiezenie-nowych-wlodarzy-wielu-zrobi-to-w-ostatniej-chwili)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-05-06T12:39:24+00:00

Pierwsi wybrani w kwietniowych wyborach prezydenci już złożyli ślubowanie i przejęli władzę w miastach. Pozostali muszą to zrobić na pierwszej sesji nowej Rady Miasta, najpóźniej we wtorek.

