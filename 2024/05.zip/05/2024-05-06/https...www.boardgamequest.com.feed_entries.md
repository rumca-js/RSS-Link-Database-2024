# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## BitterSweet Review
 - [https://www.boardgamequest.com/bittersweet-review](https://www.boardgamequest.com/bittersweet-review)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-05-06T15:35:18+00:00

<img alt="BitterSweet" class="webfeedsFeaturedVisual wp-post-image" height="487" src="https://www.boardgamequest.com/wp-content/uploads/2024/02/BitterSweet-1024x779.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="640" />Around the Board Game Quest Discord and many articles, I often make Dad jokes and references to music so a game about chocolates should be a sweet opportunity for plenty of food-related puns. I was all ready to pour some sugar on this review until I saw the chocolate-covered pea pod and realized that this [&#8230;]
<p><a href="https://www.boardgamequest.com/bittersweet-review/" rel="nofollow">Source</a></p>

## Crowdfunding Campaigns of the Week – 5/6/24
 - [https://www.boardgamequest.com/crowdfunding-campaigns-of-the-week-5-6-24](https://www.boardgamequest.com/crowdfunding-campaigns-of-the-week-5-6-24)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-05-06T13:07:49+00:00

<img alt="Crowdfunding Campaigns of the Week" class="webfeedsFeaturedVisual wp-post-image" height="426" src="https://www.boardgamequest.com/wp-content/uploads/2024/05/CcotW-56-1024x682.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="640" />We jump into April with another group of our crowdfunding campaigns to check out. This week we have a nice variety from an expansion for a popular euro game to a game with 3d pieces. Enjoy! And if you missed it on Friday, George released his list of his Top 10 Heroes for the Lord [&#8230;]
<p><a href="https://www.boardgamequest.com/crowdfunding-campaigns-of-the-week-5-6-24/" rel="nofollow">Source</a></p>

