# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik, language:pl-PL

## ⚠️ Uwaga na telefon od &#8220;straży granicznej&#8221;
 - [https://niebezpiecznik.pl/post/powrocil-scam-na-telefon-od-strazy-granicznej](https://niebezpiecznik.pl/post/powrocil-scam-na-telefon-od-strazy-granicznej)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik
 - date published: 2024-05-06T10:28:24+00:00

<a href="https://niebezpiecznik.pl/post/powrocil-scam-na-telefon-od-strazy-granicznej/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2023/11/cyberalert-straz-graniczna-150x150.jpg" width="100" /></a>Obserwujemy zwiększoną liczbę połączeń na polskie numery telefonów od oszustów, którzy podają się za &#8220;Straż Graniczną&#8221;. Połączenia wykonywane są z różnych numerów telefonu, a po ich odebraniu ofiara słyszy nagraną wiadomość, która informuje, że na granicy zatrzymano przesyłkę zaadresowaną do ofiary zawierającą &#8220;nielegalne substancje&#8221;. W wyniku tego wydano &#8220;nakaz aresztowania&#8221;. Ofiara może skontaktować się z oficerem prowadzącym tę sprawę naciskając 1. [&#8230;]

