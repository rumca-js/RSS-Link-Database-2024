# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Hey, Vin Diesel's New Riddick Movie Is Really Happening
 - [https://gizmodo.com/vin-diesel-riddick-4-furya-official-scifi-sequel-1851458968](https://gizmodo.com/vin-diesel-riddick-4-furya-official-scifi-sequel-1851458968)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-05-06T22:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/c2a15df8fae9d6f89b75c488b03c25c5.jpg" /><p>It’s been over a decade since we last caught up with <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/fast-xi-vin-diesel-status-update-universal-1851284300">Vin Diesel</a>’s sci-fi antihero Richard B. Riddick—Diesel’s been spending most of his time voicing <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/guardians-3-spoiler-i-am-groot-gamora-marvel-studios-1850396729">Marvel’s Groot</a> and doing <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/fast-x-review-jason-momoa-vin-diesel-fast-and-furious-1850409790">Fast & Furious movies</a>—but it’s time to dig those goggles out of storage. The fourth film in the series, titled Riddick: Furya, is officially on…</p><p><a href="https://gizmodo.com/vin-diesel-riddick-4-furya-official-scifi-sequel-1851458968

## Breaking Down the Dark Shadows Rising in The Acolyte's New Trailer
 - [https://gizmodo.com/star-wars-acolyte-trailer-breakdown-sith-jedi-disney-1851459538](https://gizmodo.com/star-wars-acolyte-trailer-breakdown-sith-jedi-disney-1851459538)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-05-06T21:30:00+00:00

<video loop="" poster="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/dc17825570f8320b3a8ce0b633c70ce7.jpg"><source src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/dc17825570f8320b3a8ce0b633c70ce7.mp4" type="video/mp4" /></video><p>To <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/hasbro-star-wars-day-reveals-sidious-enoch-black-series-1851454948">celebrate Star Wars Day</a> this past weekend, Lucasfilm treated us all to one more <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-acolyte-star-wars-disney-trailer-2-1851455832">major look at The Acolyte</a>, the next live-action Disney+ series for the galaxy far, far away—one that in equal measure surprises us with a bunch of new tidbits about this new murder mystery among the rise of the dark side, and potently…</p><p><a href="https://gizmodo.com/star-wars-acolyte-trailer-breakdown-sith-jedi-disney-1851459538">Read more...</a></p>

## Boeing Admits That Its Employees Falsified Aircraft Records for 787 Dreamliner
 - [https://gizmodo.com/boeing-admits-employees-falsified-aircraft-records-1851459132](https://gizmodo.com/boeing-admits-employees-falsified-aircraft-records-1851459132)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-05-06T21:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/725981aece6136b1faaa81f1580d62ab.jpg" /><p>In the latest disturbing twist to the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/new-boeing-whistleblower-claims-certain-planes-could-br-1851401224">Boeing saga</a>, the company admitted to falsifying records related to the inspection of its 787 Dreamliner plane. The company publicly disclosed this after news broke of yet another federal investigation into the company. </p><p><a href="https://gizmodo.com/boeing-admits-employees-falsified-aircraft-records-1851459132">Read more...</a></p>

## An Attempt at Reviewing the Rabbit R1
 - [https://gizmodo.com/rabbit-r1-review-ai-companion-performance-1851452097](https://gizmodo.com/rabbit-r1-review-ai-companion-performance-1851452097)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-05-06T20:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4dafa9c29bfca340d2d03aa6ad3581f6.jpg" /><p>I was pretty excited about my <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/r1-rabbit-digital-ai-assistant-apps-1851156804">Rabbit R1</a> review unit and planned on checking it out for a whole week. My plans included using it outside around the city, inside of the house as an all-day companion, and playing around on it with my friends. Sadly, I quickly ran out of things to do on it. It barely offers anything worth…</p><p><a href="https://gizmodo.com/rabbit-r1-review-ai-companion-performance-1851452097">Read more...</a></p>

## William Shatner Wants in on the Creepy De-Aging Trend to Get Back in Star Trek
 - [https://gizmodo.com/star-trek-william-shatner-open-to-de-aged-captain-kirk-1851458429](https://gizmodo.com/star-trek-william-shatner-open-to-de-aged-captain-kirk-1851458429)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-05-06T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/2a495f462df7d4fc85f697dafb81d098.jpg" /><p>Seeing a famous face <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/were-already-de-aging-kids-for-movies-1836908826">appear considerably younger</a> than their actual years <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/disney-ai-art-vfx-visual-effects-de-age-younger-older-1849835548">in a brand-new movie</a> can be startling—<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/indiana-jones-5-review-harrison-ford-dial-of-destiny-1850518708">Indiana Jones and the Dial of Destiny</a>did all right by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/indiana-jones-5-opening-harrison-ford-lucasfilm-ilm-1849808175">Harrison Ford</a>, but even Jeff Bridges shudders at <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec j

## New Fusion Record Achieved in Tungsten-Encased Reactor
 - [https://gizmodo.com/new-fusion-record-achieved-tungsten-encased-reactor-1851457745](https://gizmodo.com/new-fusion-record-achieved-tungsten-encased-reactor-1851457745)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-05-06T14:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/db33f7d069a8c7fcddbadb6aee9606ef.jpg" /><p>A tokamak in New Jersey set a new record in fusion plasma by encasing its reaction in tungsten, a heat-resistant metal that allows physicists to sustain hot plasmas for longer, and at higher energies and densities than carbon tokamaks.<br /></p><p><a href="https://gizmodo.com/new-fusion-record-achieved-tungsten-encased-reactor-1851457745">Read more...</a></p>

## Updates From Alien: Romulus, The Last of Us Season 2, and More
 - [https://gizmodo.com/alien-romulus-new-pictures-cailee-spaeny-xenomorph-1851457401](https://gizmodo.com/alien-romulus-new-pictures-cailee-spaeny-xenomorph-1851457401)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-05-06T13:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a4c34c7ce3a31842c871aed526b42770.png" /><p>Peter Macon talks about Caesar’s legacy in Kingdom of the Planet of the Apes. Get another new look at Jennifer Lopez’s mech movie Atlas. Gen V will rework its season 2 storyline after the tragic passing of Chance Perdomo. Plus, get a new look at the Rick & Morty anime. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/alien-romulus-new-pictures-cailee-spaeny-xenomorph-1851457401">Read more...</a></p>

