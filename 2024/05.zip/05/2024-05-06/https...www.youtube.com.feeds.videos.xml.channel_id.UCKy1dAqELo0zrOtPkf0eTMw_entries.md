# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Superman has red trunks CONFIRMED! #superman #dc #movie #jamesgunn #davidcorenswet #suit
 - [https://www.youtube.com/watch?v=y79BujfoCzY](https://www.youtube.com/watch?v=y79BujfoCzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T23:20:48+00:00



## DARTH JAR JAR IS REAL AND HE CAN HURT YOUSA. #starwars #jarjarbinks #lego #darthvader #darthjarjar
 - [https://www.youtube.com/watch?v=OwzV-zDW9LM](https://www.youtube.com/watch?v=OwzV-zDW9LM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T22:23:26+00:00



## James Gunn Shares First Look at David Corenswet's Superman - IGN The Fix: Entertainment
 - [https://www.youtube.com/watch?v=cJQXOr-PJmU](https://www.youtube.com/watch?v=cJQXOr-PJmU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T21:46:24+00:00

James Gunn has given us our first glimpse of David Corenswet in his Superman costume. James Gunn is set to bring us a new Superman in the Superman movie. The DC Elseworlds is the set of films James Gunn has stated will live outside of his mainline DCU Chapters, similar to its DC Comics counterpart. We’re currently on an 8-10 year long plan to see Chapter One: Gods and Monsters unfold on both the big and small screen. Superman will be the first entry in the rebooted DC cinematic universe, or #DCU, the first chapter of which James Gunn has titled“Gods and Monsters” Would love to know your thoughts on the Superman costume - do you like the turtleneck? Is the side curl working for you? Let us know in the comments, and look out for Superman in theaters July 11th, 2025. We also have an update on Netflix’s One Piece series, and The Boys season 4 teases the return of one of its silent but deadly Supes. This is your Entertainment Fix.

#IGN #Superman

## Sony Reverses Decision On Helldivers 2 PSN Account Requirement - IGN Daily Fix
 - [https://www.youtube.com/watch?v=VFnCKq0LqyQ](https://www.youtube.com/watch?v=VFnCKq0LqyQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T21:33:09+00:00

In today's Daily Fix:

Congratulations, Helldivers! You beat back the might of the Sony corporation, who mandated—undemocratically—that you link a PSN account to your game even when playing on PC. Developer Arrowhead was on the side of the gamers in this fight, even going so far as to suggest players leave negative reviews of Helldivers 2 (which they did) to get the message across to Sony that this was a bad idea. The requirement, had it gone into effect, would have also stopped players in more than a hundred countries from playing the game, seeing as how PSN is not available worldwide. Sony may have reversed course on this decision thanks to the overwhelming response from the community, but the victory may be short-lived, as Sony is making a huge push into the PC gaming space, and may require other Sony-published games to have a PSN account tied to them. In other news, Beat Saber is losing Meta Quest 1 support, which could be a forerunner to other games losing support for the five-ye

## Homelander drinking a certain type of milk in Mortal Kombat 1. #theboys #homelander #milk #mk1 #dlc
 - [https://www.youtube.com/watch?v=trfaJge_iQE](https://www.youtube.com/watch?v=trfaJge_iQE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T20:45:00+00:00



## Hades 2 - Official Early Access Showcase Trailer
 - [https://www.youtube.com/watch?v=4O83d2Y26dI](https://www.youtube.com/watch?v=4O83d2Y26dI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T18:30:05+00:00

Hades 2 is available now in Early Access on Steam and Epic Games Store. Check out the latest trailer for Hades 2 for a closer look at the action roguelite sequel. The trailer showcases what you can expect from this sequel, which features new boons, new foes, a new story, new music, and more.

#IGN #Gaming #Hades2

## 10 Things That Fallout 76: Wastelanders Doesn’t Tell You
 - [https://www.youtube.com/watch?v=vuHOAXwF7yI](https://www.youtube.com/watch?v=vuHOAXwF7yI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T17:54:55+00:00

Welcome to Appalachia, Vault Dweller! Fallout 76’s Wastelanders update radically changed the base game, so whether you’re a brand new player or an old adventurer giving it another go, there are some important things you’ll want to know. Since the game doesn’t always fully explain every little mechanic, we’ve made a list of 10 things that the game doesn’t tell you, but can really help you out there in the wild. 

0:00 - Intro
0:30 - Remodel & Respec
0:59 - The S.P.E.C.I.A.L Limit
1:31 - Picking Perks
2:00 - Crouching In Combat
2:29 - Blue Suitcases
2:57 - Strategic C.A.M.P. Placement
3:28 - Repairing Without Repair Kits
4:07 - Stash Junk Is Automatic
4:38 - How To Hack
5:07 - Photos = Loading Screens
For more Fallout 76, check out our Wiki guide at https://www.ign.com/wikis/fallout-76

## Hades 2 Early Access Review
 - [https://www.youtube.com/watch?v=3c6vNSmEZ70](https://www.youtube.com/watch?v=3c6vNSmEZ70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T17:00:02+00:00

Hades 2 Early Access reviewed by Mitchell Saltzman on PC.

"Even in its Early Access state, Hades 2 is just about everything one could ask for in a sequel to one of the best Roguelites of all time. Featuring excellent refinements to its roguelite progression, a fantastic new main character in Melinoe, and two unique sets of levels that have you fighting foes on the surface and in the underworld."

## LEGO Star Wars: Rebuild the Galaxy - Official Teaser Trailer (2024)
 - [https://www.youtube.com/watch?v=HAkJMWcteCs](https://www.youtube.com/watch?v=HAkJMWcteCs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T16:30:04+00:00

Check out the teaser trailer for LEGO Star Wars: Rebuild the Galaxy, an upcoming "four-piece” animated special featuring the voice talents of Gaten Matarazzo (Sig Greebling), Tony Revolori (Dev Greebling), Bobby Moynihan (Jedi Bob), Marsai Martin (Yesi Scala), Michael Cusack (Servo), Ahmed Best (Darth Jar Jar), and Mark Hamill (Luke Skywalker).

In LEGO Star Wars: Rebuild the Galaxy, the entire Star Wars Galaxy gets completely mixed up when an ordinary nerf-herder, Sig Greebling (Gaten Matarazzo), unearths a powerful artifact from a hidden Jedi temple. He finds himself thrust into adventure in a new, wondrously wild and twisted version of the galaxy where good guys are bad, bad guys are good, and the fate of all depends on Sig becoming the hero who can put all the pieces back together.

Dan Hernandez, Benji Samit, James Waugh, Jacqui Lopez, Josh Rimes, Jill Wilfert, Jason Cosler and Keith Malone are the executive producers. Chris Buckley directs with Daniel Cavey & Dan Langlois produc

## Apex Legends - Official Into The Void Trailer
 - [https://www.youtube.com/watch?v=4GpEGiTZqVI](https://www.youtube.com/watch?v=4GpEGiTZqVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-05-06T16:01:11+00:00

Check out the latest trailer for Apex Legends ahead of the new season, Upheaval. The trailer gives us a look at the Upheaval Battle Pass, customizable Apex Artifacts, and more. Within the void lies unfiltered chaos. Dark secrets, ripe for the taking. Will you surrender to Caustic's master plan and leave humanity behind? 

Apex Legends: Upheaval will be available on PS4 (PlayStation 4), PS5 (PlayStation 5), Xbox One, Xbox Series X/S, Nintendo Switch, and PC via the EA App and Steam on May 7, 2024.

#IGN #Gaming #ApexLegends

