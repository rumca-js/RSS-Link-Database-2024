# Source:Popular Science, URL:https://www.popsci.com/feed, language:en-US

## This road trip storytelling app with voices like Kevin Costner’s is $30 off
 - [https://www.popsci.com/sponsored-content/autio-unlimited-plan-deal](https://www.popsci.com/sponsored-content/autio-unlimited-plan-deal)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T19:28:18+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A person driving with the Autio app pulled up on their phone." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="1080" src="https://www.popsci.com/uploads/2024/05/06/image-1.png?auto=webp&amp;width=1440&amp;height=1080" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Stack Commerce</span></figcaption></figure><p>It automatically plays stories as you drive through new towns.</p>
<p>The post <a href="https://www.popsci.com/sponsored-content/autio-unlimited-plan-deal/">This road trip storytelling app with voices like Kevin Costner&#8217;s is $30 off</a> appeared first on <a href="https://www.popsci.com">Popular Science</a>.</p>

## Save $50 on this dual-camera drone that’s perfect for beginners and kids
 - [https://www.popsci.com/sponsored-content/dual-camera-drone-beginner-kid-friendly-deal](https://www.popsci.com/sponsored-content/dual-camera-drone-beginner-kid-friendly-deal)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T19:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A drone on a plain background." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="800" src="https://www.popsci.com/uploads/2024/05/06/image.png?auto=webp" style="display: block; margin: auto; margin-bottom: 5px;" width="1067" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Stack Commerce</span></figcaption></figure><p>Explore the skies at a surprisingly low price for a limited time.</p>
<p>The post <a href="https://www.popsci.com/sponsored-content/dual-camera-drone-beginner-kid-friendly-deal/">Save $50 on this dual-camera drone that&#8217;s perfect for beginners and kids</a> appeared first on <a href="https://www.popsci.com">Popular Science</a>.</p>

## SpaceX reveals new sleek spacesuits ahead of upcoming historic mission
 - [https://www.popsci.com/science/spacex-eva-suits](https://www.popsci.com/science/spacex-eva-suits)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T18:11:09+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="SpaceX EVA suit helmet close up" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2024/05/06/suit.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">The EVA suit helmet is 3D printed from polycarbonate materials. <span class="orgnc-SingleImage-credit"><a href="https://www.flickr.com/photos/polarisprogramphotos/53698254934/">SpaceX</a></span></figcaption></figure><p>The Extravehicular Activity (EVA) suits will be worn during the Polaris Dawn spacewalk and feature HUD visor displays.</p>
<p>The post <a href="https://www.popsci.com/science/spacex-eva-suits/">SpaceX reveals new sleek spacesuits ahead of upcoming historic mission<

## Upgrade Mom’s movie experience with these deep discounts on XGIMI projectors
 - [https://www.popsci.com/gear/xgimi-projector-mothers-day-amazon-deal](https://www.popsci.com/gear/xgimi-projector-mothers-day-amazon-deal)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T16:55:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="XGIMI Mogo 2 projectors arranged in a pattern on a plain background" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2024/05/06/xgimi-projector-mothers-day-deal.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Stan Horaczek</span></figcaption></figure><p>Take up to 41 percent off some of XGIMI's newest, most popular projectors just in time for the Mother's Day holiday.</p>
<p>The post <a href="https://www.popsci.com/gear/xgimi-projector-mothers-day-amazon-deal/">Upgrade Mom&#8217;s movie experience with these deep discounts on XGIMI projectors</a> appeared first on <a href="https://ww

## Gaze at the gregarious sea lions setting records in San Francisco
 - [https://www.popsci.com/environment/san-francisco-sea-lions](https://www.popsci.com/environment/san-francisco-sea-lions)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T16:03:37+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="a sea lion on its front legs on a pier" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2024/05/06/sea_lion_pier_39.jpg?auto=webp&amp;width=1440&amp;height=810.72" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">San Francisco's Pier 39 has attracted a record number of sea lions this year, according to officials. <span class="orgnc-SingleImage-credit">Tayfun Coskun/Anadolu via Getty Images</span></figcaption></figure><p>Pier 39 hasn't seen this many sea lions since the early 1990s. </p>
<p>The post <a href="https://www.popsci.com/environment/san-francisco-sea-lions/">Gaze at the gregarious sea lions setting records in San Francisco</a> appeared first on <a href="http

## Inside California’s $500 million investment in therapy apps for young people
 - [https://www.popsci.com/health/therapy-apps-young-people](https://www.popsci.com/health/therapy-apps-young-people)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T16:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="teen using phone therapy app" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2024/05/30/therapy-apps-teen.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">The rollout has been slow. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photo/close-up-of-male-hands-with-smartphone-72154939.html">DepositPhotos</a></span></figcaption></figure><p>Advocates fear it won’t pay off.</p>
<p>The post <a href="https://www.popsci.com/health/therapy-apps-young-people/">Inside California&#8217;s $500 million investment in therapy apps for young people</a> appeared first on <a href="https://www.popsci.com">Popular Sc

## Why Venus is so dry
 - [https://www.popsci.com/science/venus-dry](https://www.popsci.com/science/venus-dry)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T15:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The planet Venus is dry thanks to water loss to space as atomic hydrogen. In the dominant loss process, an HCO+ ion recombines with an electron, producing speedy hydrogen atoms (orange) that use CO molecules (blue) as a launchpad to escape." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2024/05/06/venus.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">The planet Venus is dry thanks to water loss to space as atomic hydrogen. In this illustration of the dominant loss process, an HCO+ ion recombines with an electron, producing speedy hydrogen atoms (orange) that use CO molecules (blue) as a launchpad to escape. <span class=

## Ancient mystery code was probably Sargon II’s name
 - [https://www.popsci.com/science/ancient-mystery-code-sargon](https://www.popsci.com/science/ancient-mystery-code-sargon)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T14:49:44+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Assyrian mural image of lion" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2024/05/06/index.jpeg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Late 19th century drawing of an Assyrian lion symbol published by French excavator Victor Place. <span class="orgnc-SingleImage-credit"><a href="https://digitalcollections.nypl.org/items/510d47e2-f687-a3d9-e040-e00a18064a99">New York Public Library</a></span></figcaption></figure><p>A lion, an eagle, a bull, a fig tree, and a plow all came together to point to one of Mesopotamia's greatest rulers.</p>
<p>The post <a href="https://www.popsci.com/science/ancient-mystery-code-sargon/

## Testing the waters: Scotland surges ahead on ocean Power
 - [https://www.popsci.com/environment/ocean-power-scotland](https://www.popsci.com/environment/ocean-power-scotland)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2024-05-06T12:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A tidal stream energy generator called the O2, made by Orbital Marine Power Ltd, extracts energy from the tides off the coast of Scotland and feeds it into the electric grid." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2024/05/30/Orbital-02-generating-at-EMEC-Credit-Orbital-Marine-Power_2000.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">A tidal stream energy generator called the O2, made by Orbital Marine Power Ltd, extracts energy from the tides off the coast of Scotland and feeds it into the electric grid. <span class="orgnc-SingleImage-credit">Orbital Marine Power via Undark</span></figcaption></figure><p>Tidal 

