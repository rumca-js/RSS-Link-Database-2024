# Source:ScreenGeek, URL:https://www.screengeek.net/feed, language:en-US

## Final ‘Fast & Furious’ Movie ‘Fast XI’ Coming In 2026
 - [https://www.screengeek.net/2024/05/06/fast-xi-movie-2026](https://www.screengeek.net/2024/05/06/fast-xi-movie-2026)
 - RSS feed: https://www.screengeek.net/feed
 - date published: 2024-05-06T22:35:23+00:00

<p>The Fast &#38; Furious movie franchise seemed to never have an official end in sight. Now, however, the final film &#8211; Fast XI &#8211; is being slated for a release in 2026. This was confirmed by director Louis Leterrier. As shared at a panel at CCXP MX, which was moderated by Collider&#8217;s Steve Weintraub, shared [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/05/06/fast-xi-movie-2026/">Final &#8216;Fast &#038; Furious&#8217; Movie &#8216;Fast XI&#8217; Coming In 2026</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## First Look At David Corenswet As Superman Revealed By James Gunn
 - [https://www.screengeek.net/2024/05/06/superman-david-corenswet-first-look](https://www.screengeek.net/2024/05/06/superman-david-corenswet-first-look)
 - RSS feed: https://www.screengeek.net/feed
 - date published: 2024-05-06T16:31:14+00:00

<p>The debut of the new Superman suit is now official. As James Gunn&#8217;s Superman (previously titled Superman: Legacy) filming progresses, the writer-director unveiled a sneak peek on his Threads account, revealing star David Corenswet donning the iconic Man of Steel attire. Notably, the suit appears weathered and worn, hinting at intense and gritty battles in [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/05/06/superman-david-corenswet-first-look/">First Look At David Corenswet As Superman Revealed By James Gunn</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

