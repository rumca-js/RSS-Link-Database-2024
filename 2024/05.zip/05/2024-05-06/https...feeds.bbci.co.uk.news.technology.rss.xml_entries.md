# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Acclaimed photographer cracks Instagram in his 80s
 - [https://www.bbc.com/news/articles/c89zeg04w8go](https://www.bbc.com/news/articles/c89zeg04w8go)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-05-06T01:35:11+00:00

Over a seven-decade career David Hurn has photographed everyone from the Beatles to Audrey Hepburn.

