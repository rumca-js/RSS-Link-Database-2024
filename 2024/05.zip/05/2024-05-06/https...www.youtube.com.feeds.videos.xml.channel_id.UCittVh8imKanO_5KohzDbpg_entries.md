# Source:Paul Joseph Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg, language:en-US

## Criticizing Israel illegal?
 - [https://www.youtube.com/watch?v=8MbFckdKvMQ](https://www.youtube.com/watch?v=8MbFckdKvMQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg
 - date published: 2024-05-06T21:46:03+00:00

Please subscribe to the channel for more: https://www.youtube.com/PrisonPlanetLive?sub_confirmation=1

