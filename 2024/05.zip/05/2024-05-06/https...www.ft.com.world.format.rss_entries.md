# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## British military personnel targeted in cyber attack
 - [https://www.ft.com/content/a2ca5644-094d-45a3-b34a-d2b86f203c52](https://www.ft.com/content/a2ca5644-094d-45a3-b34a-d2b86f203c52)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T23:12:26+00:00

Defence secretary Grant Shapps expected to accuse hostile state of being behind the hack

## Wet weather and early Easter damp UK spring sales
 - [https://www.ft.com/content/db437619-dfab-4c5d-bef6-e4145e42d168](https://www.ft.com/content/db437619-dfab-4c5d-bef6-e4145e42d168)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T23:02:20+00:00

Value of retail sales fell at an annual rate of 4% in April, after 3.5% growth in March

## Reeves claims PM ‘gaslighting’ British public over economy
 - [https://www.ft.com/content/5d07cfbb-f529-4eec-9b26-5a48f70c1fae](https://www.ft.com/content/5d07cfbb-f529-4eec-9b26-5a48f70c1fae)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T21:58:23+00:00

Shadow chancellor draws election battle lines ahead of more positive expected economic data

## FirstFT: European leaders press Xi on trade in Paris visit
 - [https://www.ft.com/content/889c26b6-c95a-437b-b4cd-141481812486](https://www.ft.com/content/889c26b6-c95a-437b-b4cd-141481812486)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T21:47:57+00:00

Also in today’s newsletter, Singapore battles to revive struggling stock market, and Hamas accepts hostage-for-prisoner swap proposal

## Global trade growth set to more than double this year
 - [https://www.ft.com/content/3451ba03-28fc-4300-8813-af66bb743bf4](https://www.ft.com/content/3451ba03-28fc-4300-8813-af66bb743bf4)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T20:00:34+00:00

OECD, IMF and WTO all predict sharp rebound in global flows of products this year after 2023 slump

## Brussels seeks to ban Russian funding of European politicians
 - [https://www.ft.com/content/ab480869-684e-4180-bfa6-70266beeca24](https://www.ft.com/content/ab480869-684e-4180-bfa6-70266beeca24)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T18:32:59+00:00

Latest draft sanctions aim to weaken Putin’s war effort in Ukraine and its disinformation campaigns

## Why New York law doesn’t actually matter
 - [https://www.ft.com/content/ad4d5ccb-fc3b-48ac-b81c-3ebf059058b3](https://www.ft.com/content/ad4d5ccb-fc3b-48ac-b81c-3ebf059058b3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T13:10:15+00:00

‘Brickell Bay North’ is shooting itself in the foot

## The ANC treats Anglo American as both national champion and national piñata
 - [https://www.ft.com/content/266d1981-1219-4e16-ac85-999cb6106e93](https://www.ft.com/content/266d1981-1219-4e16-ac85-999cb6106e93)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T12:00:29+00:00

South Africa’s ruling party berates big business one minute and urges it to invest the next

## America must continue to make the moral case for democracy
 - [https://www.ft.com/content/f680a21f-1b3b-4f90-afce-f5575d40ac50](https://www.ft.com/content/f680a21f-1b3b-4f90-afce-f5575d40ac50)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T11:00:30+00:00

The war in Ukraine has led the US to accept the flaws of autocratic allies like Turkey

## John Swinney poised to become Scotland’s first minister
 - [https://www.ft.com/content/03394818-0b89-4307-ab18-1541aacc1f15](https://www.ft.com/content/03394818-0b89-4307-ab18-1541aacc1f15)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T10:50:52+00:00

No challenger is expected to come forward as Scottish National party leader

## Putin orders nuclear drills in response to Macron ‘threats’
 - [https://www.ft.com/content/7219648f-a8df-4f9e-b422-2c62c63af0dd](https://www.ft.com/content/7219648f-a8df-4f9e-b422-2c62c63af0dd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T10:33:00+00:00

Russian armed forces will rehearse use of ‘tactical’ nuclear weapons in combat situations

## My husband, Yves Klein
 - [https://www.ft.com/content/26aaf671-23e6-4a87-bb10-d28b88c3fcd1](https://www.ft.com/content/26aaf671-23e6-4a87-bb10-d28b88c3fcd1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T10:00:29+00:00

As a new exhibition draws the crowds in New York, the artist’s widow Rotraut reflects on why his work still resonates

## UK train passengers face fresh wave of disruption as drivers strike
 - [https://www.ft.com/content/835341ed-c182-4406-9edc-458da3b7e2e4](https://www.ft.com/content/835341ed-c182-4406-9edc-458da3b7e2e4)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T08:34:25+00:00

Walkouts by Aslef union over pay expected to cause significant disruption to services

## A cooler jobs market may not be enough
 - [https://www.ft.com/content/5be904bf-e1ef-410e-90e7-f361e06fa5ba](https://www.ft.com/content/5be904bf-e1ef-410e-90e7-f361e06fa5ba)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T05:30:29+00:00

And utilities revisited

## Macron and Xi to arm-wrestle over EU-China trade tensions
 - [https://www.ft.com/content/b968a08e-23a9-4ffb-957a-655edc23976e](https://www.ft.com/content/b968a08e-23a9-4ffb-957a-655edc23976e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T05:00:29+00:00

Also in this newsletter: the cost of upgrading EU industry for the green transition

## The US housing ‘lock-in effect’ –quantified
 - [https://www.ft.com/content/9fb0b865-2386-41ea-ae20-8f87f8b1b582](https://www.ft.com/content/9fb0b865-2386-41ea-ae20-8f87f8b1b582)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T05:00:29+00:00

And can US mortgages be made portable or assumable?

## Step into the most mind-bending, sense-scrambling arts happening in the world
 - [https://www.ft.com/content/d1d90fe5-b93e-4135-857d-cb50957d6506](https://www.ft.com/content/d1d90fe5-b93e-4135-857d-cb50957d6506)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:30+00:00

A trip (and it is a trip) to teamLab Planets Tokyo, the showstopper exhibition that ingeniously dissolves the boundaries between real and virtual

## UK’s gender pay gap will take decades to close at current rate
 - [https://www.ft.com/content/18f88265-7497-4a72-a4e9-22a829cefec6](https://www.ft.com/content/18f88265-7497-4a72-a4e9-22a829cefec6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:30+00:00

Income inequality between women and men has only narrowed marginally since 2017

## Intrigue: To Catch a Scorpion podcast review — on the trail of the people smugglers
 - [https://www.ft.com/content/8040e9d6-629a-40f7-9eab-9923f46fa8cf](https://www.ft.com/content/8040e9d6-629a-40f7-9eab-9923f46fa8cf)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:29+00:00

Powerful BBC series hears from those who risk their lives to cross the Channel, as well as police and traffickers themselves

## Investment in rail freight imperilled by government and Labour plans
 - [https://www.ft.com/content/f5e86a68-523e-42c6-a477-0d69e362481a](https://www.ft.com/content/f5e86a68-523e-42c6-a477-0d69e362481a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:29+00:00

Freightliner boss says cargo operators must have robust rights to track access to ensure future growth

## Low T-levels uptake in England prompts calls for urgent reform of qualification
 - [https://www.ft.com/content/eb36f4ab-28ce-4083-9b1c-626b19cf3444](https://www.ft.com/content/eb36f4ab-28ce-4083-9b1c-626b19cf3444)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:29+00:00

Flagship skills qualification drew only 1% of 16- to 17-year-old students in 2022

## Number of new homes in England predicted to drop to half of official target
 - [https://www.ft.com/content/6f0acea6-3aeb-488c-948e-9e51375fb940](https://www.ft.com/content/6f0acea6-3aeb-488c-948e-9e51375fb940)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:29+00:00

Savills calls on government to take action to boost housebuilding

## Thames Water causes Redrow legal stink over damaged sewer
 - [https://www.ft.com/content/f9eb3fb3-6703-418e-a3ac-76756eb61717](https://www.ft.com/content/f9eb3fb3-6703-418e-a3ac-76756eb61717)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:29+00:00

Utility accuses housebuilder of ‘negligence’ after sewer blocked with concrete

## The world needs good carbon offsets
 - [https://www.ft.com/content/5c7a79b5-c1e0-4ed2-bd4f-73653dede492](https://www.ft.com/content/5c7a79b5-c1e0-4ed2-bd4f-73653dede492)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:29+00:00

Given some emissions will either be expensive or impossible to abate, it makes sense to start to work on the ‘net’ in net zero

## Xi’s balancing act with Europe
 - [https://www.ft.com/content/c1348c4c-4d6e-41db-be55-1b5eb5b5b4da](https://www.ft.com/content/c1348c4c-4d6e-41db-be55-1b5eb5b5b4da)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T04:00:23+00:00

The Chinese president’s first trip to region since 2019 comes amid rising tensions

## Five of the best ranch homes for sale
 - [https://propertylistings.ft.com/propertynews/united-states/7295-five-of-the-best-ranch-homes-for-sale.html](https://propertylistings.ft.com/propertynews/united-states/7295-five-of-the-best-ranch-homes-for-sale.html)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-05-06T00:07:25+00:00

Saddle up for spectacular scenery and professional riding facilities

