# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## The State Of Batman In Video Games
 - [https://www.youtube.com/watch?v=LuQdpeM3gfQ](https://www.youtube.com/watch?v=LuQdpeM3gfQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-05-06T18:31:09+00:00

What do you want from the next Batman game?

## Hades II - Early Access Floor 2 Gameplay
 - [https://www.youtube.com/watch?v=XJv3HtQnHSg](https://www.youtube.com/watch?v=XJv3HtQnHSg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-05-06T18:00:14+00:00

We head through Oceanus, the second level in Hades II using a Poseidon special projectile build to melt everyone in our path.

## Game Mess Mornings 05/06/24
 - [https://www.youtube.com/watch?v=5BjJ36a3HMM](https://www.youtube.com/watch?v=5BjJ36a3HMM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-05-06T14:52:13+00:00

Jeff Grubb and friends break down today's top stories in video game news! 

#gmm #gamemessmornings #giantbomb

## Mortal Kombat 1 Homelander Official Reveal Trailer
 - [https://www.youtube.com/watch?v=rr54phlIlgI](https://www.youtube.com/watch?v=rr54phlIlgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-05-06T03:23:59+00:00

Homelander is coming to Mortal Kombat 1!

The Boys Season 4 premieres June 13.

