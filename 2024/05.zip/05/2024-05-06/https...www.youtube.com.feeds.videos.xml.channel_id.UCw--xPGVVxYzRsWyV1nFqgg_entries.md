# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Kendrick Vs Drake Oversimplified For Nerds
 - [https://www.youtube.com/watch?v=4vv7WB2av2c](https://www.youtube.com/watch?v=4vv7WB2av2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2024-05-06T00:38:31+00:00

I don't want any of ya'll confused so I did the research, dove into the beef, and found a comparison that works on a few levels! 
New second channel: https://www.youtube.com/channel/UCC-EqiFg67s2Nd0imgRXg5w 

My books
Neon Ghosts: https://shop.wraithmarked.com/collections/standard-editions-1/products/neon-ghosts-a-witchs-sin-hardcover
Breach of Peace: https://tinyurl.com/BoPTLT  
Rebels Creed: https://tinyurl.com/RCTLTDG 
merch: https://www.danielbgreene.com

Patreon: https://www.patreon.com/DanielBGreene 
Join the Discord here: https://discord.gg/xUrPj6EP3f
All the Me Social Links: https://linktr.ee/DanielGreene

