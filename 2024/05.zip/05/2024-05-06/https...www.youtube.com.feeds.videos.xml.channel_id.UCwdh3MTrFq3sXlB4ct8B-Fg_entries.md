# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Skittering Snipers Open Fire – Warhammer Age of Sigmar
 - [https://www.youtube.com/watch?v=7MkqVH9fJjg](https://www.youtube.com/watch?v=7MkqVH9fJjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2024-05-06T13:00:44+00:00

It's a long shot, but we thought you might want to see some more rats! 🐀 Meet the jezzail crew: 

Follow for more Warhammer, more often:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/

