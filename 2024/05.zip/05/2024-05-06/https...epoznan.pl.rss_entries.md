# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Urządzili w czynie społecznym sąsiedzki ogródek. &quot;Gdy inni obiecują, my działamy&quot;
 - [https://epoznan.pl/news-news-150562-urzadzili_w_czynie_spolecznym_sasiedzki_ogrodek_gdy_inni_obiecuja_my_dzialamy?rss=1](https://epoznan.pl/news-news-150562-urzadzili_w_czynie_spolecznym_sasiedzki_ogrodek_gdy_inni_obiecuja_my_dzialamy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T20:27:00+00:00

Sąsiedzi z Łazarza działali dziś społecznie przy ul. Dmowskiego.

## Zmarł pies, który został otruty. Właścicielka psa zaapelowała do innych mieszkańców, żeby uważali na spacerach z pupilami
 - [https://epoznan.pl/news-news-150561-zmarl_pies_ktory_zostal_otruty_wlascicielka_psa_zaapelowala_do_innych_mieszkancow_zeby_uwazali_na_spacerach_z_pupilami?rss=1](https://epoznan.pl/news-news-150561-zmarl_pies_ktory_zostal_otruty_wlascicielka_psa_zaapelowala_do_innych_mieszkancow_zeby_uwazali_na_spacerach_z_pupilami?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T17:57:00+00:00

Mieszkanka Rataj wystosowała apel do wszystkich właścicieli psów.

## Organizują warsztaty, na których nauczą, jak robić własne woreczki na owoce i warzywa
 - [https://epoznan.pl/news-news-150560-organizuja_warsztaty_na_ktorych_naucza_jak_robic_wlasne_woreczki_na_owoce_i_warzywa?rss=1](https://epoznan.pl/news-news-150560-organizuja_warsztaty_na_ktorych_naucza_jak_robic_wlasne_woreczki_na_owoce_i_warzywa?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T17:35:00+00:00

Będzie też szycie i zdobienie woreczków.

## Tragiczny wypadek z udziałem motocyklisty. Młody mężczyzna zmarł na miejscu
 - [https://epoznan.pl/news-news-150559-tragiczny_wypadek_z_udzialem_motocyklisty_mlody_mezczyzna_zmarl_na_miejscu?rss=1](https://epoznan.pl/news-news-150559-tragiczny_wypadek_z_udzialem_motocyklisty_mlody_mezczyzna_zmarl_na_miejscu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T17:11:00+00:00

Do tragedii doszło w poniedziałek pod Kaliszem na drodze wojewódzkiej 470, w miejscowości Nowe Prażuchy.

## Grupka mężczyzn przechodziła obok parkingu i kopała w drzwi wszystkich samochodów. W Internecie pojawiło się nagranie
 - [https://epoznan.pl/news-news-150558-grupka_mezczyzn_przechodzila_obok_parkingu_i_kopala_w_drzwi_wszystkich_samochodow_w_internecie_pojawilo_sie_nagranie?rss=1](https://epoznan.pl/news-news-150558-grupka_mezczyzn_przechodzila_obok_parkingu_i_kopala_w_drzwi_wszystkich_samochodow_w_internecie_pojawilo_sie_nagranie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T16:09:00+00:00

Do zdarzenia doszło w nocy z piątku na sobotę około godziny 2:00 na ul. Fabrycznej.

## We wtorek nastąpi uroczyste otwarcie 120-letniego budynku. To z okazji 105. rocznicy utworzenia Uniwersytetu i Wydziału Prawa
 - [https://epoznan.pl/news-news-150557-we_wtorek_nastapi_uroczyste_otwarcie_120_letniego_budynku_to_z_okazji_105_rocznicy_utworzenia_uniwersytetu_i_wydzialu_prawa?rss=1](https://epoznan.pl/news-news-150557-we_wtorek_nastapi_uroczyste_otwarcie_120_letniego_budynku_to_z_okazji_105_rocznicy_utworzenia_uniwersytetu_i_wydzialu_prawa?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T15:30:00+00:00

Chodzi o budynek Collegium Rubrum przy Al. Niepodległości.

## Wilda: &quot;awaria prądu&quot;. Chwilowo wstrzymany został ruch tramwajowy
 - [https://epoznan.pl/news-news-150556-wilda_awaria_pradu_chwilowo_wstrzymany_zostal_ruch_tramwajowy?rss=1](https://epoznan.pl/news-news-150556-wilda_awaria_pradu_chwilowo_wstrzymany_zostal_ruch_tramwajowy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T14:00:00+00:00

W poniedziałek po godzinie 15:00 stanęły tramwaje.

## Policjanci prowadzą poszukiwania i publikują zdjęcia mężczyzny i samochodu
 - [https://epoznan.pl/news-news-150554-policjanci_prowadza_poszukiwania_i_publikuja_zdjecia_mezczyzny_i_samochodu?rss=1](https://epoznan.pl/news-news-150554-policjanci_prowadza_poszukiwania_i_publikuja_zdjecia_mezczyzny_i_samochodu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T12:55:00+00:00

Miał zapłacić fałszywym banknotem.

## Nietypowi goście za murami więzienia
 - [https://epoznan.pl/news-news-150553-nietypowi_goscie_za_murami_wiezienia?rss=1](https://epoznan.pl/news-news-150553-nietypowi_goscie_za_murami_wiezienia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T12:45:00+00:00

To forma terapii.

## Duża inwestycja na finiszu. W Poznaniu powstają nowoczesne bloki gazowe, już w maju będą testowane
 - [https://epoznan.pl/news-news-150550-duza_inwestycja_na_finiszu_w_poznaniu_powstaja_nowoczesne_bloki_gazowe_juz_w_maju_beda_testowane?rss=1](https://epoznan.pl/news-news-150550-duza_inwestycja_na_finiszu_w_poznaniu_powstaja_nowoczesne_bloki_gazowe_juz_w_maju_beda_testowane?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T12:30:00+00:00

Prace przy budowie dwóch nowych bloków gazowych na terenie poznańskiej elektrociepłowni
weszły w finalną fazę.

## 10. urodziny poznańskiej zajezdni. &quot;Wraz z rozwojem miasta i inwestycjami w tabor tramwajowy potrzeba stała się paląca&quot;
 - [https://epoznan.pl/news-news-150551-10_urodziny_poznanskiej_zajezdni_wraz_z_rozwojem_miasta_i_inwestycjami_w_tabor_tramwajowy_potrzeba_stala_sie_palaca?rss=1](https://epoznan.pl/news-news-150551-10_urodziny_poznanskiej_zajezdni_wraz_z_rozwojem_miasta_i_inwestycjami_w_tabor_tramwajowy_potrzeba_stala_sie_palaca?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T12:15:00+00:00

Mowa o zajezdni na Franowie.

## 10. urodziny poznańskiej zajezdni. Tak wyglądała w 2014 roku
 - [https://epoznan.pl/news-news-150551-10_urodziny_poznanskiej_zajezdni_tak_wygladala_w_2014_roku?rss=1](https://epoznan.pl/news-news-150551-10_urodziny_poznanskiej_zajezdni_tak_wygladala_w_2014_roku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T12:15:00+00:00

Mowa o zajezdni na Franowie.

## Akcja służb na Dolnej Wildzie. Nie kursowały tramwaje
 - [https://epoznan.pl/news-news-150552-akcja_sluzb_na_dolnej_wildzie_nie_kursowaly_tramwaje?rss=1](https://epoznan.pl/news-news-150552-akcja_sluzb_na_dolnej_wildzie_nie_kursowaly_tramwaje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T12:05:00+00:00

W pojeździe upadła pasażerka.

## Akcja służb na Górnej Wildzie. Nie kursowały tramwaje
 - [https://epoznan.pl/news-news-150552-akcja_sluzb_na_gornej_wildzie_nie_kursowaly_tramwaje?rss=1](https://epoznan.pl/news-news-150552-akcja_sluzb_na_gornej_wildzie_nie_kursowaly_tramwaje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T12:05:00+00:00

W pojeździe upadła pasażerka.

## Nowość w poznańskim szpitalu. Zadowolone będą szczególnie osoby, którym brakuje czasu na zrobienie badań
 - [https://epoznan.pl/news-news-150548-nowosc_w_poznanskim_szpitalu_zadowolone_beda_szczegolnie_osoby_ktorym_brakuje_czasu_na_zrobienie_badan?rss=1](https://epoznan.pl/news-news-150548-nowosc_w_poznanskim_szpitalu_zadowolone_beda_szczegolnie_osoby_ktorym_brakuje_czasu_na_zrobienie_badan?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T11:30:00+00:00

Już w najbliższą sobotę dla pacjentów otworzy się punkt pobrań w szpitalu im. J. Strusia przy ulicy Szwajcarskiej.

## Zmasowana akcja policji. Rano w Poznaniu i okolicach zatrzymywali kierowców
 - [https://epoznan.pl/news-news-150549-zmasowana_akcja_policji_rano_w_poznaniu_i_okolicach_zatrzymywali_kierowcow?rss=1](https://epoznan.pl/news-news-150549-zmasowana_akcja_policji_rano_w_poznaniu_i_okolicach_zatrzymywali_kierowcow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T11:30:00+00:00

Niektórzy nie powinni wsiadać za kierownicę.

## Kobieta oddaliła się ze szpitala. W samej koszuli nocnej błąkała się po ulicach Poznania
 - [https://epoznan.pl/news-news-150547-kobieta_oddalila_sie_ze_szpitala_w_samej_koszuli_nocnej_blakala_sie_po_ulicach_poznania?rss=1](https://epoznan.pl/news-news-150547-kobieta_oddalila_sie_ze_szpitala_w_samej_koszuli_nocnej_blakala_sie_po_ulicach_poznania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T11:00:00+00:00

Strażnicy miejscy podsumowują majówkę.

## Potężny pożar prawdopodobnie nie był samozapłonem. Zatrzymano poznaniaka
 - [https://epoznan.pl/news-news-150546-potezny_pozar_prawdopodobnie_nie_byl_samozaplonem_zatrzymano_poznaniaka?rss=1](https://epoznan.pl/news-news-150546-potezny_pozar_prawdopodobnie_nie_byl_samozaplonem_zatrzymano_poznaniaka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T10:30:00+00:00

Do zdarzenia doszło w połowie kwietnia w miejscowości Czacz w powiecie kościańskim.

## Rusza remont ważnej trasy w okolicach Poznania. Niebawem spore utrudnienia
 - [https://epoznan.pl/news-news-150545-rusza_remont_waznej_trasy_w_okolicach_poznania_niebawem_spore_utrudnienia?rss=1](https://epoznan.pl/news-news-150545-rusza_remont_waznej_trasy_w_okolicach_poznania_niebawem_spore_utrudnienia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T10:00:00+00:00

W Owińskach.

## Kto ma szansę zostać zastępcą prezydenta Poznania? Platforma Obywatelska zabrała głos
 - [https://epoznan.pl/news-news-150543-kto_ma_szanse_zostac_zastepca_prezydenta_poznania_platforma_obywatelska_zabrala_glos?rss=1](https://epoznan.pl/news-news-150543-kto_ma_szanse_zostac_zastepca_prezydenta_poznania_platforma_obywatelska_zabrala_glos?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T09:30:00+00:00

Padły konkretne nazwiska.

## Tragiczny majowy weekend na drogach. Zginęły cztery osoby
 - [https://epoznan.pl/news-news-150542-tragiczny_majowy_weekend_na_drogach_zginely_cztery_osoby?rss=1](https://epoznan.pl/news-news-150542-tragiczny_majowy_weekend_na_drogach_zginely_cztery_osoby?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T09:00:00+00:00

Policjanci w Wielkopolsce podsumowali pierwszych pięć dni maja.

## Rolnicy zapowiedzieli kolejny protest w centrum Poznania
 - [https://epoznan.pl/news-news-150539-rolnicy_zapowiedzieli_kolejny_protest_w_centrum_poznania?rss=1](https://epoznan.pl/news-news-150539-rolnicy_zapowiedzieli_kolejny_protest_w_centrum_poznania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T08:30:00+00:00

Już w najbliższą środę.

## Wandale w zabytkowym poznańskim dworku. &quot;Przestępcy zburzyli mur i wybili szybę&quot;
 - [https://epoznan.pl/news-news-150540-wandale_w_zabytkowym_poznanskim_dworku_przestepcy_zburzyli_mur_i_wybili_szybe?rss=1](https://epoznan.pl/news-news-150540-wandale_w_zabytkowym_poznanskim_dworku_przestepcy_zburzyli_mur_i_wybili_szybe?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T08:00:00+00:00

Na Krzesinach.

## Pod Poznaniem szukają kandydatki na Białą Damę. Przez rok czeka na nią szereg przywilejów i sława
 - [https://epoznan.pl/news-news-150536-pod_poznaniem_szukaja_kandydatki_na_biala_dame_przez_rok_czeka_na_nia_szereg_przywilejow_i_slawa?rss=1](https://epoznan.pl/news-news-150536-pod_poznaniem_szukaja_kandydatki_na_biala_dame_przez_rok_czeka_na_nia_szereg_przywilejow_i_slawa?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T07:30:00+00:00

Chętne mogą  się zgłaszać do połowy maja.

## Nietypowa akcja przed Urzędem Wojewódzkim w Poznaniu
 - [https://epoznan.pl/news-news-150537-nietypowa_akcja_przed_urzedem_wojewodzkim_w_poznaniu?rss=1](https://epoznan.pl/news-news-150537-nietypowa_akcja_przed_urzedem_wojewodzkim_w_poznaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T07:00:00+00:00

Poleje się krew.

## Spore uderzenie w narkobiznes. Zlikwidowano imponującą plantację w Stęszewie
 - [https://epoznan.pl/news-news-150533-spore_uderzenie_w_narkobiznes_zlikwidowano_imponujaca_plantacje_w_steszewie?rss=1](https://epoznan.pl/news-news-150533-spore_uderzenie_w_narkobiznes_zlikwidowano_imponujaca_plantacje_w_steszewie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T06:30:00+00:00

Policjanci zlikwidowali dużą plantację konopi i wytwórnię marihuany.

## Wielkie uderzenie w narkobiznes! Rozbito gang
 - [https://epoznan.pl/news-news-150533-wielkie_uderzenie_w_narkobiznes_rozbito_gang?rss=1](https://epoznan.pl/news-news-150533-wielkie_uderzenie_w_narkobiznes_rozbito_gang?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T06:30:00+00:00

Policjanci zlikwidowali dużą plantację konopi i wytwórnię marihuany.

## Włóczkersi mają zlot w Poznaniu
 - [https://epoznan.pl/news-news-150532-wloczkersi_maja_zlot_w_poznaniu?rss=1](https://epoznan.pl/news-news-150532-wloczkersi_maja_zlot_w_poznaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T06:00:00+00:00

Będą dziergać.

## Od dziś kursuje nowa linia!
 - [https://epoznan.pl/news-news-150531-od_dzis_kursuje_nowa_linia?rss=1](https://epoznan.pl/news-news-150531-od_dzis_kursuje_nowa_linia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T05:30:00+00:00

Zmian będzie więcej.

## Poranna ewakuacja poznańskiego dworca
 - [https://epoznan.pl/news-news-150535-poranna_ewakuacja_poznanskiego_dworca?rss=1](https://epoznan.pl/news-news-150535-poranna_ewakuacja_poznanskiego_dworca?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-06T05:15:00+00:00

Podróżni usłyszeli komunikat.

