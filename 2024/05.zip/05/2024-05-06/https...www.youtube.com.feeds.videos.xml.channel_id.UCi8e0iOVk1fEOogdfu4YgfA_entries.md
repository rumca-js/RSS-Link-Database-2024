# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## Kingdom of the Planet of the Apes TV Spot - Our Time (2024)
 - [https://www.youtube.com/watch?v=27wOOztq3I0](https://www.youtube.com/watch?v=27wOOztq3I0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-05-06T19:03:30+00:00

Check out the official trailer for Kingdom of the Planet of the Apes starring Freya Allan! 

► Buy Tickets on Fandango: https://www.fandango.com/kingdom-of-the-planet-of-the-apes-2024-234087/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: May 10, 2024 
Starring: Freya Allan, Kevin Durand, Owen Teague
Director: Wes Ball
Synopsis: Many years after the reign of Caesar, a young ape goes on a journey that will lead him to question everything he's been taught about the past and make choices that will define a future for apes and humans alike.

► Learn more: https://www.rottentomatoes.com/m/kingdom_of_the_planet_of_the_apes?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV Th

