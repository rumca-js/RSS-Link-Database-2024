# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## Watch: Bus Driver Violently Assaulted On Los Angeles Metro Just Days After 'Sick-Out' Over Out Of Control Crime
 - [https://www.louderwithcrowder.com/sick-out-attack](https://www.louderwithcrowder.com/sick-out-attack)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T22:03:54+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52182534&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>Brazen attacks in Los Angeles have become the status quo.  A lot of this has to do with the culture of lawlessness that LA progressives condone. And because officials believe the compassionate thing to do is allow drug-addicted individuals, as well as those who are severely mentally ill, to be able to run a muck with no accountability, we have this story for you. </p><p>Law-abiding citizens can only take so much, especially when one is forced to face this dystopia for a living. People often say how hard of a job police officers have. And although that is true, can you imagine what it's like to be a bus driver in Los Angeles? Obviously, it's so bad that over 360 bus operators, which is 10 percent of the workforce, held a "<a href="https://abc7.com/la-metro-responds-to-possible-sick-out-by-drivers-following-recent-assaults/147606

## NYC is kicking out illegals in preparation for a ‚Äúsummer surge‚Äù of... more illegals
 - [https://www.louderwithcrowder.com/nyc-summer-surge](https://www.louderwithcrowder.com/nyc-summer-surge)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T21:36:16+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=52182537&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C200%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>When you announce to the world that you are a ‚Äúsanctuary‚Äù for those who <a href="https://www.heritage.org/education/report/the-consequences-unchecked-illegal-immigration-americas-public-schools" target="_blank">break </a>federal immigration laws, so much so that you even give them<a href="https://nypost.com/2024/02/06/opinion/nycs-migrant-crisis-hits-new-level-of-madness-free-rooms-meals-to-thugs-who-are-robbing-us/" target="_blank"> free shelter and food</a>, you will obviously attract a ‚Äúsummer surge‚Äù of ‚Äúnewcomers.‚Äù </p><p>The <a href="https

## NYC Judge Releases Psycho Who Randomly Sucker-Punched A Mom, Then Suddenly Retires Two Years Early And Moves To Florida
 - [https://www.louderwithcrowder.com/sciarrino-florida-nyc](https://www.louderwithcrowder.com/sciarrino-florida-nyc)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T20:11:53+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52182024&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>It‚Äôs not uncommon to see New York City officials run away from the policies they promote that have helped turn NYC into total progressive ruin. Although that is pathetic on its own, what‚Äôs even more foolish is that they often do so by moving to the most Republican-run areas. Thus, we have this story for you. </p><p>A mother of three was randomly punched in the face by a psycho who broke her jaw. Brooklyn Supreme Court Justice Matthew Sciarrino decided to let the man responsible for this free. Before this, he also let a suspected murderer out. So as you

## Austin City Council Vows To Become Trans Sanctuary For Your Underage Children
 - [https://www.louderwithcrowder.com/austin-trans-sanctuary](https://www.louderwithcrowder.com/austin-trans-sanctuary)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T18:29:09+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=52181532&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Progressives tend to not like this little thing called ‚Äústate law.‚Äù That is why we often see them admittedly <a href="https://www.ncsl.org/immigration/sanctuary-policy-faq#:~:text=Only%20three%20states%E2%80%94California%2C%20Iowa,purposes%20of%20civil%20immigration%20custody." target="_blank">oppose </a>legislation to the point that an entire city or state has dubbed itself a ‚Äúsanctuary‚Äù to defy that law. Subsequently, we now have another city declaring itself a trans sanctuary for minors, with emphasis on the part that is dedicated to children. </p

## Chicago Teachers Union $50 BILLION Worth Of Demands, Includes Funding For Abortion Services And Housing For Migrants
 - [https://www.louderwithcrowder.com/migrants-teachers-chicago](https://www.louderwithcrowder.com/migrants-teachers-chicago)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T17:29:53+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=52180101&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>There is no doubt that Chicago Public Schools have earned the title of being the <a href="https://www.chicagotribune.com/1987/11/08/education-chief-city-schools-worst/" rel="noopener noreferrer" target="_blank"><u>worst in the nation</u></a> many times in the past, and a lot of that has to do with the fact that union officials could care less about education. And when you combine one of the most <a href="https://www.illinoispolicy.org/chicago-teachers-union-sees-plenty-of-scandals-in-2023/" target="_blank">corrupt </a>unions in the nation with a town that 

## "Those people, when facing real consequences, will be cowards": The truth about Pro-Hamas college activism
 - [https://www.louderwithcrowder.com/anti-israel-protestors-students](https://www.louderwithcrowder.com/anti-israel-protestors-students)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T16:29:23+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52179816&amp;width=1200&amp;height=400&amp;coordinates=0%2C93%2C0%2C201" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Pro-Hamas protests are still <a href="https://www.cnn.com/business/live-news/university-protests-pro-palestinian-israel-05-06-24/index.html" target="_blank">ongoing </a>and some students are learning that ‚Äústanding up for something you believe in‚Äù has a cost, as their entitled reality is crumbling around them. Today‚Äôs show breaks it down. </p><p>While some colleges are allowing brats to continue blocking Jewish students from class, and have even <a href="https://www.aljazeera.com/news/2024/5/6/columbia-university-cancels-main-commencement-ceremony-a

## Trump embraces "frat boy summer," drops new fire campaign ad celebrating patriotic college students defending our flag
 - [https://www.louderwithcrowder.com/donald-trump-frat-boy-summer](https://www.louderwithcrowder.com/donald-trump-frat-boy-summer)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T11:49:24+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52178597&amp;width=1200&amp;height=600&amp;coordinates=0%2C80%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>The pro-Hamas protests that started on October 8th and have continued on through this past weekend have gone from your typical hissy fit from future Democrat staffers to a new front in the culture war. <a href="https://www.louderwithcrowder.com/unc-pro-palestine-american-flag" target="_blank">All it took was frat boys saving the American flag from progressives who wanted to tear it down</a>. Remember, as Mr. Rogers taught us, when you see scary things in the news, look for the helpers because you will always find people who are helping. The helpers are wear

## Watch: Did Joe Biden poop his pants in front of the press this weekend? An investigation
 - [https://www.louderwithcrowder.com/joe-biden-walking-to-marine-one](https://www.louderwithcrowder.com/joe-biden-walking-to-marine-one)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T10:45:57+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52178504&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C80" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Reports of Joe Biden, the President of the United States and our Commander-in-Chief, sh*tting himself are once again plaguing the octogenarian. Walking to Marine One with what his supporters in the media refer to as his "halting and stiff gait," Biden suddenly stopped and squatted in a visual all too familiar to any American who has ever been around a toddler.</p><p>It was captured on video.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">üö® Crowd chants ‚ÄúUSA‚Äù for Trump at the Formula 1 Miami Grand Prix<br /><br /> <a href="http

## Sources: Who is Trump's VP? The Short List is Here (and Kristi Noem Self-Destructs)
 - [https://www.louderwithcrowder.com/sources-may-6th-2024](https://www.louderwithcrowder.com/sources-may-6th-2024)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-05-06T10:00:00+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52179151&amp;width=1200&amp;height=400&amp;coordinates=0%2C102%2C0%2C338" /><br /><br /><p>The Biden White House aims to resettle Palestinian refugees in America in their latest election pandering effort, Donald Trump‚Äôs Vice Presidential contenders were at Mar-a-Lago this weekend, South Dakota Governor Kristi Noem is in hot water for telling the world about shooting her dog and is making things worse by lying about having met Kim Jong Un, Vietnam War veteran Paul Morgan saved a friend‚Äôs life after they collapsed outside a Kentucky Walmart, and more! </p><p>
<em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><div class="rm-embed embed-media"></div><p><strong>VP POTENTIALS</strong><br /></p><ul

