# Source:Simon Willison's Weblog, URL:https://simonwillison.net/atom/everything, language:en-us

## Quoting Charity Majors
 - [https://simonwillison.net/2024/May/6/charity-majors/#atom-everything](https://simonwillison.net/2024/May/6/charity-majors/#atom-everything)
 - RSS feed: https://simonwillison.net/atom/everything
 - date published: 2024-05-06T13:52:21+00:00

<blockquote cite="https://twitter.com/mipsytipsy/status/1778534529298489428"><p>Migrations are not something you can do rarely, or put off, or avoid; not if you are a growing company. Migrations are an ordinary fact of life.<br /><br />Doing them swiftly, efficiently, and -- most of all -- *completely* is one of the most critical skills you can develop as a team.</p></blockquote><p class="cite">&mdash; <a href="https://twitter.com/mipsytipsy/status/1778534529298489428">Charity Majors</a>

