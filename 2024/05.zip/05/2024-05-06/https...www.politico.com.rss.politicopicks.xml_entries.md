# Source:Politico News Top Stories, URL:https://www.politico.com/rss/politicopicks.xml, language:en-us

## Putin rattles his atomic saber by ordering nuclear weapons drills
 - [https://www.politico.eu/article/russia-preparing-non-strategic-nuclear-weapons-drills](https://www.politico.eu/article/russia-preparing-non-strategic-nuclear-weapons-drills)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T23:33:41.180592+00:00

Kyiv denounces the exercises as “nuclear blackmail.”

## Moscow threatens to strike British military facilities following Cameron’s remarks
 - [https://www.politico.eu/article/russia-threaten-strike-british-military-facility-david-camerons-remark-war-ukraine](https://www.politico.eu/article/russia-threaten-strike-british-military-facility-david-camerons-remark-war-ukraine)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T23:33:36.641521+00:00

The foreign secretary's words confirm London's growing involvement in military operations on the side of Kyiv, according to the Kremlin.

## Journalists at Italian public media strike over Meloni government's influence
 - [https://www.politico.eu/article/giorgia-meloni-italian-state-broadcaster-rai-press-freedom-journalists-on-strike-public-media](https://www.politico.eu/article/giorgia-meloni-italian-state-broadcaster-rai-press-freedom-journalists-on-strike-public-media)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T23:33:34.751886+00:00

Her government faces increasing criticism for attacks on press freedom.

## China’s cheating threatens to wreck Paris Olympics, US anti-drugs chief says
 - [https://www.politico.eu/article/china-cheating-threate-wreck-paris-olympics-anti-drugs-chief-travis-tygart](https://www.politico.eu/article/china-cheating-threate-wreck-paris-olympics-anti-drugs-chief-travis-tygart)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T23:33:26.191341+00:00



## Australia accuses China of unsafe behavior involving fighter jet
 - [https://www.politico.com/news/2024/05/07/australia-accuses-china-of-unsafe-behavior-involving-fighter-jet-00156442](https://www.politico.com/news/2024/05/07/australia-accuses-china-of-unsafe-behavior-involving-fighter-jet-00156442)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T23:05:13+00:00

The jet endangered an Australian navy helicopter with flares over international waters.

## Joe Biden leans, once more, on the tent pole address
 - [https://www.politico.com/news/2024/05/06/joe-biden-speech-tentpole-address-00156414](https://www.politico.com/news/2024/05/06/joe-biden-speech-tentpole-address-00156414)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T19:53:52+00:00

The president has used a specific rhetorical device to tackle thorny issues. Not everyone on his team is sure it’s the most effective approach.

## Forget the sex. Check out those titillating invoices at the Trump hush money trial.
 - [https://www.politico.com/news/2024/05/06/trump-hush-money-trial-paper-trail-checks-00156408](https://www.politico.com/news/2024/05/06/trump-hush-money-trial-paper-trail-checks-00156408)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T19:49:35+00:00

Monday's proceedings had few sordid details. Prosecutors think they have some bombshell bank records instead.

## Trump disparages Jon Tester’s weight during fundraiser, saying he ‘looks pregnant’
 - [https://www.politico.com/news/2024/05/06/trump-mocks-jon-tester-looks-pregnant-00156401](https://www.politico.com/news/2024/05/06/trump-mocks-jon-tester-looks-pregnant-00156401)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T19:38:21+00:00

He also said he may campaign against the Montana Democrat, who is up for reelection.

## Trump on going to jail over gag order: 'I'll do that sacrifice'
 - [https://www.politico.com/news/2024/05/06/trump-jail-time-gag-order-hush-money-trial-00156388](https://www.politico.com/news/2024/05/06/trump-jail-time-gag-order-hush-money-trial-00156388)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T17:31:16+00:00

The judge has threatened the former president with possible jail time, something Trump and his supporters think may bolster his campaign.

## ProPublica series on Supreme Court gifts wins Pulitzer Prize
 - [https://www.politico.com/news/2024/05/06/propublica-wins-pulitzer-in-public-service-00156376](https://www.politico.com/news/2024/05/06/propublica-wins-pulitzer-in-public-service-00156376)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T17:21:48+00:00

The stories led to the adoption of a code of conduct by the high court.

## Economic growth boosts Social Security and Medicare but funding crisis still looms
 - [https://www.politico.com/news/2024/05/06/social-security-deplete-reserves-2035-00156361](https://www.politico.com/news/2024/05/06/social-security-deplete-reserves-2035-00156361)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T16:34:26+00:00

Federal officials said they expect Social Security will deplete its combined reserves and run out of money to fully pay beneficiaries in 2035.

## Israel approved Rafah military operation and started striking Hamas targets
 - [https://www.politico.com/news/2024/05/06/israel-rafah-hamas-00156372](https://www.politico.com/news/2024/05/06/israel-rafah-hamas-00156372)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T16:13:29+00:00

The decision by Israel’s War Cabinet came hours after Hamas agreed to a cease-fire that Israel hadn’t previously accepted.

## Russia detains US soldier on charges of theft
 - [https://www.politico.com/news/2024/05/06/russia-us-soldier-south-korea-00156328](https://www.politico.com/news/2024/05/06/russia-us-soldier-south-korea-00156328)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T14:16:48+00:00

The soldier, a staff sergeant, is stationed in South Korea and was arrested on Thursday, according to a U.S. official.

## Kristi Noem’s Team Told Her to Nix the Dog Story 2 Years Ago
 - [https://www.politico.com/news/magazine/2024/05/06/kristi-noem-dog-killing-story-00156290](https://www.politico.com/news/magazine/2024/05/06/kristi-noem-dog-killing-story-00156290)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T12:19:59+00:00

It would have violated the first rule of campaign memoirs: Do no harm.

## Columbia cancels commencement after weeks of turmoil
 - [https://www.politico.com/news/2024/05/06/columbia-commencement-canceled-protests-00156234](https://www.politico.com/news/2024/05/06/columbia-commencement-canceled-protests-00156234)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T08:55:16+00:00

Protesters used commencement as leverage to reach a deal; school President Minouche Shafik doubled down.

## Biden administration rolls out international cybersecurity plan
 - [https://www.politico.com/news/2024/05/06/biden-international-cybersecurity-plan-00156190](https://www.politico.com/news/2024/05/06/biden-international-cybersecurity-plan-00156190)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T05:00:00+00:00

The State Department’s international cyber strategy is aimed at setting goals for the US in leading on cyber norms at the United Nations, on AI issues and in countering China.

## Poland's President Duda plays whisperer to turn Donald Trump against Russia
 - [https://www.politico.eu/article/polands-president-duda-plays-whisperer-to-turn-donald-trump-against-russia](https://www.politico.eu/article/polands-president-duda-plays-whisperer-to-turn-donald-trump-against-russia)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T04:58:46.927125+00:00

The country's government turns to old foes for help in grooming the presidential candidate.

## Emhoff to meet with Jewish college students at White House
 - [https://www.politico.com/news/2024/05/06/doug-emhoff-jewish-college-students-invite-00156207](https://www.politico.com/news/2024/05/06/doug-emhoff-jewish-college-students-invite-00156207)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T04:00:00+00:00

The meeting is meant to mark Holocaust Remembrance Day but it will also address the wave of campus protests.

## Inside the federal government’s tug-of-war with states on the bird flu outbreak
 - [https://www.politico.com/news/2024/05/06/bird-flu-dairy-farms-cdc-00156119](https://www.politico.com/news/2024/05/06/bird-flu-dairy-farms-cdc-00156119)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T04:00:00+00:00

The CDC is locked in a power struggle with key states and agriculture players as it tries to better track the virus and prevent another potential pandemic.

## Trump’s family steers clear of trial — even as he spotlights them
 - [https://www.politico.com/news/2024/05/06/trump-trial-new-york-melania-family-00156189](https://www.politico.com/news/2024/05/06/trump-trial-new-york-melania-family-00156189)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T04:00:00+00:00

“With Donald, everything is transactional," said biographer David Cay Johnston.

## ‘Waste of a seat’: Manchin’s succession becomes a magnet for anti-establishment Republicans
 - [https://www.politico.com/news/2024/05/06/republicans-west-virginia-senate-primary-00156013](https://www.politico.com/news/2024/05/06/republicans-west-virginia-senate-primary-00156013)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T04:00:00+00:00

Rep. Alex Mooney is unlikely to defeat Mitch McConnell's handpicked candidate, Gov. Jim Justice, in this month's primary. But his fans still matter.

## Who Stole the Media’s Swagger?
 - [https://www.politico.com/news/magazine/2024/05/06/media-journalism-swagger-00154659](https://www.politico.com/news/magazine/2024/05/06/media-journalism-swagger-00154659)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-05-06T04:00:00+00:00

The decline of the news industry is sapping journalism of a crucial tool.

