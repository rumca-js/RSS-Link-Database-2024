# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## Ubuntu 24.10 “Oracular Oriole” Is Slated for Release on October 10th, 2024
 - [https://9to5linux.com/ubuntu-24-10-oracular-oriole-is-slated-for-release-on-october-10th-2024](https://9to5linux.com/ubuntu-24-10-oracular-oriole-is-slated-for-release-on-october-10th-2024)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-06T19:34:06+00:00

<p>Ubuntu 24.10 “Oracular Oriole” operating system has been slated for release later this year on October 10th, 2024, and it's expected to come with the GNOME 47 desktop environment and Linux kernel 6.10.</p>
<p>The post <a href="https://9to5linux.com/ubuntu-24-10-oracular-oriole-is-slated-for-release-on-october-10th-2024">Ubuntu 24.10 “Oracular Oriole” Is Slated for Release on October 10th, 2024</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## AlmaLinux OS 9.4 “Seafoam Ocelot” Officially Released, Based on RHEL 9.4
 - [https://9to5linux.com/almalinux-os-9-4-seafoam-ocelot-officially-released-based-on-rhel-9-4](https://9to5linux.com/almalinux-os-9-4-seafoam-ocelot-officially-released-based-on-rhel-9-4)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-06T16:14:24+00:00

<p>AlmaLinux OS 9.4 distribution is now available for download based on Red Hat Enterprise Linux 9.4. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/almalinux-os-9-4-seafoam-ocelot-officially-released-based-on-rhel-9-4">AlmaLinux OS 9.4 “Seafoam Ocelot” Officially Released, Based on RHEL 9.4</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Dillo 3.1 Open-Source Web Browser Released After 9 Year Hiatus
 - [https://9to5linux.com/dillo-3-1-open-source-web-browser-released-after-9-year-hiatus](https://9to5linux.com/dillo-3-1-open-source-web-browser-released-after-9-year-hiatus)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-06T15:11:50+00:00

<p>Dillo 3.1 open-source web browser is now available for download with support for floating HTML elements, support for OpenSSL, LibreSSL, and Mbed TLS 2 and 3 for HTTPS, and more.</p>
<p>The post <a href="https://9to5linux.com/dillo-3-1-open-source-web-browser-released-after-9-year-hiatus">Dillo 3.1 Open-Source Web Browser Released After 9 Year Hiatus</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## KeePassXC 2.7.8 Improves Bitwarden 1PUX Password Import and Passkey Support
 - [https://9to5linux.com/keepassxc-2-7-8-improves-bitwarden-1pux-password-import-and-passkey-support](https://9to5linux.com/keepassxc-2-7-8-improves-bitwarden-1pux-password-import-and-passkey-support)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-06T10:58:44+00:00

<p>KeePassXC 2.7.8 open-source password manager is now available for download with improved Bitwarden 1PUX import and Passkey support, as well as various UI enhancements and many bug fixes.</p>
<p>The post <a href="https://9to5linux.com/keepassxc-2-7-8-improves-bitwarden-1pux-password-import-and-passkey-support">KeePassXC 2.7.8 Improves Bitwarden 1PUX Password Import and Passkey Support</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

