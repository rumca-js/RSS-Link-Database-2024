# Source:CodeProject Latest Articles, URL:https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1, language:en-us

## Simple C++ DirectShow MP3 Player with .NET Wrapper
 - [https://www.codeproject.com/Articles/373613/Simple-Cplusplus-DirectShow-MP3-Player-with-NET-Wr](https://www.codeproject.com/Articles/373613/Simple-Cplusplus-DirectShow-MP3-Player-with-NET-Wr)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T23:08:00+00:00

No frills C++ MP3/WMA DirectShow player class

## C# OpenAI Library that Supports Assistants stream API
 - [https://www.codeproject.com/Articles/5372480/Csharp-OpenAI-Library-that-Supports-Assistants-str](https://www.codeproject.com/Articles/5372480/Csharp-OpenAI-Library-that-Supports-Assistants-str)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T21:26:00+00:00

C# OpenAI library Assitants, ChatCompletion, FineTuning, ImageGeneration and more

## Cross Site Scripting (XSS)
 - [https://www.codeproject.com/Articles/5381900/Cross-Site-Scripting-XSS](https://www.codeproject.com/Articles/5381900/Cross-Site-Scripting-XSS)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T15:02:00+00:00

G’day guys!.   Continuing our coverage of various security vulnerabilities, today I wanted to review Cross Site Scripting, commonly abbreviated to XSS. While technically speaking there are probably a few different flavours of this, I’m going to focus on two types of XSS; stored and unstored..

## Build Rich Web Apps with ASP.NET Core and Sircl – Part 4
 - [https://www.codeproject.com/Articles/5381910/Build-Rich-Web-Apps-with-ASP-NET-Core-and-Sircl-5](https://www.codeproject.com/Articles/5381910/Build-Rich-Web-Apps-with-ASP-NET-Core-and-Sircl-5)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T11:22:00+00:00

In this series, we will see how to build interactive web applications in ASP.NET Core with the help of Sircl.

## Build Rich Web Apps with ASP.NET Core and Sircl â€“ Part 4
 - [https://www.codeproject.com/Articles/5381910/Build-Rich-Web-Apps-with-ASP-NET-Core-and-Sircl-2](https://www.codeproject.com/Articles/5381910/Build-Rich-Web-Apps-with-ASP-NET-Core-and-Sircl-2)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T11:22:00+00:00

In this series, we will see how to build interactive web applications in ASP.NET Core with the help of Sircl.

## Learn EventSourceDB through Unit Testing
 - [https://www.codeproject.com/Articles/5381844/Learn-EventSourceDB-through-Unit-Testing](https://www.codeproject.com/Articles/5381844/Learn-EventSourceDB-through-Unit-Testing)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T09:52:00+00:00

Learn to use EventSourceDB through Unit Testing on xUnit.NET

## Diligent Engine: A Modern Cross-Platform Low-Level Graphics Library
 - [https://www.codeproject.com/Articles/1216041/Diligent-Engine-A-Modern-Cross-Platform-Low-Level](https://www.codeproject.com/Articles/1216041/Diligent-Engine-A-Modern-Cross-Platform-Low-Level)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T09:05:00+00:00

This article introduces Diligent Engine, a modern cross-platform graphics API abstraction library and rendering framework

## C# MVVM Toolkit Demo
 - [https://www.codeproject.com/Articles/5332442/Csharp-MVVM-Toolkit-Demo](https://www.codeproject.com/Articles/5332442/Csharp-MVVM-Toolkit-Demo)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-05-06T02:53:00+00:00

This article and the demo are about getting started using the MVVM Toolkit and some self-created interfaces / services for MessageBox and some dialogs.

