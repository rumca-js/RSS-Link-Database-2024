# Source:DeSmog, URL:https://www.desmog.com/feed, language:en-US

## Canada’s Bitumen Boosters Want Us to Forget About Norway
 - [https://www.desmog.com/2024/05/06/canadas-bitumen-boosters-want-us-to-forget-about-norway](https://www.desmog.com/2024/05/06/canadas-bitumen-boosters-want-us-to-forget-about-norway)
 - RSS feed: https://www.desmog.com/feed
 - date published: 2024-05-06T20:37:44+00:00

<p>Why can’t Alberta have nice things, like the $2.23 trillion Norwegian sovereign wealth fund? Alberta bills itself as an energy superpower and produces about 70 percent more petroleum in total than Norway, which has roughly the same population and enjoys some of the most generous public services in the world.&#160; So why is Alberta billions [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2024/05/06/canadas-bitumen-boosters-want-us-to-forget-about-norway/">Canada’s Bitumen Boosters Want Us to Forget About Norway</a> appeared first on <a href="https://www.desmog.com">DeSmog</a>.</p>

## Canceled Canadian CCS Project Deemed “Not Economically Feasible”
 - [https://www.desmog.com/2024/05/06/capital-power-generation-genesee-power-plant-canceled-canadian-ccs-project-not-economically-feasible](https://www.desmog.com/2024/05/06/capital-power-generation-genesee-power-plant-canceled-canadian-ccs-project-not-economically-feasible)
 - RSS feed: https://www.desmog.com/feed
 - date published: 2024-05-06T13:00:00+00:00

<p>Capital Power Generation canceled a $2.4 billion carbon capture and storage project at their Genesee Generating Station, claiming it is “technically viable but not economically feasible.” </p>
<p>The post <a href="https://www.desmog.com/2024/05/06/capital-power-generation-genesee-power-plant-canceled-canadian-ccs-project-not-economically-feasible/">Canceled Canadian CCS Project Deemed “Not Economically Feasible”</a> appeared first on <a href="https://www.desmog.com">DeSmog</a>.</p>

## Landmark Study Reveals Gas Stove Emissions Boost Childhood Asthma Rates, Adult Deaths
 - [https://www.desmog.com/2024/05/06/stanford-study-gas-stove-emissions-childhood-asthma-deaths-gas-leaks-project-label-sheldon-whitehouse](https://www.desmog.com/2024/05/06/stanford-study-gas-stove-emissions-childhood-asthma-deaths-gas-leaks-project-label-sheldon-whitehouse)
 - RSS feed: https://www.desmog.com/feed
 - date published: 2024-05-06T11:00:00+00:00

<p>A new Harvard-Stanford study shows gas stove emissions boost childhood asthma rates and could cause thousands of adult deaths. The study arrives at the same time as the launch of a new social media campaign to educate consumers on the dangers of gas stove cooking. </p>
<p>The post <a href="https://www.desmog.com/2024/05/06/stanford-study-gas-stove-emissions-childhood-asthma-deaths-gas-leaks-project-label-sheldon-whitehouse/">Landmark Study Reveals Gas Stove Emissions Boost Childhood Asthma Rates, Adult Deaths</a> appeared first on <a href="https://www.desmog.com">DeSmog</a>.</p>

