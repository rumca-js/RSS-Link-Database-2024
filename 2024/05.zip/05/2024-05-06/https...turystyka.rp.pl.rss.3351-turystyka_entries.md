# Source:Turystyka, URL:https://turystyka.rp.pl/rss/3351-turystyka, language:pl-PL

## Paryżanie chcą zarobić na igrzyskach. Więcej mieszkań do wynajęcia
 - [https://turystyka.rp.pl/zanim-wyjedziesz/art40299571-paryzanie-chca-zarobic-na-igrzyskach-wiecej-mieszkan-do-wynajecia](https://turystyka.rp.pl/zanim-wyjedziesz/art40299571-paryzanie-chca-zarobic-na-igrzyskach-wiecej-mieszkan-do-wynajecia)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-05-06T08:11:57+00:00

Podczas igrzysk olimpijskich latem 2024 roku Paryż może odwiedzić 16 mln gości. Powstanie zapotrzebowanie na 9 mln dodatkowych dób noclegowych zarówno w hotelach, jak i obiektach najmu krótkoterminowego. Jak wskazuje AirDNA, całkowita liczba ofert w Paryżu wzrosła o 45 proc. rok do roku.

## Do biur podróży wrócił wzrost cen. Trzy kraje z nowym rekordem
 - [https://turystyka.rp.pl/biura-podrozy/art40299461-do-biur-podrozy-wrocil-wzrost-cen-trzy-kraje-z-nowym-rekordem](https://turystyka.rp.pl/biura-podrozy/art40299461-do-biur-podrozy-wrocil-wzrost-cen-trzy-kraje-z-nowym-rekordem)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-05-06T07:57:29+00:00

Za wakacje w Grecji trzeba było zapłacić w zeszłym tygodniu średnio 5824 złote. Tym samym Grecja stała się najdroższym kierunkiem z pięciu najpopularniejszych wśród klientów biur podróży, pobiła nawet Wyspy Kanaryjskie. Również Turcja i Bułgaria osiągnęły rekordowe ceny.

## Albania i Maroko na wakacyjnej liście przebojów wśród niemieckich turystów
 - [https://turystyka.rp.pl/biura-podrozy/art40281121-albania-i-maroko-na-wakacyjnej-liscie-przebojow-wsrod-niemieckich-turystow](https://turystyka.rp.pl/biura-podrozy/art40281121-albania-i-maroko-na-wakacyjnej-liscie-przebojow-wsrod-niemieckich-turystow)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-05-06T05:00:00+00:00

W tym roku Niemcy masowo rezerwują wyjazdy do swoich tradycyjnych miejsc wypoczynku, takich jak Majorka, Turcja i Grecja. Ale wśród szlagierów tego lata pojawiły się też mniej dotąd znane na rynku niemieckim kierunki.

