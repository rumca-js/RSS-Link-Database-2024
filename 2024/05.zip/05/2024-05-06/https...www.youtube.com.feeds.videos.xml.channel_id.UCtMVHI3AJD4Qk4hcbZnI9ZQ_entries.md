# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Gamers Took A Massive Win, Sony Lost...
 - [https://www.youtube.com/watch?v=qoyOa96of7g](https://www.youtube.com/watch?v=qoyOa96of7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2024-05-06T17:04:18+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at what appears to be a pretty quick reversal of policies by Sony, Helldivers 2 is one of the most beloved games on the market and with Sony briefly enforcing mandated PSN connections to a PC game, a proper boycott started and gamers ended up winning against corporate tyranny. Thanks for watching!
Like, Comment and Subscribe for more videos!

