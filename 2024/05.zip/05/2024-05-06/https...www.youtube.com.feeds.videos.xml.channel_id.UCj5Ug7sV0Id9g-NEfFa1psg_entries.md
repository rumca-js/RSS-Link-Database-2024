# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:pl-PL

## Zło, nagość i przemoc w filmach i serialach. Co oglądać, a czego unikać?
 - [https://www.youtube.com/watch?v=U3lJ4wsBRgs](https://www.youtube.com/watch?v=U3lJ4wsBRgs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2024-05-06T14:54:58+00:00

Ostatni odcinek z serii z @SOWINSKY to rozmowa o serialach oraz o o tym jak oceniamy zło w kinie - czy wolno na nie patrzeć i jak znaleźć w tym zdrowy rozsądek. Komentarze z wyrwanymi z kontekstu zdaniami Pisma pt. "wasza mowa musi być tak-tak" albo "unikajcie wszystkiego co ma choćby pozór zła" za 3, 2, 1...

Rozpiska:

0:00 - Przywitanie z Łukaszem
1:59 - Najlepszy serial na śmieszno
06:56 - Drapanie po plecach
07:20 - Katolik poleca Lucyfera? No dajcie spokój...
10:56 - Rodzina Soprano i zło w sztuce
17:15 - Sceny łóżkowe, Fundacja i See 
18:20 - Peaky Blinders
19:14 - NIE WOLNO SEGZU!!!
20:21 - Breaking Bad i wchodzenie w zło
26:44 - Zadzwoń do Saula i mój ulubiony bohater
28:34 - Ulubiony Serial Tuska
31:09 - Spotkać Boga i zło/dobro w nas
36:39 - Sukcesja, Segz w Grze o tron i historia z The Wire
38:38 - Nieambitny serial i głód Krzysztofa
40:46 - Świat jest zły?
43:53 - Seriale niosące światło
45:04 - Rozdzielenie
46:13 - Nagrzany charyzmatyk i ból karku
47:18 - Jakimowicz wjec

