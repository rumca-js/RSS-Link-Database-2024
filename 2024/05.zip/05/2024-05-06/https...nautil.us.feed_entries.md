# Source:Nautilus, URL:https://nautil.us/feed, language:en-US

## What Counts as Consciousness
 - [https://nautil.us/what-counts-as-consciousness-579734](https://nautil.us/what-counts-as-consciousness-579734)
 - RSS feed: https://nautil.us/feed
 - date published: 2024-05-06T22:48:37+00:00

<p>Neuroscientist Christof Koch on human minds, AI, and bacteria.</p>
<p>The post <a href="https://nautil.us/what-counts-as-consciousness-579734/">What Counts as Consciousness</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

## The Curious Life of a Singing Fish
 - [https://nautil.us/the-curious-life-of-a-singing-fish-573189](https://nautil.us/the-curious-life-of-a-singing-fish-573189)
 - RSS feed: https://nautil.us/feed
 - date published: 2024-05-06T14:27:10+00:00

<p>Plainfin midshipman fish migrate from the deep sea to spawn—and then things get weird.</p>
<p>The post <a href="https://nautil.us/the-curious-life-of-a-singing-fish-573189/">The Curious Life of a Singing Fish</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

