# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Marty Stuart and His Fabulous Superlatives: Tiny Desk Concert
 - [https://www.youtube.com/watch?v=z2nGMDs65tI](https://www.youtube.com/watch?v=z2nGMDs65tI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2024-05-06T09:00:45+00:00

Suraya Mohamed | May 6, 2024
When Marty Stuart arrived, his cheerful smile and charismatic personality beamed. He had a charming swagger and it was immediately clear we were in the presence of a country and bluegrass music legend.

When Stuart was just 12 years old, he went on the road for the first time with a Pentecostal gospel bluegrass group called the Sullivan Family Gospel Singers. Almost 55 years later, he’s still performing and is a five-time Grammy winner, Country Music Hall of Famer and AMA Lifetime Achievement Award recipient.

Those accolades only hint at the artistry of Mary Stuart and his longtime band The Fabulous Superlatives. Looking around the room during his Tiny Desk performance, people in the audience were visibly captivated by this undeniable demonstration of musical excellence — beautiful harmonies, precise rhythmic precision and perfectly blended arrangements all sewn together with a casual flair that was simple and fun. 

Recorded just a few days before Easter

