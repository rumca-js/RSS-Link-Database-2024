# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## One Weird Reason People Suck at Parking
 - [https://www.youtube.com/watch?v=EcvWBzD9QXk](https://www.youtube.com/watch?v=EcvWBzD9QXk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2024-05-06T17:06:19+00:00

Visit https://brilliant.org/scishow/ to get started learning STEM for free. The first 200 people will get 20% off their annual premium subscription and a 30-day free trial.

Human territoriality results in some pretty ridiculous behaviors. And luckily, scientists have studied it in all kinds of situations. 

Hosted by: Hank Green (he/him)
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Benjamin Carleski, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, DrakoEsper, Eric Jensen, Friso, Garrett Galloway, Harrison Mills, J. Copen, Jaap Westera, Jason A Saslow, Jeffrey Mckishen, Jeremy Mattern, Kenny Wilson, Kevin Bealer, Kevin Knupp, Lyndsay Brown, Matt Curls, Michelle Dove, Piya Shedden, Rizwan Kassim, Sam Lutfi
----------
Looking for SciShow els

