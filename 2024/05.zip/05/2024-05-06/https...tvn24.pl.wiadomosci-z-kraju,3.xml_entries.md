# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Bodnar: potwierdzam, rozmawiam z Kancelarią Prezydenta w sprawie ustawy o KRS
 - [https://tvn24.pl/polska/adam-bodnar-minister-sprawiedliwosci-i-prokurator-generalny-o-rozmowach-z-kancelaria-prezydenta-o-ustawie-w-sprawie-krs-st7902553?source=rss](https://tvn24.pl/polska/adam-bodnar-minister-sprawiedliwosci-i-prokurator-generalny-o-rozmowach-z-kancelaria-prezydenta-o-ustawie-w-sprawie-krs-st7902553?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T18:01:35+00:00

<img alt="Bodnar: potwierdzam, rozmawiam z Kancelarią Prezydenta w sprawie ustawy o KRS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f4mr4o-adam-bodnar-7902582/alternates/LANDSCAPE_1280" />
    Adam Bodnar, minister sprawiedliwości i prokurator generalny potwierdził w "Faktach po Faktach" w TVN24, że rozmawia z Kancelarią Prezydenta w sprawie poparcia nowelizacji ustawy o KRS. Ocenił, że to "ostatni etap, kiedy można jeszcze coś z panem prezydentem skonsultować i nie narazić się na ryzyko weta".

## Pięć osób w szpitalu, łoś nie żyje. Jak przedarł się na autostradę
 - [https://tvn24.pl/tvnwarszawa/ulice/anielinek-minsk-mazowiecki-jak-los-przedostal-sie-na-autostrade-a2-st7902449?source=rss](https://tvn24.pl/tvnwarszawa/ulice/anielinek-minsk-mazowiecki-jak-los-przedostal-sie-na-autostrade-a2-st7902449?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T18:01:06+00:00

<img alt="Pięć osób w szpitalu, łoś nie żyje. Jak przedarł się na autostradę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-drsm87-zderzenie-z-losiem-na-a2-7896044/alternates/LANDSCAPE_1280" />
    Kilka dni temu na A2 w pobliżu Mińska Mazowieckiego pojawił się łoś. Doszło do zderzenia, w wyniku którego do szpitala na badania przewieziono pięć osób, w tym troje dzieci. Zwierzę nie przeżyło. Jak to możliwe, że łoś dostała się na ogrodzoną autostradę? Pytamy zarządcę drogi.

## Sędzia Szmydt na Białorusi. Komunikat prokuratury
 - [https://tvn24.pl/polska/tomasz-szmydt-poprosil-o-azyl-na-bialorus-prokuratura-krajowa-komentuje-st7902311?source=rss](https://tvn24.pl/polska/tomasz-szmydt-poprosil-o-azyl-na-bialorus-prokuratura-krajowa-komentuje-st7902311?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T14:49:21+00:00

<img alt="Sędzia Szmydt na Białorusi. Komunikat prokuratury " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tc04ij-szmydt-7902320/alternates/LANDSCAPE_1280" />
    Sędzia Wojewódzkiego Sądu Administracyjnego w Warszawie Tomasz Szmydt poinformował na konferencji prasowej w Mińsku, że ubiega się o azyl na Białorusi. Szmydt to jeden z bohaterów tzw. afery hejterskiej za czasów rządów PiS. Komunikat w związku z informacją o złożeniu przez niego wniosku o azyl wydała Prokuratura Krajowa.

## Bójka z udziałem kilkudziesięciu osób w centrum miasta
 - [https://tvn24.pl/lodz/glowno-kilkadziesiat-osob-bilo-sie-w-centrum-miasta-policja-wyjasnia-okolicznosci-zdarzenia-st7902139?source=rss](https://tvn24.pl/lodz/glowno-kilkadziesiat-osob-bilo-sie-w-centrum-miasta-policja-wyjasnia-okolicznosci-zdarzenia-st7902139?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T13:42:52+00:00

<img alt="Bójka z udziałem kilkudziesięciu osób w centrum miasta " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8xetg8-plac-wolnosci-w-glownie-7902111/alternates/LANDSCAPE_1280" />
    Około 40 osób brało udział w bójce na Placu Wolności w Głownie (Łódzkie). Policja, która pojawiła się na miejscu, nikogo już jednak nie zastała, a film, który pojawił się w sieci zniknął. Władze miasta poprosiły o zwiększenie liczby patroli i zapowiedziały, że powstanie nowoczesny monitoring.

## Remontują Cepelię. Wiemy, co będzie w pawilonie
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-w-pawilonie-cepelii-bedzie-empik-st7901323?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-w-pawilonie-cepelii-bedzie-empik-st7901323?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T13:39:36+00:00

<img alt="Remontują Cepelię. Wiemy, co będzie w pawilonie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1m826g-wizualizacja-empiku-w-budynku-cepelii-7901304/alternates/LANDSCAPE_1280" />
    Od kilku miesięcy trwają prace budowalne w pawilonie Cepelii u zbiegu Alej Jerozolimskich i ulicy Marszałkowskiej jest w trakcie przebudowy. Inwestor długo nie chciał zdradzić, co znajdzie się odrestaurowanym budynku. W poniedziałek oficjalnie ogłoszono, że będzie tam salon Empiku.

## Grozili sprzedawcy, uciekli bez łupu, grozi im 20 lat więzienia
 - [https://tvn24.pl/trojmiasto/gdansk-osowa-z-mlotkiem-zaatakowali-sprzedawce-sklepu-st7901930?source=rss](https://tvn24.pl/trojmiasto/gdansk-osowa-z-mlotkiem-zaatakowali-sprzedawce-sklepu-st7901930?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T12:35:21+00:00

<img alt="Grozili sprzedawcy, uciekli bez łupu, grozi im 20 lat więzienia" src="https://tvn24.pl/trojmiasto/cdn-zdjecie-lvnrki-z-mlotkiem-zaatakowali-sprzedawce-sklepu-7901992/alternates/LANDSCAPE_1280" />
    Grozili sprzedawcy młotkiem i go popychali. Ze sklepu uciekli bez łupu. Szybko zostali zatrzymani, trafili do aresztu, grozi im do 20 lat więzienia.

## "Polska jest jednym z głównych beneficjentów". Raport o inwestycjach
 - [https://tvn24.pl/biznes/ze-swiata/bezposrednie-inwestycje-zagraniczne-polska-jest-jednym-z-glownych-beneficjentow-st7901487?source=rss](https://tvn24.pl/biznes/ze-swiata/bezposrednie-inwestycje-zagraniczne-polska-jest-jednym-z-glownych-beneficjentow-st7901487?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T12:30:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-emcdfy-adobestock_523076046-7753590/alternates/LANDSCAPE_1280" />
    Liczba bezpośrednich inwestycji zagranicznych w całej Europie spadła w minionym roku o 4 procent w porównaniu z danymi z 2022 roku - wynika z raportu EY "Atrakcyjność inwestycyjna Europy 2024". Jednocześnie Polska była jednym z krajów, które skorzystały na zmianie sytuacji gospodarczej, a liczba projektów produkcyjnych wzrosła w naszym kraju o 17 procent.

## Prezes PERN Mirosław Skowron złożył rezygnację
 - [https://tvn24.pl/biznes/z-kraju/prezes-pern-miroslaw-skowron-zlozyl-rezygnacje-st7902046?source=rss](https://tvn24.pl/biznes/z-kraju/prezes-pern-miroslaw-skowron-zlozyl-rezygnacje-st7902046?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T12:26:43+00:00

<img alt="Prezes PERN Mirosław Skowron złożył rezygnację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lf3lhq-rurociag-przyjazn-6221598/alternates/LANDSCAPE_1280" />
    Prezes PERN Mirosław Skowron 2 maja złożył rezygnację - podała spółka w komunikacie. Nie wskazała jednak powodów rezygnacji. PERN to operator sieci rurociągów i magazynów ropy naftowej i paliw.

## Europoseł Prawa i Sprawiedliwości o listach do Parlamentu Europejskiego: popełniono pewien błąd
 - [https://tvn24.pl/polska/wybory-do-europarlamentu-2024-zdzislaw-krasnodebski-o-listach-pis-popelniono-pewien-blad-st7901300?source=rss](https://tvn24.pl/polska/wybory-do-europarlamentu-2024-zdzislaw-krasnodebski-o-listach-pis-popelniono-pewien-blad-st7901300?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T08:43:44+00:00

<img alt="Europoseł Prawa i Sprawiedliwości o listach do Parlamentu Europejskiego: popełniono pewien błąd" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pf65ht-zdzislaw-krasnodebski-7898361/alternates/LANDSCAPE_1280" />
    Prawo i Sprawiedliwość chyba za bardzo poszło w kierunku skuteczności w samej kampanii wyborczej, przy jednoczesnym osłabieniu jej już w trakcie kadencji. A to spory błąd - ocenił Zdzisław Krasnodębski, od 10 lat europoseł PiS, który tym razem nie znalazł się na listach kandydatów tej partii w wyborach do Parlamentu Europejskiego. Sam uważa, że mógłby "służyć swoim doświadczeniem w kolejnej kadencji, ale decyzja władz partii była jednak inna".

## Rodzą im się dzieci, umierają bliscy, a oni wciąż czekają na legalizację pobytu w Polsce
 - [https://tvn24.pl/wroclaw/wroclaw-czekaja-na-legalizacje-w-polsce-rodza-im-sie-dzieci-umieraja-bliscy-st7781158?source=rss](https://tvn24.pl/wroclaw/wroclaw-czekaja-na-legalizacje-w-polsce-rodza-im-sie-dzieci-umieraja-bliscy-st7781158?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-05-06T06:57:53+00:00

<img alt="Rodzą im się dzieci, umierają bliscy, a oni wciąż czekają na legalizację pobytu w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zab6bt-dolnoslaski-urzad-wojewodzki-z-lotu-ptaka-7782348/alternates/LANDSCAPE_1280" />
    Cudzoziemcy w urzędzie wojewódzkim we Wrocławiu na karty pobytu czekają nawet pięć lat. W tym czasie nie mogą opuszczać Polski. Nie mają możliwości wyjazdu w rodzinne strony, by pomóc starszym rodzicom. Inspektorzy NIK stwierdzili nieprawidłowości w procedowaniu spraw cudzoziemców w każdym kontrolowanym urzędzie wojewódzkim.

