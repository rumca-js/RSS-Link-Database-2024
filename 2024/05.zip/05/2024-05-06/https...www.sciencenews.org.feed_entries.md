# Source:Science News, URL:https://www.sciencenews.org/feed, language:en-US

## As the Arctic tundra warms, soil microbes likely will ramp up CO2 production
 - [https://www.sciencenews.org/article/arctic-tundra-soil-microbe-carbon-dioxide](https://www.sciencenews.org/article/arctic-tundra-soil-microbe-carbon-dioxide)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-05-06T15:30:00+00:00

Experiments in mini greenhouses show how the tiny organisms lurking underground in a "sleepy biome" could be a contributor to climate change.

## Online spaces may intensify teens’ uncertainty in social interactions
 - [https://www.sciencenews.org/article/online-teens-uncertainty-social-emotion](https://www.sciencenews.org/article/online-teens-uncertainty-social-emotion)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-05-06T13:45:00+00:00

Little is known of how teens learn about emotions online and then use that knowledge to cope with social uncertainty during in-person encounters.

