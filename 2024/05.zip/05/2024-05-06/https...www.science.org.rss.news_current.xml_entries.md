# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Australia bets big on dark horse quantum computing technology
 - [https://www.science.org/content/article/australia-bets-big-on-dark-horse-quantum-computing-technology](https://www.science.org/content/article/australia-bets-big-on-dark-horse-quantum-computing-technology)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-05-06T22:32:19.120387+00:00

In $940 million deal, PsiQuantum will build “utility scale” facility to harness photons

## Deadly Pacific ‘blobs’ tied to emission cuts in China
 - [https://www.science.org/content/article/deadly-pacific-blobs-tied-emission-cuts-china](https://www.science.org/content/article/deadly-pacific-blobs-tied-emission-cuts-china)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-05-06T20:23:02.199826+00:00

Warming due to cleaner air rippled across the ocean, modeling suggests

## New animal dads often kill their stepchildren. These parrots adopt them instead
 - [https://www.science.org/content/article/new-animal-dads-often-kill-their-stepchildren-these-parrots-adopt-them-instead](https://www.science.org/content/article/new-animal-dads-often-kill-their-stepchildren-these-parrots-adopt-them-instead)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-05-06T19:17:14.620248+00:00

Green-rumped parrotlet stepfathers still get their DNA into the gene pool when they spare their adoptive chicks’ lives

## Hellish Venus may have lost its water quickly
 - [https://www.science.org/content/article/hellish-venus-may-have-lost-its-water-quickly](https://www.science.org/content/article/hellish-venus-may-have-lost-its-water-quickly)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-05-06T17:07:09.385309+00:00

Newly identified water-loss mechanism means planet may have had an ocean more recently

