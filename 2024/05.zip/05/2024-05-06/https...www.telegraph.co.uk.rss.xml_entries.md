# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Tom Daley makes history by being named in Team GB diving team for Paris Olympics
 - [https://www.telegraph.co.uk/olympics/2024/05/07/tom-daley-history-team-gb-diving-paris-olympics-2024](https://www.telegraph.co.uk/olympics/2024/05/07/tom-daley-history-team-gb-diving-paris-olympics-2024)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-05-06T23:00:00+00:00



## Crystal Palace vs Manchester United: Lineups and latest updates from Premier League
 - [https://www.telegraph.co.uk/football/2024/05/06/crystal-palace-vs-manchester-united-live-score-latest](https://www.telegraph.co.uk/football/2024/05/06/crystal-palace-vs-manchester-united-live-score-latest)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-05-06T17:37:12+00:00



## Naoya Inoue suffers first knockdown of his career – then delivers brutal knockout
 - [https://www.telegraph.co.uk/boxing/2024/05/06/naoya-inoue-knockdown-then-knockout-luis-nery](https://www.telegraph.co.uk/boxing/2024/05/06/naoya-inoue-knockdown-then-knockout-luis-nery)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-05-06T14:38:14+00:00



## Surfers found dead in Mexican well were shot in the head
 - [https://www.telegraph.co.uk/world-news/2024/05/06/bodies-found-mexico-belong-to-missing-surfers](https://www.telegraph.co.uk/world-news/2024/05/06/bodies-found-mexico-belong-to-missing-surfers)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-05-06T07:03:24+00:00



## Child dies in flood, hundreds saved after storms lash Texas
 - [https://www.telegraph.co.uk/us/news/2024/05/06/storms-in-texas-lash-already-saturated-houston](https://www.telegraph.co.uk/us/news/2024/05/06/storms-in-texas-lash-already-saturated-houston)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-05-06T01:25:08+00:00



