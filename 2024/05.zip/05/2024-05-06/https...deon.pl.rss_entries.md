# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Ks. prof. Mazurkiewicz: Wiernych obowiązuje nauka społeczna Kościoła
 - [https://deon.pl/kosciol/ks-prof-mazurkiewicz-wiernych-obowiazuje-nauka-spoleczna-kosciola,2808527](https://deon.pl/kosciol/ks-prof-mazurkiewicz-wiernych-obowiazuje-nauka-spoleczna-kosciola,2808527)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T14:37:25+00:00



## "Nasza droga do Boga". Jak głosić Chrystusa zainteresowanym muzułmanom?
 - [https://deon.pl/kosciol/nasza-droga-do-boga-jak-glosic-chrystusa-zainteresowanym-muzulmanom,2808473](https://deon.pl/kosciol/nasza-droga-do-boga-jak-glosic-chrystusa-zainteresowanym-muzulmanom,2808473)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T13:47:16+00:00



## Nie układa ci się życie? W tej modlitwie wyprosisz wstawiennictwo św. Antoniego
 - [https://deon.pl/wiara/duchowosc/nie-uklada-ci-sie-zycie-w-tej-modlitwie-wyprosisz-wstawiennictwo-sw-antoniego,2808386](https://deon.pl/wiara/duchowosc/nie-uklada-ci-sie-zycie-w-tej-modlitwie-wyprosisz-wstawiennictwo-sw-antoniego,2808386)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T13:38:28+00:00



## Zawiedzione plany sprawiają, że nie ma w nas zgody na plan Boga
 - [https://deon.pl/wiara/zawiedzione-plany-sprawiaja-ze-nie-ma-w-nas-zgody-na-plan-boga,2808329](https://deon.pl/wiara/zawiedzione-plany-sprawiaja-ze-nie-ma-w-nas-zgody-na-plan-boga,2808329)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T13:30:01+00:00



## „Nareszcie wróciłam do domu”. Uzdrowiona z raka Tammy Peterson, przyjęła chrzest [WIDEO]
 - [https://deon.pl/wiara/nareszcie-wrocilam-do-domu-uzdrowiona-z-raka-tammy-peterson-przyjela-chrzest-wideo,2805890](https://deon.pl/wiara/nareszcie-wrocilam-do-domu-uzdrowiona-z-raka-tammy-peterson-przyjela-chrzest-wideo,2805890)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T13:30:00+00:00



## Białoruś: Sędzia sądu w Warszawie poprosił białoruskie władze o "opiekę i ochronę"
 - [https://deon.pl/swiat/bialorus-sedzia-sadu-w-warszawie-poprosil-bialoruskie-wladze-o-opieke-i-ochrone,2808323](https://deon.pl/swiat/bialorus-sedzia-sadu-w-warszawie-poprosil-bialoruskie-wladze-o-opieke-i-ochrone,2808323)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T13:29:08+00:00



## Czy Bóg może mówić do nas przez sny? Czy katolicy mogą odczytywać to, co im się przyśni?
 - [https://deon.pl/wiara/czy-bog-moze-mowic-do-nas-przez-sny-czy-katolicy-moga-odczytywac-to-co-im-sie-przysni,2808200](https://deon.pl/wiara/czy-bog-moze-mowic-do-nas-przez-sny-czy-katolicy-moga-odczytywac-to-co-im-sie-przysni,2808200)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T13:12:41+00:00



## Pilot oświadczył się stewardesie na pokładzie samolotu PLL LOT
 - [https://deon.pl/po-godzinach/pilot-oswiadczyl-sie-stewardesie-na-pokladzie-samolotu-pll-lot,2805809](https://deon.pl/po-godzinach/pilot-oswiadczyl-sie-stewardesie-na-pokladzie-samolotu-pll-lot,2805809)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T12:50:00+00:00



## Papież do gwardzistów szwajcarskich: Proszę was, idźcie pod prąd!
 - [https://deon.pl/kosciol/papiez-do-gwardzistow-szwajcarskich-prosze-was-idzcie-pod-prad,2808161](https://deon.pl/kosciol/papiez-do-gwardzistow-szwajcarskich-prosze-was-idzcie-pod-prad,2808161)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T12:26:43+00:00



## Fizyka zaczyna się od kwantów. Ale jak to wyjaśnić?
 - [https://deon.pl/po-godzinach/fizyka-zaczyna-sie-od-kwantow-ale-jak-to-wyjasnic,2800613](https://deon.pl/po-godzinach/fizyka-zaczyna-sie-od-kwantow-ale-jak-to-wyjasnic,2800613)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T12:00:00+00:00



## Minister nauki mówi o łączeniu uczelni. "Skierowałem wyraźny sygnał do środowiska akademickiego"
 - [https://deon.pl/swiat/minister-nauki-mowi-o-laczeniu-uczelni-skierowalem-wyrazny-sygnal-do-srodowiska-akademickiego,2808101](https://deon.pl/swiat/minister-nauki-mowi-o-laczeniu-uczelni-skierowalem-wyrazny-sygnal-do-srodowiska-akademickiego,2808101)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T11:26:21+00:00



## Siedem dróg do Notre-Dame. We Francji rozpocznie się wyjątkowa pielgrzymka
 - [https://deon.pl/kosciol/siedem-drog-do-notre-dame-we-francji-rozpocznie-sie-wyjatkowa-pielgrzymka,2808086](https://deon.pl/kosciol/siedem-drog-do-notre-dame-we-francji-rozpocznie-sie-wyjatkowa-pielgrzymka,2808086)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T11:20:08+00:00



## Marcin Zieliński: Problem we wspólnocie pojawia się, gdy ktoś mówi:  "Ale tak nigdy nie było!"
 - [https://deon.pl/wiara/marcin-zielinski-problem-we-wspolnocie-pojawia-sie-gdy-ktos-mowi--ale-tak-nigdy-nie-bylo,2807879](https://deon.pl/wiara/marcin-zielinski-problem-we-wspolnocie-pojawia-sie-gdy-ktos-mowi--ale-tak-nigdy-nie-bylo,2807879)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T10:45:19+00:00



## "DGP": Płaca minimalna w 2025 r. wyniesie ponad 4,5 tys. zł
 - [https://deon.pl/swiat/dgp-placa-minimalna-w-2025-r-wyniesie-ponad-45-tys-zl,2807996](https://deon.pl/swiat/dgp-placa-minimalna-w-2025-r-wyniesie-ponad-45-tys-zl,2807996)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T10:26:20+00:00



## 23-letni Jan wyjaśnia, dlaczego postanowił zostać gwardzistą szwajcarskim
 - [https://deon.pl/kosciol/23-letni-jan-wyjasnia-dlaczego-postanowil-zostac-gwardzista-szwajcarskim,2807897](https://deon.pl/kosciol/23-letni-jan-wyjasnia-dlaczego-postanowil-zostac-gwardzista-szwajcarskim,2807897)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T10:18:28+00:00



## Rekolekcje w codzienności. "Odkrywam to, co już jest, choć czasem pokryte kurzem"
 - [https://deon.pl/wiara/rekolekcje-w-codziennosci-odkrywam-to-co-juz-jest-choc-czasem-pokryte-kurzem,2807789](https://deon.pl/wiara/rekolekcje-w-codziennosci-odkrywam-to-co-juz-jest-choc-czasem-pokryte-kurzem,2807789)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T09:31:52+00:00



## 52-latek strzelał z wiatrówki do dzieci. Przeszkadzał mu hałas pod blokiem
 - [https://deon.pl/swiat/52-latek-strzelal-z-wiatrowki-do-dzieci-przeszkadzal-mu-halas-pod-blokiem,2807840](https://deon.pl/swiat/52-latek-strzelal-z-wiatrowki-do-dzieci-przeszkadzal-mu-halas-pod-blokiem,2807840)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T09:21:31+00:00



## Prezydent Szwajcarii: Watykan zaproszony na konferencję pokojową ws. Ukrainy
 - [https://deon.pl/kosciol/prezydent-szwajcarii-watykan-zaproszony-na-konferencje-pokojowa-ws-ukrainy,2807750](https://deon.pl/kosciol/prezydent-szwajcarii-watykan-zaproszony-na-konferencje-pokojowa-ws-ukrainy,2807750)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T09:03:31+00:00



## "Ból zaczął się zmieniać w ciepło otaczające całą dłoń". Takie łaski wyprasza święty Antoni
 - [https://deon.pl/wiara/bol-zaczal-sie-zmieniac-w-cieplo-otaczajace-cala-dlon-takie-laski-wyprasza-swiety-antoni,2807651](https://deon.pl/wiara/bol-zaczal-sie-zmieniac-w-cieplo-otaczajace-cala-dlon-takie-laski-wyprasza-swiety-antoni,2807651)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T08:48:07+00:00



## [PILNE] Rosja przeprowadzi ćwiczenia z użycia broni jądrowej. To odpowiedź na groźby Zachodu
 - [https://deon.pl/swiat/pilne-rosja-przeprowadzi-cwiczenia-z-uzycia-broni-jadrowej-to-odpowiedz-na-grozby-zachodu,2807624](https://deon.pl/swiat/pilne-rosja-przeprowadzi-cwiczenia-z-uzycia-broni-jadrowej-to-odpowiedz-na-grozby-zachodu,2807624)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T08:33:40+00:00



## Papież poleci do Singapuru. Jego wizyta ma być "duchowym doświadczeniem"
 - [https://deon.pl/kosciol/papiez-poleci-do-singapuru-jego-wizyta-ma-byc-duchowym-doswiadczeniem,2807591](https://deon.pl/kosciol/papiez-poleci-do-singapuru-jego-wizyta-ma-byc-duchowym-doswiadczeniem,2807591)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T08:02:02+00:00



## 11 maja odbędzie się 88. Ogólnopolska Pielgrzymka Akademicka na Jasną Górę
 - [https://deon.pl/kosciol/11-maja-odbedzie-sie-88-ogolnopolska-pielgrzymka-akademicka-na-jasna-gore,2807567](https://deon.pl/kosciol/11-maja-odbedzie-sie-88-ogolnopolska-pielgrzymka-akademicka-na-jasna-gore,2807567)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T07:30:04+00:00



## Zamachy bombowe, podpalenia i ataki na infrastrukturę. Rosja planuje akty sabotażu w całej Europie
 - [https://deon.pl/swiat/zamachy-bombowe-podpalenia-i-ataki-na-infrastrukture-rosja-planuje-akty-sabotazu-w-calej-europie,2807522](https://deon.pl/swiat/zamachy-bombowe-podpalenia-i-ataki-na-infrastrukture-rosja-planuje-akty-sabotazu-w-calej-europie,2807522)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T07:19:40+00:00



## Potrzebujesz pomocy? Pomodlimy się w Twojej intencji
 - [https://deon.pl/kosciol/potrzebujesz-pomocy-pomodlimy-sie-w-twojej-intencji,1369361](https://deon.pl/kosciol/potrzebujesz-pomocy-pomodlimy-sie-w-twojej-intencji,1369361)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T07:13:00+00:00



## Historia każdego proboszcza jest ważna
 - [https://deon.pl/kosciol/historia-kazdego-proboszcza-jest-wazna,2807477](https://deon.pl/kosciol/historia-kazdego-proboszcza-jest-wazna,2807477)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T07:00:24+00:00



## Japoński malarz nie wiedział nic o Jezusie i nie znał Biblii. "Moje nawrócenie dało życie śmierci"
 - [https://deon.pl/wiara/japonski-malarz-nie-wiedzial-nic-o-jezusie-i-nie-znal-biblii-moje-nawrocenie-dalo-zycie-smierci,2805239](https://deon.pl/wiara/japonski-malarz-nie-wiedzial-nic-o-jezusie-i-nie-znal-biblii-moje-nawrocenie-dalo-zycie-smierci,2805239)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T07:00:00+00:00



## Grał kapitana Titanica i króla Theodena we "Władcy pierścieni". Nie żyje słynny aktor
 - [https://deon.pl/swiat/gral-kapitana-titanica-i-krola-theodena-we-wladcy-pierscieni-nie-zyje-slynny-aktor,2807441](https://deon.pl/swiat/gral-kapitana-titanica-i-krola-theodena-we-wladcy-pierscieni-nie-zyje-slynny-aktor,2807441)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T06:10:53+00:00



## Z ciemności grobu do zmartwychwstania - łódzka Droga Światła
 - [https://deon.pl/wiara/z-ciemnosci-grobu-do-zmartwychwstania---lodzka-droga-swiatla,2807405](https://deon.pl/wiara/z-ciemnosci-grobu-do-zmartwychwstania---lodzka-droga-swiatla,2807405)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-05-06T06:00:00+00:00



