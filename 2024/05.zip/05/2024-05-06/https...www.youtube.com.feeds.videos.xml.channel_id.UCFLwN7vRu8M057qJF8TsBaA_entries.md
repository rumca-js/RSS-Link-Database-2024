# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Fallout TV show - ep. 4 review #fallout #review  #gaming #fallouttvshow #gamer #funny
 - [https://www.youtube.com/watch?v=MJweqaQJmz8](https://www.youtube.com/watch?v=MJweqaQJmz8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2024-05-06T17:42:39+00:00

I'm reviewing each episode of the new Fallout show here & on TikTok! What did you think of episode 4?

