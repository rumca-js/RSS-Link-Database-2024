# Source:Na Gałęzi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtecHyLSXoL3P-xgFsbQh-g, language:pl

## Reniferek - świetny okropny serial
 - [https://www.youtube.com/watch?v=MUuBQAkqwkY](https://www.youtube.com/watch?v=MUuBQAkqwkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtecHyLSXoL3P-xgFsbQh-g
 - date published: 2024-05-06T15:47:55+00:00

Na Gałęzi na Instagramie - https://www.instagram.com/mlukanski/

Reniferek to serial, który jest swego rodzaju fenomenem. Łączy skrajne emocje przedstawiając złożoną opowieść opartą na prawdziwych wydarzeniach. Bardzo niekomfortowy seans, który od strony warsztatowej stoi na wyjątkowo wysokim poziomie.

