# Source:The Brazilian Report, URL:https://brazilian.report/feed, language:en-US

## ADNOC gives up on Braskem acquisition
 - [https://brazilian.report/liveblog/politics-insider/2024/05/06/adnoc-gives-up-on-braskem-acquisition](https://brazilian.report/liveblog/politics-insider/2024/05/06/adnoc-gives-up-on-braskem-acquisition)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-05-06T18:16:31+00:00

<p>The Abu Dhabi National Oil Company (ADNOC) is no longer interested in buying Novonor&#8217;s controlling stake in the Brazilian petrochemical giant Braskem. Since the decision was made public, Braskem&#8217;s share price crashed by almost 15 percent. ADNOC&#8217;s withdrawal from the deal comes after long negotiations and due diligence on Braskem. Initially, the Gulf company made [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2024/05/06/adnoc-gives-up-on-braskem-acquisition/">ADNOC gives up on Braskem acquisition</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Flooding in southern Brazil disrupts logistics network
 - [https://brazilian.report/liveblog/politics-insider/2024/05/06/flooding-southern-brazil-logistics](https://brazilian.report/liveblog/politics-insider/2024/05/06/flooding-southern-brazil-logistics)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-05-06T17:50:56+00:00

<p>Brazilian railway operator Rumo announced a partial interruption of its activities in southern Brazil on Monday due to the heavy rains and flooding affecting Rio Grande do Sul, the country’s southernmost state. “Train circulation is currently partially interrupted in the region and damage to assets is still being duly measured,” the company said in a [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2024/05/06/flooding-southern-brazil-logistics/">Flooding in southern Brazil disrupts logistics network</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Tech Roundup: Are Brazilians willing to use crypto for payments?
 - [https://brazilian.report/tech/2024/05/06/willing-use-crypto-payments](https://brazilian.report/tech/2024/05/06/willing-use-crypto-payments)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-05-06T16:02:39+00:00

<p>The post <a href="https://brazilian.report/tech/2024/05/06/willing-use-crypto-payments/">Tech Roundup: Are Brazilians willing to use crypto for payments?</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Alexandre de Moraes: between criticism and justification
 - [https://brazilian.report/power/2024/05/06/alexandre-de-moraes-criticism-justification](https://brazilian.report/power/2024/05/06/alexandre-de-moraes-criticism-justification)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-05-06T15:12:08+00:00

<p>The post <a href="https://brazilian.report/power/2024/05/06/alexandre-de-moraes-criticism-justification/">Alexandre de Moraes: between criticism and justification</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

