# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## How THIS Became The Perfect Episode of Abbott Elementary
 - [https://www.youtube.com/watch?v=PjLH9mxgEN8](https://www.youtube.com/watch?v=PjLH9mxgEN8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2024-05-06T17:00:14+00:00

Abbott Elementary has been one of the stand out sitcoms on network TV since it's debut.  Since winning Emmy's, Golden Globes, and every other award it's been nominated for, Abbott Elementary has been on a streak very few sitcoms can find in their first few seasons.  Some shows like The Office or Parks and Recreation struggled early on, but Abbott has found a way to stay fresh.  This particular episode of Abbott Elementary stands out as perfection for not only delivering a compelling story and big laughs, it changed the course of the show after it had to adapt due to the writers strike. 

#abbottelementary #quintabrunson #sitcom #nerdstalgic 

The 600+ Best TV Shows Of The Last 5 Years
https://www.ranker.com/list/the-best-new-shows-that-have-premiered-in-the-last-few-years/ranker-tv

SOURCES
https://collider.com/abbott-elementary-season-3-janine-new-job/
https://collider.com/abbott-elementary-season-3-barbara/
https://screenrant.com/abbott-elementary-season-3-episode-5-zack-jacob-break

