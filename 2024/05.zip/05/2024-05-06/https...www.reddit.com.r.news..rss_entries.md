# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## China hacked Ministry of Defence, Sky News learns
 - [https://www.reddit.com/r/news/comments/1cluspa/china_hacked_ministry_of_defence_sky_news_learns](https://www.reddit.com/r/news/comments/1cluspa/china_hacked_ministry_of_defence_sky_news_learns)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T21:33:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/WelshCai"> /u/WelshCai </a> <br /> <span><a href="https://news.sky.com/story/china-hacked-ministry-of-defence-sky-news-learns-13130757">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cluspa/china_hacked_ministry_of_defence_sky_news_learns/">[comments]</a></span>

## World Food Programme Director Cindy McCain: Northern Gaza is in a 'full-blown famine'
 - [https://www.reddit.com/r/news/comments/1clspal/world_food_programme_director_cindy_mccain](https://www.reddit.com/r/news/comments/1clspal/world_food_programme_director_cindy_mccain)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T20:06:48+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/strangle_me_daddy"> /u/strangle_me_daddy </a> <br /> <span><a href="https://www.nbcnews.com/news/rcna150644">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clspal/world_food_programme_director_cindy_mccain/">[comments]</a></span>

## US Army sergeant arrested in Russia accused of theft
 - [https://www.reddit.com/r/news/comments/1cls6q0/us_army_sergeant_arrested_in_russia_accused_of](https://www.reddit.com/r/news/comments/1cls6q0/us_army_sergeant_arrested_in_russia_accused_of)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T19:46:14+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/For_All_Humanity"> /u/For_All_Humanity </a> <br /> <span><a href="https://www.bbc.com/news/world-us-canada-68966860">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cls6q0/us_army_sergeant_arrested_in_russia_accused_of/">[comments]</a></span>

## Texas judge allows alleged QAnon libel lawsuit against Anti-Defamation League to move forward
 - [https://www.reddit.com/r/news/comments/1clrk0x/texas_judge_allows_alleged_qanon_libel_lawsuit](https://www.reddit.com/r/news/comments/1clrk0x/texas_judge_allows_alleged_qanon_libel_lawsuit)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T19:20:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://www.tpr.org/news/2024-05-03/texas-judge-allows-alleged-qanon-libel-lawsuit-against-anti-defamation-league-to-move-forward">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clrk0x/texas_judge_allows_alleged_qanon_libel_lawsuit/">[comments]</a></span>

## U.S. soldier detained in Russia, officials say
 - [https://www.reddit.com/r/news/comments/1clrj6i/us_soldier_detained_in_russia_officials_say](https://www.reddit.com/r/news/comments/1clrj6i/us_soldier_detained_in_russia_officials_say)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T19:19:21+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/besselfunctions"> /u/besselfunctions </a> <br /> <span><a href="https://www.nbcnews.com/politics/politics-news/us-soldier-detained-russia-officials-say-rcna150928">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clrj6i/us_soldier_detained_in_russia_officials_say/">[comments]</a></span>

## Hamas says it accepts ceasefire proposal of Egypt, Qatar
 - [https://www.reddit.com/r/news/comments/1clnq7n/hamas_says_it_accepts_ceasefire_proposal_of_egypt](https://www.reddit.com/r/news/comments/1clnq7n/hamas_says_it_accepts_ceasefire_proposal_of_egypt)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T16:44:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/seakucumber"> /u/seakucumber </a> <br /> <span><a href="https://www.reuters.com/world/middle-east/hamas-says-it-accepts-ceasefire-proposal-egypt-qatar-2024-05-06/?utm_source=twitter&amp;utm_medium=Social">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clnq7n/hamas_says_it_accepts_ceasefire_proposal_of_egypt/">[comments]</a></span>

## Single-sex toilets to be required in non-residential buildings in England
 - [https://www.reddit.com/r/news/comments/1clnm3t/singlesex_toilets_to_be_required_in](https://www.reddit.com/r/news/comments/1clnm3t/singlesex_toilets_to_be_required_in)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T16:39:37+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/semolous"> /u/semolous </a> <br /> <span><a href="https://www.theguardian.com/uk-news/article/2024/may/06/gender-specific-toilets-to-be-required-in-non-residential-buildings-in-england">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clnm3t/singlesex_toilets_to_be_required_in/">[comments]</a></span>

## Person dies after falling from the stands at Ohio State graduation ceremony
 - [https://www.reddit.com/r/news/comments/1clnhoq/person_dies_after_falling_from_the_stands_at_ohio](https://www.reddit.com/r/news/comments/1clnhoq/person_dies_after_falling_from_the_stands_at_ohio)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T16:34:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://www.cnn.com/2024/05/06/us/person-dies-after-falling-from-the-stands-at-ohio-state-graduation-ceremony/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clnhoq/person_dies_after_falling_from_the_stands_at_ohio/">[comments]</a></span>

## Teen hands himself into police after attack on German politician
 - [https://www.reddit.com/r/news/comments/1cln5q7/teen_hands_himself_into_police_after_attack_on](https://www.reddit.com/r/news/comments/1cln5q7/teen_hands_himself_into_police_after_attack_on)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T16:21:10+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Embire"> /u/Embire </a> <br /> <span><a href="https://edition.cnn.com/2024/05/05/europe/teen-admits-matthias-ecke-attack-germany-intl/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cln5q7/teen_hands_himself_into_police_after_attack_on/">[comments]</a></span>

## A man points a gun at a pastor at church before getting tackled
 - [https://www.reddit.com/r/news/comments/1cllrky/a_man_points_a_gun_at_a_pastor_at_church_before](https://www.reddit.com/r/news/comments/1cllrky/a_man_points_a_gun_at_a_pastor_at_church_before)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T15:24:38+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/rytis"> /u/rytis </a> <br /> <span><a href="https://www.cnn.com/2024/05/06/us/man-points-gun-at-pennsylvania-pastor/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cllrky/a_man_points_a_gun_at_a_pastor_at_church_before/">[comments]</a></span>

## Russia to Carry Out Exercises for Tactical Nuclear Weapons
 - [https://www.reddit.com/r/news/comments/1clli81/russia_to_carry_out_exercises_for_tactical](https://www.reddit.com/r/news/comments/1clli81/russia_to_carry_out_exercises_for_tactical)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T15:13:57+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Miguenzo"> /u/Miguenzo </a> <br /> <span><a href="https://www.wsj.com/world/russia/russia-to-carry-out-exercises-for-tactical-nuclear-weapons-923622df">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clli81/russia_to_carry_out_exercises_for_tactical/">[comments]</a></span>

## Naked Florida woman, 24, arrested after breaking into neighbor's home: police
 - [https://www.reddit.com/r/news/comments/1clkmue/naked_florida_woman_24_arrested_after_breaking](https://www.reddit.com/r/news/comments/1clkmue/naked_florida_woman_24_arrested_after_breaking)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T14:37:39+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/zekeboy45"> /u/zekeboy45 </a> <br /> <span><a href="https://www.fox35orlando.com/news/naked-florida-woman-24-arrested-after-breaking-into-neighbors-home-police">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clkmue/naked_florida_woman_24_arrested_after_breaking/">[comments]</a></span>

## 'Afraid for her life:' Reports detail harassment ahead of Mica Miller's death
 - [https://www.reddit.com/r/news/comments/1clkgi1/afraid_for_her_life_reports_detail_harassment](https://www.reddit.com/r/news/comments/1clkgi1/afraid_for_her_life_reports_detail_harassment)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T14:30:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/_Z_E_R_O"> /u/_Z_E_R_O </a> <br /> <span><a href="https://wpde.com/news/local/mica-miller-john-paul-jp-pastors-wife-solid-rock-church-death-investigation-suicide-rally-justice-for-mica-police-report-tire-gps-tracking-device-east-coast-honda-dealership-myrtle-beach-south-carolina">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clkgi1/afraid_for_her_life_reports_detail_harassment/">[comments]</a></span>

## Trump fined $1,000 for gag order violation in hush money case as judge warns of possible jail time
 - [https://www.reddit.com/r/news/comments/1cljty8/trump_fined_1000_for_gag_order_violation_in_hush](https://www.reddit.com/r/news/comments/1cljty8/trump_fined_1000_for_gag_order_violation_in_hush)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T14:02:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://www.denver7.com/news/national-politics/trump-fined-1-000-for-gag-order-violation-in-hush-money-case-as-judge-warns-of-possible-jail-time">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cljty8/trump_fined_1000_for_gag_order_violation_in_hush/">[comments]</a></span>

## Columbia cancels main graduation amid Gaza protests - BBC News
 - [https://www.reddit.com/r/news/comments/1cliyyf/columbia_cancels_main_graduation_amid_gaza](https://www.reddit.com/r/news/comments/1cliyyf/columbia_cancels_main_graduation_amid_gaza)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T13:24:03+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/zlex"> /u/zlex </a> <br /> <span><a href="https://www.bbc.co.uk/news/world-us-canada-68965723.amp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cliyyf/columbia_cancels_main_graduation_amid_gaza/">[comments]</a></span>

## Boeing's new Starliner capsule set for first crewed flight to space station
 - [https://www.reddit.com/r/news/comments/1clicpp/boeings_new_starliner_capsule_set_for_first](https://www.reddit.com/r/news/comments/1clicpp/boeings_new_starliner_capsule_set_for_first)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T12:55:49+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Embire"> /u/Embire </a> <br /> <span><a href="https://www.reuters.com/science/boeings-new-starliner-capsule-set-first-crewed-flight-space-station-2024-05-06/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clicpp/boeings_new_starliner_capsule_set_for_first/">[comments]</a></span>

## Woman wins $1m lottery jackpot twice in 10 weeks
 - [https://www.reddit.com/r/news/comments/1clhkzp/woman_wins_1m_lottery_jackpot_twice_in_10_weeks](https://www.reddit.com/r/news/comments/1clhkzp/woman_wins_1m_lottery_jackpot_twice_in_10_weeks)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T12:16:32+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Similar_Rutabaga_593"> /u/Similar_Rutabaga_593 </a> <br /> <span><a href="https://news.sky.com/story/woman-wins-1m-jackpot-on-the-lottery-twice-in-10-weeks-13127876">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clhkzp/woman_wins_1m_lottery_jackpot_twice_in_10_weeks/">[comments]</a></span>

## Half of all IDF ammunition in war comes from U.S., report shows
 - [https://www.reddit.com/r/news/comments/1clh1db/half_of_all_idf_ammunition_in_war_comes_from_us](https://www.reddit.com/r/news/comments/1clh1db/half_of_all_idf_ammunition_in_war_comes_from_us)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T11:47:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/yqopmin"> /u/yqopmin </a> <br /> <span><a href="https://www.ynetnews.com/business/article/b1slbxig0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clh1db/half_of_all_idf_ammunition_in_war_comes_from_us/">[comments]</a></span>

## German foreign minister says Russia will face consequences for monthslong cyber espionage
 - [https://www.reddit.com/r/news/comments/1clfam8/german_foreign_minister_says_russia_will_face](https://www.reddit.com/r/news/comments/1clfam8/german_foreign_minister_says_russia_will_face)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T10:00:23+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Paul-Belgium"> /u/Paul-Belgium </a> <br /> <span><a href="https://apnews.com/article/australia-germany-china-cyberattack-russia-a31cc8063a07bdedd14b867b0f0b5971">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clfam8/german_foreign_minister_says_russia_will_face/">[comments]</a></span>

## Mexico: Surfers found dead in well were shot in head
 - [https://www.reddit.com/r/news/comments/1clewxs/mexico_surfers_found_dead_in_well_were_shot_in](https://www.reddit.com/r/news/comments/1clewxs/mexico_surfers_found_dead_in_well_were_shot_in)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T09:32:53+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/MuhammedBzdanul"> /u/MuhammedBzdanul </a> <br /> <span><a href="https://www.bbc.com/news/articles/cd13vgg720jo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clewxs/mexico_surfers_found_dead_in_well_were_shot_in/">[comments]</a></span>

## Israeli army tells Palestinians to evacuate parts of Rafah in Gaza ahead of an expected assault
 - [https://www.reddit.com/r/news/comments/1clej1e/israeli_army_tells_palestinians_to_evacuate_parts](https://www.reddit.com/r/news/comments/1clej1e/israeli_army_tells_palestinians_to_evacuate_parts)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T09:05:26+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Puzzleheaded-Reply-9"> /u/Puzzleheaded-Reply-9 </a> <br /> <span><a href="https://apnews.com/article/israel-palestinians-gaza-hamas-war-humanitarian-aid-8659eae6e0a7362504f0aa4aa4be53e0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clej1e/israeli_army_tells_palestinians_to_evacuate_parts/">[comments]</a></span>

## PlayStation Reverses Course on Helldivers 2 PSN Account Requirement - IGN
 - [https://www.reddit.com/r/news/comments/1clcw73/playstation_reverses_course_on_helldivers_2_psn](https://www.reddit.com/r/news/comments/1clcw73/playstation_reverses_course_on_helldivers_2_psn)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T07:08:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/PunixGT"> /u/PunixGT </a> <br /> <span><a href="https://www.ign.com/articles/playstation-reverses-course-on-helldivers-2-psn-account-requirement">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clcw73/playstation_reverses_course_on_helldivers_2_psn/">[comments]</a></span>

## Law enforcement release more details on missing infant, deadly shooting
 - [https://www.reddit.com/r/news/comments/1clc6lh/law_enforcement_release_more_details_on_missing](https://www.reddit.com/r/news/comments/1clc6lh/law_enforcement_release_more_details_on_missing)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T06:19:11+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/StrikeForceOne"> /u/StrikeForceOne </a> <br /> <span><a href="https://www.kob.com/new-mexico/law-enforcement-release-more-details-in-missing-infant-deadly-shooting/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clc6lh/law_enforcement_release_more_details_on_missing/">[comments]</a></span>

## Revealed: Tyson Foods dumps millions of pounds of toxic pollutants into US rivers and lakes.
 - [https://www.reddit.com/r/news/comments/1clbegs/revealed_tyson_foods_dumps_millions_of_pounds_of](https://www.reddit.com/r/news/comments/1clbegs/revealed_tyson_foods_dumps_millions_of_pounds_of)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-05-06T05:27:28+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TheRichTookItAll"> /u/TheRichTookItAll </a> <br /> <span><a href="https://www.theguardian.com/environment/2024/apr/30/tyson-foods-toxic-pollutants-lakes-rivers">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1clbegs/revealed_tyson_foods_dumps_millions_of_pounds_of/">[comments]</a></span>

