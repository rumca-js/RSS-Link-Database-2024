# Source:It's FOSS News, URL:https://news.itsfoss.com/rss, language:en-US

## Bitwarden's New Authenticator App is an Open-Source Authy Alternative
 - [https://news.itsfoss.com/bitwarden-authenticator](https://news.itsfoss.com/bitwarden-authenticator)
 - RSS feed: https://news.itsfoss.com/rss
 - date published: 2024-05-06T09:55:09+00:00

Bitwarden's authenticator app for Android and iOS. It's here!

