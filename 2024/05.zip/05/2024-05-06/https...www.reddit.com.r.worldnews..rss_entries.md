# Source:Reddit - World News, URL:https://www.reddit.com/r/worldnews/.rss, language:en

## Indian nationals charged in murder of Canadian Sikh activist
 - [https://www.reddit.com/r/worldnews/comments/1clu454/indian_nationals_charged_in_murder_of_canadian](https://www.reddit.com/r/worldnews/comments/1clu454/indian_nationals_charged_in_murder_of_canadian)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T21:05:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clu454/indian_nationals_charged_in_murder_of_canadian/"> <img alt="Indian nationals charged in murder of Canadian Sikh activist" src="https://external-preview.redd.it/QP_Cqbj8sncn_YNt2HykqWAyPc77rVBnA4DHGsu5c6c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d7296d2f318f8fafb79bff9de552574a9bd72276" title="Indian nationals charged in murder of Canadian Sikh activist" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zxNemz"> /u/zxNemz </a> <br /> <span><a href="https://www.japantimes.co.jp/news/2024/05/04/asia-pacific/politics/india-canada-arrests-killing/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clu454/indian_nationals_charged_in_murder_of_canadian/">[comments]</a></span> </td></tr></table>

## Palestinians report tanks have entered East Rafah after War Cabinet gives operation go-ahead
 - [https://www.reddit.com/r/worldnews/comments/1cltmck/palestinians_report_tanks_have_entered_east_rafah](https://www.reddit.com/r/worldnews/comments/1cltmck/palestinians_report_tanks_have_entered_east_rafah)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T20:45:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cltmck/palestinians_report_tanks_have_entered_east_rafah/"> <img alt="Palestinians report tanks have entered East Rafah after War Cabinet gives operation go-ahead" src="https://external-preview.redd.it/k1ai63jj0bLd7mN3EXFEzVpvav6SxJi1U4INtUyLdk0.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=cbda01d855d46198bbdd6588b93152768edd993d" title="Palestinians report tanks have entered East Rafah after War Cabinet gives operation go-ahead" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/pigbrotha"> /u/pigbrotha </a> <br /> <span><a href="https://www.ynetnews.com/article/b1xb11n8za">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cltmck/palestinians_report_tanks_have_entered_east_rafah/">[comments]</a></span> </td></tr></table>

## China hacked Ministry of Defence, Sky News learns
 - [https://www.reddit.com/r/worldnews/comments/1cltku5/china_hacked_ministry_of_defence_sky_news_learns](https://www.reddit.com/r/worldnews/comments/1cltku5/china_hacked_ministry_of_defence_sky_news_learns)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T20:43:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cltku5/china_hacked_ministry_of_defence_sky_news_learns/"> <img alt="China hacked Ministry of Defence, Sky News learns" src="https://external-preview.redd.it/H2sIsjWUD0hp91-25fHG3Oj9wE2nso2jSlIILI5Dl9w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=13a5bbd1cb3cdee2c74fe90f1d62cb4e34c5d49f" title="China hacked Ministry of Defence, Sky News learns" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ok-Ad-867"> /u/Ok-Ad-867 </a> <br /> <span><a href="https://news.sky.com/story/china-hacked-ministry-of-defence-sky-news-learns-13130757">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cltku5/china_hacked_ministry_of_defence_sky_news_learns/">[comments]</a></span> </td></tr></table>

## US soldier detained in Russia, White House confirms
 - [https://www.reddit.com/r/worldnews/comments/1clsyrk/us_soldier_detained_in_russia_white_house_confirms](https://www.reddit.com/r/worldnews/comments/1clsyrk/us_soldier_detained_in_russia_white_house_confirms)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T20:17:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clsyrk/us_soldier_detained_in_russia_white_house_confirms/"> <img alt="US soldier detained in Russia, White House confirms" src="https://external-preview.redd.it/4_BT4QU1O8c8thapt_i2Df7dPOe5VgpHeSC8ryN7p-Y.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=888d22ad8c3ccc43b491273a536a6629dcb2ae48" title="US soldier detained in Russia, White House confirms" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/maki23"> /u/maki23 </a> <br /> <span><a href="https://thehill.com/policy/defense/4647078-us-soldier-detained-russia/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clsyrk/us_soldier_detained_in_russia_white_house_confirms/">[comments]</a></span> </td></tr></table>

## More than 500 fall ill after eating bánh mì in Vietnam
 - [https://www.reddit.com/r/worldnews/comments/1clsmtp/more_than_500_fall_ill_after_eating_bánh_mì_in](https://www.reddit.com/r/worldnews/comments/1clsmtp/more_than_500_fall_ill_after_eating_bánh_mì_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T20:04:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clsmtp/more_than_500_fall_ill_after_eating_bánh_mì_in/"> <img alt="More than 500 fall ill after eating bánh mì in Vietnam" src="https://external-preview.redd.it/AphgrMxwqlFXyfNuAvqySvwTKp19ccmGne6sDQ1w3f0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9c228f2f21ec829668da763043faf13086162ae1" title="More than 500 fall ill after eating bánh mì in Vietnam" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Internal-Grocery-244"> /u/Internal-Grocery-244 </a> <br /> <span><a href="https://www.bbc.com/news/articles/c51n0731nklo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clsmtp/more_than_500_fall_ill_after_eating_bánh_mì_in/">[comments]</a></span> </td></tr></table>

## IDF strikes Hamas terror targets in East Rafah
 - [https://www.reddit.com/r/worldnews/comments/1clrqtw/idf_strikes_hamas_terror_targets_in_east_rafah](https://www.reddit.com/r/worldnews/comments/1clrqtw/idf_strikes_hamas_terror_targets_in_east_rafah)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T19:28:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clrqtw/idf_strikes_hamas_terror_targets_in_east_rafah/"> <img alt="IDF strikes Hamas terror targets in East Rafah" src="https://external-preview.redd.it/IFytaOR9DICA_VH3WCwODB5fWcEnUMHrGlGtHQX6zMg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=77a4e79f7127b790cc39802e7eb67784bb77bc1a" title="IDF strikes Hamas terror targets in East Rafah" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/itslalala"> /u/itslalala </a> <br /> <span><a href="https://www.jpost.com/breaking-news/article-800163">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clrqtw/idf_strikes_hamas_terror_targets_in_east_rafah/">[comments]</a></span> </td></tr></table>

## /r/WorldNews Live Thread for Israel-Hamas War (Thread #48)
 - [https://www.reddit.com/r/worldnews/comments/1clr4hv/rworldnews_live_thread_for_israelhamas_war_thread](https://www.reddit.com/r/worldnews/comments/1clr4hv/rworldnews_live_thread_for_israelhamas_war_thread)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T19:02:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clr4hv/rworldnews_live_thread_for_israelhamas_war_thread/"> <img alt="/r/WorldNews Live Thread for Israel-Hamas War (Thread #48)" src="https://a.thumbs.redditmedia.com/Mp0Gx_HomhJWx5C7CqRbB60Ywgza6uqzNaRuHwatBz4.jpg" title="/r/WorldNews Live Thread for Israel-Hamas War (Thread #48)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AutoModerator"> /u/AutoModerator </a> <br /> <span><a href="https://www.reddit.com/live/1bsso361afr0r">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clr4hv/rworldnews_live_thread_for_israelhamas_war_thread/">[comments]</a></span> </td></tr></table>

## /r/WorldNews Live Thread: Russian Invasion of Ukraine Day 803, Part 1 (Thread #949)
 - [https://www.reddit.com/r/worldnews/comments/1clqdob/rworldnews_live_thread_russian_invasion_of](https://www.reddit.com/r/worldnews/comments/1clqdob/rworldnews_live_thread_russian_invasion_of)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T18:32:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clqdob/rworldnews_live_thread_russian_invasion_of/"> <img alt="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 803, Part 1 (Thread #949)" src="https://a.thumbs.redditmedia.com/jWqSTFxxKuo9aDK8JeM4yZL4Nb_RTA85H45u1-h63L8.jpg" title="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 803, Part 1 (Thread #949)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WorldNewsMods"> /u/WorldNewsMods </a> <br /> <span><a href="https://www.reddit.com/live/18hnzysb1elcs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clqdob/rworldnews_live_thread_russian_invasion_of/">[comments]</a></span> </td></tr></table>

## Ukraine’s former Olympian weightlifter Oleksandr Pielieshenko killed in action
 - [https://www.reddit.com/r/worldnews/comments/1clqagp/ukraines_former_olympian_weightlifter_oleksandr](https://www.reddit.com/r/worldnews/comments/1clqagp/ukraines_former_olympian_weightlifter_oleksandr)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T18:28:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clqagp/ukraines_former_olympian_weightlifter_oleksandr/"> <img alt="Ukraine’s former Olympian weightlifter Oleksandr Pielieshenko killed in action" src="https://external-preview.redd.it/zYIWlzD-GpDqw1kLbJByoNIOBQLltH7EzX-Fiv8w_wk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3ac57df4ae43c99478689a80c5c170a7eaf07e92" title="Ukraine’s former Olympian weightlifter Oleksandr Pielieshenko killed in action" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/eaglemaxie"> /u/eaglemaxie </a> <br /> <span><a href="https://www.theguardian.com/sport/article/2024/may/06/ukraines-former-olympian-weightlifter-oleksandr-pielieshenko-killed-in-action">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clqagp/ukraines_former_olympian_weightlifter_oleksandr/">[comments]</a></span> </td></tr></table>

## Germany Vows to Defend Baltic Nations in Event of Russian Attack
 - [https://www.reddit.com/r/worldnews/comments/1clphl0/germany_vows_to_defend_baltic_nations_in_event_of](https://www.reddit.com/r/worldnews/comments/1clphl0/germany_vows_to_defend_baltic_nations_in_event_of)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T17:56:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clphl0/germany_vows_to_defend_baltic_nations_in_event_of/"> <img alt="Germany Vows to Defend Baltic Nations in Event of Russian Attack" src="https://external-preview.redd.it/bzqas_739gTuQ0y51L-mEBtZJxBEVf6oGA9N1xqOdPo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ec2d6d08fa92f852419a011b2e8f493a5231fd0b" title="Germany Vows to Defend Baltic Nations in Event of Russian Attack" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/OkLawfulness5555"> /u/OkLawfulness5555 </a> <br /> <span><a href="https://www.bloomberg.com/news/articles/2024-05-06/germany-vows-to-defend-baltic-nations-in-event-of-russian-attack?leadSource=reddit_wall">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clphl0/germany_vows_to_defend_baltic_nations_in_event_of/">[comments]</a></span> </td></tr></table>

## UK surgeon who described Gaza ‘massacre’ denied entry to France
 - [https://www.reddit.com/r/worldnews/comments/1clpa2e/uk_surgeon_who_described_gaza_massacre_denied](https://www.reddit.com/r/worldnews/comments/1clpa2e/uk_surgeon_who_described_gaza_massacre_denied)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T17:47:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clpa2e/uk_surgeon_who_described_gaza_massacre_denied/"> <img alt="UK surgeon who described Gaza ‘massacre’ denied entry to France" src="https://external-preview.redd.it/zXwwr9_d6mFYEhIqTwmWFDYKnl2PcOIs9CFYS8g6FK8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5e7803a7ce0642eec550b30fc290bb94ce9ab2c7" title="UK surgeon who described Gaza ‘massacre’ denied entry to France" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BasedSweet"> /u/BasedSweet </a> <br /> <span><a href="https://www.theguardian.com/world/article/2024/may/04/uk-surgeon-who-described-gaza-massacre-denied-entry-to-france">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clpa2e/uk_surgeon_who_described_gaza_massacre_denied/">[comments]</a></span> </td></tr></table>

## No ceasefire deal reached in Gaza, Israeli official says
 - [https://www.reddit.com/r/worldnews/comments/1clp15z/no_ceasefire_deal_reached_in_gaza_israeli](https://www.reddit.com/r/worldnews/comments/1clp15z/no_ceasefire_deal_reached_in_gaza_israeli)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T17:37:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clp15z/no_ceasefire_deal_reached_in_gaza_israeli/"> <img alt="No ceasefire deal reached in Gaza, Israeli official says" src="https://external-preview.redd.it/mjcNkRINYs4t98LSnSwVpc493nepMEBbPfokcJC7M6g.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=19aaacfbd921332a0e0eeb9b36a65b2a87d29deb" title="No ceasefire deal reached in Gaza, Israeli official says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/trail_phase"> /u/trail_phase </a> <br /> <span><a href="https://www.reuters.com/world/middle-east/wrapup1-israel-begins-evacuating-part-rafah-ahead-threatened-assault-2024-05-06/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clp15z/no_ceasefire_deal_reached_in_gaza_israeli/">[comments]</a></span> </td></tr></table>

## Ukraine's Foreign Ministry announces non-recognition of Putin's presidency and calls on the world to do likewise
 - [https://www.reddit.com/r/worldnews/comments/1clnvwb/ukraines_foreign_ministry_announces](https://www.reddit.com/r/worldnews/comments/1clnvwb/ukraines_foreign_ministry_announces)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T16:50:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clnvwb/ukraines_foreign_ministry_announces/"> <img alt="Ukraine's Foreign Ministry announces non-recognition of Putin's presidency and calls on the world to do likewise" src="https://external-preview.redd.it/8aea16Le8BthnyhjktbojAQJRxMaThE6TpFDQbjWgKw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=017997e1cbf90d777a0507120d0979c4f94f4223" title="Ukraine's Foreign Ministry announces non-recognition of Putin's presidency and calls on the world to do likewise" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Pravda_UA"> /u/Pravda_UA </a> <br /> <span><a href="https://www.pravda.com.ua/eng/news/2024/05/6/7454477/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clnvwb/ukraines_foreign_ministry_announces/">[comments]</a></span> </td></tr></table>

## Pentagon slams Russia's 'irresponsible' use of nuke exercises as a 'pressure tactic'
 - [https://www.reddit.com/r/worldnews/comments/1clnlyp/pentagon_slams_russias_irresponsible_use_of_nuke](https://www.reddit.com/r/worldnews/comments/1clnlyp/pentagon_slams_russias_irresponsible_use_of_nuke)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T16:39:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clnlyp/pentagon_slams_russias_irresponsible_use_of_nuke/"> <img alt="Pentagon slams Russia's 'irresponsible' use of nuke exercises as a 'pressure tactic'" src="https://external-preview.redd.it/GBK-hp8ek-CJ9Li18kEanyQsTRWLGTxZCWwkd-H-VEQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9a318fd157f752bc7c52896641aa7ce45bda8db0" title="Pentagon slams Russia's 'irresponsible' use of nuke exercises as a 'pressure tactic'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/semafornews"> /u/semafornews </a> <br /> <span><a href="https://www.semafor.com/article/05/06/2024/russia-orders-nuclear-weapons-drills-to-deter-the-west?utm_campaign=semaforreddit">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clnlyp/pentagon_slams_russias_irresponsible_use_of_nuke/">[comments]</a></span> </td></tr></table>

## 'Taboo': French women speak out on rapes by US soldiers during WWII
 - [https://www.reddit.com/r/worldnews/comments/1clmrix/taboo_french_women_speak_out_on_rapes_by_us](https://www.reddit.com/r/worldnews/comments/1clmrix/taboo_french_women_speak_out_on_rapes_by_us)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T16:05:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clmrix/taboo_french_women_speak_out_on_rapes_by_us/"> <img alt="'Taboo': French women speak out on rapes by US soldiers during WWII" src="https://external-preview.redd.it/QhL7KIdfTDdMJUfS-qxEu5BpeLlmIfx9in00trKKh7I.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0cb5a92e3942287ebd65a5e60bf4beb8f95aa127" title="'Taboo': French women speak out on rapes by US soldiers during WWII" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DoremusJessup"> /u/DoremusJessup </a> <br /> <span><a href="https://www.france24.com/en/live-news/20240506-taboo-french-women-speak-out-on-rapes-by-us-soldiers-during-wwii">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clmrix/taboo_french_women_speak_out_on_rapes_by_us/">[comments]</a></span> </td></tr></table>

## Armenia parliament speaker on his anti-Russian statements: What I said was correct, I am ready to repeat it again
 - [https://www.reddit.com/r/worldnews/comments/1clm11k/armenia_parliament_speaker_on_his_antirussian](https://www.reddit.com/r/worldnews/comments/1clm11k/armenia_parliament_speaker_on_his_antirussian)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T15:35:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clm11k/armenia_parliament_speaker_on_his_antirussian/"> <img alt="Armenia parliament speaker on his anti-Russian statements: What I said was correct, I am ready to repeat it again" src="https://external-preview.redd.it/yZrkIYCEzLexwB8x9bvHZTR2Qny2SHSA6vtjGUpPc_4.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=c6eacc27f0a739c1822b024af53c3acfb1b712eb" title="Armenia parliament speaker on his anti-Russian statements: What I said was correct, I am ready to repeat it again" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DavidofSasun"> /u/DavidofSasun </a> <br /> <span><a href="https://news.am/eng/news/821669.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clm11k/armenia_parliament_speaker_on_his_antirussian/">[comments]</a></span> </td></tr></table>

## India's Hindu nationalists are petitioning courts to tear down mosques and replace them with temples
 - [https://www.reddit.com/r/worldnews/comments/1clliyr/indias_hindu_nationalists_are_petitioning_courts](https://www.reddit.com/r/worldnews/comments/1clliyr/indias_hindu_nationalists_are_petitioning_courts)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T15:14:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clliyr/indias_hindu_nationalists_are_petitioning_courts/"> <img alt="India's Hindu nationalists are petitioning courts to tear down mosques and replace them with temples" src="https://external-preview.redd.it/tdNzcCzOk4fKN7EzvzheWNAbqZCBBE6IsGfKFP5MV8I.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=ad525d0568ebc87a61e1dc8c7e60f1040afca3b5" title="India's Hindu nationalists are petitioning courts to tear down mosques and replace them with temples" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ClassOptimal7655"> /u/ClassOptimal7655 </a> <br /> <span><a href="https://www.cbc.ca/news/world/hindu-nationalists-mosques-india-1.7193591">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clliyr/indias_hindu_nationalists_are_petitioning_courts/">[comments]</a></span> </td></tr></table>

## Russia threatens Britain with retaliation if involvement in Ukraine war deepens
 - [https://www.reddit.com/r/worldnews/comments/1cllfqr/russia_threatens_britain_with_retaliation_if](https://www.reddit.com/r/worldnews/comments/1cllfqr/russia_threatens_britain_with_retaliation_if)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T15:11:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cllfqr/russia_threatens_britain_with_retaliation_if/"> <img alt="Russia threatens Britain with retaliation if involvement in Ukraine war deepens" src="https://external-preview.redd.it/9hsQBh52YDSDoIxHsC68BgeDkihcdACnRznrjs5RQuw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6ba4bf9c94bcf89c595b0c3e0c8a5c3e665df42b" title="Russia threatens Britain with retaliation if involvement in Ukraine war deepens" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LuminousLinguist"> /u/LuminousLinguist </a> <br /> <span><a href="https://www.pbs.org/newshour/world/russia-threatens-britain-with-retaliation-if-involvement-in-ukraine-war-deepens">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cllfqr/russia_threatens_britain_with_retaliation_if/">[comments]</a></span> </td></tr></table>

## Benjamin Netanyahu rejects ceasefire demands that would 'leave Hamas intact' - as Israeli cabinet votes to close Al Jazeera office | World News
 - [https://www.reddit.com/r/worldnews/comments/1cll9zg/benjamin_netanyahu_rejects_ceasefire_demands_that](https://www.reddit.com/r/worldnews/comments/1cll9zg/benjamin_netanyahu_rejects_ceasefire_demands_that)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T15:04:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cll9zg/benjamin_netanyahu_rejects_ceasefire_demands_that/"> <img alt="Benjamin Netanyahu rejects ceasefire demands that would 'leave Hamas intact' - as Israeli cabinet votes to close Al Jazeera office | World News" src="https://external-preview.redd.it/xHnXWipVDl_7o76_Yb4TsIYkOaynfFIXWetQ-zRQvz8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=71b5f4216501bc9506a66182be6a12fdc65054bf" title="Benjamin Netanyahu rejects ceasefire demands that would 'leave Hamas intact' - as Israeli cabinet votes to close Al Jazeera office | World News" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/time_waster_3000"> /u/time_waster_3000 </a> <br /> <span><a href="https://news.sky.com/story/israels-benjamin-netanyahu-rejects-ceasefire-deal-that-would-leave-hamas-intact-13129727">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cll9zg/benjamin_netanyahu_rejects_ceasefi

## Ukraine climbs 18 spots in global press freedom ranking
 - [https://www.reddit.com/r/worldnews/comments/1cll99q/ukraine_climbs_18_spots_in_global_press_freedom](https://www.reddit.com/r/worldnews/comments/1cll99q/ukraine_climbs_18_spots_in_global_press_freedom)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T15:03:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cll99q/ukraine_climbs_18_spots_in_global_press_freedom/"> <img alt="Ukraine climbs 18 spots in global press freedom ranking" src="https://external-preview.redd.it/Ordxm52VTRKi7vH8YbjcJJgLhYs21dMe0zkM7cEIX-M.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=4ba5df2ca5a2b3eb5da6d7c9fde4d090bb133dd1" title="Ukraine climbs 18 spots in global press freedom ranking" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dhghomon"> /u/Dhghomon </a> <br /> <span><a href="https://www.kyivpost.com/post/32197">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cll99q/ukraine_climbs_18_spots_in_global_press_freedom/">[comments]</a></span> </td></tr></table>

## Russian army has already lost 475,300 invaders in Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1cll2yd/russian_army_has_already_lost_475300_invaders_in](https://www.reddit.com/r/worldnews/comments/1cll2yd/russian_army_has_already_lost_475300_invaders_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T14:56:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cll2yd/russian_army_has_already_lost_475300_invaders_in/"> <img alt="Russian army has already lost 475,300 invaders in Ukraine" src="https://external-preview.redd.it/h4DzDNkniOqv4BcoPcCWVfm9xgkbYi_kGEbwg8fbRsc.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=0fdc625882d16ca85c44b158a3e0165a276c9897" title="Russian army has already lost 475,300 invaders in Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/new974517"> /u/new974517 </a> <br /> <span><a href="https://www.ukrinform.net/rubric-ato/3860442-russian-army-has-already-lost-475300-invaders-in-ukraine.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cll2yd/russian_army_has_already_lost_475300_invaders_in/">[comments]</a></span> </td></tr></table>

## Rheinmetall CEO, Armin Papperger, reports that the company will not only deliver hundreds of thousands of artillery shells to Ukraine this year, but also some prototype shells which have a range of 100 km.
 - [https://www.reddit.com/r/worldnews/comments/1clkxl6/rheinmetall_ceo_armin_papperger_reports_that_the](https://www.reddit.com/r/worldnews/comments/1clkxl6/rheinmetall_ceo_armin_papperger_reports_that_the)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T14:50:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clkxl6/rheinmetall_ceo_armin_papperger_reports_that_the/"> <img alt="Rheinmetall CEO, Armin Papperger, reports that the company will not only deliver hundreds of thousands of artillery shells to Ukraine this year, but also some prototype shells which have a range of 100 km." src="https://external-preview.redd.it/tiIyaj5OxtTCzFn8gj-dntGshZyw7oWOGCbBm5KiWA8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4952b802074e37c504f4695cfc154e3d0236ae6b" title="Rheinmetall CEO, Armin Papperger, reports that the company will not only deliver hundreds of thousands of artillery shells to Ukraine this year, but also some prototype shells which have a range of 100 km." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/new974517"> /u/new974517 </a> <br /> <span><a href="https://www.handelsblatt.com/unternehmen/industrie/ruestungsindustrie-rheinmetall-chef-warnt-vor-scheitern-der-zeitenwende/100036758.

## Macron responded Kremlin's threats regarding possible troops deployment to Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1clkql3/macron_responded_kremlins_threats_regarding](https://www.reddit.com/r/worldnews/comments/1clkql3/macron_responded_kremlins_threats_regarding)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T14:42:05+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/new974517"> /u/new974517 </a> <br /> <span><a href="https://newsukraine.rbc.ua/news/macron-responded-kremlin-s-threats-regarding-1714907450.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clkql3/macron_responded_kremlins_threats_regarding/">[comments]</a></span>

## Ukraine is one step away from NATO invitation - PM
 - [https://www.reddit.com/r/worldnews/comments/1clkehi/ukraine_is_one_step_away_from_nato_invitation_pm](https://www.reddit.com/r/worldnews/comments/1clkehi/ukraine_is_one_step_away_from_nato_invitation_pm)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T14:27:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clkehi/ukraine_is_one_step_away_from_nato_invitation_pm/"> <img alt="Ukraine is one step away from NATO invitation - PM" src="https://external-preview.redd.it/R8v9kLv0dSEEHTSpPs5nL3jYeEG9KQnwbIGTOuWs2qE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8298326843e1931b7ef0239aeb0cb14ed6dd663a" title="Ukraine is one step away from NATO invitation - PM" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/new974517"> /u/new974517 </a> <br /> <span><a href="https://newsukraine.rbc.ua/news/ukraine-is-one-step-away-from-nato-invitation-1714984594.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clkehi/ukraine_is_one_step_away_from_nato_invitation_pm/">[comments]</a></span> </td></tr></table>

## Pro-Palestinian protesters demonstrate during Auschwitz March of the Living
 - [https://www.reddit.com/r/worldnews/comments/1clk541/propalestinian_protesters_demonstrate_during](https://www.reddit.com/r/worldnews/comments/1clk541/propalestinian_protesters_demonstrate_during)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T14:16:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clk541/propalestinian_protesters_demonstrate_during/"> <img alt="Pro-Palestinian protesters demonstrate during Auschwitz March of the Living " src="https://external-preview.redd.it/YFbtPlzFnDxDvPemMELXF4qMzOqc6_n3DFrQDS8tR38.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=cf216e0c8cab612c0d1ea2b8f03b87270c6580b3" title="Pro-Palestinian protesters demonstrate during Auschwitz March of the Living " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Master-Concept-5260"> /u/Master-Concept-5260 </a> <br /> <span><a href="https://www.ynetnews.com/article/rypvbu8za">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clk541/propalestinian_protesters_demonstrate_during/">[comments]</a></span> </td></tr></table>

## Uyghur butcher released after serving a seven-year prison sentence in Xinjiang for advising friends not to drink alcohol or smoke
 - [https://www.reddit.com/r/worldnews/comments/1cljrug/uyghur_butcher_released_after_serving_a_sevenyear](https://www.reddit.com/r/worldnews/comments/1cljrug/uyghur_butcher_released_after_serving_a_sevenyear)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T14:00:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cljrug/uyghur_butcher_released_after_serving_a_sevenyear/"> <img alt="Uyghur butcher released after serving a seven-year prison sentence in Xinjiang for advising friends not to drink alcohol or smoke" src="https://external-preview.redd.it/fKJiChozBW1rRJTfo6g6OgPSZzo_Rg7q8PYm1sSZAbU.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=36d45e5c5d058c23ad96fa66f02ae6d5c0774802" title="Uyghur butcher released after serving a seven-year prison sentence in Xinjiang for advising friends not to drink alcohol or smoke" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/whnthynvr"> /u/whnthynvr </a> <br /> <span><a href="https://www.rfa.org/english/news/uyghur/butcher-released-04222024164401.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cljrug/uyghur_butcher_released_after_serving_a_sevenyear/">[comments]</a></span> </td></tr></table>

## 3 bodies found in Mexico identified as 2 Australians, American killed in carjacking on surfing trip
 - [https://www.reddit.com/r/worldnews/comments/1clifrk/3_bodies_found_in_mexico_identified_as_2](https://www.reddit.com/r/worldnews/comments/1clifrk/3_bodies_found_in_mexico_identified_as_2)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T13:00:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clifrk/3_bodies_found_in_mexico_identified_as_2/"> <img alt="3 bodies found in Mexico identified as 2 Australians, American killed in carjacking on surfing trip" src="https://external-preview.redd.it/MPQAq9KS08NvfC0PCKXd51jLIYkyVk2seBr2W7MRisk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d000963baded23557a26b4009a53b16e7dd7e376" title="3 bodies found in Mexico identified as 2 Australians, American killed in carjacking on surfing trip" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/josh252"> /u/josh252 </a> <br /> <span><a href="https://www.nbcnews.com/news/mexico/3-bodies-found-mexico-identified-missing-surfers-rcna150790">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clifrk/3_bodies_found_in_mexico_identified_as_2/">[comments]</a></span> </td></tr></table>

## Hezbollah bombards houses of 70,000 Israelis who fled their homes on northern border
 - [https://www.reddit.com/r/worldnews/comments/1clgzin/hezbollah_bombards_houses_of_70000_israelis_who](https://www.reddit.com/r/worldnews/comments/1clgzin/hezbollah_bombards_houses_of_70000_israelis_who)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T11:44:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clgzin/hezbollah_bombards_houses_of_70000_israelis_who/"> <img alt="Hezbollah bombards houses of 70,000 Israelis who fled their homes on northern border" src="https://external-preview.redd.it/lnG9wxfphd7oQa92vvGmYRIItiX2mDjZpIaepMnbffA.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=9f8507325f8b345c95be7ead32cfadf7204e97bf" title="Hezbollah bombards houses of 70,000 Israelis who fled their homes on northern border" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/franktomi"> /u/franktomi </a> <br /> <span><a href="https://allisrael.com/hezbollah-bombards-houses-of-80-000-israelis-who-fled-their-homes-on-northern-border">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clgzin/hezbollah_bombards_houses_of_70000_israelis_who/">[comments]</a></span> </td></tr></table>

## IDF strikes Hezbollah-Radwan base after drone strike on Metula
 - [https://www.reddit.com/r/worldnews/comments/1clgso0/idf_strikes_hezbollahradwan_base_after_drone](https://www.reddit.com/r/worldnews/comments/1clgso0/idf_strikes_hezbollahradwan_base_after_drone)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T11:34:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clgso0/idf_strikes_hezbollahradwan_base_after_drone/"> <img alt="IDF strikes Hezbollah-Radwan base after drone strike on Metula" src="https://external-preview.redd.it/eX2js-ME_nUlE0CoxAwUEeehDHVbrFISL286x4YbGR4.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=3216fba154bdbee0a0c9811c86dd318179d5c432" title="IDF strikes Hezbollah-Radwan base after drone strike on Metula" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yqopmin"> /u/yqopmin </a> <br /> <span><a href="https://www.ynetnews.com/article/s1joamlmc#autoplay">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clgso0/idf_strikes_hezbollahradwan_base_after_drone/">[comments]</a></span> </td></tr></table>

## Over 23 million Afghans in dire need of humanitarian aid: UNAMA report
 - [https://www.reddit.com/r/worldnews/comments/1clg1w4/over_23_million_afghans_in_dire_need_of](https://www.reddit.com/r/worldnews/comments/1clg1w4/over_23_million_afghans_in_dire_need_of)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T10:50:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clg1w4/over_23_million_afghans_in_dire_need_of/"> <img alt="Over 23 million Afghans in dire need of humanitarian aid: UNAMA report" src="https://external-preview.redd.it/z79wgNm-A7ud7HrLR3vwvxRHFNlhVWPXZH56B4lbmVs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a1902238309666b1d6d816f3f46c1a7030db3bc5" title="Over 23 million Afghans in dire need of humanitarian aid: UNAMA report" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Away_Championship637"> /u/Away_Championship637 </a> <br /> <span><a href="https://www.indianarrative.com/world-news/over-23-million-afghans-in-dire-need-of-humanitarian-aid-unama-report-156778.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clg1w4/over_23_million_afghans_in_dire_need_of/">[comments]</a></span> </td></tr></table>

## Biden administration pauses one ammunition shipment to Israel, reason unclear | CNN Politics
 - [https://www.reddit.com/r/worldnews/comments/1clfdd2/biden_administration_pauses_one_ammunition](https://www.reddit.com/r/worldnews/comments/1clfdd2/biden_administration_pauses_one_ammunition)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T10:04:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clfdd2/biden_administration_pauses_one_ammunition/"> <img alt="Biden administration pauses one ammunition shipment to Israel, reason unclear | CNN Politics" src="https://external-preview.redd.it/MukV7J4T0xozBc3lS5Tl-oizhKktfDfQynn-P3vyZYY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c476eb5c79d597e51e1f9296bfe84e793af62b2" title="Biden administration pauses one ammunition shipment to Israel, reason unclear | CNN Politics" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/javelin3000"> /u/javelin3000 </a> <br /> <span><a href="https://www.cnn.com/2024/05/05/politics/war-israel-palestine-gaza-biden-weapons/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clfdd2/biden_administration_pauses_one_ammunition/">[comments]</a></span> </td></tr></table>

## Australian helicopter forced to take evasive action after Chinese fighter detonates flares
 - [https://www.reddit.com/r/worldnews/comments/1clemzy/australian_helicopter_forced_to_take_evasive](https://www.reddit.com/r/worldnews/comments/1clemzy/australian_helicopter_forced_to_take_evasive)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T09:13:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clemzy/australian_helicopter_forced_to_take_evasive/"> <img alt="Australian helicopter forced to take evasive action after Chinese fighter detonates flares" src="https://external-preview.redd.it/65DWCLLEtvaZME237_VGYqdyn1GTNQV12GDiaFgZPgA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3c4473e9ccd4b02cfe38a29b09ba1833c2d5381b" title="Australian helicopter forced to take evasive action after Chinese fighter detonates flares" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SUPERTHUNDERALPACA"> /u/SUPERTHUNDERALPACA </a> <br /> <span><a href="https://www.abc.net.au/news/2024-05-06/australian-helicopter-chines-fighter-flares-hmas-hobart/103812042">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clemzy/australian_helicopter_forced_to_take_evasive/">[comments]</a></span> </td></tr></table>

## NATO will directly intervene in war if Russia crosses one of two red lines - La Repubblica
 - [https://www.reddit.com/r/worldnews/comments/1cle84q/nato_will_directly_intervene_in_war_if_russia](https://www.reddit.com/r/worldnews/comments/1cle84q/nato_will_directly_intervene_in_war_if_russia)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T08:44:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cle84q/nato_will_directly_intervene_in_war_if_russia/"> <img alt="NATO will directly intervene in war if Russia crosses one of two red lines - La Repubblica" src="https://external-preview.redd.it/Z9zNArxrS3cDD8brbq2bY3LDsS1D77zUW2qrmvjoDJg.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=178b5fe683827189549c5af554216d5ca2ba1fc4" title="NATO will directly intervene in war if Russia crosses one of two red lines - La Repubblica" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Spiritual_Navigator"> /u/Spiritual_Navigator </a> <br /> <span><a href="https://www.ukrinform.net/rubric-ato/3860437-nato-will-directly-intervene-in-war-if-russia-crosses-one-of-two-red-lines-la-repubblica.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cle84q/nato_will_directly_intervene_in_war_if_russia/">[comments]</a></span> </td></tr></table>

## Argentina president Milei accepts Falklands currently British
 - [https://www.reddit.com/r/worldnews/comments/1cle6b5/argentina_president_milei_accepts_falklands](https://www.reddit.com/r/worldnews/comments/1cle6b5/argentina_president_milei_accepts_falklands)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T08:40:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cle6b5/argentina_president_milei_accepts_falklands/"> <img alt="Argentina president Milei accepts Falklands currently British" src="https://external-preview.redd.it/KWWTkILbxBGJXRRS54CVhqg2_Oh11vo3XzJGppz4fhg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9265e87a7aa637eb529e7fd53a0f07852b8c852a" title="Argentina president Milei accepts Falklands currently British" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Gyro_Armadillo"> /u/Gyro_Armadillo </a> <br /> <span><a href="https://www.bbc.com/news/articles/ce43zv3qln9o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cle6b5/argentina_president_milei_accepts_falklands/">[comments]</a></span> </td></tr></table>

## Russia to practice tactical nuclear weapon in southern military district
 - [https://www.reddit.com/r/worldnews/comments/1cldlnh/russia_to_practice_tactical_nuclear_weapon_in](https://www.reddit.com/r/worldnews/comments/1cldlnh/russia_to_practice_tactical_nuclear_weapon_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T08:00:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cldlnh/russia_to_practice_tactical_nuclear_weapon_in/"> <img alt="Russia to practice tactical nuclear weapon in southern military district" src="https://external-preview.redd.it/HhljEpIbJU0kkSHpQJJ4FHA5YL81K0nn1OL4Oxm0LUU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=12551f92e17b4b635a75a452c503ede94081e496" title="Russia to practice tactical nuclear weapon in southern military district" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Creepy-Discount-2536"> /u/Creepy-Discount-2536 </a> <br /> <span><a href="https://uk.news.yahoo.com/news/russia-practice-tactical-nuclear-weapon-073056639.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cldlnh/russia_to_practice_tactical_nuclear_weapon_in/">[comments]</a></span> </td></tr></table>

## Rains in southern Brazil leave 75 dead, 88,000 homeless and entire cities under water - Brazil Reports
 - [https://www.reddit.com/r/worldnews/comments/1cld4wn/rains_in_southern_brazil_leave_75_dead_88000](https://www.reddit.com/r/worldnews/comments/1cld4wn/rains_in_southern_brazil_leave_75_dead_88000)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T07:26:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cld4wn/rains_in_southern_brazil_leave_75_dead_88000/"> <img alt="Rains in southern Brazil leave 75 dead, 88,000 homeless and entire cities under water - Brazil Reports" src="https://external-preview.redd.it/S7-B92LJxWZej64WE8X8Mp0u0O0JxW9uke_GTl9NVpc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4cdf5e28353f40e78cef0975343330d2571dc33c" title="Rains in southern Brazil leave 75 dead, 88,000 homeless and entire cities under water - Brazil Reports" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/oneonus"> /u/oneonus </a> <br /> <span><a href="https://brazilreports.com/rains-in-southern-brazil-leave-75-dead-88000-homeless-and-entire-cities-under-water/6049/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cld4wn/rains_in_southern_brazil_leave_75_dead_88000/">[comments]</a></span> </td></tr></table>

## Methodists End Bans on Gay Clergy and Same-Sex Marriage, Closing 50 Years of Battles for Mainline Protestants
 - [https://www.reddit.com/r/worldnews/comments/1clcw7v/methodists_end_bans_on_gay_clergy_and_samesex](https://www.reddit.com/r/worldnews/comments/1clcw7v/methodists_end_bans_on_gay_clergy_and_samesex)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T07:08:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clcw7v/methodists_end_bans_on_gay_clergy_and_samesex/"> <img alt="Methodists End Bans on Gay Clergy and Same-Sex Marriage, Closing 50 Years of Battles for Mainline Protestants" src="https://external-preview.redd.it/VdyMpSwon3BaOqCZUB-xPi44ES3_lTpsQo3OPwRN3sQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ba17ff37043f1ce07c3272909c0173c1997d656b" title="Methodists End Bans on Gay Clergy and Same-Sex Marriage, Closing 50 Years of Battles for Mainline Protestants" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Otherwise_Vanilla672"> /u/Otherwise_Vanilla672 </a> <br /> <span><a href="https://news.wttw.com/2024/05/05/methodists-end-bans-gay-clergy-and-same-sex-marriage-closing-50-years-battles-mainline">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clcw7v/methodists_end_bans_on_gay_clergy_and_samesex/">[comments]</a></span> </td></tr></table>

## Soldier with the 200th Brigade from Pechenga, Russia says commanders execute their own men
 - [https://www.reddit.com/r/worldnews/comments/1clcpym/soldier_with_the_200th_brigade_from_pechenga](https://www.reddit.com/r/worldnews/comments/1clcpym/soldier_with_the_200th_brigade_from_pechenga)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T06:56:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clcpym/soldier_with_the_200th_brigade_from_pechenga/"> <img alt="Soldier with the 200th Brigade from Pechenga, Russia says commanders execute their own men" src="https://external-preview.redd.it/B0wDogwr2TyCA4xPmW6-b7nbfyni6rJoyu6w4jNpXnQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=11317d31916b6bdefbd5edc74b11f4365d31c34d" title="Soldier with the 200th Brigade from Pechenga, Russia says commanders execute their own men" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Gjrts"> /u/Gjrts </a> <br /> <span><a href="https://thebarentsobserver.com/en/security/2024/05/soldier-200th-brigade-pechenga-says-commanders-regularly-execute-their-own-men">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clcpym/soldier_with_the_200th_brigade_from_pechenga/">[comments]</a></span> </td></tr></table>

## IDF raids Hamas command center inside UNRWA HQ in central Gaza - I24NEWS
 - [https://www.reddit.com/r/worldnews/comments/1clc2ov/idf_raids_hamas_command_center_inside_unrwa_hq_in](https://www.reddit.com/r/worldnews/comments/1clc2ov/idf_raids_hamas_command_center_inside_unrwa_hq_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T06:11:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clc2ov/idf_raids_hamas_command_center_inside_unrwa_hq_in/"> <img alt="IDF raids Hamas command center inside UNRWA HQ in central Gaza - I24NEWS" src="https://external-preview.redd.it/KOxkRX04VE27mKP5vwzi9ZInNzLMWP0qRPH63Wldnes.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9ae70119b09c4a6f7c199621b09c508ec1cb085b" title="IDF raids Hamas command center inside UNRWA HQ in central Gaza - I24NEWS" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yuri_2022"> /u/yuri_2022 </a> <br /> <span><a href="https://www.i24news.tv/en/news/israel-at-war/artc-idf-raids-hamas-command-center-inside-unrwa-hq-in-central-gaza">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clc2ov/idf_raids_hamas_command_center_inside_unrwa_hq_in/">[comments]</a></span> </td></tr></table>

## IDF calls on Palestinians to evacuate eastern Rafah ahead of planned offensive
 - [https://www.reddit.com/r/worldnews/comments/1clblqa/idf_calls_on_palestinians_to_evacuate_eastern](https://www.reddit.com/r/worldnews/comments/1clblqa/idf_calls_on_palestinians_to_evacuate_eastern)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T05:40:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clblqa/idf_calls_on_palestinians_to_evacuate_eastern/"> <img alt="IDF calls on Palestinians to evacuate eastern Rafah ahead of planned offensive" src="https://external-preview.redd.it/YFXq0W8xxCjGXQuaLGGqZKD0RH2B7V6P9DpIJ6aR2mE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ad72d5f38d1c6ad245adbda5b502146677531171" title="IDF calls on Palestinians to evacuate eastern Rafah ahead of planned offensive" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/franktomi"> /u/franktomi </a> <br /> <span><a href="https://www.jpost.com/breaking-news/article-800026">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clblqa/idf_calls_on_palestinians_to_evacuate_eastern/">[comments]</a></span> </td></tr></table>

## Ukraine air force says it destroys 12 Russia-launched drones
 - [https://www.reddit.com/r/worldnews/comments/1clb9l2/ukraine_air_force_says_it_destroys_12](https://www.reddit.com/r/worldnews/comments/1clb9l2/ukraine_air_force_says_it_destroys_12)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T05:18:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clb9l2/ukraine_air_force_says_it_destroys_12/"> <img alt="Ukraine air force says it destroys 12 Russia-launched drones" src="https://external-preview.redd.it/mKqHVAGaLWiUITRbgNRDoP35M9U5u0blA-Wx_P_WJ-c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=28283100db87356cfdaee78c5280027752fa681d" title="Ukraine air force says it destroys 12 Russia-launched drones" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Witty_Squirrel2197"> /u/Witty_Squirrel2197 </a> <br /> <span><a href="https://www.reuters.com/world/europe/ukraine-air-force-says-it-destroys-12-russia-launched-drones-2024-05-06/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clb9l2/ukraine_air_force_says_it_destroys_12/">[comments]</a></span> </td></tr></table>

## Israel military begins evacuating Palestinian civilians from Rafah, radio says
 - [https://www.reddit.com/r/worldnews/comments/1clax3l/israel_military_begins_evacuating_palestinian](https://www.reddit.com/r/worldnews/comments/1clax3l/israel_military_begins_evacuating_palestinian)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T04:56:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1clax3l/israel_military_begins_evacuating_palestinian/"> <img alt="Israel military begins evacuating Palestinian civilians from Rafah, radio says" src="https://external-preview.redd.it/mKqHVAGaLWiUITRbgNRDoP35M9U5u0blA-Wx_P_WJ-c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=28283100db87356cfdaee78c5280027752fa681d" title="Israel military begins evacuating Palestinian civilians from Rafah, radio says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NewSlinger"> /u/NewSlinger </a> <br /> <span><a href="https://www.reuters.com/world/middle-east/israeli-military-begins-evacuating-palestinian-civilians-rafah-radio-says-2024-05-06/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1clax3l/israel_military_begins_evacuating_palestinian/">[comments]</a></span> </td></tr></table>

## Orbán challenger in Hungary mobilises thousands at demonstration
 - [https://www.reddit.com/r/worldnews/comments/1cladq2/orbán_challenger_in_hungary_mobilises_thousands](https://www.reddit.com/r/worldnews/comments/1cladq2/orbán_challenger_in_hungary_mobilises_thousands)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T04:23:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cladq2/orbán_challenger_in_hungary_mobilises_thousands/"> <img alt="Orbán challenger in Hungary mobilises thousands at demonstration" src="https://external-preview.redd.it/K5edKuw5hWD3gG0W6S5rueuIJLP3ymH8R2SCa86u-nk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=17d836741abfeb4327339c7231356f163d0a4cfb" title="Orbán challenger in Hungary mobilises thousands at demonstration" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/donny_i"> /u/donny_i </a> <br /> <span><a href="https://www.euronews.com/2024/05/06/orban-challenger-in-hungary-mobilises-thousands-at-demonstration">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cladq2/orbán_challenger_in_hungary_mobilises_thousands/">[comments]</a></span> </td></tr></table>

## Anne Frank Statue Is Covered Up and Draped in Palestinian Flags
 - [https://www.reddit.com/r/worldnews/comments/1cl8nlp/anne_frank_statue_is_covered_up_and_draped_in](https://www.reddit.com/r/worldnews/comments/1cl8nlp/anne_frank_statue_is_covered_up_and_draped_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T02:48:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cl8nlp/anne_frank_statue_is_covered_up_and_draped_in/"> <img alt="Anne Frank Statue Is Covered Up and Draped in Palestinian Flags" src="https://external-preview.redd.it/Wf1J3EZGbLbOPqQmQBoM2zPgYBA04H3BYfi0uwEH_tc.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=7397e8884f0791fca1a98c12a5e8a8d2917d0141" title="Anne Frank Statue Is Covered Up and Draped in Palestinian Flags" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ClickTrue1735"> /u/ClickTrue1735 </a> <br /> <span><a href="https://www.independentsentinel.com/anne-frank-statue-is-covered-up-and-draped-in-palestinian-flags/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cl8nlp/anne_frank_statue_is_covered_up_and_draped_in/">[comments]</a></span> </td></tr></table>

## 'F--k neutral': Red Cross employee allegedly broke neutrality policy with anti-Israel posts
 - [https://www.reddit.com/r/worldnews/comments/1cl7r9b/fk_neutral_red_cross_employee_allegedly_broke](https://www.reddit.com/r/worldnews/comments/1cl7r9b/fk_neutral_red_cross_employee_allegedly_broke)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T02:02:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cl7r9b/fk_neutral_red_cross_employee_allegedly_broke/"> <img alt="'F--k neutral': Red Cross employee allegedly broke neutrality policy with anti-Israel posts" src="https://external-preview.redd.it/IRWQqcasTsKKoytTIjJkWg_oa7AiXQUxaW5ClMOV11Q.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fe505a01b631a6f12b98a6ab63c3d4877769dee7" title="'F--k neutral': Red Cross employee allegedly broke neutrality policy with anti-Israel posts" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ClickTrue1735"> /u/ClickTrue1735 </a> <br /> <span><a href="https://nationalpost.com/news/world/israel-middle-east/red-cross-employee-anti-israel">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cl7r9b/fk_neutral_red_cross_employee_allegedly_broke/">[comments]</a></span> </td></tr></table>

## Korea's working-age population to dip nearly 10 mil. by 2044 amid low births
 - [https://www.reddit.com/r/worldnews/comments/1cl7616/koreas_workingage_population_to_dip_nearly_10_mil](https://www.reddit.com/r/worldnews/comments/1cl7616/koreas_workingage_population_to_dip_nearly_10_mil)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T01:31:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cl7616/koreas_workingage_population_to_dip_nearly_10_mil/"> <img alt="Korea's working-age population to dip nearly 10 mil. by 2044 amid low births" src="https://external-preview.redd.it/4RS5xjmW_RnJIyAJmREhbU2O3Pv0RKHd4tu2SDc4bxo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=22dd1344a78756a13d05b747b07267eb336b4e12" title="Korea's working-age population to dip nearly 10 mil. by 2044 amid low births" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/malcolm58"> /u/malcolm58 </a> <br /> <span><a href="https://www.koreatimes.co.kr/www/nation/2024/05/281_374068.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cl7616/koreas_workingage_population_to_dip_nearly_10_mil/">[comments]</a></span> </td></tr></table>

## While Palestinians are in the midst of a full-blown famine, Hamas bombs the Israeli aid corridor for Palestinians.
 - [https://www.reddit.com/r/worldnews/comments/1cl6mpe/while_palestinians_are_in_the_midst_of_a](https://www.reddit.com/r/worldnews/comments/1cl6mpe/while_palestinians_are_in_the_midst_of_a)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T01:04:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cl6mpe/while_palestinians_are_in_the_midst_of_a/"> <img alt="While Palestinians are in the midst of a full-blown famine, Hamas bombs the Israeli aid corridor for Palestinians." src="https://external-preview.redd.it/hC1ppAanlaYLExh_amKq0kmUDUmYwzN-6fTes2ZOKWY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ed1ddd888750fb4946dbac66677809c51bd85953" title="While Palestinians are in the midst of a full-blown famine, Hamas bombs the Israeli aid corridor for Palestinians." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/garb-aholic-"> /u/garb-aholic- </a> <br /> <span><a href="https://www.nytimes.com/2024/05/05/world/middleeast/hamas-rocket-kerem-shalom-israel.html?smid=nytcore-ios-share&amp;referringSource=articleShare&amp;sgrp=c-cb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cl6mpe/while_palestinians_are_in_the_midst_of_a/">[comments]</a></span> 

## N. Korean missile that landed in Ukraine used ‘fake’ Japan part
 - [https://www.reddit.com/r/worldnews/comments/1cl69bt/n_korean_missile_that_landed_in_ukraine_used_fake](https://www.reddit.com/r/worldnews/comments/1cl69bt/n_korean_missile_that_landed_in_ukraine_used_fake)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T00:45:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cl69bt/n_korean_missile_that_landed_in_ukraine_used_fake/"> <img alt="N. Korean missile that landed in Ukraine used ‘fake’ Japan part " src="https://external-preview.redd.it/yx3rv_6I94wOQ5Md4Sw8x7WuOrai-H-K4napLJk19s8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3326ea7a9a965b8e1f152ecdf90191fdab22f971" title="N. Korean missile that landed in Ukraine used ‘fake’ Japan part " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Saltedline"> /u/Saltedline </a> <br /> <span><a href="https://www.asahi.com/sp/ajw/articles/15256392">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cl69bt/n_korean_missile_that_landed_in_ukraine_used_fake/">[comments]</a></span> </td></tr></table>

## Media: Latvia starts digging anti-tank ditch near border with Russia
 - [https://www.reddit.com/r/worldnews/comments/1cl5faf/media_latvia_starts_digging_antitank_ditch_near](https://www.reddit.com/r/worldnews/comments/1cl5faf/media_latvia_starts_digging_antitank_ditch_near)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-05-06T00:03:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1cl5faf/media_latvia_starts_digging_antitank_ditch_near/"> <img alt="Media: Latvia starts digging anti-tank ditch near border with Russia" src="https://external-preview.redd.it/EKZR63oElQMRIMP7ap8sdWxxB7Zj7d5FkGYFp10scZc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=83dfba567809bf4e116bb78aa257bf05101a1b38" title="Media: Latvia starts digging anti-tank ditch near border with Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AbleismIsSatan"> /u/AbleismIsSatan </a> <br /> <span><a href="https://kyivindependent.com/media-latvia-starts-digging-anti-tank-ditch-near-border-with-russia/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1cl5faf/media_latvia_starts_digging_antitank_ditch_near/">[comments]</a></span> </td></tr></table>

