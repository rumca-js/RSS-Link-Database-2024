# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## Aldi’s epic snow gear sale with nothing over $100
 - [https://www.news.com.au/travel/travel-deals/aldis-epic-snow-gear-sale-with-nothing-over-100/news-story/573e31edac2063b77bab4935bb6397ef?from=rss-basic](https://www.news.com.au/travel/travel-deals/aldis-epic-snow-gear-sale-with-nothing-over-100/news-story/573e31edac2063b77bab4935bb6397ef?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-05-06T22:32:14.134858+00:00

Aldi has just dropped one of its most epic sales ever with the cheapest item only $4.99.

## Tributes continue for slain Aussie surfers Callum and Jake Robinson
 - [https://www.news.com.au/travel/travel-updates/incidents/tributes-continue-for-slain-aussie-surfers-callum-and-jake-robinson/news-story/46b1d8143a93973a468335a178bef912?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/tributes-continue-for-slain-aussie-surfers-callum-and-jake-robinson/news-story/46b1d8143a93973a468335a178bef912?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-05-06T08:53:16.962763+00:00

Emotional tributes for the Aussie surfers killed in Mexico have continued, as new details about their fate emerge.

## Ancient ruin in Jerusalem is proof bible story is real, experts say
 - [https://www.news.com.au/travel/travel-updates/experts-say-ancient-ruin-is-proof-bible-story-is-real/news-story/b9e44b98eaa8627e285b6839b8b8ae6c?from=rss-basic](https://www.news.com.au/travel/travel-updates/experts-say-ancient-ruin-is-proof-bible-story-is-real/news-story/b9e44b98eaa8627e285b6839b8b8ae6c?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-05-06T03:58:55.997666+00:00

A breakthrough archeological discovery in ancient Jerusalem is proof that a bible story is real, according to experts.

