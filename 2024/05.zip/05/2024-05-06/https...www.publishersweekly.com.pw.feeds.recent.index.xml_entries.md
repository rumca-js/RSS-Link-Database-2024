# Source:Publisher weekly, URL:https://www.publishersweekly.com/pw/feeds/recent/index.xml, language:en-US

## 'Night Watch,' 'A Day in the Life of Abed Salama,' 'King' Among 2024 Pulitzer Prize Winners
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94978-night-watch-a-day-in-the-life-of-abed-salama-king-among-2024-pulitzer-prize-winners.html](http://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94978-night-watch-a-day-in-the-life-of-abed-salama-king-among-2024-pulitzer-prize-winners.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-06T04:00:00+00:00

Novelist Jayne Anne Phillips, journalist Nathan Thrall, and biographer Jonathan Eig were among the winners of the 108th annual Pulitzer Prizes in Journalism and in Arts and Letters, announced May 6.

## PW Close-Up: Christen Karniski on Rowman & Littlefield at 75
 - [http://www.publishersweekly.com/pw/by-topic/authors/interviews/article/94903-pw-close-up-christen-karniski-on-rowman-littlefield-at-75.html](http://www.publishersweekly.com/pw/by-topic/authors/interviews/article/94903-pw-close-up-christen-karniski-on-rowman-littlefield-at-75.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-06T04:00:00+00:00



## Simon & Schuster Acquires Dutch Publisher Veen Bosch & Keuning
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/industry-deals/article/94975-simon-schuster-acquires-dutch-publisher-veen-bosch-keuning.html](http://www.publishersweekly.com/pw/by-topic/industry-news/industry-deals/article/94975-simon-schuster-acquires-dutch-publisher-veen-bosch-keuning.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-06T04:00:00+00:00



