# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Guangdong highway collapsed: 23 vehicles fell, 36 dead. How are China's infrastructures maintained?
 - [https://www.youtube.com/watch?v=ZIM1MgCrj2g](https://www.youtube.com/watch?v=ZIM1MgCrj2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2024-05-06T23:30:05+00:00

#chinainsights 

Guangdong Province in southern China suffered from many disasters in late April and early May.
Here, a bolt of lightning struck a CCP’s flag flying at a school in this province. The red-color flag means it was dyed with the blood of martyrs. It’s really a bad omen for the Chinese Communist Party CCP.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

