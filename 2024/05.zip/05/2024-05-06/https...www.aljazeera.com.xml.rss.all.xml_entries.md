# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Progressive US Senator Bernie Sanders to run for reelection
 - [https://www.aljazeera.com/news/2024/5/6/progressive-us-senator-bernie-sanders-to-run-for-reelection?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/progressive-us-senator-bernie-sanders-to-run-for-reelection?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T23:08:06+00:00

Sanders says that he will run for another term as country faces &#039;difficult political moment&#039; amid schisms over Gaza.

## Text of the Gaza ceasefire proposal approved by Hamas
 - [https://www.aljazeera.com/news/2024/5/6/text-of-the-ceasefire-proposal-approved-by-hamas?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/text-of-the-ceasefire-proposal-approved-by-hamas?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T22:04:29+00:00

The deal lays out a timetable for release of Israeli captives in Gaza and withdrawals of Israel&#039;s troops from territory.

## Here’s everything to know about Gaza truce proposal Hamas has agreed to
 - [https://www.aljazeera.com/news/2024/5/6/heres-everything-know-about-gaza-deal-hamas-agreed?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/heres-everything-know-about-gaza-deal-hamas-agreed?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T21:35:09+00:00

Palestinian group Hamas says it has agreed to an Egyptian-Qatari proposal, but Israel says it falls short of demands.

## US ‘reviewing’ Gaza ceasefire proposal, says it opposes Rafah invasion
 - [https://www.aljazeera.com/news/2024/5/6/us-reviewing-gaza-ceasefire-proposal-says-it-opposes-rafah-invasion?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/us-reviewing-gaza-ceasefire-proposal-says-it-opposes-rafah-invasion?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T21:32:33+00:00

Biden administration officials decline to share details about proposal but say they are committed to reaching deal.

## What are the implications of Israel’s ban on Al Jazeera?
 - [https://www.aljazeera.com/program/inside-story/2024/5/6/what-are-the-implications-of-israels-ban-on-al-jazeera?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/5/6/what-are-the-implications-of-israels-ban-on-al-jazeera?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T20:57:46+00:00

Qatar-based network says action by Israel&#039;s government is illegal.

## Israel needs to evaluate ceasefire deal that Hamas has agreed to, White Hou
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/israel-needs-to-evaluate-ceasefire-deal-that-hamas-has-agreed-to-white-hou?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/israel-needs-to-evaluate-ceasefire-deal-that-hamas-has-agreed-to-white-hou?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T19:59:18+00:00

White House National Security Spokesperson John Kirby said that Israel must have a chance to evaluate the possible deal.

## UK students join pro-Palestine protests
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/uk-students-join-pro-palestine-protests?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/uk-students-join-pro-palestine-protests?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T19:29:29+00:00

Students in the UK are setting up camps to show solidarity with Palestine and their post-secondary peers globally

## Journalists at Italy’s RAI strike in protest at Meloni’s government
 - [https://www.aljazeera.com/news/2024/5/6/journalists-at-italys-rai-strike-in-protest-at-melonis-government?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/journalists-at-italys-rai-strike-in-protest-at-melonis-government?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T18:37:45+00:00

The broadcaster RAI has denied censorship claims and said it is transforming into &#039;a modern digital media company&#039;.

## Hamas accepts Qatari-Egyptian proposal for Gaza ceasefire
 - [https://www.aljazeera.com/news/2024/5/6/hamas-accepts-qatari-egyptian-proposal-for-gaza-ceasefire?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/hamas-accepts-qatari-egyptian-proposal-for-gaza-ceasefire?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T17:41:14+00:00

The announcement comes as people started to flee eastern Rafah after Israel ordered tens of thousands to evacuate.

## Hamas accepts Qatari and Egyptian ceasefire proposal
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/hamas-accepts-qatari-and-egyptian-ceasefire-proposal?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/hamas-accepts-qatari-and-egyptian-ceasefire-proposal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T17:40:11+00:00

Cheers erupt in Gaza on hearing the news that Hamas has told Qatar and Egypt they will accept their ceasefire proposal.

## Pastor narrowly avoids being shot in middle of Sunday sermon
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/pastor-narrowly-avoids-being-shot-in-middle-of-sunday-sermon?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/pastor-narrowly-avoids-being-shot-in-middle-of-sunday-sermon?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T16:39:01+00:00

The livestream of a Sunday church service in Pennsylvania captured the moment a gunman tried to shoot a pastor.

## Palestinians evacuate eastern Rafah ahead of expected Israeli assault
 - [https://www.aljazeera.com/gallery/2024/5/6/palestinians-evacuate-eastern-rafah-ahead-of-expected-israeli-assault?traffic_source=rss](https://www.aljazeera.com/gallery/2024/5/6/palestinians-evacuate-eastern-rafah-ahead-of-expected-israeli-assault?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T15:34:06+00:00

Israel&#039;s military ordered the evacuation of Palestinians from eastern Rafah ahead of a ground invasion of the city.

## Growing Together: A former MOVE family reunites after prison in the US
 - [https://www.aljazeera.com/program/witness/2024/5/6/pg018026-v01-1-wit?traffic_source=rss](https://www.aljazeera.com/program/witness/2024/5/6/pg018026-v01-1-wit?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T15:30:32+00:00

As he turns 40, Mike Africa Jr experiences life with his parents for the first time after they’re released from prison.

## US campus protests of Israeli ‘genocide’ offer hope to students from Gaza
 - [https://www.aljazeera.com/features/2024/5/6/us-student-protests-of-israeli-genocide-offer-hope-to-students-from-gaza?traffic_source=rss](https://www.aljazeera.com/features/2024/5/6/us-student-protests-of-israeli-genocide-offer-hope-to-students-from-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T15:07:46+00:00

Student protests in the United States have caught the attention of students from Gaza, giving them hope for the future.

## EU to drop rule-of-law dispute with Poland
 - [https://www.aljazeera.com/news/2024/5/6/eu-to-drop-rule-of-law-dispute-with-poland?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/eu-to-drop-rule-of-law-dispute-with-poland?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T14:50:48+00:00

European Union says Poland has launched a series of measures to address concerns about judicial independence.

## Inoue vs Nery: Japanese champ defends super bantamweight titles in Tokyo
 - [https://www.aljazeera.com/sports/2024/5/6/inoue-vs-nery-japanese-champ-defends-super-bantamweight-titles-in-tokyo?traffic_source=rss](https://www.aljazeera.com/sports/2024/5/6/inoue-vs-nery-japanese-champ-defends-super-bantamweight-titles-in-tokyo?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T14:46:56+00:00

Naoya Inoue survives first-round knockdown to knock out challenger Luis Nery in the sixth round in front of 45,000 fans.

## Why is Israel forcing the evacuation of part of Rafah, Gaza’s last refuge?
 - [https://www.aljazeera.com/news/2024/5/6/why-is-israel-forcing-the-evacuation-of-part-of-rafah-gazas-last-refuge?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/why-is-israel-forcing-the-evacuation-of-part-of-rafah-gazas-last-refuge?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T14:36:19+00:00

Israel argues its security depends on disbanding Hamas battalions in Rafah as it calls on 100,000 people to evacuate.

## Columbia University cancels main commencement ceremony after Gaza protests
 - [https://www.aljazeera.com/news/2024/5/6/columbia-university-cancels-main-commencement-ceremony-after-gaza-protests?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/columbia-university-cancels-main-commencement-ceremony-after-gaza-protests?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T14:35:38+00:00

Announcement comes days after New York police raided and dispersed the Gaza solidarity encampment on Columbia&#039;s campus.

## Family says al-Shifa doctor was tortured to death in Israeli prison
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/family-says-al-shifa-doctor-was-tortured-to-death-in-israeli-prison?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/family-says-al-shifa-doctor-was-tortured-to-death-in-israeli-prison?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T14:24:38+00:00

Doctor Adnan al-Bursh&#039;s family tell Al Jazeera they believe he was tortured to death.

## Video shows moment of secondary Israeli airstrike in Rafah
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/video-shows-moment-of-secondary-israeli-airstrike-in-rafah?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/video-shows-moment-of-secondary-israeli-airstrike-in-rafah?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T14:11:32+00:00

As witnesses recorded a massive plume of smoke from an initial Israeli airstrike in Rafah, another hit the same area.

## Mexicans protest and pay tribute to murdered foreign surfers
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/mexicans-protest-and-pay-tribute-to-murdered-foreign-surfers?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/mexicans-protest-and-pay-tribute-to-murdered-foreign-surfers?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T13:35:32+00:00

The surfing community in Mexico has paid tribute to the American and two Australian tourists who were killed.

## EU urges China to use influence on Russia and Iran
 - [https://www.aljazeera.com/news/2024/5/6/eu-urges-china-to-use-influence-to-calm-russia-iran?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/eu-urges-china-to-use-influence-to-calm-russia-iran?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T13:32:59+00:00

Brussels hopes Beijing will lean on Russia to end war in Ukraine and limit Iran&#039;s missiles and drones.

## Heckler demands Netanyahu’s resignation at Holocaust memorial event
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/heckler-demands-netanyahus-resignation-at-holocaust-memorial-event?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/heckler-demands-netanyahus-resignation-at-holocaust-memorial-event?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T12:47:23+00:00

A man heckled Israel’s prime minister during a Holocaust Remembrance Day wreath-laying ceremony at Yad Vashem.

## Germany recalls ambassador to Russia citing cyberattacks
 - [https://www.aljazeera.com/news/2024/5/6/germany-recalls-russia-envoy-over-cyberattack?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/germany-recalls-russia-envoy-over-cyberattack?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T12:43:04+00:00

Berlin&#039;s recall of envoy extends diplomatic tension on eve of Putin&#039;s inauguration.

## Watching the watchdogs: How US media messed up campus protests coverage
 - [https://www.aljazeera.com/opinions/2024/5/6/watching-the-watchdogs-how-us-media-messed-up-campus-protests-coverage?traffic_source=rss](https://www.aljazeera.com/opinions/2024/5/6/watching-the-watchdogs-how-us-media-messed-up-campus-protests-coverage?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T12:41:21+00:00

Mainstream media has joined US power elites in demonising pro-Palestinian encampments on campuses.

## Tunis police raid sees refugees abandoned near the border with Algeria
 - [https://www.aljazeera.com/news/2024/5/6/tunis-police-raid-sees-refugees-abandoned-near-the-border-with-algeria?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/tunis-police-raid-sees-refugees-abandoned-near-the-border-with-algeria?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T12:15:48+00:00

Tunisia&#039;s sub-Saharan African refugees and migrants describe being victims of vilification and kidnapping nationwide.

## ‘Yemen at a crossroads’: Nearly 200 aid groups issue urgent funding appeal
 - [https://www.aljazeera.com/news/2024/5/6/yemen-at-a-crossroads-nearly-200-aid-groups-issue-urgent-funding-appeal?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/yemen-at-a-crossroads-nearly-200-aid-groups-issue-urgent-funding-appeal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T12:00:24+00:00

Only a fraction of funds needed to provide aid to millions in the war-torn country is secured, the groups say.

## Israel orders Rafah evacuation after night of intense bombardment
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/israel-orders-rafah-evacuation-after-night-of-intense-bombardment?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/israel-orders-rafah-evacuation-after-night-of-intense-bombardment?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T10:39:04+00:00

Palestinian families have begun leaving eastern Rafah after the Israeli military ordered its evacuation.

## Severe floods inundate Brazil’s southernmost state, displacing thousands
 - [https://www.aljazeera.com/program/newsfeed/2024/5/6/severe-floods-inundate-brazils-southernmost-state-displacing-thousands?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/6/severe-floods-inundate-brazils-southernmost-state-displacing-thousands?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T10:14:07+00:00

Flooding in Brazil has displaced more than 115,000 people and left close to 80 dead.

## Russia announces nuclear weapon drills after ‘provocative’ Western threats
 - [https://www.aljazeera.com/news/2024/5/6/russia-announces-nuclear-weapon-drills-after-provocative-western-threats?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/russia-announces-nuclear-weapon-drills-after-provocative-western-threats?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T10:03:24+00:00

Exercises involving tactical nuclear weapons to be held after top European leaders indicated deepening Ukraine backing.

## Death toll from southern Brazil rainfall rises with many still missing
 - [https://www.aljazeera.com/gallery/2024/5/6/death-toll-from-southern-brazil-rainfall-rises-with-many-still-missing?traffic_source=rss](https://www.aljazeera.com/gallery/2024/5/6/death-toll-from-southern-brazil-rainfall-rises-with-many-still-missing?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T09:59:24+00:00

The disaster in Brazil’s southern Rio Grande do Sul state has killed at least 78 people over the last seven days.

## Ukraine marks its third Easter at war
 - [https://www.aljazeera.com/gallery/2024/5/6/ukraine-marks-its-third-easter-at-war?traffic_source=rss](https://www.aljazeera.com/gallery/2024/5/6/ukraine-marks-its-third-easter-at-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T09:40:42+00:00

Russia has launched a barrage of drones on eastern Ukraine and claimed its troops took control of a village.

## Israel orders Rafah evacuation as Gaza truce talks stall
 - [https://www.aljazeera.com/news/2024/5/6/israeli-forces-call-on-palestinians-in-gazas-eastern-rafah-to-evacuate?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/israeli-forces-call-on-palestinians-in-gazas-eastern-rafah-to-evacuate?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T09:03:06+00:00

Blaming Hamas for deadlocked negotiations, Israel appears set to launch threatened offensive on southern Gaza city.

## Stand-in Jose Raul Mulino wins Panama presidential race
 - [https://www.aljazeera.com/news/2024/5/6/mulino-wins-panama-presidential-race?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/mulino-wins-panama-presidential-race?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T08:23:13+00:00

The stand-in for banned ex-President Ricardo Martinelli has promised to boost the economy.

## A Eurovision like no other: Israel’s war on Gaza takes centre stage
 - [https://www.aljazeera.com/news/longform/2024/5/6/a-eurovision-like-no-other-israels-war-on-gaza-takes-centre-stage?traffic_source=rss](https://www.aljazeera.com/news/longform/2024/5/6/a-eurovision-like-no-other-israels-war-on-gaza-takes-centre-stage?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T08:11:10+00:00

The annual singing show takes place in Malmo amid boycott calls, demonstrations, and alternative &#039;genocide-free&#039; events.

## President vs Prime Minister: What’s at stake in Chad presidential election?
 - [https://www.aljazeera.com/news/2024/5/6/president-vs-prime-minister-whats-at-stake-in-chad-presidential-election?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/president-vs-prime-minister-whats-at-stake-in-chad-presidential-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T07:55:09+00:00

Chad has been battling political upheaval since 2021 when longtime ruler Idriss Deby died and his son seized power.

## ‘Don’t want to fight’: Ukrainians abroad slam plan to deny embassy services
 - [https://www.aljazeera.com/news/2024/5/6/dont-want-to-fight-ukrainians-abroad-slam-plan-to-deny-embassy-services?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/dont-want-to-fight-ukrainians-abroad-slam-plan-to-deny-embassy-services?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T07:45:49+00:00

Short on soldiers to fight Russia, Kyiv says it will suspend consular access to military-age men outside Ukraine.

## Who is left behind from Vietnamese migration to the UK?
 - [https://www.aljazeera.com/opinions/2024/5/6/who-is-left-behind-from-vietnamese-migration-to-the-uk?traffic_source=rss](https://www.aljazeera.com/opinions/2024/5/6/who-is-left-behind-from-vietnamese-migration-to-the-uk?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T07:34:09+00:00

The only victims of transnational migration are not those who are on the move.

## Miami GP: McLaren’s Lando Norris pips Verstappen in career’s first F1 win
 - [https://www.aljazeera.com/sports/2024/5/6/miami-gp-mclarens-lando-norris-pips-verstappen-in-careers-first-f1-win?traffic_source=rss](https://www.aljazeera.com/sports/2024/5/6/miami-gp-mclarens-lando-norris-pips-verstappen-in-careers-first-f1-win?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T06:34:46+00:00

Briton Lando Norris, who won the race in his 110th attempt, says it was about time he finished first on the podium.

## NBA playoffs: Mitchell leads Cavs to semis with win over Magic
 - [https://www.aljazeera.com/sports/2024/5/6/nba-playoffs-mitchell-leads-cavs-to-semis-with-win-over-magic?traffic_source=rss](https://www.aljazeera.com/sports/2024/5/6/nba-playoffs-mitchell-leads-cavs-to-semis-with-win-over-magic?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T06:34:11+00:00

Donovan Mitchell scored 39 points as Cavs overcame an 18-point deficit to win the seven-game series with 106-94 score.

## India Lok Sabha election 2024 phase 3: Who votes and what’s at stake?
 - [https://www.aljazeera.com/news/2024/5/6/india-lok-sabha-election-2024-phase-3-who-votes-and-whats-at-stake?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/india-lok-sabha-election-2024-phase-3-who-votes-and-whats-at-stake?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T05:37:17+00:00

Voters in 94 constituencies in 12 states, territories go to polls on May 7 in latest phase of world’s largest election.

## Bodies of murdered Australian, US surfers identified in Mexico
 - [https://www.aljazeera.com/news/2024/5/6/bodies-of-murdered-australian-us-surfers-identified-in-mexico?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/bodies-of-murdered-australian-us-surfers-identified-in-mexico?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T04:30:35+00:00

The three men were killed during a camping and surfing trip along Mexico&#039;s Pacific coast.

## Australia’s Qantas to pay $79m over ‘ghost flights’ furore
 - [https://www.aljazeera.com/economy/2024/5/6/australias-qantas-to-pay-66m-over-ghost-flights-furore?traffic_source=rss](https://www.aljazeera.com/economy/2024/5/6/australias-qantas-to-pay-66m-over-ghost-flights-furore?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T04:23:27+00:00

Competition watchdog says national carrier&#039;s advertising of cancelled flights was &#039;egregious and unacceptable&#039;.

## Russia-Ukraine war: List of key events, day 802
 - [https://www.aljazeera.com/news/2024/5/6/russia-ukraine-war-list-of-key-events-day-802?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/russia-ukraine-war-list-of-key-events-day-802?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T02:42:01+00:00

As the war enters its 802nd day, these are the main developments.

## Xi Jinping begins first European tour in five years in France
 - [https://www.aljazeera.com/news/2024/5/6/xjp-jinping-begins-first-european-tour-in-five-years-in-france?traffic_source=rss](https://www.aljazeera.com/news/2024/5/6/xjp-jinping-begins-first-european-tour-in-five-years-in-france?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T02:06:37+00:00

Chinese president wants to repair ties with a sceptical Western Europe but faces questions over his Ukraine war stance.

## EU’s von der Leyen to urge ‘fair’ China competition in talks with Xi
 - [https://www.aljazeera.com/economy/2024/5/6/eus-von-der-leyen-to-urge-fair-china-competition-in-talks-with-xi?traffic_source=rss](https://www.aljazeera.com/economy/2024/5/6/eus-von-der-leyen-to-urge-fair-china-competition-in-talks-with-xi?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T01:42:05+00:00

Chinese President Xi Jinping set to hold talks with Ursula von der Leyen and French President Emmanuel Macron in Paris.

## India elections turn spotlight on informal jobs for youth
 - [https://www.aljazeera.com/economy/2024/5/6/india-elections-focus-on-increasing-informalisation-of-work-for-youth?traffic_source=rss](https://www.aljazeera.com/economy/2024/5/6/india-elections-focus-on-increasing-informalisation-of-work-for-youth?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-06T01:36:19+00:00

India’s workforce is becoming more informalised and the quality of employment has suffered since the COVID-19 pandemic.

