# Source:TIME - tech, URL:https://time.com/tech/feed, language:en-UK

## Jack Dorsey Leaves BlueSky Board and Calls X ‘Freedom Technology’
 - [https://time.com/6974971/jack-dorsey-leaves-bluesky-board](https://time.com/6974971/jack-dorsey-leaves-bluesky-board)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-05-06T07:00:00+00:00

The Twitter founder’s moves suggest an apparent warming of relations between him and Elon Musk.

