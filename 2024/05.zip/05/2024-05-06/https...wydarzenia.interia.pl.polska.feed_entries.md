# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Sędzia Tomasz Szmydt poprosił o azyl na Białorusi. Jest komunikat sądu
 - [https://wydarzenia.interia.pl/kraj/news-sedzia-tomasz-szmydt-poprosil-o-azyl-na-bialorusi-jest-komun,nId,7493745](https://wydarzenia.interia.pl/kraj/news-sedzia-tomasz-szmydt-poprosil-o-azyl-na-bialorusi-jest-komun,nId,7493745)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-05-06T12:25:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sedzia-tomasz-szmydt-poprosil-o-azyl-na-bialorusi-jest-komun,nId,7493745"><img align="left" alt="Sędzia Tomasz Szmydt poprosił o azyl na Białorusi. Jest komunikat sądu " src="https://i.iplsc.com/sedzia-tomasz-szmydt-poprosil-o-azyl-na-bialorusi-jest-komun/000G87D762U532YS-C321.jpg" /></a>Wojewódzki Sąd Administracyjny w Warszawie wydał komunikat, w którym przekazał, że od 22 kwietnia do 10 maja Szmydt przebywa na urlopie wypoczynkowym. Prezes sądu nie otrzymał informacji od sędziego o zrzeczeniu się urzędu. Ponadto w oświadczeniu wskazano, że kierownictwo WSA nie posiada żadnych informacji o prośbie o azyl, poza doniesieniami medialnymi.</p><br clear="all" />

## Matura 2024. Na część uczniów czeka jedna ważna zmiana
 - [https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-na-czesc-uczniow-czeka-jedna-wazna-zmiana,nId,7262714](https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-na-czesc-uczniow-czeka-jedna-wazna-zmiana,nId,7262714)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-05-06T09:15:59+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-na-czesc-uczniow-czeka-jedna-wazna-zmiana,nId,7262714"><img align="left" alt="Matura 2024. Na część uczniów czeka jedna ważna zmiana" src="https://i.iplsc.com/matura-2024-na-czesc-uczniow-czeka-jedna-wazna-zmiana/000CJD5ATMOII2PH-C321.jpg" /></a>W tym roku maturzyści pierwszy egzamin napiszą 7 maja. Uczniowie techników po raz pierwszy przystąpią do matur przygotowanych w nowej formule. Kilka zmian dotknie także tegorocznych absolwentów liceów. Co nowego pojawi się na maturze w 2024 roku? Jakie zmiany zapowiedziano na kolejne lata? Wyjaśniamy. </p><br clear="all" />

## Mrozy jeszcze nas zaskoczą. Podano konkretny termin
 - [https://wydarzenia.interia.pl/kraj/news-mrozy-jeszcze-nas-zaskocza-podano-konkretny-termin,nId,7493527](https://wydarzenia.interia.pl/kraj/news-mrozy-jeszcze-nas-zaskocza-podano-konkretny-termin,nId,7493527)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-05-06T08:50:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mrozy-jeszcze-nas-zaskocza-podano-konkretny-termin,nId,7493527"><img align="left" alt="Mrozy jeszcze nas zaskoczą. Podano konkretny termin" src="https://i.iplsc.com/mrozy-jeszcze-nas-zaskocza-podano-konkretny-termin/000J2H5G5436LFFS-C321.jpg" /></a>Majówka zakończyła się gwałtownym, burzowym akcentem. To jednak nie koniec zmian. Wiele wskazuje na to, że kolejne dni również przyniosą nieprzyjemne zwroty w pogodzie. Zrobi się chłodniej, a miejscami w nocy wrócą też przymrozki. Według synoptyków czeka nas chłodny tydzień.</p><br clear="all" />

