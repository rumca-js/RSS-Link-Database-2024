# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## She’s here!
 - [https://seths.blog/2024/05/shes-here](https://seths.blog/2024/05/shes-here)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-05-06T08:04:00+00:00

Some restaurants keep a photo of the local reviewer in the kitchen. The thinking is that if someone notices she&#8217;s in the building, everyone can up their game. And some musicians wait eagerly for A&#38;R person to be in the crowd. If they really kill it tonight, a record deal might ensue. The most resilient [&#8230;]

