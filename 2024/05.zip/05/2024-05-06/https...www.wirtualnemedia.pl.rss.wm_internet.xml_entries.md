# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Już nie poprosisz o pieniądze na Facebooku i Instagramie
 - [https://www.wirtualnemedia.pl/artykul/zbiorki-na-facebooku-instagramie-koniec](https://www.wirtualnemedia.pl/artykul/zbiorki-na-facebooku-instagramie-koniec)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-05-06T04:55:26.608952+00:00

Z Facebooka i Instagrama znika popularna funkcja pozwalająca na organizację zbiórek organizacji dobroczynnych działających w krajach Europejskiego Obszaru Gospodarczego. Ostatni dzień na tego rodzaju wpłaty to 30 czerwca 2024 roku.

## Google zapłaci miliony za treści AI?
 - [https://www.wirtualnemedia.pl/artykul/google-zaplaci-miliony-za-tresci-ai](https://www.wirtualnemedia.pl/artykul/google-zaplaci-miliony-za-tresci-ai)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-05-06T03:50:53.930847+00:00

Alphabet, właściciel Google, podpisał umowę z News Corp., wydawcy m.in „Wall Street Journal” na opracowanie nowych treści i produktów związanych ze sztuczną inteligencją, podał serwis The Information.

## YouTube "czyści" polską platformę. Jaka jest skala walki Google z dezinformacją?
 - [https://www.wirtualnemedia.pl/artykul/youtube-czysci-polska-platforme-jaka-jest-skala-walki-google-z-dezinformacja](https://www.wirtualnemedia.pl/artykul/youtube-czysci-polska-platforme-jaka-jest-skala-walki-google-z-dezinformacja)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-05-06T03:50:53.806441+00:00

- Usunęliśmy 35 000 filmów z adresem IP w Unii Europejskiej z powodu naruszenia polityki YouTube dotyczącej dezinformacji - poinformował po raz pierwszy David Wheeldon, senior director of government affairs and public policy, YouTube, Europe. Menadżer podzielił się także statystyką, ile filmów z dezinformacją udało się usunąć tylko w zeszłym roku z polskiego YouTube'a.

## Video Brothers z wyższym zyskiem. Pandora Gate objęła wzrost o 20 proc.
 - [https://www.wirtualnemedia.pl/artykul/video-brothers-ile-zarabia-lukasz-skalik-z-youtube](https://www.wirtualnemedia.pl/artykul/video-brothers-ile-zarabia-lukasz-skalik-z-youtube)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-05-06T03:50:53.674940+00:00

Socialmediowa sieć partnerska Video Brothers w ub.r. przy wzroście przychodów o 6,1 proc. do 8,73 mln zł zarobiła na czysto 2,71 mln zł, nieco więcej niż przed rokiem. Firma szacuje, że jej wyniki byłyby o jedną piątą wyższe, gdyby nie afera Pandora Gate z jesieni ub.r.

