# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Nvidia may have learned from its past VRAM mistakes
 - [https://www.digitaltrends.com/computing/nvidia-blackwell-rtx-50-laptop-leak](https://www.digitaltrends.com/computing/nvidia-blackwell-rtx-50-laptop-leak)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-05-06T19:16:23.400494+00:00

The latest leak about Nvidia's RTX 50-series spells good news for laptop gamers -- but only at certain budgets.

## The sad reality of AMD’s next-gen GPUs comes into view
 - [https://www.digitaltrends.com/computing/amd-rdna-4-navi-48-spotted](https://www.digitaltrends.com/computing/amd-rdna-4-navi-48-spotted)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-05-06T11:41:01.580518+00:00

We finally have our first sign of AMD's upcoming RDNA 4 graphics card, and it appears to confirm some of the previous rumors.

## Apple finally has a way to defeat ChatGPT
 - [https://www.digitaltrends.com/computing/apple-is-getting-ready-to-beat-chatgpt](https://www.digitaltrends.com/computing/apple-is-getting-ready-to-beat-chatgpt)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-05-06T00:41:43.305753+00:00

A new research paper reveals that Apple has been quietly working on a LLM solution of its own, and it already beats ChatGPT.

