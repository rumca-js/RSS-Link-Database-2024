# Source:LonTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg, language:en-US

## The Wyze Battery Cam Pro has a swappable battery - Full review with SD card demo
 - [https://www.youtube.com/watch?v=FYsfaRQ9OhQ](https://www.youtube.com/watch?v=FYsfaRQ9OhQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg
 - date published: 2024-05-06T22:45:00+00:00

Buy one on Amazon: https://lon.tv/enk4x (compensated affiliate link) - The Wyze Battery Cam Pro is a big improvement over their prior outdoor camera. It even has swappable batteries - something almost unheard of these days for consumer electronics. See more Wyze: https://www.youtube.com/playlist?list=PLCZHp4d1HnIsj8ifUW1LyT84jt_RI1bw5 and subscribe! http://lon.tv/s

VIDEO INDEX:
00:00 - Intro
01:25 - Price & Subscription Plans
02:19 - Outdoor durability / weatherproof
03:00 - Connectivity
03:25 - Swappable Battery
04:23 - SD Card Slot & USB-C Port for Solar
05:41 - Mount
05:52 - Speaker
06:16 - Audio test & visual quality example
06:22 - Video Specs
06:42 - Night Vision & Spotlight Demo
07:43 - Notifications
08:27 - Wyze App
08:37 - Live Streaming
09:06 - Reviewing Motion Events & SD card difficulties
10:33 - App Settings: Detection
11:39 - App Settings: Event Recording
13:22 - App Settings: Advanced Settings
14:45 - App Settings: Spotlight Settings
15:11 - Conclusion

Visit my Blog! 

