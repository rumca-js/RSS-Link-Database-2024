# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## Urbn 5,000 mAh Compact MagTag Wireless Power Bank Review: A Small Charger With Big Ambitions
 - [https://www.gadgets360.com/mobiles/reviews/urbn-5000mah-compact-magtag-wireless-power-bank-review-5580368](https://www.gadgets360.com/mobiles/reviews/urbn-5000mah-compact-magtag-wireless-power-bank-review-5580368)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T15:43:21+00:00

The Urbn MagTag 5,000mAh Wireless Power Bank is priced at Rs. 2,499

## Motorola Razr 50 Ultra Live Images Leak; Show Hole-Punch Display, Dual Rear Cameras, More
 - [https://www.gadgets360.com/mobiles/news/motorola-razr-50-ultra-live-images-renders-specifications-report-5602243](https://www.gadgets360.com/mobiles/news/motorola-razr-50-ultra-live-images-renders-specifications-report-5602243)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T13:53:50+00:00

Motorola Razr 40 Ultra was introduced in July last year

## Realme GT Neo 6 Officially Teased; Confirmed to Get Snapdragon 8s Gen 3 SoC
 - [https://www.gadgets360.com/mobiles/news/realme-gt-neo-6-launch-teaser-confirm-key-features-soc-charging-storage-5601810](https://www.gadgets360.com/mobiles/news/realme-gt-neo-6-launch-teaser-confirm-key-features-soc-charging-storage-5601810)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T13:48:40+00:00

Realme GT Neo 6 is expected to succeed the Realme GT Neo 5 (pictured)

## Acer TravelLite Laptops With Up to 13th Gen Intel Core i7 CPUs Unveiled in India: Price, Specifications
 - [https://www.gadgets360.com/laptops/news/acer-travellite-price-india-launch-specifications-features-5602023](https://www.gadgets360.com/laptops/news/acer-travellite-price-india-launch-specifications-features-5602023)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T13:25:49+00:00

The Acer TravelLite laptops offer 45W and 65W charging adapter options

## Amazon Great Summer Sale 2024: Top Deals on Routers
 - [https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-routers-discounts-deals-5601568](https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-routers-discounts-deals-5601568)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T12:57:31+00:00

Amazon Great Summer Sale 2024 will end on May 7

## Amazon Great Summer Sale 2024: Best Deals on Premium Laptops
 - [https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-premium-laptops-5600986](https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-premium-laptops-5600986)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T12:34:08+00:00

Amazon Great Summer Sale 2024 started on May 2

## Amazon Great Summer Sale 2024: Best Deals to Check Before Sale Ends Tomorrow
 - [https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-may-7-end-best-deals-smartphones-tv-tablets-discounts-deals-5600799](https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-may-7-end-best-deals-smartphones-tv-tablets-discounts-deals-5600799)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T12:15:43+00:00

mazn is giving exchange offers, EMI options, and coupon discounts over and above the sale price

## Coinbase Sued in US for Allegedly ‘Deceiving’ Investors: Details
 - [https://www.gadgets360.com/cryptocurrency/news/coinbase-sued-us-deceiving-investors-selling-cryptocurrency-securities-5601387](https://www.gadgets360.com/cryptocurrency/news/coinbase-sued-us-deceiving-investors-selling-cryptocurrency-securities-5601387)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T11:57:23+00:00

Coinbase was founded in May 2012 and is headed by CEO Brian Armstrong

## WhatsApp Update With Green Buttons and New Icons Rolled Out for iOS Users
 - [https://www.gadgets360.com/apps/news/whatsapp-update-ios-users-green-buttons-new-icons-rolled-out-5601207](https://www.gadgets360.com/apps/news/whatsapp-update-ios-users-green-buttons-new-icons-rolled-out-5601207)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T11:57:21+00:00

It might take a few days before all users get the new WhatsApp update

## Crypto Wallets Grab Vodafone’s Attention as Telco Looks to Integrate Blockchain in Operations
 - [https://www.gadgets360.com/cryptocurrency/news/vodafone-blockchain-crypto-wallet-web3-technology-david-palmer-5600872](https://www.gadgets360.com/cryptocurrency/news/vodafone-blockchain-crypto-wallet-web3-technology-david-palmer-5600872)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T10:53:43+00:00

Vodafone is thinking about linking crypto wallets to encrypted SIM cards

## Amazon Great Summer Sale 2024: Best Deals on 50-Inch to 65-Inch Smart TVs
 - [https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-smart-tv-50-55-65-inch-5599902](https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-smart-tv-50-55-65-inch-5599902)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T10:49:01+00:00

Amazon Great Summer Sale 2024 will conclude on May 7

## Samsung Good Lock App Reportedly Available on Google Play Store in Early Access
 - [https://www.gadgets360.com/apps/news/samsung-good-lock-app-google-play-store-early-access-report-5600456](https://www.gadgets360.com/apps/news/samsung-good-lock-app-google-play-store-early-access-report-5600456)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T10:26:40+00:00

Earlier, users could only download the app via the Galaxy Store

## Amazon Great Summer Sale 2024: Best Deals on Printers
 - [https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-printers-5599424](https://www.gadgets360.com/internet/features/amazon-great-summer-sale-2024-best-deals-printers-5599424)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T10:22:10+00:00

Amazon Great Summer Sale 2024 kicked off on May 2

## Patents Reveal Apple Could Be Working on Clamshell Foldable With an Interesting Hinge Design: Report
 - [https://www.gadgets360.com/mobiles/news/iphone-fold-vertical-folding-apple-foldable-phone-patent-report-5600143](https://www.gadgets360.com/mobiles/news/iphone-fold-vertical-folding-apple-foldable-phone-patent-report-5600143)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T09:16:29+00:00

Motorola currently offers one of the most radical designs we have seen with flip phones.

## Samsung Galaxy S25 Series Could Feature ‘Battery AI’ for Improved Battery Life: Report
 - [https://www.gadgets360.com/mobiles/news/samsung-s25-series-battery-life-improvement-ai-galaxy-report-5599794](https://www.gadgets360.com/mobiles/news/samsung-s25-series-battery-life-improvement-ai-galaxy-report-5599794)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T08:59:56+00:00

Samsung introduced its Galaxy AI features with the Galaxy S24 series in January

## Vivo X100 Ultra, Vivo X100s, Vivo X100s Pro Launch Set for May 13; Price, RAM and Storage Configurations Tipped
 - [https://www.gadgets360.com/mobiles/news/vivo-x100s-pro-ultra-launch-may-13-colourways-price-ram-storage-leak-weibo-5599782](https://www.gadgets360.com/mobiles/news/vivo-x100s-pro-ultra-launch-may-13-colourways-price-ram-storage-leak-weibo-5599782)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T08:56:34+00:00

Vivo listed three phones on its online store revealing colours

## Crypto Startups Turbocharge Valuations as Investment Picks Up
 - [https://www.gadgets360.com/cryptocurrency/news/crypto-startups-high-valuations-investments-fundraising-5599907](https://www.gadgets360.com/cryptocurrency/news/crypto-startups-high-valuations-investments-fundraising-5599907)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T08:54:11+00:00

An open-ended funding round rewards earlier investors

## GTA V Cheat Codes: Full List of GTA 5 Cheats for PC, PS5, PS4, and Xbox
 - [https://www.gadgets360.com/games/features/gta-5-cheat-codes-for-pc-ps-xbox-5379942](https://www.gadgets360.com/games/features/gta-5-cheat-codes-for-pc-ps-xbox-5379942)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T08:06:17+00:00

GTA 5 is one of the few games that allow users to enter cheat codes. Here's everything you need to know

## Microsoft Finds Major Security Flaw ‘Dirty Stream’ in Android Apps Totalling Billions of Downloads
 - [https://www.gadgets360.com/apps/news/microsoft-dirty-stream-security-vulnerability-android-apps-billions-of-downloads-5599430](https://www.gadgets360.com/apps/news/microsoft-dirty-stream-security-vulnerability-android-apps-billions-of-downloads-5599430)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T07:54:11+00:00

Users are recommended to keep their apps updated and avoid installing apps from third-party sources

## iQoo Z9x 5G India Launch Set for May 16; Design, Amazon Availability Confirmed
 - [https://www.gadgets360.com/mobiles/news/iqoo-z9x-5g-india-launch-date-design-colour-option-amazon-availability-5598272](https://www.gadgets360.com/mobiles/news/iqoo-z9x-5g-india-launch-date-design-colour-option-amazon-availability-5598272)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T07:26:40+00:00

iQoo Z9x 5G teased in a light green colourway

## OnePlus Nord CE 4 Lite Allegedly Gets BIS Certification, Could Launch in India Soon
 - [https://www.gadgets360.com/mobiles/news/oneplus-nord-ce-4-lite-india-launch-bis-certification-price-specifications-leak-5599164](https://www.gadgets360.com/mobiles/news/oneplus-nord-ce-4-lite-india-launch-bis-certification-price-specifications-leak-5599164)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T07:15:51+00:00

OnePlus Nord CE 4 Lite is expected to come with upgrades over the OnePlus Nord CE 3 Lite (above)

## Sony Walks Back Helldivers 2 PSN Account Linking Requirement on Steam After Widespread Backlash
 - [https://www.gadgets360.com/games/news/helldivers-2-playstation-network-account-link-steam-decision-reversed-sony-ps5-backlash-5599228](https://www.gadgets360.com/games/news/helldivers-2-playstation-network-account-link-steam-decision-reversed-sony-ps5-backlash-5599228)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T07:05:55+00:00

Helldivers 2 is one of the most played games on Steam

## Crypto Price Today: Bitcoin Trading Above $60,000, Losses Strike Ether, Shiba Inu
 - [https://www.gadgets360.com/cryptocurrency/news/bitcoin-price-today-crypto-india-ether-shiba-inu-loss-cryptocurrency-5599171](https://www.gadgets360.com/cryptocurrency/news/bitcoin-price-today-crypto-india-ether-shiba-inu-loss-cryptocurrency-5599171)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T06:55:55+00:00

The total valuation of the crypto sector stands at $2.36 trillion

## Apple’s AI Features Could Potentially Change How an iPhone is Used
 - [https://www.gadgets360.com/ai/news/apple-ai-features-iphone-wwdc-research-papers-5598989](https://www.gadgets360.com/ai/news/apple-ai-features-iphone-wwdc-research-papers-5598989)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T06:40:44+00:00

Siri could get a big upgrade with Apple’s AI integration

## iPhone 17 Series Said to Get Smaller Dynamic Island; Apple Could Unveil iPhone 17 Slim in 2025
 - [https://www.gadgets360.com/mobiles/news/iphone-17-slim-pro-max-series-smaller-dynamic-island-features-upgrades-specifications-jeff-pu-apple-report-5598587](https://www.gadgets360.com/mobiles/news/iphone-17-slim-pro-max-series-smaller-dynamic-island-features-upgrades-specifications-jeff-pu-apple-report-5598587)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T05:43:48+00:00

iPhone 15 and iPhone 15 Plus feature 6GB of RAM

## Vivo Y18, Y18e With MediaTek Helio G85 SoCs Launched in India: Price, Specifications
 - [https://www.gadgets360.com/mobiles/news/vivo-y18-y18e-price-india-launch-specifications-features-5598271](https://www.gadgets360.com/mobiles/news/vivo-y18-y18e-price-india-launch-specifications-features-5598271)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-05-06T05:40:31+00:00

Vivo Y18 and Vivo Y18e come in Gem Green and Space Black colour options

