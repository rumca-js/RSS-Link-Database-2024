# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## AI in space: Karpathy suggests AI chatbots as interstellar messengers to alien civilizations
 - [https://arstechnica.com/information-technology/2024/05/ai-in-space-karpathy-suggests-ai-chatbots-as-interstellar-messengers-to-alien-civilizations](https://arstechnica.com/information-technology/2024/05/ai-in-space-karpathy-suggests-ai-chatbots-as-interstellar-messengers-to-alien-civilizations)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-05-06T04:00:00+00:00

Let the aliens get all the 'authoritative, but wrong' answers about us

## 'Architecture by conference' is a really bad idea
 - [https://www.infoworld.com/article/3715327/architecture-by-conference-is-a-really-bad-idea.html](https://www.infoworld.com/article/3715327/architecture-by-conference-is-a-really-bad-idea.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-05-06T04:00:00+00:00

But it worked in PowerPoint!

## Google paid Apple $20 billion in 2022 to be default Safari search engine
 - [https://www.macrumors.com/2024/05/01/google-default-search-engine-safari-20-billion](https://www.macrumors.com/2024/05/01/google-default-search-engine-safari-20-billion)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-05-06T04:00:00+00:00

You might not be able to buy me love, but you can rent a good substitute

## I switched to MS Edge (Linux, MacOS, iPad)
 - [https://www.codeproject.com/Messages/5999798/I-switched-to-MS-Edge-Linux-MacOS-iPad](https://www.codeproject.com/Messages/5999798/I-switched-to-MS-Edge-Linux-MacOS-iPad)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-05-06T04:00:00+00:00

Chrome, with the shiny bits sanded off

## Software testing day
 - [https://xkcd.com/2928](https://xkcd.com/2928)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-05-06T04:00:00+00:00



## U.K. bans generic passwords over cybersecurity concerns.
 - [https://globalnews.ca/news/10468217/easy-passwords-banned-uk-cybersecurity](https://globalnews.ca/news/10468217/easy-passwords-banned-uk-cybersecurity)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-05-06T04:00:00+00:00

Let the users set the generic passwords instead

