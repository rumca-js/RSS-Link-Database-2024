# Source:China Uncensored, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCgFP46yVT-GG4o1TgXn-04Q, language:en

## Why Are Chinese Students Abroad Kidnapping Themselves?
 - [https://www.youtube.com/watch?v=Hhr61amkmhw](https://www.youtube.com/watch?v=Hhr61amkmhw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCgFP46yVT-GG4o1TgXn-04Q
 - date published: 2024-05-06T13:43:55+00:00

China is corrupt. But why have Chinese students abroad started kidnapping themselves for ransom money?

I’m Offended by Stellar Blade https://youtu.be/cAphWKos_Qw
China Unscripted Podcast www.youtube.com/@ChinaUnscripted
Check out my interviews with Serpentza and Laowhy86!
https://www.youtube.com/watch?v=kDV4s9c9sfQ&amp;pp=ygUaY2hpbmEgdW5zY3JpcHRlZCBzZXJwZW50emE%3D
https://www.youtube.com/watch?v=EHBtHp96drA&amp;t=2s&amp;pp=ygUaY2hpbmEgdW5zY3JpcHRlZCBzZXJwZW50emE%3D

YouTube demonetizes our channels, we need your support!
https://www.patreon.com/ChinaUncensored
https://chinauncensored.locals.com

We also accept bitcoin!
https://chinauncensored.tv/bitcoin

And Paypal: 
https://www.paypal.com/donate/?hosted_button_id=GAHZXYHGCBP3L

Buy our merchandise!
https://chinauncensored.tv/merchandise

China Uncensored on Odysee
https://odysee.com/@ChinaUncensored

China Uncensored on Rumble
https://rumble.com/c/ChinaUncensored

Make sure to share this video with your friends!
____________________

