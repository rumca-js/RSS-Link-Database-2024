# Source:IBM Technology, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKWaEZ-_VweaEx1j62do_vQ, language:en

## IBM Tech Now: IBM watsonx.ai demo, AI and sustainability, and the AI Bundle for IBM Z and LinuxONE
 - [https://www.youtube.com/watch?v=UhL-6nhbHRI](https://www.youtube.com/watch?v=UhL-6nhbHRI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKWaEZ-_VweaEx1j62do_vQ
 - date published: 2024-05-06T12:00:33+00:00

Want to play with the technology yourself? Explore our interactive demo for watsonx.ai → https://ibm.biz/Bdvu3f

Welcome to IBM Tech Now, a bi-weekly series bringing you the latest and greatest IBM technology news and announcements. 
 
Check out the following resources: 
(00:15) 1. A 30-day IBM watsonx.ai demo: https://ibm.biz/watsonxai-demo
(01:05) 2. AI and sustainability initiatives: https://ibm.biz/ai-and-sustainability
(02:13) 3. The AI Bundle for IBM Z and LinuxONE: https://ibm.biz/ai-bundle-for-ibm-z-and-linuxone
 
Subscribe to the IBM Cloud channel to be notified when a new IBM Tech Now video publishes → http://ibm.biz/subscribe-now

AI news moves fast. Sign up for a monthly newsletter for AI updates from IBM → https://ibm.biz/Bdvu3M

