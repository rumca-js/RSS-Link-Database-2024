# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Games They Made You BELIEVE WERE BAD
 - [https://www.youtube.com/watch?v=csucdsMky5Y](https://www.youtube.com/watch?v=csucdsMky5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-05-06T16:36:43+00:00

Some games end up having a critical or fan response at launch that makes you believe the worst. Here are some games considered "bad" by fans or critics that are actually quite a bit of fun.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1     

0:00 Intro 
0:13 Number 10
2:42 Number 9
4:41 Number 8
6:37 Number 7
8:40 Number 6
10:25 Number 5
13:04 Number 4
15:52 Number 3
17:12 Number 2
19:10 Number 1 
21:07 Bonus

