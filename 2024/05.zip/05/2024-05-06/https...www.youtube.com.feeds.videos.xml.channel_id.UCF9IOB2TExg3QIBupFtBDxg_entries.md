# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## New RNA vaccines comming
 - [https://www.youtube.com/watch?v=WgoixKhPaMY](https://www.youtube.com/watch?v=WgoixKhPaMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-05-06T16:25:33+00:00

Bill Gates in on the case

## Kyle's vaccine injury journey
 - [https://www.youtube.com/watch?v=OPpR7kIbdhA](https://www.youtube.com/watch?v=OPpR7kIbdhA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-05-06T08:55:37+00:00

Update from Mr. Kyle Warner

Countermeasures Injury Compensation Program (CICP) 
https://www.hrsa.gov/cicp/cicp-data

CICP Claims Compensated
https://www.hrsa.gov/cicp/cicp-data/table-4

See More from Kyle Warner
@ KyleWarnerMTB - Instagram
@Kyle&amp;April-RideMTB - Youtube
Website- Ridemtb.com

Backlogged: Few cases finished after millions spent investigating COVID vaccine claims

https://nam10.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.investigatetv.com%2F2024%2F04%2F29%2Fbacklogged-few-cases-finished-after-millions-spent-investigating-covid-vaccine-claims%2F&amp;data=05%7C02%7Ckyle.warner%40react19.org%7C69b08b89172e462aa6ff08dc689b595

