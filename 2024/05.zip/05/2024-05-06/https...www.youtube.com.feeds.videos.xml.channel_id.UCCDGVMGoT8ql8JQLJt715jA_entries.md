# Source:emzdanowicz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA, language:pl

## Hades 2 już jest! Droższy niż jedynka 👀
 - [https://www.youtube.com/watch?v=l8povK9Gx4w](https://www.youtube.com/watch?v=l8povK9Gx4w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA
 - date published: 2024-05-06T17:57:48+00:00

No to chyba znowu na Streamie będzie Hades 2. Z góry zapraszam na środę na 20:00 :D Wersja Early Access ma ponoć sporo contentu.

Aha - to tylko short. Nie specjalizuję się w shortach, więc zajrzyj na mój kanał po więcej "normalnej" treści ;D Z góry dzięki za suba!

#hades2 #earlyaccess

## The Elder Scrolls 6? Chętnie, nawet po średnim Starfieldzie
 - [https://www.youtube.com/watch?v=iACiw1mFvvY](https://www.youtube.com/watch?v=iACiw1mFvvY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA
 - date published: 2024-05-06T05:45:01+00:00

Starfield mnie nie zachwycił, ale The Elder Scrolls 6 będzie miało jedną, wielką przewagę. Nie będzie Starfieldem.

0:00 Starfield a TES6
1:43 Przewaga The Elder Scrolls
4:35 Poczucie przygody
7:40 Skywind

Zobacz też:

- Najlepsze gry indie kwietnia (youtube.com/watch?v=8GPAcoC3SkI)
- Recenzja gry Indika (youtube.com/watch?v=9LvLeg0SI9U)

Na moim kanale znajdziesz recenzje gier wideo. Recenzje gier na PC, recenzje gier konsolowych (gry na PS5, Switch, Xbox). Publikuję tu także wrażenia z gier, czyli materiały nieco luźniejsze, które recenzjami gier nie są. Nieważne, czy twoją ulubioną platformą do gier jest PC, Xbox, Playstation czy coś od Nintendo - wierzę, że znajdziesz tu coś dla siebie :)

#starfield #theelderscrolls #bethesda

