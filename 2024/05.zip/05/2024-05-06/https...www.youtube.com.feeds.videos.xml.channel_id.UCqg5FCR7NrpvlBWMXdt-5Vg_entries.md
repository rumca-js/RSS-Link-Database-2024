# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## What Happens When you Dock a Switch Lite?
 - [https://www.youtube.com/watch?v=rIzAExywdGY](https://www.youtube.com/watch?v=rIzAExywdGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2024-05-06T22:12:49+00:00

What Happens When you Dock a Switch Lite? #nintendoswitch #switch #nintendo 

---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

