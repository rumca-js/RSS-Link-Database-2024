# Source:Daily News Egypt, URL:https://www.dailynewsegypt.com/feed, language:en-US

## Egypt warns of Israeli military operation in Rafah
 - [https://www.dailynewsegypt.com/2024/05/06/egypt-warns-of-israeli-military-operation-in-rafah](https://www.dailynewsegypt.com/2024/05/06/egypt-warns-of-israeli-military-operation-in-rafah)
 - RSS feed: https://www.dailynewsegypt.com/feed
 - date published: 2024-05-06T19:54:53+00:00

Israel intends to continue Rafah operation; Hamas agrees to Egypt-Qatar ceasefire proposal

## US academic groups decry police force in campus protest crackdowns
 - [https://www.dailynewsegypt.com/2024/05/06/us-academic-groups-decry-police-force-in-campus-protest-crackdowns](https://www.dailynewsegypt.com/2024/05/06/us-academic-groups-decry-police-force-in-campus-protest-crackdowns)
 - RSS feed: https://www.dailynewsegypt.com/feed
 - date published: 2024-05-06T16:38:04+00:00

Over 2,400 protesters arrested since April 17 on more than 45 US campuses

## Madinaty Golf Club emerges as Egypt’s hub for global brand launches: Omar Hisham Talaat
 - [https://www.dailynewsegypt.com/2024/05/06/madinaty-golf-club-emerges-as-egypts-hub-for-global-brand-launches-omar-hisham-talaat](https://www.dailynewsegypt.com/2024/05/06/madinaty-golf-club-emerges-as-egypts-hub-for-global-brand-launches-omar-hisham-talaat)
 - RSS feed: https://www.dailynewsegypt.com/feed
 - date published: 2024-05-06T16:32:52+00:00

Madinaty Golf Club is establishing itself as a premier destination for global brand launches in Egypt, according to Omar Hisham Talaat, Chief Business Development Officer at Talaat Moustafa Group (TMG). Speaking on the sidelines of the Hechter Cup, Talaat highlighted the recent launch of French fashion brand Hechter Paris&#8217; new golf apparel line at the [&#8230;]

## Egypt urges de-escalation as Israel orders evacuation of Rafah; Hamas warns of consequences
 - [https://www.dailynewsegypt.com/2024/05/06/egypt-urges-de-escalation-as-israel-orders-evacuation-of-rafah-hamas-warns-of-consequences](https://www.dailynewsegypt.com/2024/05/06/egypt-urges-de-escalation-as-israel-orders-evacuation-of-rafah-hamas-warns-of-consequences)
 - RSS feed: https://www.dailynewsegypt.com/feed
 - date published: 2024-05-06T12:10:23+00:00

Egypt has urged both Hamas and Israel to de-escalate the current situation and return to the negotiating table, a high-level Egyptian source told Daily News Egypt on Monday.  He emphasized that a significant progress that has already been made in Gaza ceasefire talks The Egyptian appeal comes as Israel&#8217;s military issued orders for Palestinians to [&#8230;]

