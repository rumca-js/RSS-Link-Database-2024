# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Apple Is Developing AI Chips for Data Centers, Seeking Edge in Arms Race
 - [https://www.wsj.com/articles/apple-is-developing-ai-chips-for-data-centers-seeking-edge-in-arms-race-0bedd2b2?mod=rss_Technology](https://www.wsj.com/articles/apple-is-developing-ai-chips-for-data-centers-seeking-edge-in-arms-race-0bedd2b2?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-05-06T23:21:00+00:00

The company is leaning on its long history of chip development in the effort, code-named Project ACDC.

## Pentagon Needs to Open Up About Russia's Use of Musk's Starlink, Sen. Warren Says
 - [https://www.wsj.com/articles/pentagon-needs-to-open-up-about-russias-use-of-starlink-senator-says-fca6ee02?mod=rss_Technology](https://www.wsj.com/articles/pentagon-needs-to-open-up-about-russias-use-of-starlink-senator-says-fca6ee02?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-05-06T16:45:00+00:00

A letter from the lawmaker calls Moscow’s access to the satellite internet service in Ukraine a “serious national security threat.”

