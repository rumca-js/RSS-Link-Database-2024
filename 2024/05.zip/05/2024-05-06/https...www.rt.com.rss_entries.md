# Source:RT - Daily news, URL:https://www.rt.com/rss, language:en

## Germany wants to arm Ukraine with Russian funds
 - [https://www.rt.com/news/597101-germany-arm-ukraine-russian-assets/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597101-germany-arm-ukraine-russian-assets/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T22:35:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/66395ad585f54002ee63762c.jpg" style="margin-right: 10px;" /> Interest from Moscow‚Äôs sanctioned assets ought to be used to buy weapons for Kiev, German Chancellor Olaf Scholz has said <br /><a href="https://www.rt.com/news/597101-germany-arm-ukraine-russian-assets/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## France doesn‚Äôt want ‚Äòregime change‚Äô in Russia ‚Äì Macron
 - [https://www.rt.com/news/597097-france-regime-change-russia-macron/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597097-france-regime-change-russia-macron/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T21:48:37+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/66394f7585f54010dc0a1f21.jpg" style="margin-right: 10px;" /> French President Emmanuel Macron has denied that the West seeks a ‚Äúregime change‚Äù in Russia while reaffirming his nation‚Äôs support for Kiev <br /><a href="https://www.rt.com/news/597097-france-regime-change-russia-macron/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## How Israel destroyed safe spaces in Western universities
 - [https://www.rt.com/news/597066-israel-destroyed-western-universities/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597066-israel-destroyed-western-universities/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T21:43:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638cd7c203027469c644a3f.jpg" style="margin-right: 10px;" /> The crackdown on pro-Palestine campus protests might just make college kids hate the establishment again <br /><a href="https://www.rt.com/news/597066-israel-destroyed-western-universities/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US tells Israel it won‚Äôt back Rafah operation ‚Äòas currently planned‚Äô
 - [https://www.rt.com/news/597081-us-israel-rafah-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597081-us-israel-rafah-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T20:50:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663927062030276ca62b3154.jpg" style="margin-right: 10px;" /> An attack on the Gaza city would cause more Palestinian deaths and disrupt aid deliveries, the US State Department has said <br /><a href="https://www.rt.com/news/597081-us-israel-rafah-gaza/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Xi refuses to back Zelensky‚Äôs unilateral ‚Äòpeace conference‚Äô
 - [https://www.rt.com/news/597093-china-ukraine-peace-conference/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597093-china-ukraine-peace-conference/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T20:47:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/66393c7f20302739f83964ba.jpg" style="margin-right: 10px;" /> Ukraine peace talks should be recognized by all parties, the Chinese leader has said <br /><a href="https://www.rt.com/news/597093-china-ukraine-peace-conference/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel launches airstrikes on Rafah: Live updates
 - [https://www.rt.com/news/597091-israel-airstrikes-rafah-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597091-israel-airstrikes-rafah-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T19:50:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663932592030272e3834df85.jpg" style="margin-right: 10px;" /> IDF jets have struck the densely populated Palestinian city of Rafah ahead of a long-promised ground invasion <br /><a href="https://www.rt.com/news/597091-israel-airstrikes-rafah-gaza/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Moscow slams France‚Äôs ‚Äòbelligerent rhetoric‚Äô
 - [https://www.rt.com/news/597086-russia-france-ukraine-conflict/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597086-russia-france-ukraine-conflict/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T19:25:52+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663928802030273b264c452f.jpg" style="margin-right: 10px;" /> Paris is pursuing a destructive and provocative policy in the Ukraine conflict, Russia‚Äôs Foreign Ministry told the French envoy <br /><a href="https://www.rt.com/news/597086-russia-france-ukraine-conflict/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Message to the West: What‚Äôs behind Russia‚Äôs tactical nuclear drills
 - [https://www.rt.com/russia/597085-tatical-nuclear-drills-explained/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597085-tatical-nuclear-drills-explained/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T19:09:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6639029b20302737ae1dfeae.jpg" style="margin-right: 10px;" /> Surprise military exercises are intended to put the US and its allies on notice about unacceptable escalation in Ukraine, Moscow has said <br /><a href="https://www.rt.com/russia/597085-tatical-nuclear-drills-explained/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Japanese volunteer explains why he is fighting on Russia‚Äôs side against Ukraine
 - [https://www.rt.com/russia/597074-japanese-national-russian-army/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597074-japanese-national-russian-army/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T18:12:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638f46b2030273b264c450e.jpg" style="margin-right: 10px;" /> The conflict between Moscow and Kiev has been misrepresented in Japan due to Western pressure, Daisaku Kaneko tells RT <br /><a href="https://www.rt.com/russia/597074-japanese-national-russian-army/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia to hold nuclear drills to ‚Äòcool hot heads‚Äô in West ‚Äì Foreign Ministry
 - [https://www.rt.com/russia/597090-russia-nuclear-drills-cool-heads-west/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597090-russia-nuclear-drills-cool-heads-west/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T18:03:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6639199d85f54010dc0a1eed.jpg" style="margin-right: 10px;" /> The exercises are aimed at helping Western leaders realize the potential ‚Äúcatastrophic‚Äù consequences of their own actions, Moscow says <br /><a href="https://www.rt.com/russia/597090-russia-nuclear-drills-cool-heads-west/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hamas accepts ceasefire deal ‚Äì Al Jazeera
 - [https://www.rt.com/news/597089-hamas-accepts-ceasefire-deal/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597089-hamas-accepts-ceasefire-deal/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T17:50:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6639137b20302737ae1dfeba.jpg" style="margin-right: 10px;" /> The militants have reportedly agreed to a truce ahead of an Israeli invasion of Rafah <br /><a href="https://www.rt.com/news/597089-hamas-accepts-ceasefire-deal/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Belgium working on Israel sanctions
 - [https://www.rt.com/news/597087-belgium-planning-israel-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597087-belgium-planning-israel-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T17:44:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6639068485f54002ab56f99c.jpg" style="margin-right: 10px;" /> The Belgian prime minister and his deputy have both promised to punish Israel over its conduct in Gaza <br /><a href="https://www.rt.com/news/597087-belgium-planning-israel-sanctions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Man dressed as woman detained attempting to flee Ukraine (VIDEO)
 - [https://www.rt.com/russia/597083-ukraine-detains-man-in-dress/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597083-ukraine-detains-man-in-dress/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T17:04:27+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638feea85f54002ab56f997.jpg" style="margin-right: 10px;" /> A 44-year-old tried to illegally cross into Romania by presenting his sister‚Äôs passport but was caught by border guards <br /><a href="https://www.rt.com/russia/597083-ukraine-detains-man-in-dress/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## UK seizes smartphones ahead of Rwanda deportation ‚Äì Telegraph
 - [https://www.rt.com/africa/597084-uk-seizes-migrants-smartphones-rwanda-deportation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/597084-uk-seizes-migrants-smartphones-rwanda-deportation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T16:38:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663901242030273a01745251.jpg" style="margin-right: 10px;" /> UK detention centers where migrants are held for relocation to Rwanda have reportedly seized the detainees‚Äô smartphones <br /><a href="https://www.rt.com/africa/597084-uk-seizes-migrants-smartphones-rwanda-deportation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China‚Äôs Xi visits EU to avert trade war
 - [https://www.rt.com/business/597065-china-europe-trade-war-meeting/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/597065-china-europe-trade-war-meeting/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T16:03:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638fe0c85f5407ffa534e7e.jpg" style="margin-right: 10px;" /> The Chinese leader has met with EU officials to discuss strained economic ties <br /><a href="https://www.rt.com/business/597065-china-europe-trade-war-meeting/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## British citizen explains why he joined Russian army (VIDEO)
 - [https://www.rt.com/russia/597079-british-soldier-russian-army/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597079-british-soldier-russian-army/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T15:59:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638f92885f5407c7b5e6d2d.png" style="margin-right: 10px;" /> Aiden Minnis told RT that he has ‚Äúzero doubt‚Äù about his decision to leave the UK behind to fight for Russia <br /><a href="https://www.rt.com/russia/597079-british-soldier-russian-army/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukrainians safe in Hungary from Kiev‚Äôs draft ‚Äì deputy PM
 - [https://www.rt.com/news/597078-hungary-ukraine-draft-refugees/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597078-hungary-ukraine-draft-refugees/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T15:25:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638eadf85f54003ee442b3f.jpg" style="margin-right: 10px;" /> Hungary will not extradite Ukrainians to Kiev to ‚Äúbe sent to their deaths‚Äù in the conflict with Russia, Budapest has said <br /><a href="https://www.rt.com/news/597078-hungary-ukraine-draft-refugees/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## France, EU pressuring China over Russia ties
 - [https://www.rt.com/news/597076-china-xi-france-eu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597076-china-xi-france-eu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T15:22:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638e5b12030274840525ea1.jpg" style="margin-right: 10px;" /> Coordination with China on the conflicts in Ukraine and the Middle East is ‚Äúabsolutely decisive,‚Äù French President Emmanuel Macron has said <br /><a href="https://www.rt.com/news/597076-china-xi-france-eu/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia destroys Ukrainian sea drones in Black Sea (VIDEO)
 - [https://www.rt.com/russia/597082-ukrainian-sea-drones-destroyed-video/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597082-ukrainian-sea-drones-destroyed-video/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T15:11:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638f2d785f54010dc0a1ec7.png" style="margin-right: 10px;" /> The Russian military has destroyed five Ukrainian autonomous surface vessels over the past 24 hours, Moscow has said <br /><a href="https://www.rt.com/russia/597082-ukrainian-sea-drones-destroyed-video/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## West shouldn‚Äôt lecture ‚Äòsecular‚Äô India on religion ‚Äì Manipur head to RT
 - [https://www.rt.com/india/597073-west-lecture-india-manipur-chief/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/597073-west-lecture-india-manipur-chief/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T14:57:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638ed7a85f54010dc0a1ebb.jpeg" style="margin-right: 10px;" /> The chief minister of India‚Äôs violence-torn Manipur state has claimed the West is not in a position to lecture India on religion <br /><a href="https://www.rt.com/india/597073-west-lecture-india-manipur-chief/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky ignored counteroffensive warnings ‚Äì NATO member
 - [https://www.rt.com/news/597080-italy-ukraine-counteroffensive-warning/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597080-italy-ukraine-counteroffensive-warning/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T14:44:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638ec6e2030272e3834df57.jpg" style="margin-right: 10px;" /> Russia‚Äôs military superiority meant Kiev‚Äôs operation was doomed to fail, Italian Defense Minister Guido Crosetto had said <br /><a href="https://www.rt.com/news/597080-italy-ukraine-counteroffensive-warning/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kremlin dismisses claims of ‚ÄòRussian sabotage plots‚Äô in Europe
 - [https://www.rt.com/russia/597070-russia-eu-sabotage-peskov-comment/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597070-russia-eu-sabotage-peskov-comment/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T14:28:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638e55a203027496767c670.jpg" style="margin-right: 10px;" /> Accusations that Russia is plotting acts of sabotage across Europe are groundless, the presidential spokesperson has said <br /><a href="https://www.rt.com/russia/597070-russia-eu-sabotage-peskov-comment/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia issues military ultimatum to UK
 - [https://www.rt.com/russia/597075-russia-military-ultimatum-uk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597075-russia-military-ultimatum-uk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T14:10:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638e8a02030274840525ead.jpg" style="margin-right: 10px;" /> London was told Moscow would strike British targets in Ukraine ‚Äúand beyond‚Äù if Kiev uses UK-supplied long-range missiles to attack Russia <br /><a href="https://www.rt.com/russia/597075-russia-military-ultimatum-uk/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Western ambassadors summoned in Moscow
 - [https://www.rt.com/russia/597071-russia-summons-western-ambassadors/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597071-russia-summons-western-ambassadors/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T13:35:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638d48a85f54003ee442b2c.jpg" style="margin-right: 10px;" /> The UK and French ambassadors in Moscow have been summoned by the Russian Foreign Ministry amid rising tensions <br /><a href="https://www.rt.com/russia/597071-russia-summons-western-ambassadors/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia makes new gains in Ukraine‚Äôs Kharkov Region ‚Äì MOD
 - [https://www.rt.com/russia/597072-russia-gains-kharkov-region/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597072-russia-gains-kharkov-region/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T13:31:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638dac585f54002ee6375e2.jpg" style="margin-right: 10px;" /> Russian troops have driven Kiev‚Äôs forces from the villages of Kotlyarovka in Kharkov Region and Solovyovo in Donbass, Moscow says <br /><a href="https://www.rt.com/russia/597072-russia-gains-kharkov-region/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel orders evacuation of Rafah
 - [https://www.rt.com/news/597068-israel-orders-evacuation-rafah-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597068-israel-orders-evacuation-rafah-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T13:01:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638d0d385f54002ee6375cd.jpg" style="margin-right: 10px;" /> The Israeli army has ordered Palestinians to evacuate parts of Rafah, warning of ‚Äúextreme‚Äù military action against Hamas in the city <br /><a href="https://www.rt.com/news/597068-israel-orders-evacuation-rafah-gaza/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Final preparations concluded ahead of Putin swearing-in ceremony
 - [https://www.rt.com/russia/597058-putin-president-inauguration-kremlin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597058-putin-president-inauguration-kremlin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T13:01:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638c0d9203027480b0a9aeb.jpg" style="margin-right: 10px;" /> Vladimir Putin‚Äôs inauguration as Russian president will take place at the Kremlin on Tuesday <br /><a href="https://www.rt.com/russia/597058-putin-president-inauguration-kremlin/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## West is dragging Poland into war ‚Äì fugitive judge
 - [https://www.rt.com/news/597056-polish-judge-belarus-asylum/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597056-polish-judge-belarus-asylum/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T12:53:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638ae98203027469c644a0e.jpg" style="margin-right: 10px;" /> Tomasz Szmydt has asked for political asylum in Belarus, accusing Warsaw of taking an ‚Äúunfair and dishonest‚Äù stance on the Ukraine conflict <br /><a href="https://www.rt.com/news/597056-polish-judge-belarus-asylum/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Berlin recalls ambassador to Russia
 - [https://www.rt.com/news/597062-germany-recalls-ambassador-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597062-germany-recalls-ambassador-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T12:47:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638c00785f5400327745863.jpg" style="margin-right: 10px;" /> German Ambassador to Russia Alexander Lambsdorff has been recalled to Berlin for consultations over an alleged Russian hack <br /><a href="https://www.rt.com/news/597062-germany-recalls-ambassador-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian intelligence claims US wants to replace Zelensky¬†
 - [https://www.rt.com/russia/597069-us-wants-replace-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597069-us-wants-replace-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T12:45:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638cff985f5407ffa534e1c.jpg" style="margin-right: 10px;" /> The US is in talks with a number of Ukrainian politicians as it seeks to replace Vladimir Zelensky, Russian intelligence says¬†

¬† <br /><a href="https://www.rt.com/russia/597069-us-wants-replace-zelensky/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU state needs spare parts from Russia to keep public transport running ‚Äì media
 - [https://www.rt.com/russia/597067-latvia-russian-train-parts/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597067-latvia-russian-train-parts/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T12:32:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638cdad85f540032774587a.jpg" style="margin-right: 10px;" /> Latvia‚Äôs passenger railway operator says there are no EU alternatives to service Soviet-era trains <br /><a href="https://www.rt.com/russia/597067-latvia-russian-train-parts/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Nuclear weapons drills a response to ‚Äòescalation‚Äô ‚Äì Kremlin
 - [https://www.rt.com/news/597064-nuclear-weapons-drills-response-escalation-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597064-nuclear-weapons-drills-response-escalation-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T12:20:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638c9a7203027469c644a32.jpg" style="margin-right: 10px;" /> Tactical nuclear weapons drills are a response to ‚Äúunprecedented‚Äù escalation sparked by statements of NATO members, the Kremlin has said <br /><a href="https://www.rt.com/news/597064-nuclear-weapons-drills-response-escalation-nato/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Over 100 Ukrainians blocked from leaving country every day ‚Äì border service
 - [https://www.rt.com/russia/597063-ukrainians-blocked-leaving-border/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597063-ukrainians-blocked-leaving-border/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T11:49:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638c2f22030277d8d00ceda.jpg" style="margin-right: 10px;" /> Up to 150 people are prevented from leaving Ukraine every day because they are either ineligible or lack proper documents, Kiev says <br /><a href="https://www.rt.com/russia/597063-ukrainians-blocked-leaving-border/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## No international pressure can stop Israel ‚Äì Netanyahu
 - [https://www.rt.com/news/597060-international-pressure-stop-israel-netanyahu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597060-international-pressure-stop-israel-netanyahu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T11:36:33+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638bc9e203027489b10567b.jpg" style="margin-right: 10px;" /> Prime Minister Benjamin Netanyahu has said that no amount of international pressure will compel him to stop ‚Äúdefending‚Äù Israel <br /><a href="https://www.rt.com/news/597060-international-pressure-stop-israel-netanyahu/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‚ÄòWe are in danger because of NATO membership‚Äô: Turkish Patriotic party is sounding the alarm
 - [https://www.rt.com/news/597055-turkish-patriots-influence-nato-us/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597055-turkish-patriots-influence-nato-us/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T11:19:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638a9a5203027480b0a9ad1.jpg" style="margin-right: 10px;" /> Chairman of T√ºrkiye‚Äôs Vatan Party speaks about the influence of the US, Palestine, and Israel, and the future of NATO <br /><a href="https://www.rt.com/news/597055-turkish-patriots-influence-nato-us/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Sahel state electing president after three years of military rule
 - [https://www.rt.com/africa/597061-chad-presidential-elections/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/597061-chad-presidential-elections/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T11:18:58+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638bb8885f5407ffa534e06.jpg" style="margin-right: 10px;" /> Voting is underway in Chad to choose a president to replace the current military regime <br /><a href="https://www.rt.com/africa/597061-chad-presidential-elections/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Western leaders are ‚Äòinfantile morons‚Äô ‚Äì Medvedev
 - [https://www.rt.com/russia/597054-medvedev-nuclear-drill-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597054-medvedev-nuclear-drill-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T11:06:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638b00b2030274840525e6c.jpg" style="margin-right: 10px;" /> Former Russian President Dmitry Medvedev has offered an explanation for a nuclear exercise announced by Moscow on Monday <br /><a href="https://www.rt.com/russia/597054-medvedev-nuclear-drill-nato/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India seeks Interpol‚Äôs help to track down politician facing sexual assault charges
 - [https://www.rt.com/india/597059-india-interpol-revanna-mp/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/597059-india-interpol-revanna-mp/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T11:03:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638b87b85f5401cc6515de7.jpg" style="margin-right: 10px;" /> India has sought help from Interpol to track down MP Prajwal Revanna <br /><a href="https://www.rt.com/india/597059-india-interpol-revanna-mp/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian security service thwarts alleged Kiev-orchestrated terror plot
 - [https://www.rt.com/russia/597050-fsb-terror-plot-tambov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597050-fsb-terror-plot-tambov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T09:58:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638a04e85f54011356312a8.png" style="margin-right: 10px;" /> A Russian citizen suspected of planning to blow up a local courthouse was detained in the city of Tambov, the FSB has reported <br /><a href="https://www.rt.com/russia/597050-fsb-terror-plot-tambov/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Democrat leader warns US troops could enter Ukraine conflict
 - [https://www.rt.com/news/597053-democrat-leader-us-troops-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597053-democrat-leader-us-troops-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T09:35:53+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638a32485f540102a25be58.jpg" style="margin-right: 10px;" /> US could send troops to Ukraine if Kiev suffers a major defeat on the battlefield, House Minority Leader Hakeem Jeffries says <br /><a href="https://www.rt.com/news/597053-democrat-leader-us-troops-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China causing de-industrialization in EU ‚Äì von der Leyen
 - [https://www.rt.com/business/597048-leyen-xi-meeting-deindustrialization/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/597048-leyen-xi-meeting-deindustrialization/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T09:28:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663885a12030273e27086025.jpg" style="margin-right: 10px;" /> European Commission President Ursula von der Leyen is set to discuss trade imbalances with Chinese President Xi Jinping <br /><a href="https://www.rt.com/business/597048-leyen-xi-meeting-deindustrialization/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Swiss summit on Ukraine a ‚Äòparody‚Äô ‚Äì Lavrov
 - [https://www.rt.com/russia/597051-ukraine-peace-conference-switzerland/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597051-ukraine-peace-conference-switzerland/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T09:18:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/66389f7d85f54010db39ae7b.jpg" style="margin-right: 10px;" /> The Swiss-hosted Ukraine conference is a ‚Äúparody‚Äù aimed at promoting a ‚ÄúRussophobic peace formula,‚Äù the Russian foreign minister has said <br /><a href="https://www.rt.com/russia/597051-ukraine-peace-conference-switzerland/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Another African state holds ‚ÄòImmortal Regiment‚Äô march
 - [https://www.rt.com/africa/597052-immortal-regiment-marches-held-benin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/597052-immortal-regiment-marches-held-benin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T09:13:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/66389b49203027489b10565a.jpg" style="margin-right: 10px;" /> An annual ‚ÄòImmortal Regiment‚Äô event in Benin was attended by dozens of people <br /><a href="https://www.rt.com/africa/597052-immortal-regiment-marches-held-benin/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Blinken blames social media for Israel‚Äôs failed PR on Gaza conflict
 - [https://www.rt.com/news/597047-blinken-social-media-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597047-blinken-social-media-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T08:24:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663882e685f540113563128f.jpg" style="margin-right: 10px;" /> Facts get lost and emotions dominate on social media, US top diplomat Antony Blinken has said of Israel‚Äôs PR problems amid the Gaza war <br /><a href="https://www.rt.com/news/597047-blinken-social-media-israel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin orders tactical nuclear weapons drills
 - [https://www.rt.com/russia/597049-putin-orders-tactical-nuclear-drills/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597049-putin-orders-tactical-nuclear-drills/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T07:36:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638912d203027469c6449fa.jpg" style="margin-right: 10px;" /> The Russian Defense Ministry has announced tactical nuclear weapons drills <br /><a href="https://www.rt.com/russia/597049-putin-orders-tactical-nuclear-drills/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Macron ‚Äòbreathes Russophobia‚Äô ‚Äì Lavrov
 - [https://www.rt.com/russia/597041-macron-breathes-russophobia-lavrov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597041-macron-breathes-russophobia-lavrov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T06:59:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663865fc85f54010a8701ffc.jpg" style="margin-right: 10px;" /> The Russian foreign minister has said that French President Emmanuel Macron may be using Russophobia to gain a leading role in the EU <br /><a href="https://www.rt.com/russia/597041-macron-breathes-russophobia-lavrov/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Multiple dead in Ukrainian drone raid on Belgorod Region ‚Äì governor
 - [https://www.rt.com/russia/597045-multiple-dead-ukrainian-drone-raid-belgorod/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597045-multiple-dead-ukrainian-drone-raid-belgorod/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T06:40:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/6638819685f5401c1f13df9b.jpg" style="margin-right: 10px;" /> Ukrainian drones bombed civilian vehicles in Belgorod Region, leaving several people dead and dozens of injured, authorities say <br /><a href="https://www.rt.com/russia/597045-multiple-dead-ukrainian-drone-raid-belgorod/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky won‚Äôt ‚Äòmobilize God‚Äô ‚Äì Russian church
 - [https://www.rt.com/russia/597039-zelensky-wont-mobilize-god-russian/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/597039-zelensky-wont-mobilize-god-russian/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T01:52:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/66382cab85f5400c5375aa39.jpg" style="margin-right: 10px;" /> It‚Äôs not for Ukraine‚Äôs leader to determine on whose side God is on, the Russian Orthodox Church has said <br /><a href="https://www.rt.com/russia/597039-zelensky-wont-mobilize-god-russian/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel shuts down Gaza border crossing after Hamas attack
 - [https://www.rt.com/news/597040-israel-closes-gaza-crossing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/597040-israel-closes-gaza-crossing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-05-06T00:22:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.05/thumbnail/663822a92030274550327ef4.jpg" style="margin-right: 10px;" /> Israel has closed the key crossing into Gaza on Sunday <br /><a href="https://www.rt.com/news/597040-israel-closes-gaza-crossing/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

