# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: Amazon illegally interferes with an historic UK warehouse election (06 May 2024)
 - [https://pluralistic.net/2024/05/06/one-click-to-quit-the-union](https://pluralistic.net/2024/05/06/one-click-to-quit-the-union)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2024-05-06T10:13:20+00:00

Today's links Amazon illegally interferes with an historic UK warehouse election: "One click to quit" for unions, but not for Prime. Hey look at this: Delights to delectate. This day in history: 2004, 2009, 2014, 2019, 2023 Upcoming appearances: Where to find me. Upcoming appearances: Where to find me. Recent appearances: Where I've been. Latest books: You keep readin' em, I'll keep writin' 'em. Upcoming books: Like I said, I'll keep writin' 'em. Colophon: All the rest. Amazon illegally interferes with an historic UK warehouse election (permalink) Amazon is very good at everything it does, including being very bad at the things it doesn't want to do. Take signing up for Prime: nothing could be simpler. The company has built a greased slide from Prime-curiosity to Prime-confirmed that is the envy of every UX designer. But unsubscribing from Prime? That's a fucking nightmare. Somehow the company that can easily figure out how to sign up for a service is totally baffled when it comes to 

