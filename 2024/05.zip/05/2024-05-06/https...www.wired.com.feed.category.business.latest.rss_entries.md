# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Ethereum’s Cofounder Says SEC Is ‘Gaslighting’ Everyone About Crypto
 - [https://www.wired.com/story/ethereums-co-founder-says-sec-is-gaslighting-us-about-crypto](https://www.wired.com/story/ethereums-co-founder-says-sec-is-gaslighting-us-about-crypto)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2024-05-06T08:30:00+00:00

Joe Lubin cofounded Ethereum. Now his company is suing the Securities and Exchange Commission, and he says the future of the internet is at stake.

