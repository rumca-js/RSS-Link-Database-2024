# Source:UploadVR, URL:https://www.uploadvr.com/rss, language:en

## Quest 1 Loses Beat Saber Multiplayer In November
 - [https://www.uploadvr.com/beat-saber-multiplayer-quest-1-done](https://www.uploadvr.com/beat-saber-multiplayer-quest-1-done)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-05-06T19:54:10+00:00

Original Quest headsets are losing Beat Saber multiplayer in November.

## Synthabout Is Back…with A Bundle And Quest 3 Giveaway
 - [https://www.uploadvr.com/synthabout-is-back-with-a-bundle-and-quest-3-giveaway](https://www.uploadvr.com/synthabout-is-back-with-a-bundle-and-quest-3-giveaway)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-05-06T17:00:55+00:00

Fans of Synth Riders and Walkabout Mini Golf, we’ve got some news: The base games of both are available as a discounted bundle! The Synthabout bundle launched May 3rd, 2024 and will be available until May 17th, 2024 on the Meta Quest and Steam VR for $31.99 USD.

## Apple Vision Pro Sees Jump &amp; Joystick For Crossy Road Castle Hand Tracking
 - [https://www.uploadvr.com/crossy-road-castle-apple-vision-pro](https://www.uploadvr.com/crossy-road-castle-apple-vision-pro)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-05-06T15:08:58+00:00

Hipster Whale’s Crossy Road Castle uses intuitive hand gestures for platformer controls on Apple Vision Pro.

## In Pursuit Of Repetitive Beats Feels Like An &#x27;80s UK Time Capsule In VR
 - [https://www.uploadvr.com/in-pursuit-of-repetitive-beats-impressions-interview](https://www.uploadvr.com/in-pursuit-of-repetitive-beats-impressions-interview)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-05-06T11:00:12+00:00

In Pursuit Of Repetitive Beats is a pleasingly nostalgic VR exploration of the UK's acid-house movement and '80s rave scene.

Our full impressions.

