# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Improper ‘shadow’ ads thriving on Facebook during India’s election
 - [https://www.washingtonpost.com/technology/2024/05/06/india-facebook-ad-policies](https://www.washingtonpost.com/technology/2024/05/06/india-facebook-ad-policies)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-05-06T12:00:00+00:00

Many political ads on Facebook in India hide their true buyers, according to civil society groups and recent studies, threatening the integrity of the process.

## Bosses mandated them back to the office. They took legal action instead.
 - [https://www.washingtonpost.com/technology/2024/05/06/return-office-mandates-lawsuits-employees](https://www.washingtonpost.com/technology/2024/05/06/return-office-mandates-lawsuits-employees)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-05-06T11:00:00+00:00

Workers are fighting office mandates by filing legal complaints and lawsuits as employers increasingly take a hardline stance.

