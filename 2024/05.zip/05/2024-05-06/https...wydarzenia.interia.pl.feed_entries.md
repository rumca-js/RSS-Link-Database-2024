# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Kurski ponownie przyjęty do PiS. Zdradził powód swojej decyzji
 - [https://wydarzenia.interia.pl/kraj/news-kurski-ponownie-przyjety-do-pis-zdradzil-powod-swojej-decyzj,nId,7494135](https://wydarzenia.interia.pl/kraj/news-kurski-ponownie-przyjety-do-pis-zdradzil-powod-swojej-decyzj,nId,7494135)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T20:52:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kurski-ponownie-przyjety-do-pis-zdradzil-powod-swojej-decyzj,nId,7494135"><img align="left" alt="Kurski ponownie przyjęty do PiS. Zdradził powód swojej decyzji " src="https://i.iplsc.com/kurski-ponownie-przyjety-do-pis-zdradzil-powod-swojej-decyzj/000J2M9PLY4MS7I3-C321.jpg" /></a>- Nie poznaję mojego kraju i uświadamiam sobie, że to jest właśnie ten moment, kiedy powinienem stanąć u boku Jarosława Kaczyńskiego - powiedział w poniedziałek Jacek Kurski, pytany o swój powrót do Prawa i Sprawiedliwości. Były prezes TVP jest drugim kandydatem partii na mazowieckiej liście do Parlamentu Europejskiego. </p><br clear="all" />

## "Wybuchowa" inauguracja prezydentury Putina? Rosjanie boją się ataków ukraińskiej armii
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wybuchowa-inauguracja-prezydentury-putina-rosjanie-boja-sie-,nId,7494131](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wybuchowa-inauguracja-prezydentury-putina-rosjanie-boja-sie-,nId,7494131)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T20:35:05+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wybuchowa-inauguracja-prezydentury-putina-rosjanie-boja-sie-,nId,7494131"><img align="left" alt="&quot;Wybuchowa&quot; inauguracja prezydentury Putina? Rosjanie boją się ataków ukraińskiej armii" src="https://i.iplsc.com/wybuchowa-inauguracja-prezydentury-putina-rosjanie-boja-sie/000J2M3DXXVNKWWR-C321.jpg" /></a>&quot;Ukraińskie Siły Zbrojne przygotowują zmasowany atak na terytorium Rosji 7 maja o godzinie 6 rano&quot; - informuje redakcja RT. Dziennikarze, powołując się na źródła w rosyjskiej armii, przekonują, że władze w Kijowie planują uderzenia, które mają zakłócić inaugurację prezydentury Władimira Putina.</p><br clear="all" />

## Amerykański żołnierz zatrzymany w Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-amerykanski-zolnierz-zatrzymany-w-rosji,nId,7494123](https://wydarzenia.interia.pl/zagranica/news-amerykanski-zolnierz-zatrzymany-w-rosji,nId,7494123)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T19:58:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-amerykanski-zolnierz-zatrzymany-w-rosji,nId,7494123"><img align="left" alt="Amerykański żołnierz zatrzymany w Rosji" src="https://i.iplsc.com/amerykanski-zolnierz-zatrzymany-w-rosji/000J2M0J0AGEQH7J-C321.jpg" /></a>Amerykański żołnierz został zatrzymany przez rosyjskie służby, kiedy przebywał na terenie Federacji. Mundurowy miał wcześniej stacjonować w Korei Południowej, a do Rosji udać się &quot;na własną rękę&quot;, nie w celach służbowych. Według zagranicznych mediów sierżanta zatrzymano, ponieważ okradł kobietę. </p><br clear="all" />

## Rosyjskie MSZ o "bezpośredniej konfrontacji z NATO". Wskazują na Polskę
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosyjskie-msz-o-bezposredniej-konfrontacji-z-nato-wskazuja-n,nId,7494114](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosyjskie-msz-o-bezposredniej-konfrontacji-z-nato-wskazuja-n,nId,7494114)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T19:30:43+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosyjskie-msz-o-bezposredniej-konfrontacji-z-nato-wskazuja-n,nId,7494114"><img align="left" alt="Rosyjskie MSZ o &quot;bezpośredniej konfrontacji z NATO&quot;. Wskazują na Polskę" src="https://i.iplsc.com/rosyjskie-msz-o-bezposredniej-konfrontacji-z-nato-wskazuja-n/000J2LYDYAISDJMH-C321.jpg" /></a>&quot;Trudno postrzegać to inaczej niż przejaw gotowości i zamiaru podjęcia bezpośredniej konfrontacji zbrojnej z Rosją&quot; - czytamy w oświadczeniu wydanym przez rosyjskie Ministerstwo Spraw Zagranicznych. Komunikat ma tłumaczyć decyzję władz na Kremlu o organizacji ćwiczeń wojskowych jako odpowiedzi na niedawne wypowiedzi m.in. prezydenta Francji dotyczące przyszłości wojny w Ukrainie.</p><br clear="all" />

## Wielka awantura w Wejherowie. PiS dogadało się z KO
 - [https://wydarzenia.interia.pl/pomorskie/news-wielka-awantura-w-wejherowie-pis-dogadalo-sie-z-ko,nId,7493888](https://wydarzenia.interia.pl/pomorskie/news-wielka-awantura-w-wejherowie-pis-dogadalo-sie-z-ko,nId,7493888)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T19:08:16+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-wielka-awantura-w-wejherowie-pis-dogadalo-sie-z-ko,nId,7493888"><img align="left" alt="Wielka awantura w Wejherowie. PiS dogadało się z KO" src="https://i.iplsc.com/wielka-awantura-w-wejherowie-pis-dogadalo-sie-z-ko/000J2LY9WS8SB6VY-C321.jpg" /></a>Prawo i Sprawiedliwość wykluczyło ze swoich struktur kilku radnych. Decyzja zapadła po tym, jak Witold Reclaf, Krzysztof Bober, Marcin Drewa weszli w porozumienie z Platformą Obywatelską w zakresie wyboru władz powiatu wejherowskiego. Według innych przedstawicieli PiS-u miało to uniemożliwić inną koalicję, a także załamać ideały, jakie reprezentuje sama partia. Postępowania wyjaśniające wszczęto także wobec pozostałych radnych. </p><br clear="all" />

## Von der Leyen z wizytą w domu Jana Pawła II. "Mocne przypomnienie"
 - [https://wydarzenia.interia.pl/malopolskie/news-von-der-leyen-z-wizyta-w-domu-jana-pawla-ii-mocne-przypomnie,nId,7494101](https://wydarzenia.interia.pl/malopolskie/news-von-der-leyen-z-wizyta-w-domu-jana-pawla-ii-mocne-przypomnie,nId,7494101)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T19:05:28+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-von-der-leyen-z-wizyta-w-domu-jana-pawla-ii-mocne-przypomnie,nId,7494101"><img align="left" alt="Von der Leyen z wizytą w domu Jana Pawła II. &quot;Mocne przypomnienie&quot;" src="https://i.iplsc.com/von-der-leyen-z-wizyta-w-domu-jana-pawla-ii-mocne-przypomnie/000J2LV4P6P394SN-C321.jpg" /></a>- To dla nas mocne przypomnienie o naszych chrześcijańskich wartościach i jak one nam pomagają radzić sobie z wszystkimi wyzwaniami w tym chaotycznym świecie - powiedziała Ursula von der Leyen po odwiedzeniu domu Jana Pawła II. Szefowa Komisji Europejskiej odwiedziła Wadowice na własną prośbę. We wtorek ma ona przemawiać na Europejskim Kongresie Gospodarczym w Katowicach. </p><br clear="all" />

## Ofensywa Izraela. Uderzenie na miasto Rafah
 - [https://wydarzenia.interia.pl/zagranica/news-ofensywa-izraela-uderzenie-na-miasto-rafah,nId,7494106](https://wydarzenia.interia.pl/zagranica/news-ofensywa-izraela-uderzenie-na-miasto-rafah,nId,7494106)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T18:48:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ofensywa-izraela-uderzenie-na-miasto-rafah,nId,7494106"><img align="left" alt="Ofensywa Izraela. Uderzenie na miasto Rafah" src="https://i.iplsc.com/ofensywa-izraela-uderzenie-na-miasto-rafah/000G7T8X5FSNVGMR-C321.jpg" /></a>Izrael rozpoczął intensywne naloty na Rafah w Strefie Gazy - podaje w poniedziałek wieczorem AFP.</p><br clear="all" />

## Był jedynym kandydatem, nie został wybrany. "Przywieziony w teczce"
 - [https://wydarzenia.interia.pl/malopolskie/news-byl-jedynym-kandydatem-nie-zostal-wybrany-przywieziony-w-tec,nId,7494097](https://wydarzenia.interia.pl/malopolskie/news-byl-jedynym-kandydatem-nie-zostal-wybrany-przywieziony-w-tec,nId,7494097)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T18:43:36+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-byl-jedynym-kandydatem-nie-zostal-wybrany-przywieziony-w-tec,nId,7494097"><img align="left" alt="Był jedynym kandydatem, nie został wybrany. &quot;Przywieziony w teczce&quot;" src="https://i.iplsc.com/byl-jedynym-kandydatem-nie-zostal-wybrany-przywieziony-w-tec/000J2LU4N4JGNWK8-C321.jpg" /></a>Łukasz Kmita nie został wybrany przez sejmik na nowego marszałka województwa małopolskiego. Polityk Prawa i Sprawiedliwości, które ma większość w sejmiku, był jedynym zgłoszonym na to stanowisko kandydatem.</p><br clear="all" />

## Poprosił o azyl na Białorusi. Jaki majątek ma sędzia Tomasz Szmydt?
 - [https://wydarzenia.interia.pl/kraj/news-poprosil-o-azyl-na-bialorusi-jaki-majatek-ma-sedzia-tomasz-s,nId,7494064](https://wydarzenia.interia.pl/kraj/news-poprosil-o-azyl-na-bialorusi-jaki-majatek-ma-sedzia-tomasz-s,nId,7494064)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T18:37:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-poprosil-o-azyl-na-bialorusi-jaki-majatek-ma-sedzia-tomasz-s,nId,7494064"><img align="left" alt="Poprosił o azyl na Białorusi. Jaki majątek ma sędzia Tomasz Szmydt?" src="https://i.iplsc.com/poprosil-o-azyl-na-bialorusi-jaki-majatek-ma-sedzia-tomasz-s/000J2LNYX9GG1QLS-C321.jpg" /></a>Brak mieszkania, domu, oszczędności, za to kredyt na ponad pół miliona złotych - tak w skrócie opisać można majątek Tomasza Szmydta. Jak wynika z oświadczenia majątkowego, złożonego w ubiegłym roku wynika, że pomimo wysokich zarobków, jedyną rzeczą, którą posiada jest samochód z 2015 roku.</p><br clear="all" />

## Deklaracja Chin ws. broni dla Rosji. Macron komentuje
 - [https://wydarzenia.interia.pl/zagranica/news-deklaracja-chin-ws-broni-dla-rosji-macron-komentuje,nId,7494086](https://wydarzenia.interia.pl/zagranica/news-deklaracja-chin-ws-broni-dla-rosji-macron-komentuje,nId,7494086)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T18:18:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-deklaracja-chin-ws-broni-dla-rosji-macron-komentuje,nId,7494086"><img align="left" alt="Deklaracja Chin ws. broni dla Rosji. Macron komentuje" src="https://i.iplsc.com/deklaracja-chin-ws-broni-dla-rosji-macron-komentuje/000J2LSAHYDXL8BX-C321.jpg" /></a>Przewodniczący Chin Xi Jinpnig zapewnił, że nie będzie sprzedawał broni Rosji, w trakcie prowadzenia przez Federację wojny w Ukrainie. Deklaracja padła podczas spotkania z prezydentem Francji, który nie krył swojego zadowolenia. Europejskie stanowisko w tej sprawie wyraziła także Ursula von der Leyen, która wyraziła nadzieję, że Chiny wywrą jak największy nacisk na Rosję, aby ta zakończyła swoje wojenne działania. </p><br clear="all" />

## Hamas zgodził się na rozejm. Jest reakcja Izraela
 - [https://wydarzenia.interia.pl/zagranica/news-hamas-zgodzil-sie-na-rozejm-jest-reakcja-izraela,nId,7494077](https://wydarzenia.interia.pl/zagranica/news-hamas-zgodzil-sie-na-rozejm-jest-reakcja-izraela,nId,7494077)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T17:31:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-hamas-zgodzil-sie-na-rozejm-jest-reakcja-izraela,nId,7494077"><img align="left" alt="Hamas zgodził się na rozejm. Jest reakcja Izraela" src="https://i.iplsc.com/hamas-zgodzil-sie-na-rozejm-jest-reakcja-izraela/000J2LQJOYVFKMCW-C321.jpg" /></a>Szef Hamasu oświadczył, że zgadza się na propozycję tymczasowego rozejmu w Strefie Gazy. Decyzja nie spotkała się z akceptacją Izraela, którego władze uznały, że zaproponowane &quot;warunku są nie do przyjęcia&quot;.</p><br clear="all" />

## Próbował uciec z Ukrainy. Uwagę zwraca jego strój
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-probowal-uciec-z-ukrainy-uwage-zwraca-jego-stroj,nId,7494044](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-probowal-uciec-z-ukrainy-uwage-zwraca-jego-stroj,nId,7494044)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T16:46:20+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-probowal-uciec-z-ukrainy-uwage-zwraca-jego-stroj,nId,7494044"><img align="left" alt="Próbował uciec z Ukrainy. Uwagę zwraca jego strój" src="https://i.iplsc.com/probowal-uciec-z-ukrainy-uwage-zwraca-jego-stroj/000J2LG44P5LL62T-C321.jpg" /></a>Ukraińska straż graniczna poinformowała o zatrzymaniu &quot;turystyki&quot;, która próbowała nielegalnie przekroczyć granicę z Rumunią. Aresztowanym okazał się 44-latek, który w przebraniu kobiety i ukradzionym paszportem starał się uciec z Ukrainy. Mężczyzna miał na sobie koszulkę, którą naszą pracownicy popularnego dyskontu. </p><br clear="all" />

## Burza wokół przemówienia ministra. Straż Pożarna wydała komunikat
 - [https://wydarzenia.interia.pl/kraj/news-burza-wokol-przemowienia-ministra-straz-pozarna-wydala-komun,nId,7494050](https://wydarzenia.interia.pl/kraj/news-burza-wokol-przemowienia-ministra-straz-pozarna-wydala-komun,nId,7494050)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T16:38:52+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burza-wokol-przemowienia-ministra-straz-pozarna-wydala-komun,nId,7494050"><img align="left" alt="Burza wokół przemówienia ministra. Straż Pożarna wydała komunikat " src="https://i.iplsc.com/burza-wokol-przemowienia-ministra-straz-pozarna-wydala-komun/000GDJY4YCVFG1QO-C321.jpg" /></a>&quot;Komenda Główna PSP stoi na stanowisku, że usługa nagłośnienia Centralnych Obchodów Dnia Strażaka na Placu Marszałka Józefa Piłsudskiego w Warszawie nie została wykonana należycie&quot; - czytamy w komunikacie. Ponadto w mediach społecznościowych udostępniono nagranie z prób do wydarzenia, które odbyły się 3 maja.</p><br clear="all" />

## Jarosław Kaczyński przed komisją ds. afery wizowej. Jest termin
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-przed-komisja-ds-afery-wizowej-jest-termi,nId,7493810](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-przed-komisja-ds-afery-wizowej-jest-termi,nId,7493810)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T16:09:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-przed-komisja-ds-afery-wizowej-jest-termi,nId,7493810"><img align="left" alt="Jarosław Kaczyński przed komisją ds. afery wizowej. Jest termin" src="https://i.iplsc.com/jaroslaw-kaczynski-przed-komisja-ds-afery-wizowej-jest-termi/000J2KFMC27TJ9PQ-C321.jpg" /></a>Komisja ds. afery wizowej przesłucha 5 czerwca Jarosława Kaczyńskiego - przekazał szef komisji Michał Szczerba (KO). Poseł zapowiedział też, że we wtorek zostanie wysłane wezwanie o stawiennictwa na komisji do Daniela Obajtka.</p><br clear="all" />

## Francja wysłała wojska do Ukrainy? Ministerstwo zabrało głos
 - [https://wydarzenia.interia.pl/zagranica/news-francja-wyslala-wojska-do-ukrainy-ministerstwo-zabralo-glos,nId,7493860](https://wydarzenia.interia.pl/zagranica/news-francja-wyslala-wojska-do-ukrainy-ministerstwo-zabralo-glos,nId,7493860)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T15:20:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-francja-wyslala-wojska-do-ukrainy-ministerstwo-zabralo-glos,nId,7493860"><img align="left" alt="Francja wysłała wojska do Ukrainy? Ministerstwo zabrało głos" src="https://i.iplsc.com/francja-wyslala-wojska-do-ukrainy-ministerstwo-zabralo-glos/000J2KXPP3A9FEOA-C321.jpg" /></a>Francuskie Ministerstwo Spraw Zagranicznych zareagowało na informacje o wysłaniu wojsk do Ukrainy. &quot;Kampanie dezinformacyjne dotyczące francuskiego wsparcia dla Ukrainy nie słabną&quot; - podano w komunikacie.</p><br clear="all" />

## Strzały w szkole w Łomży. 15-latek ranny
 - [https://wydarzenia.interia.pl/podlaskie/news-strzaly-w-szkole-w-lomzy-15-latek-ranny,nId,7493865](https://wydarzenia.interia.pl/podlaskie/news-strzaly-w-szkole-w-lomzy-15-latek-ranny,nId,7493865)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T14:58:36+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-strzaly-w-szkole-w-lomzy-15-latek-ranny,nId,7493865"><img align="left" alt="Strzały w szkole w Łomży. 15-latek ranny  " src="https://i.iplsc.com/strzaly-w-szkole-w-lomzy-15-latek-ranny/000J2KYBK3QETXAM-C321.jpg" /></a>- Dzisiaj przed godziną 12:00 otrzymaliśmy zgłoszenie, że na terenie jednej ze szkół średnich doszło do postrzelenia 15-letniego ucznia z broni pneumatycznej - przekazał dyżurny policji podlaskiej w rozmowie z Interią.  </p><br clear="all" />

## Sędzia poprosił o azyl na Białorusi. ABW i Prokuratura reagują
 - [https://wydarzenia.interia.pl/kraj/news-sedzia-poprosil-o-azyl-na-bialorusi-abw-i-prokuratura-reaguj,nId,7493846](https://wydarzenia.interia.pl/kraj/news-sedzia-poprosil-o-azyl-na-bialorusi-abw-i-prokuratura-reaguj,nId,7493846)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T14:21:11+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sedzia-poprosil-o-azyl-na-bialorusi-abw-i-prokuratura-reaguj,nId,7493846"><img align="left" alt="Sędzia poprosił o azyl na Białorusi. ABW i Prokuratura reagują" src="https://i.iplsc.com/sedzia-poprosil-o-azyl-na-bialorusi-abw-i-prokuratura-reaguj/000J2KTD1M07Y9GI-C321.jpg" /></a>Agencja Bezpieczeństwa Wewnętrznego poinformowała o wszczęciu czynności kontrolnych, które mają zweryfikować zakres informacji niejawnych, do których dostęp miał sędzia Tomasz Szmydt. Pracownik Wojewódzkiego Sądu Administracyjnego w Warszawie uciekł na Białoruś, gdzie poprosił o azyl polityczny. Czynności w sprawie prowadzi także Mazowiecki Wydział Zamiejscowy Departamentu do Spraw Przestępczości Zorganizowanej i Korupcji Prokuratury Krajowej.</p><br clear="all" />

## Sędzia poprosił o azyl na Białorusi. ABW reaguje
 - [https://wydarzenia.interia.pl/kraj/news-sedzia-poprosil-o-azyl-na-bialorusi-abw-reaguje,nId,7493846](https://wydarzenia.interia.pl/kraj/news-sedzia-poprosil-o-azyl-na-bialorusi-abw-reaguje,nId,7493846)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T14:21:11+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sedzia-poprosil-o-azyl-na-bialorusi-abw-reaguje,nId,7493846"><img align="left" alt="Sędzia poprosił o azyl na Białorusi. ABW reaguje " src="https://i.iplsc.com/sedzia-poprosil-o-azyl-na-bialorusi-abw-reaguje/000FZ899M2IC99HN-C321.jpg" /></a>Agencja Bezpieczeństwa Wewnętrznego poinformowała o wszczęciu czynności kontrolnych, które mają zweryfikować zakres informacji niejawnych, do których dostęp miał sędzia Tomasz Szmydt. Pracownik Wojewódzkiego Sądu Administracyjnego w Warszawie uciekł na Białoruś, gdzie poprosił o azyl polityczny.</p><br clear="all" />

## Rosja grozi Wielkiej Brytanii. Możliwy atak na ich obiekty
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-grozi-wielkiej-brytanii-mozliwy-atak-na-ich-obiekty,nId,7493835](https://wydarzenia.interia.pl/zagranica/news-rosja-grozi-wielkiej-brytanii-mozliwy-atak-na-ich-obiekty,nId,7493835)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T14:05:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-grozi-wielkiej-brytanii-mozliwy-atak-na-ich-obiekty,nId,7493835"><img align="left" alt="Rosja grozi Wielkiej Brytanii. Możliwy atak na ich obiekty" src="https://i.iplsc.com/rosja-grozi-wielkiej-brytanii-mozliwy-atak-na-ich-obiekty/000J2KSOLR0RTTQ6-C321.jpg" /></a>Rosja może zaatakować brytyjskie obiekty wojskowe na terytorium Ukrainy w odpowiedzi na ukraińskie ataki z użyciem brytyjskiej broni na terenie Federacji - podało rosyjskie Ministerstwo Spraw Zagranicznych. Wezwano ambasadora Wielkiej Brytanii w Moskwie.</p><br clear="all" />

## Matura 2024. Formuła 2015 i formuła 2023. Wymagania egzaminacyjne
 - [https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-formula-2015-i-formula-2023-wymagania-egzaminacy,nId,7399564](https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-formula-2015-i-formula-2023-wymagania-egzaminacy,nId,7399564)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T13:40:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-formula-2015-i-formula-2023-wymagania-egzaminacy,nId,7399564"><img align="left" alt="Matura 2024. Formuła 2015 i formuła 2023. Wymagania egzaminacyjne" src="https://i.iplsc.com/matura-2024-formula-2015-i-formula-2023-wymagania-egzaminacy/000IUW0YAGI6B4LP-C321.jpg" /></a>Zgodnie z wytycznymi MEN w 2024 roku egzamin maturalny, podobnie jak w 2023 roku, zostanie przeprowadzony na podstawie wymagań egzaminacyjnych, a nie wymagań z podstawy programowej, jak było przed laty. Przedstawiamy wymagania egzaminacyjne dla tegorocznych maturzystów. </p><br clear="all" />

## Były poseł PiS skazany. Brał łapówki w zamian za załatwienie pracy
 - [https://wydarzenia.interia.pl/kraj/news-byly-posel-pis-skazany-bral-lapowki-w-zamian-za-zalatwienie-,nId,7493799](https://wydarzenia.interia.pl/kraj/news-byly-posel-pis-skazany-bral-lapowki-w-zamian-za-zalatwienie-,nId,7493799)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T13:30:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-byly-posel-pis-skazany-bral-lapowki-w-zamian-za-zalatwienie-,nId,7493799"><img align="left" alt="Były poseł PiS skazany. Brał łapówki w zamian za załatwienie pracy" src="https://i.iplsc.com/byly-posel-pis-skazany-bral-lapowki-w-zamian-za-zalatwienie/000DI0ORFQJHUQ8U-C321.jpg" /></a>Dwa i pół roku więzienia to wyrok jaki usłyszał były poseł PiS Grzegorz J. Sąd Rejonowy w Rybniku uznał polityka za winnego m.in. przyjmowania łapówek w zamian za rekomendowanie znajomych na stanowiskach w spółkach należących do Jastrzębskiej Spółki Węglowej.</p><br clear="all" />

## Wyruszył Marsz Żywych. Uczestnicy upamiętniają ofiary Zagłady
 - [https://wydarzenia.interia.pl/kraj/news-wyruszyl-marsz-zywych-uczestnicy-upamietniaja-ofiary-zaglady,nId,7493732](https://wydarzenia.interia.pl/kraj/news-wyruszyl-marsz-zywych-uczestnicy-upamietniaja-ofiary-zaglady,nId,7493732)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T13:15:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wyruszyl-marsz-zywych-uczestnicy-upamietniaja-ofiary-zaglady,nId,7493732"><img align="left" alt="Wyruszył Marsz Żywych. Uczestnicy upamiętniają ofiary Zagłady" src="https://i.iplsc.com/wyruszyl-marsz-zywych-uczestnicy-upamietniaja-ofiary-zaglady/000J2J841YS1SW79-C321.jpg" /></a>Kilka tysięcy uczestników Marszu Żywych wyruszyło po południu sprzed bramy w byłym niemieckim obozie Auschwitz I do byłego Auschwitz II-Birkenau. Marsz jest wyrazem pamięci o ofiarach.</p><br clear="all" />

## Niebezpieczne burze z gradem. Alert drugiego stopnia
 - [https://wydarzenia.interia.pl/kraj/news-niebezpieczne-burze-z-gradem-alert-drugiego-stopnia,nId,7493746](https://wydarzenia.interia.pl/kraj/news-niebezpieczne-burze-z-gradem-alert-drugiego-stopnia,nId,7493746)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T12:55:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niebezpieczne-burze-z-gradem-alert-drugiego-stopnia,nId,7493746"><img align="left" alt="Niebezpieczne burze z gradem. Alert drugiego stopnia" src="https://i.iplsc.com/niebezpieczne-burze-z-gradem-alert-drugiego-stopnia/000J2J59PJK7BXS9-C321.jpg" /></a>Burze znowu zawitają w Polsce. Najgorzej będzie na południu kraju - tam w części dwóch województw obowiązuje już ostrzeżenie drugiego stopnia. Miejscami może pojawić się grad oraz bardzo silne ulewy. Lokalnie może spaść nawet 50 mm wody. Intensywne zjawiska nie ustaną również w nocy.</p><br clear="all" />

## Ważna uroczystość na Kremlu. Francja wyśle swojego ambasadora
 - [https://wydarzenia.interia.pl/zagranica/news-wazna-uroczystosc-na-kremlu-francja-wysle-swojego-ambasadora,nId,7493756](https://wydarzenia.interia.pl/zagranica/news-wazna-uroczystosc-na-kremlu-francja-wysle-swojego-ambasadora,nId,7493756)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T12:54:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wazna-uroczystosc-na-kremlu-francja-wysle-swojego-ambasadora,nId,7493756"><img align="left" alt="Ważna uroczystość na Kremlu. Francja wyśle swojego ambasadora" src="https://i.iplsc.com/wazna-uroczystosc-na-kremlu-francja-wysle-swojego-ambasadora/000J2JBM62SUUOXM-C321.jpg" /></a>Francja wyśle swojego ambasadora na zaprzysiężenie prezydenta Rosji Władimira Putina na kolejną sześcioletnią kadencję - podaje Reuters, powołując się na francuskie źródło dyplomatyczne. Uroczystość zaplanowano na wtorek.</p><br clear="all" />

## Przełomowy krok UE wobec Polski. Lawina komentarzy w sieci
 - [https://wydarzenia.interia.pl/zagranica/news-przelomowy-krok-ue-wobec-polski-lawina-komentarzy-w-sieci,nId,7493690](https://wydarzenia.interia.pl/zagranica/news-przelomowy-krok-ue-wobec-polski-lawina-komentarzy-w-sieci,nId,7493690)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T12:45:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przelomowy-krok-ue-wobec-polski-lawina-komentarzy-w-sieci,nId,7493690"><img align="left" alt="Przełomowy krok UE wobec Polski. Lawina komentarzy w sieci" src="https://i.iplsc.com/przelomowy-krok-ue-wobec-polski-lawina-komentarzy-w-sieci/000J2IVXU7GO16QA-C321.jpg" /></a>Komisja Europejska wycofa się z procedury z art. 7 wobec Polski za łamanie zasad praworządności. Precedensowy krok Brukseli jest szeroko komentowany w sieci. &quot;Koalicja 15 października dotrzymuje słowa&quot; - przekonuje Kamila Gasiuk-Pihowicz (Platforma Oybwatelska). Zupełnie innego zdania jest Sebastian Kaleta (Suwerenna Polska). &quot;Ta wieloletnia szopka nie miała nic wspólnego z praworządnością, a była jedynie politycznym teatrem&quot; - twierdzi były wiceminister sprawiedliwości.</p><br clear="all" />

## Wielki szczyt ws. pokoju w Ukrainie. Papież miał postawić warunek
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wielki-szczyt-ws-pokoju-w-ukrainie-papiez-mial-postawic-waru,nId,7493663](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wielki-szczyt-ws-pokoju-w-ukrainie-papiez-mial-postawic-waru,nId,7493663)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T12:20:12+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wielki-szczyt-ws-pokoju-w-ukrainie-papiez-mial-postawic-waru,nId,7493663"><img align="left" alt="Wielki szczyt ws. pokoju w Ukrainie. Papież miał postawić warunek" src="https://i.iplsc.com/wielki-szczyt-ws-pokoju-w-ukrainie-papiez-mial-postawic-waru/000J2IVDBM9FCG9W-C321.jpg" /></a>Stolica Apostolska została zaproszona na konferencję pokojową ws. Ukrainy. Nie wiadomo, kto będzie reprezentował Watykan w Szwajcarii. &quot;Papież Franciszek jest gotów wziąć udział w konferencji w Szwajcarii tylko, gdy Rosja zostanie na nią zaproszona&quot; - miał powiedzieć rosyjskiej agencji RIA Novosti przewodniczący Światowego Związku Staroobrzędowców Leonid Sewastjanow. Związek uchodzi za polityczny pomost pomiędzy Watykanem i Kremlem.</p><br clear="all" />

## Matura 2024. Jak sprawdzić wynik matury w internecie?
 - [https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-jak-sprawdzic-wynik-matury-w-internecie,nId,7265123](https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-jak-sprawdzic-wynik-matury-w-internecie,nId,7265123)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T11:52:46+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-jak-sprawdzic-wynik-matury-w-internecie,nId,7265123"><img align="left" alt="Matura 2024. Jak sprawdzić wynik matury w internecie?" src="https://i.iplsc.com/matura-2024-jak-sprawdzic-wynik-matury-w-internecie/000HD8RW3YOII2RM-C321.jpg" /></a>Matura 2024 rozpocznie się 7 maja. Początkiem lipca będzie z kolei możliwe poznanie swoich wyników w internecie. Sprawdź, w jaki sposób zalogować się do systemu, aby jak najszybciej poznać rezultat egzaminów maturalnych.</p><br clear="all" />

## Rosjanie planują wielki atak na kluczowe miasto? Tłum żołnierzy przy granicy
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-planuja-wielki-atak-na-kluczowe-miasto-tlum-zolnier,nId,7493699](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-planuja-wielki-atak-na-kluczowe-miasto-tlum-zolnier,nId,7493699)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T11:46:23+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-planuja-wielki-atak-na-kluczowe-miasto-tlum-zolnier,nId,7493699"><img align="left" alt="Rosjanie planują wielki atak na kluczowe miasto? Tłum żołnierzy przy granicy" src="https://i.iplsc.com/rosjanie-planuja-wielki-atak-na-kluczowe-miasto-tlum-zolnier/000J2IXJFTRG0L3K-C321.jpg" /></a>Rosyjska armia zgromadziła łącznie około 50 tys. żołnierzy w obwodach biełgorodzkim, kurskim i briańskim, w pobliżu granicy z Ukrainą - wynika z najnowszego raportu Instytutu Studiów nad Wojną (ISW). W ocenie ekspertów może to świadczyć o planach ofensywy na Charków - kluczowe dla Ukrainy miasto. Strona rosyjska uważa, że zajęcie Charkowa byłoby realistycznym celem.</p><br clear="all" />

## Pierwsze posiedzenie sejmiku śląskiego. Wyłoniła się nowa koalicja
 - [https://wydarzenia.interia.pl/slaskie/news-pierwsze-posiedzenie-sejmiku-slaskiego-wylonila-sie-nowa-koa,nId,7493577](https://wydarzenia.interia.pl/slaskie/news-pierwsze-posiedzenie-sejmiku-slaskiego-wylonila-sie-nowa-koa,nId,7493577)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T11:09:51+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-pierwsze-posiedzenie-sejmiku-slaskiego-wylonila-sie-nowa-koa,nId,7493577"><img align="left" alt="Pierwsze posiedzenie sejmiku śląskiego. Wyłoniła się nowa koalicja" src="https://i.iplsc.com/pierwsze-posiedzenie-sejmiku-slaskiego-wylonila-sie-nowa-koa/000J2HPF05QDLWPW-C321.jpg" /></a>Koalicja Obywatelska, Trzecia Droga oraz Lewica oficjalnie formują koalicję w sejmiku śląskim - przekazano jeszcze przed pierwszą inauguracyjną sesją. Marszałkiem ma zostać dotychczasowy poseł PO Wojciech Saługa. W całej Polsce samorządowe jednostki na poziomie województw wybierają nowe władze.</p><br clear="all" />

## "Niszczycielski koktajl" pogodowy. Masy wody spadły na Brazylię
 - [https://wydarzenia.interia.pl/zagranica/news-niszczycielski-koktajl-pogodowy-masy-wody-spadly-na-brazylie,nId,7493650](https://wydarzenia.interia.pl/zagranica/news-niszczycielski-koktajl-pogodowy-masy-wody-spadly-na-brazylie,nId,7493650)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T11:07:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niszczycielski-koktajl-pogodowy-masy-wody-spadly-na-brazylie,nId,7493650"><img align="left" alt="&quot;Niszczycielski koktajl&quot; pogodowy. Masy wody spadły na Brazylię" src="https://i.iplsc.com/niszczycielski-koktajl-pogodowy-masy-wody-spadly-na-brazylie/000J2IAF68MHKD6S-C321.jpg" /></a>To największa katastrofa naturalna w historii brazylijskiego stanu Rio Grande do Sul. Zjawisko El Niño i zmiany klimatyczne doprowadziły do potężnych powodzi, które jeden z klimatologów nazwał &quot;niszczycielskim koktajlem&quot;. Zginęło co najmniej 78 osób, a 115 tysięcy musiało opuścić swoje domy. Ponad sto osób uznaje się za zaginione. </p><br clear="all" />

## Zapowiedź szefa MON. "Będziemy sterować transformacją"
 - [https://wydarzenia.interia.pl/kraj/news-zapowiedz-szefa-mon-bedziemy-sterowac-transformacja,nId,7493634](https://wydarzenia.interia.pl/kraj/news-zapowiedz-szefa-mon-bedziemy-sterowac-transformacja,nId,7493634)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T10:31:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zapowiedz-szefa-mon-bedziemy-sterowac-transformacja,nId,7493634"><img align="left" alt="Zapowiedź szefa MON. &quot;Będziemy sterować transformacją&quot;" src="https://i.iplsc.com/zapowiedz-szefa-mon-bedziemy-sterowac-transformacja/000ITU54UWWUJ6BY-C321.jpg" /></a>- Powołamy Dowództwo Transformacji, będziemy kreować i sterować transformacją jako całym procesem - zapowiedział Władysław Kosiniak-Kamysz. Szef MON nadmienił przy tym, że &quot;transformacja wymaga dowodzenia i zaangażowana różnych jednostek&quot;. Kosiniak-Kamysz dodał też, że jednym z głównych priorytetów będzie indywidualne wyposażenie żołnierzy Wojska Polskiego w sprzęt najwyższej jakości, co ma im dać gwarancję bezpieczeństwa.</p><br clear="all" />

## Migranci znaleźli nowy szlak przez Polskę? Straż Graniczna komentuje
 - [https://wydarzenia.interia.pl/kraj/news-migranci-znalezli-nowy-szlak-przez-polske-straz-graniczna-ko,nId,7493592](https://wydarzenia.interia.pl/kraj/news-migranci-znalezli-nowy-szlak-przez-polske-straz-graniczna-ko,nId,7493592)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T10:07:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-migranci-znalezli-nowy-szlak-przez-polske-straz-graniczna-ko,nId,7493592"><img align="left" alt="Migranci znaleźli nowy szlak przez Polskę? Straż Graniczna komentuje" src="https://i.iplsc.com/migranci-znalezli-nowy-szlak-przez-polske-straz-graniczna-ko/000J2HR7MS2YPO97-C321.jpg" /></a>- Nie mamy żadnych oficjalnych informacji na temat tego szlaku. Jest to miejsce, które zostało w jakiś sposób wytyczone przez cudzoziemców - przekazała Interii mł. chor. SG Katarzyna Przybysz p.o. rzecznika prasowego Komendanta Morskiego Oddziału Straży Granicznej. To odpowiedź na medialne doniesienia mówiące o tym, jakoby przez polskie wybrzeże miał przebiegać nowy szlak migracyjny prowadzący do Niemiec. - To musiała być jakaś sytuacja incydentalna - usłyszeliśmy.</p><br clear="all" />

## Matura 2024. Kontekst na egzaminie z języka polskiego. Obowiązkowy element
 - [https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-kontekst-na-egzaminie-z-jezyka-polskiego-obowiaz,nId,7493586](https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-kontekst-na-egzaminie-z-jezyka-polskiego-obowiaz,nId,7493586)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T09:56:29+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-kontekst-na-egzaminie-z-jezyka-polskiego-obowiaz,nId,7493586"><img align="left" alt="Matura 2024. Kontekst na egzaminie z języka polskiego. Obowiązkowy element" src="https://i.iplsc.com/matura-2024-kontekst-na-egzaminie-z-jezyka-polskiego-obowiaz/000J2HOEC5P4FU0H-C321.jpg" /></a>Kontekst to nowy obowiązkowy element matury ustnej i pisemnej z języka polskiego. Maturzysta, pisząc wypracowanie na poziomie podstawowym, powinien opierać argumentację nie tylko na dwóch tekstach literackich, ale też na minimum dwóch kontekstach. Rozróżnienie tych dwóch elementów często budzi wątpliwości wśród zdających maturę 2024. Czym zatem jest wspomniany kontekst? Wyjaśniamy. </p><br clear="all" />

## Przełom w relacjach z Brukselą. Szefowa KE: Nowy rozdział dla Polski
 - [https://wydarzenia.interia.pl/zagranica/news-przelom-w-relacjach-z-bruksela-szefowa-ke-nowy-rozdzial-dla-,nId,7493607](https://wydarzenia.interia.pl/zagranica/news-przelom-w-relacjach-z-bruksela-szefowa-ke-nowy-rozdzial-dla-,nId,7493607)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T09:43:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przelom-w-relacjach-z-bruksela-szefowa-ke-nowy-rozdzial-dla-,nId,7493607"><img align="left" alt="Przełom w relacjach z Brukselą. Szefowa KE: Nowy rozdział dla Polski" src="https://i.iplsc.com/przelom-w-relacjach-z-bruksela-szefowa-ke-nowy-rozdzial-dla/000J2I4WCL07YBL4-C321.jpg" /></a>&quot;Uważamy, że po ponad sześciu latach procedurę określoną w art. 7 można zamknąć. Gratuluję premierowi Donaldowi Tuskowi i jego rządowi w związku z tym ważnym przełomem&quot; - przekazała w sieci przewodnicząca Komisji Europejskiej Ursula von der Leyen. Bruksela twierdzi, że nad Wisłą nie ma już  &quot;wyraźnego zagrożenia&quot; dla rządów prawa. </p><br clear="all" />

## Kiedy Rosji skończą się zasoby? Skarbonka na "czarną godzinę" pustoszeje
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kiedy-rosji-skoncza-sie-zasoby-skarbonka-na-czarna-godzine-p,nId,7493498](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kiedy-rosji-skoncza-sie-zasoby-skarbonka-na-czarna-godzine-p,nId,7493498)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T09:34:32+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kiedy-rosji-skoncza-sie-zasoby-skarbonka-na-czarna-godzine-p,nId,7493498"><img align="left" alt="Kiedy Rosji skończą się zasoby? Skarbonka na &quot;czarną godzinę&quot; pustoszeje" src="https://i.iplsc.com/kiedy-rosji-skoncza-sie-zasoby-skarbonka-na-czarna-godzine-p/000J2H9OD15MQU1L-C321.jpg" /></a>&quot;Ludzi u nas dużo&quot;, zapewniają Rosjanie. Dużo czy nie, więcej niż w Ukrainie, a ci w mundurach nie buntują się mimo niedostatków i skrajnie przedmiotowego traktowania. W czym zawiera się istotna dla konfliktu na Wschodzie zmienna. Stanowi ją ludzka masa, której właściwości - liczebność i karność na granicy bezwoli - dają Moskwie przynajmniej teoretycznie możliwość prowadzenia bardzo długiej wojny.</p><br clear="all" />

## Polski sędzia poprosił o azyl na Białorusi. "Otwarty i przyjazny kraj"
 - [https://wydarzenia.interia.pl/zagranica/news-polski-sedzia-poprosil-o-azyl-na-bialorusi-otwarty-i-przyjaz,nId,7493595](https://wydarzenia.interia.pl/zagranica/news-polski-sedzia-poprosil-o-azyl-na-bialorusi-otwarty-i-przyjaz,nId,7493595)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T09:34:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polski-sedzia-poprosil-o-azyl-na-bialorusi-otwarty-i-przyjaz,nId,7493595"><img align="left" alt="Polski sędzia poprosił o azyl na Białorusi. &quot;Otwarty i przyjazny kraj&quot;" src="https://i.iplsc.com/polski-sedzia-poprosil-o-azyl-na-bialorusi-otwarty-i-przyjaz/000J2HOM1BIMKX4O-C321.jpg" /></a>Sędzia Wojewódzkiego Sądu Administracyjnego w Warszawie Tomasz Szmydt zwrócił się z prośbą o udzielenie azylu politycznego na Białorusi. Sędzia sprzeciwia się polityce polskich władz. Poinformował o tym na konferencji prasowej w Mińsku. - Łukaszenka dużo zrobił, żeby w naszym regionie była spokojna i stabilna sytuacja - powiedział na konferencji prasowej. - Białoruś jest otwartym i przyjaznym krajem - dodał. </p><br clear="all" />

## Francja miała wysłać żołnierzy do Ukrainy. Jest reakcja Kremla
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-francja-miala-wyslac-zolnierzy-do-ukrainy-jest-reakcja-kreml,nId,7493536](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-francja-miala-wyslac-zolnierzy-do-ukrainy-jest-reakcja-kreml,nId,7493536)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T09:32:31+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-francja-miala-wyslac-zolnierzy-do-ukrainy-jest-reakcja-kreml,nId,7493536"><img align="left" alt="Francja miała wysłać żołnierzy do Ukrainy. Jest reakcja Kremla" src="https://i.iplsc.com/francja-miala-wyslac-zolnierzy-do-ukrainy-jest-reakcja-kreml/000J2HNSGGWBQSUS-C321.jpg" /></a>Amerykański analityk Stephen Bryen, były członek administracji Ronalda Reagana, twierdzi, że Francja wysłała do Słowiańska na wschodzie Ukrainy około 100 żołnierzy z 3. pułku piechoty Legii Cudzoziemskiej. Mają oni pomóc armii ukraińskiej w odpieraniu ofensywy Rosji w Donbasie - poinformował. Na doniesienia odpowiedział już rzecznik Kremla Dmitrij Pieskow. </p><br clear="all" />

## Beata Kempa ostrzega przed "miastami migrantów" w Polsce
 - [https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-beata-kempa-ostrzega-przed-miastami-migrantow-w-polsce,nId,7493477](https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-beata-kempa-ostrzega-przed-miastami-migrantow-w-polsce,nId,7493477)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T09:28:30+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-beata-kempa-ostrzega-przed-miastami-migrantow-w-polsce,nId,7493477"><img align="left" alt="Beata Kempa ostrzega przed &quot;miastami migrantów&quot; w Polsce" src="https://i.iplsc.com/beata-kempa-ostrzega-przed-miastami-migrantow-w-polsce/000J2GFK05P6Q6MO-C321.jpg" /></a>- Przez Komisję Europejską będą nam rosnąć miasta migrantów wielkości Tychów czy Katowic - ostrzega w wywiadzie z Interią Beata Kempa, eurodeputowana Suwerennej Polski, kandydatka z list Prawa i Sprawiedliwości. </p><br clear="all" />

## Matura 2024. Co można wziąć na egzamin? Lista jest krótka
 - [https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-co-mozna-wziac-na-egzamin-lista-jest-krotka,nId,7363728](https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-co-mozna-wziac-na-egzamin-lista-jest-krotka,nId,7363728)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T09:28:01+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-co-mozna-wziac-na-egzamin-lista-jest-krotka,nId,7363728"><img align="left" alt="Matura 2024. Co można wziąć na egzamin? Lista jest krótka " src="https://i.iplsc.com/matura-2024-co-mozna-wziac-na-egzamin-lista-jest-krotka/000IQJM2VX3N2963-C321.jpg" /></a>Matura 2024 rozpocznie się serią obowiązkowych egzaminów 7 maja. Co maturzysta może mieć na egzaminie? Długopis - to dość oczywiste. Ale czy na maturę można zabrać jeszcze jakieś przedmioty? Odpowiadamy.</p><br clear="all" />

## Najnowszy sondaż. Kandydat niezależny zagrożeniem dla Trumpa
 - [https://wydarzenia.interia.pl/zagranica/news-najnowszy-sondaz-kandydat-niezalezny-zagrozeniem-dla-trumpa,nId,7493482](https://wydarzenia.interia.pl/zagranica/news-najnowszy-sondaz-kandydat-niezalezny-zagrozeniem-dla-trumpa,nId,7493482)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T08:32:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-najnowszy-sondaz-kandydat-niezalezny-zagrozeniem-dla-trumpa,nId,7493482"><img align="left" alt="Najnowszy sondaż. Kandydat niezależny zagrożeniem dla Trumpa" src="https://i.iplsc.com/najnowszy-sondaz-kandydat-niezalezny-zagrozeniem-dla-trumpa/000J2G4W7AVI1JNO-C321.jpg" /></a>Na pół roku przed wyborami prezydenckimi w USA Donald Trump ma 46 procent poparcia, a Joe Biden 44. &quot;Donald Trump cieszy się zaufaniem i poradzi sobie z większością problemów&quot; - wskazuje stacja ABC News. Głosy liderowi Partii Republikańskiej może odebrać kandydat niezależny Robert F. Kennedy. </p><br clear="all" />

## Zaginął 18-letni Jakub. "Wzmożono działania" poszukiwawcze
 - [https://wydarzenia.interia.pl/slaskie/news-zaginal-18-letni-jakub-wzmozono-dzialania-poszukiwawcze,nId,7493517](https://wydarzenia.interia.pl/slaskie/news-zaginal-18-letni-jakub-wzmozono-dzialania-poszukiwawcze,nId,7493517)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T08:15:30+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-zaginal-18-letni-jakub-wzmozono-dzialania-poszukiwawcze,nId,7493517"><img align="left" alt="Zaginął 18-letni Jakub. &quot;Wzmożono działania&quot; poszukiwawcze" src="https://i.iplsc.com/zaginal-18-letni-jakub-wzmozono-dzialania-poszukiwawcze/000J2FP98L9J0DVA-C321.jpg" /></a>Zaginął 18-letni Jakub Wilczek. Nastolatek ostatni raz widziany był w niedzielę około godz. 2 w nocy w okolicy rzeki Odry w Grzegorzowicach. Od tamtej pory nie skontaktował się z bliskimi. - W poniedziałek od godz. 9:00 rano zostały wzmożone jeszcze większe działania - przekazała Interii oficer prasowa KPP w Raciborzu sierż. sztab. Joanna Wiśniewska.</p><br clear="all" />

## Matura 2024 z języka polskiego już we wtorek. O tym musisz pamiętać
 - [https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-z-jezyka-polskiego-juz-we-wtorek-o-tym-musisz-pa,nId,7493444](https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-z-jezyka-polskiego-juz-we-wtorek-o-tym-musisz-pa,nId,7493444)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T08:11:18+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-z-jezyka-polskiego-juz-we-wtorek-o-tym-musisz-pa,nId,7493444"><img align="left" alt="Matura 2024 z języka polskiego już we wtorek. O tym musisz pamiętać" src="https://i.iplsc.com/matura-2024-z-jezyka-polskiego-juz-we-wtorek-o-tym-musisz-pa/000J2EEB9ARXHI7H-C321.jpg" /></a>Już we wtorek (7 maja) o godzinie 9:00 rozpocznie się tegoroczna matura. W pierwszej kolejności - jak co roku - abiturienci zmierzą się z językiem polskim na poziomie podstawowym - w formule 2023 i formule 2015. Czym różnią się powyższe egzaminy, ile czasu uczniowie będą mieć na ich rozwiązanie oraz jakie są wymagania? Poniżej prezentujemy najważniejsze informacje.</p><br clear="all" />

## Władimir Putin wydał rozkaz. Wkrótce wielkie ćwiczenia armii
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wladimir-putin-wydal-rozkaz-wkrotce-wielkie-cwiczenia-armii,nId,7493504](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wladimir-putin-wydal-rozkaz-wkrotce-wielkie-cwiczenia-armii,nId,7493504)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T07:57:22+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wladimir-putin-wydal-rozkaz-wkrotce-wielkie-cwiczenia-armii,nId,7493504"><img align="left" alt="Władimir Putin wydał rozkaz. Wkrótce wielkie ćwiczenia armii" src="https://i.iplsc.com/wladimir-putin-wydal-rozkaz-wkrotce-wielkie-cwiczenia-armii/000J2FK9FSREOBJO-C321.jpg" /></a>&quot;W odpowiedzi na prowokacyjne wypowiedzi i groźby poszczególnych zachodnich urzędników&quot; rosyjskie wojsko wkrótce rozpocznie ćwiczenia. Odpowiedni rozkaz wydał Władimir Putin, choć Kreml nie precyzuje daty rozpoczęcia oraz zakończenia manewrów. Wiadomo, że będą miały miejsce w okręgu południowym przy udziale sił lotniczych i morskich.</p><br clear="all" />

## Matura 2024: Arkusze CKE i rozwiązania w Interii. Oto harmonogram
 - [https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-arkusze-cke-i-rozwiazania-w-interii-oto-harmonog,nId,7493469](https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-arkusze-cke-i-rozwiazania-w-interii-oto-harmonog,nId,7493469)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T07:50:49+00:00

<p><a href="https://wydarzenia.interia.pl/raport-matura-2024/news-matura-2024-arkusze-cke-i-rozwiazania-w-interii-oto-harmonog,nId,7493469"><img align="left" alt="Matura 2024: Arkusze CKE i rozwiązania w Interii. Oto harmonogram" src="https://i.iplsc.com/matura-2024-arkusze-cke-i-rozwiazania-w-interii-oto-harmonog/000J2FB0ULE7UP0W-C321.jpg" /></a>We wtorek rozpoczyna się matura 2024. Na start absolwenci szkół średnich zmierzą się z trzema przedmiotami obowiązkowymi: językiem polskim, matematyką i językiem angielskim. Gdzie szukać rozwiązań? Każdego dnia Interia będzie publikowała arkusze z zaproponowanymi przez naszych ekspertów odpowiedziami. Poniżej szczegółowy harmonogram.</p><br clear="all" />

## Warszawa: Nastolatek wpadł pod tramwaj. Trafił do szpitala
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawa-nastolatek-wpadl-pod-tramwaj-trafil-do-szpitala,nId,7493472](https://wydarzenia.interia.pl/mazowieckie/news-warszawa-nastolatek-wpadl-pod-tramwaj-trafil-do-szpitala,nId,7493472)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T07:39:00+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawa-nastolatek-wpadl-pod-tramwaj-trafil-do-szpitala,nId,7493472"><img align="left" alt="Warszawa: Nastolatek wpadł pod tramwaj. Trafił do szpitala" src="https://i.iplsc.com/warszawa-nastolatek-wpadl-pod-tramwaj-trafil-do-szpitala/000J2E9HU7HVWXXX-C321.jpg" /></a>Groźny wypadek w Warszawie. W poniedziałek rano stołeczna straż pożarna otrzymała zgłoszenie o chłopcu, który wpadł pod tramwaj przy przystanku Muzeum Narodowe. - Za pomocą poduszek pneumatycznych tramwaj został uniesiony w celu ewakuacji osoby spod pojazdu - przekazał Interii st. kpt. Wojciech Kapczyński. Po zdarzeniu 14-latek został przewieziony do szpitala.</p><br clear="all" />

## Rosjanie zaatakowali dronami. Część Ukrainy pozbawiona prądu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-zaatakowali-dronami-czesc-ukrainy-pozbawiona-pradu,nId,7493434](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-zaatakowali-dronami-czesc-ukrainy-pozbawiona-pradu,nId,7493434)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T06:47:18+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-zaatakowali-dronami-czesc-ukrainy-pozbawiona-pradu,nId,7493434"><img align="left" alt="Rosjanie zaatakowali dronami. Część Ukrainy pozbawiona prądu" src="https://i.iplsc.com/rosjanie-zaatakowali-dronami-czesc-ukrainy-pozbawiona-pradu/000J2DX3T1LWTDF0-C321.jpg" /></a>Rosjanie przeprowadzili nocny atak na obwód sumski w Ukrainie. Celem stały się obiekty infrastruktury energetycznej, których uszkodzenie spowodowało przerwy w dostawach prądu. Siły Powietrzne Sił Zbrojnych Ukrainy przekazały, że zniszczono 12 z 13 dronów okupantów, jakie znalazły się nad obwodem.</p><br clear="all" />

## Burza po wystąpieniu. Marcin Kierwiński poddał się kolejnemu testowi
 - [https://wydarzenia.interia.pl/kraj/news-burza-po-wystapieniu-marcin-kierwinski-poddal-sie-kolejnemu-,nId,7493448](https://wydarzenia.interia.pl/kraj/news-burza-po-wystapieniu-marcin-kierwinski-poddal-sie-kolejnemu-,nId,7493448)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T06:42:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burza-po-wystapieniu-marcin-kierwinski-poddal-sie-kolejnemu-,nId,7493448"><img align="left" alt="Burza po wystąpieniu. Marcin Kierwiński poddał się kolejnemu testowi" src="https://i.iplsc.com/burza-po-wystapieniu-marcin-kierwinski-poddal-sie-kolejnemu/000J2E7644A1CN85-C321.jpg" /></a>- Zaraz po badaniu alkomatem udałem się do szpitala, żeby pobrać sobie krew na obecność alkoholu. Wynik jest 0,0. Mam epikryzę wypisową, bo zgłaszam się w oczywisty sposób na SOR w takich sytuacjach - ujawnił Marcin Kierwiński na antenie Radia ZET. Minister spraw wewnętrznych i administracji zapewnił, że choć nie jest abstynentem, to bardzo rzadko pije alkohol.</p><br clear="all" />

## Daniel Obajtek inauguruje kampanię "ze szczególnymi pozdrowieniami"
 - [https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-daniel-obajtek-inauguruje-kampanie-ze-szczegolnymi-pozdrowie,nId,7493418](https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-daniel-obajtek-inauguruje-kampanie-ze-szczegolnymi-pozdrowie,nId,7493418)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T06:20:41+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-daniel-obajtek-inauguruje-kampanie-ze-szczegolnymi-pozdrowie,nId,7493418"><img align="left" alt="Daniel Obajtek inauguruje kampanię &quot;ze szczególnymi pozdrowieniami&quot;" src="https://i.iplsc.com/daniel-obajtek-inauguruje-kampanie-ze-szczegolnymi-pozdrowie/000J2DVD6W4RLNJO-C321.jpg" /></a>Po serii doniesień o przebywaniu za granicą oraz ostatniej nieobecności na wiecu PiS były prezes PKN Orlen przecina spekulacje. &quot;Na kampanijnym szlaku, Bachórz w gminie Dynów. Działamy dla Polski&quot; - napisał w sieci Daniel Obajtek. I zamieścił krótki filmik z Podkarpacia - regionu, który zamierza reprezentować w Parlamencie Europejskim.
</p><br clear="all" />

## Rozmowy na szczycie. Szefowa KE domaga się "uczciwej konkurencji"
 - [https://wydarzenia.interia.pl/zagranica/news-rozmowy-na-szczycie-szefowa-ke-domaga-sie-uczciwej-konkurenc,nId,7493390](https://wydarzenia.interia.pl/zagranica/news-rozmowy-na-szczycie-szefowa-ke-domaga-sie-uczciwej-konkurenc,nId,7493390)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T05:13:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rozmowy-na-szczycie-szefowa-ke-domaga-sie-uczciwej-konkurenc,nId,7493390"><img align="left" alt="Rozmowy na szczycie. Szefowa KE domaga się &quot;uczciwej konkurencji&quot;" src="https://i.iplsc.com/rozmowy-na-szczycie-szefowa-ke-domaga-sie-uczciwej-konkurenc/000J2DRFWWVNL3MW-C321.jpg" /></a>- Musimy działać, aby konkurencja była uczciwa i niezakłócona - powiedziała przewodnicząca Komisji Europejskiej na kilkanaście godzin przed spotkaniem z Xi Jinpingiem we Francji. Politykom towarzyszyć będzie lider kraju Emmanuel Macron. Ursula von der Leyen wskazała, że &quot;obecna nierównowaga w dostępie do rynku jest nietrwała i należy ją skorygować&quot;.</p><br clear="all" />

## Burze nie odpuszczają. Alerty dla siedmiu województw
 - [https://wydarzenia.interia.pl/kraj/news-burze-nie-odpuszczaja-alerty-dla-siedmiu-wojewodztw,nId,7493395](https://wydarzenia.interia.pl/kraj/news-burze-nie-odpuszczaja-alerty-dla-siedmiu-wojewodztw,nId,7493395)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T04:55:27+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burze-nie-odpuszczaja-alerty-dla-siedmiu-wojewodztw,nId,7493395"><img align="left" alt="Burze nie odpuszczają. Alerty dla siedmiu województw" src="https://i.iplsc.com/burze-nie-odpuszczaja-alerty-dla-siedmiu-wojewodztw/000J2DPKWHO3A754-C321.jpg" /></a>Burze nie odpuszczają. W poniedziałek ponownie prognozowane są silne wyładowania atmosferyczne, w związku z czym Instytut Meteorologii i Gospodarki Wodnej (IMGW) wydał alert pierwszego stopnia dla siedmiu województw. Burzom towarzyszyć mogą silne opady deszczu lub gradu. Może również mocno wiać.</p><br clear="all" />

## Bakterie w mleku dla niemowląt. GIS alarmuje
 - [https://wydarzenia.interia.pl/ciekawostki/news-bakterie-w-mleku-dla-niemowlat-gis-alarmuje,nId,7492059](https://wydarzenia.interia.pl/ciekawostki/news-bakterie-w-mleku-dla-niemowlat-gis-alarmuje,nId,7492059)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T04:35:02+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-bakterie-w-mleku-dla-niemowlat-gis-alarmuje,nId,7492059"><img align="left" alt="Bakterie w mleku dla niemowląt. GIS alarmuje" src="https://i.iplsc.com/bakterie-w-mleku-dla-niemowlat-gis-alarmuje/000J2DP6W8B016P6-C321.jpg" /></a>&quot;Wykryto obecności bakterii Listeria monocytogenes w jednej partii mleka modyfikowanego dla niemowląt po szóstym miesiącu życia&quot; - taki komunikat podał GIS. Chodzi o mleko Bebilon, które produkowane jest przez firmę Nutricia Polska Sp. z o.o.. 

</p><br clear="all" />

## Kryzys się pogłębia. Na Izrael padły oskarżenia
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kryzys-sie-poglebia-na-izrael-padly-oskarzenia,nId,7493388](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kryzys-sie-poglebia-na-izrael-padly-oskarzenia,nId,7493388)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T04:17:27+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kryzys-sie-poglebia-na-izrael-padly-oskarzenia,nId,7493388"><img align="left" alt="Kryzys się pogłębia. Na Izrael padły oskarżenia" src="https://i.iplsc.com/kryzys-sie-poglebia-na-izrael-padly-oskarzenia/000J2DOPWK645CAG-C321.jpg" /></a>Izrael nadal odmawia ONZ niesienia pomocy w Strefie Gazy w ramach prób zapobieżenia głodowi - takie oskarżenia padły ze strony szefa agencji ONZ ds. uchodźców palestyńskich (UNRWA) Philippe Lazzariniego. Wezwał także Hamas i inne grupy do &quot;zaprzestania ataków na przejściach humanitarnych&quot;. </p><br clear="all" />

## Perfidny plan Władimira Putina. Chce "unieruchomić Europę"
 - [https://wydarzenia.interia.pl/zagranica/news-perfidny-plan-wladimira-putina-chce-unieruchomic-europe,nId,7492062](https://wydarzenia.interia.pl/zagranica/news-perfidny-plan-wladimira-putina-chce-unieruchomic-europe,nId,7492062)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T04:15:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-perfidny-plan-wladimira-putina-chce-unieruchomic-europe,nId,7492062"><img align="left" alt="Perfidny plan Władimira Putina. Chce &quot;unieruchomić Europę&quot;" src="https://i.iplsc.com/perfidny-plan-wladimira-putina-chce-unieruchomic-europe/000BND24RQG2U8IV-C321.jpg" /></a>&quot;Rosja uczy się, jak mogłaby unieruchomić Europę. To rozgrzewka&quot; - podał w niedzielę brytyjski &quot;Financial Times&quot;. Chodzi o zamachy, podpalenia i ataki na infrastrukturę, obserwowane od dłuższego czasu w Europie. Jak podaje gazeta, te &quot;nieprzypadkowe incydenty&quot; są akcjami sabotażu organizowanymi przez Kreml w związku z &quot;wejściem w trwały konflikt z Zachodem&quot;. </p><br clear="all" />

## Rosyjskie sabotaże w Europie. "To tylko rozgrzewka"
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjskie-sabotaze-w-europie-to-tylko-rozgrzewka,nId,7492062](https://wydarzenia.interia.pl/zagranica/news-rosyjskie-sabotaze-w-europie-to-tylko-rozgrzewka,nId,7492062)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-05-06T04:15:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjskie-sabotaze-w-europie-to-tylko-rozgrzewka,nId,7492062"><img align="left" alt="Rosyjskie sabotaże w Europie. &quot;To tylko rozgrzewka&quot;" src="https://i.iplsc.com/rosyjskie-sabotaze-w-europie-to-tylko-rozgrzewka/000BND24RQG2U8IV-C321.jpg" /></a>&quot;Rosja uczy się, jak mogłaby unieruchomić Europę. To rozgrzewka&quot; - podał w niedzielę brytyjski &quot;Financial Times&quot;. Chodzi o zamachy, podpalenia i ataki na infrastrukturę, obserwowane od dłuższego czasu w Europie. Jak podaje gazeta, te &quot;nieprzypadkowe incydenty&quot; są akcjami sabotażu organizowanymi przez Kreml w związku z &quot;wejściem w trwały konflikt z Zachodem&quot;. </p><br clear="all" />

