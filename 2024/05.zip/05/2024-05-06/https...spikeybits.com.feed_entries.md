# Source:Spikey Bits, URL:https://spikeybits.com/feed, language:en-US

## Chaos Space Marines Combat Patrol Value is Pretty Wild
 - [https://spikeybits.com/warhammer-40k/chaos-space-marines-combat-patrol-value-is-pretty-wild](https://spikeybits.com/warhammer-40k/chaos-space-marines-combat-patrol-value-is-pretty-wild)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T19:55:19+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/05/CHaos-Combat-Patrol-space-marines-value-pricing-worth-it.png"><img alt="CHaos Combat Patrol space marines value pricing worth it" class="aligncenter size-full wp-image-461479" height="720" src="https://spikeybits.com/wp-content/uploads/2024/05/CHaos-Combat-Patrol-space-marines-value-pricing-worth-it.png" width="1280" /></a></p>
<p><span>Here is the new Chaos Space Marines Warhammer 40k Combat Patrol box value and pricing in our savings breakdown- check it</p>
<p><a href="https://spikeybits.com/warhammer-40k/chaos-space-marines-combat-patrol-value-is-pretty-wild/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/chaos-space-marines-combat-patrol-value-is-pretty-wild/">Chaos Space Marines Combat Patrol Value is Pretty Wild</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Horus Heresy New Releases Roadmap Updated For 2024
 - [https://spikeybits.com/tabletop-news/gw-whats-next-for-horus-heresy-previews-new-releases](https://spikeybits.com/tabletop-news/gw-whats-next-for-horus-heresy-previews-new-releases)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T18:00:00+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/04/Horus-Heresy-icon-wal-hor-forge-world.png"><img alt="Horus Heresy icon wal hor forge world" class="aligncenter size-full wp-image-459405" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/Horus-Heresy-icon-wal-hor-forge-world.png" width="1280" /></a></p>
<p>Here&#8217;s the latest new release roadmap, previews, and upcoming plans from GW detailing what we can look forward to for Horus Heresy in</p>
<p><a href="https://spikeybits.com/tabletop-news/gw-whats-next-for-horus-heresy-previews-new-releases/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/tabletop-news/gw-whats-next-for-horus-heresy-previews-new-releases/">Horus Heresy New Releases Roadmap Updated For 2024</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New Skaven Jezzails Blow Away the Competition in AoS
 - [https://spikeybits.com/age-of-sigmar/new-skaven-jezzails-blow-away-the-competition-in-aos](https://spikeybits.com/age-of-sigmar/new-skaven-jezzails-blow-away-the-competition-in-aos)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T17:30:07+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/05/Skaven-Jezzails-6.png"><img alt="Skaven Jezzails 6" class="aligncenter size-full wp-image-461455" height="875" src="https://spikeybits.com/wp-content/uploads/2024/05/Skaven-Jezzails-6.png" width="1548" /></a>Skaven Jezzails are getting a big rework after their old models spent many, many years in rotation for 4th edition AoS!</p>
<p><span id="more-461447"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p><p><a href="https://spikeybits.com/age-of-sigmar/new-skaven-jezzails-blow-away-the-competition-in-aos/"></a></p><p><a href="https://spikeybits.com/age-of-sigmar/new-skaven-jezzails-blow-away-the-competition-in-aos/"></a><a href="https://spikeybits.com"></a></p>

## Age of Sigmar New Releases Roadmap Updated For 2024!
 - [https://spikeybits.com/tabletop-news/gw-releases-aos-battletome-roadmap](https://spikeybits.com/tabletop-news/gw-releases-aos-battletome-roadmap)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T17:00:00+00:00

<p><p><a href="https://spikeybits.com/?p=422416&amp;preview=true"><img alt="Ags-of-Sigmar-New-release-roadmap" class="aligncenter wp-image-422415 size-full" height="424" src="https://spikeybits.com/wp-content/uploads/2022/12/Ags-of-Sigmar-New-release-roadmap.png" width="740" /></a>Here&#8217;s the latest Age of Sigmar new releases roadmap for 2024 and previews for all the upcoming new miniatures and battletomes!</p>
<p><span id="more-422416"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p>We&#8217;ve</p>
<p><a href="https://spikeybits.com/tabletop-news/gw-releases-aos-battletome-roadmap/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/tabletop-news/gw-releases-aos-battletome-roadmap/">Age of Sigmar New Releases Roadmap Updated For 2024!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## May The 4th Reveals New Squads For Legion & Shatterpoint
 - [https://spikeybits.com/star-wars-legion/may-the-4th-reveals-two-new-squads-star-wars-legion-shatterpoint](https://spikeybits.com/star-wars-legion/may-the-4th-reveals-two-new-squads-star-wars-legion-shatterpoint)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T16:30:40+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/05/starwarspost-1.png"><img alt="May The Fourth" class="size-full wp-image-461446 aligncenter" height="720" src="https://spikeybits.com/wp-content/uploads/2024/05/starwarspost-1.png" width="1280" /></a>Atomic Mass Games celebrated May 4th by revealing new squads, for Star Wars Shatterpoint and Legion that will hit pre-orders soon!</p>
<p><span id="more-461443"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p><p><a href="https://spikeybits.com/star-wars-legion/may-the-4th-reveals-two-new-squads-star-wars-legion-shatterpoint/"></a></p><p><a href="https://spikeybits.com/star-wars-legion/may-the-4th-reveals-two-new-squads-star-wars-legion-shatterpoint/">&#038;</a><a href="https://spikeybits.com"></a></p>

## RUMORS: New Blood Angels, DKoK, & 40k Summer Release List
 - [https://spikeybits.com/wh40k-rumors/rumors-new-blood-angels-dkok-40k-summer-release-list](https://spikeybits.com/wh40k-rumors/rumors-new-blood-angels-dkok-40k-summer-release-list)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T16:15:41+00:00

<p><p><a href="https://spikeybits.com/?p=457157&amp;preview=true"><img alt="Chaos-rumors-title-hor-wal-1280-site-warhammer-40k-games-workshop1" class="aligncenter wp-image-446405 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2023/10/Chaos-rumors-title-hor-wal-1280-site-warhammer-40k-games-workshop1.png" width="1280" /></a>Huge rumors for Blood Angels, Death Korps of Krieg, GSC, and Sisters of Battle point to new miniatures coming soon to Warhammer 40k!</p>
<p><span id="more-457157"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p><p><a href="https://spikeybits.com/wh40k-rumors/rumors-new-blood-angels-dkok-40k-summer-release-list/"></a></p><p><a href="https://spikeybits.com/wh40k-rumors/rumors-new-blood-angels-dkok-40k-summer-release-list/">&#038;</a><a href="https://spikeybits.com"></a></p>

## TWO Huge New Warhammer Previews On The Way 40k AoS & More!
 - [https://spikeybits.com/warhammer-40k/two-huge-new-warhammer-previews-on-the-way-for-40k-aos-more](https://spikeybits.com/warhammer-40k/two-huge-new-warhammer-previews-on-the-way-for-40k-aos-more)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T15:55:18+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/02/warhammer-community-new-preview-games-workshop-warhammer-40k-releases-previews.png"><img alt="warhammer community new preview games workshop warhammer 40k releases previews" class="aligncenter wp-image-455750 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/02/warhammer-community-new-preview-games-workshop-warhammer-40k-releases-previews.png" width="1280" /></a>Two new GW previews are on the way (one during the week and one on the weekend) GW confirmed for</p>
<p><a href="https://spikeybits.com/warhammer-40k/two-huge-new-warhammer-previews-on-the-way-for-40k-aos-more/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/two-huge-new-warhammer-previews-on-the-way-for-40k-aos-more/">TWO Huge New Warhammer Previews On The Way 40k AoS &#038; More!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Customize Your Knights With These New Iron Wolf Minis Bits!
 - [https://spikeybits.com/new-releases/customize-your-knights-with-these-new-iron-wolf-minis-bits](https://spikeybits.com/new-releases/customize-your-knights-with-these-new-iron-wolf-minis-bits)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T14:30:27+00:00

<p><p><a href="https://spikeybits.com/?p=460362&amp;preview=true"><img alt="Mini Demon Skull Head &amp; Cowl " class="aligncenter wp-image-460370 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/ironwolf.png" width="1280" /></a>Make your Knights stand out on the tabletop with these customizable bits and head options from Iron Wolf Minis!<span id="more-460362"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/new-releases/customize-your-knights-with-these-new-iron-wolf-minis-bits/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/new-releases/customize-your-knights-with-these-new-iron-wolf-minis-bits/">Customize Your Knights With These New Iron Wolf Minis Bits!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW Shutting Down All Warehouses, Dumpsters $1M, Best 40k Armies LATEST
 - [https://spikeybits.com/warhammer-40k/gw-shutting-down-all-warehouses-dumpsters-1m-best-40k-armies-latest](https://spikeybits.com/warhammer-40k/gw-shutting-down-all-warehouses-dumpsters-1m-best-40k-armies-latest)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T10:30:14+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/05/games-workshop-close-shutdown.jpg"><img alt="games workshop close shutdown warehouse" class="aligncenter size-full wp-image-461349" height="720" src="https://spikeybits.com/wp-content/uploads/2024/05/games-workshop-close-shutdown.jpg" width="1280" /></a></p>
<p>Here are all the new wargaming releases, previews, rumors, and more from the weekend, plus the latest from Games Workshop.<br />
<span id="more-461394"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
<div></p>
<p><a href="https://spikeybits.com/warhammer-40k/gw-shutting-down-all-warehouses-dumpsters-1m-best-40k-armies-latest/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/gw-shutting-down-all-warehouses-dumpsters-1m-best-40k-armies-latest/">GW Shutting Down All Warehouses, Dumpsters $1M, Best 40k Armies LATEST</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Gruntak Rampaging Impalers Kickstarter From Avatars Of War Coming Soon!
 - [https://spikeybits.com/kickstarter/gruntak-rampaging-impalers-kickstarter-from-avatars-of-war-coming-soon](https://spikeybits.com/kickstarter/gruntak-rampaging-impalers-kickstarter-from-avatars-of-war-coming-soon)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T09:30:03+00:00

<p><p><a href="https://spikeybits.com/?p=461178&amp;preview=true"><img alt="Avatars of War Gruntak" class="aligncenter wp-image-461179" height="718" src="https://spikeybits.com/wp-content/uploads/2024/04/Screenshot_331-1.png" width="1280" /></a>Get ready to ride off with the Gruntak Rampaging Impalers Kickstarter from Avatars of War, which is on the way soon!</p>
<p><span id="more-461178"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p><p><a href="https://spikeybits.com/kickstarter/gruntak-rampaging-impalers-kickstarter-from-avatars-of-war-coming-soon/"></a></p><p><a href="https://spikeybits.com/kickstarter/gruntak-rampaging-impalers-kickstarter-from-avatars-of-war-coming-soon/"></a><a href="https://spikeybits.com"></a></p>

## GW Reveals New Tau & Ork MTO Pre-Order Lineup
 - [https://spikeybits.com/warhammer-40k/gw-reveals-new-tau-ork-mto-pre-order-lineup](https://spikeybits.com/warhammer-40k/gw-reveals-new-tau-ork-mto-pre-order-lineup)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-05-06T06:30:13+00:00

<p><p><a href="https://spikeybits.com/?p=460996&amp;preview=true"><img alt="" class="aligncenter wp-image-460485 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/GW-Made-To-Order-warhammer-40k-games-workshop.png" width="1280" /></a>These new releases for Warhammer 40k, featuring classic MTO Tau and Ork minis, will be available for pre-order this Saturday!</p>
<p><span id="more-461386"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p>It&#8217;s</p>
<p><a href="https://spikeybits.com/warhammer-40k/gw-reveals-new-tau-ork-mto-pre-order-lineup/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/gw-reveals-new-tau-ork-mto-pre-order-lineup/">GW Reveals New Tau &#038; Ork MTO Pre-Order Lineup</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

