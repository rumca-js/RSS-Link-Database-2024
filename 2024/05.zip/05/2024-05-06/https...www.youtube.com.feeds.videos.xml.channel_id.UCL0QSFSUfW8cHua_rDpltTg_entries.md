# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## Why Blaxploitation movies are dead.
 - [https://www.youtube.com/watch?v=wTrNB-nT87A](https://www.youtube.com/watch?v=wTrNB-nT87A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2024-05-06T16:03:16+00:00

#FormerNetworkExec #CallMeChato #coffy

Dante and I talk about on of our favourite Blaxploitation movies, Coffy, staring the beautiful Pam Grier.

Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Dante's YouTube channel
https://www.youtube.com/@UCl4oUjMlHmeBu5Q-OmrfpcA 

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

