# Source:Y Combinator, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcefcZRL2oaA_uBNeo5UOWg, language:en

## RFS: Dev tools inspired by existing internal tools
 - [https://www.youtube.com/watch?v=0UycVzrZm7E](https://www.youtube.com/watch?v=0UycVzrZm7E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcefcZRL2oaA_uBNeo5UOWg
 - date published: 2024-05-06T14:29:15+00:00



