# Source:Nature Materials, URL:https://www.nature.com/nmat/current_issue/rss, language:en

## Electric-field-induced multiferroic topological solitons
 - [https://www.nature.com/articles/s41563-024-01890-4](https://www.nature.com/articles/s41563-024-01890-4)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-05-06T10:18:29.539618+00:00

<p>Nature Materials, Published online: 06 May 2024; <a href="https://www.nature.com/articles/s41563-024-01890-4">doi:10.1038/s41563-024-01890-4</a></p>Control over topological antiferromagnetic entities is achieved at room temperature in multiferroic nanodevices using an electric field that induces magnetoelectric coupling to ferroelectric centre states.

