# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Woke Jesus
 - [https://www.youtube.com/watch?v=tyXLLF-L8_0](https://www.youtube.com/watch?v=tyXLLF-L8_0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2024-05-06T16:02:07+00:00

Want proof that Jesus was a woke socialist? Look no further than these classic quotes straight from the Bible.

Get your copy of 'Woke Jesus' today and defend your faith against progressive ideology: https://lucasmiles.org/bee

#comedy #bible #woke #jesus #christian

