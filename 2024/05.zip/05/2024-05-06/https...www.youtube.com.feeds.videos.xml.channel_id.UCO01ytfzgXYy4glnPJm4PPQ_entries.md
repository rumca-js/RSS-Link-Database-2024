# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Behind The Scenes Of Divorce: What Really Goes On
 - [https://www.youtube.com/watch?v=s_YQj4gTu1U](https://www.youtube.com/watch?v=s_YQj4gTu1U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-05-06T23:00:23+00:00

Matt Walsh and divorce lawyer James J. Sexton discuss the realities of divorce. 

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full interview here: https://bit.ly/3JR4Egc

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Watch The Frat Boy Clip That Has The Internet In An OUTRAGE
 - [https://www.youtube.com/watch?v=K2ceRhphcVg](https://www.youtube.com/watch?v=K2ceRhphcVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-05-06T22:00:08+00:00

Hallow - Join Hallow’s Prayer 40 Challenge. You’ll also get 3 months free at https://hallow.com/MattWalsh

The media has assembled the outrage mob once again, this time to hunt down and punish a frat boy who allegedly made racist noises while confronting a pro-Palestine protester at Ole Miss.

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1362 - https://bit.ly/4brA9Jg

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## There is no perjury allowed in my court...I think.
 - [https://www.youtube.com/watch?v=Ut283rZWut4](https://www.youtube.com/watch?v=Ut283rZWut4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-05-06T20:00:09+00:00

A NEW episode of “JUDGED by Matt Walsh” premieres tomorrow on DailyWire+! Get caught up on episodes 1-5 here: http://bit.ly/3W0jFTZ

## Wow, she's the first person to notice this
 - [https://www.youtube.com/watch?v=oWPrrQ56uWE](https://www.youtube.com/watch?v=oWPrrQ56uWE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-05-06T19:00:31+00:00



## The Left Suddenly Forgets About Gaza And Spends Two Days Outraged Over A Frat Boy's Joke
 - [https://www.youtube.com/watch?v=no5DWCHhazY](https://www.youtube.com/watch?v=no5DWCHhazY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-05-06T18:00:06+00:00

Today on the Matt Walsh Show, the media has assembled the outrage mob once again, this time to hunt down and punish a frat boy who allegedly made racist noises while confronting a pro-Palestine protester at Ole Miss. Also, a new investigation reveals that the state of Massachusetts is paying 21 dollars a plate to feed glorified dog food to illegal migrants. The scandal isn't the quality of the food, but the fact that they're spending tax money to feed illegal immigrants in the first place. And Kristi Noem goes on Face the Nation to promote her new book. What follows is one of the most bizarre and awkward interviews any politician has ever given.

TIMESTAMPS:

00:00 - 00:33 Opening 
2:01 - 20:23 The Left Suddenly Forgets About Gaza And Spends Two Days Outraged Over A Frat Boy's Joke
21:17 - 31:56 Massachusetts Pays Millions In Migrant Crisis Meals
31:57 - 40:10 RFK Claims He 'Doesn't Know Enough' About Sex-Change Surgeries For Minors
40:11 - 45:05 Harvard MDs Perform Horribly Embarrass

## Frat Boys Vs. Nerdy Protestors. Whose Side Are You Taking?
 - [https://www.youtube.com/watch?v=JmWjf-vlM1I](https://www.youtube.com/watch?v=JmWjf-vlM1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-05-06T15:00:25+00:00

The frat boy uprising continues in response to the leftist protests on college campuses across the country. 

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1361 - https://bit.ly/3WmGrpz

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Teachers being armed in school is a GOOD idea
 - [https://www.youtube.com/watch?v=Mm4JWZt3sJg](https://www.youtube.com/watch?v=Mm4JWZt3sJg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-05-06T14:00:13+00:00



