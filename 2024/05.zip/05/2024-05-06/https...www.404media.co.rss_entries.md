# Source:404 Media, URL:https://www.404media.co/rss, language:en

## 'Kendrick's Pool:' People Are Tagging Drake's House With Insults on Google Maps
 - [https://www.404media.co/kendrick-drake-google-maps-toronto](https://www.404media.co/kendrick-drake-google-maps-toronto)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-05-06T14:51:19+00:00

The Drake versus Kendrick beef enters the Google Maps arena.

## Amazon Driver Saves Woman’s Life, Rewarded With Pizza Party and Laptop
 - [https://www.404media.co/amazon-driver-saves-womans-life-rewarded-with-pizza-party-and-laptop](https://www.404media.co/amazon-driver-saves-womans-life-rewarded-with-pizza-party-and-laptop)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-05-06T13:57:48+00:00

“It’s always ‘An Amazon Driver’ when they do something good, and ‘a third party Amazon driver’ when it’s bad.”

