# Source:Glass Reflection, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmEbe0XH51CI09gm_9Fcn8Q, language:en-US

## I Watched EVERY SINGLE NEW ANIME of the Spring 2024 Season...
 - [https://www.youtube.com/watch?v=kc7CRkxaxvk](https://www.youtube.com/watch?v=kc7CRkxaxvk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmEbe0XH51CI09gm_9Fcn8Q
 - date published: 2024-05-10T17:54:16+00:00

► Find where to stream all the anime here from our friends at Yatta Tachi: https://yattatachi.com/watch-spring-2024-anime

► Support me on Patreon: http://www.patreon.com/Arkada
► Follow me on Twitter: http://www.twitter.com/GlassReflection

00:00:00 - INTRO
00:02:12 - A Condition Called Love
00:05:05 - A Salad Bowl of Eccentrics
00:06:58 - An Archdemon's Dilemma: How to Love Your Elf Bride
00:08:46 - As a Reincarnated Aristocrat, I'll Use My Appraisal Skill to Rise in the World
00:10:49 - Astro Note
00:12:52 - Bartender: Glass of God
00:15:13 - Chillin' in Another World with Level 2 Super Cheat Powers
00:17:43 - Girls Band Cry
00:19:20 - GO! GO! Loser Ranger!
00:21:08 - Gods' Games We Play
00:23:47 - Grandpa and Grandma Turn Young Again
00:24:40 - HIGHSPEED Étoile
00:25:45 - I Was Reincarnated as the 7th Prince.....
00:26:58 - Jellyfish Can’t Swim in the Night
00:29:26 - Kaiju No.8
00:32:22 - Mission: Yozakura Family
00:34:01 - Mysterious Disappearances
00:35:39 - Oblivion Battery
00

