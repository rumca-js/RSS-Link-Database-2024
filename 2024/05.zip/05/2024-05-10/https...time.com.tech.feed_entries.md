# Source:TIME - tech, URL:https://time.com/tech/feed, language:en-UK

## Strong Solar Storm Could Disrupt Communications and Produce Northern Lights in U.S.
 - [https://time.com/6976952/6976952](https://time.com/6976952/6976952)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-05-10T18:31:46+00:00

The National Oceanic and Atmospheric Administration issued a rare geomagnetic storm watch — the first in nearly 20 years.

## Asteroids, Myst, Resident Evil, SimCity and Ultima Inducted Into World Video Game Hall of Fame
 - [https://time.com/6976744/asteroids-myst-resident-evil-simcity-ultima-world-video-game-hall-of-fame](https://time.com/6976744/asteroids-myst-resident-evil-simcity-ultima-world-video-game-hall-of-fame)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-05-10T00:06:10+00:00

Asteroids, Myst, Resident Evil, SimCity and Ultima were recognized for their impacts on the video game industry and popular culture.

