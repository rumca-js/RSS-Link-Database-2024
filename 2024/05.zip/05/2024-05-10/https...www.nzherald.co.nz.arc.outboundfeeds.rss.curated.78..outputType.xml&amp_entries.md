# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## Penrose plumbing store fire: Crews are treating the blaze as unexplained
 - [https://www.nzherald.co.nz/nz/penrose-plumbing-store-fire-crews-are-treating-the-blaze-as-unexplained/IOHBOVU56RHEPLZ4GBGHMIWUPA](https://www.nzherald.co.nz/nz/penrose-plumbing-store-fire-crews-are-treating-the-blaze-as-unexplained/IOHBOVU56RHEPLZ4GBGHMIWUPA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T18:35:58+00:00

About 15 fire trucks rushed to the fire overnight.

## Black Ferns v USA: Ruby Tui on Warriors return to NRLW and what it means for sporting landscape
 - [https://www.nzherald.co.nz/sport/rugby/black-ferns/black-ferns-v-usa-ruby-tui-on-warriors-return-to-nrlw-and-what-it-means-for-sporting-landscape/EYEGZMAP7BDW7AGHU7NY53HQVQ](https://www.nzherald.co.nz/sport/rugby/black-ferns/black-ferns-v-usa-ruby-tui-on-warriors-return-to-nrlw-and-what-it-means-for-sporting-landscape/EYEGZMAP7BDW7AGHU7NY53HQVQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T18:00:00+00:00

'All that league movement just makes us focus inward like our focus has been.'

## Rainbow Storytime: Rotorua Lakes Council reviews cancellation decision
 - [https://www.nzherald.co.nz/rotorua-daily-post/news/rainbow-storytime-rotorua-lakes-council-reviews-cancellation-decision/JIJE5KPJ5BFVBLULCYJGXXZORI](https://www.nzherald.co.nz/rotorua-daily-post/news/rainbow-storytime-rotorua-lakes-council-reviews-cancellation-decision/JIJE5KPJ5BFVBLULCYJGXXZORI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:04:00+00:00

The council says the online abuse and threats were to attendees 'including children'.

## Senior Mongols gang member on the run for 12 months, armed police find loaded shotgun under couch within reach of child
 - [https://www.nzherald.co.nz/nz/senior-mongols-gang-member-on-the-run-for-12-months-armed-police-find-loaded-shotgun-under-couch-within-reach-of-child/MFCDIGZXGJA5DEZ52LI2BFWLGQ](https://www.nzherald.co.nz/nz/senior-mongols-gang-member-on-the-run-for-12-months-armed-police-find-loaded-shotgun-under-couch-within-reach-of-child/MFCDIGZXGJA5DEZ52LI2BFWLGQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:03:00+00:00

Name suppression lifted when the gang's 'orchestrating influence' was sentenced.

## Brave baby’s battle: Almost 150 days on oxygen, 78 nights in hospital, now thriving
 - [https://www.nzherald.co.nz/nz/brave-babys-battle-almost-150-days-on-oxygen-78-nights-in-hospital-now-thriving/23XNRP44AFAQFAKXANE3HSBGKA](https://www.nzherald.co.nz/nz/brave-babys-battle-almost-150-days-on-oxygen-78-nights-in-hospital-now-thriving/23XNRP44AFAQFAKXANE3HSBGKA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

Ardie Neil was born at 27 weeks and weighed just 1.2kg.

## Christopher Luxon on foreign affairs, Winston Peters, Aukus and the global events that shaped him
 - [https://www.nzherald.co.nz/nz/politics/christopher-luxon-on-foreign-affairs-winston-aukus-and-the-global-events-that-shaped-him/ZK567277QZDIXFLS64YU7INYBU](https://www.nzherald.co.nz/nz/politics/christopher-luxon-on-foreign-affairs-winston-aukus-and-the-global-events-that-shaped-him/ZK567277QZDIXFLS64YU7INYBU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

Christopher Luxon's American political hero might surprise you.

## Claire Trevett: The problems and politics of a winter power crisis for Simeon Brown, Shane Jones
 - [https://www.nzherald.co.nz/nz/politics/claire-trevett-the-problems-and-politics-of-a-winter-power-crisis-for-simeon-brown-shane-jones/M5C5HILAX5H7FNICJKTWKIXJP4](https://www.nzherald.co.nz/nz/politics/claire-trevett-the-problems-and-politics-of-a-winter-power-crisis-for-simeon-brown-shane-jones/M5C5HILAX5H7FNICJKTWKIXJP4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

No government likes to waste a crisis - even a two-hour-long one

## Herald morning quiz: May 11
 - [https://www.nzherald.co.nz/nz/herald-morning-quiz-may-11/OPBF453QEFDMNLEXDF326G4QUI](https://www.nzherald.co.nz/nz/herald-morning-quiz-may-11/OPBF453QEFDMNLEXDF326G4QUI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

Test your knowledge with the Herald's morning quiz.

## Mary Holm column: $500k? $1m? How much do I need to save for my golden years?
 - [https://www.nzherald.co.nz/business/mary-holm-column-500k-1m-how-much-do-i-need-to-save-for-my-golden-years/7XUDYTRK4BFZBMN4ARSNPPRTHA](https://www.nzherald.co.nz/business/mary-holm-column-500k-1m-how-much-do-i-need-to-save-for-my-golden-years/7XUDYTRK4BFZBMN4ARSNPPRTHA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

OPINION: If the $1m estimate were correct, a big proportion of retirees would struggle.

## Mother’s Day: What I wish I had known would change after becoming a mum
 - [https://www.nzherald.co.nz/northern-advocate/news/mothers-day-what-i-wish-i-knew-about-how-my-relationship-would-change-after-becoming-a-mum/6JAAXMFBOZFBBFC7LX5SGOC774](https://www.nzherald.co.nz/northern-advocate/news/mothers-day-what-i-wish-i-knew-about-how-my-relationship-would-change-after-becoming-a-mum/6JAAXMFBOZFBBFC7LX5SGOC774)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

The key to your relationship surviving and thriving as a new parent.

## Mt Albert Aquatic Centre near-drowning: Doctor who helped save preschooler’s life raises serious safety concerns
 - [https://www.nzherald.co.nz/nz/mt-albert-aquatic-centre-near-drowning-doctor-who-helped-save-preschoolers-life-raises-serious-safety-concerns/763EZJ6VYZFETBED4ONE37LB7I](https://www.nzherald.co.nz/nz/mt-albert-aquatic-centre-near-drowning-doctor-who-helped-save-preschoolers-life-raises-serious-safety-concerns/763EZJ6VYZFETBED4ONE37LB7I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

Preschooler was pulled blue from the water by a member of the public - not lifeguards.

## My Kitchen Rules judge Colin Fassnidge’s health scare: ‘It was a really big wake up call’
 - [https://www.nzherald.co.nz/entertainment/my-kitchen-rules-judge-colin-fassnidges-health-scare-it-was-a-really-big-wake-up-call/HXTELAVB5FFX7JUI4S36HSGK7M](https://www.nzherald.co.nz/entertainment/my-kitchen-rules-judge-colin-fassnidges-health-scare-it-was-a-really-big-wake-up-call/HXTELAVB5FFX7JUI4S36HSGK7M)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

The MKR New Zealand judge’s illness forced him to face some home truths.

## NZ should follow Singapore and Ireland to grow economy, Winston Peters says
 - [https://www.nzherald.co.nz/business/nz-should-follow-singapore-and-ireland-to-grow-economy-winston-peters-says/6PJUOVYRDFGD3PDWIAJKAXZRIM](https://www.nzherald.co.nz/business/nz-should-follow-singapore-and-ireland-to-grow-economy-winston-peters-says/6PJUOVYRDFGD3PDWIAJKAXZRIM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

Deputy Prime Minister eyeing tax and investment strategies used by other small nations.

## Skeleton found in Porirua park confirmed to be Patricia Burt, 36 years after mystery disappearance
 - [https://www.nzherald.co.nz/nz/skeleton-found-in-porirua-park-confirmed-to-be-patricia-burt-36-years-after-mystery-disappearance/FD55DVPJAZFULAWCNBJ4J4DUOQ](https://www.nzherald.co.nz/nz/skeleton-found-in-porirua-park-confirmed-to-be-patricia-burt-36-years-after-mystery-disappearance/FD55DVPJAZFULAWCNBJ4J4DUOQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T17:00:00+00:00

Patricia Burt's daughter says a visit to the site has raised more questions for her.

## Chiefs v Moana Pasifika result: Visitors cruise to Super Rugby Pacific victory
 - [https://www.nzherald.co.nz/sport/rugby/super-rugby/chiefs-v-moana-pasifika-result-visitors-cruise-to-super-rugby-pacific-victory/XDJM5KBLRJGGXBG44XMUXGVB4U](https://www.nzherald.co.nz/sport/rugby/super-rugby/chiefs-v-moana-pasifika-result-visitors-cruise-to-super-rugby-pacific-victory/XDJM5KBLRJGGXBG44XMUXGVB4U)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T09:47:16+00:00

The Chiefs moved to third in Super Rugby after an uninspiring encounter at Mt Smart.

## Prison violence: Whiu Te Aramakutu led to cells swearing after learning how long he will be in jail
 - [https://www.nzherald.co.nz/nz/prison-violence-whiu-te-aramakutu-led-to-cells-swearing-after-learning-how-long-he-will-be-in-jail/HT4IAC7MSVFHBBBRHLNCKPQBOI](https://www.nzherald.co.nz/nz/prison-violence-whiu-te-aramakutu-led-to-cells-swearing-after-learning-how-long-he-will-be-in-jail/HT4IAC7MSVFHBBBRHLNCKPQBOI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T08:00:00+00:00

Victims included an innocent householder, a prison guard, a policewoman and two inmates.

## KiwiRail mega ferries: What Labour Finance Minister Grant Robertson knew about financial troubles
 - [https://www.nzherald.co.nz/nz/kiwirail-mega-ferries-what-labour-finance-minister-grant-robertson-knew-about-financial-troubles/NHKEPQDVWBAYJF7IS7UCT2TDNM](https://www.nzherald.co.nz/nz/kiwirail-mega-ferries-what-labour-finance-minister-grant-robertson-knew-about-financial-troubles/NHKEPQDVWBAYJF7IS7UCT2TDNM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T07:01:13+00:00

Tense letters between Grant Robertson and KiwiRail's chairman have been revealed.

## Havelock North kidnapping: Adam Wardle jailed for two years, 11 months
 - [https://www.nzherald.co.nz/nz/havelock-north-kidnapping-adam-wardle-jailed-for-two-years-11-months/OXZPLREVJRH6PFH555QECMNO3Y](https://www.nzherald.co.nz/nz/havelock-north-kidnapping-adam-wardle-jailed-for-two-years-11-months/OXZPLREVJRH6PFH555QECMNO3Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T07:00:00+00:00

One girl who ran to escape returned into danger to help her screaming sister.

## Moana Pasifika v Chiefs live updates: Super Rugby Pacific round 12
 - [https://www.nzherald.co.nz/sport/rugby/super-rugby/moana-pasifika-v-chiefs-live-updates-super-rugby-pacific-round-12/IBYFNZ7JGRAGVA23OOMACC562A](https://www.nzherald.co.nz/sport/rugby/super-rugby/moana-pasifika-v-chiefs-live-updates-super-rugby-pacific-round-12/IBYFNZ7JGRAGVA23OOMACC562A)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T06:45:00+00:00

The Chiefs can move into third with a win over Moana Pasifika.

## Stolen Mercedes trial: In closing Blenheim crash case Crown says two at fault, defence says one to blame
 - [https://www.nzherald.co.nz/nz/crown-says-in-closing-blenheim-crash-case-it-takes-two-defence-says-only-one-to-blame/YSWQLLVBIFFDHFUNT7QT7NXBMQ](https://www.nzherald.co.nz/nz/crown-says-in-closing-blenheim-crash-case-it-takes-two-defence-says-only-one-to-blame/YSWQLLVBIFFDHFUNT7QT7NXBMQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T06:30:00+00:00

The Crown says ‘it takes two’, while the defence says only one person is culpable.

## Media Insider: TVNZ ordered to mediation over cuts; Revealed - Mike McRoberts’ post-Newshub business move; Screen sector funding shake-up - NZ on Air chair: ‘I’ve probably run my race’
 - [https://www.nzherald.co.nz/business/media-insider-tvnz-ordered-to-mediation-over-cuts-revealed-mike-mcroberts-post-newshub-business-move-screen-sector-funding-shake-up-nz-on-air-chair-ive-probably-run-my-race/M7UC62I2DJBAFPDILPQOUJ55GQ](https://www.nzherald.co.nz/business/media-insider-tvnz-ordered-to-mediation-over-cuts-revealed-mike-mcroberts-post-newshub-business-move-screen-sector-funding-shake-up-nz-on-air-chair-ive-probably-run-my-race/M7UC62I2DJBAFPDILPQOUJ55GQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T06:18:35+00:00

TVNZ has been ordered to mediation - will popular shows win a reprieve?

## Ponsonby shooting: Vigil held for Robert Horne at site of fatal central Auckland incident
 - [https://www.nzherald.co.nz/nz/ponsonby-shooting-vigil-held-for-robert-horne-at-site-of-fatal-central-auckland-incident/OSLA2LHKY5ACFM2BZHXUGML36U](https://www.nzherald.co.nz/nz/ponsonby-shooting-vigil-held-for-robert-horne-at-site-of-fatal-central-auckland-incident/OSLA2LHKY5ACFM2BZHXUGML36U)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T05:47:42+00:00

A long-time friend of Horne said he was "loved by everyone".

## TVNZ job cuts: Broadcaster told to enter mediation after ERA rules consultation clause was broken
 - [https://www.nzherald.co.nz/nz/tvnz-job-cuts-broadcaster-told-to-enter-mediation-after-era-rules-consultation-clause-was-broken/NJ4V3LUL7VG3VLHCUNX7FBTPA4](https://www.nzherald.co.nz/nz/tvnz-job-cuts-broadcaster-told-to-enter-mediation-after-era-rules-consultation-clause-was-broken/NJ4V3LUL7VG3VLHCUNX7FBTPA4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T05:02:36+00:00

ERA orders TVNZ to start mediation with union over job cuts.

## Taupō engineer Jon Hall jailed for ‘huge’ nationwide building forgery
 - [https://www.nzherald.co.nz/rotorua-daily-post/news/taupo-engineer-jon-hall-jailed-for-huge-nationwide-building-forgery/36SY26UBEJGLZNLWTG2KPSNBEY](https://www.nzherald.co.nz/rotorua-daily-post/news/taupo-engineer-jon-hall-jailed-for-huge-nationwide-building-forgery/36SY26UBEJGLZNLWTG2KPSNBEY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T04:14:30+00:00

It's been described as possibly the biggest ever building industry scam in New Zealand.

## National school cellphone ban: Auckland students find walkie-talkie loophole
 - [https://www.nzherald.co.nz/nz/national-school-cellphone-ban-auckland-students-find-walkie-talkie-loophole/UZHM2MM2XRBI5PVSJV6CNLNJF4](https://www.nzherald.co.nz/nz/national-school-cellphone-ban-auckland-students-find-walkie-talkie-loophole/UZHM2MM2XRBI5PVSJV6CNLNJF4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T03:40:21+00:00

Aucklander teen tells the Herald about cunning communication idea.

## Power crisis averted, but a sign of things to come?
 - [https://www.nzherald.co.nz/business/power-crisis-averted-but-a-sign-of-things-to-come/5EKOZGVCSBBG3H5LPRMQ6EWZ2M](https://www.nzherald.co.nz/business/power-crisis-averted-but-a-sign-of-things-to-come/5EKOZGVCSBBG3H5LPRMQ6EWZ2M)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T03:22:09+00:00

Businesses and individuals managed to avoid a blackout, this time.

## Burnham fatal fire: Teenage victim Elizabeth Marvin, 16, ‘always had a smile on her face’
 - [https://www.nzherald.co.nz/nz/burnham-fatal-fire-teenage-victim-elizabeth-marvin-16-always-had-a-smile-on-her-face/PSORBN7DX5HMNCRSANCOHRCXME](https://www.nzherald.co.nz/nz/burnham-fatal-fire-teenage-victim-elizabeth-marvin-16-always-had-a-smile-on-her-face/PSORBN7DX5HMNCRSANCOHRCXME)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T03:19:39+00:00

Investigation continues into the fire that killed 16-year-old Lizzy Marvin.

## Gulf Harbour body in bag: Update in homicide investigation reveals new details
 - [https://www.nzherald.co.nz/nz/gulf-harbour-body-in-bag-update-in-homicide-investigation-reveals-new-details/ZQWKQF3VSRBAZHT4KV3UOJC6UA](https://www.nzherald.co.nz/nz/gulf-harbour-body-in-bag-update-in-homicide-investigation-reveals-new-details/ZQWKQF3VSRBAZHT4KV3UOJC6UA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T03:17:21+00:00

Police share details of woman's medical history, ethnicity and approximate age.

## NZ Rugby considers cuts amid unsustainable team numbers
 - [https://www.nzherald.co.nz/sport/the-number-of-professional-rugby-teams-in-new-zealand-is-unsustainable/FO7NYS7VTVEUJDAA5NNV55LC5I](https://www.nzherald.co.nz/sport/the-number-of-professional-rugby-teams-in-new-zealand-is-unsustainable/FO7NYS7VTVEUJDAA5NNV55LC5I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T03:05:58+00:00

NZ Rugby could be on the verge of major change as the financial reality begins to bite.

## Herald afternoon quiz: May 10
 - [https://www.nzherald.co.nz/nz/herald-afternoon-quiz-may-9/4KNYCBVQHBCHPPDXEZLYTECVZM](https://www.nzherald.co.nz/nz/herald-afternoon-quiz-may-9/4KNYCBVQHBCHPPDXEZLYTECVZM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T03:00:00+00:00

Test your knowledge with the Herald's afternoon quiz.

## Latest poll: Government steady, Labour up 4 per cent; Christopher Luxon’s favourability surges
 - [https://www.nzherald.co.nz/nz/politics/government-holds-on-in-latest-poll-christopher-luxons-favourability-surges/XNBVRE4KAJHFXBHGIU7CZ3XIEM](https://www.nzherald.co.nz/nz/politics/government-holds-on-in-latest-poll-christopher-luxons-favourability-surges/XNBVRE4KAJHFXBHGIU7CZ3XIEM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T02:08:06+00:00

Taxpayers Union-Curia Poll suggests the coalition would retain power in an election.

## Ponsonby shooting: Hone Kay-Selwyn funeral monitored by police as gang-heavy farewell expected
 - [https://www.nzherald.co.nz/nz/ponsonby-shooting-hone-kay-selwyn-funeral-monitored-by-police-as-gang-heavy-farewell-expected/6QHQUA3ACZEGZB7IU55FXINH6A](https://www.nzherald.co.nz/nz/ponsonby-shooting-hone-kay-selwyn-funeral-monitored-by-police-as-gang-heavy-farewell-expected/6QHQUA3ACZEGZB7IU55FXINH6A)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T01:37:15+00:00

Hone Kay-Selwyn's funeral is coming up and will likely be attended by gang members.

## Government releases documents behind decision to cancel Cook Strait mega ferries
 - [https://www.nzherald.co.nz/nz/government-releases-documents-behind-decision-to-cancel-cook-strait-mega-ferries/UF33UY3VQ5ELRI5ME37TTXD5HQ](https://www.nzherald.co.nz/nz/government-releases-documents-behind-decision-to-cancel-cook-strait-mega-ferries/UF33UY3VQ5ELRI5ME37TTXD5HQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T01:29:44+00:00

More details have been revealed about why Finance Minister Nicola Willis sunk the ferries.

## Hone Kay-Selwyn who fatally shot man on Ponsonby Rd deemed ‘low-risk’ by Corrections
 - [https://www.nzherald.co.nz/nz/hone-kay-selwyn-who-fatally-shot-man-on-ponsonby-rd-deemed-low-risk-by-corrections/P7BK5KUDAVADNHVU37ZZNKRBXY](https://www.nzherald.co.nz/nz/hone-kay-selwyn-who-fatally-shot-man-on-ponsonby-rd-deemed-low-risk-by-corrections/P7BK5KUDAVADNHVU37ZZNKRBXY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T00:41:54+00:00

Hone Kay-Selwyn shot a man but had been assessed as a low risk of reoffending.

## Jason Tuitama jailed for killing Cass Maguire in Wellington hit-and-run
 - [https://www.nzherald.co.nz/nz/jason-tuitama-jailed-for-killing-cass-maguire-in-wellington-hit-and-run/2BZ4BOCAJZBMHNYXBT5DFKFUSE](https://www.nzherald.co.nz/nz/jason-tuitama-jailed-for-killing-cass-maguire-in-wellington-hit-and-run/2BZ4BOCAJZBMHNYXBT5DFKFUSE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-05-10T00:40:20+00:00

Jason Tuitama struck two pedestrians, killing one, after speeding through red lights.

