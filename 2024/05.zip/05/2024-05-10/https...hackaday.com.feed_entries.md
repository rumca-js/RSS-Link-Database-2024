# Source:Hackaday, URL:https://hackaday.com/feed, language:en-US

## DIY Bimetallic Strip Dings for Teatime
 - [https://hackaday.com/2024/05/10/diy-bimetallic-strip-dings-for-teatime](https://hackaday.com/2024/05/10/diy-bimetallic-strip-dings-for-teatime)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T20:00:47+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="533" src="https://hackaday.com/wp-content/uploads/2024/05/building-a-bimetallic-tea-monitoring-mechanism-ojzy1vk2zyc-webm-shot0001_featured.png?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>Do you like your cup of tea to be cooled down to exactly 54 C, have a love for machining, and possess more than a little bit of a mad <a class="read-more" href="https://hackaday.com/2024/05/10/diy-bimetallic-strip-dings-for-teatime/">&#8230;read more</a>

## The 3D Printed Computer Space Takes Shape
 - [https://hackaday.com/2024/05/10/the-3d-printed-computer-space-takes-shape](https://hackaday.com/2024/05/10/the-3d-printed-computer-space-takes-shape)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T18:30:19+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="450" src="https://hackaday.com/wp-content/uploads/2024/05/computer-space-complete-featured.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>A few weeks ago we brought you news of a project to recreate the flowing lines of the first computerised arcade game, Computer Space, as a full-size 3D printed replica. <a class="read-more" href="https://hackaday.com/2024/05/10/the-3d-printed-computer-space-takes-shape/">&#8230;read more</a>

## Hackaday Podcast Episode 270: A Cluster of Microcontrollers, a rocket engine from scratch, and a look inside Voyager
 - [https://hackaday.com/2024/05/10/hackaday-podcast-episode-270-a-cluster-of-microcontrollers-a-rocket-engine-from-scratch-and-a-look-inside-voyager](https://hackaday.com/2024/05/10/hackaday-podcast-episode-270-a-cluster-of-microcontrollers-a-rocket-engine-from-scratch-and-a-look-inside-voyager)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T16:00:35+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="484" src="https://hackaday.com/wp-content/uploads/2016/05/microphone.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>Join Hackaday Editors Elliot Williams and Tom Nardi as they get excited over the pocket-sized possibilities of the recently announced 2024 Business Card Challenge, and once again discuss their picks <a class="read-more" href="https://hackaday.com/2024/05/10/hackaday-podcast-episode-270-a-cluster-of-microcontrollers-a-rocket-engine-from-scratch-and-a-look-inside-voyager/">&#8230;read more</a>

## Reflecting on The State Of Game Boy Emulation In 2024
 - [https://hackaday.com/2024/05/10/reflecting-on-the-state-of-game-boy-emulation-in-2024](https://hackaday.com/2024/05/10/reflecting-on-the-state-of-game-boy-emulation-in-2024)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T15:30:17+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="410" src="https://hackaday.com/wp-content/uploads/2024/05/gbemu24_feat.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>Considering the decades that have passed since Nintendo&#8217;s Game Boy was considered the state-of-the-art in mobile gaming, you&#8217;d imagine that the community would have pretty much perfected the emulation of <a class="read-more" href="https://hackaday.com/2024/05/10/reflecting-on-the-state-of-game-boy-emulation-in-2024/">&#8230;read more</a>

## This Week in Security: TunnelVision, Scarecrows, and Poutine
 - [https://hackaday.com/2024/05/10/this-week-in-security-tunnelvision-scarecrows-and-poutine](https://hackaday.com/2024/05/10/this-week-in-security-tunnelvision-scarecrows-and-poutine)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T14:00:13+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="484" src="https://hackaday.com/wp-content/uploads/2016/01/darkarts.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>There&#8217;s a clever &#8220;new&#8221; attack against VPNs, called TunnelVision, done by researchers at Leviathan Security. To explain why we put &#8220;new&#8221; in quotation marks, I&#8217;ll just share my note-to-self on <a class="read-more" href="https://hackaday.com/2024/05/10/this-week-in-security-tunnelvision-scarecrows-and-poutine/">&#8230;read more</a>

## This Typewriter Types Toast
 - [https://hackaday.com/2024/05/10/this-typewriter-types-toast](https://hackaday.com/2024/05/10/this-typewriter-types-toast)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T11:00:22+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="450" src="https://hackaday.com/wp-content/uploads/2024/05/toastwriter-featured.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>As a writer it&#8217;s a pleasure to see one&#8217;s work appear from time to time on a physical medium. While newspapers may be shuffling slowly off this mortal coil, there <a class="read-more" href="https://hackaday.com/2024/05/10/this-typewriter-types-toast/">&#8230;read more</a>

## DIY Keyboard Can Handle Up To Three Host Devices
 - [https://hackaday.com/2024/05/10/diy-keyboard-can-handle-up-to-three-host-devices](https://hackaday.com/2024/05/10/diy-keyboard-can-handle-up-to-three-host-devices)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T08:00:58+00:00

<div><img alt="A Planck-inspired 40% ortholinear keyboard." class="attachment-large size-large wp-post-image" height="320" src="https://hackaday.com/wp-content/uploads/2024/05/not-planck-800.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>Here&#8217;s a story that may be familiar: [der-b] is a Linux developer who is forced two carry two laptops &#8212; one for work with unavoidable work stuff on it, and <a class="read-more" href="https://hackaday.com/2024/05/10/diy-keyboard-can-handle-up-to-three-host-devices/">&#8230;read more</a>

## The ZX Spectrum Takes To The Airwaves Again
 - [https://hackaday.com/2024/05/09/the-zx-spectrum-takes-to-the-airwaves-again](https://hackaday.com/2024/05/09/the-zx-spectrum-takes-to-the-airwaves-again)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T05:00:01+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="450" src="https://hackaday.com/wp-content/uploads/2024/05/spectrum-broadcast-featured.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>A perk of writing for Hackaday comes in the vast breadth of experience represented by our fellow writers. Through our colleague [Voja Antonić] for example we&#8217;ve gained an unparalleled insight <a class="read-more" href="https://hackaday.com/2024/05/09/the-zx-spectrum-takes-to-the-airwaves-again/">&#8230;read more</a>

## An Audio Delay, The Garden Hose Way
 - [https://hackaday.com/2024/05/09/an-audio-delay-the-garden-hose-way](https://hackaday.com/2024/05/09/an-audio-delay-the-garden-hose-way)
 - RSS feed: https://hackaday.com/feed
 - date published: 2024-05-10T02:00:50+00:00

<div><img alt="" class="attachment-large size-large wp-post-image" height="450" src="https://hackaday.com/wp-content/uploads/2024/05/hose-delay-featured.jpg?w=800" style="margin: 0 auto; margin-bottom: 15px;" width="800" /></div>Creating music in 2024 is made easier by ready access to a host of effects in software that were once the preserve only of professional studios. One such is the <a class="read-more" href="https://hackaday.com/2024/05/09/an-audio-delay-the-garden-hose-way/">&#8230;read more</a>

