# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## Expensive Hobby Tools That Aren't WORTH IT?
 - [https://www.youtube.com/watch?v=1UfDJ2i4izU](https://www.youtube.com/watch?v=1UfDJ2i4izU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2024-05-10T07:00:03+00:00

I've bought some kind of expensive hobby tools over the years. Are they worth it? Some CERTAINLY aren't.

The Amazon store with stuff from this video: https://www.amazon.com/shop/tabletopminions/list/16X66NHBWN5V7?ref_=cm_sw_r_cp_ud_aipsflist_aipsftabletopminions_1HN983YJR1JN3876JK20

Vince Venturella and I made a 'zine! Check out SNARL at http://www.snarlingbadger.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

