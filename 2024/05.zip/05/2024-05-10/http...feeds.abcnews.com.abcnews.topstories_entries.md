# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## 3 big takeaways from Day 15 of Trump's hush money trial
 - [https://abcnews.go.com/US/3-big-takeaways-day-15-trumps-hush-money/story?id=110103306](https://abcnews.go.com/US/3-big-takeaways-day-15-trumps-hush-money/story?id=110103306)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T19:55:43+00:00

A series of custodial witnesses introduced evidence Friday to set the stage for Michael Cohen's upcoming testimony in former President Trump's hush money trial.

## VA improperly approved almost $11M in bonuses to senior executives, watchdog says
 - [https://abcnews.go.com/Politics/va-improperly-approved-11m-bonuses-senior-executives-watchdog/story?id=110081569](https://abcnews.go.com/Politics/va-improperly-approved-11m-bonuses-senior-executives-watchdog/story?id=110081569)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T19:07:44+00:00

Some have challenged having to pay the money back, an inspector general said.

## WATCH:  Brother drives 17 hours to surprise sister at her nursing school graduation
 - [https://abcnews.go.com/GMA/Family/video/brother-drives-17-hours-surprise-sister-nursing-school-110113582](https://abcnews.go.com/GMA/Family/video/brother-drives-17-hours-surprise-sister-nursing-school-110113582)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T18:47:05+00:00

Kylei Gray received the surprise of a lifetime when her younger brother traveled from Florida to Indiana to be at her nursing school graduation ceremony.

## Former Miss USA 2023 alleges toxic work environment in resignation letter
 - [https://abcnews.go.com/GMA/Culture/former-miss-usa-2023-alleges-toxic-work-environment/story?id=110103496](https://abcnews.go.com/GMA/Culture/former-miss-usa-2023-alleges-toxic-work-environment/story?id=110103496)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T17:39:30+00:00

Former Miss USA 2023 Noelia Voigt claimed in her resignation letter this week that the Miss USA organization and its president cultivated a toxic work environment.

## Oakland officially adds 'San Francisco Bay' to airport name despite legal challenge
 - [https://abcnews.go.com/US/oakland-airport-name-change-san-francisco-lawsuit/story?id=110108037](https://abcnews.go.com/US/oakland-airport-name-change-san-francisco-lawsuit/story?id=110108037)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T17:32:58+00:00

The Oakland Board of Port Commissioners unanimously voted to rename Metropolitan Oakland International Airport to San Francisco Bay Oakland International Airport.

## Search crews uncover bodies of 2 skiers buried by Utah avalanche
 - [https://abcnews.go.com/US/wireStory/search-crews-uncover-bodies-2-skiers-buried-utah-110108731](https://abcnews.go.com/US/wireStory/search-crews-uncover-bodies-2-skiers-buried-utah-110108731)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T16:38:20+00:00

Search crews have recovered the bodies of two backcountry skiers who were swept away and buried by an avalanche in the mountains outside Salt Lake City

## Liam, Olivia are still the most popular US baby names; Mateo makes debut on the list
 - [https://abcnews.go.com/US/wireStory/liam-olivia-popular-us-baby-names-mateo-makes-110107965](https://abcnews.go.com/US/wireStory/liam-olivia-popular-us-baby-names-mateo-makes-110107965)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T16:06:29+00:00

Liam and Olivia have for the fifth year topped the list of top baby names for brand new boys and girls in the U.S., according to the Social Security Administration

## Police prevent environmental activists from storming Tesla factory in Germany
 - [https://abcnews.go.com/International/wireStory/police-prevent-environmental-activists-storming-tesla-factory-germany-110108132](https://abcnews.go.com/International/wireStory/police-prevent-environmental-activists-storming-tesla-factory-germany-110108132)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T15:39:27+00:00

German police say they have prevented hundreds of demonstrators from storming Tesla&rsquo;s factory near Berlin during protests against the pioneering electric car maker over its environmental footprint

## Steve Bannon's contempt of Congress conviction upheld by appeals court
 - [https://abcnews.go.com/Politics/steve-bannons-contempt-congress-conviction-upheld-appeals-court/story?id=110107409](https://abcnews.go.com/Politics/steve-bannons-contempt-congress-conviction-upheld-appeals-court/story?id=110107409)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T15:35:00+00:00

A federal appeals court upheld the criminal conviction of Steve Bannon for defying a subpoena from the House select committee investigating the Jan. 6 attack.

## US consumer sentiment drops to 6-month low on inflation, unemployment fears
 - [https://abcnews.go.com/US/wireStory/us-consumer-sentiment-drops-6-month-low-inflation-110105693](https://abcnews.go.com/US/wireStory/us-consumer-sentiment-drops-6-month-low-inflation-110105693)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T15:33:22+00:00

Consumer sentiment fell sharply in May to the lowest level in six months as Americans cited concerns about stubbornly high inflation and interest rates and fears that unemployment could rise

## Prince Harry, Meghan Markle visit Nigeria, share mental health message with kids
 - [https://abcnews.go.com/GMA/Culture/prince-harry-meghan-markle-travel-nigeria/story?id=110077911](https://abcnews.go.com/GMA/Culture/prince-harry-meghan-markle-travel-nigeria/story?id=110077911)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T13:48:50+00:00

Harry and Meghan are spending three days in Nigeria.

## Australian judge extends ban on X sharing video of Sydney bishop's stabbing
 - [https://abcnews.go.com/International/wireStory/australian-judge-extends-ban-sharing-video-sydney-bishops-110100119](https://abcnews.go.com/International/wireStory/australian-judge-extends-ban-sharing-video-sydney-bishops-110100119)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T12:49:07+00:00

An Australian judge has extended a ban on social media platform X allowing videos of the stabbing of a Sydney bishop in his church last month after government lawyers condemned the company's free speech argument for keeping the graphic images circulating

## Target will only sell Pride Month collection in some stores after backlash in 2023
 - [https://abcnews.go.com/US/target-sell-pride-month-collection-stores-after-backlash/story?id=110101112](https://abcnews.go.com/US/target-sell-pride-month-collection-stores-after-backlash/story?id=110101112)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T12:16:20+00:00

Target has announced that it will only sell their Pride Month collection in select stores after suffering a backlash and boycott last year during the 2023 Pride season.

## WATCH:  Breakthrough helps deaf baby hear for the first time
 - [https://abcnews.go.com/WNN/video/breakthrough-helps-deaf-baby-hear-time-110099637](https://abcnews.go.com/WNN/video/breakthrough-helps-deaf-baby-hear-time-110099637)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T11:39:31+00:00

An 18-month-old has become the first person to successfully undergo a new form of gene therapy. ABC News' Andrea Fujii explains.

## At least 105 tornadoes reported across the country since Monday
 - [https://abcnews.go.com/US/105-tornadoes-reported-country-monday/story?id=110099630](https://abcnews.go.com/US/105-tornadoes-reported-country-monday/story?id=110099630)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T11:09:57+00:00

There have been at least 105 reported tornadoes reported across the country since Monday.

## Pope urges Italians to have babies as a measure of hope for future
 - [https://abcnews.go.com/International/wireStory/pope-urges-italians-babies-measure-hope-future-110098340](https://abcnews.go.com/International/wireStory/pope-urges-italians-babies-measure-hope-future-110098340)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T09:47:54+00:00

Pope Francis has pressed his campaign to urge Italians to have children

## Prince Harry, Meghan arrive in Nigeria to champion the Invictus Games
 - [https://abcnews.go.com/Entertainment/wireStory/prince-harry-meghan-arrive-nigeria-invictus-games-meet-110097991](https://abcnews.go.com/Entertainment/wireStory/prince-harry-meghan-arrive-nigeria-invictus-games-meet-110097991)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T09:02:38+00:00

Prince Harry and his wife Meghan have arrived in Nigeria to champion the Invictus Games, which he founded to aid the rehabilitation of wounded and sick servicemembers and veterans

## Hopes fading for 44 workers still missing days after South Africa building collapse
 - [https://abcnews.go.com/International/wireStory/hopes-fading-44-workers-missing-days-after-south-110098081](https://abcnews.go.com/International/wireStory/hopes-fading-44-workers-missing-days-after-south-110098081)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T09:02:33+00:00

Hopes are fading for 44 construction workers buried for days in the rubble of a building that collapsed in South Africa

## Air Vanuatu files for bankruptcy protection after canceling more than 20 flights
 - [https://abcnews.go.com/International/wireStory/air-vanuatu-files-bankruptcy-protection-after-canceling-20-110093132](https://abcnews.go.com/International/wireStory/air-vanuatu-files-bankruptcy-protection-after-canceling-20-110093132)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T02:31:17+00:00

Air Vanuatu has filed for bankruptcy protection a day after the South Pacific state-owned carrier cancelled all international flights

## Seattle to open short-term recovery center for people after a fentanyl overdose
 - [https://abcnews.go.com/Health/wireStory/seattle-open-short-term-recovery-center-people-after-110093309](https://abcnews.go.com/Health/wireStory/seattle-open-short-term-recovery-center-people-after-110093309)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T02:30:05+00:00

Seattle Mayor Bruce Harrell says the city will open a new space for people to recover and receive treatment for nearly 24 hours after they have overdosed on fentanyl or other drugs

## WATCH:  Horse rescued after being stranded on rooftop amid flooding in Brazil
 - [https://abcnews.go.com/International/video/horse-rescued-after-stranded-rooftop-amid-flooding-brazil-110093311](https://abcnews.go.com/International/video/horse-rescued-after-stranded-rooftop-amid-flooding-brazil-110093311)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-05-10T00:58:27+00:00

A Brazilian horse that garnered widespread attention after a TV news helicopter spotted it stranded on a rooftop has been rescued, officials say.

