# Source:The Washington Post - World, URL:https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36, language:en-US

## Battles rage around Rafah’s edge as more than 100,000 flee the city
 - [https://www.washingtonpost.com/world/2024/05/10/israel-rafah-gaza-hamas-displaced](https://www.washingtonpost.com/world/2024/05/10/israel-rafah-gaza-hamas-displaced)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-05-10T18:27:13+00:00

Medics and journalists were unable to reach the area, making it difficult to assess the nature and intensity of the fighting.

## Sweden celebrates ABBA at this year’s Eurovision Song Contest
 - [https://www.washingtonpost.com/entertainment/music/2024/05/10/abba-anniversary-eurovision-waterloo](https://www.washingtonpost.com/entertainment/music/2024/05/10/abba-anniversary-eurovision-waterloo)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-05-10T16:01:27+00:00

Malmö, Sweden, is playing homage to ABBA’s 1974 win as the southern Swedish city hosts the Eurovision Song Contest.

## Biden’s weapons sales to Israel breach legal limits, former officials say
 - [https://www.washingtonpost.com/world/2024/05/10/israel-gaza-biden-weapons-rafah](https://www.washingtonpost.com/world/2024/05/10/israel-gaza-biden-weapons-rafah)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-05-10T10:00:35+00:00

While the administration has expressed alarm over civilian casualties in Gaza, former officials say it has side-stepped laws governing foreign arms transfers.

## China’s latest wellness trend? Marathons. But good luck getting a spot.
 - [https://www.washingtonpost.com/world/2024/05/10/china-beijing-marathon-running-olympics](https://www.washingtonpost.com/world/2024/05/10/china-beijing-marathon-running-olympics)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-05-10T09:00:24+00:00

It’s now almost impossible to get into the big running races, so smaller cities are coming up with inventive ways to attract athletes — and their cash.

## Middle East conflict live updates: Cease-fire talks stall; Netanyahu says Israel can fight solo
 - [https://www.washingtonpost.com/world/2024/05/10/israel-hamas-war-news-gaza-palestine](https://www.washingtonpost.com/world/2024/05/10/israel-hamas-war-news-gaza-palestine)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-05-10T06:06:35+00:00

Prime Minister Benjamin Netanyahu said Israel is ready to “stand alone” against its enemies after President Biden warned that the U.S. could cut military aid.

## China’s Xi wades into Europe’s political divides
 - [https://www.washingtonpost.com/world/2024/05/10/xi-jinping-europe-france-serbia-hungary](https://www.washingtonpost.com/world/2024/05/10/xi-jinping-europe-france-serbia-hungary)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-05-10T04:00:22+00:00

Xi Jinping’s three chosen stops in Europe reveal much about the global state of play.

