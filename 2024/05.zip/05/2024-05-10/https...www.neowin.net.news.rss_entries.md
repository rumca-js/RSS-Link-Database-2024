# Source:Neowin, URL:https://www.neowin.net/news/rss, language:en-us

## Microsoft president is requested to attend a US House hearing on recent security breaches
 - [https://www.neowin.net/news/microsoft-president-is-requested-to-attend-a-us-house-hearing-on-recent-security-breaches](https://www.neowin.net/news/microsoft-president-is-requested-to-attend-a-us-house-hearing-on-recent-security-breaches)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T19:18:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2015/12/brad_smith2_medium.jpg" /></div>Microsoft President Brad Smith has been asked by the US House Committee on Homeland Security to attend a hearing on May 22 to answer questions about the company&#039;s recent security breaches. <a href="https://www.neowin.net/news/microsoft-president-is-requested-to-attend-a-us-house-hearing-on-recent-security-breaches/">Read more...</a>

## 3-2-1: Save up to 66% on Windscribe VPN Pro Year Plans
 - [https://www.neowin.net/deals/3-2-1-save-up-to-66-on-windscribe-vpn-pro-year-plans](https://www.neowin.net/deals/3-2-1-save-up-to-66-on-windscribe-vpn-pro-year-plans)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T19:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/04/1523446954_snag-0002_medium.jpg" /></div>With today&#039;s highlighted deal, you can pick up a 1, 2, 3 or 4-year subscription to Windscribe VPN on the cheap. Hello, private browsing! Protect your browser and desktop with this complete Pro VPN! <a href="https://www.neowin.net/deals/3-2-1-save-up-to-66-on-windscribe-vpn-pro-year-plans/">Read more...</a>

## OpenAI confirms 'Spring Updates' event for some ChatGPT and GPT-4 updates
 - [https://www.neowin.net/news/openai-confirms-spring-updates-event-for-some-chatgpt-and-gpt-4-updates](https://www.neowin.net/news/openai-confirms-spring-updates-event-for-some-chatgpt-and-gpt-4-updates)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T18:42:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1700287670_openai-logo_medium.jpg" /></div>OpenAI has announced a new Spring Updates event, where it will talk about new features and changes coming to ChatGPT and GPT-4. The event is also expected to unveil OpenAI&#039;s search engine. <a href="https://www.neowin.net/news/openai-confirms-spring-updates-event-for-some-chatgpt-and-gpt-4-updates/">Read more...</a>

## Apple iPad Pro's M4 chip is the new Geekbench single-core performance king
 - [https://www.neowin.net/news/apple-ipad-pros-m4-chip-is-the-new-geekbench-single-core-performance-king](https://www.neowin.net/news/apple-ipad-pros-m4-chip-is-the-new-geekbench-single-core-performance-king)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T18:12:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715093771_apple-ipad-pro-silver-2-up-240507_medium.jpg" /></div>The latest Geekbench scores of the M4 chipset powering the latest Apple iPad Pro have surfaced online, claiming the top spot and suggesting a 25% jump compared to the previous generation SoC. <a href="https://www.neowin.net/news/apple-ipad-pros-m4-chip-is-the-new-geekbench-single-core-performance-king/">Read more...</a>

## be quiet! Straight Power 12 ATX 3.0 power supplies are down to their lowest prices ever
 - [https://www.neowin.net/deals/be-quiet-straight-power-12-atx-30-power-supplies-are-down-to-their-lowest-prices-ever](https://www.neowin.net/deals/be-quiet-straight-power-12-atx-30-power-supplies-are-down-to-their-lowest-prices-ever)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T17:56:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/04/1712913842_be_quiet_straight_power_12_medium.jpg" /></div>If you are building a new PC or upgrading one with a better PSU and you need one that is compatible with Nvidia&#039;s graphics cards, check out these awesome deals on be quiet!&#039;s ATX 3.0 power supplies. <a href="https://www.neowin.net/deals/be-quiet-straight-power-12-atx-30-power-supplies-are-down-to-their-lowest-prices-ever/">Read more...</a>

## Microsoft adds a better way to add polls in emails for Outlook on the web
 - [https://www.neowin.net/news/microsoft-adds-a-better-way-to-add-polls-in-emails-for-outlook-on-the-web](https://www.neowin.net/news/microsoft-adds-a-better-way-to-add-polls-in-emails-for-outlook-on-the-web)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T17:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/07/1594835886_outlook_red_medium.jpg" /></div>Microsoft has announced it has improved the experience of adding a poll inside an email for users of Outlook on the web so users won&#039;t have to switch between the main email body and the side panel. <a href="https://www.neowin.net/news/microsoft-adds-a-better-way-to-add-polls-in-emails-for-outlook-on-the-web/">Read more...</a>

## KB5037864: Microsoft fixes a Windows 11 Modern Standby bug and more with build 26120.470
 - [https://www.neowin.net/news/kb5037864-microsoft-fixes-a-windows-11-modern-standby-bug-and-more-with-build-26120470](https://www.neowin.net/news/kb5037864-microsoft-fixes-a-windows-11-modern-standby-bug-and-more-with-build-26120470)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T17:24:16+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701731558_windows_11_insider_preview_promo_15_medium.jpg" /></div>Microsoft has released the latest Windows 11 update for members flighting the Insider Program in the Dev Channel. This new build, 26120.470, (KB5037864) adds several new features and improvements. <a href="https://www.neowin.net/news/kb5037864-microsoft-fixes-a-windows-11-modern-standby-bug-and-more-with-build-26120470/">Read more...</a>

## Windows 11 Beta Channel Insiders can copy files from the share window with KB5037862
 - [https://www.neowin.net/news/windows-11-beta-channel-insiders-can-copy-files-from-the-share-window-with-build-226353575](https://www.neowin.net/news/windows-11-beta-channel-insiders-can-copy-files-from-the-share-window-with-build-226353575)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T17:15:43+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1680966844_windows_11_insider_preview_promo_16_medium.jpg" /></div>Microsoft has released the latest Windows 11 build for members of the Insider Program in the Beta Channel. The 22635.3575 build has added a way for people to copy files from the share window. <a href="https://www.neowin.net/news/windows-11-beta-channel-insiders-can-copy-files-from-the-share-window-with-build-226353575/">Read more...</a>

## PowerShell 7 Workshop ($35.99 Value) eBook, now free
 - [https://www.neowin.net/sponsored/powershell-7-workshop-3599-value-ebook-now-free](https://www.neowin.net/sponsored/powershell-7-workshop-3599-value-ebook-now-free)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715333982_w_pacb208c82_medium.jpg" /></div>By the end of this book, you&#039;ll have the confidence to use PowerShell for physical computing and writing scripts for Windows administration. Claim it for free today before the offer expires. <a href="https://www.neowin.net/sponsored/powershell-7-workshop-3599-value-ebook-now-free/">Read more...</a>

## Latest Apple 15" 2024 MacBook Air (M3 version) is already at its lowest price
 - [https://www.neowin.net/deals/latest-apple-15-2024-macbook-air-m3-version-is-already-at-its-lowest-price](https://www.neowin.net/deals/latest-apple-15-2024-macbook-air-m3-version-is-already-at-its-lowest-price)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T16:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/03/1709558696_m3_macbook_air_1_medium.jpg" /></div>It has been just over a couple of months since Apple released its M3-powered MacBook Air 2024 edition. However, the 15-inch variant of the same is already on sale at its lowest price. <a href="https://www.neowin.net/deals/latest-apple-15-2024-macbook-air-m3-version-is-already-at-its-lowest-price/">Read more...</a>

## Google's message editing feature is reportedly available to some users
 - [https://www.neowin.net/news/googles-message-editing-feature-is-reportedly-available-to-some-users](https://www.neowin.net/news/googles-message-editing-feature-is-reportedly-available-to-some-users)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T16:18:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/05/1683368431_screenshot_2023-05-06_161147-transformed_medium.jpg" /></div>Google has started testing its message editing feature for Google Messages with some users in beta. The feature has reportedly been in development at least since December last year. <a href="https://www.neowin.net/news/googles-message-editing-feature-is-reportedly-available-to-some-users/">Read more...</a>

## Skype Insider gets another big update with new features and improvements for PC and mobile
 - [https://www.neowin.net/news/skype-insider-gets-another-big-update-with-new-features-and-improvements-for-pc-and-mobile](https://www.neowin.net/news/skype-insider-gets-another-big-update-with-new-features-and-improvements-for-pc-and-mobile)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T16:02:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1692366496_skype_preview_medium.jpg" /></div>Skype Insider 8.119 is now available for testing on mobile devices and computers. The release adds a new call panel UI on mobile, a PiP call monitor on iOS, simplified audio device controls, and more. <a href="https://www.neowin.net/news/skype-insider-gets-another-big-update-with-new-features-and-improvements-for-pc-and-mobile/">Read more...</a>

## iOS 18 reported to include AI transcription and summarising
 - [https://www.neowin.net/news/ios-18-reported-to-include-ai-transcription-and-summarising](https://www.neowin.net/news/ios-18-reported-to-include-ai-transcription-and-summarising)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T15:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/04/1713190031_ios-18-image_medium.jpg" /></div>Given the recent news around AI and the benefits that Apple&#039;s latest M4 chip can provide, it comes as no surprise that reports are surfacing that iOS 18 will include AI transcription and summarising. <a href="https://www.neowin.net/news/ios-18-reported-to-include-ai-transcription-and-summarising/">Read more...</a>

## Report says Sony will announce God of War Ragnarök for PC very soon
 - [https://www.neowin.net/news/report-says-sony-will-announce-god-of-war-ragnark-for-pc-very-soon](https://www.neowin.net/news/report-says-sony-will-announce-god-of-war-ragnark-for-pc-very-soon)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T15:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/12/1639162830_god_of_war_medium.jpg" /></div>Sony may be about to announce God of War Ragnarök for the PC platform according to a report from a highly reliable leaker. The action-adventure game released less than two years ago on PlayStation. <a href="https://www.neowin.net/news/report-says-sony-will-announce-god-of-war-ragnark-for-pc-very-soon/">Read more...</a>

## Corsair launches MP700 PRO SE PCIe Gen 5 SSD with an optional water block
 - [https://www.neowin.net/news/corsair-launches-mp700-pro-se-pcie-gen-5-ssd-with-an-optional-water-block](https://www.neowin.net/news/corsair-launches-mp700-pro-se-pcie-gen-5-ssd-with-an-optional-water-block)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T14:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715352256_mp700_pro_se_1_medium.jpg" /></div>Corsair has announced a new high-end SSD in its portfolio. The MP700 PRO SE PCIe Gen 5 drive is available in 2TB and 4TB configurations with an optional water block to keep temps under control. <a href="https://www.neowin.net/news/corsair-launches-mp700-pro-se-pcie-gen-5-ssd-with-an-optional-water-block/">Read more...</a>

## Microsoft Xbox President Sarah Bond tries to justify this week's studio shutdowns
 - [https://www.neowin.net/news/microsoft-xbox-president-sarah-bond-tries-to-justify-this-weeks-studio-shutdowns](https://www.neowin.net/news/microsoft-xbox-president-sarah-bond-tries-to-justify-this-weeks-studio-shutdowns)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T14:08:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715009569_wide_medium.jpg" /></div>Microsoft Xbox President Sarah Bond stated that the decision this week to close a number of its game development studios was made to make sure &quot;the business is healthy for the long term.&quot; <a href="https://www.neowin.net/news/microsoft-xbox-president-sarah-bond-tries-to-justify-this-weeks-studio-shutdowns/">Read more...</a>

## Samsung rolls out One UI 6.1 with Galaxy AI baked in to older Galaxy phones
 - [https://www.neowin.net/news/samsung-rolls-out-one-ui-61-with-galaxy-ai-baked-in-to-older-galaxy-phones](https://www.neowin.net/news/samsung-rolls-out-one-ui-61-with-galaxy-ai-baked-in-to-older-galaxy-phones)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T13:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1708591615_galaxy-experience-space-open_dl1_medium.jpg" /></div>Samsung is releasing One UI 6.1 to older devices in the US, which will enable them to use a plethora of Galaxy AI features, including Circle to Search with Google and translation features. <a href="https://www.neowin.net/news/samsung-rolls-out-one-ui-61-with-galaxy-ai-baked-in-to-older-galaxy-phones/">Read more...</a>

## Grab this Asus TUF Gaming Nvidia GeForce RTX 4070 SUPER graphics card at its lowest price
 - [https://www.neowin.net/deals/grab-this-asus-tuf-gaming-nvidia-geforce-rtx-4070-super-graphics-card-at-its-lowest-price](https://www.neowin.net/deals/grab-this-asus-tuf-gaming-nvidia-geforce-rtx-4070-super-graphics-card-at-its-lowest-price)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T13:18:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715345009_asus-tuf-graphics-card_medium.jpg" /></div>The Asus TUF Gaming Nvidia GeForce RTX 4070 SUPER graphics card with 12GB of video RAM and core clocks of up to 2,595 MHz is currently available at its all-time low price of $659.99. <a href="https://www.neowin.net/deals/grab-this-asus-tuf-gaming-nvidia-geforce-rtx-4070-super-graphics-card-at-its-lowest-price/">Read more...</a>

## Fresh leaks show how the camera module on the alleged OnePlus 13 and 13R could look
 - [https://www.neowin.net/news/fresh-leaks-show-how-the-camera-module-on-the-alleged-oneplus-13-and-13r-could-look](https://www.neowin.net/news/fresh-leaks-show-how-the-camera-module-on-the-alleged-oneplus-13-and-13r-could-look)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T12:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715343127_oneplus-12-hero_medium.jpg" /></div>The latest leak shows off the camera module of the alleged OnePlus 13 and 13R, suggesting that OnePlus could go the OPPO way and make some shifts to the camera module on their phones. <a href="https://www.neowin.net/news/fresh-leaks-show-how-the-camera-module-on-the-alleged-oneplus-13-and-13r-could-look/">Read more...</a>

## Turn 10 promises significant multiplayer changes and more content for Forza Motorsport
 - [https://www.neowin.net/news/turn-10-promises-significant-multiplayer-changes-and-more-content-for-forza-motorsport](https://www.neowin.net/news/turn-10-promises-significant-multiplayer-changes-and-more-content-for-forza-motorsport)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T11:30:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715339451_forza_motorsport_medium.jpg" /></div>Turn 10 Studios published a message to the community with details about future updates for the ill-fated Forza Motorsport. Players can look out for more content and significant multiplayer updates. <a href="https://www.neowin.net/news/turn-10-promises-significant-multiplayer-changes-and-more-content-for-forza-motorsport/">Read more...</a>

## Beyond expectations: Groundbreaking gene therapy fully restores hearing in deaf UK toddler
 - [https://www.neowin.net/news/beyond-expectations-groundbreaking-gene-therapy-fully-restores-hearing-in-deaf-uk-toddler](https://www.neowin.net/news/beyond-expectations-groundbreaking-gene-therapy-fully-restores-hearing-in-deaf-uk-toddler)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T07:20:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715324090_deaf_toddler_medium.jpg" /></div>Science and technology have enabled hearing restoration for an 18-month-old toddler who previously couldn&#039;t hear a thing. His nearly perfect hearing now serves as a hope for many more children. <a href="https://www.neowin.net/news/beyond-expectations-groundbreaking-gene-therapy-fully-restores-hearing-in-deaf-uk-toddler/">Read more...</a>

## Apple reportedly inks a deal with Samsung to supply displays for its foldable devices
 - [https://www.neowin.net/news/apple-reportedly-inks-a-deal-with-samsung-to-supply-displays-for-its-foldable-devices](https://www.neowin.net/news/apple-reportedly-inks-a-deal-with-samsung-to-supply-displays-for-its-foldable-devices)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T06:56:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/11/1667977109_screenshot_2022-11-09_144019_medium.jpg" /></div>Apple has reportedly signed an agreement with Samsung Display to supply displays for Apple&#039;s foldable devices. Apple is rumored to debut its first foldable device, most likely an iPhone, in late 2026. <a href="https://www.neowin.net/news/apple-reportedly-inks-a-deal-with-samsung-to-supply-displays-for-its-foldable-devices/">Read more...</a>

## Apple's AI features will reportedly be powered by in-house silicon on cloud
 - [https://www.neowin.net/news/apples-ai-features-will-reportedly-be-powered-by-in-house-silicon-on-cloud](https://www.neowin.net/news/apples-ai-features-will-reportedly-be-powered-by-in-house-silicon-on-cloud)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T06:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/03/1646764275_screenshot_(83)_medium.jpg" /></div>Apple will be using its own silicon processors to power the upcoming AI features on the iPhone, iPad, and Mac devices. The company will use the M2 Ultra chips in its data centers for the operation.  <a href="https://www.neowin.net/news/apples-ai-features-will-reportedly-be-powered-by-in-house-silicon-on-cloud/">Read more...</a>

## Display output support over USB-C coming to the Google Pixel 8a with the next update
 - [https://www.neowin.net/news/display-output-support-over-usb-c-coming-to-the-google-pixel-8a-with-the-next-update](https://www.neowin.net/news/display-output-support-over-usb-c-coming-to-the-google-pixel-8a-with-the-next-update)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T05:42:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715316681_google-pixel-8a-official-hero_medium.jpg" /></div>The next update for the recently launched Google Pixel 8a is going to be big, as it will bring the display output over USB-C support for the mid-ranger. It will also come for the Pixel 8 and 8 Pro. <a href="https://www.neowin.net/news/display-output-support-over-usb-c-coming-to-the-google-pixel-8a-with-the-next-update/">Read more...</a>

## OpenAI will reportedly reveal its AI-based search engine on Monday, May 13
 - [https://www.neowin.net/news/openai-will-reportedly-reveal-its-ai-based-search-engine-on-monday-may-13](https://www.neowin.net/news/openai-will-reportedly-reveal-its-ai-based-search-engine-on-monday-may-13)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T02:14:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/01/1609914495_openai-cover_medium.jpg" /></div>OpenAI reportedly has plans to reveal a generative AI search engine on Monday, May 13. If true, the reveal will come one day before search leader Google holds its annual I/O developers conference <a href="https://www.neowin.net/news/openai-will-reportedly-reveal-its-ai-based-search-engine-on-monday-may-13/">Read more...</a>

## Microsoft will launch its long awaited mobile game store in July via the web
 - [https://www.neowin.net/news/microsoft-will-launch-its-long-awaited-mobile-game-store-in-july-via-the-web](https://www.neowin.net/news/microsoft-will-launch-its-long-awaited-mobile-game-store-in-july-via-the-web)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T00:52:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/02/1614515293_gamingnews_medium.jpg" /></div>Microsoft Xbox President Sarah Bond has confirmed that its long-in-development mobile game store will officially launch sometime in July, initially as a web-based store so it can reach more people. <a href="https://www.neowin.net/news/microsoft-will-launch-its-long-awaited-mobile-game-store-in-july-via-the-web/">Read more...</a>

## Google's Find My Device network reportedly expanding outside US and Canada
 - [https://www.neowin.net/news/googles-find-my-device-network-reportedly-expanding-outside-us-and-canada](https://www.neowin.net/news/googles-find-my-device-network-reportedly-expanding-outside-us-and-canada)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-05-10T00:14:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/04/1712644204_google_find_my_device_android_phones_medium.jpg" /></div>Google is reportedly stretching its Find My Device network outside the US and Canada. Users from Japan and the UK posted on social media that they received the opt-in message to join the network. <a href="https://www.neowin.net/news/googles-find-my-device-network-reportedly-expanding-outside-us-and-canada/">Read more...</a>

