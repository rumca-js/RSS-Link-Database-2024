# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## There Is a Nuclear Reactor in This Truck
 - [https://www.youtube.com/watch?v=ONGhezxScmw](https://www.youtube.com/watch?v=ONGhezxScmw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-05-10T16:59:00+00:00

In the most recent podcast with nuclear physicist James Walker, he and Dr. Peterson discuss the incredible technology shrinking nuclear reactors to the size of a semi truck.

Watch the full episode here: https://youtu.be/Rndu2PYx0Sc

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8

Ep.447


// COURSES //
Discovering Personality: https://jordanbpeterson.com/personality
Self Authoring Suite: https://selfauthoring.com
Understand Myself (personality test): https://understandmyself.com

// BOOKS //
Beyond Order: 12 More Rules for Life: https://jordanbpeterson.com/Beyond-Order
12 Rules for Life: An Antidote to Chaos: https://jordanbpeterson.com/12-rules-for-life
Maps of Meaning: The Architecture of Belief: https://jordanbpeterson.com/maps-of-meaning

#JordanPeterson #JordanBPeterson #DrJordanPeterson #DrJordanBPeterson #DailyWirePlus

