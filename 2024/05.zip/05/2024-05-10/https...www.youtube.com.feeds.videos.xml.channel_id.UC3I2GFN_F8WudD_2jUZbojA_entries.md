# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## 📺 Dublin's garage punk four-piece SPRINTS Live on KEXP
 - [https://www.youtube.com/watch?v=MFk4_5E7rrk](https://www.youtube.com/watch?v=MFk4_5E7rrk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-10T18:14:19+00:00



## SPRINTS - Full Performance (live on KEXP)
 - [https://www.youtube.com/watch?v=6FtN3HV1voM](https://www.youtube.com/watch?v=6FtN3HV1voM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-10T15:00:09+00:00

http://KEXP.ORG presents SPRINTS performing live in the KEXP studio. Recorded March 6, 2024

Songs:
Heavy
Cathedral
Up And Comer
Literary Mind

Karla Chubb - Vocals, Guitar
Colm O’Reilly - Guitar
Sam McCann - Bass, Vocals
Jack Callan - Drums

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht, Scott Holpainen
Editor: Jim Beckmann

https://www.sprintsmusic.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## SPRINTS - Cathedral (Live on KEXP)
 - [https://www.youtube.com/watch?v=tO1-0kWIVWM](https://www.youtube.com/watch?v=tO1-0kWIVWM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-10T11:00:47+00:00

http://KEXP.ORG presents SPRINTS performing “Cathedral” live in the KEXP studio. Recorded March 6, 2024

Karla Chubb - Vocals, Guitar
Colm O’Reilly - Guitar
Sam McCann - Bass, Vocals
Jack Callan - Drums

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht, Scott Holpainen
Editor: Jim Beckmann

https://www.sprintsmusic.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## SPRINTS - Literary Mind (Live on KEXP)
 - [https://www.youtube.com/watch?v=on4rEl1-V_4](https://www.youtube.com/watch?v=on4rEl1-V_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-10T11:00:46+00:00

http://KEXP.ORG presents SPRINTS performing “Literary Mind” live in the KEXP studio. Recorded March 6, 2024

Karla Chubb - Vocals, Guitar
Colm O’Reilly - Guitar
Sam McCann - Bass, Vocals
Jack Callan - Drums

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht, Scott Holpainen
Editor: Jim Beckmann

https://www.sprintsmusic.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## SPRINTS - Heavy (Live on KEXP)
 - [https://www.youtube.com/watch?v=WYcZJ6x4TO8](https://www.youtube.com/watch?v=WYcZJ6x4TO8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-10T11:00:33+00:00

http://KEXP.ORG presents SPRINTS performing “Heavy” live in the KEXP studio. Recorded March 6, 2024

Karla Chubb - Vocals, Guitar
Colm O’Reilly - Guitar
Sam McCann - Bass, Vocals
Jack Callan - Drums

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht, Scott Holpainen
Editor: Jim Beckmann

https://www.sprintsmusic.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## SPRINTS - Up And Comer (Live on KEXP)
 - [https://www.youtube.com/watch?v=PUoTORjmfQg](https://www.youtube.com/watch?v=PUoTORjmfQg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-05-10T11:00:17+00:00

http://KEXP.ORG presents SPRINTS performing “Up And Comer” live in the KEXP studio. Recorded March 6, 2024

Karla Chubb - Vocals, Guitar
Colm O’Reilly - Guitar
Sam McCann - Bass, Vocals
Jack Callan - Drums

Host: Kevin Cole
Audio Engineer: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Luke Knecht, Scott Holpainen
Editor: Jim Beckmann

https://www.sprintsmusic.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

