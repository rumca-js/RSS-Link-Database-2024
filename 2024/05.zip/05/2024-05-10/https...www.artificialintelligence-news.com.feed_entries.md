# Source:AI News, URL:https://www.artificialintelligence-news.com/feed, language:en-GB

## OpenAI set to unveil AI-driven challenger to Google Search
 - [https://www.artificialintelligence-news.com/2024/05/10/openai-set-unveil-ai-driven-challenger-google-search](https://www.artificialintelligence-news.com/2024/05/10/openai-set-unveil-ai-driven-challenger-google-search)
 - RSS feed: https://www.artificialintelligence-news.com/feed
 - date published: 2024-05-10T13:08:07+00:00

<p>Google&#8217;s long-standing supremacy in the search engine arena may soon be challenged as OpenAI, boosted by its partnership with Microsoft, is reportedly stepping up to launch its own AI-driven search product. According to two sources familiar with the matter who spoke to Reuters, OpenAI is scheduled to unveil its AI-powered search tool on Monday. The<a class="excerpt-read-more" href="https://www.artificialintelligence-news.com/2024/05/10/openai-set-unveil-ai-driven-challenger-google-search/" title="ReadOpenAI set to unveil AI-driven challenger to Google Search">... Read more &#187;</a></p>
<p>The post <a href="https://www.artificialintelligence-news.com/2024/05/10/openai-set-unveil-ai-driven-challenger-google-search/">OpenAI set to unveil AI-driven challenger to Google Search</a> appeared first on <a href="https://www.artificialintelligence-news.com">AI News</a>.</p>

