# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Success is not an option
 - [https://seths.blog/2024/05/success-is-not-an-option](https://seths.blog/2024/05/success-is-not-an-option)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-05-10T08:56:00+00:00

In any creative endeavor, it&#8217;s possible to define success as the big win, the moment when your dreams match reality. Success is the end of imposter syndrome, stability and finally making it to the other side. By this definition, it&#8217;s clear that success isn&#8217;t going to happen. It&#8217;s incompatible with the reason you do this [&#8230;]

