# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Otoboke Beaver: Tiny Desk Concert
 - [https://www.youtube.com/watch?v=wIfg-Ye0FVk](https://www.youtube.com/watch?v=wIfg-Ye0FVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2024-05-10T09:00:46+00:00

Lars Gotrich | May 10, 2024
Mannie Fresh bum rushed the crowd and mugged for the camera. Soul Glo's Pierce Jordan stunted on office furniture. Moses Sumney played our window-side piano. Some moments were staged and others spontaneous, but sometimes an artist just needs to "break the frame" of Tiny Desk. Case in point: Our puny shelves and cluttered junk could not contain Otoboke Beaver's Yoyoyoshie, who literally lept out from behind the Desk, ran to the wide shot and shred a noisy guitar solo most triumphantly.

Kyoto, Japan's Otoboke Beaver came into the NPR Music office with string lights color coordinated to the members' floral print dresses, an edamame hair clip for our wall and a giant, inflatable beaver. In two-minute bursts of fast, furious and outrageously fun punk rock, the band's music is a gleeful exercise in absurdist evisceration — of Japanese societal norms, gender roles, annoying trolls and bad boyfriends. Every song smirks as it explodes. At the Tiny Desk, Otoboke Bea

