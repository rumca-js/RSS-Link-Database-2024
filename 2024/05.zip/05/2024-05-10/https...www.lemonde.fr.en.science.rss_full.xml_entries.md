# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Elective egg freezing in France: 'A promise without the means'
 - [https://www.lemonde.fr/en/france/article/2024/05/10/elective-egg-freezing-in-france-a-promise-without-the-means_6671021_7.html](https://www.lemonde.fr/en/france/article/2024/05/10/elective-egg-freezing-in-france-a-promise-without-the-means_6671021_7.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2024-05-10T14:06:11+00:00

Obstetrician and gynecologist François Olivennes deplores abnormally long waiting times despite a law that is supposed to facilitate fertility preservation for women.

