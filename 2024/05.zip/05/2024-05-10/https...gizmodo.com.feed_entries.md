# Source:Gizmodo, URL:https://gizmodo.com/feed, language:en

## The Latest in Boeing’s Starliner Fiasco Is a Feud Over That 'Buzzing' Valve
 - [https://gizmodo.com/boeing-starliner-nasa-valve-valvetech-spat-lawsuit-1851469705](https://gizmodo.com/boeing-starliner-nasa-valve-valvetech-spat-lawsuit-1851469705)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T20:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/d97c906240d0a21d51d17a812f5a874d.jpg" /><p>Just when we thought things couldn’t get any worse for Boeing’s attempt at launching a crew to orbit, in comes a longstanding industry feud over rocket valves for a shocking third act.</p><p><a href="https://gizmodo.com/boeing-starliner-nasa-valve-valvetech-spat-lawsuit-1851469705">Read more...</a></p>

## Jack Dorsey Rains on Bluesky
 - [https://gizmodo.com/jack-dorsey-bluesky-twitter-founder-elon-musk-x-1851469847](https://gizmodo.com/jack-dorsey-bluesky-twitter-founder-elon-musk-x-1851469847)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b2855e00a85e03a64adb2569708cd8d1.jpg" /><p>Jack Dorsey reemerged on Elon Musk’s X recently, calling it a “<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/jack-dorsey-call-x-freedom-tech-departing-bluesky-board-1851457748">freedom technology</a>” last week as he stepped down from Bluesky’s board. In an interview with Pirate Wires Thursday, the founder of Twitter says he never really left the  platform, he just was posting less. Dorsey also shed light on his departure from…</p><p><a href="https://gizmodo.com/jack-dorsey-bluesky-twitter-founder-elon-musk-x-1851469847">Read more...</a></p>

## One of the Best Animated Sci-Fi Shows in Years Just Got Killed by Max—But There's Still Hope
 - [https://gizmodo.com/scavengers-reign-cancelled-max-but-netflix-s2-hope-1851470217](https://gizmodo.com/scavengers-reign-cancelled-max-but-netflix-s2-hope-1851470217)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T19:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/52a30c506ebf6f06ec029fff70bfd66e.jpg" /><p>io9 named <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/scavengers-reign-joe-bennett-sean-buckelew-interview-1850922928">Scavengers Reign</a> to our list of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/2023-best-scifi-fantasy-horror-tv-last-of-us-doctor-who-1851086126">the best TV shows of 2023</a>—but the series won’t be returning to Max for a second season. However, with the news of its cancellation comes a flicker of hope: <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/top-50-scifi-fantasy-horror-tv-moments-of-2023-1851093037">the excellent 12-episode first season</a> will also be available on Netflix starting May 31, something that could lead to the…</p><p><a href="https://gizmodo.com/scavengers-reign-cancelled-max-but-netflix-s2-hope-

## Top Trump Henchman Working on 'Netflix-Like' Service for China: Report
 - [https://gizmodo.com/paul-manafort-china-video-doorways-netflix-trump-rnc-1851469492](https://gizmodo.com/paul-manafort-china-video-doorways-netflix-trump-rnc-1851469492)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/76e811fdbbd6557036969c107622d7af.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/paul-manafort-learns-that-encrypting-messages-doesnt-ma-1826561511">Paul Manafort</a>, a top <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/donald-trump-nfts-mugshot-mar-a-lago-dinner-price-vip-1851464284">Trump</a> associate who pleaded guilty to money laundering and obstruction of justice before being pardoned by the 45th president in 2020, is back in the news with the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.washingtonpost.com/politics/2024/05/10/paul-manafort-pardon-donald-trump-china/" rel="noopener noreferrer" target="_blank">Washington Post</a> reporting he’s revived his international consultancy business. But there’s one fact in the new story that really…</p><p><a href="https://gizmodo.com/

## The Incredible Way Weta Created Kingdom of the Planet of the Apes' Spoilery Opening
 - [https://gizmodo.com/kingdom-of-planet-of-the-apes-vfx-weta-opening-caesar-1851466875](https://gizmodo.com/kingdom-of-planet-of-the-apes-vfx-weta-opening-caesar-1851466875)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/53dbee28099f0ee994ad48aec0b66e75.jpg" /><p>When Weta’s  Erik Winquist heard Fox was <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/kingdom-of-planet-of-the-apes-interview-wes-ball-serkis-1851462274">making another Planet of the Apes movie</a>, he was initally skeptical. “It was presented as ‘Hey, there’s another Apes film, are you interested in working on that?’ And I was like, ‘Oh. I don’t know.’” he told io9. “Part of it was... where is this going to go? Because if it’s just…</p><p><a href="https://gizmodo.com/kingdom-of-planet-of-the-apes-vfx-weta-opening-caesar-1851466875">Read more...</a></p>

## Ncuti Gatwa and Millie Gibson on Doctor Who's Lonely Heroes, and Being Embraced by Fans
 - [https://gizmodo.com/doctor-who-ncuti-gatwa-millie-gibson-interview-fandom-1851469931](https://gizmodo.com/doctor-who-ncuti-gatwa-millie-gibson-interview-fandom-1851469931)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/d83fec6e89d8649e69d358b8d76f597a.png" /><p>There are few more intimidating things in the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/doctor-who-russel-t-davies-interview-disney-lgbt-moffat-1851462126">world of Doctor Who</a> than introducing something new. Despite the series’ enduring themes of change over the last 60 years, its fandom is one that is, more often than not, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/doctor-who-disney-plus-release-time-rtd-bbc-streaming-1851435225">hesitant to adapt</a> to change at first—and will <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/doctor-who-ai-bbc-complaints-response-disney-plus-1851363443">let you know it</a>. That makes bringing in new stars,…</p><p><a href="https://gizmodo.com/doctor-who-ncuti-gatwa-millie-gibson-interview-fandom-

## Why Your Car's Key Fob Is So Hackable
 - [https://gizmodo.com/why-your-cars-key-fob-is-so-hackable-1851455426](https://gizmodo.com/why-your-cars-key-fob-is-so-hackable-1851455426)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T18:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/df941fab57469fbbea79c4fb93337434.jpg" /><p>They’re small, they’re convenient, and, according to security researchers, they’re extremely hackable. The car key fob doesn’t exactly have the greatest reputation when it comes to digital security. Over the past few years, law enforcement agencies have alleged <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.cbsnews.com/news/cars-hacked-stolen-keyless-vehicle-thefts/" rel="noopener noreferrer" target="_blank">an uptick in the number of car thefts</a> tied to  hacking…</p><p><a href="https://gizmodo.com/why-your-cars-key-fob-is-so-hackable-1851455426">Read more...</a></p>

## Lord of the Rings Fan Film Restored After Brief YouTube Deletion
 - [https://gizmodo.com/lord-of-the-rings-gollum-fan-film-youtube-warner-bros-1851469640](https://gizmodo.com/lord-of-the-rings-gollum-fan-film-youtube-warner-bros-1851469640)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/5e6dd7469052bc61c101b21aa6e743d6.jpg" /><p>The timing seemed just a little too precious. A day after <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lord-of-the-rings-gollum-movie-2026-andy-serkis-lotr-1851465944">Warner Bros. announced it would be making a new Lord of the Rings film</a> called “The Hunt for Gollum,” a fan film with the same name that had been online for 15 years was removed from YouTube. “This video contains content from <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/new-lord-of-the-rings-movies-elijah-wood-frodo-tolkien-1850337440">Warner Bros Entertainment,</a> who has…</p><p><a href="https://gizmodo.com/lord-of-the-rings-gollum-fan-film-youtube-warner-bros-1851469640">Read more...</a></p>

## New Cybertruck Owner Learns the Hard Way That Coolant Leaks Aren't Covered by Warranty
 - [https://gizmodo.com/new-cybertruck-owner-learns-the-hard-way-that-coolant-l-1851469646](https://gizmodo.com/new-cybertruck-owner-learns-the-hard-way-that-coolant-l-1851469646)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T16:45:55+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/f44ee6cc57d64eaabdd4f0432f7fd264.jpg" /><p>The hits just <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/tesla-cybertruck-breaks-in-new-innovative-way-1851426532">keep</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/watch-this-tesla-cybertruck-sputter-out-after-driving-t-1851347369">on</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/tesla-cybertruck-owners-forum-is-already-full-of-tales-1851388334">coming</a> with the Tesla <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/tesla-cybertruck-may-not-look-sharp-but-its-leg-slicin-1851462786">Cybertruck</a>. Yet another <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/nantucket-is-already-sick-of-its-new-tesla-cybertruck-o-1851458762">owner</a> has reported h

## 10 More Sci-Fi, Horror, and Fantasy Books to Read Ahead of Their Upcoming Adaptations
 - [https://gizmodo.com/10-sci-fi-fantasy-horror-books-with-adaptations-coming-1851466751](https://gizmodo.com/10-sci-fi-fantasy-horror-books-with-adaptations-coming-1851466751)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T16:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/45526c1c0c70e6c0d6dc7cc6fd9f506f.jpg" /><p>With <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/dark-matter-review-apple-tv-scifi-joel-edgerton-1851459703">Apple TV+ series Dark Matter</a>—adapted from Blake Crouch’s best-selling novel—now streaming, it seemed like the perfect time to assemble <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/sci-fi-fantasy-horror-book-adaptations-dune-mickey7-1850300929">a new list of</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/sci-fi-fantasy-horror-book-adaptations-dune-mickey7-1850300929">sci-fi, fantasy, and horror books</a> that have <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/10-scifi-horror-books-being-adapted-wicked-whalefall-1851329175">movies and TV series</a> <a class="sc-1out364-0 dPMosf sc-145m8

## Scientists Need Your Help to Find Zombie-Infected Cicadas Filled With Gut Pudding
 - [https://gizmodo.com/zombie-infected-cicadas-gut-pudding-fungal-parasite-1851469413](https://gizmodo.com/zombie-infected-cicadas-gut-pudding-fungal-parasite-1851469413)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T16:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/71f612250b3c8b0976766c4421ca49a3.jpg" /><p>If you’re in the mood for a weird scavenger hunt this spring, you’re in luck. Entomologists are asking members of the public to report sightings of adult brood cicadas that have become infested with the parasite Massospora cicadina, also known as the zombie cicada fungus. Those looking will have an easy clue: the…</p><p><a href="https://gizmodo.com/zombie-infected-cicadas-gut-pudding-fungal-parasite-1851469413">Read more...</a></p>

## Let's Talk About the Ending of Kingdom of the Planet of the Apes
 - [https://gizmodo.com/kingdom-planet-of-the-apes-ending-explained-noa-mae-fox-1851447224](https://gizmodo.com/kingdom-planet-of-the-apes-ending-explained-noa-mae-fox-1851447224)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/6f887f715c80026bcf6d7046e08acd94.jpg" /><p>“It’s like the beginning of the next one almost more than the end of this one.” That’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/kingdom-of-planet-of-the-apes-interview-wes-ball-serkis-1851462274">director Wes Bal</a>l talking to io9 about the choices made at the end of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/kingdom-of-the-planet-of-the-apes-review-wes-ball-movie-1851444769">Kingdom of the Planet of the Apes</a>, which is in theaters now. And while its story of Noa, Mae, Proximus Caesar, and the Eagle Clan reaches a conclusion, the film…</p><p><a href="https://gizmodo.com/kingdom-planet-of-the-apes-ending-explained-noa-mae-fox-1851447224">Read more...</a></p>

## First New U.S. Aluminum Smelter in 45 Years Could Cut Production Emissions by 75%
 - [https://gizmodo.com/first-new-u-s-aluminum-smelter-in-45-years-could-cut-p-1851469454](https://gizmodo.com/first-new-u-s-aluminum-smelter-in-45-years-could-cut-p-1851469454)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T15:56:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/1699654dc0c87675cdb957aabaed03d6.jpg" /><p>This story was originally published by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://grist.org" rel="noopener noreferrer" target="_blank">Grist</a>. Sign up for Grist’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://go.grist.org/signup/weekly/partner?utm_campaign=republish-content&amp;utm_medium=syndication&amp;utm_source=partner" rel="noopener noreferrer" target="_blank">weekly newsletter here</a>.<br /></p><p><a href="https://gizmodo.com/first-new-u-s-aluminum-smelter-in-45-years-could-cut-p-1851469454">Read more...</a></p>

## How Scientists Are Prepping for the Incoming Severe Solar Storm
 - [https://gizmodo.com/how-scientists-preparing-severe-solar-geomagnetic-storm-1851469148](https://gizmodo.com/how-scientists-preparing-severe-solar-geomagnetic-storm-1851469148)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T15:55:08+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/1b5470c4a14e93a8c0bf9123907e66b7.png" /><p>Inclement weather on the Sun’s surface could affect infrastructure on Earth and in space, scientists are predicting, as our host star approaches its solar maximum.<br /></p><p><a href="https://gizmodo.com/how-scientists-preparing-severe-solar-geomagnetic-storm-1851469148">Read more...</a></p>

## How to Make Sure No One Is Stealing Your Home WiFi
 - [https://gizmodo.com/how-to-make-sure-no-one-is-stealing-your-home-wifi-1851468625](https://gizmodo.com/how-to-make-sure-no-one-is-stealing-your-home-wifi-1851468625)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/aa51387486cd49b736d7f657ff50ead9.jpg" /><p>WiFi is a precious resource, and you don’t want other people—house guests, neighbors, relatives, delivery drivers, hackers sitting at the end of your garden—accessing it without your permission. With that in mind, it’s a good idea to regularly audit who’s accessing your WiFi and kick off any unwelcome interlopers.</p><p><a href="https://gizmodo.com/how-to-make-sure-no-one-is-stealing-your-home-wifi-1851468625">Read more...</a></p>

## Lego's New UCS TIE Interceptor Was Worth the 24-Year Wait
 - [https://gizmodo.com/legos-new-ucs-tie-interceptor-was-worth-the-24-year-wai-1851466764](https://gizmodo.com/legos-new-ucs-tie-interceptor-was-worth-the-24-year-wai-1851466764)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T14:47:41+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9febac9fb28da6d93ae7f8ac223e2ec7.jpg" /><p><a href="https://gizmodo.com/legos-new-ucs-tie-interceptor-was-worth-the-24-year-wai-1851466764">Read more...</a></p>

## Fallout Just Gave Amazon Its Biggest Streaming Hit In the U.S.
 - [https://gizmodo.com/amazon-fallout-ratings-nielsen-streaming-prime-video-1851468959](https://gizmodo.com/amazon-fallout-ratings-nielsen-streaming-prime-video-1851468959)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T14:00:03+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/19c74cf3f97b7a7a2adf16a683c6b246.jpg" /><p>A few weeks ago, Amazon touted that Fallout had become its <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/fallout-prime-video-streaming-numbers-65-million-global-1851443377">second-biggest debut</a> in the world, right after <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lord-of-the-rings-rings-of-power-audience-amazon-prime-1850295966">Lord of the Rings: The Rings of Power</a>. But it turns out it the heart of the wasteland—or rather specifically, the United States—the video game adaptation <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/amazon-prime-more-ads-1851463280">gave the streamer</a> its biggest opening ever by several…</p><p><a href="https://gizmodo.com/amazon-fallout-ratings-nielsen-streaming-prime-video-1851468959">Read more...</a

## Nintendo's Bowser Gets Into LinkedIn Brawl Over Plane Seats
 - [https://gizmodo.com/nintendo-doug-bowser-president-linkedin-debate-comments-1851468780](https://gizmodo.com/nintendo-doug-bowser-president-linkedin-debate-comments-1851468780)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T13:01:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3e543ff976b2138537300c374ff3a91f.jpg" /><p>We’ve all, at one point or another in our time on the internet, seen a post or comment so mean, shitty, or just bad that we can’t help but start clacking the keys and writing up a response. It turns out, even <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/nintendo-switch-lite-animal-crossing-mario-kart-bundle-1850810061">Nintendo of America’s president—Doug Bowser</a>—can’t always resist the siren song of hopping into the comments…</p><p><a href="https://gizmodo.com/nintendo-doug-bowser-president-linkedin-debate-comments-1851468780">Read more...</a></p>

## Marvels Hunt For Its X-Men Writers Is Getting Closer and Closer
 - [https://gizmodo.com/marvel-x-men-movie-mcu-writers-disney-1851468056](https://gizmodo.com/marvel-x-men-movie-mcu-writers-disney-1851468056)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/1ed277c2571a6709c9967e5941248e20.png" /><p>Stop-motion legend Phil Tippett is working on a wild-sounding new movie. Netflix is, somehow, still making an animated series out of Exploding Kittens. More Ted is on the way. Plus, what’s coming up on Doctor Who and Reginald the Vampire. To me, my spoilers!<br /></p><p><a href="https://gizmodo.com/marvel-x-men-movie-mcu-writers-disney-1851468056">Read more...</a></p>

## What Would Happen If a Massive Solar Storm Hit Earth?
 - [https://gizmodo.com/what-would-happen-if-a-massive-solar-storm-hit-the-eart-1724650105](https://gizmodo.com/what-would-happen-if-a-massive-solar-storm-hit-the-eart-1724650105)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T12:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/1397170799384530245.jpg" /><p>This article was originally published on August 20, 2015.</p><p><a href="https://gizmodo.com/what-would-happen-if-a-massive-solar-storm-hit-the-eart-1724650105">Read more...</a></p>

## World Warned to Prepare for Today's Severe Geomagnetic Storm, First in 20 Years
 - [https://gizmodo.com/severe-solar-geomagnetic-solar-storm-watch-1851468637](https://gizmodo.com/severe-solar-geomagnetic-solar-storm-watch-1851468637)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-05-10T12:31:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/31db7a5bf0d0b23fb5d223544af0c4f3.jpg" /><p>The National Oceanic and Atmospheric Administration’s Space Weather Prediction Center forecasted a “severe solar storm” expected to hit Earth tonight, according to a <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.swpc.noaa.gov/news/media-advisory-noaa-forecasts-severe-solar-storm-media-availability-scheduled-friday-may-10" rel="noopener noreferrer" target="_blank">release</a>. These geomagnetic storms happen every so often, but as the Sun approaches the maximum of its 11-year solar cycle, the space weather is getting…</p><p><a href="https://gizmodo.com/severe-solar-geomagnetic-solar-storm-watch-1851468637">Read more...</a></p>

