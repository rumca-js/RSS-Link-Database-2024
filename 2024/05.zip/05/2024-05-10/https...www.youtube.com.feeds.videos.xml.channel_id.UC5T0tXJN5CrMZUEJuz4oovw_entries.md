# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Marvel Eats Crow, DC's Superman Dress Up, DEI Caped Crusader | Friday Night Tights 301 w Lauren Chen
 - [https://www.youtube.com/watch?v=u5mqV5vM4cw](https://www.youtube.com/watch?v=u5mqV5vM4cw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2024-05-10T19:21:55+00:00

With Special Guest: @laurenchen 


PLUSHIES
https://www.makeship.com/shop/real-bbc


Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Streamlab Donations: https://streamlabs.com/sutrowatchtower/tip

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by Gamer Supps
https://gamersupps.gg/Nerdrotic

Sponsored by MetaPCs!
https://www.metapcs.com/creator-nerdrotic/

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/collections/nerdrotic-coffee

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/nerdrotic-mug?

The Lads: 
Gary from @nerdrotic @NerdroticDaily @NerdroticLive  
Jeremy from @DDayCobra @GeeksandGamers @ParkHoppin @geeksandgamersplay @GeeksandGamersTabletop @geeksandgamersclips @geeksandgamerslife 
Odin from  @OMBReviews @TheOMBReport  
Ryan from @ryankinel-rkoutpost1 @rk

