# Source:GamingOnLinux Latest Articles, URL:https://www.gamingonlinux.com/article_rss.php, language:en-us

## Bungie's classic free FPS 'Marathon' is now on Steam
 - [https://www.gamingonlinux.com/2024/05/bungies-classic-free-fps-marathon-is-now-on-steam](https://www.gamingonlinux.com/2024/05/bungies-classic-free-fps-marathon-is-now-on-steam)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-05-10T17:15:56+00:00

Before the likes of Halo: Combat Evolved and Destiny, Bungie created the FPS series Marathon which nowadays lives on as an open source project and now it's available on Steam.

## Collabora detail the improved updater for Steam Deck in SteamOS 3.6
 - [https://www.gamingonlinux.com/2024/05/collabora-detail-the-improved-updater-for-steam-deck-in-steamos-3-6](https://www.gamingonlinux.com/2024/05/collabora-detail-the-improved-updater-for-steam-deck-in-steamos-3-6)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-05-10T15:46:59+00:00

One of the companies that Valve fund for improvements across Linux, SteamOS and Steam Deck is Collabora and a developer has gone into more detail on the upgrades to the update system in SteamOS 3.6 that's now in Preview.

## Men of War II will be online-only at launch but an offline mode is in development
 - [https://www.gamingonlinux.com/2024/05/men-of-war-ii-will-be-online-only-at-launch-but-an-offline-mode-is-in-development](https://www.gamingonlinux.com/2024/05/men-of-war-ii-will-be-online-only-at-launch-but-an-offline-mode-is-in-development)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-05-10T14:53:14+00:00

The release of the strategy game Men of War II is fast approaching from Fulqrum Publishing and Ukrainian studio Best Way, which is confirmed to have Native Linux support but there's one sore spot.

## Rogue Voltage is a refreshing and very creative engineering roguelike
 - [https://www.gamingonlinux.com/2024/05/rogue-voltage-is-a-refreshing-and-very-creative-engineering-roguelike](https://www.gamingonlinux.com/2024/05/rogue-voltage-is-a-refreshing-and-very-creative-engineering-roguelike)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-05-10T13:46:46+00:00

Rogue Voltage takes the idea of roguelikes and deck-builders and spins it into something incredible clever with a little engineering involving lots of wires.

## Heroes of Might and Magic III open source build gets initial gamepad support
 - [https://www.gamingonlinux.com/2024/05/heroes-of-might-and-magic-iii-open-source-build-gets-initial-gamepad-support](https://www.gamingonlinux.com/2024/05/heroes-of-might-and-magic-iii-open-source-build-gets-initial-gamepad-support)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-05-10T12:41:24+00:00

VCMI, the cross-platform open source game engine for Heroes of Might and Magic III has another fresh release out and they've been working on hooking up gamepad support.

## SteamOS 3.6 Preview for Steam Deck brings numerous big new features
 - [https://www.gamingonlinux.com/2024/05/steamos-36-preview-for-steam-deck-brings-numerous-big-new-features](https://www.gamingonlinux.com/2024/05/steamos-36-preview-for-steam-deck-brings-numerous-big-new-features)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-05-10T12:15:49+00:00

Valve have now put SteamOS 3.6 into Preview for Steam Deck, so those willing to test can jump in now and check out more big new features.

