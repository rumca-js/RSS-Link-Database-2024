# Source:DAILYSABAH - Turkey News, URL:https://www.dailysabah.com/rssFeed/10, language:en-US

## Istanbul Airport repairs runway post-cargo plane belly landing
 - [https://www.dailysabah.com/turkiye/istanbul-airport-repairs-runway-post-cargo-plane-belly-landing/news](https://www.dailysabah.com/turkiye/istanbul-airport-repairs-runway-post-cargo-plane-belly-landing/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-10T10:07:00+00:00

The runway at Istanbul Airport closed after a cargo plane’s emergency landing due to a landing gear malfunction has reopened for flights, an official said Thursday.

'The cargo air...

## MÜSİAD's 'Türkiye's Power Awards' winners announced
 - [https://www.dailysabah.com/turkiye/musiads-turkiyes-power-awards-winners-announced/news](https://www.dailysabah.com/turkiye/musiads-turkiyes-power-awards-winners-announced/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-10T09:44:00+00:00

Türkiye's Power Awards, organized for the second time this year by the Independent Industrialists and Businessmen's Association (MÜSİAD), welcomed recipients at an organi...

## Massive 13-kilogram mushroom discovered in Elazığ
 - [https://www.dailysabah.com/turkiye/massive-13-kilogram-mushroom-discovered-in-elazig/news](https://www.dailysabah.com/turkiye/massive-13-kilogram-mushroom-discovered-in-elazig/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-10T09:08:07+00:00

Türkiye's prized morel mushrooms, known for their nutritional value, intense aroma and delicate flavor, are highly sought after worldwide.

For years, large mushrooms have bee...

## One out of every five in Türkiye combat obesity
 - [https://www.dailysabah.com/turkiye/one-out-of-every-five-in-turkiye-combat-obesity/news](https://www.dailysabah.com/turkiye/one-out-of-every-five-in-turkiye-combat-obesity/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-10T08:29:00+00:00

Obesity is emerging as a growing health concern worldwide. Data from the Turkish Statistical Institute (TurkStat) reveals that 20% of individuals in Türkiye grapple with obesity....

## One out of every five in Türkiye is combating obesity
 - [https://www.dailysabah.com/turkiye/one-out-of-every-five-in-turkiye-is-combating-obesity/news](https://www.dailysabah.com/turkiye/one-out-of-every-five-in-turkiye-is-combating-obesity/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-05-10T08:29:00+00:00

Obesity is emerging as a growing health concern worldwide. Data from the Turkish Statistical Institute (TurkStat) reveals that 20% of individuals in Türkiye grapple with obesity....

