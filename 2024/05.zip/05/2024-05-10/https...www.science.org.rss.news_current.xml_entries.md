# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## The U.S. wants to change how researchers get access to a huge trove of health data. Many don’t like the idea
 - [https://www.science.org/content/article/u-s-wants-change-how-researchers-get-access-huge-trove-health-data-many-don-t-idea](https://www.science.org/content/article/u-s-wants-change-how-researchers-get-access-huge-trove-health-data-many-don-t-idea)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-05-10T19:19:29.622152+00:00

Plan to end ability of universities to host Medicare and Medicaid data raises cost and other concerns

## A scientist asked to join the U.K. House of Lords—and got in
 - [https://www.science.org/content/article/scientist-asked-join-u-k-house-lords-and-got](https://www.science.org/content/article/scientist-asked-join-u-k-house-lords-and-got)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-05-10T17:10:22.884370+00:00

“I got one of those lovely phone calls,” evidence communication researcher Alexandra Freeman says about her surprise appointment

