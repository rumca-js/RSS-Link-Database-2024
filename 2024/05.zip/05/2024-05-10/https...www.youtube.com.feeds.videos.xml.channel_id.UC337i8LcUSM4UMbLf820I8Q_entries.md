# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## The Lord of the Rings: Peter Jackson Returns to Middle-Earth
 - [https://www.youtube.com/watch?v=x4azGPEItvg](https://www.youtube.com/watch?v=x4azGPEItvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q
 - date published: 2024-05-10T03:22:26+00:00

The Lord of the Rings: Peter Jackson Returns to Middle-Earth
----------------------------------------------------------------------------------------------
Art and Animation by Just Some Guy

Original trailer concept: FMA Brotherhood & Black Summoner

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/

