# Source:Publisher weekly, URL:https://www.publishersweekly.com/pw/feeds/recent/index.xml, language:en-US

## 4 New Debut Novels by Women That We Loved
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/95005-four-new-debut-novels-by-women-that-we-loved.html](http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/95005-four-new-debut-novels-by-women-that-we-loved.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-10T04:00:00+00:00



## Arcadia Publishing Acquires Dry Climate Studios
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/95021-arcadia-publishing-acquires-dry-climate-studios.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/95021-arcadia-publishing-acquires-dry-climate-studios.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-10T04:00:00+00:00



## In Memoriam: James A. Fox, 1939-2024
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/Obituary/article/95008-in-memoriam-james-a-fox-1939-2024.html](http://www.publishersweekly.com/pw/by-topic/industry-news/Obituary/article/95008-in-memoriam-james-a-fox-1939-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-10T04:00:00+00:00



## Jim Fox, Former HarperCollins General Counsel, Dies at 85
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/Obituary/article/95009-jim-fox-former-harpercollins-general-counsel-dies-at-85.html](http://www.publishersweekly.com/pw/by-topic/industry-news/Obituary/article/95009-jim-fox-former-harpercollins-general-counsel-dies-at-85.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-10T04:00:00+00:00



## Librarians, Advocates Sue to Block Restrictive New Alabama Library Policies
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/95012-librarians-advocates-sue-to-block-restrictive-new-alabama-library-policies.html](http://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/95012-librarians-advocates-sue-to-block-restrictive-new-alabama-library-policies.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-10T04:00:00+00:00



## The 2024 Pulitzer Prize–Winning Books, Reviewed
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/94959-the-2024-pulitzer-prize-winning-books-reviewed.html](http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/94959-the-2024-pulitzer-prize-winning-books-reviewed.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-05-10T04:00:00+00:00



