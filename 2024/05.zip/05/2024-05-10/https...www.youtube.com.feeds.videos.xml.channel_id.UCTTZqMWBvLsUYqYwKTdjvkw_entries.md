# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 🪆 86Rosyjskie APT28 na celowniku
 - [https://www.youtube.com/watch?v=JzVhlUTg3ho](https://www.youtube.com/watch?v=JzVhlUTg3ho)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2024-05-10T04:30:09+00:00

Czy Rosja próbuje wpływać na różne, w tym nielegalne sposoby na politykę innych krajów?
 
Źródła:
https://tinyurl.com/5n99w6nd
https://tinyurl.com/mrzjcjsb
 
#APT28 #Rosja #cyberbezpieczeństwo #atak

