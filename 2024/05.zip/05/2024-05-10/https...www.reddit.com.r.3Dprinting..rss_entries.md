# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Y'all be out there printing spaghetti, here's a meatball to go with it.
 - [https://www.reddit.com/r/3Dprinting/comments/1cowxe4/yall_be_out_there_printing_spaghetti_heres_a](https://www.reddit.com/r/3Dprinting/comments/1cowxe4/yall_be_out_there_printing_spaghetti_heres_a)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T18:47:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cowxe4/yall_be_out_there_printing_spaghetti_heres_a/"> <img alt="Y'all be out there printing spaghetti, here's a meatball to go with it." src="https://external-preview.redd.it/Su9EO19Op9xcyokS-Enq3zxvKUPUP0o2n_qo4Jbl7qI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=342a8c85df80cc3bc1579796bf5eda3a63d42243" title="Y'all be out there printing spaghetti, here's a meatball to go with it." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/planeturban"> /u/planeturban </a> <br /> <span><a href="https://imgur.com/a/0tB1yuw">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cowxe4/yall_be_out_there_printing_spaghetti_heres_a/">[comments]</a></span> </td></tr></table>

## One amazing adventure!
 - [https://www.reddit.com/r/3Dprinting/comments/1cow8ie/one_amazing_adventure](https://www.reddit.com/r/3Dprinting/comments/1cow8ie/one_amazing_adventure)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T18:18:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cow8ie/one_amazing_adventure/"> <img alt="One amazing adventure!" src="https://preview.redd.it/s7yhq0c35nzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f1c7402ce4153e669678c5ba5b63e23963b38626" title="One amazing adventure!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Finally, it's complete ✅ Took 17 hours and 42 minutes of work 😅</p> <p>I'm so proud of this figure and the work that I have done, I'm using a resin printer ELEGOO Mars 4k Pro and the curing machine also from ELEGOO.</p> <p>My plan is to paint the figure down the road.</p> <p>The figure is: Sol the Holiest</p> <p>I've tried some test prints first just to see if the settings were good, even went for the ones in random excels across google. Eventually found the ones that suited better 😉</p> <p>I would definitely have another go for more complex geometries 😎</p> <p>I have a page of figures, you can check here for more images and prints: <a

## My TPU arrived like this
 - [https://www.reddit.com/r/3Dprinting/comments/1cove7x/my_tpu_arrived_like_this](https://www.reddit.com/r/3Dprinting/comments/1cove7x/my_tpu_arrived_like_this)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T17:41:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cove7x/my_tpu_arrived_like_this/"> <img alt="My TPU arrived like this" src="https://preview.redd.it/yw7rntakymzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1c34c4490569f031506ea03f6212b5fdfa918f7c" title="My TPU arrived like this" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>A benchy printed fine, but do you think its time to print a coil rewinder? I am worried that it might get stuck when im not looking</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jerkface1337"> /u/jerkface1337 </a> <br /> <span><a href="https://i.redd.it/yw7rntakymzc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cove7x/my_tpu_arrived_like_this/">[comments]</a></span> </td></tr></table>

## What to Google? Not sure what search terms to use for this issue.
 - [https://www.reddit.com/r/3Dprinting/comments/1cour56/what_to_google_not_sure_what_search_terms_to_use](https://www.reddit.com/r/3Dprinting/comments/1cour56/what_to_google_not_sure_what_search_terms_to_use)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T17:13:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cour56/what_to_google_not_sure_what_search_terms_to_use/"> <img alt="What to Google? Not sure what search terms to use for this issue." src="https://external-preview.redd.it/bIdpHIvbbmGryPMA2RtwbITTu4QtdD69vbLRKaaoZmk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=50ff21d15320bb90fe02ce23684d1e294269503d" title="What to Google? Not sure what search terms to use for this issue." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sgt_ZigZag"> /u/Sgt_ZigZag </a> <br /> <span><a href="https://i.imgur.com/StjhWYA.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cour56/what_to_google_not_sure_what_search_terms_to_use/">[comments]</a></span> </td></tr></table>

## First time painting a finished print
 - [https://www.reddit.com/r/3Dprinting/comments/1cou4cr/first_time_painting_a_finished_print](https://www.reddit.com/r/3Dprinting/comments/1cou4cr/first_time_painting_a_finished_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T16:46:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cou4cr/first_time_painting_a_finished_print/"> <img alt="First time painting a finished print" src="https://preview.redd.it/8yqw6hmtomzc1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=039a9223e5ded84c82d49b83e2b27b6b1448b0ac" title="First time painting a finished print" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mikereations"> /u/mikereations </a> <br /> <span><a href="https://i.redd.it/8yqw6hmtomzc1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cou4cr/first_time_painting_a_finished_print/">[comments]</a></span> </td></tr></table>

## First Homemade Filament Print!
 - [https://www.reddit.com/r/3Dprinting/comments/1cotygi/first_homemade_filament_print](https://www.reddit.com/r/3Dprinting/comments/1cotygi/first_homemade_filament_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T16:39:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cotygi/first_homemade_filament_print/"> <img alt="First Homemade Filament Print!" src="https://b.thumbs.redditmedia.com/yWV1gnwDfljgsIRH6pqJjXmJ8LFi_IuGoDOSQE-UdJA.jpg" title="First Homemade Filament Print!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/beernoulli"> /u/beernoulli </a> <br /> <span><a href="https://www.reddit.com/gallery/1cotygi">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cotygi/first_homemade_filament_print/">[comments]</a></span> </td></tr></table>

## Where can I get a model of mountains
 - [https://www.reddit.com/r/3Dprinting/comments/1cosv8s/where_can_i_get_a_model_of_mountains](https://www.reddit.com/r/3Dprinting/comments/1cosv8s/where_can_i_get_a_model_of_mountains)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T15:53:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cosv8s/where_can_i_get_a_model_of_mountains/"> <img alt="Where can I get a model of mountains" src="https://preview.redd.it/1d7cfd9cfmzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=595e38f987e9c9278e946a75c8503aed7c37222b" title="Where can I get a model of mountains" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I want to print a huge model of the Grand Teton mountains, and i’ve found models of just a few small sections, but how could I get one of almost the entire range? Would something like the USGS be of help?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/_1unchb0x_"> /u/_1unchb0x_ </a> <br /> <span><a href="https://i.redd.it/1d7cfd9cfmzc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cosv8s/where_can_i_get_a_model_of_mountains/">[comments]</a></span> </td></tr></table>

## Cutting board organizer I made
 - [https://www.reddit.com/r/3Dprinting/comments/1costam/cutting_board_organizer_i_made](https://www.reddit.com/r/3Dprinting/comments/1costam/cutting_board_organizer_i_made)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T15:51:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1costam/cutting_board_organizer_i_made/"> <img alt="Cutting board organizer I made" src="https://a.thumbs.redditmedia.com/WZLyVDjcSIG70ofMf7WAGeGASrllgajxlibidWihNJ4.jpg" title="Cutting board organizer I made" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Popular_Error3691"> /u/Popular_Error3691 </a> <br /> <span><a href="https://www.reddit.com/gallery/1costam">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1costam/cutting_board_organizer_i_made/">[comments]</a></span> </td></tr></table>

## Compliance of 3D printed robotic arm
 - [https://www.reddit.com/r/3Dprinting/comments/1cosfz3/compliance_of_3d_printed_robotic_arm](https://www.reddit.com/r/3Dprinting/comments/1cosfz3/compliance_of_3d_printed_robotic_arm)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T15:35:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cosfz3/compliance_of_3d_printed_robotic_arm/"> <img alt=" Compliance of 3D printed robotic arm " src="https://external-preview.redd.it/djFyaW5vMGlibXpjMROjC5cCJgCNcPN4-Jd3XP_-Ppmid1yvRTaEfTwOrwV7.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0fd1748152608d42834205aed028cdafaec7fe35" title=" Compliance of 3D printed robotic arm " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SourceRobotics"> /u/SourceRobotics </a> <br /> <span><a href="https://v.redd.it/me4tkq0ibmzc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cosfz3/compliance_of_3d_printed_robotic_arm/">[comments]</a></span> </td></tr></table>

## Do you still have your very first print?
 - [https://www.reddit.com/r/3Dprinting/comments/1cosdjg/do_you_still_have_your_very_first_print](https://www.reddit.com/r/3Dprinting/comments/1cosdjg/do_you_still_have_your_very_first_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T15:32:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cosdjg/do_you_still_have_your_very_first_print/"> <img alt="Do you still have your very first print?" src="https://preview.redd.it/y1cxe78kbmzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=70fe908717b168b1100395ac6e1c024f2bd1162c" title="Do you still have your very first print?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I found those ( my first ever 3d print,printed with an unmoded ender3v2)no pressure advance, flow compensation, belt z, direct drive all those cool new stuffs. Really surprised with the quality considering what I been creating with more mods add on lol.</p> <p>Do you still have your very first print before all the mods? 🙌</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Professional-You-892"> /u/Professional-You-892 </a> <br /> <span><a href="https://i.redd.it/y1cxe78kbmzc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3D

## Dragon Key Hook
 - [https://www.reddit.com/r/3Dprinting/comments/1corv31/dragon_key_hook](https://www.reddit.com/r/3Dprinting/comments/1corv31/dragon_key_hook)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T15:10:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1corv31/dragon_key_hook/"> <img alt="Dragon Key Hook" src="https://b.thumbs.redditmedia.com/ggibO9B451f_ApXte5abiFim6KM1N4aRfnAdwAeu_Ag.jpg" title="Dragon Key Hook" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FennicVox"> /u/FennicVox </a> <br /> <span><a href="https://www.reddit.com/gallery/1corv31">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1corv31/dragon_key_hook/">[comments]</a></span> </td></tr></table>

## New printer arrived an hour ago
 - [https://www.reddit.com/r/3Dprinting/comments/1cor1hg/new_printer_arrived_an_hour_ago](https://www.reddit.com/r/3Dprinting/comments/1cor1hg/new_printer_arrived_an_hour_ago)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T14:35:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cor1hg/new_printer_arrived_an_hour_ago/"> <img alt="New printer arrived an hour ago" src="https://preview.redd.it/et0h08ha1mzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d20a37c75170ee71c9b2f8adf8378e93bac5e6b2" title="New printer arrived an hour ago" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Pretty happy to finally got my hands on the printer - waited since end of September 23 (Peopoly Magneto X)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/M_Unimaster"> /u/M_Unimaster </a> <br /> <span><a href="https://i.redd.it/et0h08ha1mzc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cor1hg/new_printer_arrived_an_hour_ago/">[comments]</a></span> </td></tr></table>

## 17-4 Steel Printed Part Sintered Using My Microwave
 - [https://www.reddit.com/r/3Dprinting/comments/1cor038/174_steel_printed_part_sintered_using_my_microwave](https://www.reddit.com/r/3Dprinting/comments/1cor038/174_steel_printed_part_sintered_using_my_microwave)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T14:33:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cor038/174_steel_printed_part_sintered_using_my_microwave/"> <img alt="17-4 Steel Printed Part Sintered Using My Microwave" src="https://external-preview.redd.it/M2g3eTJoM3owbXpjMWsTwKRoAFDmz1ETpWBJe-K5ny9ITd1hB6kJIAl4qd1r.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c1edb1da45098337378f7f98cab15dd0c5231dc2" title="17-4 Steel Printed Part Sintered Using My Microwave" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This is a 17-4 Steel test part that was printed on my fdm printer (tenlog tl-d3 pro) and sintered using my microwave sintering process.</p> <p>The main purpose for this test is to compare it with another identical part and sinter cycle, but adding a microwave Arc sinter step (another process I've been working on) to further densify and strengthen the end result.</p> <p>These are household microwaves with no modifications other than lining with ceramic insulating blanket</p> </div><!-- SC_ON --> &

## I was asked how long it took to wear the old exo. So here is the same video for the new one too after many upgrades..even if still not complete.
 - [https://www.reddit.com/r/3Dprinting/comments/1coqrio/i_was_asked_how_long_it_took_to_wear_the_old_exo](https://www.reddit.com/r/3Dprinting/comments/1coqrio/i_was_asked_how_long_it_took_to_wear_the_old_exo)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T14:22:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coqrio/i_was_asked_how_long_it_took_to_wear_the_old_exo/"> <img alt="I was asked how long it took to wear the old exo. So here is the same video for the new one too after many upgrades..even if still not complete." src="https://external-preview.redd.it/djE5NjlubDN6bHpjMfsx6XQFTlQFnp5BBZKzFTfutlKrIpdJOY9faReoYmp7.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=5918061c6699e3c7349c42583ea55558c42a6228" title="I was asked how long it took to wear the old exo. So here is the same video for the new one too after many upgrades..even if still not complete." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>For who didn't follow, it's a full body passive exoskeleton I am designing and building, mostly 3D printed. So far it's made like this: - Spine, belt, calves, feet and arms 3D printed partially in polycarbonate partially in ePLA-ST - Shoulders and hip brackets Alu CNC machined by JLC3DP - Thighs and knees MJF 3D pri

## Gundam Epyon
 - [https://www.reddit.com/r/3Dprinting/comments/1coq3vq/gundam_epyon](https://www.reddit.com/r/3Dprinting/comments/1coq3vq/gundam_epyon)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T13:53:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coq3vq/gundam_epyon/"> <img alt="Gundam Epyon" src="https://preview.redd.it/i9ge57rvtlzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=81c93b17fbd41ac70892b1e959cd0c2ab410a4e6" title="Gundam Epyon" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This is my favorite Gundam and I’m thrilled how this turned out</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/inevitible1"> /u/inevitible1 </a> <br /> <span><a href="https://i.redd.it/i9ge57rvtlzc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coq3vq/gundam_epyon/">[comments]</a></span> </td></tr></table>

## 3d printed jig for table/band sawa
 - [https://www.reddit.com/r/3Dprinting/comments/1copkyr/3d_printed_jig_for_tableband_sawa](https://www.reddit.com/r/3Dprinting/comments/1copkyr/3d_printed_jig_for_tableband_sawa)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T13:29:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1copkyr/3d_printed_jig_for_tableband_sawa/"> <img alt="3d printed jig for table/band sawa" src="https://a.thumbs.redditmedia.com/d80KscVdTJvPg0pybMrxAFBr5sA2t-s4pjFhm1AxM20.jpg" title="3d printed jig for table/band sawa" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Anyhting_But_Stock"> /u/Anyhting_But_Stock </a> <br /> <span><a href="https://www.reddit.com/gallery/1copkyr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1copkyr/3d_printed_jig_for_tableband_sawa/">[comments]</a></span> </td></tr></table>

## Is this a safe enough enclosure to be printing in my room?
 - [https://www.reddit.com/r/3Dprinting/comments/1conw02/is_this_a_safe_enough_enclosure_to_be_printing_in](https://www.reddit.com/r/3Dprinting/comments/1conw02/is_this_a_safe_enough_enclosure_to_be_printing_in)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T12:02:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1conw02/is_this_a_safe_enough_enclosure_to_be_printing_in/"> <img alt="Is this a safe enough enclosure to be printing in my room?" src="https://external-preview.redd.it/Ym1iczlkZTRhbHpjMVtd7yNQhsoC80GxuIQOzHwRTQrus0wtEaz6PHDMvKW1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=98a2149e1402f63f61264b557c5bc5dc82b3ba4b" title="Is this a safe enough enclosure to be printing in my room?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just finished setting this up the other day and wanted to make sure it’s good enough to print filament like asa abs or nylon while in my room. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Roctopus420"> /u/Roctopus420 </a> <br /> <span><a href="https://v.redd.it/uvkeycj4alzc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1conw02/is_this_a_safe_enough_enclosure_to_be_printing_in/">[comments]</a></span> </

## What can you say about my printer by looking at my branchy?
 - [https://www.reddit.com/r/3Dprinting/comments/1conpxs/what_can_you_say_about_my_printer_by_looking_at](https://www.reddit.com/r/3Dprinting/comments/1conpxs/what_can_you_say_about_my_printer_by_looking_at)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T11:54:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1conpxs/what_can_you_say_about_my_printer_by_looking_at/"> <img alt="What can you say about my printer by looking at my branchy?" src="https://preview.redd.it/t9wq9bhk8lzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=55871dd2d0bf652fd7be7e388ab3c8fcad23c941" title="What can you say about my printer by looking at my branchy?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hi guys. I'm new here and in 3D printing. I need some of your wisdom.</p> <p>Recently I had a blob of dead. Then I changed the entire hotend piece, after a day it got clogged, so I changed it for a new one today. And this is how is printing now.</p> <p>This is an Ender 3 v3 KE, the filament is Creality's Hyper PLA.</p> <p>Which can be the causes for this bad quality? Specially after some layers they all get like this.</p> <p>Thanks in advance!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/israelaz

## Hourglass made of 252 spheres
 - [https://www.reddit.com/r/3Dprinting/comments/1conmaq/hourglass_made_of_252_spheres](https://www.reddit.com/r/3Dprinting/comments/1conmaq/hourglass_made_of_252_spheres)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T11:48:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1conmaq/hourglass_made_of_252_spheres/"> <img alt="Hourglass made of 252 spheres" src="https://a.thumbs.redditmedia.com/9xFh7wnWiS34ts7ziLqGozInuHa_Ct5B2WinCEjUDf4.jpg" title="Hourglass made of 252 spheres" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Watching-Watches"> /u/Watching-Watches </a> <br /> <span><a href="https://www.printables.com/de/model/874370-hourglass">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1conmaq/hourglass_made_of_252_spheres/">[comments]</a></span> </td></tr></table>

## Borrowed a Dethatcher, Ended Up with a 3D Printing Project!
 - [https://www.reddit.com/r/3Dprinting/comments/1conbwn/borrowed_a_dethatcher_ended_up_with_a_3d_printing](https://www.reddit.com/r/3Dprinting/comments/1conbwn/borrowed_a_dethatcher_ended_up_with_a_3d_printing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T11:31:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1conbwn/borrowed_a_dethatcher_ended_up_with_a_3d_printing/"> <img alt="Borrowed a Dethatcher, Ended Up with a 3D Printing Project!" src="https://a.thumbs.redditmedia.com/vaazWWROG22YVjgFHbpf1yPotqW7CB-zRVV5IlUVxu0.jpg" title="Borrowed a Dethatcher, Ended Up with a 3D Printing Project!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rob_Bob_you_choose"> /u/Rob_Bob_you_choose </a> <br /> <span><a href="https://www.reddit.com/gallery/1conbwn">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1conbwn/borrowed_a_dethatcher_ended_up_with_a_3d_printing/">[comments]</a></span> </td></tr></table>

## Got this old printer working just because I can
 - [https://www.reddit.com/r/3Dprinting/comments/1conblk/got_this_old_printer_working_just_because_i_can](https://www.reddit.com/r/3Dprinting/comments/1conblk/got_this_old_printer_working_just_because_i_can)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T11:31:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1conblk/got_this_old_printer_working_just_because_i_can/"> <img alt="Got this old printer working just because I can" src="https://b.thumbs.redditmedia.com/ZHMcLl1XB9JnJBM6ufMxOxZpeHlCd3-TC29aOR6yszs.jpg" title="Got this old printer working just because I can" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cpufreak101"> /u/cpufreak101 </a> <br /> <span><a href="https://www.reddit.com/gallery/1conblk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1conblk/got_this_old_printer_working_just_because_i_can/">[comments]</a></span> </td></tr></table>

## VTAL MK2 airsoft Battery Box
 - [https://www.reddit.com/r/3Dprinting/comments/1compjx/vtal_mk2_airsoft_battery_box](https://www.reddit.com/r/3Dprinting/comments/1compjx/vtal_mk2_airsoft_battery_box)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T10:54:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1compjx/vtal_mk2_airsoft_battery_box/"> <img alt="VTAL MK2 airsoft Battery Box" src="https://b.thumbs.redditmedia.com/ZtWMRjTRiAF48YUJoI75nx6djGWOoC9tS237GmEYeRI.jpg" title="VTAL MK2 airsoft Battery Box" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ParasitKegel"> /u/ParasitKegel </a> <br /> <span><a href="https://www.reddit.com/gallery/1compjx">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1compjx/vtal_mk2_airsoft_battery_box/">[comments]</a></span> </td></tr></table>

## Most secure way to join two 3d printed tubelike shapes together?
 - [https://www.reddit.com/r/3Dprinting/comments/1comjtb/most_secure_way_to_join_two_3d_printed_tubelike](https://www.reddit.com/r/3Dprinting/comments/1comjtb/most_secure_way_to_join_two_3d_printed_tubelike)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T10:44:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1comjtb/most_secure_way_to_join_two_3d_printed_tubelike/"> <img alt="Most secure way to join two 3d printed tubelike shapes together?" src="https://preview.redd.it/cyfrt0rbvkzc1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=e2f00d870ec95b74cfb7907e18e333e985a68088" title="Most secure way to join two 3d printed tubelike shapes together?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/beckett77"> /u/beckett77 </a> <br /> <span><a href="https://i.redd.it/cyfrt0rbvkzc1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1comjtb/most_secure_way_to_join_two_3d_printed_tubelike/">[comments]</a></span> </td></tr></table>

## My first multicolor print test of my Eastman Turtle model. and an updated WIP image based on the print results.
 - [https://www.reddit.com/r/3Dprinting/comments/1comhf9/my_first_multicolor_print_test_of_my_eastman](https://www.reddit.com/r/3Dprinting/comments/1comhf9/my_first_multicolor_print_test_of_my_eastman)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T10:40:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1comhf9/my_first_multicolor_print_test_of_my_eastman/"> <img alt="My first multicolor print test of my Eastman Turtle model. and an updated WIP image based on the print results." src="https://a.thumbs.redditmedia.com/YH5feC9sR_NLJ7QTN195YKktW_r7FHOWNposWPMWiF4.jpg" title="My first multicolor print test of my Eastman Turtle model. and an updated WIP image based on the print results." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/H2olt"> /u/H2olt </a> <br /> <span><a href="https://www.reddit.com/gallery/1comhf9">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1comhf9/my_first_multicolor_print_test_of_my_eastman/">[comments]</a></span> </td></tr></table>

## 3D printing newbie here, what am I doing wrong?
 - [https://www.reddit.com/r/3Dprinting/comments/1com806/3d_printing_newbie_here_what_am_i_doing_wrong](https://www.reddit.com/r/3Dprinting/comments/1com806/3d_printing_newbie_here_what_am_i_doing_wrong)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T10:23:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1com806/3d_printing_newbie_here_what_am_i_doing_wrong/"> <img alt="3D printing newbie here, what am I doing wrong?" src="https://preview.redd.it/vga7alefskzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2a0c11b438a6c546385d85070ba46de0bf553a60" title="3D printing newbie here, what am I doing wrong?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hey all, I recently got my first 3D printer, the Anycubic Kobra 2 Neo. My first test print was this finger surfboard, which is split in 2 separate halves. After printing both, I noticed that the surface in the middle is not exactly straight, such that the two parts cannot be glued together without this little gap. I am using a brim to make the print stick to the print bed. Any help on that?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dvabecker"> /u/dvabecker </a> <br /> <span><a href="https://i.redd.it/vga7alefskzc1.jpeg

## Honeycomb wall inserts that are very easy to insert and remove.
 - [https://www.reddit.com/r/3Dprinting/comments/1cokckp/honeycomb_wall_inserts_that_are_very_easy_to](https://www.reddit.com/r/3Dprinting/comments/1cokckp/honeycomb_wall_inserts_that_are_very_easy_to)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T08:10:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cokckp/honeycomb_wall_inserts_that_are_very_easy_to/"> <img alt="Honeycomb wall inserts that are very easy to insert and remove." src="https://external-preview.redd.it/NXNld2wzb2o0a3pjMc6TjpIutochVvwhNtUbm02_Bo_ZsWZ0c9aC_FTYRNeB.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f795f7a355f41c759fae623b76a915d4f107cf9e" title="Honeycomb wall inserts that are very easy to insert and remove." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yassenpashov"> /u/yassenpashov </a> <br /> <span><a href="https://v.redd.it/dhsv84oj4kzc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cokckp/honeycomb_wall_inserts_that_are_very_easy_to/">[comments]</a></span> </td></tr></table>

## Am i the only one collecting failed prints and poop?
 - [https://www.reddit.com/r/3Dprinting/comments/1cojoqf/am_i_the_only_one_collecting_failed_prints_and](https://www.reddit.com/r/3Dprinting/comments/1cojoqf/am_i_the_only_one_collecting_failed_prints_and)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T07:23:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cojoqf/am_i_the_only_one_collecting_failed_prints_and/"> <img alt="Am i the only one collecting failed prints and poop?" src="https://preview.redd.it/93sjdbe9wjzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8a90254db52e154012511fe5e3ddd5ff4f24c700" title="Am i the only one collecting failed prints and poop?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/General_Ad8413"> /u/General_Ad8413 </a> <br /> <span><a href="https://i.redd.it/93sjdbe9wjzc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cojoqf/am_i_the_only_one_collecting_failed_prints_and/">[comments]</a></span> </td></tr></table>

## Yesterday learned about Dummy 13. Today been playing with my newly made toy.
 - [https://www.reddit.com/r/3Dprinting/comments/1cojk9k/yesterday_learned_about_dummy_13_today_been](https://www.reddit.com/r/3Dprinting/comments/1cojk9k/yesterday_learned_about_dummy_13_today_been)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T07:14:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cojk9k/yesterday_learned_about_dummy_13_today_been/"> <img alt="Yesterday learned about Dummy 13. Today been playing with my newly made toy." src="https://b.thumbs.redditmedia.com/zC9qsxRupyNFJo4q8hwb--isdPHCnqjJMnbB0w0oxCM.jpg" title="Yesterday learned about Dummy 13. Today been playing with my newly made toy." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/StaticS1gnal"> /u/StaticS1gnal </a> <br /> <span><a href="https://www.printables.com/model/593185-dummy-13-printable-jointed-figure-beta-files">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cojk9k/yesterday_learned_about_dummy_13_today_been/">[comments]</a></span> </td></tr></table>

## THE JOKER - BATMAN (1989) - 3D PRINT MODEL
 - [https://www.reddit.com/r/3Dprinting/comments/1coiif5/the_joker_batman_1989_3d_print_model](https://www.reddit.com/r/3Dprinting/comments/1coiif5/the_joker_batman_1989_3d_print_model)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T06:02:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coiif5/the_joker_batman_1989_3d_print_model/"> <img alt="THE JOKER - BATMAN (1989) - 3D PRINT MODEL" src="https://b.thumbs.redditmedia.com/NVvZTL7aOp6rqMKSiqrrYlJ2N1tigo20KcyHc_5vRPw.jpg" title="THE JOKER - BATMAN (1989) - 3D PRINT MODEL" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Matthew9384"> /u/Matthew9384 </a> <br /> <span><a href="https://www.reddit.com/gallery/1coiif5">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coiif5/the_joker_batman_1989_3d_print_model/">[comments]</a></span> </td></tr></table>

## My first super detailed print
 - [https://www.reddit.com/r/3Dprinting/comments/1coicqf/my_first_super_detailed_print](https://www.reddit.com/r/3Dprinting/comments/1coicqf/my_first_super_detailed_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T05:51:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coicqf/my_first_super_detailed_print/"> <img alt="My first super detailed print" src="https://a.thumbs.redditmedia.com/fImZZj_Nlxxw_M8rGPQhjw3_CYkY_GtGBacqF00Uyt0.jpg" title="My first super detailed print" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Academic_Ad_9326"> /u/Academic_Ad_9326 </a> <br /> <span><a href="https://www.reddit.com/gallery/1coicqf">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coicqf/my_first_super_detailed_print/">[comments]</a></span> </td></tr></table>

## Anyone know where to find a similar project?
 - [https://www.reddit.com/r/3Dprinting/comments/1coh3az/anyone_know_where_to_find_a_similar_project](https://www.reddit.com/r/3Dprinting/comments/1coh3az/anyone_know_where_to_find_a_similar_project)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T04:31:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coh3az/anyone_know_where_to_find_a_similar_project/"> <img alt="Anyone know where to find a similar project?" src="https://external-preview.redd.it/azc5a2Y3aW8xanpjMRLhgTTqUDCj7xmHAX0CLthTym7bdY2cgc-b3irvMgfQ.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=a8e2eaaf3bcb5a800ed4b14413e12df3b11c9f81" title="Anyone know where to find a similar project?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Thought these were really cool and pretty cute. Searched reverse images to find who made it, someone on Twitter with no arduino source code, STLs or CADs. Very sad. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/countjj"> /u/countjj </a> <br /> <span><a href="https://v.redd.it/k6s01vlo1jzc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coh3az/anyone_know_where_to_find_a_similar_project/">[comments]</a></span> </td></tr></table>

## Why do my prints look like macarons?
 - [https://www.reddit.com/r/3Dprinting/comments/1cogtae/why_do_my_prints_look_like_macarons](https://www.reddit.com/r/3Dprinting/comments/1cogtae/why_do_my_prints_look_like_macarons)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T04:15:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cogtae/why_do_my_prints_look_like_macarons/"> <img alt="Why do my prints look like macarons?" src="https://preview.redd.it/zhly6g0pyizc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6564a5fbd861efee4350247d6616c2d266df6b06" title="Why do my prints look like macarons?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I don't know why the weird layers happen like this every time. First few layers seem fine, then a few messed up layers, then back to normal. Using orca slicer on a Ender3 S1</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SmilinBob82"> /u/SmilinBob82 </a> <br /> <span><a href="https://i.redd.it/zhly6g0pyizc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cogtae/why_do_my_prints_look_like_macarons/">[comments]</a></span> </td></tr></table>

## How long will filament on AMS-Lite last in a humid environment like my shed?
 - [https://www.reddit.com/r/3Dprinting/comments/1cofjoz/how_long_will_filament_on_amslite_last_in_a_humid](https://www.reddit.com/r/3Dprinting/comments/1cofjoz/how_long_will_filament_on_amslite_last_in_a_humid)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T03:04:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cofjoz/how_long_will_filament_on_amslite_last_in_a_humid/"> <img alt="How long will filament on AMS-Lite last in a humid environment like my shed?" src="https://preview.redd.it/1zdhes63mizc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5d39dbe695b3f0f3f13781189d81d03cbc295b20" title="How long will filament on AMS-Lite last in a humid environment like my shed?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>As the title says, I am ordering a Bambu A1 w/ AMS-Lite and I want to know if the high humidity will give me problems for the AMS-Lite system specifically? The shed is not insulated, I live in in an area with high heat and high humidity. I will not use multicolor all the time. Would I be better off just skipping the AMS-Lite and later on splurge on something with an enclosed AMS kit? Thanks!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/anon97979jjj"> /u/anon979

## I built a 3D printed Guitar
 - [https://www.reddit.com/r/3Dprinting/comments/1cof20e/i_built_a_3d_printed_guitar](https://www.reddit.com/r/3Dprinting/comments/1cof20e/i_built_a_3d_printed_guitar)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T02:38:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cof20e/i_built_a_3d_printed_guitar/"> <img alt="I built a 3D printed Guitar" src="https://b.thumbs.redditmedia.com/gV4COMaB-b390tpnM1SGpxWwM9n9tVvI8ZrM1s4cpxE.jpg" title="I built a 3D printed Guitar" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jcosta89"> /u/jcosta89 </a> <br /> <span><a href="https://www.reddit.com/gallery/1coeq90">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cof20e/i_built_a_3d_printed_guitar/">[comments]</a></span> </td></tr></table>

## I designed and 3D printed some stands for my gaming figures
 - [https://www.reddit.com/r/3Dprinting/comments/1coevht/i_designed_and_3d_printed_some_stands_for_my](https://www.reddit.com/r/3Dprinting/comments/1coevht/i_designed_and_3d_printed_some_stands_for_my)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T02:28:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coevht/i_designed_and_3d_printed_some_stands_for_my/"> <img alt="I designed and 3D printed some stands for my gaming figures" src="https://b.thumbs.redditmedia.com/65e6vhy-dw49ZhUmGiNb-v6ojSjjiMr3gb9InuMwHMM.jpg" title="I designed and 3D printed some stands for my gaming figures" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JustThatJay13"> /u/JustThatJay13 </a> <br /> <span><a href="https://www.reddit.com/gallery/1coevht">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coevht/i_designed_and_3d_printed_some_stands_for_my/">[comments]</a></span> </td></tr></table>

## "What" ain't no country I've ever heard of
 - [https://www.reddit.com/r/3Dprinting/comments/1coeiyt/what_aint_no_country_ive_ever_heard_of](https://www.reddit.com/r/3Dprinting/comments/1coeiyt/what_aint_no_country_ive_ever_heard_of)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T02:10:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coeiyt/what_aint_no_country_ive_ever_heard_of/"> <img alt="&quot;What&quot; ain't no country I've ever heard of" src="https://preview.redd.it/f654xa7fcizc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8e9af1e63daa5182dcef1e59a2c88ef1e5280440" title="&quot;What&quot; ain't no country I've ever heard of" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/colinwehrle"> /u/colinwehrle </a> <br /> <span><a href="https://i.redd.it/f654xa7fcizc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coeiyt/what_aint_no_country_ive_ever_heard_of/">[comments]</a></span> </td></tr></table>

## What do you think of this grenade launcher that I modeled and printed for my Playmobil? I printed it with a 0.4 nozzle and a layer height of 0.12 in FDM.
 - [https://www.reddit.com/r/3Dprinting/comments/1coe714/what_do_you_think_of_this_grenade_launcher_that_i](https://www.reddit.com/r/3Dprinting/comments/1coe714/what_do_you_think_of_this_grenade_launcher_that_i)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T01:52:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coe714/what_do_you_think_of_this_grenade_launcher_that_i/"> <img alt="What do you think of this grenade launcher that I modeled and printed for my Playmobil? I printed it with a 0.4 nozzle and a layer height of 0.12 in FDM." src="https://b.thumbs.redditmedia.com/V8-rosEhQ--sM4dbzLkp8fvc1p9h9fvbV8gnpBu7PFs.jpg" title="What do you think of this grenade launcher that I modeled and printed for my Playmobil? I printed it with a 0.4 nozzle and a layer height of 0.12 in FDM." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Atomized_creations"> /u/Atomized_creations </a> <br /> <span><a href="https://www.reddit.com/gallery/1coe714">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coe714/what_do_you_think_of_this_grenade_launcher_that_i/">[comments]</a></span> </td></tr></table>

## First multi color print after 8 years of printing
 - [https://www.reddit.com/r/3Dprinting/comments/1cocq5h/first_multi_color_print_after_8_years_of_printing](https://www.reddit.com/r/3Dprinting/comments/1cocq5h/first_multi_color_print_after_8_years_of_printing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T00:38:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1cocq5h/first_multi_color_print_after_8_years_of_printing/"> <img alt="First multi color print after 8 years of printing" src="https://preview.redd.it/6j3jmpy1whzc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9469a8bdf6ca1b115263b3f09027e608a2c203af" title="First multi color print after 8 years of printing" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mre64"> /u/Mre64 </a> <br /> <span><a href="https://i.redd.it/6j3jmpy1whzc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1cocq5h/first_multi_color_print_after_8_years_of_printing/">[comments]</a></span> </td></tr></table>

## Alien VS Predator By Wicked3D
 - [https://www.reddit.com/r/3Dprinting/comments/1coc4ad/alien_vs_predator_by_wicked3d](https://www.reddit.com/r/3Dprinting/comments/1coc4ad/alien_vs_predator_by_wicked3d)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-05-10T00:08:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1coc4ad/alien_vs_predator_by_wicked3d/"> <img alt="Alien VS Predator By Wicked3D" src="https://b.thumbs.redditmedia.com/DMnb_Q0WfVNaef2zkc_7yeZ3sU3UGLvSzAN8WrA814U.jpg" title="Alien VS Predator By Wicked3D" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SoulNightStorm"> /u/SoulNightStorm </a> <br /> <span><a href="https://www.reddit.com/gallery/1coc4ad">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1coc4ad/alien_vs_predator_by_wicked3d/">[comments]</a></span> </td></tr></table>

