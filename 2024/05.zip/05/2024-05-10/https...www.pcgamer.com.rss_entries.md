# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## OpenAI, a company built on 'scraping' content without permission, makes a copyright claim against a subreddit using its logo
 - [https://www.pcgamer.com/software/ai/openai-a-company-built-on-scraping-content-without-permission-makes-a-copyright-claim-against-a-subreddit-using-its-logo](https://www.pcgamer.com/software/ai/openai-a-company-built-on-scraping-content-without-permission-makes-a-copyright-claim-against-a-subreddit-using-its-logo)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T19:34:03+00:00

OpenAIrony is dead.

## Helldivers 2 major order challenges players to scrap 2 billion bots, but Super Earth warns it'll much be harder than last time
 - [https://www.pcgamer.com/games/third-person-shooter/helldivers-2-major-order-challenges-players-to-scrap-2-billion-bots-but-super-earth-warns-itll-much-be-harder-than-last-time](https://www.pcgamer.com/games/third-person-shooter/helldivers-2-major-order-challenges-players-to-scrap-2-billion-bots-but-super-earth-warns-itll-much-be-harder-than-last-time)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T19:26:12+00:00

Our second chance at unlocking Anti-Tank Mines is just two billion bots away.

## Can you guess which 2 mysterious games Deus Ex director Warren Spector secretly worked on, but decided not to be credited for?
 - [https://www.pcgamer.com/gaming-industry/can-you-guess-which-2-mysterious-games-deus-ex-director-warren-spector-secretly-worked-on-but-decided-not-to-be-credited-for](https://www.pcgamer.com/gaming-industry/can-you-guess-which-2-mysterious-games-deus-ex-director-warren-spector-secretly-worked-on-but-decided-not-to-be-credited-for)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T18:16:40+00:00

The Epic Mickey director worked on a pair of games he decided to take his name off of, and he's been keeping them secret.

## The best strategy games on PC
 - [https://www.pcgamer.com/the-best-strategy-games](https://www.pcgamer.com/the-best-strategy-games)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T18:13:58+00:00

From real-time classics to modern turn-based favorites, these are the best strategy games on PC.

## Here's when Homeworld 3 launches in your region
 - [https://www.pcgamer.com/games/rts/homeworld-3-release-time-launch-date-collectors-edition-early-access](https://www.pcgamer.com/games/rts/homeworld-3-release-time-launch-date-collectors-edition-early-access)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T18:07:22+00:00

Get the mothership ready.

## One Manor Lords player is managing a city with over 3,000 residents and just 1 market to 'push the game to the limit'
 - [https://www.pcgamer.com/games/city-builder/one-manor-lords-player-is-managing-a-city-with-over-3000-residents-and-just-1-market-to-push-the-game-to-the-limit](https://www.pcgamer.com/games/city-builder/one-manor-lords-player-is-managing-a-city-with-over-3000-residents-and-just-1-market-to-push-the-game-to-the-limit)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T16:39:56+00:00

Sitting on a knife's edge.

## Gee that Lord of the Rings: Gollum game sucked didn't it, so how about a Gollum movie?
 - [https://www.pcgamer.com/movies-tv/gee-that-gollum-game-sucked-didnt-it-so-how-about-a-gollum-movie](https://www.pcgamer.com/movies-tv/gee-that-gollum-game-sucked-didnt-it-so-how-about-a-gollum-movie)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T16:38:02+00:00

Warner Bros. cranks up the marketing machine once more on the precious.

## Brace yourself, EA is thinking real hard about inserting ads into its videogames
 - [https://www.pcgamer.com/games/brace-yourself-ea-is-thinking-real-hard-about-inserting-ads-into-its-videogames](https://www.pcgamer.com/games/brace-yourself-ea-is-thinking-real-hard-about-inserting-ads-into-its-videogames)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T16:09:24+00:00

CEO Andrew Wilson was asked about in-game ads in a recent earnings call.

## President of Xbox at Microsoft asked about the closure of Hi-Fi Rush developer Tango Gameworks, spends close to a minute saying almost nothing
 - [https://www.pcgamer.com/gaming-industry/president-of-xbox-at-microsoft-asked-about-the-closure-of-hi-fi-rush-developer-tango-gameworks-spends-close-to-a-minute-saying-almost-nothing](https://www.pcgamer.com/gaming-industry/president-of-xbox-at-microsoft-asked-about-the-closure-of-hi-fi-rush-developer-tango-gameworks-spends-close-to-a-minute-saying-almost-nothing)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T16:08:02+00:00

Something something, long-term commitment.

## AMD's gaming graphics business looks like it's in terminal decline
 - [https://www.pcgamer.com/hardware/graphics-cards/amds-gaming-graphics-business-looks-like-its-in-terminal-decline](https://www.pcgamer.com/hardware/graphics-cards/amds-gaming-graphics-business-looks-like-its-in-terminal-decline)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T15:20:38+00:00

There's no getting round it, the Radeon RX 7000 GPU family looks like a disaster.

## Manor Lords' new massive patch stops your villagers from partying too hard and introduces players to the woeful world of the King's Tax
 - [https://www.pcgamer.com/games/city-builder/manor-lords-first-massive-patch-stops-your-villagers-from-partying-too-hard-and-introduces-players-to-the-woeful-world-of-the-kings-tax](https://www.pcgamer.com/games/city-builder/manor-lords-first-massive-patch-stops-your-villagers-from-partying-too-hard-and-introduces-players-to-the-woeful-world-of-the-kings-tax)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T14:59:40+00:00

Party-rocked too close to the sun.

## Despite being just a humble CPU socket, AMD 'boldly suggests' AM4 has 'legendary status'
 - [https://www.pcgamer.com/hardware/processors/despite-being-just-a-humble-cpu-socket-amd-boldly-suggests-am4-has-legendary-status](https://www.pcgamer.com/hardware/processors/despite-being-just-a-humble-cpu-socket-amd-boldly-suggests-am4-has-legendary-status)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T14:38:27+00:00

Few other CPU sockets have lasted as long or supported as many chips as this one, but its history isn't entirely free of hiccups.

## The largely forgotten Fallout demo, which features completely unique content not found in the main game, is a free must-play for any serious Fallout fan
 - [https://www.pcgamer.com/games/rpg/the-largely-forgotten-fallout-demo-which-features-completely-unique-content-not-found-in-the-main-game-is-a-free-must-play-for-any-serious-fallout-fan](https://www.pcgamer.com/games/rpg/the-largely-forgotten-fallout-demo-which-features-completely-unique-content-not-found-in-the-main-game-is-a-free-must-play-for-any-serious-fallout-fan)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T14:19:36+00:00

Download it now and dive into a unique slice of OG Fallout action

## Former Dragon Age lead writer David Gaider pours scorn on EA's AI dreams: 'What they took as excitement was really a veiled wail of despair'
 - [https://www.pcgamer.com/gaming-industry/former-dragon-age-lead-writer-david-gaider-pours-scorn-on-eas-ai-dreams-what-they-took-as-excitement-was-really-a-veiled-wail-of-despair](https://www.pcgamer.com/gaming-industry/former-dragon-age-lead-writer-david-gaider-pours-scorn-on-eas-ai-dreams-what-they-took-as-excitement-was-really-a-veiled-wail-of-despair)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T14:17:07+00:00

Gaider remembers how excited execs were for live service games like Anthem, and reckons they're just repeating a pattern.

## 'Everyone and their mum' is playing Hades 2, which is exactly why The Rogue Prince of Persia is delayed
 - [https://www.pcgamer.com/games/roguelike/everyone-and-their-mum-is-playing-hades-2-which-is-exactly-why-the-rogue-prince-of-persia-is-delayed](https://www.pcgamer.com/games/roguelike/everyone-and-their-mum-is-playing-hades-2-which-is-exactly-why-the-rogue-prince-of-persia-is-delayed)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T14:10:15+00:00

Honestly, fair play.

## 'A number of threads retracted from the brain' of Neuralink's first implant patient, but they say they're still 'beating my friends in games that as a quadriplegic I should not be beating them in'
 - [https://www.pcgamer.com/hardware/a-number-of-threads-retracted-from-the-brain-of-neuralinks-first-implant-patient-but-they-say-theyre-still-beating-my-friends-in-games-that-as-a-quadriplegic-i-should-not-be-beating-them-in](https://www.pcgamer.com/hardware/a-number-of-threads-retracted-from-the-brain-of-neuralinks-first-implant-patient-but-they-say-theyre-still-beating-my-friends-in-games-that-as-a-quadriplegic-i-should-not-be-beating-them-in)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T12:20:53+00:00

Small setbacks and brain implants strikes as a potentially disastrous combo, but the trial still seems like a success so far.

## Resident Evil modders and the biggest fighting game channel on YouTube join forces to remedy a 26-year-old April Fools' joke
 - [https://www.pcgamer.com/games/resident-evil/resident-evil-modders-and-the-biggest-fighting-game-channel-on-youtube-join-forces-to-remedy-a-26-year-old-april-fools-joke](https://www.pcgamer.com/games/resident-evil/resident-evil-modders-and-the-biggest-fighting-game-channel-on-youtube-join-forces-to-remedy-a-26-year-old-april-fools-joke)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T11:48:30+00:00

An urban legend no more.

## You can buy Prey, Fallout: New Vegas, and Fallout 3 at just under $2 a pop right now—that's 3 games for less than I'll be spending on lunch today
 - [https://www.pcgamer.com/games/rpg/you-can-buy-prey-fallout-new-vegas-and-fallout-3-at-just-under-dollar2-a-pop-right-nowthats-3-games-for-less-than-ill-be-spending-on-lunch-today](https://www.pcgamer.com/games/rpg/you-can-buy-prey-fallout-new-vegas-and-fallout-3-at-just-under-dollar2-a-pop-right-nowthats-3-games-for-less-than-ill-be-spending-on-lunch-today)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T11:30:18+00:00

The trinity bundle has a lot of other good titles, too.

## Steam Deck update brings improved graphics driver for better performance, along with fixes and features galore
 - [https://www.pcgamer.com/hardware/handheld-gaming-pcs/steam-deck-update-brings-improved-graphics-driver-for-better-performance-along-with-fixes-and-features-galore](https://www.pcgamer.com/hardware/handheld-gaming-pcs/steam-deck-update-brings-improved-graphics-driver-for-better-performance-along-with-fixes-and-features-galore)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T11:03:03+00:00

It's SteamOS update day, at least for those of you on the preview channel.

## Fallout 3, the objectively 5th-best Fallout game, is free to keep via Twitch Prime right now
 - [https://www.pcgamer.com/games/fallout/fallout-3-the-objectively-5th-best-fallout-game-is-free-to-keep-via-twitch-prime-right-now](https://www.pcgamer.com/games/fallout/fallout-3-the-objectively-5th-best-fallout-game-is-free-to-keep-via-twitch-prime-right-now)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T10:58:28+00:00

My scientific ranking of the Fallouts in the guise of PSA posts continues.

## Watch out Intel and AMD, more Arm chips are coming to the PC
 - [https://www.pcgamer.com/hardware/processors/watch-out-intel-and-amd-more-arm-chips-are-coming-to-the-pc](https://www.pcgamer.com/hardware/processors/watch-out-intel-and-amd-more-arm-chips-are-coming-to-the-pc)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T10:41:50+00:00

Could Nvidia be one of the other manufacturers planning to join Qualcomm in offering PC-specific Arm-based CPUs?

## Solo players, it's not just you: 1-player missions in Helldivers 2 currently have 4-player patrol spawn times
 - [https://www.pcgamer.com/games/third-person-shooter/solo-players-its-not-just-you-1-player-missions-in-helldivers-2-currently-have-4-player-patrol-spawn-times](https://www.pcgamer.com/games/third-person-shooter/solo-players-its-not-just-you-1-player-missions-in-helldivers-2-currently-have-4-player-patrol-spawn-times)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T10:34:12+00:00

2:45.

## How to summon Andariel in Diablo 4
 - [https://www.pcgamer.com/games/action/diablo-4-andariel-sandscorched-shackles-pincushioned-dolls](https://www.pcgamer.com/games/action/diablo-4-andariel-sandscorched-shackles-pincushioned-dolls)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T10:21:52+00:00

Gather Sandscorched Shackles and Pincushioned Dolls to fight this new boss in season four.

## Beta teething issues aside, Discord's Roll20 activity for running D&D and other RPGs inside the app works great
 - [https://www.pcgamer.com/games/rpg/beta-teething-issues-aside-discords-roll20-activity-for-running-dandd-and-other-rpgs-inside-the-app-works-great](https://www.pcgamer.com/games/rpg/beta-teething-issues-aside-discords-roll20-activity-for-running-dandd-and-other-rpgs-inside-the-app-works-great)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T03:30:09+00:00

They see me rollin'.

## Today's Wordle answer for Friday, May 10
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-may-10-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-may-10-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-05-10T03:00:36+00:00

Get all the help you need with today's Wordle.

