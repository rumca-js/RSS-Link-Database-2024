# Source:Na Gałęzi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtecHyLSXoL3P-xgFsbQh-g, language:pl

## Królestwo Planety Małp - fani serii nie będą zawiedzeni
 - [https://www.youtube.com/watch?v=UkaX6_h2eAA](https://www.youtube.com/watch?v=UkaX6_h2eAA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtecHyLSXoL3P-xgFsbQh-g
 - date published: 2024-05-10T14:21:59+00:00

Na Gałęzi na Instagramie - https://www.instagram.com/mlukanski/

Królestwo Planety Małp powinno zadowolić wszystkich fanów serii. Jest to film naprawdę nieźle zrealizowany, jednak równocześnie nie jest pozbawiony drobnych problemów. Zapraszam na recenzję!

