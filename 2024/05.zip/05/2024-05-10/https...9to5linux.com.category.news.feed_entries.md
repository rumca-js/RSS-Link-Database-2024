# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## GNOME 47 Desktop Environment Release Date Slated for September 18th, 2024
 - [https://9to5linux.com/gnome-47-desktop-environment-release-date-slated-for-september-18th-2024](https://9to5linux.com/gnome-47-desktop-environment-release-date-slated-for-september-18th-2024)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-10T17:15:25+00:00

<p>The upcoming GNOME 47 desktop environment has a release schedule with a release date set for September 18th, 2024. Here's what to expect!</p>
<p>The post <a href="https://9to5linux.com/gnome-47-desktop-environment-release-date-slated-for-september-18th-2024">GNOME 47 Desktop Environment Release Date Slated for September 18th, 2024</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## KDE Frameworks 6.2 Released with Many Improvements for Plasma 6 Users
 - [https://9to5linux.com/kde-frameworks-6-2-released-with-many-improvements-for-plasma-6-users](https://9to5linux.com/kde-frameworks-6-2-released-with-many-improvements-for-plasma-6-users)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-10T16:30:07+00:00

<p>KDE Frameworks 6.2 is now available as another update to prepare Plasma users for the upcoming KDE Plasma 6.1 desktop environment release. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/kde-frameworks-6-2-released-with-many-improvements-for-plasma-6-users">KDE Frameworks 6.2 Released with Many Improvements for Plasma 6 Users</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## LibreOffice 7.6.7 Is Here as the Last Update in the Series, Upgrade to LibreOffice 24.2
 - [https://9to5linux.com/libreoffice-7-6-7-is-here-as-the-last-update-in-the-series-upgrade-to-libreoffice-24-2](https://9to5linux.com/libreoffice-7-6-7-is-here-as-the-last-update-in-the-series-upgrade-to-libreoffice-24-2)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-10T14:58:56+00:00

<p>LibreOffice 7.6.7 is now available for download as the last update in the LibreOffice 7.6 office suite series fixing 44 bugs and regressions. Users are urged to upgrade to LibreOffice 24.2.</p>
<p>The post <a href="https://9to5linux.com/libreoffice-7-6-7-is-here-as-the-last-update-in-the-series-upgrade-to-libreoffice-24-2">LibreOffice 7.6.7 Is Here as the Last Update in the Series, Upgrade to LibreOffice 24.2</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Rocky Linux 9.4 Released as Another Free Red Hat Enterprise Linux 9.4 Distro
 - [https://9to5linux.com/rocky-linux-9-4-released-as-another-free-red-hat-enterprise-linux-9-4-distro](https://9to5linux.com/rocky-linux-9-4-released-as-another-free-red-hat-enterprise-linux-9-4-distro)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-05-10T13:12:06+00:00

<p>Rocky Linux 9.4 distribution is now avaiable for download as a free and open-source alternative to Red Hat Enterprise Linux 9.4. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/rocky-linux-9-4-released-as-another-free-red-hat-enterprise-linux-9-4-distro">Rocky Linux 9.4 Released as Another Free Red Hat Enterprise Linux 9.4 Distro</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

