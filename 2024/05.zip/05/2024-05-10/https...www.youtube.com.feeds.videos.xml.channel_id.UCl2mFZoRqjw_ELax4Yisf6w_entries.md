# Source:Louis Rossmann, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## FUTO funds Immich with 3 year commitment: the best image gallery software
 - [https://www.youtube.com/watch?v=uyTPqxgqgjU](https://www.youtube.com/watch?v=uyTPqxgqgjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2024-05-10T17:16:26+00:00

https://futo.org/what-is-futo/
https://immich.app/
https://github.com/immich-app/immich
https://youtu.be/CE0EB5bXj14
https://www.nytimes.com/2022/08/21/technology/google-surveillance-toddler-photo.html
https://digitalcontentnext.org/wp-content/uploads/2018/08/DCN-Google-Data-Collection-Paper.pdf

