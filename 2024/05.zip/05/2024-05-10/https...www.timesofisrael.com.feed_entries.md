# Source:The Times of Israel, URL:https://www.timesofisrael.com/feed, language:en-US

## Hezbollah fires barrage of rockets at Kiryat Shmona, causing blazes, property damage
 - [https://www.timesofisrael.com/hezbollah-fires-barrage-of-rockets-at-kiryat-shmona-causing-blazes-property-damage](https://www.timesofisrael.com/hezbollah-fires-barrage-of-rockets-at-kiryat-shmona-causing-blazes-property-damage)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T19:34:57+00:00

<p>Military says out of 35 rockets launched, 15 downed by Iron Dome; terror group says salvo in response to killing of technician, rescue worker for Hezbollah ally</p>
<p>The post <a href="https://www.timesofisrael.com/hezbollah-fires-barrage-of-rockets-at-kiryat-shmona-causing-blazes-property-damage/">Hezbollah fires barrage of rockets at Kiryat Shmona, causing blazes, property damage</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/F240510AMA16-1024x640.jpg" title="Hezbollah fires barrage of rockets at Kiryat Shmona, causing blazes, property damage" width="160" /></figure>

## ‘Is your fav author a zionist?’: Viral list sparks antisemitism fears among authors
 - [https://www.timesofisrael.com/is-your-fav-author-a-zionist-viral-list-sparks-antisemitism-fears-among-authors](https://www.timesofisrael.com/is-your-fav-author-a-zionist-viral-list-sparks-antisemitism-fears-among-authors)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T19:22:14+00:00

<p>List posted online categorizes writers as 'Pro-Israel/Zionist,' 'Pro-Palestinian/Anti-Zionist,' various types of 'It’s complicated,' or 'Both sides-ing it'</p>
<p>The post <a href="https://www.timesofisrael.com/is-your-fav-author-a-zionist-viral-list-sparks-antisemitism-fears-among-authors/">&#8216;Is your fav author a zionist?&#8217;: Viral list sparks antisemitism fears among authors</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/Screenshot-2024-05-10-184010-e1715355953589-1024x640.png" title="&#8216;Is your fav author a zionist?&#8217;: Viral list sparks antisemitism fears among authors" width="160" /></figure>

## ‘We cannot undermine our ally Israel’: 26 Democrats pan Biden’s hold up of weapons
 - [https://www.timesofisrael.com/we-cannot-undermine-our-ally-israel-26-democrats-pan-bidens-hold-up-of-weapons](https://www.timesofisrael.com/we-cannot-undermine-our-ally-israel-26-democrats-pan-bidens-hold-up-of-weapons)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T18:55:58+00:00

<p>In letter to White House, pro-Israel legislators concerned about the message it sends to Iranian proxies; in contrast, progressive Jewish Senator Sanders applauds measure</p>
<p>The post <a href="https://www.timesofisrael.com/we-cannot-undermine-our-ally-israel-26-democrats-pan-bidens-hold-up-of-weapons/">&#8216;We cannot undermine our ally Israel&#8217;: 26 Democrats pan Biden&#8217;s hold up of weapons</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/11-03-2023-Wasserman-Schultz-Gottheimer-e1715363035638-1024x640.jpg" title="&#8216;We cannot undermine our ally Israel&#8217;: 26 Democrats pan Biden&#8217;s hold up of weapons" width="160" /></figure>

## UN General Assembly adopts resolution boosting standing of Palestinian mission
 - [https://www.timesofisrael.com/un-general-assembly-adopts-resolution-boosting-standing-of-palestinian-mission](https://www.timesofisrael.com/un-general-assembly-adopts-resolution-boosting-standing-of-palestinian-mission)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T18:10:39+00:00

<p>Symbolic move gives Palestinians spot in UNGA's member's hall, but not voting rights; FM Katz labels move a 'prize for Hamas'; Palestinian UN envoy calls it 'investment in peace'</p>
<p>The post <a href="https://www.timesofisrael.com/un-general-assembly-adopts-resolution-boosting-standing-of-palestinian-mission/">UN General Assembly adopts resolution boosting standing of Palestinian mission</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AFP__20240510__34RB7LR__v4__HighRes__UnPalestinianIsraelConflictDiplomacy-e1715359624229-1024x640.jpg" title="UN General Assembly adopts resolution boosting standing of Palestinian mission" width="160" /></figure>

## Who are Israel’s key weapons suppliers, and who has halted exports since Oct. 7?
 - [https://www.timesofisrael.com/who-are-israels-key-weapons-suppliers-and-who-has-halted-exports-since-oct-7](https://www.timesofisrael.com/who-are-israels-key-weapons-suppliers-and-who-has-halted-exports-since-oct-7)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T17:35:11+00:00

<p>Billions of dollars of munitions still coming from US despite partial halt; since beginning of year, German weapon exports have slowed, while Italy has stopped fresh approvals</p>
<p>The post <a href="https://www.timesofisrael.com/who-are-israels-key-weapons-suppliers-and-who-has-halted-exports-since-oct-7/">Who are Israel&#8217;s key weapons suppliers, and who has halted exports since Oct. 7?</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/AP23286548577775-1024x640.jpg" title="Who are Israel&#8217;s key weapons suppliers, and who has halted exports since Oct. 7?" width="160" /></figure>

## After Biden arms freeze, Israel can still fight in Rafah. Lebanon is a different story
 - [https://www.timesofisrael.com/after-biden-arms-freeze-israel-can-still-fight-in-rafah-lebanon-is-a-different-story](https://www.timesofisrael.com/after-biden-arms-freeze-israel-can-still-fight-in-rafah-lebanon-is-a-different-story)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T16:21:21+00:00

<p>Stuck in a long war against Hamas, Israel needs a steady US weapons supply to be prepared for a war on Hezbollah -- which is now likely to be more aggressive </p>
<p>The post <a href="https://www.timesofisrael.com/after-biden-arms-freeze-israel-can-still-fight-in-rafah-lebanon-is-a-different-story/">After Biden arms freeze, Israel can still fight in Rafah. Lebanon is a different story</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/10/33XX97N-highres-e1715345405124-1024x640.jpg" title="After Biden arms freeze, Israel can still fight in Rafah. Lebanon is a different story" width="160" /></figure>

## Gallant blasts Smotrich for mid-war holdup of fighter jet procurement
 - [https://www.timesofisrael.com/gallant-blasts-smotrich-for-mid-war-holdup-of-fighter-jet-procurement](https://www.timesofisrael.com/gallant-blasts-smotrich-for-mid-war-holdup-of-fighter-jet-procurement)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T16:20:36+00:00

<p>Finance minister doubles down, saying he seeks to convene committee tasked with looking at defense budget before approving purchase of F-15s, F-35s</p>
<p>The post <a href="https://www.timesofisrael.com/gallant-blasts-smotrich-for-mid-war-holdup-of-fighter-jet-procurement/">Gallant blasts Smotrich for mid-war holdup of fighter jet procurement</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/F231226CG128-1024x640.jpg" title="Gallant blasts Smotrich for mid-war holdup of fighter jet procurement" width="160" /></figure>

## 12 soldiers stung by wasp swarm after tank runs over nest in southern Gaza
 - [https://www.timesofisrael.com/12-soldiers-stung-by-wasp-swarm-after-tank-runs-over-nest-in-southern-gaza](https://www.timesofisrael.com/12-soldiers-stung-by-wasp-swarm-after-tank-runs-over-nest-in-southern-gaza)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T16:08:05+00:00

<p>In unusual incident, Sheba Hospital admits 10 of the soldiers for treatment, with one sent to ICU, says some were stung by hundreds of the insects, but none in critical danger</p>
<p>The post <a href="https://www.timesofisrael.com/12-soldiers-stung-by-wasp-swarm-after-tank-runs-over-nest-in-southern-gaza/">12 soldiers stung by wasp swarm after tank runs over nest in southern Gaza</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24129537933428-e1715353902941-1024x640.jpg" title="12 soldiers stung by wasp swarm after tank runs over nest in southern Gaza" width="160" /></figure>

## In 1st, PM accepts some responsibility for Oct. 7: ‘I hold myself and everyone on this’
 - [https://www.timesofisrael.com/in-1st-pm-accepts-some-responsibility-for-oct-7-i-hold-myself-and-everyone-on-this](https://www.timesofisrael.com/in-1st-pm-accepts-some-responsibility-for-oct-7-i-hold-myself-and-everyone-on-this)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T15:52:00+00:00

<p>Netanyahu coaxed into admission in an interview with Dr. Phil after asserting for months that he'd wait for post-war commission before speaking of own role in allowing onslaught</p>
<p>The post <a href="https://www.timesofisrael.com/in-1st-pm-accepts-some-responsibility-for-oct-7-i-hold-myself-and-everyone-on-this/">In 1st, PM accepts some responsibility for Oct. 7: &#8216;I hold myself and everyone on this&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/Screenshot-2024-05-10-at-9.12.40-AM-1024x640.jpg" title="In 1st, PM accepts some responsibility for Oct. 7: &#8216;I hold myself and everyone on this&#8217;" width="160" /></figure>

## Four IDF soldiers killed as battles rage across Gaza; tanks said to advance into Rafah
 - [https://www.timesofisrael.com/four-idf-soldiers-killed-as-battles-rage-across-gaza-tanks-said-to-advance-into-rafah](https://www.timesofisrael.com/four-idf-soldiers-killed-as-battles-rage-across-gaza-tanks-said-to-advance-into-rafah)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T15:26:02+00:00

<p>Security cabinet said to approve measured expansion of op in southern part of Strip, risking clash with Biden; dozens of gunmen killed in fighting, tunnels found</p>
<p>The post <a href="https://www.timesofisrael.com/four-idf-soldiers-killed-as-battles-rage-across-gaza-tanks-said-to-advance-into-rafah/">Four IDF soldiers killed as battles rage across Gaza; tanks said to advance into Rafah</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/Fallen-4-faces-1024x640.jpeg" title="Four IDF soldiers killed as battles rage across Gaza; tanks said to advance into Rafah" width="160" /></figure>

## Environmentalists attack case holding Magna Carta copy in London, document unharmed
 - [https://www.timesofisrael.com/environmentalists-attack-case-holding-magna-carta-copy-in-london-document-unharmed](https://www.timesofisrael.com/environmentalists-attack-case-holding-magna-carta-copy-in-london-document-unharmed)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T14:52:09+00:00

<p>Octogenarian activists attempted to break reinforced glass case housing one of the founding documents of Western democracy with a hammer and a chisel</p>
<p>The post <a href="https://www.timesofisrael.com/environmentalists-attack-case-holding-magna-carta-copy-in-london-document-unharmed/">Environmentalists attack case holding Magna Carta copy in London, document unharmed</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/Screenshot-2024-05-10-195326-1024x640.png" title="Environmentalists attack case holding Magna Carta copy in London, document unharmed" width="160" /></figure>

## With their jobs on the line, Biden and Netanyahu tested to push through fraught ties
 - [https://www.timesofisrael.com/with-their-jobs-on-the-line-biden-and-netanyahu-tested-to-push-through-fraught-ties](https://www.timesofisrael.com/with-their-jobs-on-the-line-biden-and-netanyahu-tested-to-push-through-fraught-ties)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T14:31:00+00:00

<p>US president acting more assertively to rein in Rafah op, which PM sees as key to his own political survival, but Biden aides assert ties will not be fully broken on his watch</p>
<p>The post <a href="https://www.timesofisrael.com/with-their-jobs-on-the-line-biden-and-netanyahu-tested-to-push-through-fraught-ties/">With their jobs on the line, Biden and Netanyahu tested to push through fraught ties</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/biden-bibi-1024x640.jpg" title="With their jobs on the line, Biden and Netanyahu tested to push through fraught ties" width="160" /></figure>

## Police dismantle anti-Israel encampment at MIT,  begin clearing at other campuses
 - [https://www.timesofisrael.com/police-dismantle-anti-israel-encampment-at-mit-begin-clearing-at-other-campuses](https://www.timesofisrael.com/police-dismantle-anti-israel-encampment-at-mit-begin-clearing-at-other-campuses)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T14:30:21+00:00

<p>Police in riot gear also clear out encampments at Penn and University of Arizona; MIT president says encampment 'no longer safely sustainable'</p>
<p>The post <a href="https://www.timesofisrael.com/police-dismantle-anti-israel-encampment-at-mit-begin-clearing-at-other-campuses/">Police dismantle anti-Israel encampment at MIT,  begin clearing at other campuses</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24131351488475-1-1024x640.jpg" title="Police dismantle anti-Israel encampment at MIT,  begin clearing at other campuses" width="160" /></figure>

## A Palestinian-American’s call for compromise strikes a chord on social media
 - [https://www.timesofisrael.com/a-palestinian-americans-call-for-compromise-strikes-a-chord-on-social-media](https://www.timesofisrael.com/a-palestinian-americans-call-for-compromise-strikes-a-chord-on-social-media)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T13:40:36+00:00

<p>Profanity-laden overview by Mo Husseini -- a distant relative of the infamous Mufti of Jerusalem -- spares neither side, enticing the 'silent majority' with commonsensical optimism</p>
<p>The post <a href="https://www.timesofisrael.com/a-palestinian-americans-call-for-compromise-strikes-a-chord-on-social-media/">A Palestinian-American’s call for compromise strikes a chord on social media</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/Israel-Palestine-guy-1024x640.jpg" title="A Palestinian-American’s call for compromise strikes a chord on social media" width="160" /></figure>

## Borrell: Other EU countries to follow Spain and Ireland recognizing Palestinian state
 - [https://www.timesofisrael.com/borrell-other-eu-countries-to-follow-spain-and-ireland-recognizing-palestinian-state](https://www.timesofisrael.com/borrell-other-eu-countries-to-follow-spain-and-ireland-recognizing-palestinian-state)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T13:37:40+00:00

<p>Ahead of UN vote on Palestinian membership, union's foreign policy chief says Slovenia, Belgium to take steps toward recognition with Dublin, Madrid set to make move on May 21</p>
<p>The post <a href="https://www.timesofisrael.com/borrell-other-eu-countries-to-follow-spain-and-ireland-recognizing-palestinian-state/">Borrell: Other EU countries to follow Spain and Ireland recognizing Palestinian state</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24128299954191-e1715345345893-1024x640.jpg" title="Borrell: Other EU countries to follow Spain and Ireland recognizing Palestinian state" width="160" /></figure>

## Northern residents plan to ‘disengage’ from Israel in Independence Day protest
 - [https://www.timesofisrael.com/northern-residents-plan-to-disengage-from-israel-in-independence-day-protest](https://www.timesofisrael.com/northern-residents-plan-to-disengage-from-israel-in-independence-day-protest)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T13:28:43+00:00

<p>Residents and communities to hold a series of protests against government's inability to allow some 60,000 residents, evacuated due to border fighting, to return to their homes </p>
<p>The post <a href="https://www.timesofisrael.com/northern-residents-plan-to-disengage-from-israel-in-independence-day-protest/">Northern residents plan to &#8216;disengage&#8217; from Israel in Independence Day protest</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/F240505DC32-1024x640.jpg" title="Northern residents plan to &#8216;disengage&#8217; from Israel in Independence Day protest" width="160" /></figure>

## Aiming for divestment, Pro-Palestinian students push schools to open books on Israel
 - [https://www.timesofisrael.com/aiming-for-divestment-pro-palestinian-students-push-schools-to-open-books-on-israel](https://www.timesofisrael.com/aiming-for-divestment-pro-palestinian-students-push-schools-to-open-books-on-israel)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T12:22:32+00:00

<p>Protesters demand university endowments disclose assets linked to Israeli companies or those doing business with Jerusalem, though colleges have many reasons to resist calls</p>
<p>The post <a href="https://www.timesofisrael.com/aiming-for-divestment-pro-palestinian-students-push-schools-to-open-books-on-israel/">Aiming for divestment, Pro-Palestinian students push schools to open books on Israel</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24130832188296-1024x640.jpg" title="Aiming for divestment, Pro-Palestinian students push schools to open books on Israel" width="160" /></figure>

## Hamas says no budging from already-rejected hostage deal offer as Cairo talks break up
 - [https://www.timesofisrael.com/hamas-says-no-budging-from-already-rejected-hostage-deal-offer-as-cairo-talks-break-up](https://www.timesofisrael.com/hamas-says-no-budging-from-already-rejected-hostage-deal-offer-as-cairo-talks-break-up)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T11:00:29+00:00

<p>Terror group claims 'ball in the hands of the occupation' after team decamps for Doha while insisting it will not make any concessions; Egypt says flexibility needed on both sides</p>
<p>The post <a href="https://www.timesofisrael.com/hamas-says-no-budging-from-already-rejected-hostage-deal-offer-as-cairo-talks-break-up/">Hamas says no budging from already-rejected hostage deal offer as Cairo talks break up</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/F240509AVS147-1024x640.jpg" title="Hamas says no budging from already-rejected hostage deal offer as Cairo talks break up" width="160" /></figure>

## UNRWA shuts Jerusalem headquarters after Israelis allegedly set fire in compound
 - [https://www.timesofisrael.com/unrwa-shuts-jerusalem-headquarters-after-israelis-allegedly-set-fire-in-compound](https://www.timesofisrael.com/unrwa-shuts-jerusalem-headquarters-after-israelis-allegedly-set-fire-in-compound)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T10:46:15+00:00

<p>Head of UN agency for Palestinian refugees says facility to remain closed until 'proper security' restored, accusing armed Israeli extremists of threatening and harassing staff</p>
<p>The post <a href="https://www.timesofisrael.com/unrwa-shuts-jerusalem-headquarters-after-israelis-allegedly-set-fire-in-compound/">UNRWA shuts Jerusalem headquarters after Israelis allegedly set fire in compound</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/F240327YS01-1024x640.jpg" title="UNRWA shuts Jerusalem headquarters after Israelis allegedly set fire in compound" width="160" /></figure>

## Daily Briefing May 10, Day 217: Blinken report to exonerate Israel; will US arms follow?
 - [https://www.timesofisrael.com/daily-briefing-may-10-day-217-blinken-report-to-exonerate-israel-will-us-arms-follow](https://www.timesofisrael.com/daily-briefing-may-10-day-217-blinken-report-to-exonerate-israel-will-us-arms-follow)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T10:43:03+00:00

<p>US bureau chief Jacob Magid on reports of overdue report to Congress and cognitive dissonance in American and Israeli views of Rafah; news editor Amy Spiro on all things Eurovision</p>
<p>The post <a href="https://www.timesofisrael.com/daily-briefing-may-10-day-217-blinken-report-to-exonerate-israel-will-us-arms-follow/">Daily Briefing May 10, Day 217: Blinken report to exonerate Israel; will US arms follow?</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/F240509FFF015-1024x640.jpg" title="Daily Briefing May 10, Day 217: Blinken report to exonerate Israel; will US arms follow?" width="160" /></figure>

## World Values Network, ZOA invite you to Yom HaZikaron, Yom Haatzmaut Events in NYC - Sponsored Content
 - [https://toi.li/dY4qF2](https://toi.li/dY4qF2)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T10:20:31+00:00

<p>Memorial event for Israel's fallen heroes followed by an outdoor concert for Israel's 76th Independence Day Celebration</p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/world-values-network-zoa-invite-you-to-yom-hazikaron-yom-haatzmaut-events-in-nyc/">World Values Network, ZOA invite you to Yom HaZikaron, Yom Haatzmaut Events in NYC</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/Screenshot-2024-05-10-at-12.42.21-1024x640.png" title="World Values Network, ZOA invite you to Yom HaZikaron, Yom Haatzmaut Events in NYC" width="160" /></figure>

## Report: State Department set to confirm Israel not breaking international law in Gaza
 - [https://www.timesofisrael.com/report-state-department-set-to-confirm-israel-not-breaking-international-law-in-gaza](https://www.timesofisrael.com/report-state-department-set-to-confirm-israel-not-breaking-international-law-in-gaza)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T07:55:00+00:00

<p>Overdue filing, which could be sent as early as Friday, will use critical language to describe suspected violations, but won't find Israel misusing arms or blocking aid, Axios says</p>
<p>The post <a href="https://www.timesofisrael.com/report-state-department-set-to-confirm-israel-not-breaking-international-law-in-gaza/">Report: State Department set to confirm Israel not breaking international law in Gaza</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AFP__20240510__34RA7PD__v1__HighRes__PalestinianIsraelConflict-1024x640.jpg" title="Report: State Department set to confirm Israel not breaking international law in Gaza" width="160" /></figure>

## New dark comedy for stage asks: Was Bulgaria’s King Boris III friend or foe to the Jews?
 - [https://www.timesofisrael.com/new-dark-comedy-for-stage-asks-was-bulgarias-king-boris-iii-friend-or-foe-to-the-jews](https://www.timesofisrael.com/new-dark-comedy-for-stage-asks-was-bulgarias-king-boris-iii-friend-or-foe-to-the-jews)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T07:44:56+00:00

<p>The paradoxical leader dabbled in fascism, was loved by his people, saved 50,000 lives while enacting antisemitic laws, and is the subject of a play running in NYC through June 2</p>
<p>The post <a href="https://www.timesofisrael.com/new-dark-comedy-for-stage-asks-was-bulgarias-king-boris-iii-friend-or-foe-to-the-jews/">New dark comedy for stage asks: Was Bulgaria’s King Boris III friend or foe to the Jews?</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/CROPDavid-Leopold-Sasha-Wilson-Joseph-Cullen-Lawrence-Boothman-Clare-Fraenkel-in-THE-BRIEF-LIFE-MYSTERIOUS-DEATH-OF-BORIS-III-KING-OF-BULGARIA-Photo-by-Carol-Rosegg-2048x1138-1-1024x640.jpg" title="New dark comedy for stage asks: Was Bulgaria’s King Boris III friend or foe to the Jews?" width="160" /></figure>

## After freezing arms transfers, Biden suffers backlash from pro-Israel community in US
 - [https://www.timesofisrael.com/after-freezing-arms-transfers-biden-suffers-backlash-from-pro-israel-community-in-us](https://www.timesofisrael.com/after-freezing-arms-transfers-biden-suffers-backlash-from-pro-israel-community-in-us)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T07:17:00+00:00

<p>Jewish groups, politicians criticize president for withholding supply of bombs to Israel that, citing past civilian fatalities, he does not want used in population centers in Rafah</p>
<p>The post <a href="https://www.timesofisrael.com/after-freezing-arms-transfers-biden-suffers-backlash-from-pro-israel-community-in-us/">After freezing arms transfers, Biden suffers backlash from pro-Israel community in US</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24130777924963-1024x640.jpg" title="After freezing arms transfers, Biden suffers backlash from pro-Israel community in US" width="160" /></figure>

## What Matters Now to Haviv Rettig Gur: What is antisemitism, really?
 - [https://www.timesofisrael.com/what-matters-now-to-haviv-rettig-gur-what-is-antisemitism-really](https://www.timesofisrael.com/what-matters-now-to-haviv-rettig-gur-what-is-antisemitism-really)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T06:00:34+00:00

<p>ToI's senior analyst drills down into the history and today's reports of the oldest hatred and delves into how the day commemorating its most terrible application unites Israelis</p>
<p>The post <a href="https://www.timesofisrael.com/what-matters-now-to-haviv-rettig-gur-what-is-antisemitism-really/">What Matters Now to Haviv Rettig Gur: What is antisemitism, really?</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AFP__20240503__2150570555__v3__HighRes__DuelingRalliesHeldAtGeorgeWashingtonUniversi-1-1024x640.jpg" title="What Matters Now to Haviv Rettig Gur: What is antisemitism, really?" width="160" /></figure>

## Israeli PI mistakenly freed by UK after arrest over alleged hack-for-hire scheme
 - [https://www.timesofisrael.com/israeli-pi-mistakenly-freed-by-uk-after-arrest-over-alleged-hack-for-hire-scheme](https://www.timesofisrael.com/israeli-pi-mistakenly-freed-by-uk-after-arrest-over-alleged-hack-for-hire-scheme)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T05:01:50+00:00

<p>Amit Forlit's whereabouts unknown after procedural issue leads to no-show at court hearing; private eye accused of being paid to gather information about Argentinian debt crisis</p>
<p>The post <a href="https://www.timesofisrael.com/israeli-pi-mistakenly-freed-by-uk-after-arrest-over-alleged-hack-for-hire-scheme/">Israeli PI mistakenly freed by UK after arrest over alleged hack-for-hire scheme</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP23147453822264-1024x640.jpg" title="Israeli PI mistakenly freed by UK after arrest over alleged hack-for-hire scheme" width="160" /></figure>

## Several detained at MIT for blocking parking garage in anti-Israel protest
 - [https://www.timesofisrael.com/several-detained-at-mit-for-blocking-parking-garage-in-anti-israel-protest](https://www.timesofisrael.com/several-detained-at-mit-for-blocking-parking-garage-in-anti-israel-protest)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T03:45:53+00:00

<p>Demonstrators call for prestigious Massachusetts university to 'cut ties to a state that is currently enacting a genocide,' as encampment protests continue at numerous US campuses</p>
<p>The post <a href="https://www.timesofisrael.com/several-detained-at-mit-for-blocking-parking-garage-in-anti-israel-protest/">Several detained at MIT for blocking parking garage in anti-Israel protest</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24130749441129-e1715312373502-1024x640.jpg" title="Several detained at MIT for blocking parking garage in anti-Israel protest" width="160" /></figure>

## ‘Didn’t fall from the sky’: Biden threat follows months of feeling PM ignored his warnings
 - [https://www.timesofisrael.com/didnt-fall-from-the-sky-biden-threat-due-to-months-of-feeling-pm-ignored-his-warnings](https://www.timesofisrael.com/didnt-fall-from-the-sky-biden-threat-due-to-months-of-feeling-pm-ignored-his-warnings)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T03:16:51+00:00

<p>Explaining president's radical shift, US officials say Biden kept up regular arms deliveries since October 7 but the Israelis 'knew this wasn't going to be able to go on forever'</p>
<p>The post <a href="https://www.timesofisrael.com/didnt-fall-from-the-sky-biden-threat-due-to-months-of-feeling-pm-ignored-his-warnings/">&#8216;Didn&#8217;t fall from the sky&#8217;: Biden threat follows months of feeling PM ignored his warnings</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24130777404252-1024x640.jpg" title="&#8216;Didn&#8217;t fall from the sky&#8217;: Biden threat follows months of feeling PM ignored his warnings" width="160" /></figure>

## PM hoping to overcome differences with Biden, says ‘no choice’ but to destroy Hamas
 - [https://www.timesofisrael.com/liveblog-may-10-2024](https://www.timesofisrael.com/liveblog-may-10-2024)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T02:27:40+00:00

<p>Leading American Jewish groups slam US president's decision to withhold aid: 'Undermines our ally, emboldens terror’ * IDF strikes Hezbollah sites in Lebanon after attacks on north</p>
<p>The post <a href="https://www.timesofisrael.com/liveblog-may-10-2024/">PM hoping to overcome differences with Biden, says ‘no choice’ but to destroy Hamas</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/AP23313151755188-1024x640.jpg" title="PM hoping to overcome differences with Biden, says ‘no choice’ but to destroy Hamas" width="160" /></figure>

## Wasting troops’ hard-fought gains, Israel is taking time it doesn’t have in Gaza
 - [https://www.timesofisrael.com/wasting-troops-hard-fought-gains-israel-is-taking-time-it-doesnt-have-in-gaza](https://www.timesofisrael.com/wasting-troops-hard-fought-gains-israel-is-taking-time-it-doesnt-have-in-gaza)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T01:22:52+00:00

<p>Facing a war in which speed would be paramount, the army found itself having to take it slow due to decisions made decades ago; 7 months on, Hamas is hoping to run out the clock</p>
<p>The post <a href="https://www.timesofisrael.com/wasting-troops-hard-fought-gains-israel-is-taking-time-it-doesnt-have-in-gaza/">Wasting troops&#8217; hard-fought gains, Israel is taking time it doesn&#8217;t have in Gaza</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24129537694888-1024x640.jpg" title="Wasting troops&#8217; hard-fought gains, Israel is taking time it doesn&#8217;t have in Gaza" width="160" /></figure>

## IDF cancels Lag B’Omer celebrations on Mount Meron in light of Hezbollah attacks
 - [https://www.timesofisrael.com/idf-cancels-lag-bomer-celebrations-on-mount-meron-in-light-of-hezbollah-attacks](https://www.timesofisrael.com/idf-cancels-lag-bomer-celebrations-on-mount-meron-in-light-of-hezbollah-attacks)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-05-10T00:21:19+00:00

<p>Police asked to prevent worshipers from reaching rabbi's grave for annual pilgrimage; rocket attack from Lebanon sparks blaze in northern town</p>
<p>The post <a href="https://www.timesofisrael.com/idf-cancels-lag-bomer-celebrations-on-mount-meron-in-light-of-hezbollah-attacks/">IDF cancels Lag B’Omer celebrations on Mount Meron in light of Hezbollah attacks</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/05/meron3-1024x640.jpg" title="IDF cancels Lag B’Omer celebrations on Mount Meron in light of Hezbollah attacks" width="160" /></figure>

