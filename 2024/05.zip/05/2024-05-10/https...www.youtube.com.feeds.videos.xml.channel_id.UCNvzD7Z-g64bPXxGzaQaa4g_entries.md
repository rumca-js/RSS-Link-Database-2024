# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## WARNER BROS LOSES MILLIONS ON SUICIDE SQUAD, EA ADDING IN-GAME ADS & MORE
 - [https://www.youtube.com/watch?v=Hluw7VASa2A](https://www.youtube.com/watch?v=Hluw7VASa2A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-05-10T18:10:09+00:00

Thank you Vessi for sponsoring this video. Step into Summer fun activities with Vessi. Visit https://www.vessi.com/gameranx/ for an automatic 15% off your first purchase at checkout.

~~SOURCES~~


Suicide Squad
https://www.ign.com/articles/suicide-squad-kill-the-justice-league-flop-leads-to-200-million-impairment-charge-warner-bros-confirms

EA adding ads in games
https://www.tomshardware.com/video-games/ea-is-looking-at-adding-in-game-ads-in-aaa-games-well-be-very-thoughtful-as-we-move-into-that-says-ceo

Xbox
https://www.gamesindustry.biz/xbox-reportedly-shutting-down-four-bethesda-studios

Helldivers 2 update
https://www.ign.com/articles/helldivers-2-pc-escapes-psn-account-requirement-but-ghost-of-tsushima-multiplayer-does-not

Switch 2 announcement coming (for real)
https://twitter.com/NintendoCoLtd/status/1787736518762881197


Animal Well
https://www.animalwell.net/

Little Kitty, Big City
https://store.steampowered.com/app/1177980/Little_Kitty_Big_City/

Multiversus returns May

