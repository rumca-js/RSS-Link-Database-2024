# Source:Road to VR, URL:https://www.roadtovr.com/feed, language:en-US

## Latest SteamVR Update Includes Steam Link Improvements for Quest
 - [https://www.roadtovr.com/steamvr-2-5-update-quest-steam-link](https://www.roadtovr.com/steamvr-2-5-update-quest-steam-link)
 - RSS feed: https://www.roadtovr.com/feed
 - date published: 2024-05-10T13:48:22+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="360" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2023/11/STEAM-LINK-meta-quest-640x360.jpg" style="display: block; margin-bottom: 10px; clear: both;" width="640" /><div style="margin: 5px 5% 10px 5%;"><img alt="" height="220" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2023/11/STEAM-LINK-meta-quest-341x220.jpg" title="Image courtesy Valve" width="341" /></div>
<div>The latest major SteamVR update has arrived, coming with it an improvement to Steam Link for Quest. Initially released in November 2023, Steam Link is Valve&#8217;s own app on the Meta Quest Store which allows users to quickly and easily connect their Quest headset wirelessly to SteamVR to play PC VR or flatscreen PC content, [&#8230;]</div>
<p>The post <a href="https://www.roadtovr.com/steamvr-2-5-update-quest-steam-link/" rel="nofollow">Latest SteamVR Update Includes Steam Link Improvements for Quest</a> appeared first on <a h

## ‘Pokémon Go’ Studio Releases Mixed Reality Pet ‘Hello, Dot’, Now Available on Quest 3
 - [https://www.roadtovr.com/niantic-virtual-pet-hello-dot-quest-3-release](https://www.roadtovr.com/niantic-virtual-pet-hello-dot-quest-3-release)
 - RSS feed: https://www.roadtovr.com/feed
 - date published: 2024-05-10T08:29:35+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="360" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/05/hello-dot-640x360.jpg" style="display: block; margin-bottom: 10px; clear: both;" width="640" /><div style="margin: 5px 5% 10px 5%;"><img alt="" height="220" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/05/hello-dot-341x220.jpg" title="Image courtesy Niantic" width="341" /></div>
<div>Niantic, the studio behind Pokémon Go, revealed it&#8217;s been working on a Quest 3 mixed reality experience that lets you play with your very own pint-sized virtual pet. Called Hello, Dot, Niantic calls the app a &#8220;mixed reality showcase&#8221; from its Peridot AR pet franchise, which the studio launched on mobile last year. Here&#8217;s how the studio describes Hello, [&#8230;]</div>
<p>The post <a href="https://www.roadtovr.com/niantic-virtual-pet-hello-dot-quest-3-release/" rel="nofollow">&#8216;Pokémon Go&#8217; Studio Releases Mixed Reali

