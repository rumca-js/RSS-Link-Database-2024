# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## California Will Add a Fixed Charge to Electric Bills and Reduce Rates
 - [https://www.nytimes.com/2024/05/10/business/energy-environment/california-electric-bills-fixed-charge.html](https://www.nytimes.com/2024/05/10/business/energy-environment/california-electric-bills-fixed-charge.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-05-10T15:06:48+00:00

Officials said the decision would lower bills and encourage people to use cars and appliances that did not use fossil fuels, but some experts said it would discourage energy efficiency.

## Meet Kevin’s A.I. Friends
 - [https://www.nytimes.com/2024/05/10/podcasts/hard-fork-ai-friends.html](https://www.nytimes.com/2024/05/10/podcasts/hard-fork-ai-friends.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-05-10T09:04:59+00:00

They gave him notes on his outfits and reassurance before a big talk, and they shared made-up gossip about each other.

## How Airlines Are Using AI to Make Flying Easier
 - [https://www.nytimes.com/2024/05/10/travel/airlines-artificial-intelligence.html](https://www.nytimes.com/2024/05/10/travel/airlines-artificial-intelligence.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-05-10T09:02:21+00:00

Airlines are using artificial intelligence to save fuel, keep customers informed and hold connecting flights for delayed passengers. Here’s what to expect.

