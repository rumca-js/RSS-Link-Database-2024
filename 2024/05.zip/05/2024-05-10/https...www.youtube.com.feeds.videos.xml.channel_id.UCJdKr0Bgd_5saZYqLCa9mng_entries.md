# Source:The Rubin Report, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng, language:en

## Host Goes Silent When Javier Milei Says What No Politician Will Admit
 - [https://www.youtube.com/watch?v=GKHTw0mjcq4](https://www.youtube.com/watch?v=GKHTw0mjcq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-05-10T18:15:01+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of his talk with Josh Hammer and Emily Wilson, better known as “Emily Saves America,” about how Javier Milei is already turning around Argentina’s inflation rate.
Watch Dave Rubin's FULL ROUNDTABLE: https://www.youtube.com/watch?v=ChPtA9UUEIQ&amp;list=PLEbhOtC9klbDuslX72KMcTDipzyDwaAYL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #JavierMilei #inflation #Argentina #Socialism #DaveRubin

The Rubin Report Roundtable is a place where you can hear sane discussions on controversial topics. Is the state of US news driving you crazy? Does the coverage of political news rarely seem “fair and balanced”? Serious discussions on US politics is vital to having a healthy democracy. No matter what political party you belong to, we need to be able to hear a variety of political perspectives

## Ask Any Migrant Supporter This & Watch What Happens | Mayor Francis Suarez
 - [https://www.youtube.com/watch?v=m2-Ou-WCoaI](https://www.youtube.com/watch?v=m2-Ou-WCoaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-05-10T17:15:05+00:00

Dave Rubin of “The Rubin Report” talks to Mayor Francis Suarez about Miami's immigration landscape and its impact; how the shift from wet foot, dry foot policy changed illegal immigration; how to address the root causes of migration, like political and economic desperation; how to deal with societal drug use through community engagement, mental health, and employment to prevent crime; and much more.

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

#RubinReport #Miami #Cities #Democrats #mayor #immigration #bordercrisis #migrantcrisis #migrants #FrancisSuarez #DaveRubin

Is the state of US news driving you crazy? Does the coverage of political news rarely seem “fair and balanced”? Serious discussions on US politics is vital to having a healthy democracy. No matter what political party you belong to, we need to be able to hear a variety of political perspectives. Whether you majored in political science or just want to have a deeper understanding of the issues you’l

## Kristi Noem Really Screwed Up This Fox News Interview
 - [https://www.youtube.com/watch?v=ChPtA9UUEIQ](https://www.youtube.com/watch?v=ChPtA9UUEIQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-05-10T15:00:07+00:00

Dave Rubin of “The Rubin Report” talks to Josh Hammer and Emily Wilson, better known as “Emily Saves America,” about Kristi Noem’s disastrous interview on Fox News’ “Jesse Watters Primetime,” where Jesse gave her numerous chances to clear up the story of her killing her dog as well as her “meeting” with Kim Jon Un; Greg Gutfeld and Dana Perino ripping into Kristi Noem for canceling her appearance on “Gutfeld!” as well as her book tour promoting “No Going Back”; MSNBC’s Joy Reid sharing a bizarre theory about Brittney Griner’s race and sexuality being part of the reason that she was targeted by the Putin regime; Colin Kaepernick’s interview with ISPO about the collapse of DEI; how Javier Milei is already turning around Argentina’s inflation rate; and much more.

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

Today’s Sponsors:
The Wellness Company - Replace your energy

## Don Lemon Goes Quiet After Elon Musk Explains the Simple Math of Democrat’s Plan
 - [https://www.youtube.com/watch?v=BQkJ38ETCWM](https://www.youtube.com/watch?v=BQkJ38ETCWM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-05-10T02:15:00+00:00

Dave Rubin of “The Rubin Report” reacts to a DM clip of Elon Musk explaining to Don Lemon the simple math behind how Democrats are using the migrant crisis to increase their political power.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=5S_AnGtqNQY&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#DaveRubinReacts #RubinReport #ElonMusk #math #migrants #Democrats #DonLemon #DaveRubin #Shorts

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help

## What Democrat Racism Looks Like
 - [https://www.youtube.com/watch?v=OJiiGWlsl10](https://www.youtube.com/watch?v=OJiiGWlsl10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-05-10T01:15:01+00:00

Dave Rubin of “The Rubin Report” reacts to a DM clip Kathy Hochul making racist remarks about black kids and exposing the Democrat's soft bigotry of low expectations.

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#DaveRubinReacts #Democrats #woke #KathyHochul #Shorts

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy. To hear what Dave has to say on these and a variety of other topics watch this playlist:
https://www.youtube.com/playlist?list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL

To make sure you never miss a single 

## Joe Biden Reveals Who Should Control Your Kids
 - [https://www.youtube.com/watch?v=MgeRWB6l9eY](https://www.youtube.com/watch?v=MgeRWB6l9eY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-05-10T00:15:00+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of Joe Biden attacking “anti-trans legislation” by explaining why kids are the property of the government, not their parents.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=-S6fuobLfrg&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #Biden #parentalrights #LGBTQ #trans #transkids #daverubin 

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy. To hear what Dave

