# Source:All Africa, URL:https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf, language:en

## Africa: 'Judicial Institutions Are Susceptible to Corruption'
 - [https://allafrica.com/stories/202405100439.html](https://allafrica.com/stories/202405100439.html)
 - RSS feed: https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf
 - date published: 2024-05-10T15:43:05+00:00

[Liberian Observer] While corruption has direct damaging consequences in general on the functioning of state institutions, and in particular on the administration of justice, it decreases public trust in justice and weakens the capacity of judicial systems to guarantee the protection of human rights, and it affects the tasks and duties of the judges, prosecutors, lawyers, and other legal professionals.

## Africa: French Catering Company Gives Refugee Women a Recipe for Success
 - [https://allafrica.com/stories/202405100436.html](https://allafrica.com/stories/202405100436.html)
 - RSS feed: https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf
 - date published: 2024-05-10T15:36:52+00:00

[RFI] French catering company Bande de Cheffes employs women displaced from their own countries to cook food from around the world. The goal is to make the most of refugees' talents while allowing them to earn their own living.

## Africa: Kenya Is Once Again in FATF's Crosshairs
 - [https://allafrica.com/stories/202405100119.html](https://allafrica.com/stories/202405100119.html)
 - RSS feed: https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf
 - date published: 2024-05-10T08:11:42+00:00

[ISS] To curb money laundering, financial oversight of the real estate, legal, casino and transport sectors must be improved.

## Africa: AI Becomes Latest Frontier in China-Us Race for Africa
 - [https://allafrica.com/stories/202405100088.html](https://allafrica.com/stories/202405100088.html)
 - RSS feed: https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf
 - date published: 2024-05-10T07:36:30+00:00

[VOA] Johannesburg -- What's the future of Artificial Intelligence in Africa?

