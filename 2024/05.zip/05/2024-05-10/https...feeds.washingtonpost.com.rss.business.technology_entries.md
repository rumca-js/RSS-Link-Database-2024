# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Google’s new ‘Find My’ device network is useful but a stalking risk
 - [https://www.washingtonpost.com/technology/2024/05/10/android-find-my-network-google-is-it-safe](https://www.washingtonpost.com/technology/2024/05/10/android-find-my-network-google-is-it-safe)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-05-10T16:30:00+00:00

The always-on Bluetooth tracking technologies from Apple and Google help pinpoint lost or stolen devices. But they can be abused.

## Apple apologizes for iPad ad after blowback
 - [https://www.washingtonpost.com/technology/2024/05/09/apple-ipad-ad-apology](https://www.washingtonpost.com/technology/2024/05/09/apple-ipad-ad-apology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-05-10T00:53:33+00:00

Apple has apologized for an iPad ad that appeared to destroy art supplies and musical instruments.

