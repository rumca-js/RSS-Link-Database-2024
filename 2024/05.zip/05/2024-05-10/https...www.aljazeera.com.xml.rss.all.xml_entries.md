# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Kylian Mbappe confirms he will leave Paris Saint-Germain at end of season
 - [https://www.aljazeera.com/sports/2024/5/10/kylian-mbappe-confirms-he-will-leave-paris-saint-germain-at-end-of-season?traffic_source=rss](https://www.aljazeera.com/sports/2024/5/10/kylian-mbappe-confirms-he-will-leave-paris-saint-germain-at-end-of-season?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T19:36:58+00:00

Mbappe has so far won six Ligue 1 titles and three French Cups in his seven years at PSG, his hometown club.

## UN backs Palestine’s bid for membership: How did your country vote?
 - [https://www.aljazeera.com/news/2024/5/10/un-backs-palestines-bid-for-membership-how-did-your-country-vote?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/un-backs-palestines-bid-for-membership-how-did-your-country-vote?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T18:38:51+00:00

A breakdown by country of the UN General Assembly vote on a resolution for Palestinian to become a full UN member.

## What are the takeaways for Beijing from Xi Jinping’s visit to Europe?
 - [https://www.aljazeera.com/program/inside-story/2024/5/10/what-are-the-takeaways-for-beijing-from-xi-jinpings-visit-to-europe?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/5/10/what-are-the-takeaways-for-beijing-from-xi-jinpings-visit-to-europe?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T18:23:25+00:00

Chinese president conducts five-day charm offensive, signing trade deals and pledging investments.

## Floods kill 50 people in northern Afghanistan’s Baghlan province
 - [https://www.aljazeera.com/news/2024/5/10/floods-kill-dozens-northern-afghanistan-baghlan-province?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/floods-kill-dozens-northern-afghanistan-baghlan-province?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T18:13:07+00:00

Officials say residents were unprepared for the heavy flash floods, adding that the death toll could rise.

## ‘Death sentence’: Gaza’s hospitals failing as Israel cuts off supplies
 - [https://www.aljazeera.com/program/newsfeed/2024/5/10/death-sentence-gazas-hospitals-failing-as-israel-cuts-off-supplies?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/10/death-sentence-gazas-hospitals-failing-as-israel-cuts-off-supplies?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T17:36:15+00:00

Israel’s capture and closure of the Rafah border crossing has blocked aid deliveries to Gaza.

## Mozambique’s president says northern town ‘under attack’ by armed groups
 - [https://www.aljazeera.com/news/2024/5/10/mozambiques-president-says-northern-town-under-attack-by-armed-groups?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/mozambiques-president-says-northern-town-under-attack-by-armed-groups?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T15:40:50+00:00

President Filipe Nyusi said the country&#039;s army is battling ISIL-linked groups in gas-rich Cabo Delgado&#039;s Macomia.

## United Nations General Assembly backs Palestinian bid for membership
 - [https://www.aljazeera.com/news/2024/5/10/un-general-assembly-backs-palestinian-bid-for-membership?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/un-general-assembly-backs-palestinian-bid-for-membership?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T15:27:40+00:00

Resolution does not give Palestine full UN membership, but recognises them as qualified to join and extends rights.

## Are US graduation ceremonies the latest battleground for Gaza protests?
 - [https://www.aljazeera.com/news/2024/5/10/are-us-graduation-ceremonies-the-latest-battleground-for-gaza-protests?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/are-us-graduation-ceremonies-the-latest-battleground-for-gaza-protests?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T14:50:00+00:00

Here&#039;s how pro-Palestine campus protests and encampments are affecting graduation ceremonies at US universities.

## When will EVs become mainstream in the US?
 - [https://www.aljazeera.com/economy/2024/5/10/when-will-evs-become-mainstream-in-the-us?traffic_source=rss](https://www.aljazeera.com/economy/2024/5/10/when-will-evs-become-mainstream-in-the-us?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T14:45:01+00:00

Electric vehicle adoption ‘inevitable’ in US, but unclear how fast transition will happen, experts say.

## Israel’s war on Gaza: Challenging the narrative of a “just” war
 - [https://www.aljazeera.com/program/upfront/2024/5/10/israels-war-on-gaza-challenging-the-narrative-of-a-just-war?traffic_source=rss](https://www.aljazeera.com/program/upfront/2024/5/10/israels-war-on-gaza-challenging-the-narrative-of-a-just-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T14:44:26+00:00

Marc Lamont Hill challenges Newsweek opinion editor Batya Ungar-Sargon on her support for Israel’s war on Gaza.

## Russia attempts ground offensive into Ukraine’s Kharkiv
 - [https://www.aljazeera.com/news/2024/5/10/russia-attempts-ground-offensive-into-ukraines-kharkiv?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/russia-attempts-ground-offensive-into-ukraines-kharkiv?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T13:15:39+00:00

Ukrainian forces fighting to halt new Russian assault aimed at creating Putin&#039;s planned &#039;buffer zone&#039;.

## UK revokes visa of law student who addressed pro-Palestine protest
 - [https://www.aljazeera.com/news/2024/5/10/uk-government-revokes-visa-of-palestinian-student?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/uk-government-revokes-visa-of-palestinian-student?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T13:09:46+00:00

Dana Abuqamar says her comments at a rally last year which raised suspicion were mischaracterised.

## The impact of student encampments for Gaza at universities worldwide
 - [https://www.aljazeera.com/program/the-stream/2024/5/10/the-impact-of-student-encampments-for-gaza-at-universities-worldwide?traffic_source=rss](https://www.aljazeera.com/program/the-stream/2024/5/10/the-impact-of-student-encampments-for-gaza-at-universities-worldwide?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T13:00:24+00:00

After the escalation at US student encampments, we revisit the students raising their voices to protest the war on Gaza.

## Israel’s war on Gaza brings controversy to Eurovision 2024
 - [https://www.aljazeera.com/program/newsfeed/2024/5/10/israels-war-on-gaza-brings-controversy-to-eurovision-2024?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/10/israels-war-on-gaza-brings-controversy-to-eurovision-2024?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T12:36:44+00:00

Has Israel’s war on Gaza made Saturday’s Eurovision final the most controversial one ever?

## Nigeria’s women drivers rally together to navigate male-dominated industry
 - [https://www.aljazeera.com/features/2024/5/10/nigerias-women-drivers-rally-together-to-navigate-male-dominated-industry?traffic_source=rss](https://www.aljazeera.com/features/2024/5/10/nigerias-women-drivers-rally-together-to-navigate-male-dominated-industry?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T12:01:11+00:00

From help in emergencies, to loan assistance and campaigning for women&#039;s rights, female drivers lend one another a hand.

## Tunisia: The migration trap
 - [https://www.aljazeera.com/news/2024/5/10/tunisia-the-migration-trap?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/tunisia-the-migration-trap?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T11:57:36+00:00

Asylum seekers from across Africa are becoming stranded, unable to return home and persecuted by authorities.

## India’s top court grants bail to opposition leader Arvind Kejriwal
 - [https://www.aljazeera.com/news/2024/5/10/indias-top-court-grants-bail-to-opposition-leader-arvind-kejriwal?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/indias-top-court-grants-bail-to-opposition-leader-arvind-kejriwal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T11:57:18+00:00

Supreme Court allows Delhi chief minister to leave custody until June 1, allowing him to campaign for elections.

## With measles on the rise, rebuilding trust in vaccines is a must
 - [https://www.aljazeera.com/opinions/2024/5/10/with-measles-on-the-rise-rebuilding-trust-in-vaccines-is-a-must?traffic_source=rss](https://www.aljazeera.com/opinions/2024/5/10/with-measles-on-the-rise-rebuilding-trust-in-vaccines-is-a-must?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T11:31:09+00:00

Trust in vaccines and health experts is declining, causing preventable infections like measles to become more common.

## Who is John Swinney, Scotland’s new first minister after Humza Yousaf quit?
 - [https://www.aljazeera.com/news/2024/5/10/who-is-john-swinney-scotlands-new-first-minister-after-humza-yousaf-quit?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/who-is-john-swinney-scotlands-new-first-minister-after-humza-yousaf-quit?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T10:37:57+00:00

Mild-mannered 60-year-old Swinney, who joined the SNP at 15, is the party&#039;s third leader in 14 months.

## South Africa top court hears case questioning Zuma’s electoral eligibility
 - [https://www.aljazeera.com/news/2024/5/10/south-africa-top-court-hears-case-questioning-zumas-electoral-eligibility?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/south-africa-top-court-hears-case-questioning-zumas-electoral-eligibility?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T10:19:38+00:00

Ex-president could be disqualified from running in the most competitive polls in post-apartheid history on May 29.

## Brazilian horse ‘Caramelo’ rescued after being trapped on roof by floods
 - [https://www.aljazeera.com/news/2024/5/10/brazilian-horse-caramelo-rescued-after-being-trapped-on-roof-by-floods?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/brazilian-horse-caramelo-rescued-after-being-trapped-on-roof-by-floods?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T10:14:53+00:00

Rescue brings rare good news to southern Brazil, devastated by worst flooding in 80 years that has killed more than 100.

## Gaza ceasefire talks end with no deal as Israel ramps up Rafah attacks
 - [https://www.aljazeera.com/news/2024/5/10/gaza-ceasefire-talks-end-with-no-deal-as-israel-ramps-up-rafah-attacks?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/gaza-ceasefire-talks-end-with-no-deal-as-israel-ramps-up-rafah-attacks?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T09:31:00+00:00

UNRWA official accuses Israel of subjecting Gaza to &#039;medieval siege&#039; as 110,000 Palestinians flee Rafah.

## Thousands march in Sweden’s Malmo against Israel’s Eurovision participation
 - [https://www.aljazeera.com/gallery/2024/5/10/thousands-march-in-swedens-malmo-against-israels-eurovision-participation?traffic_source=rss](https://www.aljazeera.com/gallery/2024/5/10/thousands-march-in-swedens-malmo-against-israels-eurovision-participation?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T08:30:52+00:00

Contest organisers, who say the event should be nonpolitical, resisted calls to exclude Israel over its war on Gaza.

## Iran’s Khamenei urges people to vote in parliamentary run-off amid apathy
 - [https://www.aljazeera.com/news/2024/5/10/irans-khamenei-urges-people-to-vote-in-parliamentary-run-off-amid-apathy?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/irans-khamenei-urges-people-to-vote-in-parliamentary-run-off-amid-apathy?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T07:38:33+00:00

Conservatives swept first round of parliamentary and religious assembly elections in March.

## ‘Israeli extremists’ set fire to UNRWA HQ in occupied East Jerusalem
 - [https://www.aljazeera.com/program/newsfeed/2024/5/10/israeli-extremists-set-fire-to-unrwa-hq-in-occupied-east-jerusalem?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/10/israeli-extremists-set-fire-to-unrwa-hq-in-occupied-east-jerusalem?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T07:17:36+00:00

The UN agency for Palestinian refugees says it has been forced to temporarily close its occupied east Jerusalem compound

## ‘We’ll fight with fingernails’ says Israeli PM after US warning
 - [https://www.aljazeera.com/program/newsfeed/2024/5/10/well-fight-with-fingernails-says-israeli-pm-after-us-warning?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/5/10/well-fight-with-fingernails-says-israeli-pm-after-us-warning?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T06:22:24+00:00

Israeli Prime Minister Benjamin Netanyahu said that Israel will fight alone ‘with our fingernails’ if necessary.

## Air Vanuatu goes into liquidation, thousands of passengers stranded
 - [https://www.aljazeera.com/news/2024/5/10/air-vanuatu-goes-into-liquidation-thousands-of-passengers-stranded?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/air-vanuatu-goes-into-liquidation-thousands-of-passengers-stranded?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T06:06:59+00:00

Consultants overseeing process say they hope to get the airline&#039;s four planes back in the skies as soon as possible.

## Iranian man loses bid to be freed from Australian immigration detention
 - [https://www.aljazeera.com/news/2024/5/10/iranian-man-loses-bid-to-be-freed-from-australian-immigration-detention?traffic_source=rss](https://www.aljazeera.com/news/2024/5/10/iranian-man-loses-bid-to-be-freed-from-australian-immigration-detention?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T04:54:57+00:00

Court rules detention can be justified when an individual is refusing to cooperate in their deportation.

## In India’s Arabica coffee capital, an election protest is brewing
 - [https://www.aljazeera.com/features/2024/5/10/in-indias-arabica-coffee-capital-an-election-protest-is-brewing?traffic_source=rss](https://www.aljazeera.com/features/2024/5/10/in-indias-arabica-coffee-capital-an-election-protest-is-brewing?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T04:48:18+00:00

Araku Valley coffee is sold in cafes around the world, but its farmers do not have toilets.

## Two mango seasons: A long wait for Pakistan families hit by May 9 violence
 - [https://www.aljazeera.com/features/2024/5/10/two-mango-seasons-a-long-wait-for-pakistan-families-hit-by-may-9-violence?traffic_source=rss](https://www.aljazeera.com/features/2024/5/10/two-mango-seasons-a-long-wait-for-pakistan-families-hit-by-may-9-violence?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-05-10T03:54:57+00:00

As the Supreme Court debates the convictions of 85 people, families wait for their loved ones.

