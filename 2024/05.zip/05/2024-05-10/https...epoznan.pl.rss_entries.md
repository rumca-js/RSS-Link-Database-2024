# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Wyciągnięto kobietę ze stawu. Trwa akcja służb
 - [https://epoznan.pl/news-news-150701-wyciagnieto_kobiete_ze_stawu_trwa_akcja_sluzb?rss=1](https://epoznan.pl/news-news-150701-wyciagnieto_kobiete_ze_stawu_trwa_akcja_sluzb?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T20:00:00+00:00

W miejscowości Kuczewola (powiat kaliski).

## Spłonął dom pięcioosobowej rodziny. Zostali bez dachu nad głową. Jeden z członków rodziny choruje na nowotwór. &quot;Nieszczęścia chodzą parami&quot;
 - [https://epoznan.pl/news-news-150700-splonal_dom_piecioosobowej_rodziny_zostali_bez_dachu_nad_glowa_jeden_z_czlonkow_rodziny_choruje_na_nowotwor_nieszczescia_chodza_parami?rss=1](https://epoznan.pl/news-news-150700-splonal_dom_piecioosobowej_rodziny_zostali_bez_dachu_nad_glowa_jeden_z_czlonkow_rodziny_choruje_na_nowotwor_nieszczescia_chodza_parami?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T18:40:00+00:00

Do pożaru doszło we wtorek w miejscowości Koźle (powiat szamotulski).

## Literacka: znaleziono zwłoki mężczyzny w mieszkaniu. Policja prowadzi czynności pod nadzorem prokuratury. Z mieszkania wyniesiono broń
 - [https://epoznan.pl/news-news-150699-literacka_znaleziono_zwloki_mezczyzny_w_mieszkaniu_policja_prowadzi_czynnosci_pod_nadzorem_prokuratury_z_mieszkania_wyniesiono_bron?rss=1](https://epoznan.pl/news-news-150699-literacka_znaleziono_zwloki_mezczyzny_w_mieszkaniu_policja_prowadzi_czynnosci_pod_nadzorem_prokuratury_z_mieszkania_wyniesiono_bron?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T17:58:00+00:00

W piątek ujawniono zwłoki 48-letniego mężczyzny.

## Literacka: znaleziono zwłoki mężczyzny w mieszkaniu. Policja zabezpieczyła broń. Czynności prowadzone są pod nadzorem prokuratury
 - [https://epoznan.pl/news-news-150699-literacka_znaleziono_zwloki_mezczyzny_w_mieszkaniu_policja_zabezpieczyla_bron_czynnosci_prowadzone_sa_pod_nadzorem_prokuratury?rss=1](https://epoznan.pl/news-news-150699-literacka_znaleziono_zwloki_mezczyzny_w_mieszkaniu_policja_zabezpieczyla_bron_czynnosci_prowadzone_sa_pod_nadzorem_prokuratury?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T17:58:00+00:00

W piątek ujawniono zwłoki 48-letniego mężczyzny.

## W jednym z wielkopolskich miast zniknęły banery kandydata PiS do Europarlamentu Ryszarda Czarneckiego. Zagrażały bezpieczeństwu na drodze
 - [https://epoznan.pl/news-news-150698-w_jednym_z_wielkopolskich_miast_zniknely_banery_kandydata_pis_do_europarlamentu_ryszarda_czarneckiego_zagrazaly_bezpieczenstwu_na_drodze?rss=1](https://epoznan.pl/news-news-150698-w_jednym_z_wielkopolskich_miast_zniknely_banery_kandydata_pis_do_europarlamentu_ryszarda_czarneckiego_zagrazaly_bezpieczenstwu_na_drodze?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T17:35:00+00:00

Chodzi o Kalisz.

## Właściciel &quot;Kociaka&quot; poprosił swoich klientów, żeby nie oddawali na niego głosów w plebiscycie na &quot;Osobowość Roku&quot;. &quot;Co innego, gdyby głosowanie było darmowe&quot;
 - [https://epoznan.pl/news-news-150697-wlasciciel_kociaka_poprosil_swoich_klientow_zeby_nie_oddawali_na_niego_glosow_w_plebiscycie_na_osobowosc_roku_co_innego_gdyby_glosowanie_bylo_darmowe?rss=1](https://epoznan.pl/news-news-150697-wlasciciel_kociaka_poprosil_swoich_klientow_zeby_nie_oddawali_na_niego_glosow_w_plebiscycie_na_osobowosc_roku_co_innego_gdyby_glosowanie_bylo_darmowe?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T16:38:00+00:00

Paweł Mieszała został nominowany do wyżej wspomnianego tytułu.

## Są pozytywne efekty odcinkowego pomiaru prędkości na autostradowej obwodnicy Poznania. Kierowcy zdejmują nogę z gazu
 - [https://epoznan.pl/news-news-150696-sa_pozytywne_efekty_odcinkowego_pomiaru_predkosci_na_autostradowej_obwodnicy_poznania_kierowcy_zdejmuja_noge_z_gazu?rss=1](https://epoznan.pl/news-news-150696-sa_pozytywne_efekty_odcinkowego_pomiaru_predkosci_na_autostradowej_obwodnicy_poznania_kierowcy_zdejmuja_noge_z_gazu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T15:32:00+00:00

Chodzi o odcinkowy pomiar prędkości między węzłami Poznań Komorniki i Poznań Krzesiny.

## Weszli do klatki schodowej z ulotkami. Mieli zostawić je dla mieszkańców, a zostawili własne odchody
 - [https://epoznan.pl/news-news-150695-weszli_do_klatki_schodowej_z_ulotkami_mieli_zostawic_je_dla_mieszkancow_a_zostawili_wlasne_odchody?rss=1](https://epoznan.pl/news-news-150695-weszli_do_klatki_schodowej_z_ulotkami_mieli_zostawic_je_dla_mieszkancow_a_zostawili_wlasne_odchody?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T14:40:00+00:00

Coraz większy problem na Łazarzu.

## Miasto przypomina. Zbliża się ważny termin dla poznaniaków!
 - [https://epoznan.pl/news-news-150692-miasto_przypomina_zbliza_sie_wazny_termin_dla_poznaniakow?rss=1](https://epoznan.pl/news-news-150692-miasto_przypomina_zbliza_sie_wazny_termin_dla_poznaniakow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T12:55:00+00:00

Chodzi o podatek od nieruchomości.

## Ogromne korki w okolicach ronda Starołęka. &quot;Co zrobili z sygnalizacją&quot;
 - [https://epoznan.pl/news-news-150691-ogromne_korki_w_okolicach_ronda_staroleka_co_zrobili_z_sygnalizacja?rss=1](https://epoznan.pl/news-news-150691-ogromne_korki_w_okolicach_ronda_staroleka_co_zrobili_z_sygnalizacja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T12:45:00+00:00

Zdaniem naszego Czytelnika, może być to problem z sygnalizacją świetlną w okolicach.

## Klub na Fali wciąż stoi. Kiedy może rozpocząć się demontaż?
 - [https://epoznan.pl/news-news-150689-klub_na_fali_wciaz_stoi_kiedy_moze_rozpoczac_sie_demontaz?rss=1](https://epoznan.pl/news-news-150689-klub_na_fali_wciaz_stoi_kiedy_moze_rozpoczac_sie_demontaz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T12:30:00+00:00

Mamy odpowiedź właścicieli.

## Klub na Fali wciąż stoi nad Wartą. Kiedy może rozpocząć się demontaż?
 - [https://epoznan.pl/news-news-150689-klub_na_fali_wciaz_stoi_nad_warta_kiedy_moze_rozpoczac_sie_demontaz?rss=1](https://epoznan.pl/news-news-150689-klub_na_fali_wciaz_stoi_nad_warta_kiedy_moze_rozpoczac_sie_demontaz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T12:30:00+00:00

Mamy odpowiedź właścicieli.

## 2500 zł mandatu dla rowerzysty. Sam przyjechał na komendę
 - [https://epoznan.pl/news-news-150690-2500_zl_mandatu_dla_rowerzysty_sam_przyjechal_na_komende?rss=1](https://epoznan.pl/news-news-150690-2500_zl_mandatu_dla_rowerzysty_sam_przyjechal_na_komende?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T12:15:00+00:00

Stawił się na wezwanie.

## Budowa II etapu tramwaju na Naramowice zagrożona?
 - [https://epoznan.pl/news-news-150688-budowa_ii_etapu_tramwaju_na_naramowice_zagrozona?rss=1](https://epoznan.pl/news-news-150688-budowa_ii_etapu_tramwaju_na_naramowice_zagrozona?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T12:00:00+00:00

Miasto odpowiada.

## Miasto kusi milionem złotych za frekwencję. Wszystko w rękach mieszkańców
 - [https://epoznan.pl/news-news-150687-miasto_kusi_milionem_zlotych_za_frekwencje_wszystko_w_rekach_mieszkancow?rss=1](https://epoznan.pl/news-news-150687-miasto_kusi_milionem_zlotych_za_frekwencje_wszystko_w_rekach_mieszkancow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T11:30:00+00:00

Można zdobyć dodatkowe środki dla swojego osiedla.

## 27-latek chodził z maczetą po ulicach. Są nowe informacje
 - [https://epoznan.pl/news-news-150685-27_latek_chodzil_z_maczeta_po_ulicach_sa_nowe_informacje?rss=1](https://epoznan.pl/news-news-150685-27_latek_chodzil_z_maczeta_po_ulicach_sa_nowe_informacje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T11:00:00+00:00

Sytuacja miała miejsce w ubiegłą środę.

## Recepty na tabletkę &quot;dzień po&quot; . NFZ rozwiewa wątpliwości
 - [https://epoznan.pl/news-news-150684-recepty_na_tabletke_dzien_po_nfz_rozwiewa_watpliwosci?rss=1](https://epoznan.pl/news-news-150684-recepty_na_tabletke_dzien_po_nfz_rozwiewa_watpliwosci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T10:33:00+00:00

Chodzi o pilotaż antykoncepcji awaryjnej bez limitów.

## Jest apel do właścicieli psów w Poznaniu!
 - [https://epoznan.pl/news-news-150682-jest_apel_do_wlascicieli_psow_w_poznaniu?rss=1](https://epoznan.pl/news-news-150682-jest_apel_do_wlascicieli_psow_w_poznaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T10:00:00+00:00

Chodzi o kaczki.

## Czołgi K2 nie będą produkowane w Poznaniu? Jest oficjalne stanowisko
 - [https://epoznan.pl/news-news-150680-czolgi_k2_nie_beda_produkowane_w_poznaniu_jest_oficjalne_stanowisko?rss=1](https://epoznan.pl/news-news-150680-czolgi_k2_nie_beda_produkowane_w_poznaniu_jest_oficjalne_stanowisko?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T09:30:00+00:00

Na temat  lokalizacji produkcji czołgów K2 wypowiedział się zarząd Polskiej Grupy Zbrojeniowej S.A.

## Akcja służb w magazynie Allegro
 - [https://epoznan.pl/news-news-150678-akcja_sluzb_w_magazynie_allegro?rss=1](https://epoznan.pl/news-news-150678-akcja_sluzb_w_magazynie_allegro?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T08:45:00+00:00

Sytuacja szybko została opanowana.

## Strażacy, policja i pogotowie na Jeżyckiej
 - [https://epoznan.pl/news-news-150679-strazacy_policja_i_pogotowie_na_jezyckiej?rss=1](https://epoznan.pl/news-news-150679-strazacy_policja_i_pogotowie_na_jezyckiej?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T08:40:00+00:00

Około godziny 10.

## Sporo policjantów na placu Wolności. Już dokładnie wiadomo, co się działo
 - [https://epoznan.pl/news-news-150677-sporo_policjantow_na_placu_wolnosci_juz_dokladnie_wiadomo_co_sie_dzialo?rss=1](https://epoznan.pl/news-news-150677-sporo_policjantow_na_placu_wolnosci_juz_dokladnie_wiadomo_co_sie_dzialo?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T08:30:00+00:00

W akcji brał udział sam Komendant Wojewódzki Policji w Poznaniu insp. Tomasz Olczyk.

## Urodzony w Poznaniu polityk ministrem w rządzie Donalda Tuska
 - [https://epoznan.pl/news-news-150675-urodzony_w_poznaniu_polityk_ministrem_w_rzadzie_donalda_tuska?rss=1](https://epoznan.pl/news-news-150675-urodzony_w_poznaniu_polityk_ministrem_w_rzadzie_donalda_tuska?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T07:45:00+00:00

Właśnie ogłoszono ważne zmiany.

## Szczęśliwiec zainwestował 2 złote w Wielkopolsce. Wygrał 250 tysięcy
 - [https://epoznan.pl/news-news-150674-szczesliwiec_zainwestowal_2_zlote_w_wielkopolsce_wygral_250_tysiecy?rss=1](https://epoznan.pl/news-news-150674-szczesliwiec_zainwestowal_2_zlote_w_wielkopolsce_wygral_250_tysiecy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T07:30:00+00:00

W Kaskadzie padły 2 główne wygrane po 250 000 zł każda. Jedna z nich w Wielkopolsce.

## Przez okno wypadło niemal 50 tys. zł. Już wiadomo, kto je zabrał
 - [https://epoznan.pl/news-news-150673-przez_okno_wypadlo_niemal_50_tys_zl_juz_wiadomo_kto_je_zabral?rss=1](https://epoznan.pl/news-news-150673-przez_okno_wypadlo_niemal_50_tys_zl_juz_wiadomo_kto_je_zabral?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T07:00:00+00:00

Zatrzymano dwie osoby.

## Wielkie pokazy lotnicze w Poznaniu. Jest ostrzeżenie!
 - [https://epoznan.pl/news-news-150672-wielkie_pokazy_lotnicze_w_poznaniu_jest_ostrzezenie?rss=1](https://epoznan.pl/news-news-150672-wielkie_pokazy_lotnicze_w_poznaniu_jest_ostrzezenie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T06:30:00+00:00

Ktoś próbuje podszywać się pod organizatorów.

## Porsche wstrzymało ruch tramwajów. Kierowca musi zapłacić 2000 złotych
 - [https://epoznan.pl/news-news-150671-porsche_wstrzymalo_ruch_tramwajow_kierowca_musi_zaplacic_2000_zlotych?rss=1](https://epoznan.pl/news-news-150671-porsche_wstrzymalo_ruch_tramwajow_kierowca_musi_zaplacic_2000_zlotych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T06:00:00+00:00

Na Wildzie.

## Zamiast płyt chodnikowych &quot;mała oaza zieleni&quot;. Tak zmieniła się jedna z poznańskich ulic
 - [https://epoznan.pl/news-news-150670-zamiast_plyt_chodnikowych_mala_oaza_zieleni_tak_zmienila_sie_jedna_z_poznanskich_ulic?rss=1](https://epoznan.pl/news-news-150670-zamiast_plyt_chodnikowych_mala_oaza_zieleni_tak_zmienila_sie_jedna_z_poznanskich_ulic?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-05-10T05:30:00+00:00

Zakwitną róże.

