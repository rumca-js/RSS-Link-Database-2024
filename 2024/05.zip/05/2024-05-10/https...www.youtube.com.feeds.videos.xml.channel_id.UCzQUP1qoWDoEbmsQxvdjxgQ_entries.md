# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #2149 - Sebastian Maniscalco
 - [https://www.youtube.com/watch?v=PC9svktwGng](https://www.youtube.com/watch?v=PC9svktwGng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2024-05-10T17:00:15+00:00

Sebastian Maniscalco is a comedian, actor, and host of the podcast, "The Pete and Sebastian Show" alongside Pete Correale. Watch his latest TV series, “Bookie” on Max. Catch his highly anticipated 2024 tour, “It Ain’t Right,” this coming July.

www.sebastianlive.com

