# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Hundreds of protesters attempt to storm Tesla factory
 - [https://news.sky.com/story/hundreds-of-protesters-attempt-to-storm-tesla-factory-near-berlin-13133105](https://news.sky.com/story/hundreds-of-protesters-attempt-to-storm-tesla-factory-near-berlin-13133105)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T18:38:00+00:00

Hundreds of protesters wanting to stop the expansion of a Tesla factory near Germany's capital of Berlin were blocked by police as they attempted to storm the site.

## Terror, grief and rising smoke leave streets completely empty - as Ukrainians flee border town's fiercest attack yet
 - [https://news.sky.com/story/elderly-ukrainians-evacuating-vovchansk-in-kharkiv-after-new-russian-attack-say-this-is-fiercest-fighting-theyve-seen-in-war-13133020](https://news.sky.com/story/elderly-ukrainians-evacuating-vovchansk-in-kharkiv-after-new-russian-attack-say-this-is-fiercest-fighting-theyve-seen-in-war-13133020)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T17:46:00+00:00

Russian forces launched a surprise attack early on Friday in an attempt to open a new front in the war.

## Sale of alcohol to be banned overnight in parts of Majorca and Ibiza
 - [https://news.sky.com/story/new-alcohol-ban-in-majorca-and-ibiza-marks-fresh-clampdown-on-excessive-tourism-13133007](https://news.sky.com/story/new-alcohol-ban-in-majorca-and-ibiza-marks-fresh-clampdown-on-excessive-tourism-13133007)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T17:02:00+00:00

The sale of alcohol will be totally banned between 9.30pm and 8am in areas of "excessive tourism" in Majorca and Ibiza, under a new decree passed by the government of Spain's Balearic Islands.

## Dutch Eurovision entry not rehearsing 'until further notice' over 'incident'
 - [https://news.sky.com/story/eurovision-the-netherlands-entry-joost-klein-not-rehearsing-until-further-notice-over-incident-13132862](https://news.sky.com/story/eurovision-the-netherlands-entry-joost-klein-not-rehearsing-until-further-notice-over-incident-13132862)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T13:28:00+00:00

The Netherlands' Eurovision entry Joost Klein is under investigation by the European Broadcasting Union (EBU) due to an unexplained "incident" - and will not be rehearsing again until "further notice".

## Dutch Eurovision entry stopped from rehearsing over 'incident'
 - [https://news.sky.com/story/eurovision-the-netherlands-entry-joost-klein-stopped-from-rehearsing-over-incident-13132862](https://news.sky.com/story/eurovision-the-netherlands-entry-joost-klein-stopped-from-rehearsing-over-incident-13132862)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T13:28:00+00:00

The Netherlands' Eurovision entry Joost Klein is under investigation by the European Broadcasting Union (EBU) due to an unexplained "incident" - and will not be rehearsing again until "further notice".

## FIFA offers peace talks with leagues and players over legal action threat
 - [https://news.sky.com/story/fifa-offers-peace-talks-with-leagues-and-players-over-legal-action-threat-13132801](https://news.sky.com/story/fifa-offers-peace-talks-with-leagues-and-players-over-legal-action-threat-13132801)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T11:56:00+00:00

FIFA has offered to hold peace talks with the World Leagues Association - headed by the boss of the Premier League - to stave off the threat of legal action over a new Club World Cup.

## Apple 'sorry' for crushing musical instruments and books in 'tone-deaf' advert
 - [https://news.sky.com/story/apple-apologises-for-crushing-musical-instruments-and-books-in-tone-deaf-ipad-pro-advert-13132706](https://news.sky.com/story/apple-apologises-for-crushing-musical-instruments-and-books-in-tone-deaf-ipad-pro-advert-13132706)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T09:29:00+00:00

Apple has apologised for its new iPad Pro advert where it crushed cameras, books and musical instruments, saying it "missed the mark".

## Harry and Meghan set for three-day trip to Nigeria
 - [https://news.sky.com/story/harry-and-meghan-set-for-three-day-trip-to-nigeria-13132613](https://news.sky.com/story/harry-and-meghan-set-for-three-day-trip-to-nigeria-13132613)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T05:24:00+00:00

Prince Harry and Meghan, the Duchess of Sussex, are set to start a three-day visit to Nigeria on the invitation of the country's chief of defence staff.

## Two skiers killed in avalanche in Utah mountains
 - [https://news.sky.com/story/two-skiers-killed-in-avalanche-in-utah-mountains-13132589](https://news.sky.com/story/two-skiers-killed-in-avalanche-in-utah-mountains-13132589)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-05-10T02:23:00+00:00

Two skiers have been killed during an avalanche in mountains near Salt Lake City.

