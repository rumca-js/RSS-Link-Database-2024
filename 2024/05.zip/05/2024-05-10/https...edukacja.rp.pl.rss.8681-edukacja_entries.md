# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Matura 2024: WOS - arkusze CKE
 - [https://www.rp.pl/edukacja/art40329471-matura-2024-wos-arkusze-cke](https://www.rp.pl/edukacja/art40329471-matura-2024-wos-arkusze-cke)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-05-10T12:03:14+00:00

Matura 2024 - dzień czwarty. Dziś maturzyści zmagali się z egzaminem z wiedzy o społeczeństwie na poziomie rozszerzonym. Publikujemy arkusze CKE.

## Egzamin ósmoklasisty. Informacje o egzaminie z języka polskiego
 - [https://edukacja.rp.pl/matura-i-egzamin-osmoklasisty/art40325111-egzamin-osmoklasisty-informacje-o-egzaminie-z-jezyka-polskiego](https://edukacja.rp.pl/matura-i-egzamin-osmoklasisty/art40325111-egzamin-osmoklasisty-informacje-o-egzaminie-z-jezyka-polskiego)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-05-10T10:00:00+00:00

Egzamin ósmoklasisty 2024 - język polski. Podczas egzaminu uczniowie muszą wykazać się znajomością lektur, które czytali od czwartej do ósmej klasy szkoły podstawowej. Ich znajomość może okazać się kluczowa.

