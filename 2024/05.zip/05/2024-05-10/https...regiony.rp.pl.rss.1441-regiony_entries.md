# Source:RP - Regiony, URL:https://regiony.rp.pl/rss/1441-regiony, language:pl-PL

## Tramwajem, autobusem i pociągiem tylko z jednym biletem? Nowy pomysł rządu
 - [https://regiony.rp.pl/transport/art40330171-tramwajem-autobusem-i-pociagiem-tylko-z-jednym-biletem-nowy-pomysl-rzadu](https://regiony.rp.pl/transport/art40330171-tramwajem-autobusem-i-pociagiem-tylko-z-jednym-biletem-nowy-pomysl-rzadu)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-05-10T12:17:48+00:00

Może powstać jeden bilet łączący różne rodzaje publicznego transportu. Ministerstwo Infrastruktury rozpoczęło prace nad projektem Ogólnopolskiego Biletu Zintegrowanego (OBZ).

## Rowerowa rewolucja we Francji
 - [https://regiony.rp.pl/rowerem-przez-polske/art40329961-rowerowa-rewolucja-we-francji](https://regiony.rp.pl/rowerem-przez-polske/art40329961-rowerowa-rewolucja-we-francji)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-05-10T11:59:00+00:00

Wraz z rosnącym zainteresowaniem społecznym i wsparciem ze strony państwa, Francja staje się światowym liderem w promowaniu roweru jako środka transportu. Jej przykład pokazuje, że droga do zrównoważonej mobilności bywa wyboista, ale jest możliwa do pokonania.

## E-bike na ścieżce wzrostu, czyli rewolucja w polskiej mobilności
 - [https://regiony.rp.pl/rowerem-przez-polske/art40329911-e-bike-na-sciezce-wzrostu-czyli-rewolucja-w-polskiej-mobilnosci](https://regiony.rp.pl/rowerem-przez-polske/art40329911-e-bike-na-sciezce-wzrostu-czyli-rewolucja-w-polskiej-mobilnosci)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-05-10T11:48:00+00:00

Dowodem na to, że Polska w ostatnich latach doświadcza dynamicznego rozwoju w dziedzinie nowej mobilności może być zmiana nazwy organizacji branżowej, znanej dawnej jako PSPA, a dziś jako Polskie Stowarzyszenie Nowej Mobilności – co podczas wystąpienia na 4th Polish Bicycle Summit z dumą ogłosił Maciej Mazur, dyrektor zarządzający PSNM.

## Kampania „Kręć kilometry dla Gdańska”, czyli rowerem do pracy i szkoły
 - [https://regiony.rp.pl/rowerem-przez-polske/art40329851-kampania-krec-kilometry-dla-gdanska-czyli-rowerem-do-pracy-i-szkoly](https://regiony.rp.pl/rowerem-przez-polske/art40329851-kampania-krec-kilometry-dla-gdanska-czyli-rowerem-do-pracy-i-szkoly)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-05-10T11:31:15+00:00

Kampania „Kręć kilometry dla Gdańska” to przykład miejskiej inicjatywy, która promuje zdrowy tryb życia, integruje społeczność i wspiera rozwój infrastruktury rowerowej. Jej sukces widoczny w statystykach przekłada się na rosnącą liczbę uczestników i na zaangażowanie mieszkańców.

## Gminy nie nadążają z kontrolą szamb i przydomowych oczyszczalni. Za duże koszty?
 - [https://regiony.rp.pl/ekologia/art40319461-gminy-nie-nadazaja-z-kontrola-szamb-i-przydomowych-oczyszczalni-za-duze-koszty](https://regiony.rp.pl/ekologia/art40319461-gminy-nie-nadazaja-z-kontrola-szamb-i-przydomowych-oczyszczalni-za-duze-koszty)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-05-10T11:11:27+00:00

Gminy skontrolowały w 2023 r. co czwartą posesję, na których znajdują się szamba lub przydomowe oczyszczalnie ścieków. Do początku sierpnia powinny zaś skontrolować wszystkie. Co dziewiąty samorząd nie skontrolował w zeszłym roku żadnej posesji.

