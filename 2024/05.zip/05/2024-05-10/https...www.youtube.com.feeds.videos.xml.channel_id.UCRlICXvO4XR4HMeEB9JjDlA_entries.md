# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## He Spent £70 MILLION on Hats!
 - [https://www.youtube.com/watch?v=DNzMNXvgHNg](https://www.youtube.com/watch?v=DNzMNXvgHNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2024-05-10T16:00:13+00:00

Thoughty2 Patreon & Discord: https://www.patreon.com/thoughty2
Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book

Follow Thoughty2
TikTok: https://www.tiktok.com/@realthoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

Writing: Steven Rix

Editing: Jack Stevens
Sandeep Rai

Script Development: Steven Rix

