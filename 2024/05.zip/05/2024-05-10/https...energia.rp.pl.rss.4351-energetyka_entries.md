# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Powstał zespół odpowiedzialny za wydzielanie węgla. Spółki energetyczne zyskują
 - [https://energia.rp.pl/energetyka-zawodowa/art40329971-powstal-zespol-odpowiedzialny-za-wydzielanie-wegla-spolki-energetyczne-zyskuja](https://energia.rp.pl/energetyka-zawodowa/art40329971-powstal-zespol-odpowiedzialny-za-wydzielanie-wegla-spolki-energetyczne-zyskuja)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-05-10T11:49:21+00:00

W resorcie aktywów państwowych powstał zespół ds. wydzielenia aktywów węglowych ze spółek sektora energetycznego z udziałem Skarbu Państwa - podano w zarządzeniu ministra opublikowanym w Dzienniku Urzędowym resortu. Ponownie już w tym tygodniu spółki elektroenergetyczne rosną o kilka procent.

