# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## ‘Rockstar’ Milei just loves to travel
 - [https://www.batimes.com.ar/news/opinion-and-analysis/rockstar-milei-just-loves-to-travel.phtml](https://www.batimes.com.ar/news/opinion-and-analysis/rockstar-milei-just-loves-to-travel.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-05-25T09:52:00+00:00

<p><img alt="Plata no hay art" src="https://fotos.perfil.com/2024/05/24/trim/540/304/plata-no-hay-art-1807623.jpg" /></p>For the frenetic Milei, there is no time to waste … as long as his public image remains shielded from the vicissitudes of day-to-day life, then the show must go on.
 <a href="https://www.batimes.com.ar/news/opinion-and-analysis/rockstar-milei-just-loves-to-travel.phtml">Leer más</a>

## The pain in Spain falls mainly on the gain
 - [https://www.batimes.com.ar/news/op-ed/the-pain-in-spain-falls-mainly-on-the-gain.phtml](https://www.batimes.com.ar/news/op-ed/the-pain-in-spain-falls-mainly-on-the-gain.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-05-25T09:35:00+00:00

<p><img alt="The pain in Spain falls mainly on the gain" src="https://fotos.perfil.com/2024/05/24/trim/540/304/the-pain-in-spain-falls-mainly-on-the-gain-1807613.jpg" /></p>This dispute is far more easily personalised as being between President Milei and Spain’s PM Pedro Sánchez rather than between the two nations.
 <a href="https://www.batimes.com.ar/news/op-ed/the-pain-in-spain-falls-mainly-on-the-gain.phtml">Leer más</a>

## Gulliver Milei needs to engage with the Lilliputians
 - [https://www.batimes.com.ar/news/opinion-and-analysis/gulliver-milei-needs-to-engage-with-the-lilliputians.phtml](https://www.batimes.com.ar/news/opinion-and-analysis/gulliver-milei-needs-to-engage-with-the-lilliputians.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-05-25T09:23:00+00:00

<p><img alt="Milei's Travels, Gulliver's Travels." src="https://fotos.perfil.com/2024/05/24/trim/540/304/mileis-travels-gullivers-travels-1807625.jpg" /></p>Even the Lilliputians in Jonathan Swift’s 'Gulliver’s Travels' were clever enough to feed their giant alien visitor before using him for their own advantage.
 <a href="https://www.batimes.com.ar/news/opinion-and-analysis/gulliver-milei-needs-to-engage-with-the-lilliputians.phtml">Leer más</a>

## Anti-Semitism comes back with a vengeance
 - [https://www.batimes.com.ar/news/opinion-and-analysis/anti-semitism-comes-back-with-a-vengeance.phtml](https://www.batimes.com.ar/news/opinion-and-analysis/anti-semitism-comes-back-with-a-vengeance.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-05-25T09:04:00+00:00

<p><img alt="Netanyahu and the Middle East crisis." src="https://fotos.perfil.com/2024/05/24/trim/540/304/netanyahu-and-the-middle-east-crisis-1807634.jpg" /></p>Though there has never been any shortage of reasons to persecute Jews, the chief one which underlies most others is envy.
 <a href="https://www.batimes.com.ar/news/opinion-and-analysis/anti-semitism-comes-back-with-a-vengeance.phtml">Leer más</a>

## Norberto Milei: The unknown story of the President’s father
 - [https://www.batimes.com.ar/news/opinion-and-analysis/norberto-milei-the-unknown-story-of-the-presidents-father.phtml](https://www.batimes.com.ar/news/opinion-and-analysis/norberto-milei-the-unknown-story-of-the-presidents-father.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-05-25T08:27:00+00:00

<p><img alt="Norberto Milei." src="https://fotos.perfil.com/2024/05/24/trim/540/304/norberto-milei-1807646.jpg" /></p>How President Javier Milei’s father went from being a bus-driver to businessman. His lost trials for tax evasion and the companies he formed with his daughter, Karina, to manage millions of dollars. The scenes of physical and psychological violence which distanced him from his son.
 <a href="https://www.batimes.com.ar/news/opinion-and-analysis/norberto-milei-the-unknown-story-of-the-presidents-father.phtml">Leer más</a>

## Beware coaches… success is nothing if not ephemeral
 - [https://www.batimes.com.ar/news/sports/beware-coaches-success-is-nothing-if-not-ephemeral.phtml](https://www.batimes.com.ar/news/sports/beware-coaches-success-is-nothing-if-not-ephemeral.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-05-25T08:17:00+00:00

<p><img alt="Martín Demichelis stock" src="https://fotos.perfil.com/2024/05/24/trim/540/304/martin-demichelis-stock-1807642.jpg" /></p>Football is a cut-throat business, whether you are coaching at the nation's biggest clubs or fighting down the bottom of the table.
 <a href="https://www.batimes.com.ar/news/sports/beware-coaches-success-is-nothing-if-not-ephemeral.phtml">Leer más</a>

