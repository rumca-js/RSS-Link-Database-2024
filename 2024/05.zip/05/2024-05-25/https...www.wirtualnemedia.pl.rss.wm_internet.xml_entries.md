# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Goniec: Filip Chajzer zbierał na chore dziecko, nie wypłacił jego matce 350 tys. zł
 - [https://www.wirtualnemedia.pl/artykul/fundacja-filip-chajzer-zbiorka-nie-wyplacil-na-chore-dziecko-prokuratura](https://www.wirtualnemedia.pl/artykul/fundacja-filip-chajzer-zbiorka-nie-wyplacil-na-chore-dziecko-prokuratura)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-05-25T07:48:59.892634+00:00

Popularny prezenter Filip Chajzer nie wypłacił matce śmiertelnie chorego dziecka wszystkich pieniędzy, które na leczenie chłopca zebrała fundacja celebryty – informuje portal Goniec. Sprawę bada prokuratura.

