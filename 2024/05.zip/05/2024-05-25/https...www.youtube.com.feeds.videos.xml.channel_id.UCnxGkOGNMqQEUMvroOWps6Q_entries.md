# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Safety Researchers Warn Against Mad Race Towards Sentient Artificial Intelligence
 - [https://www.youtube.com/watch?v=reekag0qFKM](https://www.youtube.com/watch?v=reekag0qFKM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2024-05-25T17:00:29+00:00

JRE #2156  w/Jeremie & Edouard Harris
YouTube: https://youtu.be/c6JdeL90ans
JRE on Spotify: https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk

