# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## Kroos will leave at the top - Ancelotti
 - [https://www.channelnewsasia.com/sport/kroos-will-leave-top-ancelotti-4364136](https://www.channelnewsasia.com/sport/kroos-will-leave-top-ancelotti-4364136)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T23:41:17+00:00



## Chebet breaks 10,000m record, Kerr beats Ingebrigtsen
 - [https://www.channelnewsasia.com/sport/chebet-breaks-10000m-record-kerr-beats-ingebrigtsen-4364056](https://www.channelnewsasia.com/sport/chebet-breaks-10000m-record-kerr-beats-ingebrigtsen-4364056)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T22:21:10+00:00



## AI in Southeast Asia: 'Algorithm hallucinations' and ethical risks as e-commerce firms adopt new technologies
 - [https://www.channelnewsasia.com/asia/ai-southeastasia-ecommerce-shopping-cyber-security-4343206](https://www.channelnewsasia.com/asia/ai-southeastasia-ecommerce-shopping-cyber-security-4343206)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T22:00:00+00:00

In the latest in a series exploring the impact of AI in Southeast Asia, e-commerce companies, experts and customers share how machine-learning is streamlining online shopping and helping retailers get to know buyers better. But at what cost?

## Commentary: Heatwaves can be deadly for older adults
 - [https://www.channelnewsasia.com/commentary/heatwave-deadly-old-ageing-population-risk-4360991](https://www.channelnewsasia.com/commentary/heatwave-deadly-old-ageing-population-risk-4360991)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T22:00:00+00:00

An ageing global population and rising temperatures mean millions are at risk, say academics from Boston University and Ca' Foscari University of Venice.

## Commentary: The extraordinary logistics of India’s election
 - [https://www.channelnewsasia.com/commentary/india-election-polling-booth-worker-electronic-voting-machine-tamper-4361011](https://www.channelnewsasia.com/commentary/india-election-polling-booth-worker-electronic-voting-machine-tamper-4361011)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T22:00:00+00:00

The experience of conducting elections in India, a developing country with remarkable diversity, merits closer examination, says this academic.

## Commentary: The way Singapore Airlines handled SQ321 turbulence crisis is a lesson for other carriers
 - [https://www.channelnewsasia.com/commentary/singapore-airlines-sia-sq321-turbulence-crisis-response-death-injuries-4361101](https://www.channelnewsasia.com/commentary/singapore-airlines-sia-sq321-turbulence-crisis-response-death-injuries-4361101)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T22:00:00+00:00

While SIA’s crisis management efforts have been lauded, the safety and security of air travel will be on the minds of passengers and airlines alike, says Endau Analytics’ Shukor Yusof.

## Preparing for Paris: What it's like to train with Singapore's Olympic-bound badminton star Loh Kean Yew
 - [https://www.channelnewsasia.com/singapore/loh-kean-yew-badminton-olympics-bwf-singapore-athlete-4315736](https://www.channelnewsasia.com/singapore/loh-kean-yew-badminton-olympics-bwf-singapore-athlete-4315736)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T22:00:00+00:00

CNA’s Matthew Mohan gets a taste of how the former world champion is gearing up for his second Olympic Games.

## Kroos bids emotional farewell to Real fans
 - [https://www.channelnewsasia.com/sport/kroos-bids-emotional-farewell-real-fans-4364001](https://www.channelnewsasia.com/sport/kroos-bids-emotional-farewell-real-fans-4364001)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T21:29:59+00:00



## Leverkusen's 'dream season' will long be remembered - Alonso
 - [https://www.channelnewsasia.com/sport/leverkusens-dream-season-will-long-be-remembered-alonso-4364006](https://www.channelnewsasia.com/sport/leverkusens-dream-season-will-long-be-remembered-alonso-4364006)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T21:28:14+00:00



## What will it take for Singapore’s yachting industry to rival that of Phuket’s? ONE15 Marina’s Johnathan Sit has a clue
 - [https://www.channelnewsasia.com/people/singapore-yachting-industry-one15-marina-regional-gm-jonathan-sit-4354921](https://www.channelnewsasia.com/people/singapore-yachting-industry-one15-marina-regional-gm-jonathan-sit-4354921)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T21:27:00+00:00

The regional general manager of ONE15 Marina wants you to forget about that typical four-hour charter and consider taking a yacht out to Indonesia’s Nirup Island instead.

## Milan draw 3-3 with Salernitana in Giroud, Pioli farewell
 - [https://www.channelnewsasia.com/sport/milan-draw-3-3-salernitana-giroud-pioli-farewell-4363991](https://www.channelnewsasia.com/sport/milan-draw-3-3-salernitana-giroud-pioli-farewell-4363991)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T21:26:09+00:00



## PSG beat Lyon 2-1 in French Cup final to clinch domestic treble
 - [https://www.channelnewsasia.com/sport/psg-beat-lyon-2-1-french-cup-final-clinch-domestic-treble-4363976](https://www.channelnewsasia.com/sport/psg-beat-lyon-2-1-french-cup-final-clinch-domestic-treble-4363976)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T21:22:38+00:00



## PSG beat Lyon 2-1 to win French Cup final in Mbappe's farewell appearance
 - [https://www.channelnewsasia.com/sport/psg-beat-lyon-2-1-win-french-cup-final-mbappes-farewell-appearance-4363976](https://www.channelnewsasia.com/sport/psg-beat-lyon-2-1-win-french-cup-final-mbappes-farewell-appearance-4363976)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T21:22:38+00:00



## World Court's order on Rafah does not rule out entire offensive, Israel says
 - [https://www.channelnewsasia.com/world/world-courts-order-rafah-does-not-rule-out-entire-offensive-israel-says-4363536](https://www.channelnewsasia.com/world/world-courts-order-rafah-does-not-rule-out-entire-offensive-israel-says-4363536)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T21:04:00+00:00



## G7 ministers move closer to Russian assets deal to help Ukraine
 - [https://www.channelnewsasia.com/world/g7-ministers-move-closer-russian-assets-deal-help-ukraine-4363926](https://www.channelnewsasia.com/world/g7-ministers-move-closer-russian-assets-deal-help-ukraine-4363926)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T20:43:37+00:00



## Ten-man Leverkusen clinch German Cup for first ever domestic double
 - [https://www.channelnewsasia.com/sport/ten-man-leverkusen-clinch-german-cup-first-ever-domestic-double-4363911](https://www.channelnewsasia.com/sport/ten-man-leverkusen-clinch-german-cup-first-ever-domestic-double-4363911)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T20:29:14+00:00



## PGA Tour player Grayson Murray dies - PGA tour
 - [https://www.channelnewsasia.com/sport/pga-tour-player-grayson-murray-dies-pga-tour-4363901](https://www.channelnewsasia.com/sport/pga-tour-player-grayson-murray-dies-pga-tour-4363901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T20:18:03+00:00



## Kewell slams referee after Marinos' CL final loss
 - [https://www.channelnewsasia.com/sport/kewell-slams-referee-after-marinos-cl-final-loss-4363891](https://www.channelnewsasia.com/sport/kewell-slams-referee-after-marinos-cl-final-loss-4363891)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T20:11:57+00:00



## FA Cup win could be glorious United farewell for Ten Hag
 - [https://www.channelnewsasia.com/sport/fa-cup-win-could-be-glorious-united-farewell-ten-hag-4363826](https://www.channelnewsasia.com/sport/fa-cup-win-could-be-glorious-united-farewell-ten-hag-4363826)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T19:35:17+00:00



## Attack kings Toulouse go on the defensive to win title
 - [https://www.channelnewsasia.com/sport/attack-kings-toulouse-go-defensive-win-title-4363796](https://www.channelnewsasia.com/sport/attack-kings-toulouse-go-defensive-win-title-4363796)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T19:13:31+00:00



## Kenyan Chebet smashes women's 10,000m world record
 - [https://www.channelnewsasia.com/sport/kenyan-chebet-smashes-womens-10000m-world-record-4363801](https://www.channelnewsasia.com/sport/kenyan-chebet-smashes-womens-10000m-world-record-4363801)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T19:11:40+00:00



## Al-Ain crush Marinos to win Asian Champions League final
 - [https://www.channelnewsasia.com/sport/al-ain-crush-marinos-win-asian-champions-league-final-4363806](https://www.channelnewsasia.com/sport/al-ain-crush-marinos-win-asian-champions-league-final-4363806)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T19:10:17+00:00



## Leclerc on pole but still haunted by the past
 - [https://www.channelnewsasia.com/sport/leclerc-pole-still-haunted-past-4363781](https://www.channelnewsasia.com/sport/leclerc-pole-still-haunted-past-4363781)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T19:08:01+00:00



## Man City final plan was not good, says Guardiola
 - [https://www.channelnewsasia.com/sport/man-city-final-plan-was-not-good-says-guardiola-4363786](https://www.channelnewsasia.com/sport/man-city-final-plan-was-not-good-says-guardiola-4363786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T19:05:08+00:00



## Juve end season with routine win over Monza
 - [https://www.channelnewsasia.com/sport/juve-end-season-routine-win-over-monza-4363761](https://www.channelnewsasia.com/sport/juve-end-season-routine-win-over-monza-4363761)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T18:59:47+00:00



## Barcelona beat Lyon 2-0 to win second straight Women's Champions League
 - [https://www.channelnewsasia.com/sport/barcelona-beat-lyon-2-0-win-second-straight-womens-champions-league-4363751](https://www.channelnewsasia.com/sport/barcelona-beat-lyon-2-0-win-second-straight-womens-champions-league-4363751)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T18:56:11+00:00



## Fire at entertainment venue kills at least 24 people in western India
 - [https://www.channelnewsasia.com/asia/fire-entertainment-venue-kills-least-24-people-western-india-4363551](https://www.channelnewsasia.com/asia/fire-entertainment-venue-kills-least-24-people-western-india-4363551)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T18:53:18+00:00



## Biden highlights US commitment to Israel, Ukraine, Indo-Pacific in West Point speech
 - [https://www.channelnewsasia.com/world/biden-highlights-us-commitment-israel-ukraine-indo-pacific-west-point-speech-4363691](https://www.channelnewsasia.com/world/biden-highlights-us-commitment-israel-ukraine-indo-pacific-west-point-speech-4363691)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T18:38:34+00:00



## Russian strikes on Ukrainian city of Kharkiv kill at least two, dozens injured
 - [https://www.channelnewsasia.com/world/russian-strikes-ukrainian-city-kharkiv-kill-least-two-dozens-injured-4363416](https://www.channelnewsasia.com/world/russian-strikes-ukrainian-city-kharkiv-kill-least-two-dozens-injured-4363416)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T17:37:00+00:00



## Verstappen says his Red Bull has a fundamental problem
 - [https://www.channelnewsasia.com/sport/verstappen-says-his-red-bull-has-fundamental-problem-4363621](https://www.channelnewsasia.com/sport/verstappen-says-his-red-bull-has-fundamental-problem-4363621)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T17:23:21+00:00



## Buttler knock guides England to 23-run victory over Pakistan
 - [https://www.channelnewsasia.com/sport/buttler-knock-guides-england-23-run-victory-over-pakistan-4363611](https://www.channelnewsasia.com/sport/buttler-knock-guides-england-23-run-victory-over-pakistan-4363611)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T17:15:39+00:00



## Sociedad win is big boost for Atletico, Lino says
 - [https://www.channelnewsasia.com/sport/sociedad-win-big-boost-atletico-lino-says-4363586](https://www.channelnewsasia.com/sport/sociedad-win-big-boost-atletico-lino-says-4363586)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T17:01:17+00:00



## Toulouse claim sixth title after epic victory over Leinster
 - [https://www.channelnewsasia.com/sport/toulouse-claim-sixth-title-after-epic-victory-over-leinster-4363541](https://www.channelnewsasia.com/sport/toulouse-claim-sixth-title-after-epic-victory-over-leinster-4363541)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T16:40:32+00:00



## Atletico Madrid end season with 2-0 win over Real Sociedad
 - [https://www.channelnewsasia.com/sport/atletico-madrid-end-season-2-0-win-over-real-sociedad-4363531](https://www.channelnewsasia.com/sport/atletico-madrid-end-season-2-0-win-over-real-sociedad-4363531)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T16:36:32+00:00



## Celtic leave it late to beat Rangers and win Scottish Cup
 - [https://www.channelnewsasia.com/sport/celtic-leave-it-late-beat-rangers-and-win-scottish-cup-4363481](https://www.channelnewsasia.com/sport/celtic-leave-it-late-beat-rangers-and-win-scottish-cup-4363481)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T16:12:18+00:00



## Man United stun Man City to win FA Cup final
 - [https://www.channelnewsasia.com/sport/man-united-stun-man-city-win-fa-cup-final-4363486](https://www.channelnewsasia.com/sport/man-united-stun-man-city-win-fa-cup-final-4363486)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T16:09:12+00:00



## Man United stun Man City to win FA Cup
 - [https://www.channelnewsasia.com/sport/fa-cup-man-united-stun-man-city-4363486](https://www.channelnewsasia.com/sport/fa-cup-man-united-stun-man-city-4363486)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T16:09:00+00:00



## Spanish defence minister says Gaza war is 'real genocide'
 - [https://www.channelnewsasia.com/world/spanish-defence-minister-says-gaza-war-real-genocide-4363386](https://www.channelnewsasia.com/world/spanish-defence-minister-says-gaza-war-real-genocide-4363386)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T15:50:17+00:00



## Pogacar poised to win Giro after solo stage 20 victory
 - [https://www.channelnewsasia.com/sport/pogacar-poised-win-giro-after-solo-stage-20-victory-4363426](https://www.channelnewsasia.com/sport/pogacar-poised-win-giro-after-solo-stage-20-victory-4363426)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T15:30:19+00:00



## Leclerc ends Verstappen's record run with Monaco pole
 - [https://www.channelnewsasia.com/sport/leclerc-ends-verstappens-record-run-monaco-pole-4363401](https://www.channelnewsasia.com/sport/leclerc-ends-verstappens-record-run-monaco-pole-4363401)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T15:12:34+00:00



## Keys eases to Strasbourg title in straight-sets win over Collins
 - [https://www.channelnewsasia.com/sport/keys-eases-strasbourg-title-straight-sets-win-over-collins-4363391](https://www.channelnewsasia.com/sport/keys-eases-strasbourg-title-straight-sets-win-over-collins-4363391)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T15:06:21+00:00



## South Africa's ruling ANC rallies to defend solo rule
 - [https://www.channelnewsasia.com/world/south-africas-ruling-anc-rallies-defend-solo-rule-4363251](https://www.channelnewsasia.com/world/south-africas-ruling-anc-rallies-defend-solo-rule-4363251)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T14:21:00+00:00



## More than 10,000 people reach UK in small boats since January
 - [https://www.channelnewsasia.com/world/more-10000-people-reach-uk-small-boats-january-4363231](https://www.channelnewsasia.com/world/more-10000-people-reach-uk-small-boats-january-4363231)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T13:58:57+00:00



## Espargaro wins Catalunya GP sprint after three race leaders crash
 - [https://www.channelnewsasia.com/sport/espargaro-wins-catalunya-gp-sprint-after-three-race-leaders-crash-4363341](https://www.channelnewsasia.com/sport/espargaro-wins-catalunya-gp-sprint-after-three-race-leaders-crash-4363341)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T13:38:57+00:00



## Nadal says 2024 may not be his last French Open, ahead of Zverev showdown
 - [https://www.channelnewsasia.com/sport/nadal-says-2024-may-not-be-his-last-french-open-ahead-zverev-showdown-4363336](https://www.channelnewsasia.com/sport/nadal-says-2024-may-not-be-his-last-french-open-ahead-zverev-showdown-4363336)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T13:36:18+00:00



## Yemen's Houthis postpone release of 100 prisoners belonging to government forces
 - [https://www.channelnewsasia.com/world/yemens-houthis-postpone-release-100-prisoners-belonging-government-forces-4363296](https://www.channelnewsasia.com/world/yemens-houthis-postpone-release-100-prisoners-belonging-government-forces-4363296)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T13:23:05+00:00



## Rooney appointed manager at Plymouth Argyle
 - [https://www.channelnewsasia.com/sport/rooney-appointed-manager-plymouth-argyle-4363301](https://www.channelnewsasia.com/sport/rooney-appointed-manager-plymouth-argyle-4363301)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T12:45:22+00:00



## Xavi 'proud and calm' after being sacked by Barcelona
 - [https://www.channelnewsasia.com/sport/xavi-proud-and-calm-after-being-sacked-barcelona-4363291](https://www.channelnewsasia.com/sport/xavi-proud-and-calm-after-being-sacked-barcelona-4363291)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T12:32:13+00:00



## Leclerc stays on top in final Monaco practice
 - [https://www.channelnewsasia.com/sport/leclerc-stays-top-final-monaco-practice-4363271](https://www.channelnewsasia.com/sport/leclerc-stays-top-final-monaco-practice-4363271)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T12:22:21+00:00



## Gaia Series 40: The Challenge Of A Young Leader
 - [https://www.channelnewsasia.com/japan-hour/gaia-series-40-challenge-young-leader-4357131](https://www.channelnewsasia.com/japan-hour/gaia-series-40-challenge-young-leader-4357131)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T12:00:00+00:00

Dive into the bustling world of Japanet Takata in Sasebo City, where dynamic leadership and innovative strategies are reshaping the future of retail in Japan.

## Osaka hopes dedication to clay pays off at Roland Garros
 - [https://www.channelnewsasia.com/sport/osaka-hopes-dedication-clay-pays-roland-garros-4363221](https://www.channelnewsasia.com/sport/osaka-hopes-dedication-clay-pays-roland-garros-4363221)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T11:32:32+00:00



## Scarred by 2020 Hindu-Muslim riots, India district voters want peace
 - [https://www.channelnewsasia.com/asia/scarred-2020-hindu-muslim-riots-india-district-voters-want-peace-4363181](https://www.channelnewsasia.com/asia/scarred-2020-hindu-muslim-riots-india-district-voters-want-peace-4363181)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T11:16:07+00:00



## G7 aims to use frozen Russian assets to help 'desperate' Ukraine
 - [https://www.channelnewsasia.com/world/g7-aims-use-frozen-russian-assets-help-desperate-ukraine-4363076](https://www.channelnewsasia.com/world/g7-aims-use-frozen-russian-assets-help-desperate-ukraine-4363076)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T10:38:00+00:00



## G7 will try to use frozen Russian assets to help Ukraine
 - [https://www.channelnewsasia.com/world/g7-will-try-use-frozen-russian-assets-help-ukraine-4363076](https://www.channelnewsasia.com/world/g7-will-try-use-frozen-russian-assets-help-ukraine-4363076)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T10:38:00+00:00



## In restive New Caledonia, Macron sees Pacific power and influence
 - [https://www.channelnewsasia.com/world/restive-new-caledonia-macron-sees-pacific-power-and-influence-4363131](https://www.channelnewsasia.com/world/restive-new-caledonia-macron-sees-pacific-power-and-influence-4363131)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T10:16:00+00:00



## Espargaro smashes lap record to take pole at Catalunya GP
 - [https://www.channelnewsasia.com/sport/espargaro-smashes-lap-record-take-pole-catalunya-gp-4363136](https://www.channelnewsasia.com/sport/espargaro-smashes-lap-record-take-pole-catalunya-gp-4363136)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T10:02:06+00:00



## Doncic drills game-winner as Mavs edge T'Wolves for 2-0 NBA series lead
 - [https://www.channelnewsasia.com/sport/doncic-drills-game-winner-mavs-edge-twolves-2-0-nba-series-lead-4362876](https://www.channelnewsasia.com/sport/doncic-drills-game-winner-mavs-edge-twolves-2-0-nba-series-lead-4362876)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T10:00:08+00:00



## Malaysian footballer discharged from hospital after acid attack: Club CEO
 - [https://www.channelnewsasia.com/sport/faisal-halim-acid-attack-malaysian-footballer-discharged-hospital-4363061](https://www.channelnewsasia.com/sport/faisal-halim-acid-attack-malaysian-footballer-discharged-hospital-4363061)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T09:37:36+00:00



## Copa America to feature its first female referees
 - [https://www.channelnewsasia.com/sport/copa-america-feature-its-first-female-referees-4363066](https://www.channelnewsasia.com/sport/copa-america-feature-its-first-female-referees-4363066)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T07:29:09+00:00



## Israel strikes Rafah after top UN court orders it to halt offensive
 - [https://www.channelnewsasia.com/world/israel-strikes-rafah-top-un-court-orders-halt-offensive-4362836](https://www.channelnewsasia.com/world/israel-strikes-rafah-top-un-court-orders-halt-offensive-4362836)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T07:28:52+00:00



## Edge buffet restaurant at Pan Pacific Hotel suspended after 16 diners fall ill
 - [https://www.channelnewsasia.com/singapore/edge-buffet-restaurant-pan-pacific-hotel-16-diners-ill-gastroenteritis-sfa-moh-4363051](https://www.channelnewsasia.com/singapore/edge-buffet-restaurant-pan-pacific-hotel-16-diners-ill-gastroenteritis-sfa-moh-4363051)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T06:37:00+00:00

The Health Ministry and the Singapore Food Agency are investigating six incidents of gastroenteritis, with 16 people falling ill after eating food prepared by Edge restaurant between May 2 and May 18.

## Djokovic worried about French Open title defence
 - [https://www.channelnewsasia.com/sport/djokovic-worried-about-french-open-title-defence-4363031](https://www.channelnewsasia.com/sport/djokovic-worried-about-french-open-title-defence-4363031)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T05:41:22+00:00



## China ends war games, Taiwan details surge in warplanes and ships
 - [https://www.channelnewsasia.com/asia/china-ends-war-games-taiwan-surge-warplanes-ships-4362806](https://www.channelnewsasia.com/asia/china-ends-war-games-taiwan-surge-warplanes-ships-4362806)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T04:48:00+00:00



## Singapore police to launch new NSF vocation to fight cybercrimes and scams
 - [https://www.channelnewsasia.com/singapore/police-launch-new-nsf-vocation-cybercrimes-scams-4362801](https://www.channelnewsasia.com/singapore/police-launch-new-nsf-vocation-cybercrimes-scams-4362801)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T02:53:47+00:00



## Taylor Swift had over 250 pairs of shoes designed by Christian Louboutin for the Eras Tour
 - [https://www.channelnewsasia.com/entertainment/taylor-swift-eras-tour-shoes-christian-louboutin-4362766](https://www.channelnewsasia.com/entertainment/taylor-swift-eras-tour-shoes-christian-louboutin-4362766)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T02:40:46+00:00

The pop superstar has worked with the French luxury shoe designer since her Reputation Tour in 2018.

## Rapper Sean Kingston and his mother allegedly stole more than US$1 million through fraud
 - [https://www.channelnewsasia.com/entertainment/rapper-sean-kingston-mother-alleged-fraud-theft-4362341](https://www.channelnewsasia.com/entertainment/rapper-sean-kingston-mother-alleged-fraud-theft-4362341)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T01:50:42+00:00

The pair are accused of stealing money, jewellery, a luxury Cadillac car and furniture.

## Canada orders dissolution of two firms, citing national security concerns
 - [https://www.channelnewsasia.com/business/canada-orders-dissolution-two-firms-citing-national-security-concerns-4362741](https://www.channelnewsasia.com/business/canada-orders-dissolution-two-firms-citing-national-security-concerns-4362741)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T01:41:05+00:00



## Singaporean doctor and medtech start-up entrepreneur Lynne Lim wins first prize at 2024 Cartier Women’s Initiative
 - [https://www.channelnewsasia.com/people/cartier-womens-initiative-lynne-lim-nousq-singapore-4360286](https://www.channelnewsasia.com/people/cartier-womens-initiative-lynne-lim-nousq-singapore-4360286)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T01:04:00+00:00

Dr Lynne Lim, an ear, nose and throat (ENT) specialist and founder of medtech start-up NousQ, was awarded first place in the Science &amp; Technology Pioneer category at the 2024 Cartier Women’s Initiative, an impact entrepreneurship programme started by the French jewellery brand to support women-led businesses driving change.

## US, China defence chiefs to meet following Taiwan tension
 - [https://www.channelnewsasia.com/asia/us-china-defence-chiefs-meet-taiwan-tension-4362541](https://www.channelnewsasia.com/asia/us-china-defence-chiefs-meet-taiwan-tension-4362541)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T00:21:40+00:00



## Exploring 3 Japanese onsen towns that are less than 3 hours away from Tokyo by shinkansen
 - [https://www.channelnewsasia.com/travel/japan-onsen-kaga-hot-springs-4351216](https://www.channelnewsasia.com/travel/japan-onsen-kaga-hot-springs-4351216)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T00:07:39+00:00

A new high-speed train stop unlocks Kaga, a destination for onsen, nourishing food and traditional crafts, as an easy-to-reach getaway from Japan's capital.

## How to get the best deals at this IKEA section that has items up to 70% off
 - [https://www.channelnewsasia.com/living/ikea-section-deals-discount-singapore-4239721](https://www.channelnewsasia.com/living/ikea-section-deals-discount-singapore-4239721)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-05-25T00:05:00+00:00

IKEA superfans know the As-Is area, where display and returned items are offered at a discounted price, is the best-kept open secret when looking for deals.

