# Source:KinoCheck, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLRlryMfL8ffxzrtqv0_k_w, language:en-US

## New MCU X-Men Movie, Pirates of the Caribbean Spin-Off, Jurassic World 4... KinoCheck News
 - [https://www.youtube.com/watch?v=rsS9O47de8E](https://www.youtube.com/watch?v=rsS9O47de8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLRlryMfL8ffxzrtqv0_k_w
 - date published: 2024-05-25T16:02:10+00:00

This time in the #KinoCheckNews "Shōgun Season 2", “The Smashing Machine”, “Vision Series”, “Pirates of the Caribbean Reboot & Spin-off”, “X-Men Movie", “Jurassic World 4”, “The Witcher 4”, “M3GAN 2.0”, “Five Nights at Freddy's 2” etc.| Subscribe ➤ https://abo.yt/ki | 2024 Movie News Show | More News https://KinoCheck.com/news

00:00 Shōgun Season 2
So it's happening after all! Although the Japanese epic "Shōgun" was planned as a mini-series and the makers repeatedly emphasized that there would be no further episodes, it seems that they have now changed their minds. Two more seasons are currently in the works…https://kinocheck.com/news/5etmp2

01:32 The Smashing Machine
He is hardly recognizable: A first picture of Dwayne Johnson as mixed martial artist Mark Kerr was posted on Instagram. He plays the real-life role model in the drama "The Smashing Machine" from A24…
https://kinocheck.com/news/9derie

02:26 Vision Series
After "Agatha All Along", the next MCU series based on the events

## I Don't Want To Be A Bird! | Spies in Disguise
 - [https://www.youtube.com/watch?v=3DjLJzEVx-o](https://www.youtube.com/watch?v=3DjLJzEVx-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLRlryMfL8ffxzrtqv0_k_w
 - date published: 2024-05-25T11:02:00+00:00



