# Source:FT - International homepage, URL:https://www.ft.com/rss/home, language:en

## Tesla investors advised to vote against Musk’s $56bn pay and Texas move
 - [https://www.ft.com/content/8d823cef-543a-4d33-afa0-c68f081842d1](https://www.ft.com/content/8d823cef-543a-4d33-afa0-c68f081842d1)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T21:41:00+00:00

Proxy adviser Glass Lewis says 2018 pay award is “excessive” and proposed reincorporation is risky

## Rishi Sunak vows to reintroduce UK national service in first major campaign policy
 - [https://www.ft.com/content/138e4d90-a92c-4a14-8978-580984ce72cd](https://www.ft.com/content/138e4d90-a92c-4a14-8978-580984ce72cd)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T21:00:51+00:00

Mandatory work for 18-year-olds would provide “opportunities” and “experience”, prime minister says

## More US high-grade borrowers at risk of downgrade as economy slows
 - [https://www.ft.com/content/fb4216bb-b04e-4615-88a4-7dfffa7c47b1](https://www.ft.com/content/fb4216bb-b04e-4615-88a4-7dfffa7c47b1)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T12:00:51+00:00

Proportion of investment-grade companies at risk of falling to junk now exceeds those likely to be upgraded

## Technology for slashing nuclear power plant waste wins Swiss backing
 - [https://www.ft.com/content/286490fd-9181-4c94-8444-a5a19621bbe6](https://www.ft.com/content/286490fd-9181-4c94-8444-a5a19621bbe6)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T12:00:51+00:00

‘Nuclear transmutation’ could cut highly radioactive waste by 80%, says national body

## Women’s football boss Michele Kang: ‘I want the next generation to compete on an equal playing field’
 - [https://www.ft.com/content/b7bb32ea-44ef-49cb-bf72-b78f6cffb1be](https://www.ft.com/content/b7bb32ea-44ef-49cb-bf72-b78f6cffb1be)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T12:00:51+00:00

Owner of teams including Olympique Lyon Féminin wants to bring better resources to the female game

## BlackRock pushed Anglo to extend talks with BHP
 - [https://www.ft.com/content/3ba432ba-dcd1-4828-90bf-66e2cc171d4d](https://www.ft.com/content/3ba432ba-dcd1-4828-90bf-66e2cc171d4d)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T11:00:51+00:00

FTSE 100 group rebuffed third takeover proposal for mining megamerger

## G7 finance chiefs back plan to leverage frozen Russian assets to fund Ukraine
 - [https://www.ft.com/content/0657aa18-24a6-4588-a6bf-746660b9ed4f](https://www.ft.com/content/0657aa18-24a6-4588-a6bf-746660b9ed4f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T10:19:08+00:00

Ministers meeting in Italy also pledge to press China to cut industrial subsidies

## Can the runaway Hoka boom last?
 - [https://www.ft.com/content/81f8def3-591d-4ae5-b93f-aaaa12cfd406](https://www.ft.com/content/81f8def3-591d-4ae5-b93f-aaaa12cfd406)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T10:16:40+00:00

Shoe beloved by runners, celebrities and Joe Biden has boosted owner Deckers Brands, but now has rivals snapping at its heels

## Trump, the limits of justice and other takeaways from the ‘hush money’ trial
 - [https://www.ft.com/content/35223a6a-a3a6-4e33-b7e6-965e817346b1](https://www.ft.com/content/35223a6a-a3a6-4e33-b7e6-965e817346b1)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T09:00:24+00:00

How a singular defendant has found ways to spin historic proceedings to his unexpected advantage

## Germany’s new generation of winegrowers
 - [https://www.ft.com/content/5b752ad1-91ec-4fba-931a-6030f8f02cb9](https://www.ft.com/content/5b752ad1-91ec-4fba-931a-6030f8f02cb9)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T04:00:24+00:00

The dark days of sweet wine and poor quality have never felt further away

## Matisse and Ellsworth Kelly, Fondation Louis Vuitton — a smart pairing of colourful masters
 - [https://www.ft.com/content/b3432539-36b0-4319-bee6-aa8e5a2321ba](https://www.ft.com/content/b3432539-36b0-4319-bee6-aa8e5a2321ba)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T04:00:24+00:00

The French painter pushed towards an architectural abstraction, which the American picked up and ran with

## Rishi Sunak and the conservative dilemma
 - [https://www.ft.com/content/b68d5861-49c3-41b3-9137-77dde3ec5114](https://www.ft.com/content/b68d5861-49c3-41b3-9137-77dde3ec5114)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T04:00:24+00:00

The right likes markets but not their cultural consequences

## What went wrong with capitalism
 - [https://www.ft.com/content/7650d057-be19-45ce-9a4e-b5ac0418d5c4](https://www.ft.com/content/7650d057-be19-45ce-9a4e-b5ac0418d5c4)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T04:00:24+00:00

America has become unhealthily dependent on loose money and big government, argues Ruchir Sharma

## Investment theme du jour: don’t overthink it
 - [https://www.ft.com/content/348edc39-eaaf-4978-a265-afa882d1b489](https://www.ft.com/content/348edc39-eaaf-4978-a265-afa882d1b489)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-05-25T03:00:24+00:00

The widespread belief that the stock market just wants to go up is conflicting with the prospect of higher-for-longer rates

