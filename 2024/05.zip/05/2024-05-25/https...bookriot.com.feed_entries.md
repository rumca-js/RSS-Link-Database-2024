# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## The Most Popular Posts of the Week
 - [https://bookriot.com/the-most-popular-posts-of-the-week](https://bookriot.com/the-most-popular-posts-of-the-week)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-05-25T17:05:02+00:00

Pets eating books, exciting books to read this summer, horror short story collections, and more in this week's most popular posts.

## Book Riot’s YA Book Deals of the Day for May 25, 2024
 - [https://bookriot.com/book-riots-ya-book-deals-of-the-day-for-may-25-2024](https://bookriot.com/book-riots-ya-book-deals-of-the-day-for-may-25-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-05-25T10:30:00+00:00

A teen living through the Kuala Lumpur race riots, a magical historical fantasy, a mission to Jupiter's moon, and more of today's best YA book deals.

## Book Riot’s Deals of the Day for May 25, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-may-25-2024](https://bookriot.com/book-riots-deals-of-the-day-for-may-25-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-05-25T10:00:00+00:00

A beautiful beekeeper, different ways to experience time, Ghanian email scams, and more of today's best book deals.

