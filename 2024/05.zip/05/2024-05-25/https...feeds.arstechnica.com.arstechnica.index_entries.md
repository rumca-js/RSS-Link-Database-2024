# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## “Deny, denounce, delay”: The battle over the risk of ultra-processed foods
 - [https://arstechnica.com/?p=2026867](https://arstechnica.com/?p=2026867)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-05-25T11:15:34+00:00

Big Food is trying to dampen fears about the effects of industrially formulated substances.

## NASA finds more issues with Boeing’s Starliner, but crew launch set for June 1
 - [https://arstechnica.com/?p=2027053](https://arstechnica.com/?p=2027053)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-05-25T03:34:42+00:00

Fixing the helium leak would delay Starliner crew test flight for months.

