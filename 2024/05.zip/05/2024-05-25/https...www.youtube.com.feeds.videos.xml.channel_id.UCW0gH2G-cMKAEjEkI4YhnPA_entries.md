# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## The Hunt For Gollum (Book Version) | Tolkien Explained
 - [https://www.youtube.com/watch?v=5gL9Ctwmc_g](https://www.youtube.com/watch?v=5gL9Ctwmc_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2024-05-25T16:00:06+00:00

Hit subscribe and the bell for great Tolkien content every week!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

NOTR merch: https://nerdoftherings.creator-spring.com/

To purchase artist work, check out these amazing artists!
Tulikoura - https://www.deviantart.com/tulikoura
Matthew Stewart - http://www.matthew-stewart.com/
BellaBergolts - https://www.deviantart.com/bellabergolts
Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney
Jerry Vanderstelt - https://vandersteltstudio.com/store/
Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Kimberly80 - https://www.deviantart.com/kimberly80
Turner Mohan - www.instagram.com/turner_mohan
Ted Nasmith - www.tednasmith.com/shop/
Anke Eissmann - http://anke.edoras-art.de/anke_illustration.html
Aronja Art - https://www.instagram.com/aronjaart/
Ivan Cavini - https://www.instagram.com/ivan_cavini/
Sara Morello - https://www.artst

