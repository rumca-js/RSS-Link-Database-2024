# Source:NPR News, URL:https://feeds.npr.org/1002/rss.xml, language:en

## Disney composer Richard Sherman has died at 95
 - [https://www.npr.org/2024/05/25/1119947006/richard-sherman-dead-disney-composer](https://www.npr.org/2024/05/25/1119947006/richard-sherman-dead-disney-composer)
 - RSS feed: https://feeds.npr.org/1002/rss.xml
 - date published: 2024-05-25T22:57:55+00:00

Sherman and his brother Robert became Disney Studios' first ever in-house songwriters. They won two Oscars for their songs and score to <em>Mary Poppins</em> and composed the classic "It's a Small World."

## Opinion: The puzzling allure of Al Capone's pistol
 - [https://www.npr.org/2024/05/25/nx-s1-4976202/opinion-the-puzzling-allure-of-al-capones-pistol](https://www.npr.org/2024/05/25/nx-s1-4976202/opinion-the-puzzling-allure-of-al-capones-pistol)
 - RSS feed: https://feeds.npr.org/1002/rss.xml
 - date published: 2024-05-25T13:08:38+00:00

There are other, more meaningful guns to pursue than Al Capone's "Sweetheart."

## When Baby Sloth tumbles out of a tree, Mama Sloth comes for him — s l o w l y
 - [https://www.npr.org/2024/05/25/1249942047/when-baby-sloth-tumbles-out-of-a-tree-mama-sloth-comes-for-him-s-l-o-w-l-y](https://www.npr.org/2024/05/25/1249942047/when-baby-sloth-tumbles-out-of-a-tree-mama-sloth-comes-for-him-s-l-o-w-l-y)
 - RSS feed: https://feeds.npr.org/1002/rss.xml
 - date published: 2024-05-25T12:43:22+00:00

Did you know on average a sloth will fall out of a tree once a week for its entire life? It's true — and the inspiration for Brian Cronin and Doreen Cronin's new children's book, <em>Mama in the Moon.</em>

## Asian adoptees: You are not alone
 - [https://www.npr.org/2024/05/25/nx-s1-4978648/adopt-adoption-aapi-heritage-month](https://www.npr.org/2024/05/25/nx-s1-4978648/adopt-adoption-aapi-heritage-month)
 - RSS feed: https://feeds.npr.org/1002/rss.xml
 - date published: 2024-05-25T11:04:00+00:00

Asian adoptees make up the majority of international adoptees in the U.S. Despite this, their stories are often left out of the conversation during AAPI Heritage month.

