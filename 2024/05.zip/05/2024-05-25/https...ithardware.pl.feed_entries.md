# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## USA: Rosja wystrzeliła broń antysatelitarną
 - [https://ithardware.pl/aktualnosci/usa_rosja_wystrzelila_bron_antysatelitarna-33219.html](https://ithardware.pl/aktualnosci/usa_rosja_wystrzelila_bron_antysatelitarna-33219.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T19:43:20+00:00

<img src="https://ithardware.pl/artykuly/min/33219_1.jpg" />            Rząd Stan&oacute;w Zjednoczonych oskarżył Rosję o wystrzelenie nowej broni antysatelitarnej, kt&oacute;ra operuje w pobliżu ważnego amerykańskiego satelity.

Rosja odm&oacute;wiła pozytywnej identyfikacji obiektu, jednak niezależni...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/usa_rosja_wystrzelila_bron_antysatelitarna-33219.html">https://ithardware.pl/aktualnosci/usa_rosja_wystrzelila_bron_antysatelitarna-33219.html</a></p>

## Pamięci HBM3E Samsunga nie spełniają wymagań Nvidii - przegrzewają się i zużywają za dużo energii
 - [https://ithardware.pl/aktualnosci/pamieci_hbm3e_samsunga_nie_spelniaja_wymagan_nvidii_przegrzewaja_sie_i_zuzywaja_za_duzo_energii-33218.html](https://ithardware.pl/aktualnosci/pamieci_hbm3e_samsunga_nie_spelniaja_wymagan_nvidii_przegrzewaja_sie_i_zuzywaja_za_duzo_energii-33218.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T19:20:40+00:00

<img src="https://ithardware.pl/artykuly/min/33218_1.png" />            Samsung zmaga się z poważnymi wyzwaniami związanymi z najnowszymi stosami pamięci HBM3 i HBM3E, kt&oacute;re nie przeszły test&oacute;w Nvidii z powodu problem&oacute;w z nadmiernym wydzielaniem ciepła i zużyciem energii.

To niepowodzenie jest...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pamieci_hbm3e_samsunga_nie_spelniaja_wymagan_nvidii_przegrzewaja_sie_i_zuzywaja_za_duzo_energii-33218.html">https://ithardware.pl/aktualnosci/pamieci_hbm3e_samsunga_nie_spelniaja_wymagan_nvidii_przegrzewaja_sie_i_zuzywaja_za_duzo_energii-33218.html</a></p>

## Elon Musk szuka inżynierów AI dla Tesli - 6-cyfrowe wynagrodzenia pomimo masowych zwolnień
 - [https://ithardware.pl/aktualnosci/elon_musk_szuka_inzynierow_ai_dla_tesli_6_cyfrowe_wynagrodzenia_pomimo_masowych_zwolnien-33217.html](https://ithardware.pl/aktualnosci/elon_musk_szuka_inzynierow_ai_dla_tesli_6_cyfrowe_wynagrodzenia_pomimo_masowych_zwolnien-33217.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T18:54:00+00:00

<img src="https://ithardware.pl/artykuly/min/33217_1.jpg" />            Tesla opublikowała nowy zbi&oacute;r ofert pracy, kt&oacute;ry odzwierciedla rosnące skupienie dyrektora generalnego Elona Muska na sztucznej inteligencji, nawet kosztem innych kluczowych grup, takich jak 500-osobowy zesp&oacute;ł...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_szuka_inzynierow_ai_dla_tesli_6_cyfrowe_wynagrodzenia_pomimo_masowych_zwolnien-33217.html">https://ithardware.pl/aktualnosci/elon_musk_szuka_inzynierow_ai_dla_tesli_6_cyfrowe_wynagrodzenia_pomimo_masowych_zwolnien-33217.html</a></p>

## W czerwcu z PS Plus zniknie 12 gier. Sony ujawnia listę
 - [https://ithardware.pl/aktualnosci/w_czerwcu_z_ps_plus_zniknie_12_gier_sony_ujawnia_liste-33216.html](https://ithardware.pl/aktualnosci/w_czerwcu_z_ps_plus_zniknie_12_gier_sony_ujawnia_liste-33216.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T18:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/33216_1.jpg" />            Sony potwierdziło, że w czerwcu z katalogu&nbsp;PlayStation Plus zostanie usuniętych 12 gier. Jeżeli ktoś więc chce ograć interesujący go tytuł, musi się pospieszyć.

W przyszłym miesiącu PS Plus Extra oraz PS Plus Premium opuści sporo...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/w_czerwcu_z_ps_plus_zniknie_12_gier_sony_ujawnia_liste-33216.html">https://ithardware.pl/aktualnosci/w_czerwcu_z_ps_plus_zniknie_12_gier_sony_ujawnia_liste-33216.html</a></p>

## Call of Duty: Black Ops 6 trafi na PS4 i Xbox One? Jest na to szansa
 - [https://ithardware.pl/aktualnosci/call_of_duty_black_ops_6_trafi_na_ps4_i_xbox_one_jest_na_to_szansa-33215.html](https://ithardware.pl/aktualnosci/call_of_duty_black_ops_6_trafi_na_ps4_i_xbox_one_jest_na_to_szansa-33215.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T17:38:00+00:00

<img src="https://ithardware.pl/artykuly/min/33215_1.jpg" />            Call of Duty: Black Ops 6 został w końcu oficjalnie zapowiedziany. Na szczeg&oacute;ły musimy jeszcze poczekać, aczkolwiek wiadomo, że gra zmierza na PC, PS5 i Xbox Series X/S. Nie wiadomo czy zagrają także posiadacze konsol poprzedniej generacji,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/call_of_duty_black_ops_6_trafi_na_ps4_i_xbox_one_jest_na_to_szansa-33215.html">https://ithardware.pl/aktualnosci/call_of_duty_black_ops_6_trafi_na_ps4_i_xbox_one_jest_na_to_szansa-33215.html</a></p>

## Aplikacja w Windowsie będzie dokładniej przewidywać pogodę dzięki sztucznej inteligencji
 - [https://ithardware.pl/aktualnosci/aplikacja_w_windowsie_bedzie_dokladniej_przewidywac_pogode_dzieki_sztucznej_inteligencji-33212.html](https://ithardware.pl/aktualnosci/aplikacja_w_windowsie_bedzie_dokladniej_przewidywac_pogode_dzieki_sztucznej_inteligencji-33212.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T16:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/33212_1.jpg" />            Zaledwie kilka tygodni temu Microsoft ogłosił, że jego zesp&oacute;ł odpowiedzialny za aplikację pogodową w systemie Windows opracował rozwiązania oparte na sztucznej inteligencji, kt&oacute;re wydają się poprawiać prognozowanie pogody w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/aplikacja_w_windowsie_bedzie_dokladniej_przewidywac_pogode_dzieki_sztucznej_inteligencji-33212.html">https://ithardware.pl/aktualnosci/aplikacja_w_windowsie_bedzie_dokladniej_przewidywac_pogode_dzieki_sztucznej_inteligencji-33212.html</a></p>

## Apple zaczęło sprzedawać odnowione iPhone 14 po niższych cenach
 - [https://ithardware.pl/aktualnosci/apple_zaczelo_sprzedawac_odnowione_iphone_14_po_nizszych_cenach-33214.html](https://ithardware.pl/aktualnosci/apple_zaczelo_sprzedawac_odnowione_iphone_14_po_nizszych_cenach-33214.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T15:07:20+00:00

<img src="https://ithardware.pl/artykuly/min/33214_1.jpg" />            Apple ruszyło ze sprzedażą odnowionych modeli iPhone 14. Firma oferuje te urządzenia w obniżonych cenach. Niestety na polskiej stronie Apple jeszcze ich nie odnajdziemy.

Opr&oacute;cz fabrycznie nowych urządzeń firma Apple ma r&oacute;wnież w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_zaczelo_sprzedawac_odnowione_iphone_14_po_nizszych_cenach-33214.html">https://ithardware.pl/aktualnosci/apple_zaczelo_sprzedawac_odnowione_iphone_14_po_nizszych_cenach-33214.html</a></p>

## Apple rozwiązuje problem z przywracanymi zdjęciami i wyjaśnia co było przyczyną błędu
 - [https://ithardware.pl/aktualnosci/apple_rozwiazuje_problem_z_przywracanymi_zdjeciami_i_wyjasnia_co_bylo_przyczyna_bledu-33210.html](https://ithardware.pl/aktualnosci/apple_rozwiazuje_problem_z_przywracanymi_zdjeciami_i_wyjasnia_co_bylo_przyczyna_bledu-33210.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/33210_1.jpg" />            Apple naprawiło błąd w iOS, kt&oacute;ry powodował, że na urządzeniu ponownie pojawiały się usunięte zdjęcia r&oacute;wnież te trwale wyrzucone z kosza. Teraz firma z Cupertino wyjaśniła,&nbsp;co stało za tym problemem.

Apple...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_rozwiazuje_problem_z_przywracanymi_zdjeciami_i_wyjasnia_co_bylo_przyczyna_bledu-33210.html">https://ithardware.pl/aktualnosci/apple_rozwiazuje_problem_z_przywracanymi_zdjeciami_i_wyjasnia_co_bylo_przyczyna_bledu-33210.html</a></p>

## HWiNFO przygotowywane na następne generacje GPU Intel. Battlemage, Celestial i Melville Sound
 - [https://ithardware.pl/aktualnosci/hwinfo_przygotowywane_na_nastepne_generacje_gpu_intel_battlemage_celestial_i_melville_sound-33213.html](https://ithardware.pl/aktualnosci/hwinfo_przygotowywane_na_nastepne_generacje_gpu_intel_battlemage_celestial_i_melville_sound-33213.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T13:08:30+00:00

<img src="https://ithardware.pl/artykuly/min/33213_1.jpg" />            Na stronie HWiNFO pojawiła się informacja o planach dodania do programu kart graficznych kolejnych generacji Intela. Wśr&oacute;d nich znajduje się między innymi Battlemage, czyli seria nadchodzących gamingowych kart dla komputer&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hwinfo_przygotowywane_na_nastepne_generacje_gpu_intel_battlemage_celestial_i_melville_sound-33213.html">https://ithardware.pl/aktualnosci/hwinfo_przygotowywane_na_nastepne_generacje_gpu_intel_battlemage_celestial_i_melville_sound-33213.html</a></p>

## Automatyczny upscaling w Windowsie - lista 12 gier, w których domyślnie będzie włączony
 - [https://ithardware.pl/aktualnosci/automatyczny_upscaling_w_windowsie_lista_12_gier_w_ktorych_domyslnie_bedzie_wlaczony-33211.html](https://ithardware.pl/aktualnosci/automatyczny_upscaling_w_windowsie_lista_12_gier_w_ktorych_domyslnie_bedzie_wlaczony-33211.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T11:47:40+00:00

<img src="https://ithardware.pl/artykuly/min/33211_1.jpg" />            Microsoft wprowadza własną technologię upscalingu, kt&oacute;ra jest wbudowana w system. Problem w tym, że na razie nie można z niej skorzystać, bo do działania wymagana jest między innymi platforma z chipem Snapdragon X.

Zaledwie kilka dni...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/automatyczny_upscaling_w_windowsie_lista_12_gier_w_ktorych_domyslnie_bedzie_wlaczony-33211.html">https://ithardware.pl/aktualnosci/automatyczny_upscaling_w_windowsie_lista_12_gier_w_ktorych_domyslnie_bedzie_wlaczony-33211.html</a></p>

## Nadchodzi nowy DOOM. Są przecieki o dacie premiery i nazwie gry
 - [https://ithardware.pl/aktualnosci/nadchodzi_nowy_doom_sa_przecieki_o_dacie_premiery_i_nazwie_gry-33209.html](https://ithardware.pl/aktualnosci/nadchodzi_nowy_doom_sa_przecieki_o_dacie_premiery_i_nazwie_gry-33209.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T10:39:10+00:00

<img src="https://ithardware.pl/artykuly/min/33209_1.jpg" />            Po 4 latach oczekiwania wreszcie zobaczymy kolejnego DOOMa. Według przeciek&oacute;w nowa gra z tej serii zostanie przedstawiona publice w trakcie wydarzenia Xbox Games Showcase. Pojawiły się r&oacute;wnież informacje zdradzające finalną nazwę...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nadchodzi_nowy_doom_sa_przecieki_o_dacie_premiery_i_nazwie_gry-33209.html">https://ithardware.pl/aktualnosci/nadchodzi_nowy_doom_sa_przecieki_o_dacie_premiery_i_nazwie_gry-33209.html</a></p>

## MSI MPG 271QRX QD-OLED - test gamingowego OLED-a z odświeżaniem 360 Hz
 - [https://ithardware.pl/testyirecenzje/msi_mpg_271qrx_qd_oled-33208.html](https://ithardware.pl/testyirecenzje/msi_mpg_271qrx_qd_oled-33208.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-05-25T06:04:34+00:00

<img src="https://ithardware.pl/artykuly/min/33208_1.jpg" />            MSI MPG 271QRX QD-OLED - test gamingowego OLED-a z odświeżaniem 360 Hz

MSI MPG 271QRX QD-OLED to jeden z przedstawicieli nowej generacji monitor&oacute;w z panelami QD-OLED dla graczy, kt&oacute;rzy szukają bezkompromisowego sprzętu najwyższej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/msi_mpg_271qrx_qd_oled-33208.html">https://ithardware.pl/testyirecenzje/msi_mpg_271qrx_qd_oled-33208.html</a></p>

