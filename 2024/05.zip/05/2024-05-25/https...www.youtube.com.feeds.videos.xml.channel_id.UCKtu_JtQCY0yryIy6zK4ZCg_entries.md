# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## ⌚ HOW TO DRAW POSES IN 2 MIN
 - [https://www.youtube.com/watch?v=ccsnOhaofAI](https://www.youtube.com/watch?v=ccsnOhaofAI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg
 - date published: 2024-05-25T11:30:27+00:00

🤯 23K SALE - Get 38% OFF the ART School: Digital Artists program  🎓 http://cgart.school until MAY 31st 2024 ONLY!! 

Join the program and access our private art community on Discord! WE JUST PASSED 23,000 ENROLLED STUDENTS! 💥 Nani?! What are you waiting for!

GESTURE DRAWING APP:
http://cbr.sh/xkbbn

REFERENCE PACKS:
https://cubebrush.co/grafit

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

🖌 Get my brushes for FREE here: http://cbr.sh/befto
💻 HOW TO USE THE FREE BRUSHES: https://youtu.be/8EC1Ibda3BI
🖌 Clip Studio Paint MB LENGENDARY Lineart Brush: http://cbr.sh/vb2lt6
🖌 Get my advanced brush set here: http://cbr.sh/btml0

🚀 My Store: https://cubebrush.co/mb
🎨 Practice files download: http://cbr.sh/xsqi64

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

FOLLOW ME ON SOCIAL MEDIA:
✏ Twitter: https://twitter.com/ytartschool
📷 Instagram: https://instagram.com/bluefley

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

#learntodraw #drawingtutorial #gesturedrawing

