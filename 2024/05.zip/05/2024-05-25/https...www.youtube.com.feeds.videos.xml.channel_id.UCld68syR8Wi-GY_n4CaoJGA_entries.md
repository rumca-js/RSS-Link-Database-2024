# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Winamp Plans To "Open The Source Code"
 - [https://www.youtube.com/watch?v=2Sy90K9CB8w](https://www.youtube.com/watch?v=2Sy90K9CB8w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-05-25T21:00:00+00:00

Winamp is a music player that I extensively used during my youth on Windows and it turns out that the project is going to "open the source code" whatever that is supposed to mean.

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Twitter Post: https://x.com/winamp/status/1791121664689725683
Press Release: https://about.winamp.com/press/article/winamp-open-source-code
XDA Developer Post: https://www.xda-developers.com/winamp-open-source/
Tech Spot Post: https://www.techspot.com/news/103039-winamp-music-player-soon-become-open-source-project.html
NFTs: https://mashable.com/article/winamp-nft-art-original-skin

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gamin

