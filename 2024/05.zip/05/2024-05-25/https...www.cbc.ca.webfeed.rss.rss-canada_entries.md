# Source:CBC | Canada News, URL:https://www.cbc.ca/webfeed/rss/rss-canada, language:en

## Should school food allergen bans be scrapped?
 - [https://www.cbc.ca/player/play/9.4233845?cmp=rss](https://www.cbc.ca/player/play/9.4233845?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-05-25T04:00:00+00:00

<img alt="CBC&apos;s Gabriel Guindi poses in the foreground with an image of peanuts in their shells spread on a table in the background" height="349" src="https://i.cbc.ca/ais/3506326a-33ec-4474-8785-afb4f532c92a,1716500006309/full/max/0/default.jpg?im=Crop%2Crect%3D%280%2C0%2C1919%2C1079%29%3BResize%3D%28620%29" title="" width="620" /><p>Allergy Quebec is recommending the removal of peanut bans in schools, favouring education and awareness like other provinces have done.</p>

