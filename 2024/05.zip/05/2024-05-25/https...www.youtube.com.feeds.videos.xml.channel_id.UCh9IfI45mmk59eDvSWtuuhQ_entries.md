# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## When Your Algorithm Starts Judging You
 - [https://www.youtube.com/watch?v=yDSJGjarfMk](https://www.youtube.com/watch?v=yDSJGjarfMk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2024-05-25T17:27:46+00:00

Go to https://ground.news/ryangeorge to start discovering your own blindspots. Subscribe through my link for 40% off unlimited access this month.

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats and dog and child.
TikTok/Instagram: @TheRyanGeorge

Written in collaboration with Scott Roberts

