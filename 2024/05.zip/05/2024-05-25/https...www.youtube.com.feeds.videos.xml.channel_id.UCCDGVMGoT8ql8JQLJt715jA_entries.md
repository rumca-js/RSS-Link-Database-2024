# Source:emzdanowicz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA, language:pl

## Nowa gra Valve. Czy Deadlock będzie hitem?
 - [https://www.youtube.com/watch?v=fTdX2MjyC8M](https://www.youtube.com/watch?v=fTdX2MjyC8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA
 - date published: 2024-05-25T06:45:02+00:00

Valve znów spróbuje sił na poletku gier sieciowych. Jaki będzie Deadlock? Czy to klon Overwatcha? Na szczęście wiele wskazuje na to, że nie... A zapowiedź zapewne już blisko.

0:00 Valve robi nową grę
1:44 Czym jest Deadlock
2:51 Cztery ścieżki i... tower defense?
4:25 Setting i postacie
6:08 Deadlock naprawdę się ukaże
7:54 Czy czekam?

Zobacz też:

- Moja recenzja gry Indika: https://www.youtube.com/watch?v=9LvLeg0SI9U
- Moje wrażenia z Hadesa 2: https://www.youtube.com/watch?v=mlY0TTI7N_o

Na moim kanale znajdziesz recenzje gier wideo (oraz wrażenia czy opinie z wersji beta czy Early Access). Recenzje gier na PC, recenzje gier konsolowych (gry na PS5, Switch, Xbox). Nieważne, czy twoją ulubioną platformą do gier jest PC, Xbox, Playstation czy coś od Nintendo - wierzę, że znajdziesz tu coś dla siebie :)

#valve #deadlock

