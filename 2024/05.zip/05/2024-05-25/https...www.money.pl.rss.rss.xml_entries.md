# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Największa sensacja na Wall Street zalicza kolejny kwartał spektakularnego wzrostu [WYKRES TYGODNIA]
 - [https://www.money.pl/gielda/tomasz-hondo/najwieksza-sensacja-na-wall-street-zalicza-kolejny-kwartal-spektakularnego-wzrostu-wykres-tygodnia-7030996362037952a.html](https://www.money.pl/gielda/tomasz-hondo/najwieksza-sensacja-na-wall-street-zalicza-kolejny-kwartal-spektakularnego-wzrostu-wykres-tygodnia-7030996362037952a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-05-25T15:24:30+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ed6bfc43-862a-483c-9081-757cb9a6d812" width="308" /> Nvidia to od pewnego czasu największa sensacja na Wall Street. Od kilku kwartałów notuje gwałtowny wzrost przychodów i zysku na akcję. Zagrożeniem dla giełdowej wyceny ulubieńca inwestorów byłoby dopiero zatrzymanie wzrostu, a następnie załamanie zysków - pisze dla money.pl analityk Tomasz Hońdo.

## Amerykanie kupili bank w Polsce, by go sprzedać. Kiedy i za ile?
 - [https://www.money.pl/banki/amerykanie-kupili-bank-w-polsce-by-go-sprzedac-kiedy-i-za-ile-7030312199613120a.html](https://www.money.pl/banki/amerykanie-kupili-bank-w-polsce-by-go-sprzedac-kiedy-i-za-ile-7030312199613120a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-05-25T14:42:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/66ff4870-e7d3-4864-aa2c-1427d262af25" width="308" /> - Zapewniam, że nie będziemy najbardziej agresywnym bankiem na rynku - mówi w wywiadzie dla money.pl Adam Marciniak, prezes VeloBanku. W marcu amerykański fundusz Cerberus kupił bank za ponad miliard złotych po to, by za kilka lat sprzedać go za co najmniej dwa razy tyle.

## Co zrobić z pieniędzmi na wypadek wojny? Ekspert ma złotą radę
 - [https://www.money.pl/pieniadze/co-zrobic-z-pieniedzmi-na-wypadek-wojny-ekspert-ma-zlota-rade-7031329488644800a.html](https://www.money.pl/pieniadze/co-zrobic-z-pieniedzmi-na-wypadek-wojny-ekspert-ma-zlota-rade-7031329488644800a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-05-25T11:23:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/af3135ea-ec08-44eb-8d56-09e0140c0d44" width="308" /> Część klasy średniej drży, kiedy myśli o losach swoich oszczędnościach w kontekście zagrożenia wojną. Maciej Samcik, twórca portalu "Subiektywnie o finansach" podzielił się swoją radą, która może okazać się receptą na to zmartwienie Polaków.

## Żarty w tytułach przelewów mogą skończyć się poważnymi konsekwencjami
 - [https://www.money.pl/banki/zarty-w-tytulach-przelewow-moga-skonczyc-sie-powaznymi-konsekwencjami-7030972907120769a.html](https://www.money.pl/banki/zarty-w-tytulach-przelewow-moga-skonczyc-sie-powaznymi-konsekwencjami-7030972907120769a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-05-25T11:20:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/61105e5b-1306-48f2-b159-607d18be5b5b" width="308" /> Tytuły przelewów bankowych mogą zawierać różnorodne wpisy, czasem nawet dość nietypowe. Krzysztof Drozd, starszy specjalista ds. relacji z mediami w mBanku, w rozmowie z o2.pl zaznaczał, że w pewnych sytuacjach bank ma prawo zwrócić się do klienta z prośbą o wyjaśnienia.

## Koniec "13" i "14" emerytury? Ekspert ma inny pomysł na emerytów
 - [https://www.money.pl/emerytury/trzynastki-i-czternastki-do-skasowania-jest-inny-pomysl-na-emerytow-7031275625790208a.html](https://www.money.pl/emerytury/trzynastki-i-czternastki-do-skasowania-jest-inny-pomysl-na-emerytow-7031275625790208a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-05-25T07:31:41+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/79cf7ec0-b4c7-475f-8fc1-db57a3d770b8" width="308" /> Eksperci proponują zmiany w dodatkach dla emerytów. Ich zdaniem trzynaste i czternaste emerytury powinny zniknąć. Co w zamian? O tym mówił dr Tomasz Lasocki z Wydziału Prawa i Administracji Uniwersytetu Warszawskiego.

