# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## The Mortal Realms Reforged Preview and US Open Dallas - Highlights
 - [https://www.youtube.com/watch?v=qcnM8e6b4uM](https://www.youtube.com/watch?v=qcnM8e6b4uM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2024-05-25T15:00:45+00:00

Catch up with the reveals from the Mortal Realms Reforged event! https://ow.ly/ZVhn50RU0x3

Follow for more Warhammer, more often:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/

