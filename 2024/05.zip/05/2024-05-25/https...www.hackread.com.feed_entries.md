# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Data Leak Exposes 500GB of Indian Police, Military Biometric Data
 - [https://www.hackread.com/data-leak-indian-police-military-biometric-data](https://www.hackread.com/data-leak-indian-police-military-biometric-data)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2024-05-25T13:31:29+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>The records belonged to two separate India-based firms, ThoughtGreen Technologies and Timing Technologies. Both provide application development, RFID technology, and biometric verification services.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/data-leak-indian-police-military-biometric-data/" rel="nofollow">Data Leak Exposes 500GB of Indian Police, Military Biometric Data</a></p>

