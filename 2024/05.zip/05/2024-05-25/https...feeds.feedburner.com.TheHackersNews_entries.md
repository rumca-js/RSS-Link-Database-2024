# Source:The Hacker News, URL:https://feeds.feedburner.com/TheHackersNews, language:en-US

## Experts Find Flaw in Replicate AI Service Exposing Customers' Models and Data
 - [https://thehackernews.com/2024/05/experts-find-flaw-in-replicate-ai.html](https://thehackernews.com/2024/05/experts-find-flaw-in-replicate-ai.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-05-25T09:11:00+00:00

Cybersecurity researchers have discovered a critical security flaw in an artificial intelligence (AI)-as-a-service provider&nbsp;Replicate&nbsp;that could have allowed threat actors to gain access to proprietary AI models and sensitive information.
"Exploitation of this vulnerability would have allowed unauthorized access to the AI prompts and results of all Replicate's platform customers,"

